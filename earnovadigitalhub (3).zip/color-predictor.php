<?php
require_once 'config/database.php';
require_once 'includes/session.php';
require_once 'includes/connect.php';

// Require authentication
requireLogin();
checkSessionTimeout();

// Get current user data
$user = getCurrentUser();
$user_id = $user['id'];

try {
    $pdo = getDBConnection();
    
    // Fetch user details with balance
    $stmt = $pdo->prepare("
        SELECT u.*, b.total_balance, b.task_earnings, b.referral_earnings
        FROM users u
        LEFT JOIN balances b ON u.id = b.user_id
        WHERE u.id = ?
    ");
    $stmt->execute([$user_id]);
    $user_data = $stmt->fetch();
    
    if (!$user_data) {
        header('Location: login.php');
        exit;
    }
    
    $is_premium = ($user_data['membership_type'] === 'premium');
    
    if (!$is_premium) {
        ?>
        <!DOCTYPE html>
        <html lang="en">
        <head>
          <meta charset="UTF-8" />
          <meta name="viewport" content="width=device-width, initial-scale=1.0" />
          <title>Color Predictor - FlowEarner</title>
          <style>
            :root {
              --page-blue-900: #030922;
              --page-blue-700: #0a164a;
              --page-blue-500: #142a7e;
              --page-mint: #4de1c1;
              --page-white: #f5f9ff;
              --page-orange: #fb923c;
            }

            * { box-sizing: border-box; margin: 0; padding: 0; }

            body {
              font-family: "Titillium Web", "Segoe UI", sans-serif;
              background: radial-gradient(circle at 0% 0%, rgba(61, 116, 255, 0.28), transparent 55%),
                          radial-gradient(circle at 100% 0%, rgba(77, 225, 193, 0.18), transparent 40%),
                          linear-gradient(180deg, var(--page-blue-900), var(--page-blue-700));
              color: var(--page-white);
              min-height: 100vh;
              overflow: hidden;
            }

            .lock-overlay {
              position: fixed;
              top: 0;
              left: 0;
              width: 100vw;
              height: 100vh;
              background: rgba(5, 10, 25, 0.75);
              backdrop-filter: blur(6px);
              display: flex;
              justify-content: center;
              align-items: center;
              z-index: 9999;
            }

            .lock-container {
              position: relative;
              max-width: 600px;
              width: 90%;
              text-align: center;
              background: rgba(13, 24, 62, 0.85);
              backdrop-filter: blur(20px);
              border: 1px solid rgba(86, 139, 241, 0.3);
              border-radius: 24px;
              padding: clamp(32px, 5vw, 48px);
              box-shadow: 0 40px 120px rgba(4, 10, 36, 0.7);
              z-index: 10000;
            }

            .lock-icon {
              width: 120px;
              height: 120px;
              margin: 0 auto 24px;
              background: linear-gradient(135deg, rgba(251, 146, 60, 0.2), rgba(239, 68, 68, 0.2));
              border-radius: 50%;
              display: flex;
              align-items: center;
              justify-content: center;
              border: 3px solid rgba(251, 146, 60, 0.4);
            }

            .lock-icon svg {
              width: 60px;
              height: 60px;
              fill: var(--page-orange);
              filter: drop-shadow(0 4px 12px rgba(251, 146, 60, 0.5));
            }

            h1 {
              font-size: clamp(1.8rem, 4vw, 2.4rem);
              margin-bottom: 16px;
              color: var(--page-white);
              letter-spacing: 0.02em;
            }

            .lock-message {
              font-size: clamp(1rem, 2vw, 1.1rem);
              line-height: 1.7;
              color: rgba(216, 230, 255, 0.85);
              margin-bottom: 32px;
            }

            .upgrade-btn {
              display: inline-block;
              padding: 16px 40px;
              background: linear-gradient(135deg, #fb923c, #f97316);
              color: var(--page-blue-900);
              font-size: 1.1rem;
              font-weight: 700;
              border: none;
              border-radius: 14px;
              cursor: pointer;
              text-decoration: none;
              transition: transform 0.3s ease, box-shadow 0.3s ease;
              box-shadow: 0 12px 28px rgba(251, 146, 60, 0.4);
              letter-spacing: 0.02em;
            }

            .upgrade-btn:hover {
              transform: translateY(-3px);
              box-shadow: 0 16px 36px rgba(251, 146, 60, 0.5);
            }

            .back-link {
              display: inline-block;
              margin-top: 24px;
              color: rgba(210, 226, 255, 0.7);
              text-decoration: none;
              font-size: 0.95rem;
              transition: color 0.3s ease;
            }

            .back-link:hover {
              color: var(--page-mint);
            }
          </style>
        </head>
        <body>
          <div class="lock-overlay">
            <div class="lock-container">
              <div class="lock-icon">
                <svg viewBox="0 0 24 24">
                  <path d="M12 2a5 5 0 0 1 5 5v3h1a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V12a2 2 0 0 1 2-2h1V7a5 5 0 0 1 5-5Zm0 2a3 3 0 0 0-3 3v3h6V7a3 3 0 0 0-3-3Zm-6 9v8h12v-8H6Zm6 2a2 2 0 1 1 0 4 2 2 0 0 1 0-4Z"/>
                </svg>
              </div>
              
              <h1>Premium Members Only</h1>
              
              <p class="lock-message">
                Color Predictor is an exclusive game for <strong>Premium Members</strong>. Upgrade now to unlock this exciting game and start winning real rewards!
              </p>
            
              <a href="membership.php" class="upgrade-btn">Upgrade to Premium</a>
              
              <br>
              <a href="play-earn.php" class="back-link">← Back to Games</a>
            </div>
          </div>
        </body>
        </html>
        <?php
        exit;
    }
    
    $today = date('Y-m-d');
    if ($user_data['color_predictor_last_reset'] !== $today) {
        $stmt = $pdo->prepare("UPDATE users SET color_predictor_free_plays = 2, color_predictor_last_reset = ? WHERE id = ?");
        $stmt->execute([$today, $user_id]);
        $user_data['color_predictor_free_plays'] = 2;
    }
    
} catch (PDOException $e) {
    error_log("Color Predictor Error: " . $e->getMessage());
    $error_message = "Unable to load game data.";
}

$task_earnings = $user_data['task_earnings'] ?? 0;
$free_plays = $user_data['color_predictor_free_plays'] ?? 0;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Color Predictor - FlowEarner</title>
    <style>
        body {
            margin: 0;
            font-family: 'Inter', sans-serif;
            background: linear-gradient(135deg, #0a0e27 0%, #1a1f3a 100%);
            color: #fff;
            overflow-x: hidden;
        }
        
        .container {
            max-width: 1400px;
            margin: 0 auto;
            padding: 20px;
        }
        
        .page-header {
            text-align: center;
            padding: 40px 20px;
            background: linear-gradient(135deg, rgba(255, 77, 77, 0.2), rgba(77, 225, 193, 0.1));
            border-radius: 20px;
            margin-bottom: 30px;
            box-shadow: 0 0 40px rgba(255, 77, 77, 0.3);
        }
        
        .page-header h1 {
            font-size: 3rem;
            margin: 0 0 10px;
            background: linear-gradient(135deg, #ff4d4d, #4de1c1);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            text-shadow: 0 0 30px rgba(255, 77, 77, 0.5);
        }
        
        .page-header p {
            font-size: 1.2rem;
            color: rgba(255, 255, 255, 0.7);
        }
        
        .back-link {
            display: inline-block;
            margin-bottom: 20px;
            padding: 10px 20px;
            background: rgba(77, 225, 193, 0.2);
            border: 2px solid rgba(77, 225, 193, 0.3);
            border-radius: 10px;
            color: #4de1c1;
            text-decoration: none;
            font-weight: 600;
            transition: all 0.3s ease;
        }
        
        .back-link:hover {
            background: rgba(77, 225, 193, 0.3);
            transform: translateX(-5px);
        }
        
        .game-container {
            display: grid;
            grid-template-columns: 2fr 1fr;
            gap: 30px;
            margin-bottom: 30px;
        }
        
        .game-board {
            background: linear-gradient(135deg, rgba(26, 58, 171, 0.3), rgba(5, 16, 58, 0.5));
            border: 2px solid rgba(77, 225, 193, 0.3);
            border-radius: 20px;
            padding: 30px;
        }
        
        .color-options {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 20px;
            margin-bottom: 30px;
        }
        
        .color-option {
            aspect-ratio: 1;
            border-radius: 20px;
            border: 3px solid transparent;
            cursor: pointer;
            transition: all 0.3s ease;
            position: relative;
            overflow: hidden;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 2rem;
            font-weight: 700;
        }
        
        .color-option.red {
            background: linear-gradient(135deg, #ff4d4d, #ff1744);
            box-shadow: 0 10px 40px rgba(255, 77, 77, 0.4);
        }
        
        .color-option.green {
            background: linear-gradient(135deg, #4de1c1, #00e676);
            box-shadow: 0 10px 40px rgba(77, 225, 193, 0.4);
        }
        
        .color-option.blue {
            background: linear-gradient(135deg, #2c5bf5, #448aff);
            box-shadow: 0 10px 40px rgba(44, 91, 245, 0.4);
        }
        
        .color-option:hover {
            transform: scale(1.05);
            border-color: #fff;
        }
        
        .color-option.selected {
            border-color: #fff;
            box-shadow: 0 0 60px currentColor;
            animation: pulse 1s infinite;
        }
        
        @keyframes pulse {
            0%, 100% { transform: scale(1); }
            50% { transform: scale(1.05); }
        }
        
        .result-display {
            background: rgba(255, 255, 255, 0.05);
            border: 2px solid rgba(77, 225, 193, 0.3);
            border-radius: 15px;
            padding: 30px;
            text-align: center;
            min-height: 200px;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
        }
        
        .result-color {
            width: 150px;
            height: 150px;
            border-radius: 50%;
            margin-bottom: 20px;
            display: none;
            animation: colorReveal 0.5s ease;
        }
        
        @keyframes colorReveal {
            0% { transform: scale(0); opacity: 0; }
            100% { transform: scale(1); opacity: 1; }
        }
        
        .result-text {
            font-size: 2rem;
            font-weight: 700;
            margin-bottom: 10px;
        }
        
        .result-amount {
            font-size: 2.5rem;
            font-weight: 900;
            color: #4de1c1;
        }
        
        .game-controls {
            background: linear-gradient(135deg, rgba(26, 58, 171, 0.3), rgba(5, 16, 58, 0.5));
            border: 2px solid rgba(77, 225, 193, 0.3);
            border-radius: 20px;
            padding: 25px;
        }
        
        .balance-display {
            background: rgba(44, 91, 245, 0.2);
            border: 1px solid rgba(44, 91, 245, 0.5);
            border-radius: 15px;
            padding: 15px;
            margin-bottom: 20px;
        }
        
        .balance-item {
            display: flex;
            justify-content: space-between;
            margin-bottom: 10px;
        }
        
        .balance-label {
            color: rgba(255, 255, 255, 0.7);
        }
        
        .balance-value {
            font-weight: 700;
            color: #4de1c1;
        }
        
        .bet-input {
            width: 100%;
            padding: 15px;
            border-radius: 10px;
            border: 2px solid rgba(77, 225, 193, 0.3);
            background: rgba(255, 255, 255, 0.05);
            color: #fff;
            font-size: 1.1rem;
            margin-bottom: 15px;
        }
        
        .play-btn {
            width: 100%;
            padding: 18px;
            border-radius: 15px;
            border: none;
            background: linear-gradient(135deg, #ff4d4d, #ff1744);
            color: #fff;
            font-size: 1.2rem;
            font-weight: 700;
            cursor: pointer;
            transition: all 0.3s ease;
            box-shadow: 0 0 30px rgba(255, 77, 77, 0.5);
            margin-bottom: 10px;
        }
        
        .play-btn:hover {
            transform: scale(1.05);
            box-shadow: 0 0 50px rgba(255, 77, 77, 0.8);
        }
        
        .play-btn:disabled {
            opacity: 0.5;
            cursor: not-allowed;
        }
        
        .free-play-btn {
            background: linear-gradient(135deg, #ff914d, #ff6b6b);
        }
        
        .multiplier-info {
            margin-top: 20px;
            padding: 15px;
            background: rgba(255, 255, 255, 0.05);
            border-radius: 10px;
        }
        
        .multiplier-info h4 {
            margin-top: 0;
            margin-bottom: 15px;
            color: #4de1c1;
        }
        
        .multiplier-list {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 10px;
            font-size: 0.9rem;
        }
        
        .multiplier-item {
            display: flex;
            justify-content: space-between;
            padding: 8px;
            background: rgba(255, 255, 255, 0.05);
            border-radius: 8px;
        }
        
        .multiplier-item.rare {
            background: rgba(255, 215, 0, 0.1);
            border: 1px solid rgba(255, 215, 0, 0.3);
        }
        
        /* Custom Popup Modal */
        .game-popup {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.9);
            z-index: 1000;
            align-items: center;
            justify-content: center;
        }
        
        .game-popup.active {
            display: flex;
        }
        
        .popup-content {
            background: linear-gradient(135deg, rgba(26, 58, 171, 0.95), rgba(5, 16, 58, 0.95));
            border: 3px solid rgba(77, 225, 193, 0.5);
            border-radius: 30px;
            padding: 40px;
            text-align: center;
            max-width: 500px;
            width: 90%;
            box-shadow: 0 0 80px rgba(44, 91, 245, 0.8);
            animation: popIn 0.5s ease;
        }
        
        @keyframes popIn {
            0% { transform: scale(0.5); opacity: 0; }
            100% { transform: scale(1); opacity: 1; }
        }
        
        .popup-icon {
            width: 120px;
            height: 120px;
            margin: 0 auto 20px;
            animation: bounce 1s infinite;
        }
        
        @keyframes bounce {
            0%, 100% { transform: translateY(0); }
            50% { transform: translateY(-20px); }
        }
        
        .popup-title {
            font-size: 2.5rem;
            font-weight: 900;
            margin-bottom: 15px;
        }
        
        .popup-message {
            font-size: 1.2rem;
            margin-bottom: 20px;
            color: rgba(255, 255, 255, 0.8);
        }
        
        .popup-amount {
            font-size: 3rem;
            font-weight: 900;
            color: #4de1c1;
            margin-bottom: 30px;
            text-shadow: 0 0 20px rgba(77, 225, 193, 0.8);
        }
        
        .popup-buttons {
            display: flex;
            gap: 15px;
            justify-content: center;
        }
        
        .popup-btn {
            padding: 15px 30px;
            border-radius: 15px;
            border: none;
            font-size: 1.1rem;
            font-weight: 700;
            cursor: pointer;
            transition: all 0.3s ease;
        }
        
        .popup-btn.primary {
            background: linear-gradient(135deg, #4de1c1, #00e676);
            color: #0a0e27;
        }
        
        .popup-btn.secondary {
            background: rgba(255, 255, 255, 0.1);
            color: #fff;
            border: 2px solid rgba(255, 255, 255, 0.3);
        }
        
        .popup-btn:hover {
            transform: scale(1.05);
        }
        
        /* Leaderboard */
        .leaderboard {
            background: linear-gradient(135deg, rgba(26, 58, 171, 0.3), rgba(5, 16, 58, 0.5));
            border: 2px solid rgba(77, 225, 193, 0.3);
            border-radius: 20px;
            padding: 25px;
            margin-top: 30px;
        }
        
        .leaderboard h3 {
            margin-top: 0;
            font-size: 1.8rem;
            background: linear-gradient(135deg, #ff4d4d, #4de1c1);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }
        
        .leaderboard-list {
            display: flex;
            flex-direction: column;
            gap: 15px;
        }
        
        .leaderboard-item {
            display: grid;
            grid-template-columns: 50px 60px 1fr auto auto;
            gap: 15px;
            align-items: center;
            background: rgba(255, 255, 255, 0.05);
            padding: 15px;
            border-radius: 15px;
            border: 1px solid rgba(77, 225, 193, 0.2);
            transition: all 0.3s ease;
        }
        
        .leaderboard-item:hover {
            background: rgba(255, 255, 255, 0.1);
            border-color: rgba(77, 225, 193, 0.5);
        }
        
        .rank {
            font-size: 1.5rem;
            font-weight: 700;
            color: #4de1c1;
        }
        
        .rank.gold { color: #ffd700; }
        .rank.silver { color: #c0c0c0; }
        .rank.bronze { color: #cd7f32; }
        
        .player-avatar {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            border: 2px solid rgba(77, 225, 193, 0.5);
        }
        
        .player-info {
            display: flex;
            flex-direction: column;
        }
        
        .player-name {
            font-weight: 700;
            font-size: 1.1rem;
        }
        
        .player-username {
            color: rgba(255, 255, 255, 0.6);
            font-size: 0.9rem;
        }
        
        .stat {
            text-align: right;
        }
        
        .stat-label {
            color: rgba(255, 255, 255, 0.6);
            font-size: 0.8rem;
        }
        
        .stat-value {
            font-weight: 700;
            color: #4de1c1;
            font-size: 1.1rem;
        }
        
        @media (max-width: 768px) {
            .game-container {
                grid-template-columns: 1fr;
            }
            
            .leaderboard-item {
                grid-template-columns: 40px 50px 1fr;
                gap: 10px;
            }
            
            .stat {
                display: none;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <a href="play-earn.php" class="back-link">← Back to Games</a>
        
        <div class="page-header">
            <h1>🎨 Color Predictor</h1>
            <p>Choose your color and predict the outcome to win big!</p>
        </div>
        
        <div class="game-container">
            <div class="game-board">
                <h2 style="margin-top: 0;">Select Your Color</h2>
                <div class="color-options">
                    <div class="color-option red" data-color="red" onclick="selectColor('red')">
                        <svg width="80" height="80" viewBox="0 0 100 100" style="filter: drop-shadow(0 0 10px rgba(255,255,255,0.5));">
                            <circle cx="50" cy="50" r="40" fill="rgba(255,255,255,0.3)" stroke="#fff" stroke-width="3"/>
                            <text x="50" y="65" font-size="24" font-weight="bold" fill="#fff" text-anchor="middle">RED</text>
                        </svg>
                    </div>
                    <div class="color-option green" data-color="green" onclick="selectColor('green')">
                        <svg width="80" height="80" viewBox="0 0 100 100" style="filter: drop-shadow(0 0 10px rgba(255,255,255,0.5));">
                            <circle cx="50" cy="50" r="40" fill="rgba(255,255,255,0.3)" stroke="#fff" stroke-width="3"/>
                            <text x="50" y="65" font-size="20" font-weight="bold" fill="#fff" text-anchor="middle">GREEN</text>
                        </svg>
                    </div>
                    <div class="color-option blue" data-color="blue" onclick="selectColor('blue')">
                        <svg width="80" height="80" viewBox="0 0 100 100" style="filter: drop-shadow(0 0 10px rgba(255,255,255,0.5));">
                            <circle cx="50" cy="50" r="40" fill="rgba(255,255,255,0.3)" stroke="#fff" stroke-width="3"/>
                            <text x="50" y="65" font-size="24" font-weight="bold" fill="#fff" text-anchor="middle">BLUE</text>
                        </svg>
                    </div>
                </div>
                
                <div class="result-display" id="resultDisplay">
                    <div class="result-color" id="resultColor"></div>
                    <div class="result-text" id="resultText">Select a color and place your bet!</div>
                    <div class="result-amount" id="resultAmount"></div>
                </div>
            </div>
            
            <div class="game-controls">
                <div class="balance-display">
                    <div class="balance-item">
                        <span class="balance-label">Task Balance:</span>
                        <span class="balance-value" id="taskBalance">₦<?php echo number_format($task_earnings, 2); ?></span>
                    </div>
                    <div class="balance-item">
                        <span class="balance-label">Free Plays:</span>
                        <span class="balance-value" id="freePlays"><?php echo $free_plays; ?>/2</span>
                    </div>
                </div>
                
                <input type="number" class="bet-input" id="betAmount" placeholder="Enter bet amount (min ₦1,000)" min="1000" step="100" value="1000">
                
                <button class="play-btn free-play-btn" id="freePlayBtn" onclick="playGame(true)" <?php echo $free_plays <= 0 ? 'disabled' : ''; ?>>
                    🎁 Play Free (<?php echo $free_plays; ?> left)
                </button>
                
                <button class="play-btn" id="betPlayBtn" onclick="playGame(false)">
                    💰 Play with Bet
                </button>
                
                <div class="multiplier-info">
                    <h4>Win Multipliers:</h4>
                    <div class="multiplier-list">
                        <div class="multiplier-item">
                            <span>x0 (Lose)</span>
                            <span>50%</span>
                        </div>
                        <div class="multiplier-item">
                            <span>x1.5</span>
                            <span>30%</span>
                        </div>
                        <div class="multiplier-item">
                            <span>x2</span>
                            <span>15%</span>
                        </div>
                        <div class="multiplier-item rare">
                            <span>x3 🎰</span>
                            <span>5%</span>
                        </div>
                    </div>
                    <p style="margin-top: 15px; font-size: 0.85rem; color: rgba(255, 255, 255, 0.6);">
                        Minimum win: ₦50 | Maximum multiplier: x3
                    </p>
                </div>
            </div>
        </div>
        
         Leaderboard 
        <div class="leaderboard">
            <h3>🏆 Top Players</h3>
            <div class="leaderboard-list" id="leaderboardList">
                <div style="text-align: center; padding: 20px; color: rgba(255, 255, 255, 0.5);">
                    Loading leaderboard...
                </div>
            </div>
        </div>
    </div>
    
     Custom Popup Modal 
    <div class="game-popup" id="gamePopup">
        <div class="popup-content">
            <div class="popup-icon" id="popupIcon"></div>
            <div class="popup-title" id="popupTitle">You Won!</div>
            <div class="popup-message" id="popupMessage">Congratulations!</div>
            <div class="popup-amount" id="popupAmount">₦0.00</div>
            <div class="popup-buttons">
                <button class="popup-btn primary" onclick="closePopup()">✓ Awesome!</button>
                <button class="popup-btn secondary" onclick="playAgain()">🔄 Play Again</button>
            </div>
        </div>
    </div>
    
    <script>
        let selectedColor = null;
        let isPlaying = false;
        
        function selectColor(color) {
            selectedColor = color;
            document.querySelectorAll('.color-option').forEach(el => {
                el.classList.remove('selected');
            });
            document.querySelector(`.color-option.${color}`).classList.add('selected');
        }
        
        async function playGame(isFree) {
            if (isPlaying) return;
            
            if (!selectedColor) {
                showPopup('error', 'No Color Selected', 'Please select a color first!', '');
                return;
            }
            
            const betAmount = isFree ? 0 : parseFloat(document.getElementById('betAmount').value);
            
            if (!isFree && (isNaN(betAmount) || betAmount < 1000)) {
                showPopup('error', 'Invalid Bet', 'Minimum bet amount is ₦1,000', '');
                return;
            }
            
            isPlaying = true;
            document.getElementById('freePlayBtn').disabled = true;
            document.getElementById('betPlayBtn').disabled = true;
            
            // Show loading state
            document.getElementById('resultText').textContent = 'Predicting...';
            document.getElementById('resultAmount').textContent = '';
            document.getElementById('resultColor').style.display = 'none';
            
            try {
                const response = await fetch('api/color-predictor-play.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        selected_color: selectedColor,
                        bet_amount: betAmount,
                        is_free_play: isFree
                    })
                });
                
                const data = await response.json();
                
                if (data.success) {
                    // Show result color animation
                    const resultColor = document.getElementById('resultColor');
                    resultColor.className = 'result-color ' + data.result_color;
                    resultColor.style.display = 'block';
                    
                    // Update balances
                    document.getElementById('taskBalance').textContent = '₦' + parseFloat(data.new_balance).toFixed(2);
                    document.getElementById('freePlays').textContent = data.free_plays_remaining + '/2';
                    
                    // Update free play button
                    const freePlayBtn = document.getElementById('freePlayBtn');
                    if (data.free_plays_remaining <= 0) {
                        freePlayBtn.disabled = true;
                        freePlayBtn.textContent = '🎁 No Free Plays Left';
                    } else {
                        freePlayBtn.textContent = `🎁 Play Free (${data.free_plays_remaining} left)`;
                    }
                    
                    // Show result after animation
                    setTimeout(() => {
                        if (data.multiplier > 0) {
                            document.getElementById('resultText').textContent = `${data.result_color.toUpperCase()}! You Won!`;
                            document.getElementById('resultAmount').textContent = '₦' + parseFloat(data.win_amount).toFixed(2);
                            
                            // Show win popup
                            if (data.multiplier >= 3) {
                                showPopup('jackpot', 'JACKPOT! 🎰', `You hit the rare x3 multiplier!`, '₦' + parseFloat(data.win_amount).toFixed(2));
                            } else if (data.multiplier >= 2) {
                                showPopup('bigwin', 'Big Win! 🎉', `x${data.multiplier} multiplier!`, '₦' + parseFloat(data.win_amount).toFixed(2));
                            } else {
                                showPopup('win', 'You Won! ✨', `x${data.multiplier} multiplier`, '₦' + parseFloat(data.win_amount).toFixed(2));
                            }
                        } else {
                            document.getElementById('resultText').textContent = `${data.result_color.toUpperCase()}! Try Again!`;
                            document.getElementById('resultAmount').textContent = '₦0.00';
                            showPopup('lose', 'Better Luck Next Time! 😔', 'The color was ' + data.result_color.toUpperCase(), '');
                        }
                        
                        // Reload leaderboard
                        loadLeaderboard();
                    }, 1000);
                } else {
                    showPopup('error', 'Error', data.message || 'An error occurred', '');
                }
            } catch (error) {
                console.error('Error:', error);
                showPopup('error', 'Error', 'An error occurred. Please try again.', '');
            }
            
            isPlaying = false;
            document.getElementById('freePlayBtn').disabled = false;
            document.getElementById('betPlayBtn').disabled = false;
        }
        
        function showPopup(type, title, message, amount) {
            const popup = document.getElementById('gamePopup');
            const icon = document.getElementById('popupIcon');
            const titleEl = document.getElementById('popupTitle');
            const messageEl = document.getElementById('popupMessage');
            const amountEl = document.getElementById('popupAmount');
            
            // Set icon based on type
            const icons = {
                'jackpot': '<svg width="120" height="120" viewBox="0 0 100 100"><circle cx="50" cy="50" r="45" fill="#ffd700" stroke="#fff" stroke-width="3"/><text x="50" y="65" font-size="40" text-anchor="middle">🎰</text></svg>',
                'bigwin': '<svg width="120" height="120" viewBox="0 0 100 100"><circle cx="50" cy="50" r="45" fill="#4de1c1" stroke="#fff" stroke-width="3"/><text x="50" y="65" font-size="40" text-anchor="middle">🎉</text></svg>',
                'win': '<svg width="120" height="120" viewBox="0 0 100 100"><circle cx="50" cy="50" r="45" fill="#2c5bf5" stroke="#fff" stroke-width="3"/><text x="50" y="65" font-size="40" text-anchor="middle">✨</text></svg>',
                'lose': '<svg width="120" height="120" viewBox="0 0 100 100"><circle cx="50" cy="50" r="45" fill="#ff4d4d" stroke="#fff" stroke-width="3"/><text x="50" y="65" font-size="40" text-anchor="middle">😔</text></svg>',
                'error': '<svg width="120" height="120" viewBox="0 0 100 100"><circle cx="50" cy="50" r="45" fill="#ff4d4d" stroke="#fff" stroke-width="3"/><text x="50" y="65" font-size="40" text-anchor="middle">⚠️</text></svg>'
            };
            
            icon.innerHTML = icons[type] || icons['win'];
            titleEl.textContent = title;
            messageEl.textContent = message;
            amountEl.textContent = amount;
            amountEl.style.display = amount ? 'block' : 'none';
            
            popup.classList.add('active');
        }
        
        function closePopup() {
            document.getElementById('gamePopup').classList.remove('active');
        }
        
        function playAgain() {
            closePopup();
            selectedColor = null;
            document.querySelectorAll('.color-option').forEach(el => {
                el.classList.remove('selected');
            });
            document.getElementById('resultText').textContent = 'Select a color and place your bet!';
            document.getElementById('resultAmount').textContent = '';
            document.getElementById('resultColor').style.display = 'none';
        }
        
        async function loadLeaderboard() {
            try {
                const response = await fetch('api/color-predictor-leaderboard.php');
                const data = await response.json();
                
                if (data.success && data.leaderboard.length > 0) {
                    const leaderboardList = document.getElementById('leaderboardList');
                    leaderboardList.innerHTML = data.leaderboard.map((player, index) => `
                        <div class="leaderboard-item">
                            <div class="rank ${index === 0 ? 'gold' : index === 1 ? 'silver' : index === 2 ? 'bronze' : ''}">#${index + 1}</div>
                            <img src="${player.profile_picture || 'front/assets/images/default-avatar.png'}" alt="${player.username}" class="player-avatar">
                            <div class="player-info">
                                <div class="player-name">${player.full_name || player.username}</div>
                                <div class="player-username">@${player.username}</div>
                            </div>
                            <div class="stat">
                                <div class="stat-label">Profit</div>
                                <div class="stat-value">₦${parseFloat(player.total_profit).toFixed(2)}</div>
                            </div>
                            <div class="stat">
                                <div class="stat-label">Wins</div>
                                <div class="stat-value">${player.total_wins}</div>
                            </div>
                        </div>
                    `).join('');
                } else {
                    document.getElementById('leaderboardList').innerHTML = '<div style="text-align: center; padding: 20px; color: rgba(255, 255, 255, 0.5);">No players yet. Be the first!</div>';
                }
            } catch (error) {
                console.error('Error loading leaderboard:', error);
            }
        }
        
        // Load leaderboard on page load
        document.addEventListener('DOMContentLoaded', function() {
            loadLeaderboard();
        });
    </script>
</body>
</html>
