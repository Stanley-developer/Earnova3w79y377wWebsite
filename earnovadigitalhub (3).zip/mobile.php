<?php
require_once 'config/database.php';
require_once 'includes/session.php';
require_once 'includes/connect.php';
require_once 'includes/theme-handler.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$user_id = $_SESSION['user_id'];
$pdo = getDBConnection();

// Fetch user data
$user_data = getCurrentUser();
$fullname = htmlspecialchars($user_data['fullname'] ?? $user_data['username']);
$membership_type = $user_data['membership_type'] ?? 'free';

// Fetch wallet balances
$stmt = $pdo->prepare("
    SELECT u.id, b.task_earnings, b.referral_earnings, b.total_balance 
    FROM users u 
    LEFT JOIN balances b ON u.id = b.user_id 
    WHERE u.id = ?
");
$stmt->execute([$user_id]);
$balances = $stmt->fetch();

// Fetch recent transactions (last 20)
$stmt = $pdo->prepare("
    SELECT 
        transaction_type,
        amount,
        description,
        created_at,
        CASE 
            WHEN transaction_type IN ('withdrawal', 'bid_fee', 'ad_purchase', 'premium_upgrade') THEN 'debit'
            WHEN transaction_type IN ('deposit', 'task_reward', 'referral_commission', 'daily_reward', 'video_earning') THEN 'credit'
            ELSE 'debit'
        END as category
    FROM transactions 
    WHERE user_id = ? 
    ORDER BY created_at DESC 
    LIMIT 20
");
$stmt->execute([$user_id]);
$transactions = $stmt->fetchAll();


 
    $stmt = $pdo->prepare("
        SELECT transaction_type, amount, balance_type, created_at
        FROM transactions
        WHERE user_id = ?
        ORDER BY created_at DESC
        LIMIT 5
    ");
    $stmt->execute([$user_id]);
    $recent_history_overlay = $stmt->fetchAll();
    
    $stmt = $pdo->prepare("
        SELECT transaction_type, amount, balance_type, created_at
        FROM transactions
        WHERE user_id = ?
        ORDER BY created_at DESC
        LIMIT 2
    ");
    $stmt->execute([$user_id]);
    $recent_history_dashboard = $stmt->fetchAll();
    
    $stmt = $pdo->prepare("
        SELECT am.id, am.title, am.message, am.created_at
        FROM admin_messages am
        WHERE am.is_active = 1
        AND am.id NOT IN (
            SELECT message_id FROM user_message_reads WHERE user_id = ?
        )
        ORDER BY am.created_at DESC
        LIMIT 1
    ");
    $stmt->execute([$user_id]);
    $admin_notification = $stmt->fetch();
    
    $stmt = $pdo->prepare("
        SELECT am.id, am.title, am.message, am.created_at
        FROM admin_messages am
        WHERE am.is_active = 1
        ORDER BY am.created_at DESC
        LIMIT 3
    ");
    $stmt->execute();
    $admin_messages_overlay = $stmt->fetchAll();

// Placeholder for actual balance fetching if needed for specific cards
$prime_wallet = $balances['total_balance'] ?? 0; // Example: Using total_balance for prime_wallet
$activity_balance = $balances['task_earnings'] ?? 0; // Example: Using task_earnings for activity_balance
$referral_balance = $balances['referral_earnings'] ?? 0; // Example: Using referral_earnings for referral_balance


$games = [
    [
        'title' => 'Plinko 3D',
        'image' => 'https://images.unsplash.com/photo-1511512578047-dfb367046420?w=400&h=200&fit=crop',
        'description' => 'Drop the ball and watch it bounce through pegs to win multipliers!'
    ],
    [
        'title' => 'Keno 3D',
        'image' => 'https://images.unsplash.com/photo-1516975080664-ed2fc6a32937?w=400&h=200&fit=crop',
        'description' => 'Pick your lucky numbers and match them to win big prizes!'
    ],
    [
        'title' => 'Spin & Win',
        'image' => 'https://images.unsplash.com/photo-1596838132731-3301c3fd4317?w=400&h=200&fit=crop',
        'description' => 'Spin the lucky wheel and land on amazing multipliers!'
    ],
    [
        'title' => 'Mystery Box',
        'image' => 'https://images.unsplash.com/photo-1549298222-1c31e8915347?w=400&h=200&fit=crop',
        'description' => 'Choose a mystery box and reveal your surprise prize!'
    ],
    [
        'title' => 'Dice Roll',
        'image' => 'https://images.unsplash.com/photo-1516975080664-ed2fc6a32937?w=400&h=200&fit=crop&q=80',
        'description' => 'Roll the dice and predict the outcome to win big!'
    ],
    [
        'title' => 'Slot Machine',
        'image' => 'https://images.unsplash.com/photo-1566073771259-6a8506099945?w=400&h=200&fit=crop',
        'description' => 'Spin the reels and match symbols for jackpot wins!'
    ],
    [
        'title' => 'Card Flip',
        'image' => 'https://images.unsplash.com/photo-1541278107931-e006523892df?w=400&h=200&fit=crop',
        'description' => 'Flip cards to match pairs and earn bonus rewards!'
    ],
    [
        'title' => 'Lucky 7s',
        'image' => 'https://images.unsplash.com/photo-1606229365485-93a3b8ee0385?w=400&h=200&fit=crop',
        'description' => 'Hit the lucky sevens and multiply your winnings!'
    ],
    [
        'title' => 'Treasure Hunt',
        'image' => 'https://images.unsplash.com/photo-1530103862676-de8c9debad1d?w=400&h=200&fit=crop',
        'description' => 'Search for hidden treasures and claim amazing prizes!'
    ],
    [
        'title' => 'Color Blast',
        'image' => 'https://images.unsplash.com/photo-1614680376573-df3480f0c6ff?w=400&h=200&fit=crop',
        'description' => 'Match colors to create explosive combos and win!'
    ],
    [
        'title' => 'Mega Bingo',
        'image' => 'https://images.unsplash.com/photo-1609710228159-0fa9bd7c0827?w=400&h=200&fit=crop',
        'description' => 'Mark your numbers and complete patterns for big wins!'
    ],
    [
        'title' => 'Coin Toss',
        'image' => 'https://images.unsplash.com/photo-1621416894569-0f39ed31d247?w=400&h=200&fit=crop',
        'description' => 'Call heads or tails and double your rewards instantly!'
    ]
];

// Helper functions (assuming these exist elsewhere or are defined here)
function timeAgo($timestamp) {
    // Placeholder for actual time ago calculation
    return date('j M Y, g:ia', strtotime($timestamp));
}

function formatCurrency($amount) {
    return '₦' . number_format(abs($amount), 2);
}

function formatTransactionType($type) {
    return ucwords(str_replace('_', ' ', $type));
}

?>

<?php include "doctype.php"; ?>
    <link rel="stylesheet" href="assets/css/gamified-fintech-theme.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: var(--font-sans);
            background: var(--bg-primary);
            color: var(--text-primary);
            min-height: 100vh;
            padding-bottom: 100px;
        }

        .dashboard-container {
            max-width: 500px;
            margin: 0 auto;
            padding: 20px 16px;
        }

        /* Balance Cards Section */
        .balance-cards-wrapper {
            margin-bottom: 32px;
        }

        .balance-cards-scroll {
            display: flex;
            gap: 16px;
            overflow-x: auto;
            scroll-snap-type: x mandatory;
            scrollbar-width: none;
            -ms-overflow-style: none;
            padding-bottom: 8px;
            scroll-behavior: smooth;
            /* Added scroll-padding to create 15px peek effect */
            scroll-padding-right: 15px;
            padding-right: 0;
        }

        .balance-cards-scroll::-webkit-scrollbar {
            display: none;
        }

        .balance-card {
            min-width: 450px;
            height: 180px;
            border-radius: 30px;
            padding: 24px;
            box-shadow: 0 10px 40px rgba(4, 10, 36, 0.4);
            scroll-snap-align: start;
            position: relative;
            overflow: hidden;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            backdrop-filter: blur(20px);
            /* Updated transition for smoother 3D perspective effect */
            transition: all 0.6s cubic-bezier(0.34, 1.56, 0.64, 1);
            transform: translateZ(0);
            will-change: transform;
        }

        .balance-card:active,
        .balance-card:focus {
            transform: scale(1.02) translateZ(10px);
            box-shadow: 0 15px 50px rgba(77, 225, 193, 0.3);
        }

        /* Added individual stripe patterns for each card */
        .prime-card {
            background: linear-gradient(135deg, 
                rgba(44, 91, 245, 0.95) 0%, 
                rgba(26, 58, 171, 0.9) 50%,
                rgba(15, 31, 102, 0.85) 100%);
            background-image: 
                repeating-linear-gradient(45deg, transparent, transparent 35px, rgba(255, 255, 255, 0.05) 35px, rgba(255, 255, 255, 0.05) 70px),
                linear-gradient(135deg, 
                    rgba(44, 91, 245, 0.95) 0%, 
                    rgba(26, 58, 171, 0.9) 50%,
                    rgba(15, 31, 102, 0.85) 100%);
                    
                    
        }

        .activity-card {
            background: linear-gradient(135deg, 
                rgba(236, 72, 153, 0.95) 0%, 
                rgba(190, 24, 93, 0.9) 50%,
                rgba(131, 24, 67, 0.85) 100%);
            background-image: 
                repeating-linear-gradient(-45deg, transparent, transparent 35px, rgba(255, 255, 255, 0.08) 35px, rgba(255, 255, 255, 0.08) 70px),
                linear-gradient(135deg, 
                    rgba(236, 72, 153, 0.95) 0%, 
                    rgba(190, 24, 93, 0.9) 50%,
                    rgba(131, 24, 67, 0.85) 100%);
        }

        .referral-card {
            background: linear-gradient(135deg, 
                rgba(59, 130, 246, 0.95) 0%, 
                rgba(37, 99, 235, 0.9) 50%,
                rgba(29, 78, 216, 0.85) 100%);
            background-image: 
                repeating-linear-gradient(0deg, transparent, transparent 35px, rgba(255, 255, 255, 0.06) 35px, rgba(255, 255, 255, 0.06) 70px),
                repeating-linear-gradient(90deg, transparent, transparent 35px, rgba(255, 255, 255, 0.06) 35px, rgba(255, 255, 255, 0.06) 70px),
                linear-gradient(135deg, 
                    rgba(59, 130, 246, 0.95) 0%, 
                    rgba(37, 99, 235, 0.9) 50%,
                    rgba(29, 78, 216, 0.85) 100%);
        }

        .balance-card::before {
            content: '';
            position: absolute;
            top: -50%;
            right: -30%;
            width: 200px;
            height: 200px;
            background: radial-gradient(circle, rgba(77, 225, 193, 0.15), transparent);
            border-radius: 50%;
        }

        .balance-card-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
        }

        .wallet-name {
            font-size: 0.85rem;
            font-weight: 500;
            color: rgba(255, 255, 255, 0.75);
            text-transform: uppercase;
            letter-spacing: 0.05em;
        }
        
          .wallet-name2 {
            font-size: 0.95rem;
            font-weight: 700;
            color: rgba(255, 255, 255, 0.75);
            text-transform: uppercase;
            letter-spacing: 0.05em;
        }


        .card-icon {
            width: 40px;
            height: 40px;
            display: flex;
            gap: 4px;
            align-items: center;
        }

        .card-icon-circle {
            width: 16px;
            height: 16px;
            border-radius: 50%;
        }

        .circle-gold {
            background: linear-gradient(135deg, #fbbf24, #f59e0b);
        }

        .circle-mint {
            background: linear-gradient(135deg, #4de1c1, #2bc9a7);
        }

        .balance-amount {
            font-size: 2.2rem;
            font-weight: 700;
            color: #ffffff;
            margin: 8px 0;
            text-align: center;
            letter-spacing: -0.02em;
            flex: start;
            text-align: start;
            justify-content: start;
        }

        .balance-card-footer {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .wallet-holder {
            font-size: 0.75rem;
            color: rgba(255, 255, 255, 0.7);
        }

        .wallet-holder strong {
            color: #ffffff;
            font-weight: 600;
        }

        /* Added 3D button styles for balance type selection */
        .balance-type-buttons {
            display: flex;
            gap: 8px;
            margin-top: 12px;
            flex-wrap: wrap;
        }

        .balance-type-btn {
            display: inline-flex;
            align-items: center;
            gap: 4px;
            padding: 6px 12px;
            background: rgba(255, 255, 255, 0.1);
            border: 1px solid rgba(255, 255, 255, 0.2);
            border-radius: 12px;
            color: rgba(255, 255, 255, 0.9);
            font-size: 0.7rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s cubic-bezier(0.34, 1.56, 0.64, 1);
            transform: perspective(600px) rotateX(0deg);
            text-transform: uppercase;
            letter-spacing: 0.05em;
        }

        .balance-type-btn:hover {
            background: rgba(255, 255, 255, 0.15);
            border-color: rgba(255, 255, 255, 0.4);
            transform: perspective(600px) rotateX(-15deg) translateZ(20px);
            box-shadow: 0 10px 30px rgba(77, 225, 193, 0.2), inset 0 1px 0 rgba(255, 255, 255, 0.2);
        }

        .balance-type-btn:active {
            transform: perspective(600px) rotateX(-5deg) translateZ(10px);
        }

        .balance-type-btn svg {
            width: 14px;
            height: 14px;
            fill: currentColor;
        }

        /* History Tabs Section */
        .history-tabs-wrapper {
            margin-bottom: 24px;
            display: flex;
            justify-content: center;
        }

        .history-tabs {
            display: inline-flex;
            background: rgba(13, 24, 62, 0.6);
            border: 1px solid rgba(86, 139, 241, 0.3);
            border-radius: 50px;
            padding: 6px;
            gap: 6px;
        }

        .history-tab {
            padding: 10px 32px;
            border-radius: 40px;
            border: none;
            background: transparent;
            color: rgba(216, 230, 255, 0.6);
            font-family: var(--font-sans);
            font-size: 0.95rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .history-tab.active {
            background: linear-gradient(135deg, #4de1c1, #2bc9a7);
            color: #030922;
            box-shadow: 0 0 20px rgba(77, 225, 193, 0.5), inset 0 2px 4px rgba(255, 255, 255, 0.3);
        }

        /* Transaction List Section */
        .transactions-wrapper {
            display: flex;
            flex-direction: column;
            gap: 8px;
        }

        .transaction-item {
            background: rgba(13, 24, 62, 0.5);
            backdrop-filter: blur(20px);
            border: 1px solid rgba(86, 139, 241, 0.2);
            border-radius: 20px;
            padding: 16px;
            display: flex;
            align-items: center;
            gap: 14px;
            transition: all 0.3s ease;
        }

        .transaction-item:hover {
            background: rgba(13, 24, 62, 0.7);
            border-color: rgba(86, 139, 241, 0.4);
            transform: translateY(-2px);
        }

        .transaction-icon {
            width: 46px;
            height: 46px;
            border-radius: 50%;
            background: linear-gradient(135deg, rgba(77, 225, 193, 0.25), rgba(44, 92, 245, 0.15));
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.1rem;
            font-weight: 700;
            color: #4de1c1;
            flex-shrink: 0;
        }

        .transaction-icon.debit {
            background: linear-gradient(135deg, rgba(255, 77, 77, 0.25), rgba(239, 68, 68, 0.15));
            color: #ff4d4d;
        }

        .transaction-details {
            flex: 1;
            min-width: 0;
        }

        .transaction-type {
            font-size: 0.95rem;
            font-weight: 600;
            color: var(--text-primary);
            margin-bottom: 2px;
        }

        .transaction-description {
            font-size: 0.8rem;
            color: var(--text-muted);
            margin-bottom: 3px;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }

        .transaction-date {
            font-size: 0.75rem;
            color: var(--text-tertiary);
        }

        .transaction-amount {
            font-size: 1.05rem;
            font-weight: 700;
            flex-shrink: 0;
        }

        .transaction-amount.credit {
            color: #10b981;
        }

        .transaction-amount.debit {
            color: #ff4d4d;
        }

        .empty-state {
            text-align: center;
            padding: 48px 24px;
            color: var(--text-tertiary);
        }

        .empty-state svg {
            width: 64px;
            height: 64px;
            margin-bottom: 16px;
            opacity: 0.4;
        }

        /* Quick Action Grid Styles */
        .quick-actions-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 10px;
            /*margin-bottom: 12px;*/
            margin-top: -20px;
        }

        .quick-action-item {
            background: rgba(13, 24, 62, 0.5);
            backdrop-filter: blur(20px);
            border: 1px solid rgba(86, 139, 241, 0.2);
            border-radius: 20px;
            padding: 10px;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            gap: 6px;
            text-decoration: none;
            color: var(--text-primary);
            transition: all 0.3s ease;
            cursor: pointer;
            
        }

        .quick-action-item:hover {
            background: rgba(13, 24, 62, 0.7);
            border-color: rgba(86, 139, 241, 0.4);
            transform: translateY(-4px);
            box-shadow: 0 8px 24px rgba(77, 225, 193, 0.2);
        }

        .quick-action-icon {
            width: 35px;
            height: 35px;
            border-radius: 50%;
            background: linear-gradient(135deg, rgba(77, 225, 193, 0.25), rgba(44, 92, 245, 0.15));
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.4rem;
        }

        .quick-action-item:nth-child(1) .quick-action-icon {
            background: linear-gradient(135deg, rgba(76, 175, 80, 0.25), rgba(56, 142, 60, 0.15));
            color: #4caf50;
        }

        .quick-action-item:nth-child(2) .quick-action-icon {
            background: linear-gradient(135deg, rgba(255, 152, 0, 0.25), rgba(255, 111, 0, 0.15));
            color: #ff9800;
        }

        .quick-action-item:nth-child(3) .quick-action-icon {
            background: linear-gradient(135deg, rgba(63, 81, 181, 0.25), rgba(48, 63, 159, 0.15));
            color: #3f51b5;
        }

        .quick-action-item:nth-child(4) .quick-action-icon {
            background: linear-gradient(135deg, rgba(233, 30, 99, 0.25), rgba(194, 24, 91, 0.15));
            color: #e91e63;
        }

        .quick-action-label {
            font-size: 0.55rem;
            font-weight: 600;
            text-align: center;
            color: var(--text-primary);
        }
        
        
        
         /* Games Section Styles */
        .games-section-wrapper {
            margin-top: 40px;
            margin-bottom: 24px;
        }

        .games-section-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 16px;
            padding: 0 4px;
        }

        .games-section-title {
            font-size: 1.3rem;
            font-weight: 700;
            color: #ffffff;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .games-ticker {
            display: flex;
            gap: 16px;
            overflow-x: auto;
            scroll-snap-type: none;
            scrollbar-width: none;
            -ms-overflow-style: none;
            padding-bottom: 8px;
            /* Removed scroll-behavior for continuous ticker control */
            scroll-behavior: auto;
        }

        .games-ticker::-webkit-scrollbar {
            display: none;
        }

        .game-card-item {
            min-width: 160px;
            height: 200px;
            background: linear-gradient(135deg, rgba(44, 91, 245, 0.4), rgba(77, 225, 193, 0.1));
            border: 1px solid rgba(77, 225, 193, 0.3);
            border-radius: 16px;
            overflow: hidden;
            cursor: pointer;
            /* Improved transition for smoother animations */
            transition: all 0.4s cubic-bezier(0.34, 1.56, 0.64, 1);
            scroll-snap-align: none;
            display: flex;
            flex-direction: column;
            position: relative;
            flex-shrink: 0;
        }

        .game-card-item:hover {
            transform: translateY(-8px) scale(1.05);
            border-color: rgba(77, 225, 193, 0.6);
            box-shadow: 0 12px 36px rgba(77, 225, 193, 0.25);
        }

        .game-card-image {
            width: 100%;
            height: 120px;
            object-fit: cover;
            border-radius: 14px 14px 0 0;
        }

        .game-card-info {
            padding: 12px;
            flex: 1;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
        }

        .game-card-title {
            font-size: 0.95rem;
            font-weight: 700;
            color: #ffffff;
            line-height: 1.2;
        }

        .game-card-cta {
            display: inline-block;
            padding: 6px 12px;
            background: linear-gradient(135deg, #4de1c1, #2bc9a7);
            color: #030922;
            border-radius: 12px;
            font-size: 0.75rem;
            font-weight: 700;
            text-align: center;
            align-self: flex-start;
            margin-top: auto;
        }

        .games-scroll-hint {
            font-size: 0.75rem;
            color: rgba(216, 230, 255, 0.5);
            text-align: center;
            margin-top: 8px;
            margin-bottom: 8px;
        }


       
    /* Updated mobile footer with 5 icons */
    .mobile-fintech-footer {
      display: none;
      position: fixed;
      left: 12px;
      right: 12px;
      bottom: 16px;
      padding: 10px;
      background: transparent;
      border: 1px solid rgba(86, 139, 241, 0.35);
      border-radius: 32px;
      backdrop-filter: blur(50px);
      box-shadow: 0 20px 60px rgba(4, 10, 36, 0.7);
      justify-content: space-around;
      align-items: center;
      z-index: 90;
    }

    .mobile-fintech-footer a {
      flex: 1;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      gap: 4px;
      text-decoration: none;
      color: rgba(205, 219, 255, 0.75);
      font-size: 0.45rem;
      letter-spacing: 0.06em;
      text-transform: uppercase;
      transition: all var(--transition-short);
      padding: 8px 4px;
      border-radius: 16px;
    }

    .mobile-fintech-footer a:nth-child(3) .icon-wrapper {
      width: 56px;
      height: 56px;
      border-radius: 50%;
      background: linear-gradient(135deg, rgba(77, 225, 193, 0.25), rgba(47, 91, 234, 0.25));
      backdrop-filter: blur(12px);
      border: 2px solid rgba(77, 225, 193, 0.4);
      display: flex;
      align-items: center;
      justify-content: center;
      box-shadow: 0 8px 24px rgba(77, 225, 193, 0.3);
    }

    .mobile-fintech-footer a:nth-child(3) svg {
      width: 28px;
      height: 28px;
    }

    .mobile-fintech-footer a.active {
      color: var(--page-mint);
    }

    .mobile-fintech-footer svg {
      width: 22px;
      height: 22px;
      fill: currentColor;
      filter: drop-shadow(0 4px 12px rgba(4, 10, 36, 0.4));
    }

    .mobile-fintech-footer a:hover {
      color: var(--page-mint);
      transform: translateY(-2px);
    }

    .mobile-fintech-footer a:nth-child(3):hover {
      transform: translateY(-14px);
    }
    
      @media (max-width: 680px) {

      .mobile-fintech-footer {
        display: flex;
      }
    }


        .nav-item {
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 4px;
            text-decoration: none;
            color: rgba(216, 230, 255, 0.6);
            transition: all 0.3s ease;
            padding: 8px 12px;
            border-radius: 16px;
        }

        .nav-item:hover {
            color: #4de1c1;
            background: rgba(77, 225, 193, 0.1);
            transform: translateY(-2px);
        }

        .nav-item.active {
            color: #4de1c1;
        }

        .nav-item svg {
            width: 22px;
            height: 22px;
            fill: currentColor;
        }

        .nav-item span {
            font-size: 0.7rem;
            font-weight: 600;
        }

        .nav-item.center {
            position: relative;
        }

        .nav-item.center .icon-wrapper {
            background: linear-gradient(135deg, #4de1c1, #2bc9a7);
            width: 56px;
            height: 56px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            transform: translateY(-12px);
            box-shadow: 0 8px 24px rgba(77, 225, 193, 0.4);
        }

        .nav-item.center svg {
            fill: #030922;
        }

        /* Desktop Responsive Layout */
        @media (min-width: 768px) {
            .dashboard-container {
                max-width: 1000px;
            }

            .balance-cards-scroll {
                display: grid;
                grid-template-columns: repeat(3, 1fr);
                gap: 20px;
                overflow: visible;
                padding-bottom: 0;
            }

            .balance-card {
                min-width: 100%;
                height: 200px;
            }

            .quick-actions-grid {
                grid-template-columns: repeat(4, 1fr);
                gap: 16px;
            }

            .quick-action-item {
                padding: 20px;
            }
        }

        @media (max-width: 480px) {
            .balance-card {
                min-width: 290px;
            }

            .balance-amount {
                font-size: 1.9rem;
            }

            .dashboard-container {
                padding: 16px 12px;
            }

            .mobile-fintech-footer {
                width: calc(100% - 24px);
                padding: 10px 16px;
            }

            .nav-item span {
                font-size: 0.65rem;
            }
        }
        
        
  /* Full-screen notification overlay */
  .notification-overlay {
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: rgba(3, 9, 34, 0.98);
    backdrop-filter: blur(20px);
    z-index: 9999;
    display: none;
    overflow-y: auto;
    padding: 20px;
  }

  .notification-overlay.active {
    display: block;
  }

  .notification-overlay-content {
    max-width: 800px;
    margin: 0 auto;
    padding: 20px;
  }

  .notification-overlay-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 30px;
    padding-bottom: 20px;
    border-bottom: 1px solid rgba(86, 139, 241, 0.28);
  }

  .notification-overlay-header h2 {
    margin: 0;
    font-size: clamp(1.5rem, 3vw, 2rem);
    color: var(--page-white);
  }

  .close-overlay-btn {
    background: rgba(255, 71, 87, 0.2);
    border: 1px solid rgba(255, 71, 87, 0.3);
    color: #ff4757;
    padding: 10px 20px;
    border-radius: 12px;
    cursor: pointer;
    font-weight: 600;
    transition: all 0.3s ease;
  }

  .close-overlay-btn:hover {
    background: rgba(255, 71, 87, 0.3);
    transform: scale(1.05);
  }

  .notification-section {
    margin-bottom: 30px;
  }

  .notification-section h3 {
    font-size: clamp(1.1rem, 2vw, 1.3rem);
    color: var(--page-mint);
    margin-bottom: 15px;
  }

  .history-item {
    background: rgba(13, 24, 62, 0.78);
    border: 1px solid rgba(86, 139, 241, 0.28);
    border-radius: 14px;
    padding: 16px;
    margin-bottom: 12px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    transition: all 0.3s ease;
  }

  .history-item:hover {
    border-color: rgba(77, 225, 193, 0.4);
    transform: translateX(5px);
  }

  .history-item-left {
    flex: 1;
  }

  .history-item-type {
    font-weight: 600;
    font-size: 0.95rem;
    color: var(--page-white);
    margin-bottom: 4px;
  }

  .history-item-meta {
    font-size: 0.8rem;
    color: rgba(205, 219, 255, 0.7);
  }

  .history-item-amount {
    font-weight: 700;
    font-size: 1.1rem;
    color: var(--page-mint);
  }

  .admin-message-item {
    background: linear-gradient(135deg, rgba(255, 130, 70, 0.15), rgba(12, 29, 82, 0.85));
    border: 1px solid rgba(255, 130, 70, 0.3);
    border-radius: 14px;
    padding: 18px;
    margin-bottom: 12px;
  }

  .admin-message-title {
    font-weight: 700;
    font-size: 1rem;
    color: #ffb366;
    margin-bottom: 8px;
  }

  .admin-message-text {
    font-size: 0.9rem;
    color: rgba(255, 255, 255, 0.85);
    line-height: 1.6;
    margin-bottom: 8px;
  }

  .admin-message-time {
    font-size: 0.75rem;
    color: rgba(255, 179, 102, 0.7);
  }

  .view-more-btn {
    display: inline-block;
    background: rgba(45, 92, 230, 0.72);
    color: var(--page-white);
    padding: 12px 24px;
    border-radius: 12px;
    text-decoration: none;
    font-weight: 600;
    transition: all 0.3s ease;
    margin-top: 10px;
  }

  .view-more-btn:hover {
    background: rgba(45, 92, 230, 0.85);
    transform: translateY(-2px);
  }

  /* Admin notification banner */
  .admin-notification-banner {
    background: linear-gradient(135deg, rgba(255, 130, 70, 0.25), rgba(12, 29, 82, 0.85));
    border: 1px solid rgba(255, 130, 70, 0.4);
    border-radius: 18px;
    padding: 20px;
    margin-bottom: 20px;
    box-shadow: 0 10px 40px rgba(255, 130, 70, 0.3);
    position: relative;
  }

  .admin-notification-banner h4 {
    margin: 0 0 10px 0;
    font-size: 1.1rem;
    color: #ffb366;
    display: flex;
    align-items: center;
    gap: 8px;
  }

  .admin-notification-banner h4 svg {
    width: 20px;
    height: 20px;
    fill: #ffb366;
  }

  .admin-notification-banner p {
    margin: 0 0 15px 0;
    color: rgba(255, 255, 255, 0.9);
    line-height: 1.6;
  }

  .read-checkbox-container {
    display: flex;
    align-items: center;
    gap: 10px;
  }

  .read-checkbox-container input[type="checkbox"] {
    width: 20px;
    height: 20px;
    cursor: pointer;
  }

  .read-checkbox-container label {
    font-size: 0.9rem;
    color: rgba(255, 255, 255, 0.85);
    cursor: pointer;
  }

    </style>
</head>
<body>
    <?php include "header.php"; ?>
    <?php include "embed.php"; ?>

    <div class="dashboard-container">
        <!-- Balance Cards Section -->
        <div class="balance-cards-wrapper">
            <div class="balance-cards-scroll">
                <!-- Prime Wallet Card -->
                <div class="balance-card prime-card">
                    <div class="balance-card-header">
                        <span class="wallet-name">Total Earnings</span>
                        <div class="card-icon">
                            <div class="card-icon-circle circle-gold"></div>
                            <div class="card-icon-circle circle-mint"></div>
                        </div>
                    </div>
                    <div class="balance-amount">₦ <?php echo number_format($prime_wallet, 2); ?></div>
                     <span class="wallet-holder">
                                Total Balance
                            </span>
                    <div class="balance-card-footer">
                        <span class="wallet-holder">Holder: <strong><?php echo $fullname; ?></strong></span>
                       
                    
                    </div>
                </div>

                <!-- Activity Balance Card -->
                <div class="balance-card activity-card">
                    <div class="balance-card-header">
                        <span class="wallet-name">Activity Balance</span>
                        <div class="card-icon">
                            <div class="card-icon-circle circle-gold"></div>
                            <div class="card-icon-circle circle-mint"></div>
                        </div>
                    </div>
                    <div class="balance-amount">₦ <?php echo number_format($activity_balance, 2); ?></div>
                            <span class="wallet-holder">
                                Incentives & tasks
                            </span>
                    <div class="balance-card-footer">
                        <span class="wallet-holder">Holder: <strong><?php echo $fullname; ?></strong></span>
                        
                       
                    </div>
                </div>

                <!-- Referral Balance Card -->
                <div class="balance-card referral-card">
                    <div class="balance-card-header">
                        <span class="wallet-name">Prime Earnings</span>
                        <div class="card-icon">
                            <div class="card-icon-circle circle-gold"></div>
                            <div class="card-icon-circle circle-mint"></div>
                        </div>
                    </div>
                    <div class="balance-amount">₦ <?php echo number_format($referral_balance, 2); ?></div>
                     <span class="wallet-holder">
                                Commission earnings & deposit
                            </span>
                    <div class="balance-card-footer">
                        
                        <span class="wallet-holder">Holder: <strong><?php echo $fullname; ?></strong></span>
                        
                           
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Quick Actions Grid -->
        <div class="quick-actions-grid">
            <a href="membership.php" class="quick-action-item">
               <div class="quick-action-icon">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
                    <rect x="2" y="5" width="20" height="14" rx="3" stroke="currentColor" stroke-width="2"/>
                    <path d="M2 10H22" stroke="currentColor" stroke-width="2"/>
                </svg>
            </div>

                <span class="quick-action-label">Deposit</span>
            </a>
            <a href="withdrawal.php" class="quick-action-item">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
                    <path d="M12 2L15 6H9L12 2Z" stroke="currentColor" stroke-width="2" />
                    <path d="M5 10C5 6.7 7.7 5 12 5C16.3 5 19 6.7 19 10V17C19 19.8 16.8 22 14 22H10C7.2 22 5 19.8 5 17V10Z" 
                          stroke="currentColor" stroke-width="2"/>
                </svg>
                <span class="quick-action-label">Withdraw</span>
            </a>
            <a href="perform-task.php" class="quick-action-item">
                <div class="quick-action-icon">
    
                  <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
                    <path d="M12 2L15 6H9L12 2Z" stroke="currentColor" stroke-width="2" />
                    <path d="M5 10C5 6.7 7.7 5 12 5C16.3 5 19 6.7 19 10V17C19 19.8 16.8 22 14 22H10C7.2 22 5 19.8 5 17V10Z" 
                          stroke="currentColor" stroke-width="2"/>
                </svg>
</div>

                <span class="quick-action-label">Task</span>
            </a>
            <a href="chat-earn.php" class="quick-action-item">
                <div class="quick-action-icon">
    <svg viewBox="0 0 24 24"><path d="M4 4H20V16H7L4 19V4Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>
</div>

                <span class="quick-action-label">Chat & Earn</span>
            </a>
        </div>
        
        
        
        <!-- ========================= -->
<!--     SKILLS CENTER CARD    -->
<!-- ========================= -->

<div class="skills-center-card" style="
    background: rgba(13, 24, 62, 0.5);
    backdrop-filter: blur(20px);
    border: 1px solid rgba(86,139,241,0.2);
    border-radius: 20px;
    padding: 18px;
    margin-top: 22px;
    color: #fff;
">

    <!-- Title -->
    <h3 style="
        font-size: 18px;
        font-weight: 600;
        margin: 0 0 8px 0;
    ">
        Skills Center
    </h3>

    <!-- Description (with glass morphing border + background) -->
    <div style="
        background:linear-gradient(135deg, rgba(44,91,245,0.35), rgba(77,225,193,0.12));
        border:1px solid rgba(77,225,193,0.25);
       
        backdrop-filter: blur(12px);
        border-radius: 14px;
        padding: 12px 14px;
        margin-bottom: 20px;
        box-shadow: 0 4px 14px rgba(0,0,0,0.2);
    ">
        <p style="
            font-size: 14px;
            opacity: 0.85;
            margin: 0;
            line-height: 1.5;
        ">
            Explore exclusive learning opportunities from top professors and industry experts.
        </p>
    </div>

    <!-- Button + Arrow Wrapper -->
    <div style="position: relative; width: 100%; text-align: center;">

        <!-- Bouncing Arrow -->
        <div id="skills-arrow" style="
            position: absolute;
            left: 50%;
            transform: translateX(-50%);
            top: -18px;
            animation: bounceArrow 1.4s infinite ease-in-out;
            opacity: 0.9;
            width: 24px;
            height: 24px;
        ">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
                <path d="M12 18L5 11H19L12 18Z" fill="#fff"/>
            </svg>
        </div>

        <!-- View Button -->
        <a href="skills-require.php" class="skills-view-btn" style="
            display: inline-block;
            padding: 12px 28px;
            border-radius: 30px;
            background: rgba(86,139,241,1);
            color: #fff;
            text-decoration: none;
            font-size: 15px;
            font-weight: 600;
            box-shadow: 0px 4px 10px rgba(0,0,0,0.25);
        ">
            View
        </a>
    </div>

</div>

<style>
@keyframes bounceArrow {
    0%   { transform: translate(-50%, 0); }
    50%  { transform: translate(-50%, -8px); }
    100% { transform: translate(-50%, 0); }
}
</style>

<script>
document.addEventListener("DOMContentLoaded", () => {
    const arrow = document.getElementById("skills-arrow");
    setInterval(() => {
        arrow.style.opacity = arrow.style.opacity === "1" ? "0.4" : "1";
    }, 900);
});
</script>

        
        
        <!--TWO GRID LAYOUT -->
<div style="
    display:grid;
    grid-template-columns: repeat(2,1fr);
    gap:18px;
    margin-top:35px
">

    <!-- CHAT-EARN BOX -->
    <a href="chat-earn.php" style="text-decoration:none;">
    <div class="ce-box" style="
        position:relative;
        background:linear-gradient(135deg, rgba(44,91,245,0.35), rgba(77,225,193,0.12));
        border:1px solid rgba(77,225,193,0.25);
        backdrop-filter:blur(28px);
        border-radius:26px;
        box-shadow:0 18px 55px rgba(4,10,36,0.55);
        padding:20px;
        height:150px;
        display:flex;
        flex-direction:column;
        justify-content:flex-end;
        overflow:hidden;
        cursor:pointer;
    ">

        <!-- TOP BADGE (STATIC) -->
        <div class="ce-badge" style="
            position:absolute;
            top:-10px; /* lowered 6px for full circle visibility */
            right:18px;
            width:52px;
            height:52px;
            z-index:99;
            border-radius:50%;
            background:linear-gradient(135deg,#4de1c1,#2bc9a7);
            border:2px solid rgba(255,255,255,0.25);
            box-shadow:0 8px 24px rgba(77,225,193,0.4);
            display:flex;
            align-items:center;
            justify-content:center;
        ">
            <div class="ce-icon-wrapper">
                <svg class="ce-icon" width="26" height="26" viewBox="0 0 24 24" fill="#030922">
                    <path d="M3 12h18M3 6h12M3 18h12"/>
                </svg>
            </div>
        </div>

        <!-- BACKGROUND SVG (STATIC) -->
        <div style="
            position:absolute;
            inset:0;
            display:flex;
            align-items:center;
            justify-content:center;
            opacity:0.12;
        ">
            <svg width="160" height="160" viewBox="0 0 24 24" fill="#4de1c1">
                <path d="M12 21s-6.7-4.35-9.33-9.2C.28 7.7 2.1 3 6.33 3 8.6 3 10.27 4.4 12 6.09 13.73 4.4 15.4 3 17.67 3c4.23 0 6.05 4.7 3.66 8.8C18.7 16.65 12 21 12 21z"/>
            </svg>
        </div>

        <!-- TEXT CONTENT -->
        <h3 class="ce-h3" style="
            font-size:1.05rem;
            font-weight:700;
            color:#fff;
            margin-bottom:6px; /* increased spacing */
            z-index:2;
            position:relative;
        ">Chat-Earn</h3>

        <p class="ce-p" style="
            font-size:0.78rem;
            color:rgba(216,230,255,0.7);
            position:relative;
            z-index:2;
            line-height:1.33;
        ">Earn rewards by chatting, completing tasks, and engaging daily.</p>
    </div>
    </a>

    <!-- SKILLS REQUIRE BOX -->
    <a href="skill-require.php" style="text-decoration:none;">
    <div class="sr-box" style="
        position:relative;
        background:linear-gradient(135deg, rgba(59,130,246,0.35), rgba(77,225,193,0.12));
        border:1px solid rgba(77,225,193,0.25);
        backdrop-filter:blur(28px);
        border-radius:26px;
        box-shadow:0 18px 55px rgba(4,10,36,0.55);
        padding:20px;
        height:150px;
        display:flex;
        flex-direction:column;
        justify-content:flex-end;
        overflow:hidden;
        cursor:pointer;
    ">

        <!-- TOP BADGE (STATIC) -->
        <div class="sr-badge" style="
            position:absolute;
            top:-10px; /* lowered 6px for full circle visibility */
            right:18px;
            width:52px;
            height:52px;
            z-index:99;
            border-radius:50%;
            background:linear-gradient(135deg,#4de1c1,#2bc9a7);
            border:2px solid rgba(255,255,255,0.25);
            box-shadow:0 8px 24px rgba(77,225,193,0.4);
            display:flex;
            align-items:center;
            justify-content:center;
        ">
            <div class="sr-icon-wrapper">
                <svg class="sr-icon" width="26" height="26" viewBox="0 0 24 24" fill="#030922">
                    <path d="M12 2l4 7h-8l4-7zm0 20l-4-7h8l-4 7zm10-10l-7 4v-8l7 4zm-20 0l7-4v8l-7-4z"/>
                </svg>
            </div>
        </div>

        <!-- BACKGROUND SVG (STATIC) -->
        <div style="
            position:absolute;
            inset:0;
            display:flex;
            align-items:center;
            justify-content:center;
            opacity:0.12;
        ">
            <svg width="160" height="160" viewBox="0 0 24 24" fill="#4de1c1">
                <path d="M12 2l4 7h-8l4-7zm0 20l-4-7h8l-4 7zm10-10l-7 4v-8l7 4zm-20 0l7-4v8l-7-4z"/>
            </svg>
        </div>

        <!-- TEXT -->
        <h3 class="sr-h3" style="
            font-size:1.05rem;
            font-weight:700;
            color:#fff;
            margin-bottom:6px; /* increased spacing */
            z-index:2;
            position:relative;
        ">Skills Required</h3>

        <p class="sr-p" style="
            font-size:0.78rem;
            color:rgba(216,230,255,0.7);
            position:relative;
            z-index:2;
            line-height:1.33;
        ">View tasks requiring specific skills and unlock advanced rewards.</p>
    </div>
    </a>

</div>

        <!-- Games Section - Added below transactions -->
        <div class="games-section-wrapper">
            <div class="games-section-header">
                <h2 class="wallet-name2">Earnova Games</h2>
            </div>
            <p class="games-scroll-hint">Swipe to explore → </p>
            <div class="games-ticker" id="gamesTicker">
                <?php foreach ($games as $game): ?>
                    <div class="game-card-item" onclick="navigateToGame('<?php echo htmlspecialchars($game['title']); ?>')">
                        <img src="<?php echo htmlspecialchars($game['image']); ?>" alt="<?php echo htmlspecialchars($game['title']); ?>" class="game-card-image">
                        <div class="game-card-info">
                            <div class="game-card-title"><?php echo htmlspecialchars($game['title']); ?></div>
                            <div class="game-card-cta">Play Now</div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>


        <!-- History Tabs -->
        <div class="history-tabs-wrapper">
            <div class="history-tabs">
                <button class="history-tab" data-tab="debit" onclick="filterTransactions('debit')">Debit</button>
                <button class="history-tab active" data-tab="credit" onclick="filterTransactions('credit')">Credit</button>
            </div>
        </div>

        <!-- Transaction List -->
        <div class="transactions-wrapper" id="transactionsWrapper">
            <?php if (empty($transactions)): ?>
                <div class="empty-state">
                    <svg viewBox="0 0 24 24" fill="currentColor">
                        <path d="M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm0 16H5V5h14v14zm-7-2h2v-4h4v-2h-4V7h-2v4H7v2h4z"/>
                    </svg>
                    <p>No transactions yet</p>
                </div>
            <?php else: ?>
                <?php foreach ($transactions as $txn): ?>
                    <?php
                    $is_credit = $txn['category'] === 'credit';
                    $icon_letter = '';
                    
                    if (in_array($txn['transaction_type'], ['deposit', 'task_reward', 'referral_commission', 'daily_reward', 'video_earning'])) {
                        $icon_letter = 'D';
                    } elseif (in_array($txn['transaction_type'], ['withdrawal'])) {
                        $icon_letter = 'W';
                    } else {
                        $icon_letter = 'T';
                    }
                    
                    $type_label = ucwords(str_replace('_', ' ', $txn['transaction_type']));
                    $description = htmlspecialchars($txn['description'] ?? 'Transaction');
                    $date = date('d M Y h:ia', strtotime($txn['created_at']));
                    $amount = number_format($txn['amount'], 2);
                    ?>
                    <div class="transaction-item" data-category="<?php echo $txn['category']; ?>">
                        <div class="transaction-icon <?php echo $txn['category']; ?>">
                            <?php echo $icon_letter; ?>
                        </div>
                        <div class="transaction-details">
                            <div class="transaction-type"><?php echo $type_label; ?></div>
                            <div class="transaction-description"><?php echo $description; ?></div>
                            <div class="transaction-date"><?php echo $date; ?></div>
                        </div>
                        <div class="transaction-amount <?php echo $txn['category']; ?>">
                            <?php echo $is_credit ? '+' : '-'; ?>₦<?php echo $amount; ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>
    
    
  <!-- Full-screen notification overlay -->
  <div class="notification-overlay" id="notificationOverlay">
    <div class="notification-overlay-content">
      <div class="notification-overlay-header">
        <h2>Notifications</h2>
        <button class="close-overlay-btn" onclick="toggleNotificationOverlay()">Close</button>
      </div>

      <?php if (!empty($admin_messages_overlay)): ?>
      <div class="notification-section">
        <h3>Admin Messages</h3>
        <?php foreach ($admin_messages_overlay as $msg): ?>
        <div class="admin-message-item" id="adminMsg<?php echo $msg['id']; ?>">
          <div class="admin-message-title"><?php echo htmlspecialchars($msg['title']); ?></div>
          <div class="admin-message-text"><?php echo nl2br(htmlspecialchars($msg['message'])); ?></div>
          <div class="admin-message-time"><?php echo timeAgo($msg['created_at']); ?></div>
          <!-- Added "I've read it" button with auto-refresh -->
          <button onclick="markMessageReadAndRefresh(<?php echo $msg['id']; ?>)" style="margin-top: 12px; background: rgba(77, 225, 193, 0.3); border: 1px solid rgba(77, 225, 193, 0.5); color: var(--page-mint); padding: 8px 16px; border-radius: 10px; cursor: pointer; font-weight: 600; font-size: 0.85rem; transition: all 0.3s ease;">
            I've read it
          </button>
        </div>
        <?php endforeach; ?>
      </div>
      <?php endif; ?>

      <?php if (!empty($recent_history_overlay)): ?>
      <div class="notification-section">
        <h3>Recent History</h3>
        <?php foreach ($recent_history_overlay as $history): ?>
        <div class="history-item">
          <div class="history-item-left">
            <div class="history-item-type"><?php echo formatTransactionType($history['transaction_type']); ?></div>
            <div class="history-item-meta"><?php echo timeAgo($history['created_at']); ?></div>
          </div>
          <div class="history-item-amount"><?php echo formatCurrency($history['amount']); ?></div>
        </div>
        <?php endforeach; ?>
        <a href="history.php" class="view-more-btn">View More History</a>
      </div>
      <?php endif; ?>
    </div>
  </div>


   <nav class="mobile-fintech-footer">
    
  <a href="dashboard.php" class="active">
    <svg viewBox="0 0 24 24"><path d="M12 3a9 9 0 1 1 0 18 9 9 0 0 1 0-18Zm1 4h-2v6h6v-2h-4V7Z"/></svg>
    <span>Dashboard</span>
  </a>

  <!-- Premium (crown icon) -->
  <a href="membership.php">
    <svg viewBox="0 0 24 24"><path d="M5 7l2.5 5 4.5-4 4.5 4L19 7l2 13H3l2-13Z"/></svg>
    <span>Premium</span>
  </a>

  <a href="daily-rewards.php">
    <svg viewBox="0 0 24 24"><path d="M20 3H4a1 1 0 0 0-1 1v16l5-3 5 3 5-3 5 3V4a1 1 0 0 0-1-1Zm-2 5-6.7 6.7L7 10.4l1.4-1.4 2.9 2.9L17.6 6 18 8Z"/></svg>
    <span>Rewards</span>
  </a>

  <a href="history.php">
  <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
    <path d="M13 3a9 9 0 1 0 9 9h-2a7 7 0 1 1-7-7V3l4 4-4 4V7a5 5 0 1 0 5 5h2a7 7 0 1 1-7-7z"/>
  </svg>
  <span>History</span>
</a>


  <a href="profile.php">
    <svg viewBox="0 0 24 24"><path d="M12 2a6 6 0 0 1 6 6c0 3.31-2.69 6-6 6s-6-2.69-6-6a6 6 0 0 1 6-6Zm0 14c4.42 0 8 1.79 8 4v2H4v-2c0-2.21 3.58-4 8-4Z"/></svg>
    <span>Profile</span>
  </a>
</nav>

    <script>
        let currentFilter = 'credit';
        let currentBalanceType = 'total_balance';

        let balanceCardsScroll = document.querySelector('.balance-cards-scroll');
        let balanceAutoScrollInterval;
        let balanceLastInteractionTime = Date.now();
        let balanceInactivityTimeout;
        const BALANCE_INACTIVITY_DELAY = 4000; // 4 seconds before auto-scroll starts
        const BALANCE_SCROLL_SPEED = 1; // pixels per interval (smooth increment)
        const BALANCE_SCROLL_INTERVAL = 30; // milliseconds between scroll steps

        function startBalanceCardAutoScroll() {
            // Only auto-scroll if not at the end
            const maxScroll = balanceCardsScroll.scrollWidth - balanceCardsScroll.clientWidth;
            if (balanceCardsScroll.scrollLeft < maxScroll - 5) {
                balanceAutoScrollInterval = setInterval(() => {
                    balanceCardsScroll.scrollLeft += BALANCE_SCROLL_SPEED;
                    
                    // Check if we've reached the end
                    if (balanceCardsScroll.scrollLeft >= maxScroll - 5) {
                        clearInterval(balanceAutoScrollInterval);
                    }
                }, BALANCE_SCROLL_INTERVAL);
            }
        }

        function resetBalanceInactivityTimer() {
            clearTimeout(balanceInactivityTimeout);
            clearInterval(balanceAutoScrollInterval);
            balanceLastInteractionTime = Date.now();
            
            // Start auto-scroll after 4 seconds of inactivity
            balanceInactivityTimeout = setTimeout(() => {
                startBalanceCardAutoScroll();
            }, BALANCE_INACTIVITY_DELAY);
        }

        // Balance card interaction listeners
        balanceCardsScroll.addEventListener('scroll', resetBalanceInactivityTimer);
        balanceCardsScroll.addEventListener('wheel', resetBalanceInactivityTimer);
        balanceCardsScroll.addEventListener('touchstart', resetBalanceInactivityTimer);
        balanceCardsScroll.addEventListener('touchend', resetBalanceInactivityTimer);
        balanceCardsScroll.addEventListener('mousedown', resetBalanceInactivityTimer);
        balanceCardsScroll.addEventListener('mouseup', resetBalanceInactivityTimer);

        function filterTransactions(type) {
            currentFilter = type;
            
            document.querySelectorAll('.history-tab').forEach(tab => {
                tab.classList.remove('active');
            });
            document.querySelector(`[data-tab="${type}"]`).classList.add('active');
            
            const transactions = document.querySelectorAll('.transaction-item');
            let visibleCount = 0;
            
            transactions.forEach(item => {
                if (item.dataset.category === type) {
                    item.style.display = 'flex';
                    visibleCount++;
                } else {
                    item.style.display = 'none';
                }
            });
            
            const wrapper = document.getElementById('transactionsWrapper');
            let emptyState = wrapper.querySelector('.empty-state');
            
            if (visibleCount === 0 && !emptyState) {
                emptyState = document.createElement('div');
                emptyState.className = 'empty-state';
                emptyState.innerHTML = `
                    <svg viewBox="0 0 24 24" fill="currentColor">
                        <path d="M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm0 16H5V5h14v14zm-7-2h2v-4h4v-2h-4V7h-2v4H7v2h4z"/>
                    </svg>
                    <p>No ${type} transactions yet</p>
                `;
                wrapper.appendChild(emptyState);
            } else if (visibleCount > 0 && emptyState) {
                emptyState.remove();
            }
        }
        
        function navigateToGame(gameName) {
            window.location.href = 'play-earn.php#' + gameName.toLowerCase().replace(/\s+/g, '-');
        }

        function changeBalanceType(balanceType) {
            currentBalanceType = balanceType;
            const primeWalletAmountElement = document.querySelector('.prime-card .balance-amount');
            const primeWalletNameElement = document.querySelector('.prime-card .wallet-name');

            let newAmount = 0;
            let newName = '';

            const balanceData = <?php echo json_encode($balances); ?>;

            switch (balanceType) {
                case 'total_balance':
                    newAmount = balanceData.total_balance;
                    newName = 'Total Earnings';
                    break;
                case 'task_earnings':
                    newAmount = balanceData.task_earnings;
                    newName = 'Activity Balance';
                    break;
                case 'referral_earnings':
                    newAmount = balanceData.referral_earnings;
                    newName = 'Referral Balance';
                    break;
                default:
                    newAmount = balanceData.total_balance;
                    newName = 'Total Earnings';
            }

            primeWalletAmountElement.textContent = `₦ ${parseFloat(newAmount).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
            primeWalletNameElement.textContent = newName;
            
            document.querySelectorAll('.balance-type-btn').forEach(btn => btn.classList.remove('active'));
            document.querySelector(`.balance-type-btn[onclick="changeBalanceType('${balanceType}')"]`).classList.add('active');
        }

        let gamesTicker = document.getElementById('gamesTicker');
        let gamesAutoScrollInterval;
        let gamesScrollPosition = 0;
        let gamesLastInteractionTime = Date.now();
        let gamesInactivityTimeout;
        const GAMES_INACTIVITY_DELAY = 4000; // 4 seconds
        const GAMES_SCROLL_SPEED = 0.8; // pixels per interval for smooth continuous movement
        const GAMES_SCROLL_INTERVAL = 30; // milliseconds (adjust for speed: lower = faster, higher = slower)

        // Speed adjustment guide: 
        // GAMES_SCROLL_SPEED: 0.5 = very slow, 0.8 = medium, 1.2 = fast, 2.0 = very fast
        // GAMES_SCROLL_INTERVAL: 20ms = faster updates (smoother), 50ms = slower updates

        function startGamesTickerScroll() {
            gamesAutoScrollInterval = setInterval(() => {
                gamesScrollPosition += GAMES_SCROLL_SPEED;
                const maxScroll = gamesTicker.scrollWidth - gamesTicker.clientWidth;
                
                if (gamesScrollPosition >= maxScroll) {
                    gamesScrollPosition = 0;
                }
                gamesTicker.scrollLeft = gamesScrollPosition;
            }, GAMES_SCROLL_INTERVAL);
        }

        function resetGamesInactivityTimer() {
            clearTimeout(gamesInactivityTimeout);
            clearInterval(gamesAutoScrollInterval);
            gamesLastInteractionTime = Date.now();
            
            // Resume auto-scroll after 4 seconds of no interaction
            gamesInactivityTimeout = setTimeout(() => {
                startGamesTickerScroll();
            }, GAMES_INACTIVITY_DELAY);
        }

        // Games carousel interaction listeners - pause and resume on any interaction
        gamesTicker.addEventListener('wheel', (e) => {
            e.preventDefault();
            resetGamesInactivityTimer();
        });

        gamesTicker.addEventListener('touchstart', () => {
            resetGamesInactivityTimer();
        });

        gamesTicker.addEventListener('touchend', () => {
            resetGamesInactivityTimer();
        });

        gamesTicker.addEventListener('mousedown', () => {
            resetGamesInactivityTimer();
        });

        gamesTicker.addEventListener('mouseup', () => {
            resetGamesInactivityTimer();
        });

        // Detect manual scroll
        gamesTicker.addEventListener('scroll', () => {
            resetGamesInactivityTimer();
        });

        window.addEventListener('DOMContentLoaded', () => {
            filterTransactions('credit');
            resetBalanceInactivityTimer();
            resetGamesInactivityTimer();
            changeBalanceType(currentBalanceType);
        });

        function toggleNotificationOverlay() {
            const overlay = document.getElementById('notificationOverlay');
            overlay.classList.toggle('active');
        }

        function markMessageReadAndRefresh(messageId) {
            fetch('mark-message-read.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: 'message_id=' + messageId
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    showToast('Message marked as read!');
                    setTimeout(() => {
                        window.location.reload();
                    }, 1000);
                }
            })
            .catch(err => {
                console.error('Failed to mark message as read:', err);
            });
        }
        
        function showToast(message) {
          console.log('Toast:', message);
        }
    </script>
</body>
</html>
