<?php
// Ensure user data is available
if (!isset($user_data)) {
    $user_data = getCurrentUser();
}

$username = htmlspecialchars($user_data['username'] ?? 'user');

$membership_status = '';
$badge_class = 'free';
$badge_text = 'Activate Account';

// Determine user tier and set appropriate badge
if ($user_data['membership_type'] === 'senior' || !empty($user_data['advertiser_plan'])) {
    $badge_class = 'senior';
    $badge_text = 'Premium Plus';
} elseif ($user_data['membership_type'] === 'premium') {
    $badge_class = 'premium';
    $badge_text = 'Premium';
} else {
    $badge_class = 'free';
    $badge_text = 'Activate Account';
}

$profile_picture = !empty($user_data['profile_picture']) 
    ? htmlspecialchars($user_data['profile_picture']) 
    : 'profile-picture.jpg';

// Check for unread admin notifications
$unread_count = 0;
if (isset($pdo) && isset($user_id)) {
    try {
        $stmt = $pdo->prepare("
            SELECT COUNT(*) as unread_count
            FROM admin_messages am
            WHERE am.is_active = 1
            AND am.id NOT IN (
                SELECT message_id FROM user_message_reads WHERE user_id = ?
            )
        ");
        $stmt->execute([$user_id]);
        $result = $stmt->fetch();
        $unread_count = $result['unread_count'] ?? 0;
    } catch (PDOException $e) {
        error_log("Header notification count error: " . $e->getMessage());
    }
}
// Country-based notification: if user's country (from `users`.`country`) is not Nigeria, show one additional notification
$country_notification = false;
$user_country = 'Nigeria';
$user_currency = 'NGN';

// Prefer country from current user data if available
if (isset($user_data) && !empty($user_data['country'])) {
    $user_country = $user_data['country'];
} else if (isset($pdo) && isset($user_id)) {
    try {
        // Fallback to explicit users lookup if getCurrentUser didn't include it
        $stmt2 = $pdo->prepare("SELECT country FROM users WHERE id = ? LIMIT 1");
        $stmt2->execute([$user_id]);
        $row = $stmt2->fetch();
        if ($row && !empty($row['country'])) {
            $user_country = $row['country'];
        }
    } catch (Exception $e) {
        error_log("Header users lookup error: " . $e->getMessage());
    }
}

// Normalize check and determine currency using a small mapping
if (strtolower(trim($user_country)) !== 'nigeria') {
    $country_notification = true;
    // Expanded mapping for many countries (especially African) to avoid defaulting to USD
    $country_currency_map = [
        'nigeria' => 'NGN',
        'niger' => 'XOF',
        'benin' => 'XOF',
        'burkina faso' => 'XOF',
        'mali' => 'XOF',
        'senegal' => 'XOF',
        'cote d\'ivoire' => 'XOF',
        'côte d\'ivoire' => 'XOF',
        'ivory coast' => 'XOF',
        'togo' => 'XOF',
        'guinea-bissau' => 'XOF',
        'guinea bissau' => 'XOF',
        'cameroon' => 'XAF',
        'central african republic' => 'XAF',
        'chad' => 'XAF',
        'equatorial guinea' => 'XAF',
        'gabon' => 'XAF',
        'congo' => 'XAF',
        'democratic republic of the congo' => 'CDF',
        'dr congo' => 'CDF',
        'congo drc' => 'CDF',
        'south africa' => 'ZAR',
        'namibia' => 'NAD',
        'botswana' => 'BWP',
        'zimbabwe' => 'ZWL',
        'zambia' => 'ZMW',
        'malawi' => 'MWK',
        'mozambique' => 'MZN',
        'angola' => 'AOA',
        'madagascar' => 'MGA',
        'mauritius' => 'MUR',
        'seychelles' => 'SCR',
        'lesotho' => 'LSL',
        'eswatini' => 'SZL',
        'uganda' => 'UGX',
        'kenya' => 'KES',
        'tanzania' => 'TZS',
        'rwanda' => 'RWF',
        'burundi' => 'BIF',
        'eritrea' => 'ERN',
        'ethiopia' => 'ETB',
        'somalia' => 'SOS',
        'sudan' => 'SDG',
        'south sudan' => 'SSP',
        'libya' => 'LYD',
        'tunisia' => 'TND',
        'algeria' => 'DZD',
        'morocco' => 'MAD',
        'mauritania' => 'MRU',
        'senegal' => 'XOF',
        'ghana' => 'GHS',
        'gambia' => 'GMD',
        'liberia' => 'LRD',
        'sierra leone' => 'SLL',
        // Common global mappings
        'united states' => 'USD',
        'usa' => 'USD',
        'united kingdom' => 'GBP',
        'uk' => 'GBP',
        'canada' => 'CAD',
        'australia' => 'AUD',
        'europe' => 'EUR',
        'european union' => 'EUR',
        'france' => 'EUR',
        'germany' => 'EUR',
        'spain' => 'EUR',
        'italy' => 'EUR',
        'netherlands' => 'EUR',
        'switzerland' => 'CHF',
        'sweden' => 'SEK',
        'norway' => 'NOK',
        'denmark' => 'DKK',
        'japan' => 'JPY',
        'china' => 'CNY',
        'india' => 'INR',
    ];

    $lc = strtolower(trim($user_country));
    $user_currency = $country_currency_map[$lc] ?? 'USD';

    // Increase unread count to reflect this additional important notification
    $unread_count = intval($unread_count) + 1;
}

$current_page = basename($_SERVER['PHP_SELF']);

$menu_items = array(
  array('name' => 'Perform Task', 'file' => 'perform-task.php', 'icon' => 'M9 11l3 3L22 4l-1.41-1.41L12 10.17 10.41 8.59 9 10l-3.59-3.59L4 8l5 5zM19 19H5v-2h14v2zm0-4H5v-2h14v2z', 'color' => '#FF6B6B'),
  array('name' => 'Post Task', 'file' => 'post-task.php', 'icon' => 'M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8l-6-6Zm1 14h-3v3h-2v-3H7v-2h3v-3h2v3h3v2Zm-3-9V3.5L18.5 8H12Z', 'color' => '#4ECDC4'),
  array('name' => 'My Tasks', 'file' => 'my-posted-task.php', 'icon' => 'M9 11H7v2h2v-2zm0-4H7v2h2V7zm0 8H7v2h2v-2zm10-8H11v2h8V7zm0 4H11v2h8v-2zm0 4H11v2h8v-2zM4 3h16a1 1 0 0 1 1 1v18a1 1 0 0 1-1.6.8L13 15v3H4a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1z', 'color' => '#FFD93D'),
);

$earn_items = array(
  array(
    'name' => 'Echo Chat',
    'file' => 'chat-earn.php',
    'icon' => 'M4 4h16a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2H8l-4 4V6a2 2 0 0 1 2-2z',
    'color' => '#6BCB77'
  ),
  array(
    'name' => 'Watch & Earn',
    'file' => 'watch-earn.php',
    'icon' => 'M3 5h18v12H3V5zm6 1v10l8-5-8-5z',
    'color' => '#A78BFA'
  ),
  array(
    'name' => 'Stream & Earn',
    'file' => 'stream-earn.php',
    'icon' => 'M12 3v8.8a3.5 3.5 0 1 1-2-3.2V5h6V3h-4z',
    'color' => '#F87171'
  ),
  array(
    'name' => 'Play & Earn',
    'file' => 'play-earn.php',
    'icon' => 'M6 9l-2 6a3 3 0 0 0 3 4h1.5l2-2h3l2 2H17a3 3 0 0 0 3-4l-2-6H6z',
    'color' => '#34D399'
  ),
);



$account_items = array(
  array('name' => 'Dashboard', 'file' => 'dashboard.php', 'icon' => 'M12 3a9 9 0 1 1 0 18 9 9 0 0 1 0-18Zm1 4h-2v6h6v-2h-4V7Z', 'color' => '#60A5FA'),
  array('name' => 'Withdrawal', 'file' => 'withdrawal.php', 'icon' => 'M12 1L8 5h3v9h2V5h3l-4-4zm-7 18v2h14v-2H5z', 'color' => '#FB7185'),
  array('name' => 'Premium', 'file' => 'membership.php', 'icon' => 'M5 7l2.5 5 4.5-4 4.5 4L19 7l2 13H3l2-13Z', 'color' => '#FBBF24'),
//   array('name' => 'Rewards', 'file' => 'daily-rewards.php', 'icon' => 'M20 3H4a1 1 0 0 0-1 1v16l5-3 5 3 5-3 5 3V4a1 1 0 0 0-1-1Zm-2 5-6.7 6.7L7 10.4l1.4-1.4 2.9 2.9L17.6 6 18 8Z', 'color' => '#A78BFA'),
);

$community_items = array(
  array('name' => 'Skill Center', 'file' => 'skill-require.php', 'icon' => 'M12 2a10 10 0 0 0-10 10 9.9 9.9 0 0 0 5.7 9L8 21a8 8 0 1 1 8 0l.3.9A9.9 9.9 0 0 0 22 12 10 10 0 0 0 12 2Zm-1 5h2v6h-2Zm0 8h2v2h-2Z', 'color' => '#14B8A6'),
  array('name' => 'My Invites', 'file' => 'referrals.php', 'icon' => 'M12 12a4 4 0 1 0-4-4 4 4 0 0 0 4 4Zm0 2c-4 0-8 1.79 8 4v1.5h-4v-1.3a6.8 6.8 0 0 0-1.2-2.2A7.9 7.9 0 0 1 18 14Z', 'color' => '#F59E0B'),
);

$other_items = array(
  array('name' => 'Deposit', 'file' => 'membership.php', 'icon' => 'M12 2 2 7v2h20V7L12 2zM4 10v10h2v-8h2v8h2v-8h4v8h2v-8h2v8h2V10H4zM2 22h20v-2H2v2z', 'color' => '#0EA5E9'),
  array('name' => 'History', 'file' => 'history.php', 'icon' => 'M13 3a9 9 0 1 0 9 9h-2a7 7 0 1 1-7-7V3l4 4-4 4V7a5 5 0 1 0 5 5h2a7 7 0 1 1-7-7z', 'color' => '#8B5CF6'),
  array('name' => 'Profile Settings', 'file' => 'profile.php', 'icon' => 'M12 2a6 6 0 0 1 6 6c0 3.31-2.69 6-6 6s-6-2.69-6-6a6 6 0 0 1 6-6Zm0 14c4.42 0 8 1.79 8 4v2H4v-2c0-2.21 3.58-4 8-4Z', 'color' => '#06B6D4'),
);
?>

<style>
.opay-header {
    position: sticky;
    top: 0;
    z-index: 100;
    
    background: transparent;
    backdrop-filter: blur(20px);
    /* border-bottom: 1px solid rgba(86, 139, 241, 0.28); */
    /* box-shadow: 0 4px 20px rgba(4, 10, 36, 0.5); */
    padding: 12px 20px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 16px;
    
 
}

.opay-header-left {
    display: flex;
    align-items: center;
    gap: 14px;
}

.opay-back-link {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    font-weight: 600;
    letter-spacing: 0.06em;
    text-transform: uppercase;
    font-size: 0.75rem;
    color: #f5f9ff;
    text-decoration: none;
    transition: all 0.3s ease;
    padding: 8px 12px;
    border-radius: 10px;
    background: rgba(44, 91, 245, 0.15);
    border: 1px solid rgba(44, 91, 245, 0.3);
}

.opay-back-link:hover {
    background: rgba(44, 91, 245, 0.25);
    transform: translateX(-3px);
}

.opay-profile-pic {
    width: 40px;
    height: 40px;
    border-radius: 50%;
    overflow: hidden;
    border: 2px solid rgba(77, 225, 193, 0.4);
    box-shadow: 0 4px 12px rgba(77, 225, 193, 0.3);
}

.opay-profile-pic img {
    width: 100%;
    height: 100%;
    object-fit: cover;
}

.opay-badge {
    display: inline-block;
    padding: 4px 10px;
    border-radius: 12px;
    font-size: 0.4rem;
    font-weight: 700;
    letter-spacing: 0.05em;
    text-transform: uppercase;
    position: relative;
}

.opay-badge.premium {
    background: linear-gradient(135deg, rgba(255, 215, 0, 0.3), rgba(255, 165, 0, 0.3));
    border: 1px solid rgba(255, 215, 0, 0.5);
    color: #ffd700;
}

.opay-badge.free {
    background: rgba(100, 154, 255, 0.2);
    border: 1px solid rgba(100, 154, 255, 0.4);
    color: #64a0ff;
}

/* Added senior badge with crown styling and animation */
.opay-badge.senior {
    background: linear-gradient(135deg, rgba(218, 165, 32, 0.4), rgba(255, 215, 0, 0.3));
    border: 1px solid rgba(218, 165, 32, 0.6);
    color: #ffd700;
    padding-top: 12px;
}

.opay-badge.senior::before {
    content: '👑';
    position: absolute;
    top: -8px;
    left: 50%;
    transform: translateX(-50%);
    font-size: 1rem;
    animation: crownFloat 2s ease-in-out infinite;
}

@keyframes crownFloat {
    0%, 100% {
        transform: translateX(-50%) translateY(0);
    }
    50% {
        transform: translateX(-50%) translateY(-4px);
    }
}

.opay-username {
    font-size: 0.6rem;
    font-weight: 600;
    color: var(--page-white);
}

.opay-header-right {
    display: flex;
    align-items: center;
    gap: 16px;
}

.opay-help-icon {
    position: relative;
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 2px;
    cursor: pointer;
    transition: all 0.3s ease;
    text-decoration: none;
}

.opay-help-icon:hover {
    transform: translateY(-2px);
}

.opay-help-text {
    font-size: 0.65rem;
    font-weight: 600;
    letter-spacing: 0.05em;
    text-transform: uppercase;
    color: rgba(77, 225, 193, 0.9);
}

.opay-help-circle {
    width: 36px;
    height: 36px;
    border-radius: 50%;
    background: rgba(77, 225, 193, 0.2);
    border: 1px solid rgba(77, 225, 193, 0.4);
    display: flex;
    align-items: center;
    justify-content: center;
    box-shadow: 0 4px 12px rgba(77, 225, 193, 0.3);
}

.opay-help-circle svg {
    width: 18px;
    height: 18px;
    fill: var(--page-mint);
}

.opay-notification-icon {
    position: relative;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    width: 40px;
    height: 40px;
    background: rgba(77, 225, 193, 0.2);
    border: 1px solid rgba(77, 225, 193, 0.3);
    border-radius: 50%;
    cursor: pointer;
    transition: all 0.3s ease;
}

.opay-notification-icon:hover {
    background: rgba(77, 225, 193, 0.3);
    transform: scale(1.05);
}

.opay-notification-icon svg {
    width: 20px;
    height: 20px;
    fill: var(--page-mint);
}

.opay-notification-badge {
    position: absolute;
    top: -4px;
    right: -4px;
    background: #ff4757;
    color: white;
    font-size: 0.65rem;
    font-weight: 700;
    padding: 2px 6px;
    border-radius: 10px;
    min-width: 18px;
    text-align: center;
}

@media (max-width: 680px) {
    .opay-header {
        padding: 30px 22px;
        gap: 10px;
    }

    .opay-header-left {
        gap: 8px;
    }

    .opay-back-link {
        font-size: 0.65rem;
        padding: 6px 8px;
    }

    .opay-profile-pic {
        width: 32px;
        height: 32px;
    }

    .opay-badge {
        font-size: 0.6rem;
        padding: 3px 8px;
    }

    .opay-badge.senior {
        padding-top: 10px;
    }

    .opay-username {
        font-size: 0.8rem;
    }

    .opay-header-right {
        gap: 10px;
    }

    .opay-help-text {
        font-size: 0.6rem;
    }

    .opay-help-circle {
        width: 30px;
        height: 30px;
    }

    .opay-help-circle svg {
        width: 16px;
        height: 16px;
    }

    .opay-notification-icon {
        width: 36px;
        height: 36px;
    }
}

/* Added navigation styles from side-bar.php for hamburger menu */
@import url('https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap');

/* Hamburger button - positioned in header */
.hamburger-btn {
    width: 44px;
    height: 44px;
    background: linear-gradient(135deg, rgba(44, 91, 245, 0.9), rgba(26, 58, 171, 0.8));
    border: 1px solid rgba(44, 91, 245, 0.5);
    border-radius: 12px;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    gap: 5px;
    cursor: pointer;
    transition: all 0.3s ease;
    box-shadow: 0 4px 15px rgba(44, 91, 245, 0.4);
    padding: 0;
    border: 1px solid rgba(44, 91, 245, 0.5);
}

.hamburger-btn:hover {
    transform: scale(1.05);
    box-shadow: 0 6px 20px rgba(44, 91, 245, 0.6);
}

.hamburger-btn span {
    width: 22px;
    height: 2.5px;
    background: #fff;
    border-radius: 2px;
    transition: all 0.3s ease;
}

.hamburger-btn.active span:nth-child(1) {
    transform: rotate(45deg) translate(6px, 6px);
}

.hamburger-btn.active span:nth-child(2) {
    opacity: 0;
}

.hamburger-btn.active span:nth-child(3) {
    transform: rotate(-45deg) translate(6px, -6px);
}

/* Sidebar overlay */
.sidebar-overlay {
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: rgba(3, 9, 34, 0.8);
    backdrop-filter: blur(5px);
    opacity: 0;
    visibility: hidden;
    transition: all 0.3s ease;
    z-index: 9998;
    cursor: pointer;
}

.sidebar-overlay.active {
    opacity: 1;
    visibility: visible;
}

/* Sidebar panel */
.sidebar-panel {
    position: fixed;
    top: 0;
    left: 0;
    bottom: 0;
    width: 280px;
    background: linear-gradient(180deg, rgba(13, 24, 62, 0.98), rgba(8, 18, 52, 0.98));
    backdrop-filter: blur(20px);
    border-right: 1px solid rgba(86, 139, 241, 0.28);
    box-shadow: 4px 0 30px rgba(4, 10, 36, 0.7);
    transform: translateX(-100%);
    transition: transform 0.4s cubic-bezier(0.19, 1, 0.22, 1);
    z-index: 9999;
    overflow-y: auto;
    display: flex;
    flex-direction: column;
}

.sidebar-panel.active {
    transform: translateX(0);
}

/* Sidebar header */
.sidebar-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 20px;
    border-bottom: 1px solid rgba(86, 139, 241, 0.2);
    flex-shrink: 0;
}

.sidebar-logo {
    font-size: 1.3rem;
    font-weight: 700;
    color: #fff;
    letter-spacing: 0.05em;
    display: flex;
    align-items: center;
    gap: 8px;
}

.sidebar-logo img {
    width: 32px;
    height: 32px;
    object-fit: contain;
    transform: scale(1.5) translateY(1px);
    transform-origin: center;
}

.sidebar-close-btn {
    background: none;
    border: none;
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 4px;
    color: rgba(205, 219, 255, 0.7);
    transition: color 0.3s ease;
}

.sidebar-close-btn:hover {
    color: #fff;
}

.sidebar-close-btn svg {
    width: 24px;
    height: 24px;
}

/* Menu sections with dropdown */
.sidebar-menu-section {
    padding: 8px 0;
}

.sidebar-section-toggle {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 12px 16px;
    background: none;
    border: none;
    cursor: pointer;
    width: 100%;
    color: rgba(205, 219, 255, 0.75);
    font-family: 'Poppins', sans-serif;
    font-size: 0.85rem;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 0.05em;
    transition: all 0.3s ease;
}

.sidebar-section-toggle:hover {
    color: #fff;
    background: rgba(44, 92, 240, 0.1);
}

.sidebar-section-toggle svg {
    width: 16px;
    height: 16px;
    transition: transform 0.3s ease;
}

.sidebar-section-toggle.active svg {
    transform: rotate(180deg);
}

.sidebar-section-items {
    max-height: 0;
    overflow: hidden;
    transition: max-height 0.3s ease;
}

.sidebar-section-items.active {
    max-height: 500px;
}

/* Menu list */
.sidebar-menu-list {
    display: flex;
    flex-direction: column;
    padding: 16px 0;
    flex: 1;
    font-family: 'Poppins', sans-serif;
}

/* Menu items */
.sidebar-menu-item {
    display: flex;
    align-items: center;
    gap: 12px;
    padding: 12px 16px;
    text-decoration: none;
    color: rgba(205, 219, 255, 0.85);
    font-family: 'Poppins', sans-serif;
    font-size: 0.9rem;
    font-weight: 500;
    transition: all 0.3s ease;
    border-left: 3px solid transparent;
    position: relative;
}

.sidebar-menu-item.active {
    background: linear-gradient(90deg, rgba(77, 225, 193, 0.15), transparent);
    color: #fff;
    border-left-color: #4de1c1;
    padding-left: 20px;
}

.sidebar-menu-item:hover {
    background: rgba(44, 92, 240, 0.1);
    color: #fff;
    border-left-color: #4de1c1;
    padding-left: 20px;
}

.sidebar-menu-item svg {
    width: 20px;
    height: 20px;
    flex-shrink: 0;
    fill: currentColor;
}

.sidebar-menu-item span {
    font-size: 0.9rem;
    font-weight: 500;
}

/* Logout section */
.sidebar-logout-section {
    padding: 16px 0;
    border-top: 1px solid rgba(86, 139, 241, 0.2);
    margin-top: auto;
    flex-shrink: 0;
}

.sidebar-logout-btn {
    display: flex;
    align-items: center;
    gap: 12px;
    padding: 12px 16px;
    background: linear-gradient(135deg, rgba(255, 77, 77, 0.15), rgba(255, 51, 102, 0.1));
    border: 1px solid rgba(255, 77, 77, 0.3);
    border-radius: 8px;
    margin: 0 8px;
    color: #FF6B6B;
    font-family: 'Poppins', sans-serif;
    font-weight: 600;
    cursor: pointer;
    transition: all 0.3s ease;
    width: calc(100% - 16px);
}

.sidebar-logout-btn:hover {
    background: linear-gradient(135deg, rgba(255, 77, 77, 0.25), rgba(255, 51, 102, 0.2));
    border-color: rgba(255, 77, 77, 0.5);
    transform: translateY(-2px);
}

.sidebar-logout-btn svg {
    width: 18px;
    height: 18px;
    fill: currentColor;
}

body.sidebar-open {
    overflow: hidden;
    height: 100vh;
}
</style>

<header class="opay-header">
    <div class="opay-header-left">
       
        <div class="opay-profile-pic">
            <img src="<?php echo $profile_picture; ?>" alt="Profile">
        </div>
        
        
        
        <span class="opay-username">Hi, @<?php echo $username; ?></span>
        <span class="opay-badge <?php echo $badge_class; ?>">
            <?php echo $badge_text; ?>
        </span>
    </div>
    
    <div class="opay-header-right">
       
        
        <div class="opay-notification-icon" onclick="toggleNotificationOverlay()">
            <svg viewBox="0 0 24 24">
                <path d="M12 22c1.1 0 2-.9 2-2h-4c0 1.1.9 2 2 2zm6-6v-5c0-3.07-1.63-5.64-4.5-6.32V4c0-.83-.67-1.5-1.5-1.5s-1.5.67-1.5 1.5v.68C7.64 5.36 6 7.92 6 11v5l-2 2v1h16v-1l-2-2zm-2 1H8v-6c0-2.48 1.51-4.5 4-4.5s4 2.02 4 4.5v6z"/>
            </svg>
            <?php if ($unread_count > 0): ?>
                <span class="opay-notification-badge"><?php echo $unread_count; ?></span>
            <?php endif; ?>
        </div>
         <!-- Added hamburger menu button -->
        <button class="hamburger-btn" id="hamburgerBtn" aria-label="Toggle Menu">
            <span></span>
            <span></span>
            <span></span>
        </button>
        
    </div>
</header>

<!-- Added sidebar navigation overlay and panel -->
<div class="sidebar-overlay" id="sidebarOverlay"></div>

<div class="sidebar-panel" id="sidebarPanel">
    <div class="sidebar-header">
        <div class="sidebar-logo">
            <img src="logo.png" alt="Earnova Logo">
            <span style="display: none;">Earnova</span>
        </div>
        <button class="sidebar-close-btn" id="sidebarCloseBtn" aria-label="Close Menu">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <line x1="18" y1="6" x2="6" y2="18"></line>
                <line x1="6" y1="6" x2="18" y2="18"></line>
            </svg>
        </button>
    </div>

    <div class="sidebar-menu-list">
        <!-- Tasks Section -->
        <div class="sidebar-menu-section">
            <button class="sidebar-section-toggle active" onclick="toggleSection(this)">
                Tasks
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <polyline points="6 9 12 15 18 9"></polyline>
                </svg>
            </button>
            <div class="sidebar-section-items active">
                <?php foreach($menu_items as $item): ?>
                    <a href="<?php echo $item['file']; ?>" class="sidebar-menu-item <?php echo ($current_page === $item['file']) ? 'active' : ''; ?>">
                        <svg viewBox="0 0 24 24" style="color: <?php echo $item['color']; ?>"><path d="<?php echo $item['icon']; ?>"/></svg>
                        <span><?php echo $item['name']; ?></span>
                    </a>
                <?php endforeach; ?>
            </div>
        </div>

        <!-- Earn Section -->
        <div class="sidebar-menu-section">
            <button class="sidebar-section-toggle" onclick="toggleSection(this)">
                Earn
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <polyline points="6 9 12 15 18 9"></polyline>
                </svg>
            </button>
            <div class="sidebar-section-items">
                <?php foreach($earn_items as $item): ?>
                    <a href="<?php echo $item['file']; ?>" class="sidebar-menu-item <?php echo ($current_page === $item['file']) ? 'active' : ''; ?>">
                        <svg viewBox="0 0 24 24" style="color: <?php echo $item['color']; ?>"><path d="<?php echo $item['icon']; ?>"/></svg>
                        <span><?php echo $item['name']; ?></span>
                    </a>
                <?php endforeach; ?>
            </div>
        </div>

        <!-- Account Section -->
        <div class="sidebar-menu-section">
            <button class="sidebar-section-toggle" onclick="toggleSection(this)">
                Account
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <polyline points="6 9 12 15 18 9"></polyline>
                </svg>
            </button>
            <div class="sidebar-section-items">
                <?php foreach($account_items as $item): ?>
                    <a href="<?php echo $item['file']; ?>" class="sidebar-menu-item <?php echo ($current_page === $item['file']) ? 'active' : ''; ?>">
                        <svg viewBox="0 0 24 24" style="color: <?php echo $item['color']; ?>"><path d="<?php echo $item['icon']; ?>"/></svg>
                        <span><?php echo $item['name']; ?></span>
                    </a>
                <?php endforeach; ?>
            </div>
        </div>

        <!-- Community Section -->
        <div class="sidebar-menu-section">
            <button class="sidebar-section-toggle" onclick="toggleSection(this)">
                Community
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <polyline points="6 9 12 15 18 9"></polyline>
                </svg>
            </button>
            <div class="sidebar-section-items">
                <?php foreach($community_items as $item): ?>
                    <a href="<?php echo $item['file']; ?>" class="sidebar-menu-item <?php echo ($current_page === $item['file']) ? 'active' : ''; ?>">
                        <svg viewBox="0 0 24 24" style="color: <?php echo $item['color']; ?>"><path d="<?php echo $item['icon']; ?>"/></svg>
                        <span><?php echo $item['name']; ?></span>
                    </a>
                <?php endforeach; ?>
            </div>
        </div>

        <!-- More Section -->
        <div class="sidebar-menu-section">
            <button class="sidebar-section-toggle" onclick="toggleSection(this)">
                More
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <polyline points="6 9 12 15 18 9"></polyline>
                </svg>
            </button>
            <div class="sidebar-section-items">
                <?php foreach($other_items as $item): ?>
                    <a href="<?php echo $item['file']; ?>" class="sidebar-menu-item <?php echo ($current_page === $item['file']) ? 'active' : ''; ?>">
                        <svg viewBox="0 0 24 24" style="color: <?php echo $item['color']; ?>"><path d="<?php echo $item['icon']; ?>"/></svg>
                        <span><?php echo $item['name']; ?></span>
                    </a>
                <?php endforeach; ?>
            </div>
        </div>
    </div>

    <!-- Logout Section -->
    <div class="sidebar-logout-section">
        <button class="sidebar-logout-btn" onclick="openLogoutModal()">
            <svg viewBox="0 0 24 24" fill="currentColor"><path d="M17 7l-1.41 1.41L18.17 11H8v2h10.17l-2.58 2.58L17 17l5-5zM4 5h8V3H4c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h8v-2H4V5z"/></svg>
            <span>Logout</span>
        </button>
    </div>
</div>

<!-- Logout Modal -->
<div id="logoutModal" style="display: none; position: fixed; top: 0; left: 0; right: 0; bottom: 0; background: rgba(3, 9, 34, 0.9); backdrop-filter: blur(10px); z-index: 10000; justify-content: center; align-items: center;">
    <div style="background: linear-gradient(180deg, rgba(13, 24, 62, 0.98), rgba(8, 18, 52, 0.98)); border: 1px solid rgba(86, 139, 241, 0.28); border-radius: 16px; padding: 32px; max-width: 400px; box-shadow: 0 20px 60px rgba(4, 10, 36, 0.7);">
        <h2 style="font-family: 'Poppins', sans-serif; font-size: 1.5rem; color: #fff; margin-bottom: 16px; font-weight: 700;">Confirm Logout</h2>
        <p style="font-family: 'Poppins', sans-serif; color: rgba(205, 219, 255, 0.85); margin-bottom: 32px; font-size: 0.95rem;">Are you sure you want to logout from your account?</p>
        <div style="display: flex; gap: 12px;">
            <button onclick="window.location.href='logout.php'" style="flex: 1; padding: 12px 16px; background: linear-gradient(135deg, rgba(255, 77, 77, 0.25), rgba(255, 51, 102, 0.2)); color: #FF6B6B; border: 1px solid rgba(255, 77, 77, 0.3); border-radius: 8px; font-family: 'Poppins', sans-serif; font-weight: 600; cursor: pointer; transition: all 0.3s ease;">
                Yes, Logout
            </button>
            <button onclick="closeLogoutModal()" style="flex: 1; padding: 12px 16px; background: rgba(44, 92, 240, 0.2); color: #4de1c1; border: 1px solid rgba(44, 92, 240, 0.3); border-radius: 8px; font-family: 'Poppins', sans-serif; font-weight: 600; cursor: pointer; transition: all 0.3s ease;">
                Cancel
            </button>
        </div>
    </div>
</div>

<script>
const hamburgerBtn = document.getElementById('hamburgerBtn');
const sidebarOverlay = document.getElementById('sidebarOverlay');
const sidebarPanel = document.getElementById('sidebarPanel');
const sidebarCloseBtn = document.getElementById('sidebarCloseBtn');

function toggleSidebar() {
    hamburgerBtn.classList.toggle('active');
    sidebarOverlay.classList.toggle('active');
    sidebarPanel.classList.toggle('active');
    document.body.classList.toggle('sidebar-open');
}

function closeSidebar() {
    hamburgerBtn.classList.remove('active');
    sidebarOverlay.classList.remove('active');
    sidebarPanel.classList.remove('active');
    document.body.classList.remove('sidebar-open');
}

function toggleSection(btn) {
    btn.classList.toggle('active');
    const items = btn.nextElementSibling;
    items.classList.toggle('active');
}

function openLogoutModal() {
    document.getElementById('logoutModal').style.display = 'flex';
}

function closeLogoutModal() {
    document.getElementById('logoutModal').style.display = 'none';
}

hamburgerBtn.addEventListener('click', toggleSidebar);
sidebarOverlay.addEventListener('click', closeSidebar);
sidebarCloseBtn.addEventListener('click', closeSidebar);

document.querySelectorAll('.sidebar-menu-item').forEach(link => {
    link.addEventListener('click', closeSidebar);
});

document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape' && sidebarPanel.classList.contains('active')) {
        closeSidebar();
    }
});
</script>
