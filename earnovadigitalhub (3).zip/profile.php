<?php
session_start();
require_once 'config/database.php';
require_once 'includes/session.php';
require_once 'includes/connect.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$user_id = $_SESSION['user_id'];
$success_message = '';
$error_message = '';

// Fetch user data
$stmt = $conn->prepare("
    SELECT u.*, b.total_balance, b.task_earnings, b.referral_earnings
    FROM users u
    LEFT JOIN balances b ON u.id = b.user_id
    WHERE u.id = ?
");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();
$stmt->close();

if (!$user) {
    header('Location: login.php');
    exit();
}

$is_senior = ($user['advertiser_plan'] === 'senior');

function canUpdateField($last_updated, $days_required) {
    // Always allow updates - no time restrictions
    return ['can_update' => true, 'message' => ''];
}

$can_update_username = canUpdateField($user['username_last_updated'] ?? null, 30);
$can_update_full_name = canUpdateField($user['full_name_last_updated'] ?? null, 30);
$can_update_phone = canUpdateField($user['phone_last_updated'] ?? null, 30);
$can_update_profile_picture = canUpdateField($user['profile_picture_last_updated'] ?? null, 60);
$can_update_withdrawal = canUpdateField($user['withdrawal_method_last_updated'] ?? null, 7);
$can_update_gender = empty($user['gender']) ? ['can_update' => true, 'message' => ''] : ['can_update' => false, 'message' => 'Gender is a permanent setting and cannot be changed once set'];


// Set theme in session if not set
if (!isset($_SESSION['theme'])) {
    $_SESSION['theme'] = $user['theme_preference'] ?? 'dark';
}

// Calculate profile completion percentage
$profile_fields = [
    'full_name' => !empty($user['full_name']),
    'email' => !empty($user['email']),
    'phone' => !empty($user['phone']),
    'profile_picture' => !empty($user['profile_picture']),
    'instagram_link' => !empty($user['instagram_link']),
    'twitter_link' => !empty($user['twitter_link']),
    'email_verified' => $user['email_verified']
];
$completed_fields = count(array_filter($profile_fields));
$total_fields = count($profile_fields);
$profile_completion = round(($completed_fields / $total_fields) * 100);

// Handle profile update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_profile'])) {
    $full_name = trim($_POST['full_name']);
    $phone = trim($_POST['phone']);
    $username = trim($_POST['username']);
    
    $errors = [];
    $updates = [];
    $update_params = [];
    $update_types = '';
    
    // Validate inputs
    if (empty($full_name)) {
        $errors[] = "Full name is required";
    }
    
    if (!empty($phone) && !preg_match('/^[0-9+\-\s()]+$/', $phone)) {
        $errors[] = "Invalid phone number format";
    }
    
    // Check if phone number already exists for another user
    if (!empty($phone) && empty($errors)) {
        $stmt_check_phone = $conn->prepare("SELECT id FROM users WHERE phone = ? AND id != ?");
        $stmt_check_phone->bind_param("si", $phone, $user_id);
        $stmt_check_phone->execute();
        $result_check_phone = $stmt_check_phone->get_result();
        $stmt_check_phone->close();

        if ($result_check_phone->num_rows > 0) {
            $errors[] = "Phone number already in use. Please use a different phone number";
        }
    }
    
    // Check if username already exists
    if (empty($errors)) {
        $stmt_check_username = $conn->prepare("SELECT id FROM users WHERE username = ? AND id != ?");
        $stmt_check_username->bind_param("si", $username, $user_id);
        $stmt_check_username->execute();
        $result_check_username = $stmt_check_username->get_result();
        $stmt_check_username->close();

        if ($result_check_username->num_rows > 0) {
            $errors[] = "Username already in use. Please choose a different one";
        }
    }
    
    if (empty($errors)) {
        // Check each field individually and only update if allowed
        if ($full_name !== $user['full_name']) {
            if ($can_update_full_name['can_update']) {
                $updates[] = "full_name = ?";
                $updates[] = "full_name_last_updated = NOW()";
                $update_params[] = $full_name;
                $update_types .= 's';
            } else {
                $errors[] = "Full name: " . $can_update_full_name['message'];
            }
        }
        
        if ($phone !== ($user['phone'] ?? '')) {
            if ($can_update_phone['can_update']) {
                $updates[] = "phone = ?";
                $updates[] = "phone_last_updated = NOW()";
                $update_params[] = $phone;
                $update_types .= 's';
            } else {
                $errors[] = "Phone: " . $can_update_phone['message'];
            }
        }
        
        if ($username !== $user['username']) {
            if ($can_update_username['can_update']) {
                $updates[] = "username = ?";
                $updates[] = "username_last_updated = NOW()";
                $update_params[] = $username;
                $update_types .= 's';
            } else {
                $errors[] = "Username: " . $can_update_username['message'];
            }
        }
        
        if (!empty($updates)) {
            $update_params[] = $user_id;
            $update_types .= 'i';
            
            $sql = "UPDATE users SET " . implode(", ", $updates) . " WHERE id = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param($update_types, ...$update_params);
            
            if ($stmt->execute()) {
                $success_message = "Profile updated successfully!";
                // Refresh user data
                $stmt_refresh = $conn->prepare("
                    SELECT u.*, b.total_balance, b.task_earnings, b.referral_earnings
                    FROM users u
                    LEFT JOIN balances b ON u.id = b.user_id
                    WHERE u.id = ?
                ");
                $stmt_refresh->bind_param("i", $user_id);
                $stmt_refresh->execute();
                $result_refresh = $stmt_refresh->get_result();
                $user = $result_refresh->fetch_assoc();
                $stmt_refresh->close();
                
                // Recalculate restrictions
                $can_update_full_name = canUpdateField($user['full_name_last_updated'], 60);
                $can_update_phone = canUpdateField($user['phone_last_updated'], 60);
                $can_update_username = canUpdateField($user['username_last_updated'], 60);
            } else {
                $errors[] = "Failed to update profile";
            }
            $stmt->close();
        } else {
            if (empty($errors)) {
                $success_message = "No changes detected";
            }
        }
    }
    
    if (!empty($errors)) {
        $error_message = implode(". ", $errors);
    }
}

// Handle email update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_email'])) {
    $new_email = trim($_POST['email']);
    
    // Validate email
    if (!filter_var($new_email, FILTER_VALIDATE_EMAIL)) {
        $error_message = "Invalid email format";
    } else {
        // Check if email already exists
        $stmt = $conn->prepare("SELECT id FROM users WHERE email = ? AND id != ?");
        $stmt->bind_param("si", $new_email, $user_id);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows > 0) {
            $error_message = "Email already in use";
        } else {
            $stmt = $conn->prepare("UPDATE users SET email = ?, email_verified = FALSE WHERE id = ?");
            $stmt->bind_param("si", $new_email, $user_id);
            
            if ($stmt->execute()) {
                $success_message = "Email updated successfully! Please verify your new email.";
                $user['email'] = $new_email;
                $user['email_verified'] = false;
            } else {
                $error_message = "Failed to update email";
            }
        }
        $stmt->close();
    }
}

// Handle avatar upload
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['avatar'])) {
    if (!$can_update_profile_picture['can_update']) {
        $error_message = "Profile picture update restriction: " . $can_update_profile_picture['message'];
    } else {
        $allowed_types = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
        $max_size = 5 * 1024 * 1024; // 5MB
        
        $file = $_FILES['avatar'];
        
        if ($file['error'] === UPLOAD_ERR_OK) {
            if (!in_array($file['type'], $allowed_types)) {
                $error_message = "Invalid file type. Only JPG, PNG, GIF, and WebP are allowed.";
            } elseif ($file['size'] > $max_size) {
                $error_message = "File too large. Maximum size is 5MB.";
            } else {
                // Create uploads directory if it doesn't exist
                $upload_dir = 'uploads/avatars/';
                if (!file_exists($upload_dir)) {
                    mkdir($upload_dir, 0777, true);
                }
                
                // Generate unique filename
                $extension = pathinfo($file['name'], PATHINFO_EXTENSION);
                $filename = 'avatar_' . $user_id . '_' . time() . '.' . $extension;
                $filepath = $upload_dir . $filename;
                
                if (move_uploaded_file($file['tmp_name'], $filepath)) {
                    // Delete old avatar if exists
                    if (!empty($user['profile_picture']) && file_exists($user['profile_picture'])) {
                        unlink($user['profile_picture']);
                    }
                    
                    $stmt = $conn->prepare("UPDATE users SET profile_picture = ?, profile_picture_last_updated = NOW() WHERE id = ?");
                    $stmt->bind_param("si", $filepath, $user_id);
                    
                    if ($stmt->execute()) {
                        $success_message = "Avatar updated successfully!";
                        $user['profile_picture'] = $filepath;
                        $user['profile_picture_last_updated'] = date('Y-m-d H:i:s');
                        $can_update_profile_picture = canUpdateField($user['profile_picture_last_updated'], 60);
                    } else {
                        $error_message = "Failed to update avatar in database";
                    }
                    $stmt->close();
                } else {
                    $error_message = "Failed to upload file";
                }
            }
        } else {
            $error_message = "Upload error: " . $file['error'];
        }
    }
}

// Handle social links update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_socials'])) {
    $instagram = trim($_POST['instagram_link']);
    $twitter = trim($_POST['twitter_link']);
    $discord = trim($_POST['discord_link']);
    
    // Validate URLs if provided
    if (!empty($instagram) && !filter_var($instagram, FILTER_VALIDATE_URL)) {
        $error_message = "Invalid Instagram URL";
    } elseif (!empty($twitter) && !filter_var($twitter, FILTER_VALIDATE_URL)) {
        $error_message = "Invalid Twitter URL";
    } elseif (!empty($discord) && !filter_var($discord, FILTER_VALIDATE_URL)) {
        $error_message = "Invalid Discord URL";
    } else {
        $stmt = $conn->prepare("UPDATE users SET instagram_link = ?, twitter_link = ?, discord_link = ? WHERE id = ?");
        $stmt->bind_param("sssi", $instagram, $twitter, $discord, $user_id);
        
        if ($stmt->execute()) {
            $success_message = "Social links updated successfully!";
            $user['instagram_link'] = $instagram;
            $user['twitter_link'] = $twitter;
            $user['discord_link'] = $discord;
        } else {
            $error_message = "Failed to update social links";
        }
        $stmt->close();
    }
}

$is_senior = isset($user['advertiser_plan']) && strtolower($user['advertiser_plan']) === 'senior';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_chat_earn'])) {

    // Only SENIOR users can update Echo Chat
    if (!$is_senior) {
        $error_message = "Echo Chat settings are reserved exclusively for Premium Plus members.";
    
    } else {

        $whatsapp_number = trim($_POST['whatsapp_number']);
        $chat_earn_enabled = isset($_POST['chat_earn_enabled']) ? 1 : 0;

        // Validate WhatsApp number
        if (!empty($whatsapp_number)) {

            if (!preg_match('/^0[7-9][0-1]\d{8}$/', $whatsapp_number)) {
                $error_message = "Invalid WhatsApp number format. Enter a valid Nigerian number (070, 080, 081, 071, 090, 091...).";

            } else {

                // Ensure number is unique
                $stmt_check = $conn->prepare("SELECT id FROM users WHERE whatsapp_number = ? AND id != ?");
                $stmt_check->bind_param("si", $whatsapp_number, $user_id);
                $stmt_check->execute();
                $result_check = $stmt_check->get_result();
                $stmt_check->close();

                if ($result_check->num_rows > 0) {
                    $error_message = "This WhatsApp number is already used by another user.";

                } else {
                    // Save updates
                    $stmt = $conn->prepare("UPDATE users SET whatsapp_number = ?, chat_earn_enabled = ? WHERE id = ?");
                    $stmt->bind_param("sii", $whatsapp_number, $chat_earn_enabled, $user_id);

                    if ($stmt->execute()) {
                        $success_message = "Echo Chat settings updated successfully!";
                        $user['whatsapp_number'] = $whatsapp_number;
                        $user['chat_earn_enabled'] = $chat_earn_enabled;
                    } else {
                        $error_message = "Failed to update Echo Chat settings.";
                    }

                    $stmt->close();
                }
            }

        } else {
            // No number provided — update only the toggle
            $stmt = $conn->prepare("UPDATE users SET whatsapp_number = ?, chat_earn_enabled = ? WHERE id = ?");
            $stmt->bind_param("sii", $whatsapp_number, $chat_earn_enabled, $user_id);

            if ($stmt->execute()) {
                $success_message = "Echo Chat settings updated successfully!";
                $user['whatsapp_number'] = $whatsapp_number;
                $user['chat_earn_enabled'] = $chat_earn_enabled;
            } else {
                $error_message = "Failed to update Echo Chat settings.";
            }

            $stmt->close();
        }
    }
}


// Handle Withdrawal Method save
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_withdrawal_method'])) {
    if (!$can_update_withdrawal['can_update']) {
        $error_message = "Withdrawal method update restriction: " . $can_update_withdrawal['message'];
    } else {
        $account_number = trim($_POST['account_number']);
        $account_name = trim($_POST['account_name']);
        $bank_name = trim($_POST['bank_name']);
        $bank_code = trim($_POST['bank_code']);

        // Basic validation
        if (empty($account_number) || empty($account_name) || empty($bank_name) || empty($bank_code)) {
            $error_message = "All withdrawal details are required. Please verify your account number and select a bank.";
        } elseif (!is_numeric($account_number) || strlen($account_number) !== 10) {
            $error_message = "Invalid account number format. It should be 10 digits.";
        } else {
            $stmt = $conn->prepare("UPDATE users SET withdrawal_account_number = ?, withdrawal_account_name = ?, withdrawal_bank_name = ?, withdrawal_bank_code = ?, withdrawal_method_last_updated = NOW() WHERE id = ?");
            $stmt->bind_param("ssssi", $account_number, $account_name, $bank_name, $bank_code, $user_id);
            
            if ($stmt->execute()) {
                $success_message = "Withdrawal method saved successfully!";
                $user['withdrawal_account_number'] = $account_number;
                $user['withdrawal_account_name'] = $account_name;
                $user['withdrawal_bank_name'] = $bank_name;
                $user['withdrawal_bank_code'] = $bank_code;
                $user['withdrawal_method_last_updated'] = date('Y-m-d H:i:s');
                $can_update_withdrawal = canUpdateField($user['withdrawal_method_last_updated'], 7);
            } else {
                $error_message = "Failed to save withdrawal method.";
            }
            $stmt->close();
        }
    }
}

// Handle Account Deletion
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_account'])) {
    $password = $_POST['password'];
    
    // Ensure $user['password'] is set and is a valid hash
    if (isset($user['password']) && password_verify($password, $user['password'])) {
        // Delete user
        $stmt = $conn->prepare("DELETE FROM users WHERE id = ?");
        $stmt->bind_param("i", $user_id);
        if ($stmt->execute()) {
            // Clean up associated data if necessary (e.g., balances, etc.)
            // ...

            // Destroy session and redirect to login
            session_destroy();
            header('Location: login.php?message=account_deleted');
            exit();
        } else {
            $error_message = "Failed to delete account.";
        }
        $stmt->close();
    } else {
        $error_message = "Incorrect password.";
    }
}

// Handle Gender Update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_gender'])) {
    $gender = $_POST['gender'] ?? null;
    
    // Check if gender is already set
    if (!empty($user['gender'])) {
        $error_message = "Gender is a permanent setting and cannot be changed once set.";
    } elseif (!in_array($gender, ['male', 'female'])) {
        $error_message = "Invalid gender selection";
    } else {
        $stmt = $conn->prepare("UPDATE users SET gender = ? WHERE id = ?");
        $stmt->bind_param("si", $gender, $user_id);
        
        if ($stmt->execute()) {
            $success_message = "Gender set successfully!";
            $user['gender'] = $gender;
            $can_update_gender = ['can_update' => false, 'message' => 'Gender is a permanent setting and cannot be changed once set'];
        } else {
            $error_message = "Failed to set gender";
        }
        $stmt->close();
    }
}


// Get connected socials count
$connected_socials = 0;
if (!empty($user['instagram_link'])) $connected_socials++;
if (!empty($user['twitter_link'])) $connected_socials++;
if (!empty($user['discord_link'])) $connected_socials++;

// Default avatar if none set
$avatar_url = !empty($user['profile_picture']) ? $user['profile_picture'] : 'profile-picture.jpg';

// Get current theme
$current_theme = $_SESSION['theme'] ?? 'dark';
$is_dark_mode = $current_theme === 'dark';
?>
<?php include "doctype.php"; ?>
  <style>

     :root {
      --page-blue-900: #030922;
      --page-blue-700: #0a164a;
      --page-blue-500: #142a7e;
      --page-blue-300: #2c5bf5;
      --page-mint: #4de1c1;
      --page-white: #f5f9ff;
      --panel-glass: rgba(13, 24, 62, 0.84);
      --panel-border: rgba(86, 139, 241, 0.3);
      --shadow-heavy: 0 40px 120px rgba(4, 10, 36, 0.65);
      --transition-short: 0.4s ease;
      
      /* Added indigo/blue-purple color scheme for profile aside */
      --profile-primary: #6366f1;
      --profile-secondary: #a5b4fc;
      --profile-dark: #0f0a1a;
      --profile-glass: rgba(99, 102, 241, 0.15);
    }

    /* Light mode theme variables */
    html.light {
      --page-blue-900: #ffffff;
      --page-blue-700: #f8f9fa;
      --page-blue-500: #495057;
      --page-blue-300: #2c5bf5;
      --page-mint: #20c997;
      --page-white: #212529;
      --panel-glass: rgba(255, 255, 255, 0.95);
      --panel-border: rgba(206, 212, 218, 0.5);
      --shadow-heavy: 0 10px 40px rgba(0, 0, 0, 0.1);
    }

    * { box-sizing: border-box; }

    body {
      margin: 0;
      font-family: "Titillium Web", "Segoe UI", sans-serif;
      background: #030922;
      overflow-x: hidden;
      transition: background 0.3s ease, color 0.3s ease;
    }

    /* Light mode body background */
    html.light body {
      background: linear-gradient(180deg, #ffffff, #f8f9fa);
    }

    .page-shell { min-height: 100vh; display: grid; grid-template-columns: 320px 1fr; }

    @media (max-width: 960px) {
      .page-shell { grid-template-columns: 1fr; }
      aside { position: sticky; top: 0; z-index: 20; border-bottom: 1px solid var(--panel-border); }
    }

    /* Updated aside with indigo/blue-purple profile theme */
    aside {
      
      backdrop-filter: blur(18px);
      padding: 36px 32px;
      display: grid;
      gap: 32px;
      border-right: 2px solid var(--profile-primary);
      position: relative;
      overflow: hidden;
    }

    aside::before {
      content: "";
      position: absolute;
      top: 0;
      right: 0;
      width: 200px;
      height: 200px;
      background: radial-gradient(circle, var(--profile-glass), transparent 70%);
      border-radius: 50%;
      pointer-events: none;
    }

    .back-link {
      display: inline-flex;
      align-items: center;
      gap: 10px;
      font-weight: 600;
      letter-spacing: 0.1em;
      text-transform: uppercase;
      color: var(--profile-secondary);
      transition: color var(--transition-short), transform var(--transition-short);
      position: relative;
      z-index: 2;
      text-decoration: none;
    }

    .back-link:hover { color: var(--profile-primary); transform: translateX(-4px); }

    .page-title {
      font-size: clamp(1.5rem, 4vw, 2rem);
      letter-spacing: 0.1em;
      text-transform: uppercase;
      margin: 0 0 12px;
      color: white;
      position: relative;
      z-index: 2;
    }

    .side-description { 
      color: rgba(200, 210, 255, 0.85); 
      line-height: 1.7; 
      font-size: clamp(0.875rem, 2vw, 1rem);
      position: relative;
      z-index: 2;
    }

    /* Updated vector-cluster with indigo/blue-purple theme */
    .vector-cluster {
      position: relative;
      border-radius: 24px;
      padding: 24px;
      background: linear-gradient(135deg, rgba(99, 102, 241, 0.25), rgba(60, 50, 139, 0.6));
      box-shadow: 0 20px 60px rgba(99, 102, 241, 0.3);
      overflow: hidden;
      border: 1px solid var(--profile-primary);
      z-index: 2;
    }

    .vector-cluster::after {
      content: "";
      position: absolute;
      width: 250px;
      height: 250px;
      top: -120px;
      right: -80px;
      border-radius: 50%;
      background: radial-gradient(circle, rgba(165, 180, 252, 0.4), transparent 60%);
    }

    .vector-cluster img {
      width: 100%;
      border-radius: 18px;
      display: block;
      filter: drop-shadow(0 20px 50px rgba(99, 102, 241, 0.4));
      position: relative;
      z-index: 2;
    }

    main { padding: 42px 48px; display: grid; gap: 42px; }

    .profile-hero {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
      gap: 28px;
      align-items: center;
      background: var(--panel-glass);
      border-radius: 26px;
      border: 1px solid var(--panel-border);
      padding: 38px;
      box-shadow: var(--shadow-heavy);
      position: relative;
      overflow: hidden;
    }

    .profile-hero::before {
      content: "";
      position: absolute;
      inset: 0;
      background: url("front/assets/images/partners-icon2.png") center/contain no-repeat;
      opacity: 0.06;
    }

    .profile-copy { position: relative; z-index: 2; }

    .profile-copy h1 { 
      margin: 0 0 12px; 
      font-size: clamp(1.8rem, 4vw, 2.4rem); 
    }

    .profile-copy p { 
      margin: 0; 
      color: rgba(218, 231, 255, 0.78); 
      line-height: 1.7; 
      font-size: clamp(0.875rem, 2vw, 1rem);
    }

    /* Light mode text colors */
    html.light .profile-copy p {
      color: rgba(73, 80, 87, 0.8);
    }

    .profile-photo { position: relative; z-index: 2; text-align: center; }

    .profile-photo img {
      width: clamp(100px, 18vw, 100px);
      border-radius: 50%;
      border: 6px solid rgba(77, 225, 193, 0.28);
      box-shadow: var(--shadow-heavy);
    }

    .settings-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));
      gap: 22px;
    }

    .settings-card {
      padding: 24px;
      border-radius: 20px;
      background: rgba(6, 16, 48, 0.9);
      border: 1px solid rgba(100, 154, 255, 0.24);
      box-shadow: var(--shadow-heavy);
      position: relative;
      overflow: hidden;
    }

    /* Light mode settings card */
    html.light .settings-card {
      background: rgba(255, 255, 255, 0.95);
      border: 1px solid rgba(206, 212, 218, 0.5);
    }

    .settings-card::after {
      content: "";
      position: absolute;
      width: 100px;
      height: 100px;
      top: -20px;
      right: -14px;
      border-radius: 50%;
      background: radial-gradient(circle, rgba(77, 225, 193, 0.28), transparent 60%);
    }

    .settings-card h3 { 
      margin: 0 0 12px; 
      letter-spacing: 0.05em; 
      font-size: clamp(1rem, 2vw, 1.1rem);
    }

    .settings-card p { 
      color: rgba(205, 219, 255, 0.7); 
      margin-bottom: 18px; 
      line-height: 1.68; 
      font-size: clamp(0.875rem, 2vw, 0.95rem);
    }

    /* Light mode settings card text */
    html.light .settings-card p {
      color: rgba(73, 80, 87, 0.7);
    }

    .btn-cta {
      border: none;
      border-radius: 16px;
      padding: 12px 18px;
      font-weight: 600;
      letter-spacing: 0.04em;
      text-transform: uppercase;
      cursor: pointer;
     background: rgba(86,139,241,1);
      color: var(--page-white);
      border: 1px solid rgba(115, 166, 255, 0.4);
      transition: transform var(--transition-short);
      font-size: clamp(0.8rem, 2vw, 0.9rem);
    }

    .btn-cta:hover { transform: translateY(-4px); }

    /* Added new action buttons for logout, delete, theme */
    .btn-logout {
      background: linear-gradient(135deg, #fbbf24, #f59e0b);
      color: #030922;
      border: none;
    }

    .btn-delete {
      background: linear-gradient(135deg, #ef4444, #dc2626);
      color: white;
      border: none;
    }

    .btn-theme {
      background: linear-gradient(135deg, #8b5cf6, #7c3aed);
      color: white;
      border: none;
    }

    .credential-panel {
      background: rgba(9, 23, 66, 0.9);
      border: 1px solid var(--panel-border);
      border-radius: 24px;
      padding: 28px;
      box-shadow: var(--shadow-heavy);
      display: grid;
      gap: 18px;
    }

    /* Light mode credential panel */
    html.light .credential-panel {
      background: rgba(255, 255, 255, 0.95);
    }

    .credential-row {
      display: grid;
      grid-template-columns: 1fr 220px;
      gap: 16px;
      align-items: center;
    }

    @media (max-width: 720px) { .credential-row { grid-template-columns: 1fr; } }

    label { 
      font-size: clamp(0.8rem, 2vw, 0.9rem); 
      letter-spacing: 0.08em; 
      text-transform: uppercase; 
      color: rgba(205, 219, 255, 0.7); 
    }

    /* Light mode label */
    html.light label {
      color: rgba(73, 80, 87, 0.8);
    }

    input { 
      border: 1px solid rgba(99, 149, 255, 0.26); 
      border-radius: 16px; 
      padding: 14px 16px; 
      background: rgba(5, 12, 36, 0.82); 
      color: var(--page-white); 
      font-size: clamp(0.875rem, 2vw, 1rem);
    }

    /* Light mode input */
    html.light input, html.light select {
      background: rgba(255, 255, 255, 0.95);
      border: 1px solid rgba(206, 212, 218, 0.5);
      color: #212529;
    }

    input:focus, select:focus { 
      border-color: var(--page-mint); 
      box-shadow: 0 0 0 3px rgba(77, 225, 193, 0.2); 
      outline: none; 
    }
    
    /* Added Opay-style select dropdown styling */
    select {
      appearance: none;
      background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 12 12'%3E%3Cpath fill='%234de1c1' d='M6 9L1 4h10z'/%3E%3C/svg%3E");
      background-repeat: no-repeat;
      background-position: right 16px center;
      padding-right: 40px;
    }
    
    select option {
      background: var(--page-blue-700);
      color: var(--page-white);
      padding: 12px;
    }
    
    html.light select option {
      background: white;
      color: #212529;
    }

    .security-bar {
      height: 14px;
      border-radius: 999px;
      background: rgba(23, 44, 120, 0.6);
      overflow: hidden;
    }

    .security-fill {
      height: 100%;
      width: 82%;
      background: linear-gradient(135deg, rgba(47, 91, 234, 0.95), rgba(77, 225, 193, 0.85));
      border-radius: 999px;
      box-shadow: 0 10px 25px rgba(56, 104, 228, 0.45);
    }

    .ticker {
      border-radius: 24px;
      border: 1px solid rgba(77, 225, 193, 0.32);
      background: rgba(8, 18, 52, 0.78);
      padding: 16px;
      box-shadow: var(--shadow-heavy);
      overflow: hidden;
    }

    .ticker-track {
      display: inline-flex;
      gap: 42px;
      animation: tickerMove 30s linear infinite;
      letter-spacing: 0.16em;
      text-transform: uppercase;
      color: rgba(204, 228, 255, 0.82);
      font-weight: 600;
      white-space: nowrap;
      font-size: clamp(0.75rem, 2vw, 0.9rem);
    }

    @keyframes tickerMove { from { transform: translateX(0); } to { transform: translateX(-50%); } }

    footer {
      padding: 48px 0 36px;
      background: linear-gradient(180deg, rgba(1, 5, 16, 0.95), rgba(1, 4, 12, 0.98));
      border-top: 1px solid rgba(86, 136, 230, 0.2);
    }

    .footer-grid {
      max-width: 1020px;
      margin: 0 auto;
      padding: 0 32px;
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(160px, 1fr));
      gap: 24px;
    }

    .footer-list h4 { 
      text-transform: uppercase; 
      letter-spacing: 0.12em; 
      font-size: clamp(0.75rem, 2vw, 0.82rem); 
      margin-bottom: 16px; 
      color: rgba(181, 201, 240, 0.76); 
    }

    .footer-list ul { 
      list-style: none; 
      padding: 0; 
      margin: 0; 
      display: grid; 
      gap: 12px; 
    }

    .footer-list a { 
      color: rgba(210, 224, 253, 0.7); 
      font-size: clamp(0.8rem, 2vw, 0.9rem); 
      transition: color var(--transition-short); 
    }

    .footer-list a:hover { color: var(--page-mint); }

    .footer-brand { 
      text-align: center; 
      text-transform: uppercase; 
      letter-spacing: 0.14em; 
      color: rgba(160, 180, 226, 0.68); 
      margin-top: 32px; 
      font-size: clamp(0.7rem, 2vw, 0.76rem); 
    }

    .back-link {
      display: inline-flex;
      align-items: center;
      gap: 10px;
      font-weight: 600;
      font-size: clamp(0.75rem, 1.5vw, 0.875rem);
      letter-spacing: 0.1em;
      text-transform: uppercase;
      color: rgba(210, 226, 255, 0.78);
      transition: color var(--transition-short), transform var(--transition-short);
      text-decoration: none;
    }

    .back-link:hover { color: var(--page-white); transform: translateX(-4px); }

    .page-title {
      font-size: clamp(1rem, 3vw, 1.5rem);
      letter-spacing: 0.1em;
      text-transform: uppercase;
      margin: 0 0 clamp(0.5rem, 1vw, 0.75rem);
      font-weight: 700;
    }

    .side-description { 
      color: rgba(206, 224, 255, 0.74); 
      line-height: 1.7; 
      font-size: clamp(0.875rem, 1.5vw, 1rem);
    }

    .vector-cluster {
      position: relative;
      border-radius: 24px;
      padding: clamp(1rem, 2vw, 1.5rem);
      background: 
        linear-gradient(135deg, rgba(251, 191, 36, 0.3), rgba(217, 119, 6, 0.6)),
        rgba(12, 29, 82, 0.9);
      box-shadow: var(--shadow-heavy);
      overflow: hidden;
    }

    .vector-cluster::after {
      content: "";
      position: absolute;
      width: 320px;
      height: 320px;
      top: -150px;
      right: -120px;
      border-radius: 50%;
      background: radial-gradient(circle, rgba(245, 158, 11, 0.35), transparent 60%);
    }

    .vector-cluster img {
      width: 100%;
      border-radius: 18px;
      display: block;
      filter: drop-shadow(0 28px 80px rgba(251, 191, 36, 0.4));
    }

    .aside-welcome {
      display: grid;
      grid-template-columns: auto 1fr;
      align-items: center;
      gap: clamp(0.75rem, 1.5vw, 1rem);
      background: rgba(8, 21, 64, 0.92);
      border: 1px solid rgba(120, 170, 255, 0.25);
      border-radius: 20px;
      padding: clamp(0.875rem, 1.75vw, 1.125rem);
      box-shadow: 0 18px 48px rgba(3, 9, 30, 0.5);
      position: relative;
      z-index: 2;
    }

    .aside-avatar {
      width: clamp(48px, 10vw, 64px);
      height: clamp(48px, 10vw, 64px);
      border-radius: 50%;
      overflow: hidden;
      border: 4px solid rgba(251, 191, 36, 0.35);
      box-shadow: 0 14px 34px rgba(3, 9, 30, 0.55);
    }

    .aside-avatar img {
      width: 100%;
      display: block;
    }

    .welcome-tag {
      margin: 0;
      font-size: clamp(0.6875rem, 1.25vw, 0.75rem);
      letter-spacing: 0.12em;
      text-transform: uppercase;
      color: rgba(205, 219, 255, 0.62);
    }

    .aside-welcome h3 {
      margin: clamp(0.25rem, 0.5vw, 0.375rem) 0 clamp(0.125rem, 0.25vw, 0.25rem);
      font-size: clamp(1rem, 2vw, 1.12rem);
      letter-spacing: 0.04em;
      color: var(--page-white);
      font-weight: 700;
    }

    .welcome-meta {
      font-size: clamp(0.75rem, 1.5vw, 0.8rem);
      letter-spacing: 0.08em;
      color: rgba(149, 183, 255, 0.7);
    }


    .section-white {
      background: rgba(245, 249, 255, 0.96);
      border: 1px solid rgba(60, 102, 212, 0.14);
      border-radius: 26px;
      box-shadow: var(--shadow-heavy);
      padding: 36px;
      color: var(--page-blue-700);
      position: relative;
      overflow: hidden;
    }

    .section-white::before {
      content: "";
      position: absolute;
      inset: 0;
      background: radial-gradient(circle at 78% 18%, rgba(44, 92, 240, 0.14), transparent 60%);
    }

    .section-white h2 {
      margin-top: 0;
      color: var(--page-blue-500);
      font-size: clamp(1.2rem, 3vw, 1.5rem);
    }

    .section-white p {
      color: rgba(20, 42, 126, 0.68);
      line-height: 1.7;
      font-size: clamp(0.875rem, 2vw, 1rem);
    }

    .profile-chip-row {
      position: relative;
      z-index: 2;
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
      gap: 18px;
      margin-top: 24px;
    }

    .profile-chip {
      padding: 18px;
      border-radius: 18px;
      background: rgba(44, 92, 240, 0.08);
      border: 1px solid rgba(44, 92, 240, 0.18);
      color: var(--page-blue-500);
      font-weight: 600;
      letter-spacing: 0.02em;
      display: grid;
      gap: 6px;
    }

    .profile-chip span {
      font-size: clamp(0.7rem, 2vw, 0.75rem);
      letter-spacing: 0.1em;
      text-transform: uppercase;
      color: rgba(20, 42, 126, 0.6);
    }

   
    /* Updated mobile footer with 5 icons */
    .mobile-fintech-footer {
      display: none;
      position: fixed;
      left: 12px;
      right: 12px;
      bottom: 16px;
      padding: 10px;
      background: transparent;
      border: 1px solid rgba(86, 139, 241, 0.35);
      border-radius: 32px;
      backdrop-filter: blur(50px);
      box-shadow: 0 20px 60px rgba(4, 10, 36, 0.7);
      justify-content: space-around;
      align-items: center;
      z-index: 90;
    }

    .mobile-fintech-footer a {
      flex: 1;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      gap: 4px;
      text-decoration: none;
      color: rgba(205, 219, 255, 0.75);
      font-size: 0.45rem;
      letter-spacing: 0.06em;
      text-transform: uppercase;
      transition: all var(--transition-short);
      padding: 8px 4px;
      border-radius: 16px;
    }
    .mobile-fintech-footer a.active { color: var(--page-mint); }

    .mobile-fintech-footer svg { 
      width: 24px; 
      height: 24px; 
      fill: currentColor; 
      filter: drop-shadow(0 12px 30px rgba(4, 10, 36, 0.45)); 
    }

    .mobile-fintech-footer a:hover { transform: translateY(-4px); }

    @media (max-width: 680px) {
      body { padding-bottom: 160px; }
      aside { padding: 28px 20px; }
      main { padding: 32px 10px 160px; }
      .profile-hero,
      .settings-grid,
      .credential-panel,
      .ticker,
      .section-white { margin-left: 0; margin-right: 0; }
      .settings-card { margin: 0; }
      .mobile-fintech-footer { display: flex; }
    }

    /* Modal styles for confirmations */
    .modal-overlay {
      display: none;
      position: fixed;
      inset: 0;
      background: rgba(0, 0, 0, 0.8);
      z-index: 1000;
      align-items: center;
      justify-content: center;
    }

    .modal-overlay.show {
      display: flex;
    }

    .modal-content {
      background: var(--page-blue-700);
      border-radius: 24px;
      padding: 32px;
      max-width: 500px;
      width: 90%;
      border: 1px solid var(--panel-border);
      box-shadow: var(--shadow-heavy);
    }

    html.light .modal-content {
      background: white;
    }

    .modal-content h2 {
      margin-top: 0;
      color: var(--page-white);
    }

    html.light .modal-content h2 {
      color: #212529;
    }

    .modal-buttons {
      display: flex;
      gap: 12px;
      margin-top: 24px;
    }

     /* Common toast styles */
.toast-message {
  position: fixed;
  top: 20px;
  right: -400px; /* start hidden off-screen */
  padding: 16px 24px;
  border-radius: 12px;
  color: white;
  font-family: 'Segoe UI', sans-serif;
  font-size: 15px;
  z-index: 1000;
  opacity: 0;
  box-shadow: 0 10px 40px rgba(0, 0, 0, 0.2);
  transition: right 0.6s ease, opacity 0.6s ease;
}

/* Success styling */
.toast-message.success {
  background: rgba(77, 225, 193, 0.95);
  color: #030922;
  box-shadow: 0 10px 40px rgba(77, 225, 193, 0.4);
}

/* Error styling */
.toast-message.error {
  background: rgba(255, 77, 77, 0.95);
  color: #fff;
  box-shadow: 0 10px 40px rgba(255, 77, 77, 0.4);
}

/* When visible */
.toast-message.show {
  right: 20px;
  opacity: 1;
}

/* Withdrawal payment method section */
.withdrawal-method-card {
  background: linear-gradient(135deg, rgba(139, 92, 246, 0.1), rgba(124, 58, 237, 0.05));
  border: 1px solid rgba(139, 92, 246, 0.3);
  border-radius: 20px;
  padding: 24px;
  margin-top: 24px;
}

html.light .withdrawal-method-card {
  background: linear-gradient(135deg, rgba(139, 92, 246, 0.05), rgba(124, 58, 237, 0.02));
}

.bank-list {
  display: grid;
  gap: 12px;
  margin-top: 16px;
}

.bank-item {
    background:linear-gradient(135deg, rgba(44,91,245,0.35), rgba(77,225,193,0.12));
        border:1px solid rgba(77,225,193,0.25);
       
        backdrop-filter: blur(12px);
  /*border: 1px solid rgba(99, 102, 241, 0.2);*/
  border-radius: 12px;
  padding: 12px 16px;
  display: flex;
  justify-content: space-between;
  align-items: center;
}

  </style>
<body>
  <?php include "embed.php"; ?>
 <?php if ($success_message): ?>
  <div id="toast-success" class="toast-message success">
    <?php echo htmlspecialchars($success_message); ?>
  </div>
<?php endif; ?>

<?php if ($error_message): ?>
  <div id="toast-error" class="toast-message error">
    <?php echo htmlspecialchars($error_message); ?>
  </div>
<?php endif; ?>

  <div class="page-shell">
    <aside>
      <a class="back-link" href="dashboard.php">← Back</a>
      
      <div>
        <h2 class="page-title">Profile</h2>
        <p class="side-description">Configure your identity, manage secure credentials, and amplify your Earnova presence.</p>
      </div>
     </aside>
    <main>
      <section class="profile-hero" style="border-color: rgba(251, 191, 36, 0.4);
      background: linear-gradient(135deg, rgba(251, 191, 36, 0.08), rgba(13, 24, 62, 0.78));">
        <div class="profile-copy">
          <h1 style="font-size: 20px; color: white;">Craft Your Signature.</h1>
          <p>Update your presence, and align security to keep your flows unstoppable.</p>
          <!-- Display user's full name and details -->
          <div style="margin-top: 20px; padding: 16px; background: rgba(77, 225, 193, 0.1); border-radius: 12px; border: 1px solid rgba(77, 225, 193, 0.2);">
            <p style="margin: 0 0 8px; font-size: 0.85rem; opacity: 0.7;">Full Name</p>
            <p style="margin: 0; font-size: 1.1rem; font-weight: 600;"><?php echo htmlspecialchars($user['full_name'] ?? 'Not set'); ?></p>
            <p style="margin: 12px 0 4px; font-size: 0.85rem; opacity: 0.7;">Email</p>
            <p style="margin: 0; font-size: 0.95rem;"><?php echo htmlspecialchars($user['email']); ?></p>
            <p style="margin: 12px 0 4px; font-size: 0.85rem; opacity: 0.7;">Username</p>
            <p style="margin: 0; font-size: 0.95rem;">@<?php echo htmlspecialchars($user['username']); ?></p>
          </div>
        </div>
        <div class="profile-photo">
          <!-- Display user's actual avatar -->
          <img src="<?php echo htmlspecialchars($avatar_url); ?>" alt="Profile avatar" />
        </div>
      </section>

      <section class="settings-grid">
        <!-- <article class="settings-card">
          <h3>Identity Sync</h3>
          <p>Update your display name, location, and pronouns to keep the community aligned.</p>
        Show restriction message if cannot update 
          <?php //if (!$can_update_full_name['can_update'] || !$can_update_phone['can_update'] || !$can_update_username['can_update']): ?>
            <p style="color: #fbbf24; font-size: 0.85rem; margin-top: 12px;">
               <?php //echo !$can_update_full_name['can_update'] ? $can_update_full_name['message'] : (!$can_update_phone['can_update'] ? $can_update_phone['message'] : $can_update_username['message']); ?>
            </p>
            <button class="btn-cta" style="opacity: 0.5; cursor: not-allowed;" disabled>Edit Identity</button>
          <?php //else: ?>
            <button class="btn-cta" onclick="document.getElementById('identityModal').style.display='flex'">Edit Identity</button>
          <?php //endif; ?>
        </article> -->
        
        <!-- Added Gender Settings card as separate card -->
        <article class="settings-card" style="background: linear-gradient(135deg, rgba(77, 225, 193, 0.08), rgba(13, 24, 62, 0.78));">
          <h3 style="color: white;">Gender</h3>
          <p>Set your gender. This is a permanent decision and cannot be changed once set.</p>
          <?php if (!empty($user['gender'])): ?>
            <p style="color: var(--page-mint); font-size: 0.9rem; margin-top: 12px;">
              ✓ Gender set to: <strong><?php echo ucfirst($user['gender']); ?></strong> (Permanent)
            </p>
            <button class="btn-cta" style="opacity: 0.5; cursor: not-allowed;" disabled style="">Already Set</button>
          <?php else: ?>
            <button class="btn-cta" onclick="document.getElementById('genderModal').style.display='flex'">Set Gender</button>
          <?php endif; ?>
        </article>
        
        <article class="settings-card" style="background: linear-gradient(135deg, rgba(77, 225, 193, 0.08), rgba(13, 24, 62, 0.78));">
          <h3 style="color: #fff;">Profile</h3>
          <p>Upload a new Profile Picture.</p>
          <!-- Show restriction message if cannot update -->
          <?php if (!$can_update_profile_picture['can_update']): ?>
            <p style="color: #fbbf24; font-size: 0.85rem; margin-top: 12px;">
               <?php echo $can_update_profile_picture['message']; ?>
            </p>
            <button class="btn-cta" style="opacity: 0.5; cursor: not-allowed;" disabled>Upload</button>
          <?php else: ?>
            <button class="btn-cta" onclick="document.getElementById('avatarModal').style.display='flex'">Upload</button>
          <?php endif; ?>
        </article>
        <!-- <article class="settings-card">
          <h3>Social Links</h3>
          <p>Connect Instagram, X, and custom portals for faster referrals and collabs.</p>
           Added modal trigger for social links 
          <button class="btn-cta" onclick="document.getElementById('socialModal').style.display='flex'">Connect</button>
        </article> -->
        <!-- Added Withdrawal Payment Method card -->
        <article class="settings-card" style="background: linear-gradient(135deg, rgba(77, 225, 193, 0.08), rgba(13, 24, 62, 0.78));">
          <h3 style="color: #fff;">Withdrawal Method</h3>
          <p>Set up your bank account for withdrawals. Account name will be verified via Paystack.</p>
          <!-- Show restriction message if cannot update -->
          <?php if (!$can_update_withdrawal['can_update']): ?>
            <p style="color: #fbbf24; font-size: 0.85rem; margin-top: 12px;">
               <?php echo $can_update_withdrawal['message']; ?>
            </p>
            <button class="btn-cta" style="opacity: 0.5; cursor: not-allowed;" disabled>Setup Payment</button>
          <?php else: ?>
            <button class="btn-cta" onclick="openWithdrawalModal()">Setup Payment</button>
          <?php endif; ?>
        </article>
        
        
        
            <!-- Display saved withdrawal method if exists -->
      <?php if (!empty($user['withdrawal_account_number'])): ?>
      <section class="withdrawal-method-card">
        <h3 style="margin-top: 0; display: flex; align-items: center; gap: 8px; color: white;">
          <svg viewBox="0 0 24 24" width="20" height="20" fill="currentColor">
            <path d="M20 4H4c-1.11 0-1.99.89-1.99 2L2 18c0 1.11.89 2 2 2h16c1.11 0 2-.89 2-2V6c0-1.11-.89-2-2-2zm0 14H4v-6h16v6zm0-10H4V6h16v2z"/>
          </svg>
          Saved Withdrawal Method
        </h3>
        <div class="bank-list">
          <div class="bank-item">
            <div>
              <p style="margin: 0; font-size: 0.85rem; opacity: 0.7;  color: #fff;">Account Name</p>
              <p style="margin: 4px 0 0; font-weight: 600; color: var(--page-mint);"><?php echo htmlspecialchars($user['withdrawal_account_name']); ?></p>
            </div>
          </div>
          <div class="bank-item">
            <div>
              <p style="margin: 0; font-size: 0.85rem; opacity: 0.7;  color: #fff;">Account Number</p>
              <p style="margin: 4px 0 0; font-weight: 600; color: var(--page-mint);"><?php echo htmlspecialchars($user['withdrawal_account_number']); ?></p>
            </div>
          </div>
          <div class="bank-item">
            <div>
              <p style="margin: 0; font-size: 0.85rem; opacity: 0.7;  color: #fff;">Bank</p>
              <p style="margin: 4px 0 0; font-weight: 600; color: var(--page-mint);"><?php echo htmlspecialchars($user['withdrawal_bank_name']); ?></p>
            </div>
            <!-- Disable update button if cannot update -->
            <?php if (!$can_update_withdrawal['can_update']): ?>
              <button class="btn-cta" style="padding: 8px 16px; font-size: 0.75rem; opacity: 0.5; cursor: not-allowed;" disabled>Update</button>
            <?php else: ?>
              <button class="btn-cta" style="padding: 8px 16px; font-size: 0.75rem;" onclick="openWithdrawalModal()">Update</button>
            <?php endif; ?>
          </div>
        </div>
      </section>
      <?php endif; ?>
        
        
       
        <article class="settings-card" style="background: linear-gradient(135deg, rgba(77, 225, 193, 0.08), rgba(13, 24, 62, 0.78));">
          <h3 style="color: #fff;">Echo Chat Settings</h3>
          <p>Enable Echo Chat to connect with new people daily. Set your WhatsApp number and preferences.</p>
          <button class="btn-cta" onclick="document.getElementById('chatEarnModal').style.display='flex'">Configure</button>
        </article>
        <!-- Added Logout card -->
        <article class="settings-card" style="background: linear-gradient(135deg, rgba(77, 225, 193, 0.08), rgba(13, 24, 62, 0.78));">
          <h3 style="color: #fff;">Logout</h3>
          <p>Sign out of your account securely.</p>
          <button class="btn-cta btn-logout" onclick="document.getElementById('logoutModal').style.display='flex'">Logout</button>
        </article>
        <!-- Added Delete Account card -->
        <article class="settings-card" style="background: linear-gradient(135deg, rgba(77, 225, 193, 0.08), rgba(13, 24, 62, 0.78));">
          <h3 style="color: #fff;">Delete Account</h3>
          <p>Permanently delete your account and all associated data.</p>
          <button class="btn-cta btn-delete" onclick="document.getElementById('deleteModal').style.display='flex'">Delete Account</button>
        </article>
        <!-- Added Theme Toggle card -->
        <!-- <article class="settings-card">
          <h3>Theme Mode</h3>
          <p>Switch between dark and light mode. Current: <?php //echo $is_dark_mode ? 'Dark' : 'Light'; ?> Mode</p>
          <button class="btn-cta btn-theme" onclick="toggleTheme()">
            <?php //echo $is_dark_mode ? 'Switch to Light' : 'Switch to Dark'; ?>
          </button>
        </article> -->
      </section>

  

      <!--<section class="credential-panel">-->
        <!-- Added form for email update -->
      <!--  <form method="POST" action="">-->
      <!--    <div class="credential-row">-->
      <!--      <div>-->
      <!--        <label for="email">Email</label>-->
      <!--        <input id="email" name="email" type="email" value="<?php echo htmlspecialchars($user['email']); ?>" />-->
      <!--      </div>-->
      <!--      <button type="submit" name="update_email" class="btn-cta">Update Email</button>-->
      <!--    </div>-->
      <!--  </form>-->
        
        <!-- Display user's actual phone -->
      <!--  <div class="credential-row">-->
      <!--    <div>-->
      <!--      <label for="phone">Phone</label>-->
      <!--      <input id="phone" type="tel" value="<?php echo htmlspecialchars($user['phone'] ?? ''); ?>" readonly />-->
      <!--    </div>-->
          <!-- Disable update button if cannot update -->
      <!--    <?php if (!$can_update_phone['can_update']): ?>-->
      <!--      <button class="btn-cta" style="opacity: 0.5; cursor: not-allowed;" disabled>Update</button>-->
      <!--    <?php else: ?>-->
      <!--      <button class="btn-cta" onclick="document.getElementById('identityModal').style.display='flex'">Update</button>-->
      <!--    <?php endif; ?>-->
      <!--  </div>-->
        
        <!-- Handle username update -->
      <!--  <div class="credential-row">-->
      <!--    <div>-->
      <!--      <label for="username">Username</label>-->
      <!--      <input id="username" name="username" type="text" value="<?php echo htmlspecialchars($user['username']); ?>" readonly />-->
      <!--    </div>-->
          <!-- Disable update button if cannot update -->
      <!--    <?php if (!$can_update_username['can_update']): ?>-->
      <!--      <p style="color: #fbbf24; font-size: 0.85rem; margin-top: 12px;">-->
      <!--         <?php echo $can_update_username['message']; ?>-->
      <!--      </p>-->
      <!--      <button class="btn-cta" style="opacity: 0.5; cursor: not-allowed;" disabled>Update</button>-->
      <!--    <?php else: ?>-->
      <!--      <button class="btn-cta" onclick="document.getElementById('usernameModal').style.display='flex'">Update</button>-->
      <!--    <?php endif; ?>-->
      <!--  </div>-->

      <!--  <div>-->
      <!--    <span style="letter-spacing: 0.08em; text-transform: uppercase; color: rgba(205, 219, 255, 0.7);">Security Strength</span>-->
      <!--    <div class="security-bar">-->
            <!-- Dynamic security strength based on profile completion -->
      <!--      <div class="security-fill" style="width: <?php echo $profile_completion; ?>%;"></div>-->
      <!--    </div>-->
      <!--  </div>-->
      <!--</section>-->

      <section class="ticker">
        <div class="ticker-track">
          PROFILE UPDATE — Avatar synced • 1 MIN AGO ✦ SECURITY UPDATE — 2FA rotated • 4 MIN AGO ✦ SOCIAL LINK — Discord connected • 8 MIN AGO ✦ EMAIL UPDATE — Verified • 12 MIN AGO ✦
        </div>
      </section>

      <!-- <section class="section-white">
        <h2>Account Vitals</h2>
        <p>Keep every layer of your identity electrified. Review the vital stats and patch anything that slows your brutal glow.</p>
        <div class="profile-chip-row">
           Display actual connected socials count 
          <div class="profile-chip"><span>Connections</span><?php //echo $connected_socials; ?> socials linked</div>
          <div class="profile-chip"><span>Security</span><?php //echo $user['email_verified'] ? 'Email verified' : 'Email pending'; ?></div>
          <div class="profile-chip"><span>Membership</span><?php //echo ucfirst($user['membership_type']); ?> member</div>
        </div>
      </section> -->
    </main>
  </div>

  <!-- Added Withdrawal Method Modal -->
  <div id="withdrawalMethodModal" class="modal-overlay">
    <div class="modal-content">
      <h2 style="margin-top: 0;">Setup Withdrawal Method</h2>
      <!-- Show restriction warning in modal -->
      <?php if (!$can_update_withdrawal['can_update']): ?>
        <div style="padding: 16px; background: rgba(251, 191, 36, 0.1); border-radius: 12px; border: 1px solid rgba(251, 191, 36, 0.3); margin-bottom: 20px;">
          <p style="margin: 0; color: #fbbf24; font-size: 0.9rem;">
             <?php echo $can_update_withdrawal['message']; ?>
          </p>
        </div>
      <?php endif; ?>
      <form method="POST" action="" id="withdrawalForm">
        <input type="hidden" name="save_withdrawal_method" value="1">
        <input type="hidden" name="account_name" id="hidden_account_name" value="">
        <input type="hidden" name="bank_name" id="hidden_bank_name" value="">
        <input type="hidden" name="bank_code" id="hidden_bank_code" value="">
        <div style="margin-bottom: 20px;">
          <label for="account_number" style="display: block; margin-bottom: 8px;">Account Number</label>
          <!-- Disable input if cannot update -->
          <input id="account_number" name="account_number" type="text" placeholder="Enter 10-digit account number" maxlength="10" style="width: 100%;" <?php echo !$can_update_withdrawal['can_update'] ? 'readonly' : ''; ?> />
          <div id="verification_loading" style="display: none; margin-top: 8px; color: var(--page-mint); font-size: 0.85rem;">
            <span>Verifying account...</span>
          </div>
        </div>
        <!-- Bank selection is now handled dynamically -->
        <div style="margin-bottom: 20px;">
          <label for="bank_code_select" style="display: block; margin-bottom: 8px;">Select Bank</label>
          <!-- Disable select if cannot update -->
          <select id="bank_code_select" name="bank_code_select" style="width: 100%; padding: 14px 16px; border-radius: 16px; background: rgba(5, 12, 36, 0.82); color: var(--page-white); border: 1px solid rgba(99, 149, 255, 0.26); font-size: 1rem; cursor: pointer;" <?php echo !$can_update_withdrawal['can_update'] ? 'disabled' : ''; ?>>
            <option value="">Loading banks...</option>
          </select>
        </div>
      <div id="account_name_display" style="display: none; margin-bottom: 20px; padding: 16px; background: rgba(77, 225, 193, 0.1); border-radius: 12px; border: 1px solid rgba(77, 225, 193, 0.2);">
        <p style="margin: 0 0 8px; font-size: 0.85rem; opacity: 0.7; color: white;">✓ Verified Account Name</p>
        <p id="verified_account_name" style="margin: 0; font-size: 1.1rem; font-weight: 600; color: var(--page-mint);"></p>
      </div>
      <div id="multiple_banks_display" style="display: none; margin-bottom: 20px;">
        <p style="margin: 0 0 12px; font-size: 0.9rem; color: var(--page-mint);">✓ This account is linked to multiple banks. Select one:</p>
        <div id="banks_list" style="display: grid; gap: 8px;"></div>
      </div>
      <div class="modal-buttons">
        <!-- Disable submit button if cannot update -->
        <?php if (!$can_update_withdrawal['can_update']): ?>
          <button type="button" class="btn-cta" style="flex: 1; opacity: 0.5; cursor: not-allowed;" disabled>Save Method</button>
        <?php else: ?>
          <button type="button" class="btn-cta" style="flex: 1;" onclick="saveWithdrawalMethod()">Save Method</button>
        <?php endif; ?>
        <button type="button" class="btn-cta" onclick="closeWithdrawalModal()" style="flex: 1; background: rgba(255,77,77,0.7);">Cancel</button>
      </div>
      </form>
    </div>
  </div>

  <!-- Added Logout Modal -->
  <div id="logoutModal" class="modal-overlay">
    <div class="modal-content">
      <h2 style="margin-top: 0;">Confirm Logout</h2>
      <p>Are you sure you want to logout?</p>
      <div class="modal-buttons">
        <button class="btn-cta btn-logout" style="flex: 1;" onclick="window.location.href='logout.php'">Yes, Logout</button>
        <button class="btn-cta" onclick="document.getElementById('logoutModal').style.display='none'" style="flex: 1; background: rgba(255,77,77,0.7);">Cancel</button>
      </div>
    </div>
  </div>

  <!-- Added Delete Account Modal -->
  <div id="deleteModal" class="modal-overlay">
    <div class="modal-content">
      <h2 style="margin-top: 0;">Delete Account</h2>
      <p style="color: #ef4444; font-weight: 600;">Warning: This action cannot be undone!</p>
      <p>Enter your password to confirm account deletion:</p>
      <div style="margin: 20px 0;">
        <input id="delete_password" type="password" placeholder="Enter your password" style="width: 100%;" />
      </div>
      <div class="modal-buttons">
        <button class="btn-cta btn-delete" style="flex: 1;" onclick="deleteAccount()">Delete Account</button>
        <button class="btn-cta" onclick="document.getElementById('deleteModal').style.display='none'" style="flex: 1; background: rgba(255,77,77,0.7);">Cancel</button>
      </div>
    </div>
  </div>

  <!-- Added Identity Update Modal -->
  <div id="identityModal" class="modal-overlay">
    <div class="modal-content">
      <h2 style="margin-top: 0;">Update Identity</h2>
      <!-- Show restriction warning in modal -->
      <?php if (!$can_update_full_name['can_update'] || !$can_update_phone['can_update'] || !$can_update_username['can_update']): ?>
        <div style="padding: 16px; background: rgba(251, 191, 36, 0.1); border-radius: 12px; border: 1px solid rgba(251, 191, 36, 0.3); margin-bottom: 20px;">
          <p style="margin: 0; color: #fbbf24; font-size: 0.9rem;">
             <?php echo !$can_update_full_name['can_update'] ? $can_update_full_name['message'] : (!$can_update_phone['can_update'] ? $can_update_phone['message'] : $can_update_username['message']); ?>
          </p>
        </div>
      <?php endif; ?>
      <form method="POST" action="">
        <div style="margin-bottom: 20px;">
          <label for="full_name" style="display: block; margin-bottom: 8px;">Full Name</label>
          <!-- Disable input if cannot update -->
          <input id="full_name" name="full_name" type="text" value="<?php echo htmlspecialchars($user['full_name']); ?>" required style="width: 100%;" <?php echo !$can_update_full_name['can_update'] ? 'readonly' : ''; ?> />
        </div>
        <div style="margin-bottom: 20px;">
          <label for="username_update" style="display: block; margin-bottom: 8px;">Username</label>
          <!-- Disable input if cannot update -->
          <input id="username_update" name="username" type="text" value="<?php echo htmlspecialchars($user['username']); ?>" required style="width: 100%;" <?php echo !$can_update_username['can_update'] ? 'readonly' : ''; ?> />
          <small style="color: rgba(205, 219, 255, 0.6); font-size: 0.8rem; display: block; margin-top: 4px;">3-20 characters, letters, numbers, and underscores only</small>
        </div>
        <div style="margin-bottom: 20px;">
          <label for="phone_update" style="display: block; margin-bottom: 8px;">Phone</label>
          <!-- Disable input if cannot update -->
          <input id="phone_update" name="phone" type="tel" value="<?php echo htmlspecialchars($user['phone'] ?? ''); ?>" style="width: 100%;" <?php echo !$can_update_phone['can_update'] ? 'readonly' : ''; ?> />
        </div>
        <div style="display: flex; gap: 12px;">
          <!-- Disable submit button if cannot update -->
          <?php if (!$can_update_full_name['can_update'] || !$can_update_phone['can_update'] || !$can_update_username['can_update']): ?>
            <button type="button" class="btn-cta" style="flex: 1; opacity: 0.5; cursor: not-allowed;" disabled>Save Changes</button>
          <?php else: ?>
            <button type="submit" name="update_profile" class="btn-cta" style="flex: 1;">Save Changes</button>
          <?php endif; ?>
          <button type="button" class="btn-cta" onclick="document.getElementById('identityModal').style.display='none'" style="flex: 1; background: rgba(255,77,77,0.7);">Cancel</button>
        </div>
      </form>
    </div>
  </div>

  <!-- Added Avatar Upload Modal -->
  <div id="avatarModal" class="modal-overlay">
    <div class="modal-content">
      <h2 style="margin-top: 0;">Upload Avatar</h2>
      <!-- Show restriction warning in modal -->
      <?php if (!$can_update_profile_picture['can_update']): ?>
        <div style="padding: 16px; background: rgba(251, 191, 36, 0.1); border-radius: 12px; border: 1px solid rgba(251, 191, 36, 0.3); margin-bottom: 20px;">
          <p style="margin: 0; color: #fbbf24; font-size: 0.9rem;">
             <?php echo $can_update_profile_picture['message']; ?>
          </p>
        </div>
      <?php endif; ?>
      <form method="POST" action="" enctype="multipart/form-data">
        <div style="margin-bottom: 20px;">
          <label for="avatar" style="display: block; margin-bottom: 8px;">Choose Image (Max 5MB)</label>
          <!-- Disable input if cannot update -->
          <input id="avatar" name="avatar" type="file" accept="image/jpeg,image/png,image/gif,image/webp" required style="width: 100%;" <?php echo !$can_update_profile_picture['can_update'] ? 'disabled' : ''; ?> />
        </div>
        <div style="display: flex; gap: 12px;">
          <!-- Disable submit button if cannot update -->
          <?php if (!$can_update_profile_picture['can_update']): ?>
            <button type="button" class="btn-cta" style="flex: 1; opacity: 0.5; cursor: not-allowed;" disabled>Upload</button>
          <?php else: ?>
            <button type="submit" class="btn-cta" style="flex: 1;">Upload</button>
          <?php endif; ?>
          <button type="button" class="btn-cta" onclick="document.getElementById('avatarModal').style.display='none'" style="flex: 1; background: rgba(255,77,77,0.7);">Cancel</button>
        </div>
      </form>
    </div>
  </div>

  <!-- Added Social Links Modal -->
  <div id="socialModal" class="modal-overlay">
    <div class="modal-content">
      <h2 style="margin-top: 0;">Connect Social Links</h2>
      <form method="POST" action="">
        <div style="margin-bottom: 20px;">
          <label for="instagram_link" style="display: block; margin-bottom: 8px;">Instagram URL</label>
          <input id="instagram_link" name="instagram_link" type="url" value="<?php echo htmlspecialchars($user['instagram_link'] ?? ''); ?>" placeholder="https://instagram.com/username" style="width: 100%;" />
        </div>
        <div style="margin-bottom: 20px;">
          <label for="twitter_link" style="display: block; margin-bottom: 8px;">Twitter/X URL</label>
          <input id="twitter_link" name="twitter_link" type="url" value="<?php echo htmlspecialchars($user['twitter_link'] ?? ''); ?>" placeholder="https://twitter.com/username" style="width: 100%;" />
        </div>
        <div style="margin-bottom: 20px;">
          <label for="discord_link" style="display: block; margin-bottom: 8px;">Discord URL</label>
          <input id="discord_link" name="discord_link" type="url" value="<?php echo htmlspecialchars($user['discord_link'] ?? ''); ?>" placeholder="https://discord.gg/invite" style="width: 100%;" />
        </div>
        <div style="display: flex; gap: 12px;">
          <button type="submit" name="update_socials" class="btn-cta" style="flex: 1;">Save Links</button>
          <button type="button" class="btn-cta" onclick="document.getElementById('socialModal').style.display='none'" style="flex: 1; background: rgba(255,77,77,0.7);">Cancel</button>
        </div>
      </form>
    </div>
  </div>

  
  <div id="chatEarnModal" class="modal-overlay">
    <div class="modal-content">
      <h2 style="margin-top: 0;">Echo Chat Settings</h2>
      <form method="POST" action="">
        <div style="margin-bottom: 20px;">
          <label for="whatsapp_number" style="display: block; margin-bottom: 8px;">WhatsApp Number</label>
          <!-- Updated placeholder to show Nigerian format without +234 -->
          <input id="whatsapp_number" name="whatsapp_number" type="tel" value="<?php echo htmlspecialchars($user['whatsapp_number'] ?? ''); ?>" placeholder="080XXXXXXXX" maxlength="11" pattern="0[7-9][0-1]\d{8}" style="width: 100%;" />
          <small style="display: block; margin-top: 5px; color: #999;">Enter your Nigerian number (11 digits starting with 070, 080, 081, 071, 090, 091, etc.)</small>
        </div>
        <!-- REMOVED Gender field as per update -->
        <div style="margin-bottom: 20px;">
          <label style="display: flex; align-items: center; gap: 12px; cursor: pointer;">
            <input type="checkbox" name="chat_earn_enabled" <?php echo ($user['chat_earn_enabled'] ?? 0) ? 'checked' : ''; ?> style="width: 20px; height: 20px;" />
            <span>Click the box to enable Echo Chat (Allow users to connect with you)</span>
          </label>
        </div>
        <div style="display: flex; gap: 12px;">
          <button type="submit" name="update_chat_earn" class="btn-cta" style="flex: 1;">Save Settings</button>
          <button type="button" class="btn-cta" onclick="document.getElementById('chatEarnModal').style.display='none'" style="flex: 1; background: rgba(255,77,77,0.7);">Cancel</button>
        </div>
      </form>
    </div>
  </div>

  <!-- Added Username Update Modal -->
  <div id="usernameModal" class="modal-overlay">
    <div class="modal-content">
      <h2 style="margin-top: 0;">Update Username</h2>
      <!-- Show restriction warning in modal -->
      <?php if (!$can_update_username['can_update']): ?>
        <div style="padding: 16px; background: rgba(251, 191, 36, 0.1); border-radius: 12px; border: 1px solid rgba(251, 191, 36, 0.3); margin-bottom: 20px;">
          <p style="margin: 0; color: #fbbf24; font-size: 0.9rem;">
             <?php echo $can_update_username['message']; ?>
          </p>
        </div>
      <?php endif; ?>
      <form method="POST" action="">
        <div style="margin-bottom: 20px;">
          <label for="new_username" style="display: block; margin-bottom: 8px;">New Username</label>
          <!-- Disable input if cannot update -->
          <input id="new_username" name="username" type="text" value="<?php echo htmlspecialchars($user['username']); ?>" required style="width: 100%;" <?php echo !$can_update_username['can_update'] ? 'readonly' : ''; ?> />
          <p style="font-size: 0.8rem; color: rgba(205, 219, 255, 0.7); margin-top: 6px;">
            Must be 3-20 characters and contain only letters, numbers, and underscores.
          </p>
        </div>
        <div style="display: flex; gap: 12px;">
          <!-- Disable submit button if cannot update -->
          <?php if (!$can_update_username['can_update']): ?>
            <button type="button" class="btn-cta" style="flex: 1; opacity: 0.5; cursor: not-allowed;" disabled>Save Changes</button>
          <?php else: ?>
            <button type="submit" name="update_username" class="btn-cta" style="flex: 1;">Save Changes</button>
          <?php endif; ?>
          <button type="button" class="btn-cta" onclick="document.getElementById('usernameModal').style.display='none'" style="flex: 1; background: rgba(255,77,77,0.7);">Cancel</button>
        </div>
      </form>
    </div>
  </div>

  <!-- Added Gender Update Modal -->
  <div id="genderModal" class="modal-overlay">
    <div class="modal-content">
      <h2 style="margin-top: 0;">Set Your Gender</h2>
      <div style="padding: 16px; background: rgba(251, 191, 36, 0.1); border-radius: 12px; border: 1px solid rgba(251, 191, 36, 0.3); margin-bottom: 20px;">
        <p style="margin: 0; color: #fbbf24; font-size: 0.9rem;">
         Warning: This is a permanent decision. Once you set your gender, it cannot be changed.
        </p>
      </div>
      <?php if (!empty($user['gender'])): ?>
        <div style="padding: 16px; background: rgba(77, 225, 193, 0.1); border-radius: 12px; border: 1px solid rgba(77, 225, 193, 0.3); margin-bottom: 20px;">
          <p style="margin: 0; color: var(--page-mint); font-size: 0.9rem;">
            ✓ Your gender is already set to: <strong><?php echo ucfirst($user['gender']); ?></strong>
          </p>
        </div>
      <?php endif; ?>
      <form method="POST" action="">
        <div style="margin-bottom: 20px;">
          <label style="display: block; margin-bottom: 12px; font-weight: 600;">Select Your Gender</label>
          <div style="display: grid; gap: 12px;">
            <label style="display: flex; align-items: center; gap: 12px; padding: 16px; border-radius: 12px; background: rgba(5, 12, 36, 0.82); border: 1px solid rgba(99, 149, 255, 0.26); cursor: pointer; transition: all 0.3s;" <?php echo !empty($user['gender']) ? 'style="opacity: 0.5; cursor: not-allowed;"' : ''; ?>>
              <input type="radio" name="gender" value="male" required style="width: 20px; height: 20px;" <?php echo !empty($user['gender']) ? 'disabled' : ''; ?> />
              <span style="font-size: 1.1rem;">Male</span>
            </label>
            <label style="display: flex; align-items: center; gap: 12px; padding: 16px; border-radius: 12px; background: rgba(5, 12, 36, 0.82); border: 1px solid rgba(99, 149, 255, 0.26); cursor: pointer; transition: all 0.3s;" <?php echo !empty($user['gender']) ? 'style="opacity: 0.5; cursor: not-allowed;"' : ''; ?>>
              <input type="radio" name="gender" value="female" required style="width: 20px; height: 20px;" <?php echo !empty($user['gender']) ? 'disabled' : ''; ?> />
              <span style="font-size: 1.1rem;"> Female</span>
            </label>
          </div>
        </div>
        <div style="display: flex; gap: 12px;">
          <?php if (!empty($user['gender'])): ?>
            <button type="button" class="btn-cta" style="flex: 1; opacity: 0.5; cursor: not-allowed;" disabled>Already Set</button>
          <?php else: ?>
            <button type="submit" name="update_gender" class="btn-cta" style="flex: 1;">Confirm Gender</button>
          <?php endif; ?>
          <button type="button" class="btn-cta" onclick="document.getElementById('genderModal').style.display='none'" style="flex: 1; background: rgba(255,77,77,0.7);">Cancel</button>
        </div>
      </form>
    </div>
  </div>

   <nav class="mobile-fintech-footer">
    
  <a href="dashboard.php">
    <svg viewBox="0 0 24 24"><path d="M12 3a9 9 0 1 1 0 18 9 9 0 0 1 0-18Zm1 4h-2v6h6v-2h-4V7Z"/></svg>
    <span>Dashboard</span>
  </a>

  <!-- Premium (crown icon) -->
  <a href="membership.php">
    <svg viewBox="0 0 24 24"><path d="M5 7l2.5 5 4.5-4 4.5 4L19 7l2 13H3l2-13Z"/></svg>
    <span>Premium</span>
  </a>

  <a href="post-task.php">
<svg viewBox="0 0 24 24" aria-hidden="true">
  <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8l-6-6Zm1 14h-3v3h-2v-3H7v-2h3v-3h2v3h3v2Zm-3-9V3.5L18.5 8H12Z"/>
</svg>
    
    <span>Advert Post</span>
  </a>
  
  

  <a href="history.php">
  <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
    <path d="M13 3a9 9 0 1 0 9 9h-2a7 7 0 1 1-7-7V3l4 4-4 4V7a5 5 0 1 0 5 5h2a7 7 0 1 1-7-7z"/>
  </svg>
  <span>History</span>
</a>


  <a href="profile.php" class="active">
    <svg viewBox="0 0 24 24"><path d="M12 2a6 6 0 0 1 6 6c0 3.31-2.69 6-6 6s-6-2.69-6-6a6 6 0 0 1 6-6Zm0 14c4.42 0 8 1.79 8 4v2H4v-2c0-2.21 3.58-4 8-4Z"/></svg>
    <span>Profile</span>
  </a>
</nav>


  <script>
document.addEventListener("DOMContentLoaded", () => {
  const successToast = document.getElementById("toast-success");
  const errorToast = document.getElementById("toast-error");

  function showToast(toast) {
    if (!toast) return;
    setTimeout(() => toast.classList.add("show"), 100);
    setTimeout(() => toast.classList.remove("show"), 5000);
  }

  showToast(successToast);
  showToast(errorToast);

  loadBanks();
  
  const accountNumberInput = document.getElementById('account_number');
  const bankCodeSelect = document.getElementById('bank_code_select'); // Renamed to avoid conflict
  
  const bankSelectContainer = bankCodeSelect.parentElement;
  bankSelectContainer.style.display = 'none';
  
  accountNumberInput.addEventListener('input', handleAccountNumberInput);
  accountNumberInput.addEventListener('paste', function(e) {
    setTimeout(() => handleAccountNumberInput.call(this), 10);
  });
  
  function handleAccountNumberInput() {
    const accountNumber = this.value.replace(/\D/g, '');
    this.value = accountNumber;
    
    if (accountNumber.length === 10) {
      autoVerifyAccountWithoutBank(accountNumber);
    } else {
      document.getElementById('account_name_display').style.display = 'none';
      document.getElementById('multiple_banks_display').style.display = 'none';
      bankSelectContainer.style.display = 'none';
    }
  }
  
  bankCodeSelect.addEventListener('change', function() { // Use renamed element
    const accountNumber = accountNumberInput.value;
    if (accountNumber.length === 10 && this.value) {
      autoVerifyAccount(accountNumber, this.value);
    }
  });
});

async function loadBanks() {
  try {
    const response = await fetch('api/paystack-get-banks.php');
    const data = await response.json();
    
    if (data.success) {
      const bankSelect = document.getElementById('bank_code_select'); // Use renamed element
      bankSelect.innerHTML = '<option value="">-- Select your bank --</option>';
      
      data.banks.forEach(bank => {
        const option = document.createElement('option');
        option.value = bank.code;
        option.textContent = bank.name;
        bankSelect.appendChild(option);
      });
    }
  } catch (error) {
    console.error('Error loading banks:', error);
  }
}

async function autoVerifyAccountWithoutBank(accountNumber) {
  const loadingDiv = document.getElementById('verification_loading');
  const accountNameDisplay = document.getElementById('account_name_display');
  const verifiedNameEl = document.getElementById('verified_account_name');
  const hiddenAccountNameInput = document.getElementById('hidden_account_name');
  const bankSelectContainer = document.getElementById('bank_code_select').parentElement; // Use renamed element
  
  loadingDiv.style.display = 'block';
  accountNameDisplay.style.display = 'none';
  bankSelectContainer.style.display = 'none';
  hiddenAccountNameInput.value = '';
  document.getElementById('hidden_bank_name').value = ''; // Clear hidden bank name
  document.getElementById('hidden_bank_code').value = ''; // Clear hidden bank code
  
  try {
    const formData = new FormData();
    formData.append('account_number', accountNumber);
    formData.append('resolve_only', 'true');
    
    const response = await fetch('api/paystack-verify-account.php', {
      method: 'POST',
      body: formData
    });
    
    const data = await response.json();
    
    loadingDiv.style.display = 'none';
    
    if (data.success) {
      verifiedNameEl.textContent = data.account_name;
      hiddenAccountNameInput.value = data.account_name;
      accountNameDisplay.style.display = 'block';
      
      if (data.bank_code) {
        document.getElementById('bank_code_select').value = data.bank_code; // Use renamed element
        document.getElementById('hidden_bank_name').value = data.bank_name || '';
        document.getElementById('hidden_bank_code').value = data.bank_code;
      } else {
        bankSelectContainer.style.display = 'block'; // Show bank selection if bank code not provided
      }
      
      showToastMessage('✓ Account verified successfully!', 'success');
    } else {
      accountNameDisplay.style.display = 'none';
      bankSelectContainer.style.display = 'block';
      showToastMessage(data.message || 'Could not verify account. Please select your bank.', 'error');
    }
  } catch (error) {
    console.error('Error verifying account:', error);
    loadingDiv.style.display = 'none';
    accountNameDisplay.style.display = 'none';
    bankSelectContainer.style.display = 'block';
    showToastMessage('Error occurred during verification. Please select your bank.', 'error');
  }
}

async function autoVerifyAccount(accountNumber, bankCode) {
  const loadingDiv = document.getElementById('verification_loading');
  const accountNameDisplay = document.getElementById('account_name_display');
  const verifiedNameEl = document.getElementById('verified_account_name');
  const hiddenAccountNameInput = document.getElementById('hidden_account_name');
  const bankSelect = document.getElementById('bank_code_select'); // Use renamed element
  const bankNameInput = document.getElementById('hidden_bank_name');
  const bankCodeInput = document.getElementById('hidden_bank_code');
  
  loadingDiv.style.display = 'block';
  accountNameDisplay.style.display = 'none';
  hiddenAccountNameInput.value = '';
  
  try {
    const formData = new FormData();
    formData.append('account_number', accountNumber);
    formData.append('bank_code', bankCode);
    
    const response = await fetch('api/paystack-verify-account.php', {
      method: 'POST',
      body: formData
    });
    
    const data = await response.json();
    
    loadingDiv.style.display = 'none';
    
    if (data.success) {
      verifiedNameEl.textContent = data.account_name;
      hiddenAccountNameInput.value = data.account_name;
      accountNameDisplay.style.display = 'block';
      
      // Set bank name from selected option
      const selectedOption = bankSelect.options[bankSelect.selectedIndex];
      bankNameInput.value = selectedOption.text;
      bankCodeInput.value = bankCode;
      
      showToastMessage('✓ Account verified successfully!', 'success');
    } else {
      accountNameDisplay.style.display = 'none';
      hiddenAccountNameInput.value = '';
      bankNameInput.value = '';
      bankCodeInput.value = '';
      showToastMessage(data.message || 'Could not verify account', 'error');
    }
  } catch (error) {
    console.error('Error verifying account:', error);
    loadingDiv.style.display = 'none';
    accountNameDisplay.style.display = 'none';
    hiddenAccountNameInput.value = '';
    bankNameInput.value = '';
    bankCodeInput.value = '';
    showToastMessage('Error verifying account', 'error');
  }
}

function saveWithdrawalMethod() {
  const form = document.getElementById('withdrawalForm');
  const accountNumber = document.getElementById('account_number').value;
  const bankCodeSelect = document.getElementById('bank_code_select'); // Use renamed element
  const bankCode = bankCodeSelect.value;
  const bankName = bankCodeSelect.options[bankCodeSelect.selectedIndex].text;
  const accountName = document.getElementById('hidden_account_name').value;
  
  if (!accountNumber || !bankCode || !accountName || bankName === '-- Select your bank --') {
    showToastMessage('Please enter account number, verify it, and select a bank', 'error');
    return;
  }
  
  // Set hidden fields before submitting
  form.querySelector('input[name="account_name"]').value = accountName;
  form.querySelector('input[name="bank_name"]').value = bankName;
  form.querySelector('input[name="bank_code"]').value = bankCode;
  
  // Submit the form using fetch API for smoother experience
  const formData = new FormData(form);

  fetch(form.action, {
      method: 'POST',
      body: formData
  })
  .then(response => response.text()) // Get the response as text to parse HTML
  .then(html => {
      // Parse the response HTML to find toast messages
      const parser = new DOMParser();
      const doc = parser.parseFromString(html, "text/html");
      
      const successMessage = doc.getElementById("toast-success")?.textContent;
      const errorMessage = doc.getElementById("toast-error")?.textContent;

      if (successMessage) {
          showToastMessage(successMessage, 'success');
          setTimeout(() => {
            window.location.reload();
          }, 2000); // Reload after showing success
      } else if (errorMessage) {
          showToastMessage(errorMessage, 'error');
      } else {
          // Fallback if no specific toast found, check if page reloaded or if there's another error indicator
          showToastMessage('An unexpected error occurred.', 'error');
      }
  })
  .catch(error => {
      console.error('Error saving withdrawal method:', error);
      showToastMessage('Error saving withdrawal method', 'error');
  });
}

function openWithdrawalModal() {
  document.getElementById('withdrawalMethodModal').style.display='flex';
  loadBanks(); // Ensure banks are loaded when modal opens
}

function closeWithdrawalModal() {
  document.getElementById('withdrawalMethodModal').style.display='none';
  // Reset form
  document.getElementById('account_number').value = '';
  document.getElementById('bank_code_select').value = ''; // Use renamed element
  document.getElementById('account_name_display').style.display = 'none';
  document.getElementById('verification_loading').style.display = 'none';
  document.getElementById('hidden_account_name').value = ''; // Clear hidden field
  document.getElementById('hidden_bank_name').value = ''; // Clear hidden bank name
  document.getElementById('hidden_bank_code').value = ''; // Clear hidden bank code
  document.getElementById('bank_code_select').innerHTML = '<option value="">Loading banks...</option>'; // Reset select
}

async function toggleTheme() {
  const currentTheme = document.documentElement.classList.contains('light') ? 'light' : 'dark';
  const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
  
  try {
    const formData = new FormData();
    formData.append('theme', newTheme);
    
    const response = await fetch('api/update-theme.php', {
      method: 'POST',
      body: formData
    });
    
    const data = await response.json();
    
    if (data.success) {
      document.documentElement.classList.remove('dark', 'light');
      document.documentElement.classList.add(newTheme);
      showToastMessage(`Switched to ${newTheme} mode!`, 'success');
      setTimeout(() => {
        window.location.reload();
      }, 1000);
    } else {
      showToastMessage(data.message || 'Failed to update theme', 'error');
    }
  } catch (error) {
    console.error('Error updating theme:', error);
    showToastMessage('Error updating theme', 'error');
  }
}

async function deleteAccount() {
  const password = document.getElementById('delete_password').value;
  
  if (!password) {
    showToastMessage('Please enter your password', 'error');
    return;
  }

  const formData = new FormData();
  formData.append('password', password);
  formData.append('delete_account', '1'); // Indicate delete action
  
  try {
    const response = await fetch('profile.php', { // Submit to the current page
        method: 'POST',
        body: formData
    });
    
    const html = await response.text();
    const parser = new DOMParser();
    const doc = parser.parseFromString(html, "text/html");
    
    const successMessage = doc.getElementById("toast-success")?.textContent;
    const errorMessage = doc.getElementById("toast-error")?.textContent;

    if (successMessage) {
      showToastMessage('Account deleted successfully', 'success');
      setTimeout(() => {
        window.location.href = 'login.php?message=account_deleted';
      }, 2000);
    } else if (errorMessage) {
      showToastMessage(errorMessage, 'error');
    } else {
      // Check for specific PHP redirect (e.g., if already logged out, or other redirects)
      if (window.location.href.includes('login.php')) {
        // Already redirected by PHP
      } else {
        showToastMessage('Failed to delete account. Please try again.', 'error');
      }
    }
  } catch (error) {
    console.error('Error deleting account:', error);
    showToastMessage('Error deleting account', 'error');
  }
}


function showToastMessage(message, type) {
  let toast = document.getElementById(`toast-${type}`);
  
  if (!toast) {
    toast = document.createElement("div");
    toast.id = `toast-${type}`;
    toast.className = `toast-message ${type}`;
    document.body.appendChild(toast);
  }
  
  toast.textContent = message;
  toast.classList.remove("show");
  setTimeout(() => toast.classList.add("show"), 50);
  setTimeout(() => toast.classList.remove("show"), 4000);
}
</script>


</body>
</html>
