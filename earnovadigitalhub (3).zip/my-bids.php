<?php
session_start();
require_once 'config/database.php';
require_once 'includes/session.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$user_id = $_SESSION['user_id'];

// Fetch user details
$stmt = $conn->prepare("SELECT u.*, v.verification_status, v.verified_at 
                        FROM users u 
                        LEFT JOIN user_verification v ON u.id = v.user_id 
                        WHERE u.id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();
$stmt->close();

// Check if user is premium
if ($user['membership_type'] !== 'premium') {
    header('Location: membership.php?error=premium_required');
    exit();
}

// Fetch user's bids
$stmt = $conn->prepare("
    SELECT jb.*, j.title, j.description, j.budget, j.location as job_location, j.deadline,
           j.admin_contact_number
    FROM job_bids jb
    JOIN jobs j ON jb.job_id = j.id
    WHERE jb.user_id = ?
    ORDER BY jb.created_at DESC
");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$bids = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();

// Count bid statistics
$total_bids = count($bids);
$approved_bids = count(array_filter($bids, fn($b) => $b['status'] === 'approved'));
$pending_bids = count(array_filter($bids, fn($b) => $b['status'] === 'pending'));
$rejected_bids = count(array_filter($bids, fn($b) => $b['status'] === 'rejected'));
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>My Bids - FlowEarner</title>
  <style>
    :root {
      --page-blue-900: #030922;
      --page-blue-700: #0a164a;
      --page-blue-500: #142a7e;
      --page-blue-300: #2c5bf5;
      --page-mint: #4de1c1;
      --page-white: #f5f9ff;
      --panel-glass: rgba(13, 24, 62, 0.84);
      --panel-border: rgba(86, 139, 241, 0.3);
      --shadow-heavy: 0 40px 120px rgba(4, 10, 36, 0.65);
      --transition-short: 0.4s ease;
    }

    * { box-sizing: border-box; }

    body {
      margin: 0;
      font-family: "Titillium Web", "Segoe UI", sans-serif;
      background: radial-gradient(circle at 0% 0%, rgba(61, 116, 255, 0.28), transparent 55%),
                  radial-gradient(circle at 100% 0%, rgba(77, 225, 193, 0.2), transparent 45%),
                  linear-gradient(180deg, var(--page-blue-900), var(--page-blue-700));
      color: var(--page-white);
      min-height: 100vh;
    }

    .page-shell {
      display: grid;
      grid-template-columns: 320px 1fr;
      min-height: 100vh;
    }

    aside {
      background: rgba(5, 15, 44, 0.92);
      backdrop-filter: blur(18px);
      padding: 36px 32px;
      display: grid;
      gap: 30px;
      border-right: 1px solid var(--panel-border);
      position: sticky;
      top: 0;
      height: 100vh;
      overflow-y: auto;
    }

    main {
      padding: 42px 48px;
      display: grid;
      gap: 42px;
    }

    .back-link {
      display: inline-flex;
      align-items: center;
      gap: 10px;
      font-weight: 600;
      letter-spacing: 0.1em;
      text-transform: uppercase;
      color: rgba(210, 226, 255, 0.78);
      text-decoration: none;
      transition: color var(--transition-short);
    }

    .back-link:hover { color: var(--page-mint); }

    .page-title {
      font-size: clamp(1.5rem, 4vw, 2rem);
      letter-spacing: 0.1em;
      text-transform: uppercase;
      margin: 0 0 10px;
    }

    .side-description {
      color: rgba(206, 224, 255, 0.74);
      line-height: 1.7;
    }

    .stats-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
      gap: 20px;
      margin-bottom: 30px;
    }

    .stat-card {
      padding: 24px;
      border-radius: 20px;
      background: rgba(6, 16, 48, 0.9);
      border: 1px solid rgba(100, 154, 255, 0.24);
      box-shadow: var(--shadow-heavy);
    }

    .stat-label {
      font-size: 0.85rem;
      letter-spacing: 0.18em;
      text-transform: uppercase;
      color: rgba(205, 222, 255, 0.7);
    }

    .stat-value {
      font-size: 1.8rem;
      font-weight: 700;
      margin: 12px 0;
    }

    .bid-card {
      padding: 28px;
      border-radius: 24px;
      background: rgba(6, 16, 48, 0.9);
      border: 1px solid rgba(100, 154, 255, 0.24);
      box-shadow: var(--shadow-heavy);
      margin-bottom: 20px;
    }

    .bid-header {
      display: flex;
      justify-content: space-between;
      align-items: start;
      margin-bottom: 16px;
    }

    .bid-title {
      font-size: 1.3rem;
      font-weight: 700;
      margin-bottom: 8px;
    }

    .status-badge {
      padding: 8px 16px;
      border-radius: 12px;
      font-size: 0.8rem;
      font-weight: 600;
      letter-spacing: 0.08em;
      text-transform: uppercase;
    }

    .status-pending {
      background: rgba(255, 193, 7, 0.2);
      color: #ffc107;
    }

    .status-approved {
      background: rgba(77, 225, 193, 0.2);
      color: var(--page-mint);
    }

    .status-rejected {
      background: rgba(255, 51, 102, 0.2);
      color: #ff3366;
    }

    .bid-details {
      display: grid;
      gap: 12px;
      margin-top: 16px;
      padding-top: 16px;
      border-top: 1px dashed rgba(103, 158, 255, 0.25);
    }

    .detail-row {
      display: flex;
      justify-content: space-between;
      font-size: 0.9rem;
    }

    .detail-label {
      color: rgba(205, 219, 255, 0.7);
    }

    .btn-whatsapp {
      display: inline-flex;
      align-items: center;
      gap: 10px;
      padding: 14px 26px;
      border-radius: 18px;
      background: linear-gradient(135deg, #25d366, #128c7e);
      color: white;
      font-weight: 600;
      text-decoration: none;
      margin-top: 16px;
      transition: transform var(--transition-short);
    }

    .btn-whatsapp:hover {
      transform: translateY(-2px);
    }

    .empty-state {
      text-align: center;
      padding: 60px 20px;
      color: rgba(205, 219, 255, 0.7);
    }

    .empty-state h3 {
      font-size: 1.5rem;
      margin-bottom: 12px;
    }

    @media (max-width: 960px) {
      .page-shell {
        grid-template-columns: 1fr;
      }

      aside {
        position: relative;
        height: auto;
      }

      main {
        padding: 32px 20px;
      }
    }
  </style>
</head>
<body>
  <div class="page-shell">
    <aside>
      <a class="back-link" href="find-jobs.php">← Back to Jobs</a>
      <div>
        <h2 class="page-title">My Bids</h2>
        <p class="side-description">Track all your job bids and see approval status. Contact clients directly when approved.</p>
      </div>
    </aside>

    <main>
      <div class="stats-grid">
        <div class="stat-card">
          <div class="stat-label">Total Bids</div>
          <div class="stat-value"><?php echo $total_bids; ?></div>
        </div>
        <div class="stat-card">
          <div class="stat-label">Approved</div>
          <div class="stat-value" style="color: var(--page-mint);"><?php echo $approved_bids; ?></div>
        </div>
        <div class="stat-card">
          <div class="stat-label">Pending</div>
          <div class="stat-value" style="color: #ffc107;"><?php echo $pending_bids; ?></div>
        </div>
        <div class="stat-card">
          <div class="stat-label">Rejected</div>
          <div class="stat-value" style="color: #ff3366;"><?php echo $rejected_bids; ?></div>
        </div>
      </div>

      <?php if (empty($bids)): ?>
        <div class="empty-state">
          <h3>No Bids Yet</h3>
          <p>You haven't submitted any job bids. Browse available jobs and start bidding!</p>
          <a href="find-jobs.php" class="btn-whatsapp" style="background: linear-gradient(135deg, rgba(47, 91, 234, 0.95), rgba(77, 225, 193, 0.85)); display: inline-flex; margin-top: 20px;">
            Browse Jobs
          </a>
        </div>
      <?php else: ?>
        <?php foreach ($bids as $bid): ?>
          <div class="bid-card">
            <div class="bid-header">
              <div>
                <div class="bid-title"><?php echo htmlspecialchars($bid['title']); ?></div>
                <p style="color: rgba(205, 219, 255, 0.7); margin: 0;"><?php echo htmlspecialchars(substr($bid['description'], 0, 150)) . '...'; ?></p>
              </div>
              <span class="status-badge status-<?php echo $bid['status']; ?>">
                <?php echo ucfirst($bid['status']); ?>
              </span>
            </div>

            <div class="bid-details">
              <div class="detail-row">
                <span class="detail-label">Your Proposed Rate:</span>
                <strong>₦<?php echo number_format($bid['proposed_rate'], 2); ?></strong>
              </div>
              <div class="detail-row">
                <span class="detail-label">Job Budget:</span>
                <strong>₦<?php echo number_format($bid['budget'], 2); ?></strong>
              </div>
              <div class="detail-row">
                <span class="detail-label">Location:</span>
                <strong><?php echo htmlspecialchars($bid['job_location']); ?></strong>
              </div>
              <div class="detail-row">
                <span class="detail-label">Deadline:</span>
                <strong><?php echo date('M d, Y', strtotime($bid['deadline'])); ?></strong>
              </div>
              <div class="detail-row">
                <span class="detail-label">Bid Submitted:</span>
                <strong><?php echo date('M d, Y H:i', strtotime($bid['created_at'])); ?></strong>
              </div>
            </div>

            <?php if ($bid['status'] === 'approved' && !empty($bid['admin_contact_number'])): ?>
              <a href="https://wa.me/<?php echo preg_replace('/[^0-9]/', '', $bid['admin_contact_number']); ?>?text=Hello! I'm contacting you regarding the job: <?php echo urlencode($bid['title']); ?>" 
                 class="btn-whatsapp" target="_blank">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor">
                  <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413Z"/>
                </svg>
                Contact Client on WhatsApp
              </a>
            <?php elseif ($bid['status'] === 'pending'): ?>
              <p style="margin-top: 16px; color: rgba(205, 219, 255, 0.7); font-size: 0.9rem;">
                ⏳ Your bid is under review. You'll be notified once the admin approves it.
              </p>
            <?php elseif ($bid['status'] === 'rejected'): ?>
              <p style="margin-top: 16px; color: #ff3366; font-size: 0.9rem;">
                ❌ This bid was not approved. Keep trying with other jobs!
              </p>
            <?php endif; ?>
          </div>
        <?php endforeach; ?>
      <?php endif; ?>
    </main>
  </div>
</body>
</html>
