<?php
require_once 'config/database.php';
require_once 'includes/session.php';
require_once 'includes/connect.php';

// Require authentication
requireLogin();
checkSessionTimeout();

// Get current user data
$user = getCurrentUser();
$user_id = $user['id'];

try {
    $pdo = getDBConnection();
    
    // Fetch user details with balances
    $stmt = $pdo->prepare("
        SELECT u.*, b.total_balance, b.task_earnings, b.referral_earnings
        FROM users u
        LEFT JOIN balances b ON u.id = b.user_id
        WHERE u.id = ?
    ");
    $stmt->execute([$user_id]);
    $user_data = $stmt->fetch();
    
    if (!$user_data) {
        header('Location: login.php');
        exit;
    }
    
    $is_member = in_array($user_data['membership_type'], ['premium', 'senior']);
    
    // Platform prices (for 10 participants)
     $platform_prices = [
        'tiktok' => ['name' => 'TikTok', 'member' => 320, 'non_member' => 320],
        'instagram' => ['name' => 'Instagram', 'member' => 350, 'non_member' => 350],
        'whatsapp' => ['name' => 'WhatsApp', 'member' => 320, 'non_member' => 320],
        'playstore' => ['name' => 'PlayStore', 'member' => 700, 'non_member' => 700],
        'appstore' => ['name' => 'AppStore', 'member' => 800, 'non_member' => 800],
        'telegram' => ['name' => 'Telegram', 'member' => 320, 'non_member' => 320],
        'twitter' => ['name' => 'Twitter/X', 'member' => 380, 'non_member' => 380],
        'facebook' => ['name' => 'Facebook', 'member' => 350, 'non_member' => 350],
        'linkedin' => ['name' => 'LinkedIn', 'member' => 350, 'non_member' => 350],
        'snapchat' => ['name' => 'Snapchat', 'member' => 340, 'non_member' => 340],
        'youtube' => ['name' => 'YouTube', 'member' => 400, 'non_member' => 400],
        'pinterest' => ['name' => 'Pinterest', 'member' => 350, 'non_member' => 350],
        'reddit' => ['name' => 'Reddit', 'member' => 350, 'non_member' => 350],
        'discord' => ['name' => 'Discord', 'member' => 300, 'non_member' => 300],
        'twitch' => ['name' => 'Twitch', 'member' => 400, 'non_member' => 400],
        'audiomack' => ['name' => 'Audiomack', 'member' => 300, 'non_member' => 300],
        'boomplay' => ['name' => 'Boomplay', 'member' => 450, 'non_member' => 450],
        'spotify' => ['name' => 'Spotify', 'member' => 400, 'non_member' => 400],
        'applemusic' => ['name' => 'Apple Music', 'member' => 400, 'non_member' => 400],
        'soundcloud' => ['name' => 'SoundCloud', 'member' => 450, 'non_member' => 450],
        'website' => ['name' => 'Website', 'member' => 500, 'non_member' => 500]
    ];
    
    // Handle actions
    $message = '';
    $messageType = '';
    
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $action = $_POST['action'] ?? '';
        $task_id = intval($_POST['task_id'] ?? 0);
        
        if ($action === 'pause' && $task_id > 0) {
            // Pause task
            $stmt = $pdo->prepare("UPDATE tasks SET is_active = 0 WHERE id = ? AND title IN (SELECT title FROM advertisements WHERE user_id = ?)");
            $stmt->execute([$task_id, $user_id]);
            $_SESSION['task_message'] = 'Task paused successfully';
            $_SESSION['task_message_type'] = 'success';
            header('Location: my-posted-task.php');
            exit;
            
        } elseif ($action === 'resume' && $task_id > 0) {

        // Check if the task is permanently disabled by admin
        $stmt = $pdo->prepare("SELECT is_permanently_disabled FROM tasks WHERE id = ?");
        $stmt->execute([$task_id]);
        $task_status = $stmt->fetch();
    
        if (!$task_status) {
            $_SESSION['task_message'] = 'Task not found.';
            $_SESSION['task_message_type'] = 'error';
            header('Location: my-posted-task.php');
            exit;
        }
    
        // Block the user if admin disabled the task
        if ($task_status['is_permanently_disabled'] == 1) {
            $_SESSION['task_message'] = 'You cannot activate this task because it was disabled by admin. Check dashboard notifications to see the reason.';
            $_SESSION['task_message_type'] = 'error';
            header('Location: my-posted-task.php');
            exit;
        }
    
        // Continue with normal resume
        $stmt = $pdo->prepare("UPDATE tasks SET is_active = 1 WHERE id = ? AND title IN (SELECT title FROM advertisements WHERE user_id = ?)");
        $stmt->execute([$task_id, $user_id]);
    
        $_SESSION['task_message'] = 'Task resumed successfully';
        $_SESSION['task_message_type'] = 'success';
        header('Location: my-posted-task.php');
        exit;
    
            
        } elseif ($action === 'edit' && $task_id > 0) {
             // Get original task to check if disabled
    $stmt = $pdo->prepare("SELECT is_permanently_disabled, task_url, title FROM tasks WHERE id = ?");
    $stmt->execute([$task_id]);
    $original_task = $stmt->fetch();

    if (!$original_task) {
        $_SESSION['task_message'] = 'Task not found.';
        $_SESSION['task_message_type'] = 'error';
        header('Location: my-posted-task.php');
        exit;
    }

    if ($original_task['is_permanently_disabled'] == 1) {
        $_SESSION['task_message'] = 'You cannot edit this task because it was disabled by admin.';
        $_SESSION['task_message_type'] = 'error';
        header('Location: my-posted-task.php');
        exit;
    }
            // Edit task
            $title = trim($_POST['title'] ?? '');
            $description = trim($_POST['description'] ?? '');
            $task_url = trim($_POST['task_url'] ?? '');
            
            if (empty($title) || empty($description) || empty($task_url)) {
                $_SESSION['task_message'] = 'Please fill in all fields';
                $_SESSION['task_message_type'] = 'error';
            } elseif (!filter_var($task_url, FILTER_VALIDATE_URL)) {
                $_SESSION['task_message'] = 'Please provide a valid URL';
                $_SESSION['task_message_type'] = 'error';
            } else {
                // Get original task to verify URL matches task type
                $stmt = $pdo->prepare("SELECT * FROM tasks WHERE id = ?");
                $stmt->execute([$task_id]);
                $original_task = $stmt->fetch();
                
               if ($original_task) {
    // Detect original task platform
    $original_platform = detectPlatformFromUrl($original_task['task_url']);
    
    // Detect new URL platform
    $new_platform = detectPlatformFromUrl($task_url);
    
    if ($original_platform !== $new_platform) {
        $_SESSION['task_message'] = 'URL does not match the original task platform.';
        $_SESSION['task_message_type'] = 'error';
    } else {
        // Update task
        $stmt = $pdo->prepare("UPDATE tasks SET title = ?, description = ?, task_url = ? WHERE id = ?");
        $stmt->execute([$title, $description, $task_url, $task_id]);
        
        // Update advertisement
        $stmt = $pdo->prepare("UPDATE advertisements SET title = ?, description = ?, target_url = ? WHERE user_id = ? AND title = ?");
        $stmt->execute([$title, $description, $task_url, $user_id, $original_task['title']]);
        
        $_SESSION['task_message'] = 'Task updated successfully';
        $_SESSION['task_message_type'] = 'success';
    }
    
               }

    header('Location: my-posted-task.php');
    exit;
}

            
        } elseif ($action === 'extend' && $task_id > 0) {
             // Check if the task is permanently disabled by admin
    $stmt = $pdo->prepare("SELECT is_permanently_disabled, task_url, title FROM tasks WHERE id = ?");
    $stmt->execute([$task_id]);
    $task = $stmt->fetch();

    if (!$task) {
        $_SESSION['task_message'] = 'Task not found.';
        $_SESSION['task_message_type'] = 'error';
        header('Location: my-posted-task.php');
        exit;
    }

    if ($task['is_permanently_disabled'] == 1) {
        $_SESSION['task_message'] = 'You cannot extend this task because it was disabled by admin.';
        $_SESSION['task_message_type'] = 'error';
        header('Location: my-posted-task.php');
        exit;
    }
            $additional_participants = intval($_POST['additional_participants'] ?? 0);
            
            if ($additional_participants < 10) {
                $_SESSION['task_message'] = 'Minimum 10 additional participants required';
                $_SESSION['task_message_type'] = 'error';
            } elseif ($additional_participants > 1000) {
                $_SESSION['task_message'] = 'Maximum 1000 additional participants allowed';
                $_SESSION['task_message_type'] = 'error';
            } else {
                // Get task details
                $stmt = $pdo->prepare("
                    SELECT t.*, a.title as ad_title 
                    FROM tasks t
                    JOIN advertisements a ON t.title = a.title
                    WHERE t.id = ? AND a.user_id = ?
                ");
                $stmt->execute([$task_id, $user_id]);
                $task = $stmt->fetch();
                
                if ($task) {
                    // Determine platform from task URL - matching post-task.php logic
                    $platform_key = detectPlatformFromUrl($task['task_url']);
                    
                    // Use exact pricing from post-task.php (members get lower prices)
                    $base_price = $is_member ? $platform_prices[$platform_key]['member'] : $platform_prices[$platform_key]['non_member'];
                    $extension_cost = ($additional_participants / 10) * $base_price;
                    
                    $available_balance = $user_data['referral_earnings'];
                    
                    if ($available_balance < $extension_cost) {
                        $_SESSION['task_message'] = 'Insufficient Balance for extension';
                        $_SESSION['task_message_type'] = 'error';
                    } else {
                        $pdo->beginTransaction();
                        try {
                            $stmt = $pdo->prepare("UPDATE balances SET referral_earnings = referral_earnings - ?, total_balance = total_balance - ? WHERE user_id = ?");
                            $stmt->execute([$extension_cost, $extension_cost, $user_id]);
                            
                            $stmt = $pdo->prepare("UPDATE advertisements SET budget = budget + ?, remaining_budget = remaining_budget + ? WHERE user_id = ? AND title = ?");
                            $stmt->execute([$extension_cost, $extension_cost, $user_id, $task['title']]);
                            
                            // Update task participants count
                            $stmt = $pdo->prepare("UPDATE tasks SET participants_count = participants_count + ? WHERE id = ?");
                            $stmt->execute([$additional_participants, $task_id]);

                            
                            // Record transaction
                            $stmt = $pdo->prepare("INSERT INTO transactions (user_id, transaction_type, amount, balance_type, description, reference_id, created_at) VALUES (?, 'ad_purchase', ?, 'prime_earnings', ?, ?, NOW())");
                            $description_text = "Extended task: {$task['title']} by {$additional_participants} participants";
                            $stmt->execute([$user_id, $extension_cost, $description_text, "EXTEND-{$task_id}"]);
                            
                            $pdo->commit();
                            $_SESSION['task_message'] = "Task extended successfully! Added {$additional_participants} participants.";
                            $_SESSION['task_message_type'] = 'success';
                            
                            // Refresh user data
                            $stmt = $pdo->prepare("SELECT u.*, b.total_balance, b.task_earnings, b.referral_earnings FROM users u LEFT JOIN balances b ON u.id = b.user_id WHERE u.id = ?");
                            $stmt->execute([$user_id]);
                            $user_data = $stmt->fetch();
                            
                        } catch (Exception $e) {
                            $pdo->rollBack();
                            $_SESSION['task_message'] = 'Failed to extend task';
                            $_SESSION['task_message_type'] = 'error';
                        }
                    }
                }
            }
            header('Location: my-posted-task.php');
            exit;
        }
    }
    
    $message = $_SESSION['task_message'] ?? '';
    $messageType = $_SESSION['task_message_type'] ?? '';
    if ($message) {
        unset($_SESSION['task_message']);
        unset($_SESSION['task_message_type']);
    }
    
    // Fetch user's posted tasks
  $stmt = $pdo->prepare("
    SELECT 
        t.id,
        t.title,
        t.description,
        t.task_url,
        t.reward_amount,
        t.is_active,
        t.is_permanently_disabled,
        t.created_at,
        t.participants_count,
        a.target_url,
        a.budget,
        a.remaining_budget,
        a.total_actions
    FROM tasks t
    JOIN advertisements a ON t.title = a.title
    WHERE a.user_id = ?
    ORDER BY t.created_at DESC
");

    $stmt->execute([$user_id]);
    $posted_tasks = $stmt->fetchAll();
    
} catch (PDOException $e) {
    error_log("My Posted Tasks Error: " . $e->getMessage());
    $error_message = "Unable to load tasks.";
}

$username = htmlspecialchars($user_data['username'] ?? 'User');
$membership_status = $is_member ? 'Premium Member' : 'Free Member';

function detectPlatformFromUrl($url) {
    $url_lower = strtolower($url);
    
    $platform_patterns = [
        'tiktok' => ['tiktok.com', 'vm.tiktok.com'],
        'instagram' => ['instagram.com', 'instagr.am'],
        'whatsapp' => ['whatsapp.com', 'wa.me', 'chat.whatsapp.com'],
        'playstore' => ['play.google.com'],
        'appstore' => ['apps.apple.com', 'itunes.apple.com'],
        'telegram' => ['t.me', 'telegram.me', 'telegram.org'],
        'twitter' => ['twitter.com', 'x.com'],
        'facebook' => ['facebook.com', 'fb.com', 'fb.me'],
        'linkedin' => ['linkedin.com'],
        'snapchat' => ['snapchat.com'],
        'youtube' => ['youtube.com', 'youtu.be'],
        'pinterest' => ['pinterest.com', 'pin.it'],
        'reddit' => ['reddit.com', 'redd.it'],
        'discord' => ['discord.com', 'discord.gg'],
        'twitch' => ['twitch.tv'],
        'audiomack' => ['audiomack.com'],
        'boomplay' => ['boomplay.com'],
        'spotify' => ['spotify.com', 'open.spotify.com'],
        'applemusic' => ['music.apple.com'],
        'soundcloud' => ['soundcloud.com']
    ];
    
    foreach ($platform_patterns as $platform => $patterns) {
        foreach ($patterns as $pattern) {
            if (strpos($url_lower, $pattern) !== false) {
                return $platform;
            }
        }
    }
    
    return 'tiktok'; // default
}

function calculateDynamicRemainingBudget($pdo, $task_id, $participants_count, $budget) {
    try {
        // Get count of users who completed the task
        $stmt = $pdo->prepare("SELECT COUNT(DISTINCT user_id) as completed_count FROM user_tasks WHERE task_id = ? AND status = 'completed'");
        $stmt->execute([$task_id]);
        $result = $stmt->fetch();
        $completed_count = $result['completed_count'] ?? 0;
        
        // Calculate amount per participant
        $amount_per_participant = $budget / $participants_count;
        
        // Remaining = Total budget - (completed_count * amount_per_participant)
        $deducted_amount = $completed_count * $amount_per_participant;
        $remaining = $budget - $deducted_amount;
        
        return max(0, round($remaining, 2)); // Ensure we don't go below 0
    } catch (Exception $e) {
        error_log("Error calculating dynamic remaining budget: " . $e->getMessage());
        return $budget; // Fallback to full budget if error
    }
}

function getParticipantCount($pdo, $task_id, $user_id) {
    try {
        // Get count of users who started the task
        $stmt = $pdo->prepare("SELECT COUNT(DISTINCT user_id) as count FROM user_tasks WHERE task_id = ? AND status = 'completed'");
        $stmt->execute([$task_id]);
        $result = $stmt->fetch();
        return $result['count'] ?? 0;
    } catch (Exception $e) {
        error_log("Error getting participant count: " . $e->getMessage());
        return 0;
    }
}
?>
<?php include "doctype.php"; ?>
  <link rel="stylesheet" href="my-posted-task.css" />

<body>
    
   
              
              
  <?php include "embed.php"; ?>
  <?php include "header2.php"; ?>
  <div class="page-shell">
    
    <main>
      <!-- Updated alert styling to match earnova toast-message pattern -->
      <?php if ($message): ?>
        <div id="toast-<?php echo $messageType; ?>" class="toast-message <?php echo $messageType; ?>">
          <?php echo htmlspecialchars($message); ?>
        </div>
      <?php endif; ?>

      <section class="hero-section">
        <div class="hero-content">
          <h1 style="font-size: 18px;">Task Management Center
             <div class="stats-box">
        <h4>Quick Stats</h4>
        <div class="stat-item">
          <span>Total Tasks</span>
          <strong><?php echo count($posted_tasks); ?></strong>
        </div>
        <div class="stat-item">
          <span>Active Tasks</span>
          <strong><?php echo count(array_filter($posted_tasks, fn($t) => $t['is_active'])); ?></strong>
        </div>
          </h1>
          <p>Monitor your published tasks, track participant progress, and manage task settings all in one place.</p>
        </div>
        <a href="post-task.php" class="btn-primary">+ Post New Task</a>
      </section>

      <?php if (empty($posted_tasks)): ?>
        <section class="empty-state">
          <svg viewBox="0 0 24 24" width="80" height="80" fill="rgba(77, 225, 193, 0.3)">
            <path d="M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm-5 14H7v-2h7v2zm3-4H7v-2h10v2zm0-4H7V7h10v2z"/>
          </svg>
          <h2>No Tasks Posted Yet</h2>
          <p>Start by posting your first task and reach thousands of users across multiple platforms.</p>
          <a href="post-task.php" class="btn-primary">Post Your First Task</a>
        </section>
      <?php else: ?>
        <section class="tasks-grid">
          <?php foreach ($posted_tasks as $task): 
            $platform = detectPlatformFromUrl($task['target_url']);
            $completed_participants = getParticipantCount($pdo, $task['id'], $user_id);
            $total_participants = $task['participants_count'] ?? $task['total_actions'];
            $completion_rate = $total_participants > 0 ? ($completed_participants / $total_participants) * 100 : 0;
            
            $dynamic_remaining = calculateDynamicRemainingBudget($pdo, $task['id'], $total_participants, $task['budget']);
          ?>
            <article class="task-card <?php echo $task['is_active'] ? 'active' : 'paused'; ?>">
              <div class="task-header">
                <div class="platform-icon" data-platform="<?php echo $platform; ?>">
                  <?php echo getPlatformSVG($platform); ?>
                </div>
                <div class="task-status">
  <?php if ($task['is_permanently_disabled'] == 1): ?>
      <span class="status-badge paused" style="background:#b00020;">Disabled</span>
  <?php elseif ($task['is_active']): ?>
      <span class="status-badge active">Active</span>
  <?php else: ?>
      <span class="status-badge paused">Paused</span>
  <?php endif; ?>
</div>

              </div>
              
              <h3 class="task-title"><?php echo htmlspecialchars($task['title']); ?></h3>
              <p class="task-description"><?php echo htmlspecialchars(substr($task['description'], 0, 100)) . (strlen($task['description']) > 100 ? '...' : ''); ?></p>
              
              <div class="task-stats">
                <div class="stat">
                  <span class="stat-label">Participants</span>
                  <!-- Display completed count / total participants -->
                  <span class="stat-value"><?php echo $completed_participants; ?> / <?php echo $total_participants; ?></span>
                </div>
                
                <div class="stat">
                  <!--<span class="stat-label">Remaining</span>-->
                  <!-- Display dynamic remaining budget based on completed participants count -->
                  <!--<span class="stat-value">₦<?php //echo number_format($dynamic_remaining, 2); ?></span>-->
                </div>
                
                <div class="stat">
                  <span class="stat-label">Price </span>
                  <span class="stat-value">₦<?php echo number_format($task['budget']); ?></span>
                </div>
              </div>
              
              <div class="progress-bar">
                <div class="progress-fill" style="width: <?php echo round($completion_rate); ?>%"></div>
              </div>
              <p class="progress-text"><?php echo round($completion_rate); ?>% Complete</p>
              
              <div class="task-actions">
                <?php if ($task['is_active']): ?>
                  <form method="POST" style="display: inline;">
                    <input type="hidden" name="action" value="pause">
                    <input type="hidden" name="task_id" value="<?php echo $task['id']; ?>">
                    <button type="submit" class="btn-action btn-pause"> <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" fill="currentColor" viewBox="0 0 24 24">
    <path d="M6 4h4v16H6zM14 4h4v16h-4z"/>
  </svg></button>
                  </form>
                <?php else: ?>
                  <form method="POST" style="display: inline;">
                    <input type="hidden" name="action" value="resume">
                    <input type="hidden" name="task_id" value="<?php echo $task['id']; ?>">
                    <button type="submit" class="btn-action btn-resume"><svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" fill="currentColor" viewBox="0 0 24 24">
    <path d="M8 5v14l11-7z"/>
  </svg></button>
                  </form>
                <?php endif; ?>
                
                <button class="btn-action btn-edit" onclick="openEditModal(<?php echo htmlspecialchars(json_encode($task)); ?>)"><svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" fill="currentColor" viewBox="0 0 24 24">
    <path d="M3 17.25V21h3.75L17.81 9.94l-3.75-3.75L3 17.25zM20.71 
    7.04a1.003 1.003 0 0 0 0-1.42l-2.34-2.34a1.003 
    1.003 0 0 0-1.42 0l-1.83 1.83 3.75 3.75 1.84-1.82z"/>
  </svg></button>
                <button class="btn-action btn-extend" onclick="openExtendModal(<?php echo $task['id']; ?>, '<?php echo $platform; ?>')"> <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" fill="currentColor" viewBox="0 0 24 24">
    <path d="M12 8v5l4 2 .75-1.23-3.25-1.52V8h-1.5zM12 2a10 10 0 1 0 0 18 10 10 0 0 0 0-16z"/>
  </svg></button>
                
                <!-- Removed delete button completely -->
              </div>
              
              <div class="task-meta">
                <span>Posted: <?php echo date('M d, Y', strtotime($task['created_at'])); ?></span>
                <a href="<?php echo htmlspecialchars($task['task_url']); ?>" target="_blank" class="task-link">View Task →</a>
              </div>
            </article>
          <?php endforeach; ?>
        </section>
      <?php endif; ?>

   
  <div id="editModal" class="modal">
    <div class="modal-content">
      <span class="close" onclick="closeEditModal()">&times;</span>
      <h2>Edit Task</h2>
      <form method="POST" id="editForm">
        <input type="hidden" name="action" value="edit">
        <input type="hidden" name="task_id" id="edit_task_id">
        
        <div class="form-group">
          <label for="edit_title">Task Title</label>
          <input type="text" id="edit_title" name="title" required>
        </div>
        
        <div class="form-group">
          <label for="edit_description">Description</label>
          <textarea id="edit_description" name="description" rows="4" required></textarea>
        </div>
        
        <div class="form-group">
          <label for="edit_task_url">Task URL</label>
          <input type="url" id="edit_task_url" name="task_url" required>
          <small>Note: URL must match the original task type</small>
        </div>
        
        <button type="submit" class="btn-primary">Save Changes</button>
      </form>
    </div>
  </div>

   
  <div id="extendModal" class="modal">
    <div class="modal-content">
      <span class="close" onclick="closeExtendModal()">&times;</span>
      <h2>Extend Task Participants</h2>
      <form method="POST" id="extendForm" onsubmit="return validateExtendForm()">
        <input type="hidden" name="action" value="extend">
        <input type="hidden" name="task_id" id="extend_task_id">
        
        <div class="form-group">
          <label for="additional_participants">Additional Participants</label>
          <input type="text" id="additional_participants" name="additional_participants" value="10" inputmode="numeric" pattern="[0-9]*" required>
          <small>Minimum 10, Maximum 1000 participants</small>
        </div>
        
        <div class="pricing-summary">
          <h3>Extension Cost</h3>
          <div class="summary-row">
            <span>Platform:</span>
            <span id="extend_platform">--</span>
          </div>
          <div class="summary-row">
            <span>Additional Participants:</span>
            <span id="extend_participants">10</span>
          </div>
          <div class="summary-row total">
            <span>Total Cost:</span>
            <span id="extend_cost">₦0.00</span>
          </div>
          <p class="note">Payment will be deducted from your Prime earnings.</p>
        </div>
        
        <button type="submit" class="btn-primary">Extend Task</button>
      </form>
    </div>
  </div>

   <nav class="mobile-fintech-footer">
    
  <a href="dashboard.php">
    <svg viewBox="0 0 24 24"><path d="M12 3a9 9 0 1 1 0 18 9 9 0 0 1 0-18Zm1 4h-2v6h6v-2h-4V7Z"/></svg>
    <span>Dashboard</span>
  </a>

  <!-- Premium (crown icon) -->
  <a href="membership.php">
    <svg viewBox="0 0 24 24"><path d="M5 7l2.5 5 4.5-4 4.5 4L19 7l2 13H3l2-13Z"/></svg>
    <span>Premium</span>
  </a>

  <a href="post-task.php">
<svg viewBox="0 0 24 24" aria-hidden="true">
  <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8l-6-6Zm1 14h-3v3h-2v-3H7v-2h3v-3h2v3h3v2Zm-3-9V3.5L18.5 8H12Z"/>
</svg>
    
    <span>Advert Post</span>
  </a>
  
  

  <a href="history.php">
  <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
    <path d="M13 3a9 9 0 1 0 9 9h-2a7 7 0 1 1-7-7V3l4 4-4 4V7a5 5 0 1 0 5 5h2a7 7 0 1 1-7-7z"/>
  </svg>
  <span>History</span>
</a>


  <a href="profile.php">
    <svg viewBox="0 0 24 24"><path d="M12 2a6 6 0 0 1 6 6c0 3.31-2.69 6-6 6s-6-2.69-6-6a6 6 0 0 1 6-6Zm0 14c4.42 0 8 1.79 8 4v2H4v-2c0-2.21 3.58-4 8-4Z"/></svg>
    <span>Profile</span>
  </a>
</nav>

    </main>
  </div>

  <!-- Added toast message styles from profile.php -->
  <style>
    /* Toast message styling to match earnova design */
    .toast-message {
      position: fixed;
      top: 20px;
      right: -400px;
      padding: 16px 24px;
      border-radius: 12px;
      color: white;
      font-family: 'Segoe UI', sans-serif;
      font-size: 15px;
      z-index: 1000;
      opacity: 0;
      box-shadow: 0 10px 40px rgba(0, 0, 0, 0.2);
      transition: right 0.6s ease, opacity 0.6s ease;
    }

    .toast-message.success {
      background: rgba(77, 225, 193, 0.95);
      color: #030922;
      box-shadow: 0 10px 40px rgba(77, 225, 193, 0.4);
    }

    .toast-message.error {
      background: rgba(255, 77, 77, 0.95);
      color: #fff;
      box-shadow: 0 10px 40px rgba(255, 77, 77, 0.4);
    }

    .toast-message.show {
      right: 20px;
      opacity: 1;
    }
  </style>

<script>
const isMember = <?php echo $is_member ? 'true' : 'false'; ?>;
const platformPrices = <?php echo json_encode($platform_prices); ?>;
let currentExtendPlatform = 'tiktok';

// Open edit modal
function openEditModal(task) {
  document.getElementById('edit_task_id').value = task.id;
  document.getElementById('edit_title').value = task.title;
  document.getElementById('edit_description').value = task.description;
  document.getElementById('edit_task_url').value = task.task_url;
  document.getElementById('editModal').style.display = 'block';
}

// Close edit modal
function closeEditModal() {
  document.getElementById('editModal').style.display = 'none';
}

// Open extend modal
function openExtendModal(taskId, platform) {
  currentExtendPlatform = platform;
  document.getElementById('extend_task_id').value = taskId;
  document.getElementById('extend_platform').textContent = platformPrices[platform].name;
  calculateExtensionCost();
  document.getElementById('extendModal').style.display = 'block';
}

// Close extend modal
function closeExtendModal() {
  document.getElementById('extendModal').style.display = 'none';
}

// Calculate extension cost and update DOM
function calculateExtensionCost() {
  let participantsInput = document.getElementById('additional_participants');
  let participants = parseInt(participantsInput.value) || 0;

  if (isNaN(participants) || participants === 0) {
    participants = 10;
  }

  const basePrice = isMember ? platformPrices[currentExtendPlatform].member : platformPrices[currentExtendPlatform].non_member;
  const totalCost = (participants / 10) * basePrice;

  document.getElementById('extend_participants').textContent = participants;
  document.getElementById('extend_cost').textContent = '₦' + Math.round(totalCost).toLocaleString('en-NG');
}

// Validate extend form on submission
function validateExtendForm() {
  let participantsInput = document.getElementById('additional_participants');
  let participants = parseInt(participantsInput.value) || 0;

  if (isNaN(participants) || participants === '') {
    showToastError('Please enter a valid number of participants');
    return false;
  }

  if (participants < 10) {
    showToastError('Minimum 10 additional participants required');
    return false;
  }

  if (participants > 1000) {
    showToastError('Maximum 1000 additional participants allowed');
    return false;
  }

  return true;
}

// Show toast error
function showToastError(message) {
  const toast = document.createElement('div');
  toast.className = 'toast-message error show';
  toast.textContent = message;
  document.body.appendChild(toast);

  setTimeout(() => {
    toast.classList.remove('show');
    setTimeout(() => toast.remove(), 600);
  }, 5000);
}

// Live update as you type
document.getElementById('additional_participants').addEventListener('input', calculateExtensionCost);

// Close modals when clicking outside
window.onclick = function(event) {
  if (event.target.classList.contains('modal')) {
    event.target.style.display = 'none';
  }
}

// Toast messages
function initializeToast() {
  const successToast = document.getElementById("toast-success");
  const errorToast = document.getElementById("toast-error");

  function showToast(toast) {
    if (!toast) return;
    setTimeout(() => toast.classList.add("show"), 100);
    setTimeout(() => toast.classList.remove("show"), 5000);
  }

  showToast(successToast);
  showToast(errorToast);
}

// Initialize toasts when page loads
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', initializeToast);
} else {
  initializeToast();
}
</script>

  
  <?php

function getPlatformSVG($platform) {
    $svgs = [
        'tiktok' => '<svg viewBox="0 0 24 24" fill="#ffffff" aria-hidden="true"><path d="M19.59 6.69a4.83 4.83 0 0 1-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 0 1-5.2 1.74 2.89 2.89 0 0 1 2.31-4.64 2.93 2.93 0 0 1 .88.13V9.4a6.84 6.84 0 0 0-1-.05A6.33 6.33 0 0 0 5 20.1a6.34 6.34 0 0 0 10.86-4.43v-7a8.16 8.16 0 0 0 4.77 1.52v-3.4a4.85 4.85 0 0 1-1-.1z"/></svg>',

        'instagram' => '<svg viewBox="0 0 24 24" aria-hidden="true"><defs><linearGradient id="igGrad" x1="0" x2="1" y1="0" y2="1"><stop offset="0" stop-color="#f58529"/><stop offset="0.3" stop-color="#dd2a7b"/><stop offset="0.6" stop-color="#8134af"/><stop offset="1" stop-color="#515bd4"/></linearGradient></defs><path fill="url(#igGrad)" d="M7.8 2h8.4C19.4 2 22 4.6 22 7.8v8.4a5.8 5.8 0 0 1-5.8 5.8H7.8C4.6 22 2 19.4 2 16.2V7.8A5.8 5.8 0 0 1 7.8 2m-.2 2A3.6 3.6 0 0 0 4 7.6v8.8C4 18.39 5.61 20 7.6 20h8.8a3.6 3.6 0 0 0 3.6-3.6V7.6C20 5.61 18.39 4 16.4 4H7.6m9.65 1.5a1.25 1.25 0 0 1 1.25 1.25A1.25 1.25 0 0 1 17.25 8 1.25 1.25 0 0 1 16 6.75a1.25 1.25 0 0 1 1.25-1.25M12 7a5 5 0 0 1 5 5 5 5 0 0 1-5 5 5 5 0 0 1-5-5 5 5 0 0 1 5-5m0 2a3 3 0 0 0-3 3 3 3 0 0 0 3 3 3 3 0 0 0 3-3 3 3 0 0 0-3-3z"/></svg>',

        'whatsapp' => '<svg viewBox="0 0 24 24" fill="#25D366" aria-hidden="true"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/></svg>',
        
        'playstore' => '<svg width="24" height="24" viewBox="0 0 256 256" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M29.24 20.6199C27.13 22.7299 26 25.6399 26 28.2599V227.66C26 230.28 27.13 233.19 29.24 235.3L29.87 235.93L134.87 130.93V130.3L29.24 20.6199Z" fill="#EA4335"/><path d="M178.51 174.77L134.87 131.12V130.93L178.51 87.2899L179.24 87.9199L232.19 118.72C247.65 127.95 247.65 144.1 232.19 153.33L179.24 184.13L178.51 184.76V174.77Z" fill="#FBBC04"/><path d="M178.51 87.2899L134.87 130.93L29.24 20.6199C31.35 18.5099 34.26 17.3799 36.88 17.3799C39.5 17.3799 42.41 18.5099 44.52 20.6199L178.51 87.2899Z" fill="#4285F4"/><path d="M178.51 174.77L44.52 241.44C42.41 243.55 39.5 244.68 36.88 244.68C34.26 244.68 31.35 243.55 29.24 241.44L134.87 131.12L178.51 174.77Z" fill="#34A853"/></svg>',

        'twitter' => '<svg viewBox="0 0 24 24" fill="#ffffff" aria-hidden="true" xmlns="http://www.w3.org/2000/svg">
        <path fill="currentColor" d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24h-6.66l-5.214-6.817-5.97 6.817H1.67l7.73-8.835L1.254 2.25h6.83l4.713 6.231 5.447-6.231zm-1.161 17.52h1.833L7.084 4.126H5.117l11.966 15.644z"/>
         </svg>',

        'youtube' => '<svg viewBox="0 0 24 24" fill="#FF0000" aria-hidden="true"><path d="M10 15l5.19-3L10 9v6m11.56-7.83c.13.47.22 1.1.28 1.9.07.8.1 1.49.1 2.09L22 12c0 2.19-.16 3.8-.44 4.83-.25.9-.83 1.48-1.73 1.73-.47.13-1.33.22-2.65.28-1.3.07-2.49.1-3.59.1L12 19c-4.19 0-6.8-.16-7.83-.44-.9-.25-1.48-.83-1.73-1.73-.13-.47-.22-1.1-.28-1.9-.07-.8-.1-1.49-.1-2.09L2 12c0-2.19.16-3.8.44-4.83.25-.9.83-1.48 1.73-1.73.47-.13 1.33-.22 2.65-.28 1.3-.07 2.49-.1 3.59-.1L12 5c4.19 0 6.8.16 7.83.44.9.25 1.48.83 1.73 1.73z"/></svg>',

        'facebook' => '<svg viewBox="0 0 24 24" fill="#1877F2" aria-hidden="true"><path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/></svg>',

        'linkedin' => '<svg viewBox="0 0 24 24" fill="#0077B5" aria-hidden="true"><path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433c-1.144 0-2.063-.926-2.063-2.065 0-1.138.92-2.063 2.063-2.063 1.14 0 2.064.925 2.064 2.063 0 1.139-.925 2.065-2.064 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z"/></svg>',

        'telegram' => '<svg viewBox="0 0 24 24" fill="#0088CC" aria-hidden="true"><path d="M11.944 0A12 12 0 0 0 0 12a12 12 0 0 0 12 12 12 12 0 0 0 12-12A12 12 0 0 0 12 0a12 12 0 0 0-.056 0zm4.962 7.224c.1-.002.321.023.465.14a.506.506 0 0 1 .171.325c.016.093.036.306.02.472-.18 1.898-.962 6.502-1.36 8.627-.168.9-.499 1.201-.82 1.23-.696.065-1.225-.46-1.9-.902-1.056-.693-1.653-1.124-2.678-1.8-1.185-.78-.417-1.21.258-1.91.177-.184 3.247-2.977 3.307-3.23.007-.032.014-.15-.056-.212s-.174-.041-.249-.024c-.106.024-1.793 1.14-5.061 3.345-.48.33-.913.49-1.302.48-.428-.008-1.252-.241-1.865-.44-.752-.245-1.349-.374-1.297-.789.027-.216.325-.437.893-.663 3.498-1.524 5.83-2.529 6.998-3.014 3.332-1.386 4.025-1.627 4.476-1.635z"/></svg>',

        'twitter' => '<svg viewBox="0 0 24 24" aria-hidden="true"><g stroke="#ffffff" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 3l18 18"/><path d="M21 3L3 21"/></g></svg>',

        'snapchat' => '<svg viewBox="0 0 24 24" fill="#FFFC00" aria-hidden="true"><path d="M12.206.793c.99 0 4.347.276 5.93 3.821.529 1.193.403 3.219.299 4.847l-.003.06c-.012.18-.022.345-.03.51.075.045.203.09.401.09.3-.016.659-.12 1.033-.301.165-.088.344-.104.464-.104.182 0 .359.029.509.09.45.149.734.479.734.838.015.449-.39.839-1.213 1.168-.089.029-.209.075-.344.119-.45.135-1.139.36-1.333.81-.09.224-.061.524.12.868l.015.015c.06.136 1.526 3.475 4.791 4.014.255.044.435.27.42.509 0 .075-.015.149-.045.225-.24.569-1.273.988-3.146 1.271-.059.091-.12.375-.164.57-.029.179-.074.36-.134.553-.076.271-.27.405-.555.405h-.03c-.135 0-.313-.031-.538-.074-.36-.075-.765-.135-1.273-.135-.3 0-.599.015-.913.074-.6.104-1.123.464-1.723.884-.853.599-1.826 1.288-3.294 1.288-.06 0-.119-.015-.18-.015h-.149c-1.468 0-2.427-.675-3.279-1.288-.599-.42-1.107-.779-1.707-.884-.314-.045-.629-.074-.928-.074-.54 0-.958.089-1.272.149-.211.043-.391.074-.54.074-.374 0-.523-.224-.583-.42-.061-.192-.09-.389-.135-.567-.046-.181-.105-.494-.166-.57-1.918-.222-2.95-.642-3.189-1.226-.031-.063-.052-.15-.055-.225-.015-.243.165-.465.42-.509 3.264-.54 4.73-3.879 4.791-4.01l.016-.029c.18-.345.224-.645.119-.869-.195-.434-.884-.658-1.332-.809-.121-.029-.24-.074-.346-.119-1.107-.435-1.257-.93-1.197-1.273.09-.479.674-.793 1.168-.793.146 0 .27.029.383.074.42.194.789.3 1.104.3.234 0 .384-.06.465-.105l-.046-.569c-.098-1.626-.225-3.651.307-4.837C7.392 1.077 10.739.807 11.727.807l.419-.015h.06z"/></svg>',

        'youtube' => '<svg viewBox="0 0 24 24" fill="#FF0000" aria-hidden="true"><path d="M10 15l5.19-3L10 9v6m11.56-7.83c.13.47.22 1.1.28 1.9.07.8.1 1.49.1 2.09L22 12c0 2.19-.16 3.8-.44 4.83-.25.9-.83 1.48-1.73 1.73-.47.13-1.33.22-2.65.28-1.3.07-2.49.1-3.59.1L12 19c-4.19 0-6.8-.16-7.83-.44-.9-.25-1.48-.83-1.73-1.73-.13-.47-.22-1.1-.28-1.9-.07-.8-.1-1.49-.1-2.09L2 12c0-2.19.16-3.8.44-4.83.25-.9.83-1.48 1.73-1.73.47-.13 1.33-.22 2.65-.28 1.3-.07 2.49-.1 3.59-.1L12 5c4.19 0 6.8.16 7.83.44.9.25 1.48.83 1.73 1.73z"/></svg>',

       
        
    
        'pinterest' => '<svg viewBox="0 0 24 24" fill="#E60023"><path d="M12.017 0C5.396 0 .029 5.367.029 11.987c0 5.079 3.158 9.417 7.618 11.162-.105-.949-.199-2.403.041-3.439.219-.937 1.406-5.957 1.406-5.957s-.359-.72-.359-1.781c0-1.663.967-2.911 2.168-2.911 1.024 0 1.518.769 1.518 1.688 0 1.029-.653 2.567-.992 3.992-.285 1.193.6 2.165 1.775 2.165 2.128 0 3.768-2.245 3.768-5.487 0-2.861-2.063-4.869-5.008-4.869-3.41 0-5.409 2.562-5.409 5.199 0 1.033.394 2.143.889 2.741.099.12.112.225.085.345-.09.375-.293 1.199-.334 1.363-.053.225-.172.271-.401.165-1.495-.69-2.433-2.878-2.433-4.646 0-3.776 2.748-7.252 7.92-7.252 4.158 0 7.392 2.967 7.392 6.923 0 4.135-2.607 7.462-6.233 7.462-1.214 0-2.354-.629-2.758-1.379l-.749 2.848c-.269 1.045-1.004 2.352-1.498 3.146 1.123.345 2.306.535 3.55.535 6.607 0 11.985-5.365 11.985-11.987C23.97 5.39 18.592.026 11.985.026L12.017 0z"/></svg>',

        'reddit' => '<svg viewBox="0 0 24 24" fill="#FF4500" aria-hidden="true"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-3 13.5a1.5 1.5 0 1 1 0-3 1.5 1.5 0 0 1 0 3zm6 0a1.5 1.5 0 1 1 0-3 1.5 1.5 0 0 1 0 3zM10.5 14a3 3 0 0 1 3-3h-2.5a3 3 0 1 1 0 6h2.5a3 3 0 1 1-3-3z"/></svg>',

        'discord' => '<svg viewBox="0 0 24 24" fill="#5865F2" aria-hidden="true"><path d="M20.317 4.492c-1.53-.69-3.17-1.2-4.885-1.49a.075.075 0 00-.079.036c-.211.375-.445.864-.607 1.25a17.97 17.97 0 00-5.406 0c-.162-.386-.405-.875-.616-1.25a.077.077 0 00-.079-.036c-1.716.29-3.354.8-4.885 1.49a.07.07 0 00-.032.027C1.9 8.55.27 12.45 1.635 16.25a.075.075 0 00.029.052c1.582.973 3.112 1.565 4.615 1.96.03.008.061 0 .076-.021.415-.566.784-1.156 1.095-1.776a.075.075 0 00-.041-.104c-.606-.229-1.184-.499-1.738-.8a.075.075 0 01-.008-.125c.116-.088.233-.18.346-.273a.074.074 0 01.076-.01c3.64 1.663 7.581 1.663 11.183 0a.074.074 0 01.077.009c.113.094.23.185.346.274a.075.075 0 01-.006.125c-.554.3-1.131.571-1.738.8a.075.075 0 00-.041.105c.311.62.68 1.21 1.095 1.776a.075.075 0 00.076.021c1.503-.395 3.033-.987 4.615-1.96a.075.075 0 00.031-.03z"/></svg>',

        'twitch' => '<svg viewBox="0 0 24 24" fill="#9146FF" aria-hidden="true"><path d="M21.484 5.612a6.722 6.722 0 00-1.66-2.205 7.008 7.008 0 00-2.395-1.718 7.178 7.178 0 00-3.016-.445H7.362a7.177 7.177 0 00-3.016.445 6.721 6.721 0 00-1.66 2.205 6.999 6.999 0 00-1.177 2.649 7.326 7.326 0 00-.438 3.367v4.402c0 1.075.13 2.115.438 3.367a6.72 6.72 0 001.66 2.205 7.008 7.008 0 002.395 1.718 7.178 7.178 0 003.016.445h6.762a7.178 7.178 0 003.016-.445 6.721 6.721 0 001.66-2.205 7.008 7.008 0 001.177-2.649 7.325 7.325 0 00.438-3.367v-4.402c0-1.075-.13-2.115-.438-3.367zm-2.845 9.682a3.516 3.516 0 01-.739 1.335 3.425 3.425 0 01-1.195 1.041 3.506 3.506 0 01-1.584.445H7.362a3.506 3.506 0 01-1.584-.445 3.425 3.425 0 01-1.195-1.041 3.515 3.515 0 01-.739-1.335 3.645 3.645 0 01-.261-1.771v-4.402a3.645 3.645 0 01.261-1.771 3.516 3.516 0 01.739-1.335 3.425 3.425 0 011.195-1.041 3.506 3.506 0 011.584-.445h6.762a3.506 3.506 0 011.584.445 3.425 3.425 0 011.195 1.041 3.516 3.516 0 01.739 1.335 3.645 3.645 0 01-.261 1.771v4.402a3.645 3.645 0 01-.261 1.771z"/></svg>',

        'audiomack' => '<svg viewBox="0 0 24 24" fill="#FF8800" aria-hidden="true"><path d="M12 2L2 7v10l10 5 10-5V7l-10-5zm0 2.18L19.82 8 12 11.82 4.18 8 12 4.18zM4 9.48l7 3.5v7.84l-7-3.5V9.48zm16 0v7.84l-7 3.5v-7.84l7-3.5z"/></svg>',

        'boomplay' => '<svg viewBox="0 0 24 24" fill="#E91E63" aria-hidden="true"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 14.5v-9l6 4.5-6 4.5z"/></svg>',

        'spotify' => '<svg viewBox="0 0 24 24" fill="#1DB954" aria-hidden="true"><path d="M12 0C5.4 0 0 5.4 0 12s5.4 12 12 12 12-5.4 12-12S18.66 0 12 0zm5.521 17.34c-.24.359-.66.48-1.021.24-2.82-1.74-6.36-2.101-10.561-1.141-.418.122-.779-.179-.899-.539-.12-.421.18-.78.54-.9 4.56-1.021 8.52-.6 11.64 1.32.42.18.479.659.301 1.02zm1.44-3.3c-.301.42-.841.6-1.262.3-3.239-1.98-8.159-2.58-11.939-1.38-.479.12-1.02-.12-1.14-.6-.12-.48.12-.1.6-1.141C9.6 9.9 15 10.561 18.72 12.84c.361.181.54.78.241 1.2zm.12-3.36C15.24 8.4 8.82 8.16 5.16 9.301c-.6.179-1.2-.181-1.38-.721-.18-.601.18-.72.72-1.381 4.26-1.26 11.28-1.02 15.721 1.621.539.3.719 1.02.419 1.56-.299.421-1.02.599-1.559.3z"/></svg>',

        'applemusic' => '<svg viewBox="0 0 24 24" fill="#FA243C" aria-hidden="true"><path d="M23.994 6.124a9.23 9.23 0 0 0-.24-2.19c-.317-1.31-1.062-2.31-2.18-3.043a5.022 5.022 0 0 0-1.877-.726 10.496 10.496 0 0 0-1.564-.15c-.04-.003-.083-.01-.124-.013H5.986c-.152.01-.303.017-.455.026-.747.043-1.49.123-2.193.4-1.336.53-2.3 1.452-2.865 2.78-.192.448-.292.925-.363 1.408a10.61 10.61 0 0 0-.1 1.18c0 .032-.007.062-.01.093v12.223c.01.14.017.283.027.424.05.815.154 1.624.497 2.373.65 1.42 1.738 2.353 3.234 2.801.42.127.856.187 1.293.228.555.053 1.11.06 1.667.06h11.03a12.5 12.5 0 0 0 1.57-.1c.822-.106 1.596-.35 2.296-.81a5.046 5.046 0 0 0 1.88-2.207c.186-.42.293-.87.344-1.333.065-.586.092-1.178.092-1.77V6.124z"/></svg>',

        'soundcloud' => '<svg viewBox="0 0 24 24" fill="#FF5500" aria-hidden="true"><path d="M1.175 12.225c-.051 0-.094.046-.101.1l-.233 2.154.233 2.105c.007.058.05.098.101.098.05 0 .09-.04.099-.098l.255-2.105-.27-2.154c0-.057-.045-.1-.09-.1m-.899.828c-.06 0-.091.037-.104.094L0 14.479l.165 1.308c0 .055.045.094.09.094s.089-.045.104-.104l.21-1.319-.21-1.334c0-.061-.044-.09-.09-.09m1.83-1.229c-.061 0-.12.045-.12.104l-.21 2.563.225 2.458c0 .06.045.12.119.12.061 0 .105-.061.121-.12l.254-2.474-.254-2.458c0-.06-.045-.12.09-.09m.945-.089c-.075 0-.135.06-.15.135l-.193 2.64.21 2.458c0 .06.045.12.119.12.061 0 .105-.061.121-.12l.254-2.474-.254-2.458c0-.06-.045-.12.09-.09m.959-.166c-.09 0-.15.074-.165.148l-.195 2.883.209 2.714c.016.09.075.165.166.165.074 0 .149-.074.164-.165l.226-2.714-.226-2.883c-.015-.091-.075-.165-.165-.165m.971-.15c-.09 0-.166.074-.18.165l-.18 3.046.18 2.883c.015.09.075.165.18.165.09 0 .164-.074.18-.165l.209-2.883-.209-3.046c-.016-.09-.09-.165-.18-.165m.986-.104c-.104 0-.18.09-.194.179l-.18 3.165.18 2.883c.015.104.09.18.194.18.09 0 .18-.09.195-.18l.209-2.883-.209-3.165c-.015-.104-.09-.18-.195-.18m.987-.045c-.105 0-.195.09-.21.195l-.164 3.195.164 2.883c.016.119.105.225.225.225.119 0 .21-.105.225-.225l.179-2.82-.179-3.27c-.016-.135-.12-.254-.255-.254m1.003-.09c-.135 0-.314.149-.33.329l-.089 3.629.089 2.82c.016.18.15.33.33.33.179 0 .313-.15.329-.33l.119-2.82-.119-3.629c-.016-.18-.15-.329-.329-.329m1.018-.09c-.18 0-.314.149-.33.329l-.089 3.629.089 2.82c.016.18.15.33.33.33.179 0 .313-.15.329-.33l.119-2.82-.119-3.629c-.016-.18-.15-.329-.329-.329m6.628 1.763c-.195 0-.375.045-.539.104v7.008c0 .06.045.104.104.104h8.254c.81 0 1.469-.659 1.469-1.469 0-2.025-1.643-3.668-3.668-3.668-.405 0-.795.074-1.155.195-.24-1.38-1.425-2.429-2.865-2.429-.405 0-.795.09-1.155.24-.195-.09-.405-.135-.63-.135z"/></svg>',
        
        'website' => '<svg viewBox="0 0 24 24" fill="#ffffff" aria-hidden="true"><path d="M12 2a10 10 0 1 0 10 10A10.011 10.011 0 0 0 12 2Zm6.93 6h-3.27a15.27 15.27 0 0 0-1.2-3.51A8.025 8.025 0 0 1 18.93 8Zm-6.93-4.95c.69.89 1.39 2.19 1.8 3.95h-3.6c.41-1.76 1.11-3.06 1.8-3.95ZM8.54 10a18.5 18.5 0 0 1 .63-3h5.66a18.5 18.5 0 0 1 .63 3Zm0 2h6.92a18.5 18.5 0 0 1-.63 3H9.17a18.5 18.5 0 0 1-.63-3Zm.17 5h5.66c-.41 1.76-1.11 3.06-1.8 3.95-.69-.89-1.39-2.19-1.8-3.95Zm6.66 3.51c.5-1.1.89-2.33 1.2-3.51h3.27a8.025 8.025 0 0 1-4.47 3.51ZM5.2 16h3.27c.31 1.18.7 2.41 1.2 3.51A8.025 8.025 0 0 1 5.2 16Zm4.47-11.51c-.5 1.1-.89 2.33-1.2 3.51H5.2a8.025 8.025 0 0 1 4.47-3.51ZM4.07 14a8.025 8.025 0 0 1 0-4h3.27a20.9 20.9 0 0 0 0 4Z"/></svg>',

    ];

    return $svgs[$platform] ?? $svgs['tiktok']; // Default to TikTok SVG
}
?>
</body>
</html>
