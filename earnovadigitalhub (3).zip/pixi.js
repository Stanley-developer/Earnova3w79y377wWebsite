const app = new PIXI.Application({
    width: 800,
    height: 600,
    backgroundColor: 0xB8864B,
    antialias: true,
    resolution: 1
});
document.body.appendChild(app.view);
const SUITS = [
    {name: 'Circle', color: 0xde2d2d, symbol: 'circle'},
    {name: 'Cross', color: 0x2156c9, symbol: 'cross'},
    {name: 'Triangle', color: 0x2ea13b, symbol: 'triangle'},
    {name: 'Star', color: 0xf3c81c, symbol: 'star'},
    {name: 'Square', color: 0x8a26a6, symbol: 'square'}
];
const SUIT_NAMES = SUITS.map(s => s.name);
const WHOT_CARD = {number: 20, suit: 'Whot', isWhot: true};
const CARD_WIDTH = 80, CARD_HEIGHT = 120;
const HAND_Y = 460, AI_HAND_Y = 40;
const DISCARD_X = 400, DISCARD_Y = 260;
const MARKET_X = 650, MARKET_Y = 120;
const PLAYER_COUNT = 2;
const HAND_SIZE = 5;
function shuffle(arr) {
    for (let i = arr.length - 1; i > 0; i--) {
        let j = Math.floor(Math.random() * (i + 1));
        [arr[i], arr[j]] = [arr[j], arr[i]];
    }
}
function cloneCard(card) {
    return {number: card.number, suit: card.suit, isWhot: card.isWhot || false};
}
function cardEquals(a, b) {
    return a.number === b.number && a.suit === b.suit && !!a.isWhot === !!b.isWhot;
}
function getSuitObj(suit) {
    if (suit === 'Whot') return null;
    return SUITS.find(s => s.name === suit);
}
function getCardColor(card) {
    if (card.isWhot) return 0xfad02e;
    let suit = getSuitObj(card.suit);
    return suit ? suit.color : 0xffffff;
}
function getCardSymbol(card) {
    if (card.isWhot) return 'crown';
    let suit = getSuitObj(card.suit);
    return suit ? suit.symbol : '';
}
function getCardValue(card) {
    if (card.isWhot) return 0;
    return card.number;
}
function createDeck() {
    let deck = [];
    for (let s = 0; s < SUITS.length; s++) {
        for (let n = 1; n <= 14; n++) {
            deck.push({number: n, suit: SUITS[s].name, isWhot: false});
        }
    }
    for (let i = 0; i < 4; i++) deck.push({number: 20, suit: 'Whot', isWhot: true});
    return deck;
}
function drawCardGraphics(card, faceUp = true, highlight = false) {
    let g = new PIXI.Graphics();
    if (!faceUp) {
        g.beginFill(0xb71c1c);
        g.drawRoundedRect(0, 0, CARD_WIDTH, CARD_HEIGHT, 12);
        g.endFill();
        for (let i = 0; i < 3; i++) {
            g.lineStyle(1, 0xffffff, 0.2);
            g.drawCircle(20 + i * 20, 30 + i * 15, 12);
        }
        return g;
    }
    g.beginFill(0xffffff);
    g.drawRoundedRect(0, 0, CARD_WIDTH, CARD_HEIGHT, 12);
    g.endFill();
    if (highlight) {
        let glow = new PIXI.filters.GlowFilter({distance: 8, outerStrength: 2, color: 0xffe066});
        g.filters = [glow];
    }
    let color = getCardColor(card);
    if (!card.isWhot) {
        drawCardSymbol(g, getCardSymbol(card), color, 16, 14, 34, 0.8);
        let number = new PIXI.Text(card.number + '', {
            fontFamily: 'Arial',
            fontWeight: 'bold',
            fontSize: 38,
            fill: color,
            align: 'center'
        });
        number.anchor.set(0.5);
        number.x = CARD_WIDTH / 2;
        number.y = CARD_HEIGHT / 2 + 10;
        g.addChild(number);
    } else {
        drawCardSymbol(g, 'crown', 0xfad02e, CARD_WIDTH / 2, 24, 38, 1);
        let text = new PIXI.Text('20', {
            fontFamily: 'Arial',
            fontWeight: 'bold',
            fontSize: 36,
            fill: 0x222222
        });
        text.anchor.set(0.5);
        text.x = CARD_WIDTH / 2;
        text.y = CARD_HEIGHT / 2 + 12;
        g.addChild(text);
        let whot = new PIXI.Text('WHOT', {
            fontFamily: 'Arial',
            fontWeight: 'bold',
            fontSize: 18,
            fill: 0xfad02e
        });
        whot.anchor.set(0.5);
        whot.x = CARD_WIDTH / 2;
        whot.y = CARD_HEIGHT - 22;
        g.addChild(whot);
    }
    return g;
}
function drawCardSymbol(g, type, color, x, y, size, alpha = 1) {
    g.beginFill(color, alpha);
    if (type === 'circle') {
        g.drawCircle(x, y, size / 2);
    } else if (type === 'cross') {
        let w = size / 2, h = size / 6;
        g.drawRect(x - w, y - h / 2, size, h);
        g.drawRect(x - h / 2, y - w, h, size);
    } else if (type === 'triangle') {
        g.drawPolygon([
            x, y - size / 2,
            x - size / 2, y + size / 2,
            x + size / 2, y + size / 2
        ]);
    } else if (type === 'star') {
        let spikes = 5, outer = size / 2, inner = size / 4;
        let rot = Math.PI / 2 * 3, step = Math.PI / spikes;
        let pts = [];
        for (let i = 0; i < spikes; i++) {
            pts.push(
                x + Math.cos(rot) * outer,
                y + Math.sin(rot) * outer
            );
            rot += step;
            pts.push(
                x + Math.cos(rot) * inner,
                y + Math.sin(rot) * inner
            );
            rot += step;
        }
        g.drawPolygon(pts);
    } else if (type === 'square') {
        g.drawRect(x - size / 2, y - size / 2, size, size);
    } else if (type === 'crown') {
        g.moveTo(x - size / 2, y + size / 4);
        g.lineTo(x - size / 3, y - size / 3);
        g.lineTo(x - size / 6, y + size / 8);
        g.lineTo(x, y - size / 3);
        g.lineTo(x + size / 6, y + size / 8);
        g.lineTo(x + size / 3, y - size / 3);
        g.lineTo(x + size / 2, y + size / 4);
        g.lineTo(x - size / 2, y + size / 4);
        g.endFill();
        g.beginFill(color, 0.5);
        g.drawRect(x - size / 2, y + size / 4, size, size / 6);
    }
    g.endFill();
}
function createCardSprite(card, faceUp = true) {
    let g = drawCardGraphics(card, faceUp);
    let s = new PIXI.Sprite(app.renderer.generateTexture(g));
    s.card = cloneCard(card);
    s.faceUp = faceUp;
    return s;
}
function getValidPlays(hand, topCard, whotShape) {
    return hand.filter(card => isValidPlay(card, topCard, whotShape));
}
function isValidPlay(card, topCard, whotShape) {
    if (card.isWhot) return true;
    if (topCard.isWhot && whotShape) {
        return card.suit === whotShape;
    }
    return card.number === topCard.number || card.suit === topCard.suit;
}
function getRandomElement(arr) {
    return arr[Math.floor(Math.random() * arr.length)];
}
class WhotGame {
    constructor() {
        this.state = 'menu';
        this.container = new PIXI.Container();
        app.stage.addChild(this.container);
        this.resize();
        window.addEventListener('resize', () => this.resize());
        this.initMenu();
    }
    resize() {
        let scale = Math.min(window.innerWidth / 800, window.innerHeight / 600);
        app.stage.scale.set(scale);
        app.renderer.resize(window.innerWidth, window.innerHeight);
        this.container.x = (window.innerWidth - 800 * scale) / (2 * scale);
        this.container.y = (window.innerHeight - 600 * scale) / (2 * scale);
    }
    clear() {
        this.container.removeChildren();
    }
    initMenu() {
        this.clear();
        this.state = 'menu';
        let bg = new PIXI.Graphics();
        bg.beginFill(0xB8864B);
        bg.drawRect(0, 0, 800, 600);
        bg.endFill();
        this.container.addChild(bg);
        let title = new PIXI.Text('Nigerian Whot', {fontFamily:'Arial',fontWeight:'bold',fontSize:44,fill:0xffffff});
        title.anchor.set(0.5);
        title.x = 400; title.y = 90;
        this.container.addChild(title);
        let playAI = this.makeButton('Play vs AI', 400, 240, () => {
            this.mode = 'ai';
            this.startGame();
        });
        this.container.addChild(playAI);
        let playHotseat = this.makeButton('Hotseat 2P', 400, 320, () => {
            this.mode = 'hotseat';
            this.startGame();
        });
        this.container.addChild(playHotseat);
        let rules = new PIXI.Text(
            'Match shape or number. Specials: 1=Hold, 2=Pick 2, 5=Pick 3, 8=Skip, 14=Market, 20=Whot (choose shape).\nFirst to play all cards wins!',
            {fontFamily:'Arial',fontSize:18,fill:0xffffff,wordWrap:true,wordWrapWidth:600}
        );
        rules.anchor.set(0.5,0);
        rules.x = 400; rules.y = 400;
        this.container.addChild(rules);
    }
    makeButton(label, x, y, cb) {
        let g = new PIXI.Graphics();
        g.beginFill(0x2156c9);
        g.drawRoundedRect(-90, -28, 180, 56, 16);
        g.endFill();
        let t = new PIXI.Text(label, {fontFamily:'Arial',fontSize:26,fill:0xffffff});
        t.anchor.set(0.5);
        t.x = 0; t.y = 0;
        g.addChild(t);
        g.x = x; g.y = y;
        g.eventMode = 'static';
        g.cursor = 'pointer';
        g.on('pointertap', cb);
        return g;
    }
    startGame() {
        this.clear();
        this.state = 'dealing';
        this.deck = createDeck();
        shuffle(this.deck);
        this.players = [
            {name:'You',hand:[],isAI:false,moves:0},
            {name: this.mode==='ai'?'Bot Oyinbo':'Player 2',hand:[],isAI:this.mode==='ai',moves:0}
        ];
        for (let i = 0; i < PLAYER_COUNT; i++) {
            for (let j = 0; j < HAND_SIZE; j++) {
                this.players[i].hand.push(this.deck.pop());
            }
        }
        this.market = [...this.deck];
        this.deck = [];
        this.discard = [];
        this.whotShape = null;
        this.special = null;
        this.turn = Math.random()<0.5?0:1;
        this.moves = 0;
        this.startTime = Date.now();
        this.lastDrawnCard = null;
        this.skipNext = [false,false];
        this.suspended = [false,false];
        this.generalMarketPending = false;
        this.dealAnimIndex = 0;
        this.dealAnim();
    }
    dealAnim() {
        if (this.dealAnimIndex < HAND_SIZE*PLAYER_COUNT) {
            let player = Math.floor(this.dealAnimIndex / HAND_SIZE);
            let card = this.players[player].hand[this.dealAnimIndex%HAND_SIZE];
            this.renderGame({dealAnim:true,dealPlayer:player,dealCard:card,dealIndex:this.dealAnimIndex%HAND_SIZE});
            setTimeout(()=>{this.dealAnimIndex++;this.dealAnim();}, 80);
        } else {
            setTimeout(()=>this.startFirstTurn(), 600);
        }
    }
    startFirstTurn() {
        let starter = this.turn;
        let card = this.market.pop();
        this.discard.push(card);
        this.whotShape = null;
        this.renderGame();
        setTimeout(()=>{this.state='play';this.renderGame();if(this.players[this.turn].isAI) this.aiTurn();}, 800);
    }
    renderGame(opts={}) {
        this.clear();
        let bg = new PIXI.Graphics();
        for (let i = 0; i < 12; i++) {
            bg.beginFill(i%2?0xB8864B:0xA0723A);
            bg.drawRect(0, i*50, 800, 50);
            bg.endFill();
        }
        this.container.addChild(bg);
        let marketCount = this.market.length;
        let marketStack = new PIXI.Container();
        for (let i = 0; i < Math.min(4,marketCount); i++) {
            let s = createCardSprite({number:0,suit:'',isWhot:false}, false);
            s.x = MARKET_X + i*3;
            s.y = MARKET_Y + i*2;
            marketStack.addChild(s);
        }
        this.container.addChild(marketStack);
        let marketBadge = new PIXI.Text(marketCount+'', {fontFamily:'Arial',fontSize:18,fill:0xffffff,fontWeight:'bold'});
        marketBadge.anchor.set(0.5);
        marketBadge.x = MARKET_X + CARD_WIDTH/2;
        marketBadge.y = MARKET_Y + CARD_HEIGHT + 12;
        this.container.addChild(marketBadge);
        let discardCard = this.discard.length?this.discard[this.discard.length-1]:null;
        if (discardCard) {
            let face = createCardSprite(discardCard, true);
            face.x = DISCARD_X; face.y = DISCARD_Y;
            face.anchor.set(0.5);
            if (discardCard.isWhot && this.whotShape) {
                let g = new PIXI.Graphics();
                g.beginFill(getSuitObj(this.whotShape).color);
                drawCardSymbol(g, getSuitObj(this.whotShape).symbol, getSuitObj(this.whotShape).color, 40, 18, 30);
                g.endFill();
                let s = new PIXI.Sprite(app.renderer.generateTexture(g));
                s.anchor.set(0.5);
                s.x = CARD_WIDTH/2;
                s.y = 28;
                face.addChild(s);
            }
            if ([1,2,5,8,14].includes(discardCard.number)||discardCard.isWhot) {
                let glow = new PIXI.filters.GlowFilter({distance: 10, outerStrength: 2, color: 0xffe066});
                face.filters = [glow];
            }
            this.container.addChild(face);
            face.x = DISCARD_X; face.y = DISCARD_Y;
            face.anchor.set(0.5);
        }
        for (let p = 0; p < PLAYER_COUNT; p++) {
            let hand = this.players[p].hand;
            let isAI = this.players[p].isAI;
            let y = p === 0 ? HAND_Y : AI_HAND_Y;
            let baseX = 400 - (hand.length * 36) / 2;
            let handCont = new PIXI.Container();
            for (let i = 0; i < hand.length; i++) {
                let card = hand[i];
                let s = createCardSprite(card, p === 0 || !isAI);
                s.x = baseX + i * 36;
                s.y = y;
                s.zIndex = i;
                s.anchor.set(0.5);
                if (p === 0) {
                    s.eventMode = 'static';
                    s.cursor = 'pointer';
                    s.interactive = true;
                    s.on('pointertap', () => this.onCardClick(i));
                    if (this.state === 'play' && this.turn === 0 && isValidPlay(card, discardCard, this.whotShape)) {
                        s.filters = [new PIXI.filters.OutlineFilter(3, 0x2ea13b)];
                    }
                }
                handCont.addChild(s);
            }
            this.container.addChild(handCont);
            let badge = new PIXI.Text(hand.length+'', {fontFamily:'Arial',fontSize:18,fill:0xffffff,fontWeight:'bold'});
            badge.anchor.set(0.5);
            badge.x = baseX + hand.length * 36 + 28;
            badge.y = y + 8;
            this.container.addChild(badge);
            let name = new PIXI.Text(this.players[p].name, {fontFamily:'Arial',fontSize:16,fill:0xffffff,fontWeight:'bold'});
            name.anchor.set(0.5);
            name.x = 60;
            name.y = y - 32;
            this.container.addChild(name);
            if (this.turn === p && this.state === 'play') {
                let turnInd = new PIXI.Graphics();
                turnInd.beginFill(0xfad02e);
                turnInd.drawCircle(0, 0, 22);
                turnInd.endFill();
                let arr = new PIXI.Text('▶',{fontFamily:'Arial',fontSize:22,fill:0x333333});
                arr.anchor.set(0.5);
                arr.x = 0; arr.y = 0;
                turnInd.addChild(arr);
                turnInd.x = 60; turnInd.y = y - 62;
                this.container.addChild(turnInd);
            }
        }
        let stats = new PIXI.Graphics();
        stats.beginFill(0x000000,0.25);
        stats.drawRoundedRect(590, 500, 200, 80, 14);
        stats.endFill();
        this.container.addChild(stats);
        let t = Math.floor((Date.now() - this.startTime)/1000);
        let mins = Math.floor(t/60), secs = t%60;
        let statText = new PIXI.Text(
            `Cards: ${this.players[0].hand.length}\nMoves: ${this.moves}\nTime: ${mins}:${secs.toString().padStart(2,'0')}`,
            {fontFamily:'Arial',fontSize:18,fill:0xffffff}
        );
        statText.x = 600; statText.y = 510;
        this.container.addChild(statText);
        if (this.state === 'play' && this.turn === 0) {
            let valid = getValidPlays(this.players[0].hand, discardCard, this.whotShape);
            if (valid.length === 0 && !this.lastDrawnCard) {
                let drawBtn = this.makeButton('Draw 1', 400, HAND_Y+90, ()=>this.onDrawClick());
                drawBtn.width = 100;
                this.container.addChild(drawBtn);
            }
            if (this.lastDrawnCard && !isValidPlay(this.lastDrawnCard, discardCard, this.whotShape)) {
                let passBtn = this.makeButton('Pass', 100, HAND_Y+90, ()=>this.onPassClick());
                passBtn.width = 100;
                this.container.addChild(passBtn);
            }
        }
        if (this.state === 'whotChoice') {
            let modal = new PIXI.Graphics();
            modal.beginFill(0x000000,0.7);
            modal.drawRect(0,0,800,600);
            modal.endFill();
            this.container.addChild(modal);
            let prompt = new PIXI.Text('Choose Shape',{fontFamily:'Arial',fontSize:28,fill:0xffffff});
            prompt.anchor.set(0.5);
            prompt.x = 400; prompt.y = 220;
            this.container.addChild(prompt);
            for (let i = 0; i < SUITS.length; i++) {
                let btn = new PIXI.Container();
                let g = new PIXI.Graphics();
                g.beginFill(SUITS[i].color);
                g.drawCircle(0,0,28);
                g.endFill();
                drawCardSymbol(g, SUITS[i].symbol, 0xffffff, 0, 0, 30, 0.75);
                btn.addChild(g);
                btn.x = 220 + i*110;
                btn.y = 320;
                btn.eventMode = 'static';
                btn.cursor = 'pointer';
                btn.on('pointertap', ()=>this.onWhotShapeChosen(SUITS[i].name));
                this.container.addChild(btn);
            }
        }
        if (this.state === 'win') {
            let modal = new PIXI.Graphics();
            modal.beginFill(0x000000,0.8);
            modal.drawRect(0,0,800,600);
            modal.endFill();
            this.container.addChild(modal);
            let winner = this.players[this.winner].name;
            let winText = new PIXI.Text(
                `${winner} Wins!\nMoves: ${this.moves}\nTime: ${Math.floor((Date.now()-this.startTime)/1000)}s`,
                {fontFamily:'Arial',fontWeight:'bold',fontSize:38,fill:0xfad02e,align:'center'}
            );
            winText.anchor.set(0.5);
            winText.x = 400; winText.y = 240;
            this.container.addChild(winText);
            let again = this.makeButton('Play Again', 400, 350, ()=>this.startGame());
            this.container.addChild(again);
            let menu = this.makeButton('Menu', 400, 420, ()=>this.initMenu());
            this.container.addChild(menu);
        }
        let menuBtn = new PIXI.Graphics();
        menuBtn.beginFill(0xde2d2d);
        menuBtn.drawCircle(0,0,20);
        menuBtn.endFill();
        let xText = new PIXI.Text('X',{fontFamily:'Arial',fontSize:18,fill:0xffffff});
        xText.anchor.set(0.5);
        xText.x = 0; xText.y = 0;
        menuBtn.addChild(xText);
        menuBtn.x = 30; menuBtn.y = 30;
        menuBtn.eventMode = 'static';
        menuBtn.cursor = 'pointer';
        menuBtn.on('pointertap',()=>this.initMenu());
        this.container.addChild(menuBtn);
    }
    onCardClick(index) {
        if (this.state !== 'play' || this.turn !== 0) return;
        let hand = this.players[0].hand;
        let card = hand[index];
        let topCard = this.discard[this.discard.length-1];
        if (isValidPlay(card, topCard, this.whotShape)) {
            this.playCard(0, index);
        } else {
            this.renderGame();
        }
    }
    onDrawClick() {
        if (this.state !== 'play' || this.turn !== 0) return;
        if (this.market.length === 0) return;
        let card = this.market.pop();
        this.players[0].hand.push(card);
        this.lastDrawnCard = card;
        this.renderGame();
        let topCard = this.discard[this.discard.length-1];
        if (isValidPlay(card, topCard, this.whotShape)) {
            setTimeout(()=>{
                let idx = this.players[0].hand.length-1;
                this.playCard(0, idx);
            }, 700);
        }
    }
    onPassClick() {
        if (this.state !== 'play' || this.turn !== 0) return;
        this.lastDrawnCard = null;
        this.nextTurn();
    }
    playCard(playerIdx, handIdx) {
        let player = this.players[playerIdx];
        let card = player.hand[handIdx];
        player.hand.splice(handIdx,1);
        this.discard.push(card);
        this.moves++;
        player.moves++;
        this.lastDrawnCard = null;
        if (card.isWhot) {
            this.state = 'whotChoice';
            this.renderGame();
            return;
        }
        this.whotShape = null;
        if ([1,2,5,8,14].includes(card.number)) {
            this.special = card.number;
            this.applySpecial(card.number, playerIdx);
        } else {
            this.special = null;
            this.checkEndOrNext();
        }
    }
    onWhotShapeChosen(shape) {
        let card = this.discard[this.discard.length-1];
        this.whotShape = shape;
        this.state = 'play';
        this.special = card.isWhot?20:null;
        this.applySpecial(this.special, this.turn);
    }
    applySpecial(number, playerIdx) {
        if (number === 1) {
            this.skipNext[(playerIdx+1)%2] = true;
            setTimeout(()=>this.checkEndOrNext(), 500);
        } else if (number === 2) {
            let next = (playerIdx+1)%2;
            for (let i = 0; i < 2; i++) {
                if (this.market.length) this.players[next].hand.push(this.market.pop());
            }
            this.skipNext[next] = true;
            setTimeout(()=>this.checkEndOrNext(), 800);
        } else if (number === 5) {
            let next = (playerIdx+1)%2;
            for (let i = 0; i < 3; i++) {
                if (this.market.length) this.players[next].hand.push(this.market.pop());
            }
            this.skipNext[next] = true;
            setTimeout(()=>this.checkEndOrNext(), 800);
        } else if (number === 8) {
            let next = (playerIdx+1)%2;
            this.suspended[next] = true;
            setTimeout(()=>this.checkEndOrNext(), 500);
        } else if (number === 14) {
            let opp = (playerIdx+1)%2;
            if (this.market.length) this.players[opp].hand.push(this.market.pop());
            setTimeout(()=>this.checkEndOrNext(), 700);
        } else if (number === 20) {
            setTimeout(()=>this.checkEndOrNext(), 400);
        } else {
            setTimeout(()=>this.checkEndOrNext(), 400);
        }
        this.renderGame();
    }
    checkEndOrNext() {
        for (let i = 0; i < PLAYER_COUNT; i++) {
            if (this.players[i].hand.length === 0) {
                this.state = 'win';
                this.winner = i;
                this.renderGame();
                return;
            }
        }
        if (this.market.length === 0) {
            let vals = this.players.map(p=>p.hand.reduce((a,c)=>a+getCardValue(c),0));
            let min = Math.min(...vals);
            let winIdx = vals.indexOf(min);
            this.state = 'win';
            this.winner = winIdx;
            this.renderGame();
            return;
        }
        this.nextTurn();
    }
    nextTurn() {
        this.turn = (this.turn+1)%2;
        if (this.skipNext[this.turn]) {
            this.skipNext[this.turn] = false;
            setTimeout(()=>this.nextTurn(), 400);
            return;
        }
        if (this.suspended[this.turn]) {
            this.suspended[this.turn] = false;
            setTimeout(()=>this.nextTurn(), 400);
            return;
        }
        this.state = 'play';
        this.renderGame();
        if (this.players[this.turn].isAI) {
            setTimeout(()=>this.aiTurn(), 800);
        }
    }
    aiTurn() {
        if (this.state !== 'play' || !this.players[this.turn].isAI) return;
        let ai = this.players[this.turn];
        let topCard = this.discard[this.discard.length-1];
        let valid = getValidPlays(ai.hand, topCard, this.whotShape);
        let playIdx = -1;
        for (let i = 0; i < ai.hand.length; i++) {
            if (isValidPlay(ai.hand[i], topCard, this.whotShape)) {
                playIdx = i;
                break;
            }
        }
        if (valid.length > 0) {
            let specials = valid.filter(c=>[2,5,8,14].includes(c.number));
            if (specials.length && Math.random()<0.7) {
                playIdx = ai.hand.indexOf(getRandomElement(specials));
            }
            if (playIdx === -1) playIdx = ai.hand.indexOf(getRandomElement(valid));
            setTimeout(()=>this.playCard(this.turn, playIdx), 900);
        } else {
            if (this.market.length) {
                let card = this.market.pop();
                ai.hand.push(card);
                this.renderGame();
                if (isValidPlay(card, topCard, this.whotShape) && Math.random()<0.5) {
                    let idx = ai.hand.length-1;
                    setTimeout(()=>this.playCard(this.turn, idx), 900);
                } else {
                    setTimeout(()=>this.nextTurn(), 900);
                }
            } else {
                setTimeout(()=>this.nextTurn(), 900);
            }
        }
    }
}
let game = new WhotGame();
app.ticker.add((delta) => {});
