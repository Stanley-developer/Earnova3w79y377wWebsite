<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Page Title -->
    <title>EARNOVA - Earning, Gaming & Social Reward Platform</title>

    <!-- Favicon -->
    <link rel="icon" type="image/png" href="logo.png">

    <!-- SEO Meta Tags -->
    <meta name="description" content="EARNOVA is a gaming and social reward platform where users earn daily through tasks, games, and engagement. Join today and start earning instantly!">
    <meta name="keywords" content="EARNOVA, earn money online, gaming rewards, social tasks, daily rewards, earn coins, Nigeria, CBI MONIE, online income, game platform, reward system">
    <meta name="author" content="EARNOVA Team">

    <!-- Open Graph (for social media sharing) -->
    <meta property="og:title" content="EARNOVA - Earning, Gaming & Social Reward Platform">
    <meta property="og:description" content="Earn daily by completing gaming and social tasks on EARNOVA. Join now and start growing your income online!">
    <meta property="og:image" content="logo.png">
    <meta property="og:type" content="website">
    <meta property="og:url" content="https://earnova.com"> <!-- replace with your actual domain -->

    <!-- Optional: Twitter Card -->
    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:title" content="EARNOVA - Earning, Gaming & Social Reward Platform">
    <meta name="twitter:description" content="Earn daily through gaming, social tasks, and rewards on EARNOVA.">
    <meta name="twitter:image" content="logo.png">
</head>
