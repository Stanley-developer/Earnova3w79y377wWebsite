<?php
require_once 'config/database.php';
require_once 'includes/session.php';
require_once 'includes/connect.php';

requireLogin();
checkSessionTimeout();

$user = getCurrentUser();
$user_id = $user['id'];

try {
    $pdo = getDBConnection();
    $stmt = $pdo->prepare("SELECT u.*, b.total_balance, b.referral_earnings, b.game_earnings, b.task_earnings FROM users u LEFT JOIN balances b ON u.id = b.user_id WHERE u.id = ?");
    $stmt->execute([$user_id]);
    $user_data = $stmt->fetch();
    
    if (!$user_data) {
        header('Location: login.php');
        exit;
    }
    
    $is_premium = ($user_data['membership_type'] === 'premium');
} catch (PDOException $e) {
    error_log("Temple Run Error: " . $e->getMessage());
    $error_message = "Unable to load game data.";
}

$game_earnings = $user_data['game_earnings'] ?? 0;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Temple Run - FlowEarner</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        
        body {
            font-family: 'Arial', sans-serif;
            background: #000;
            overflow: hidden;
            width: 100%;
            height: 100vh;
        }
        
        #gameContainer {
            width: 100%;
            height: 100%;
            position: relative;
            background: linear-gradient(180deg, #87ceeb 0%, #e0f6ff 100%);
        }
        
        canvas#gameCanvas {
            display: block;
            width: 100%;
            height: 100%;
        }
        
        .hud {
            position: absolute;
            top: 20px;
            left: 20px;
            color: #fff;
            font-size: 24px;
            font-weight: bold;
            text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.7);
            z-index: 100;
        }
        
        .hud-item {
            margin-bottom: 10px;
            background: rgba(0, 0, 0, 0.5);
            padding: 10px 20px;
            border-radius: 8px;
            min-width: 200px;
        }
        
        .game-over-modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.8);
            z-index: 200;
            align-items: center;
            justify-content: center;
        }
        
        .game-over-modal.active {
            display: flex;
        }
        
        .game-over-content {
            background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%);
            border: 3px solid #4de1c1;
            border-radius: 20px;
            padding: 40px;
            text-align: center;
            max-width: 500px;
            color: #fff;
        }
        
        .game-over-title {
            font-size: 3em;
            margin-bottom: 20px;
            color: #fb923c;
        }
        
        .game-over-stat {
            font-size: 1.5em;
            margin: 15px 0;
            color: #4de1c1;
        }
        
        .game-over-buttons {
            display: flex;
            gap: 15px;
            justify-content: center;
            margin-top: 30px;
            flex-wrap: wrap;
        }
        
        .game-over-btn {
            padding: 15px 40px;
            border: none;
            border-radius: 10px;
            font-size: 1.2em;
            font-weight: bold;
            cursor: pointer;
            transition: all 0.3s ease;
        }
        
        .btn-restart {
            background: linear-gradient(135deg, #fb923c, #f97316);
            color: #fff;
        }
        
        .btn-restart:hover {
            transform: scale(1.05);
            box-shadow: 0 0 20px rgba(251, 146, 60, 0.6);
        }
        
        .btn-menu {
            background: rgba(255, 255, 255, 0.1);
            color: #fff;
            border: 2px solid #4de1c1;
        }
        
        .btn-menu:hover {
            background: rgba(77, 225, 193, 0.2);
        }
        
        .premium-modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.9);
            z-index: 200;
            align-items: center;
            justify-content: center;
        }
        
        .premium-modal.active {
            display: flex;
        }
        
        .premium-content {
            background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%);
            border: 3px solid #fb923c;
            border-radius: 20px;
            padding: 40px;
            text-align: center;
            max-width: 500px;
            color: #fff;
        }
        
        .premium-title {
            font-size: 2.5em;
            margin-bottom: 20px;
            color: #fb923c;
        }
        
        .premium-message {
            font-size: 1.2em;
            margin: 20px 0;
        }
        
        .premium-btn {
            padding: 15px 40px;
            background: linear-gradient(135deg, #fb923c, #f97316);
            color: #fff;
            border: none;
            border-radius: 10px;
            font-size: 1.2em;
            font-weight: bold;
            cursor: pointer;
            margin-top: 20px;
            transition: all 0.3s ease;
        }
        
        .premium-btn:hover {
            transform: scale(1.05);
            box-shadow: 0 0 20px rgba(251, 146, 60, 0.6);
        }
        
        @media (max-width: 768px) {
            .hud {
                font-size: 16px;
                top: 10px;
                left: 10px;
            }
            
            .hud-item {
                min-width: 150px;
                padding: 8px 15px;
                margin-bottom: 8px;
            }
            
            .game-over-content {
                padding: 20px;
                max-width: 90%;
            }
            
            .game-over-title {
                font-size: 2em;
            }
        }
    </style>
</head>
<body>
    <div id="gameContainer">
        <canvas id="gameCanvas"></canvas>
        <div class="hud">
            <div class="hud-item">Distance: <span id="distanceVal">0</span>m</div>
            <div class="hud-item">Earnings: ₦<span id="earningsVal">0</span></div>
        </div>
    </div>
    
    <div class="game-over-modal" id="gameOverModal">
        <div class="game-over-content">
            <div class="game-over-title">GAME OVER</div>
            <div class="game-over-stat">Distance: <span id="finalDistance">0</span>m</div>
            <div class="game-over-stat">Earnings: ₦<span id="finalEarnings">0</span></div>
            <div class="game-over-buttons">
                <button class="game-over-btn btn-restart" onclick="location.reload()">Play Again</button>
                <button class="game-over-btn btn-menu" onclick="window.location.href='play-earn.php'">Back to Games</button>
            </div>
        </div>
    </div>
    
    <div class="premium-modal" id="premiumModal">
        <div class="premium-content">
            <div class="premium-title">🔒 Premium Required</div>
            <div class="premium-message">Temple Run is exclusively for Premium Members!</div>
            <button class="premium-btn" onclick="window.location.href='membership.php'">Upgrade to Premium</button>
        </div>
    </div>

    <script>
        const IS_PREMIUM = <?php echo $is_premium ? 'true' : 'false'; ?>;
        const USER_ID = <?php echo $user_id; ?>;
        
        if (!IS_PREMIUM) {
            document.getElementById('premiumModal').classList.add('active');
        }
        
        const canvas = document.getElementById('gameCanvas');
        const ctx = canvas.getContext('2d');
        
        // Canvas setup
        canvas.width = window.innerWidth;
        canvas.height = window.innerHeight;
        window.addEventListener('resize', () => {
            canvas.width = window.innerWidth;
            canvas.height = window.innerHeight;
        });
        
        // Game state
        let gameActive = IS_PREMIUM;
        let gameOver = false;
        let distance = 0;
        let earnings = 0;
        
        // Player
        const player = {
            x: canvas.width / 2,
            y: canvas.height * 0.7,
            width: 30,
            height: 50,
            lane: 1, // 0 = left, 1 = center, 2 = right
            velocityY: 0,
            isJumping: false,
            jumpPower: 0
        };
        
        // Road
        const road = {
            width: 150,
            segments: [],
            speed: 8
        };
        
        // Obstacles
        let obstacles = [];
        let coins = [];
        let nextObstacleDistance = 100;
        let nextCoinDistance = 50;
        
        // Swipe detection
        let touchStartX = 0;
        let touchStartY = 0;
        
        document.addEventListener('touchstart', (e) => {
            touchStartX = e.touches[0].clientX;
            touchStartY = e.touches[0].clientY;
        });
        
        document.addEventListener('touchend', (e) => {
            const touchEndX = e.changedTouches[0].clientX;
            const touchEndY = e.changedTouches[0].clientY;
            handleSwipe(touchStartX, touchStartY, touchEndX, touchEndY);
        });
        
        // Mouse support for desktop
        let mouseDown = false;
        let mouseStartX = 0;
        let mouseStartY = 0;
        
        document.addEventListener('mousedown', (e) => {
            mouseDown = true;
            mouseStartX = e.clientX;
            mouseStartY = e.clientY;
        });
        
        document.addEventListener('mouseup', (e) => {
            if (mouseDown) {
                handleSwipe(mouseStartX, mouseStartY, e.clientX, e.clientY);
                mouseDown = false;
            }
        });
        
        function handleSwipe(startX, startY, endX, endY) {
            if (!gameActive || gameOver) return;
            
            const deltaX = endX - startX;
            const deltaY = startY - endY; // Inverted for up detection
            const minSwipe = 30;
            
            // Swipe up to jump
            if (deltaY > minSwipe && Math.abs(deltaX) < 50) {
                if (!player.isJumping) {
                    player.isJumping = true;
                    player.jumpPower = 15;
                }
            }
            // Swipe left
            else if (deltaX > minSwipe && Math.abs(deltaY) < 50) {
                if (player.lane > 0) {
                    player.lane--;
                }
            }
            // Swipe right
            else if (-deltaX > minSwipe && Math.abs(deltaY) < 50) {
                if (player.lane < 2) {
                    player.lane++;
                }
            }
        }
        
        // Keyboard support
        document.addEventListener('keydown', (e) => {
            if (!gameActive || gameOver) return;
            if (e.key === 'ArrowLeft' && player.lane > 0) {
                player.lane--;
            } else if (e.key === 'ArrowRight' && player.lane < 2) {
                player.lane++;
            } else if (e.key === ' ' || e.key === 'ArrowUp') {
                if (!player.isJumping) {
                    player.isJumping = true;
                    player.jumpPower = 15;
                }
            }
        });
        
        function generateRoad() {
            road.segments = [];
            for (let i = 0; i < 100; i++) {
                road.segments.push({
                    y: canvas.height * 0.7 - i * 30,
                    curve: Math.sin(i * 0.3) * 60,
                    obstacles: []
                });
            }
        }
        
        function generateObstacles() {
            if (distance >= nextObstacleDistance) {
                const lane = Math.floor(Math.random() * 3);
                obstacles.push({
                    distance: distance + 200,
                    lane: lane,
                    type: Math.random() > 0.5 ? 'wall' : 'block',
                    width: 40,
                    height: 60
                });
                nextObstacleDistance = distance + Math.random() * 150 + 100;
            }
        }
        
        function generateCoins() {
            if (distance >= nextCoinDistance) {
                const lane = Math.floor(Math.random() * 3);
                coins.push({
                    distance: distance + 200,
                    lane: lane,
                    collected: false,
                    size: 10
                });
                nextCoinDistance = distance + Math.random() * 80 + 50;
            }
        }
        
        function update() {
            if (!gameActive || gameOver) return;
            
            // Update distance
            distance += road.speed / 10;
            
            // Jump physics
            if (player.isJumping) {
                player.jumpPower -= 0.5;
                player.velocityY = -player.jumpPower;
                
                if (player.jumpPower <= 0) {
                    player.isJumping = false;
                    player.velocityY = 0;
                }
            } else {
                player.velocityY = 0;
            }
            
            player.y += player.velocityY;
            
            // Keep player in bounds
            if (player.y < canvas.height * 0.3) player.y = canvas.height * 0.3;
            if (player.y > canvas.height * 0.7) player.y = canvas.height * 0.7;
            
            // Check collisions with obstacles
            obstacles.forEach(obs => {
                const obsScreenY = canvas.height * 0.7 - (distance - obs.distance) * 3;
                
                if (obsScreenY > player.y - 60 && obsScreenY < player.y + 50 &&
                    obs.lane === player.lane) {
                    endGame();
                }
                
                if (obsScreenY < -100) {
                    obstacles.splice(obstacles.indexOf(obs), 1);
                }
            });
            
            // Check coin collection
            coins.forEach(coin => {
                const coinScreenY = canvas.height * 0.7 - (distance - coin.distance) * 3;
                
                if (!coin.collected && coinScreenY > player.y - 60 && coinScreenY < player.y + 50 &&
                    coin.lane === player.lane) {
                    coin.collected = true;
                    earnings += 100;
                    document.getElementById('earningsVal').textContent = earnings.toLocaleString();
                }
                
                if (coinScreenY < -100) {
                    coins.splice(coins.indexOf(coin), 1);
                }
            });
            
            // Generate new obstacles and coins
            generateObstacles();
            generateCoins();
            
            // Update HUD
            document.getElementById('distanceVal').textContent = Math.floor(distance);
        }
        
        function draw() {
            // Clear canvas
            ctx.fillStyle = 'linear-gradient(180deg, #87ceeb 0%, #e0f6ff 100%)';
            ctx.fillRect(0, 0, canvas.width, canvas.height);
            
            // Draw perspective road
            const roadBaseWidth = 200;
            const roadTopWidth = 80;
            
            ctx.fillStyle = 'rgba(139, 90, 43, 0.7)';
            
            // Draw road segments
            for (let i = 50; i > 0; i--) {
                const perspective = i / 50;
                const y = canvas.height * 0.7 - (50 - i) * 15;
                const width = roadBaseWidth * perspective + roadTopWidth * (1 - perspective);
                const x = canvas.width / 2 - width / 2;
                
                ctx.fillRect(x, y, width, 15);
                
                // Road lane markers
                ctx.strokeStyle = 'rgba(255, 255, 255, 0.5)';
                ctx.lineWidth = 2;
                ctx.beginPath();
                ctx.moveTo(x + width / 3, y);
                ctx.lineTo(x + width / 3, y + 15);
                ctx.stroke();
                ctx.beginPath();
                ctx.moveTo(x + (width * 2) / 3, y);
                ctx.lineTo(x + (width * 2) / 3, y + 15);
                ctx.stroke();
            }
            
            // Draw obstacles
            obstacles.forEach(obs => {
                const obsScreenY = canvas.height * 0.7 - (distance - obs.distance) * 3;
                const laneX = canvas.width / 2 - 75 + obs.lane * 75;
                
                if (obsScreenY > -100 && obsScreenY < canvas.height + 100) {
                    ctx.fillStyle = '#ff4444';
                    ctx.fillRect(laneX - obs.width / 2, obsScreenY, obs.width, obs.height);
                    
                    // Obstacle glow
                    ctx.strokeStyle = 'rgba(255, 68, 68, 0.8)';
                    ctx.lineWidth = 3;
                    ctx.strokeRect(laneX - obs.width / 2, obsScreenY, obs.width, obs.height);
                }
            });
            
            // Draw coins
            coins.forEach(coin => {
                if (!coin.collected) {
                    const coinScreenY = canvas.height * 0.7 - (distance - coin.distance) * 3;
                    const laneX = canvas.width / 2 - 75 + coin.lane * 75;
                    
                    if (coinScreenY > -50 && coinScreenY < canvas.height + 50) {
                        ctx.fillStyle = '#fbbf24';
                        ctx.beginPath();
                        ctx.arc(laneX, coinScreenY, coin.size, 0, Math.PI * 2);
                        ctx.fill();
                        
                        ctx.strokeStyle = '#f59e0b';
                        ctx.lineWidth = 2;
                        ctx.stroke();
                    }
                }
            });
            
            // Draw player
            ctx.fillStyle = '#4de1c1';
            ctx.fillRect(player.x - player.width / 2, player.y - player.height / 2, player.width, player.height);
            
            // Player glow
            ctx.strokeStyle = 'rgba(77, 225, 193, 0.8)';
            ctx.lineWidth = 3;
            ctx.strokeRect(player.x - player.width / 2, player.y - player.height / 2, player.width, player.height);
        }
        
        function gameLoop() {
            if (gameActive) {
                update();
            }
            draw();
            requestAnimationFrame(gameLoop);
        }
        
        function endGame() {
            gameOver = true;
            gameActive = false;
            
            // Submit score
            submitScore();
            
            document.getElementById('finalDistance').textContent = Math.floor(distance);
            document.getElementById('finalEarnings').textContent = earnings.toLocaleString();
            document.getElementById('gameOverModal').classList.add('active');
        }
        
        async function submitScore() {
            try {
                const response = await fetch('api/temple-run-play.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        distance: Math.floor(distance),
                        earnings: earnings
                    })
                });
                const data = await response.json();
            } catch (error) {
                console.error('Score submission error:', error);
            }
        }
        
        // Initialize
        generateRoad();
        generateObstacles();
        generateCoins();
        gameLoop();
    </script>
</body>
</html>
