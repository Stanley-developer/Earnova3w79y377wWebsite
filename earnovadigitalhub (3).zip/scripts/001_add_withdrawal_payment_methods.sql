-- Add columns for withdrawal payment methods to users table
ALTER TABLE users 
ADD COLUMN IF NOT EXISTS withdrawal_account_number VARCHAR(20) DEFAULT NULL,
ADD COLUMN IF NOT EXISTS withdrawal_account_name VARCHAR(255) DEFAULT NULL,
ADD COLUMN IF NOT EXISTS withdrawal_bank_name VARCHAR(255) DEFAULT NULL,
ADD COLUMN IF NOT EXISTS withdrawal_bank_code VARCHAR(10) DEFAULT NULL,
ADD COLUMN IF NOT EXISTS withdrawal_banks_json TEXT DEFAULT NULL COMMENT 'JSON array of multiple banks if account has multiple banks',
ADD COLUMN IF NOT EXISTS theme_preference ENUM('dark', 'light') DEFAULT 'dark' COMMENT 'User theme preference';

-- Create index for faster lookups
CREATE INDEX IF NOT EXISTS idx_withdrawal_account ON users(withdrawal_account_number);
