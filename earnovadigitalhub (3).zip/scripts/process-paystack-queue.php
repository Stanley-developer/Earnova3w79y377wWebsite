<?php

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/connect.php';

$log_file = __DIR__ . '/../paystack_error_logs';
$timestamp = date('Y-m-d H:i:s');

file_put_contents($log_file, "[$timestamp] CRON: Starting Paystack queue processor\n", FILE_APPEND);

$token = 'sys_' . substr(md5('earnova_paystack_cron'), 0, 16);

// Use the correct domain
$api_url = 'https://earnova-digital-hub.com/api/process-paystack-transfer.php?token=' . urlencode($token);

file_put_contents($log_file, "[$timestamp] CRON: Calling API: $api_url\n", FILE_APPEND);

$ch = curl_init();
curl_setopt_array($ch, [
    CURLOPT_URL => $api_url,
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_TIMEOUT => 120,
    CURLOPT_FOLLOWLOCATION => true,
    CURLOPT_CUSTOMREQUEST => 'GET',
    CURLOPT_SSL_VERIFYPEER => false
]);

$response = curl_exec($ch);
$http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$curl_error = curl_error($ch);
curl_close($ch);

$log_message = "[$timestamp] CRON: HTTP $http_code - Response: " . substr($response, 0, 500) . "\n";
file_put_contents($log_file, $log_message, FILE_APPEND);

if ($curl_error) {
    file_put_contents($log_file, "[$timestamp] CRON: CURL Error: $curl_error\n", FILE_APPEND);
}

// Also log to the separate queue log file for backwards compatibility
$queue_log_file = __DIR__ . '/../logs/paystack-queue.log';

if (!file_exists(dirname($queue_log_file))) {
    mkdir(dirname($queue_log_file), 0755, true);
}

$queue_log_message = "[$timestamp] HTTP $http_code - " . substr($response, 0, 200) . "\n";
file_put_contents($queue_log_file, $queue_log_message, FILE_APPEND);

file_put_contents($log_file, "[$timestamp] CRON: Queue processor completed\n", FILE_APPEND);

echo "Paystack queue processed at $timestamp - HTTP $http_code\n";
?>
