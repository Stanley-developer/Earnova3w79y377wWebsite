<?php
require_once 'config/database.php';
require_once 'includes/session.php';
require_once 'includes/connect.php';

// Require authentication
requireLogin();
checkSessionTimeout();

// Get current user data
$user = getCurrentUser();
$user_id = $user['id'];

try {
    $pdo = getDBConnection();
    
    // Fetch user details with balance
    $stmt = $pdo->prepare("SELECT u.*, b.total_balance, b.referral_earnings, b.game_earnings, b.task_earnings FROM users u LEFT JOIN balances b ON u.id = b.user_id WHERE u.id = ?");
    $stmt->execute([$user_id]);
    $user_data = $stmt->fetch();
    
    if (!$user_data) {
        header('Location: login.php');
        exit;
    }
    
    $is_premium = ($user_data['membership_type'] === 'premium');
    
} catch (PDOException $e) {
    error_log("Keno 3D Error: " . $e->getMessage());
    $error_message = "Unable to load game data.";
}

$referral_earnings = $user_data['referral_earnings'] ?? 0;
$game_earnings = $user_data['game_earnings'] ?? 0;
$task_earnings = $user_data['task_earnings'] ?? 0;
$membership_type = $user_data['membership_type'] ?? 'free';
$user_email = $user_data['email'] ?? '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Keno 3D - FlowEarner</title>
    <link rel="stylesheet" href="assets/css/gamified-fintech-theme.css">
    <style>
        :root {
            --page-blue-900: #030922;
            --page-blue-800: #0a1642;
            --page-blue-700: #0a164a;
            --page-blue-500: #142e7e;
            --page-mint: #4de1c1;
            --page-white: #f5f9ff;
            --page-orange: #fb923c;
            --page-gold: #fbbf24;
            --page-red: #ef4444;
        }

        * { box-sizing: border-box; margin: 0; padding: 0; }

        body {
            font-family: 'Inter', sans-serif;
            background: linear-gradient(135deg, #0a0e27 0%, #1a1f3a 100%);
            color: #fff;
            overflow-x: hidden;
        }
        
        .container {
            max-width: 1400px;
            margin: 0 auto;
            padding: 20px;
        }
        
        .page-header {
            text-align: center;
            padding: 30px 20px;
            background: linear-gradient(135deg, rgba(44, 91, 245, 0.2), rgba(77, 225, 193, 0.1));
            border-radius: 20px;
            margin-bottom: 20px;
        }
        
        .page-header h1 {
            font-size: 2.5rem;
            margin: 0 0 10px;
            background: linear-gradient(135deg, #2c5bf5, #4de1c1);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }
        
        .back-link {
            display: inline-block;
            margin-bottom: 20px;
            color: var(--page-mint);
            text-decoration: none;
            font-size: 1rem;
            transition: color 0.3s ease;
        }
        
        .back-link:hover {
            color: #fff;
        }
        
        .game-layout {
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 20px;
            margin-bottom: 30px;
        }
        
        .game-canvas-container {
            background: linear-gradient(135deg, #1a2a5e 0%, #0f1937 100%);
            border: 2px solid rgba(77, 225, 193, 0.2);
            border-radius: 30px;
            padding: 20px;
            position: relative;
            width: 100%;
            max-width: 800px;
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 20px;
            overflow: hidden;
            box-shadow: 0 10px 40px rgba(0, 0, 0, 0.5);
        }
        
        .top-balance-bar {
            display: flex;
            justify-content: flex-end;
            align-items: center;
            width: 100%;
            gap: 15px;
        }
        
        .balance-chip {
            background: rgba(10, 22, 66, 0.8);
            border: 2px solid rgba(77, 225, 193, 0.3);
            border-radius: 25px;
            padding: 8px 20px;
            display: flex;
            align-items: center;
            gap: 10px;
            cursor: pointer;
            transition: all 0.3s ease;
        }
        
        .balance-chip:hover {
            background: rgba(10, 22, 66, 1);
            border-color: var(--page-mint);
        }
        
        .balance-chip-icon {
            font-size: 1.2rem;
        }
        
        .balance-chip-value {
            color: #fff;
            font-weight: 600;
            font-size: 1rem;
        }
        
        .deposit-chip {
            background: linear-gradient(135deg, #ef4444, #dc2626);
            border: none;
            color: #fff;
            font-weight: 700;
            padding: 10px 25px;
        }
        
        .deposit-chip:hover {
            transform: scale(1.05);
        }
        
        /* Added volume control button styles */
        .volume-control {
            background: rgba(10, 22, 66, 0.8);
            border: 2px solid rgba(77, 225, 193, 0.3);
            border-radius: 50%;
            width: 45px;
            height: 45px;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: all 0.3s ease;
            font-size: 1.3rem;
        }
        
        .volume-control:hover {
            background: rgba(10, 22, 66, 1);
            border-color: var(--page-mint);
            transform: scale(1.05);
        }
        
        .volume-control.muted {
            border-color: rgba(239, 68, 68, 0.5);
            color: var(--page-red);
        }
        
        .keno-grid {
            display: grid;
            grid-template-columns: repeat(10, 1fr);
            gap: 8px;
            width: 100%;
            max-width: 700px;
            padding: 20px;
            background: rgba(10, 22, 66, 0.4);
            border-radius: 20px;
            border: 2px solid rgba(251, 191, 36, 0.3);
        }
        
        .keno-number {
            aspect-ratio: 1;
            background: rgba(10, 22, 66, 0.8);
            border: 2px solid rgba(77, 225, 193, 0.3);
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.2rem;
            font-weight: 700;
            color: #fff;
            cursor: pointer;
            transition: all 0.3s ease;
            user-select: none;
        }
        
        .keno-number:hover {
            background: rgba(77, 225, 193, 0.2);
            border-color: var(--page-mint);
            transform: scale(1.05);
        }
        
        .keno-number.selected {
            /* Changed from gold to bright red to match image 2 */
            background: linear-gradient(135deg, #ef4444, #dc2626);
            border-color: #ef4444;
            color: #fff;
            transform: scale(1.1);
            box-shadow: 0 0 20px rgba(239, 68, 68, 0.6);
        }
        
        .keno-number.drawn {
            /* Changed to yellow outline for missed numbers (image 3) */
            background: rgba(10, 22, 66, 0.8);
            border: 3px solid #fbbf24;
            border-color: var(--page-gold);
            animation: pulse 0.5s ease;
        }
        
        .keno-number.matched {
            /* Changed to bright red for matched numbers (image 3) */
            background: linear-gradient(135deg, #ef4444, #dc2626);
            border-color: #ef4444;
            color: #fff;
            animation: celebrate 0.6s ease;
            box-shadow: 0 0 25px rgba(239, 68, 68, 0.8);
        }
        
        @keyframes pulse {
            0%, 100% { transform: scale(1); }
            50% { transform: scale(1.15); }
        }
        
        @keyframes celebrate {
            0%, 100% { transform: scale(1) rotate(0deg); }
            25% { transform: scale(1.2) rotate(-5deg); }
            75% { transform: scale(1.2) rotate(5deg); }
        }
        
        .game-controls {
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 15px;
            width: 100%;
        }
        
        .action-buttons {
            display: flex;
            gap: 15px;
        }
        
        .quick-pick-btn, .clear-btn {
            padding: 12px 35px;
            border-radius: 15px;
            border: none;
            font-size: 1.1rem;
            font-weight: 700;
            cursor: pointer;
            transition: all 0.3s ease;
            text-transform: uppercase;
        }
        
        .quick-pick-btn {
            background: linear-gradient(135deg, #ef4444, #dc2626);
            color: #fff;
        }
        
        .quick-pick-btn:hover {
            transform: scale(1.05);
            box-shadow: 0 0 30px rgba(239, 68, 68, 0.6);
        }
        
        .clear-btn {
            background: rgba(255, 255, 255, 0.1);
            color: #fff;
            border: 2px solid rgba(255, 255, 255, 0.3);
        }
        
        .clear-btn:hover {
            background: rgba(255, 255, 255, 0.2);
        }
        
        .selection-counter {
            color: var(--page-gold);
            font-size: 1.1rem;
            font-weight: 600;
        }
        
        .bottom-controls {
            width: 100%;
            background: rgba(10, 22, 66, 0.6);
            border-radius: 20px;
            padding: 20px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 15px;
        }
        
        .bet-controls {
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .bet-label {
            color: rgba(255, 255, 255, 0.7);
            font-size: 0.9rem;
            margin-right: 5px;
        }
        
        .bet-btn {
            width: 40px;
            height: 40px;
            border-radius: 10px;
            border: 2px solid rgba(251, 146, 60, 0.5);
            background: rgba(251, 146, 60, 0.1);
            color: var(--page-orange);
            font-size: 1.2rem;
            cursor: pointer;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        .bet-btn:hover {
            background: rgba(251, 146, 60, 0.3);
            border-color: var(--page-orange);
        }
        
        .bet-display {
            background: rgba(10, 22, 66, 0.8);
            border: 2px solid rgba(77, 225, 193, 0.3);
            border-radius: 12px;
            padding: 10px 30px;
            color: #fff;
            font-size: 1.2rem;
            font-weight: 600;
            min-width: 120px;
            text-align: center;
        }
        
        .play-button {
            background: linear-gradient(135deg, #ef4444, #dc2626);
            border: none;
            border-radius: 15px;
            padding: 12px 50px;
            color: #fff;
            font-size: 1.3rem;
            font-weight: 700;
            cursor: pointer;
            transition: all 0.3s ease;
            text-transform: uppercase;
            letter-spacing: 1px;
        }
        
        .play-button:hover:not(:disabled) {
            transform: scale(1.05);
            box-shadow: 0 0 30px rgba(239, 68, 68, 0.8);
        }
        
        .play-button:disabled {
            opacity: 0.5;
            cursor: not-allowed;
        }
        
        .info-btn {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            border: 2px solid rgba(239, 68, 68, 0.5);
            background: rgba(239, 68, 68, 0.1);
            color: var(--page-red);
            font-size: 1.2rem;
            cursor: pointer;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        .info-btn:hover {
            background: rgba(239, 68, 68, 0.3);
        }
        
        .particles {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            pointer-events: none;
            overflow: hidden;
        }
        
        .particle {
            position: absolute;
            width: 3px;
            height: 3px;
            background: var(--page-gold);
            border-radius: 50%;
            animation: float 10s infinite;
            opacity: 0.6;
        }
        
        @keyframes float {
            0%, 100% {
                transform: translateY(0) translateX(0);
                opacity: 0;
            }
            10% {
                opacity: 0.6;
            }
            90% {
                opacity: 0.6;
            }
            100% {
                transform: translateY(-100vh) translateX(50px);
                opacity: 0;
            }
        }
        
        .modal-overlay {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.9);
            z-index: 1000;
            align-items: center;
            justify-content: center;
            /* Added opacity transition for smooth modal appearance */
            opacity: 0;
            transition: opacity 0.3s ease;
        }
        
        .modal-overlay.active {
            display: flex;
            /* Make modal fully visible when active */
            opacity: 1;
        }
        
        .modal-content {
            background: linear-gradient(135deg, #0a0e27, #1a1f3a);
            border-radius: 30px;
            padding: 40px;
            max-width: 600px;
            width: 90%;
            border: 2px solid rgba(77, 225, 193, 0.3);
            text-align: center;
            position: relative;
            max-height: 90vh;
            overflow-y: auto;
        }
        
        .modal-close {
            position: absolute;
            top: 20px;
            right: 20px;
            background: rgba(255, 59, 48, 0.2);
            border: 2px solid rgba(255, 59, 48, 0.5);
            color: #ff3b30;
            padding: 8px 16px;
            border-radius: 10px;
            cursor: pointer;
            font-weight: 600;
        }
        
        .modal-icon {
            font-size: 5rem;
            margin-bottom: 20px;
        }
        
        .modal-title {
            font-size: 2rem;
            margin-bottom: 15px;
        }
        
        .modal-message {
            font-size: 1.1rem;
            color: rgba(255, 255, 255, 0.8);
            line-height: 1.6;
            margin-bottom: 30px;
        }
        
        .modal-btn {
            padding: 15px 40px;
            border-radius: 15px;
            border: none;
            background: linear-gradient(135deg, #2c5bf5, #4de1c1);
            color: #fff;
            font-size: 1.1rem;
            font-weight: 700;
            cursor: pointer;
            margin: 0 10px;
            transition: all 0.3s ease;
        }
        
        .tutorial-steps {
            text-align: left;
            margin: 20px 0;
            position: relative;
        }
        
        .tutorial-step {
            background: rgba(77, 225, 193, 0.1);
            padding: 20px;
            border-radius: 15px;
            margin-bottom: 15px;
            /* border-left: 4px solid var(--page-mint); */
            display: none;
        }
        
        .tutorial-step.active {
            display: block;
            animation: slideIn 0.3s ease;
        }
        
        @keyframes slideIn {
            from {
                opacity: 0;
                transform: translateX(-20px);
            }
            to {
                opacity: 1;
                transform: translateX(0);
            }
        }
        
        .tutorial-step h4 {
            color: var(--page-mint);
            margin-bottom: 12px;
            font-size: 1.3rem;
        }
        
        .tutorial-step p {
            line-height: 1.6;
            font-size: 1rem;
        }
        
        .tutorial-navigation {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-top: 30px;
            gap: 15px;
        }
        
        .tutorial-nav-btn {
            padding: 12px 30px;
            border-radius: 12px;
            border: none;
            background: linear-gradient(135deg, #2c5bf5, #4de1c1);
            color: #fff;
            font-size: 1rem;
            font-weight: 600;
            cursor: pointer;
            display: flex;
            align-items: center;
            gap: 8px;
            transition: all 0.3s ease;
        }
        
        .tutorial-nav-btn:hover {
            transform: scale(1.05);
        }
        
        .tutorial-nav-btn:disabled {
            opacity: 0.3;
            cursor: not-allowed;
            transform: scale(1);
        }
        
        .tutorial-progress {
            text-align: center;
            color: rgba(255, 255, 255, 0.7);
            font-size: 0.9rem;
        }
        
        .tutorial-dots {
            display: flex;
            justify-content: center;
            gap: 8px;
            margin-top: 10px;
        }
        
        .tutorial-dot {
            width: 10px;
            height: 10px;
            border-radius: 50%;
            background: rgba(255, 255, 255, 0.3);
            transition: all 0.3s ease;
        }
        
        .tutorial-dot.active {
            background: var(--page-mint);
            width: 30px;
            border-radius: 5px;
        }
        
        .exchange-input {
            width: 100%;
            padding: 15px;
            border-radius: 10px;
            border: 2px solid rgba(77, 225, 193, 0.3);
            background: rgba(255, 255, 255, 0.05);
            color: #fff;
            font-size: 1.2rem;
            margin: 20px 0;
            text-align: center;
        }
        
        .upgrade-modal .modal-content {
            border-color: rgba(251, 146, 60, 0.5);
        }
        
        .prize-table {
            background: rgba(77, 225, 193, 0.1);
            padding: 20px;
            border-radius: 15px;
            margin: 20px 0;
            text-align: left;
        }
        
        .prize-table h4 {
            color: var(--page-gold);
            margin-bottom: 15px;
            text-align: center;
        }
        
        .prize-row {
            display: flex;
            justify-content: space-between;
            padding: 8px 0;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }
        
        .prize-row:last-child {
            border-bottom: none;
        }
        
        @media (max-width: 768px) {
            .game-canvas-container {
                max-width: 100%;
                padding: 15px;
                margin: 0 10px;
            }
            
            .keno-grid {
                /* Make grid boxes smaller on mobile to fit perfectly */
                gap: 4px;
                padding: 10px;
                max-width: 100%;
            }
            
            .keno-number {
                /* Reduce font size for mobile */
                font-size: 0.85rem;
                border-width: 1.5px;
            }
            
            .page-header h1 {
                font-size: 1.8rem;
            }

            .modal-content {
                padding: 25px;
                max-width: 95%;
            }
            
            .tutorial-navigation {
                flex-direction: column;
            }
            
            .tutorial-nav-btn {
                width: 100%;
                justify-content: center;
            }
            
            .bottom-controls {
                flex-wrap: wrap;
                justify-content: center;
            }
            
            .bet-controls {
                order: 1;
                width: 100%;
                justify-content: center;
            }
            
            .play-button {
                order: 2;
                width: 100%;
            }
            
            .info-btn {
                order: 3;
            }
            
            .action-buttons {
                flex-direction: column;
                width: 100%;
            }
            
            .quick-pick-btn, .clear-btn {
                width: 100%;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <a href="play-earn.php" class="back-link">← Back to Games</a>
        
        <div class="page-header">
            <h1>Keno 3D</h1>
            <p>Pick your numbers and win big rewards!</p>
        </div>
        
        <div class="game-layout">
            <div class="game-canvas-container">
                <div class="particles" id="particles"></div>
                
                <div class="top-balance-bar">
                    <!-- Added volume control button -->
                    <div class="volume-control" id="volumeControl" onclick="toggleMute()" title="Toggle Sound">
                        🔊
                    </div>
                    <div class="balance-chip" onclick="openBalanceModal('game')">
                        <span class="balance-chip-icon"></span>
                        <span class="balance-chip-value" id="gameBalance">₦<?php echo number_format($game_earnings, 2); ?></span>
                    </div>
                    <div class="balance-chip deposit-chip" onclick="window.location.href='membership.php'">
                        Deposit
                    </div>
                </div>
                
                <div class="keno-grid" id="kenoGrid"></div>
                
                <div class="game-controls">
                    <div class="action-buttons">
                        <button class="quick-pick-btn" onclick="quickPick()">QUICK PICK</button>
                        <button class="clear-btn" onclick="clearSelection()">CLEAR</button>
                    </div>
                    <div class="selection-counter">Selected: <span id="selectedCount">0</span>/10</div>
                </div>
                
                <div class="bottom-controls">
                    <div class="bet-controls">
                        <span class="bet-label">Bet:</span>
                        <button class="bet-btn" onclick="decreaseBet()">↓</button>
                        <button class="bet-btn" onclick="decreaseBetSmall()">−</button>
                        <div class="bet-display" id="betDisplay">1</div>
                        <button class="bet-btn" onclick="increaseBetSmall()">+</button>
                        <button class="bet-btn" onclick="increaseBet()">↑</button>
                    </div>
                    <button class="play-button" id="playBtn" onclick="playGame()">PLAY</button>
                    <button class="info-btn" onclick="showTutorial()">ⓘ</button>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Added audio elements for sound effects -->
    <audio id="bgMusic" loop>
        <source src="assets/sounds/keno-bg-music.mp3" type="audio/mpeg">
    </audio>
    <audio id="selectionSound">
        <source src="assets/sounds/keno-select.mp3" type="audio/mpeg">
    </audio>
    <audio id="reviewSound">
        <source src="assets/sounds/keno-review.mp3" type="audio/mpeg">
    </audio>
    <audio id="winSound">
        <source src="assets/sounds/keno-win.mp3" type="audio/mpeg">
    </audio>
    <audio id="loseSound">
        <source src="assets/sounds/keno-lose.mp3" type="audio/mpeg">
    </audio>
    <audio id="drawSound">
        <source src="assets/sounds/keno-draw.mp3" type="audio/mpeg">
    </audio>
    
    <!-- Tutorial Modal -->
    <div class="modal-overlay" id="tutorialModal">
        <div class="modal-content">
            <button class="modal-close" onclick="closeTutorial()">✕</button>
            <div class="modal-icon" id="tutorialIcon">🎓</div>
            <h2 class="modal-title">How to Play Keno</h2>
            
            <div class="tutorial-steps">
                <div class="tutorial-step active" data-step="1">
                    <h4>Step 1: Pick Your Numbers</h4>
                    <p>Select exactly 10 numbers from the grid (1-80). Click on any number to select it. Selected numbers will turn gold. You can also use "QUICK PICK" for random selection.</p>
                </div>
                <div class="tutorial-step" data-step="2">
                    <h4>Step 2: Set Your Bet</h4>
                    <p>Use the + and - buttons to adjust your bet amount. Minimum bet is ₦1,000. Your bet will be deducted from your Play Balance (referral earnings).</p>
                </div>
                <div class="tutorial-step" data-step="3">
                    <h4>Step 3: Play the Game</h4>
                    <!-- Updated to say 10 numbers instead of 15 -->
                    <p>Click the red "PLAY" button to start. The system will randomly draw 10 gold numbers. Watch as the drawn numbers light up on the grid!</p>
                </div>
                <div class="tutorial-step" data-step="4">
                    <h4>Step 4: Win Prizes</h4>
                    <p>The more numbers you match, the bigger your prize! Winnings are added to Game Earnings. 60% win rate, 40% loss rate.</p>
                    <div class="prize-table">
                        <h4>Prize Table</h4>
                        <div class="prize-row"><span>3 Matches</span><span>1.0x</span></div>
                        <div class="prize-row"><span>4 Matches</span><span>1.5x</span></div>
                        <div class="prize-row"><span>5 Matches</span><span>2.0x</span></div>
                        <div class="prize-row"><span>6 Matches</span><span>3.0x</span></div>
                        <div class="prize-row"><span>7 Matches</span><span>4.0x</span></div>
                        <div class="prize-row"><span>8 Matches</span><span>4.5x</span></div>
                        <!-- Fixed 9 matches multiplier to 5.0x -->
                        <div class="prize-row"><span>9 Matches</span><span>5.0x</span></div>
                    </div>
                </div>
            </div>
            
            <div class="tutorial-progress">
                <span id="tutorialStepText">Step 1 of 4</span>
                <div class="tutorial-dots">
                    <div class="tutorial-dot active"></div>
                    <div class="tutorial-dot"></div>
                    <div class="tutorial-dot"></div>
                    <div class="tutorial-dot"></div>
                </div>
            </div>
            
            <div class="tutorial-navigation">
                <button class="tutorial-nav-btn" id="tutorialPrevBtn" onclick="previousTutorialStep()" disabled>
                    ← Back
                </button>
                <button class="tutorial-nav-btn" id="tutorialNextBtn" onclick="nextTutorialStep()">
                    Next →
                </button>
            </div>
            
            <p style="margin: 20px 0; color: rgba(255, 255, 255, 0.7);">
                Need more help? <a href="https://www.youtube.com/watch?v=keno-tutorial" target="_blank" style="color: var(--page-mint);">Watch Tutorial Video</a>
            </p>
        </div>
    </div>
    
    <!-- Balance Exchange Modal -->
    <div class="modal-overlay" id="exchangeModal">
        <div class="modal-content">
            <button class="modal-close" onclick="closeExchangeModal()">✕</button>
            <div class="modal-icon">💱</div>
            <h2 class="modal-title">Exchange Game Earnings</h2>
            <p class="modal-message">Convert your Game Earnings to Task Balance for withdrawals.</p>
            <div style="background: rgba(77, 225, 193, 0.1); padding: 15px; border-radius: 10px; margin: 20px 0;">
                <p style="margin-bottom: 10px;">Available Game Earnings:</p>
                <p style="font-size: 2rem; font-weight: 700; color: var(--page-mint);" id="availableGameEarnings">₦0.00</p>
            </div>
            <input type="number" class="exchange-input" id="exchangeAmount" placeholder="Enter amount to exchange" min="100" step="100">
            <button class="modal-btn" onclick="exchangeBalance()">Exchange Now</button>
        </div>
    </div>
    
    <!-- Upgrade Required Modal -->
    <div class="modal-overlay upgrade-modal" id="upgradeModal">
        <div class="modal-content">
            <button class="modal-close" onclick="closeUpgradeModal()">✕</button>
            <div class="modal-icon">🔒</div>
            <h2 class="modal-title">Premium Membership Required</h2>
            <p class="modal-message">
                This game is exclusively for Premium Members. Upgrade now to unlock all games and start winning real rewards!
            </p>
            <div style="background: rgba(251, 146, 60, 0.1); padding: 20px; border-radius: 10px; margin: 20px 0; text-align: left;">
                <h4 style="color: var(--page-orange); margin-bottom: 15px;">Premium Benefits:</h4>
                <p style="margin-bottom: 8px;">✓ Access to all games</p>
                <p style="margin-bottom: 8px;">✓ Higher winning rates</p>
                <p style="margin-bottom: 8px;">✓ Exclusive tournaments</p>
                <p>✓ Priority support</p>
            </div>
            <button class="modal-btn" onclick="window.location.href='membership.php'" style="background: linear-gradient(135deg, #fb923c, #f97316);">
                Upgrade to Premium
            </button>
        </div>
    </div>
    
    <!-- Removed Deposit Modal -->
    
    <!-- Result Modal -->
    <div class="modal-overlay" id="resultModal">
        <div class="modal-content">
            <div class="modal-icon" id="resultIcon">🎉</div>
            <h2 class="modal-title" id="resultTitle">You Won!</h2>
            <p style="font-size: 3rem; font-weight: 900; color: var(--page-mint); margin: 20px 0;" id="resultAmount">₦0.00</p>
            <p class="modal-message" id="resultMessage">Your winnings have been added to Game Earnings!</p>
            <button class="modal-btn" onclick="closeResultModal()">Claim Reward</button>
            <button class="modal-btn" onclick="playAgain()" style="background: rgba(255, 255, 255, 0.1);">Play Again</button>
        </div>
    </div>
    
    <!-- Notification Modal (replaces alert()) -->
    <div class="modal-overlay" id="notificationModal">
        <div class="modal-content">
            <button class="modal-close" onclick="closeNotificationModal()">✕</button>
            <div class="modal-icon" id="notificationIcon">ℹ️</div>
            <h2 class="modal-title" id="notificationTitle">Notification</h2>
            <p class="modal-message" id="notificationMessage"></p>
            <button class="modal-btn" onclick="closeNotificationModal()">OK</button>
        </div>
    </div>
    
    <script>
        const PAYSTACK_PUBLIC_KEY = 'pk_test_2889acc30e717c743676ced0e02e0e1ad4d274fe';
        const USER_EMAIL = '<?php echo $user_email; ?>';
        const IS_PREMIUM = <?php echo $is_premium ? 'true' : 'false'; ?>;
        
        let selectedNumbers = new Set();
        let isPlaying = false;
        let hasSeenTutorial = localStorage.getItem('keno_tutorial_seen') === 'true';
        let currentTutorialStep = 1;
        const totalTutorialSteps = 4;
        let betAmount = 1; // This represents thousands (1 = ₦1,000)
        
        /* Added sound management system */
        let isMuted = localStorage.getItem('keno_sound_muted') === 'true';
        const sounds = {
            bgMusic: document.getElementById('bgMusic'),
            selection: document.getElementById('selectionSound'),
            review: document.getElementById('reviewSound'),
            win: document.getElementById('winSound'),
            lose: document.getElementById('loseSound'),
            draw: document.getElementById('drawSound')
        };
        
        // Set initial volumes
        sounds.bgMusic.volume = 0.3;
        sounds.selection.volume = 0.5;
        sounds.review.volume = 0.6;
        sounds.win.volume = 0.7;
        sounds.lose.volume = 0.5;
        sounds.draw.volume = 0.4;
        
        function playSound(soundName) {
            if (isMuted) return;
            
            const sound = sounds[soundName];
            if (sound) {
                sound.currentTime = 0;
                sound.play().catch(e => console.log('[v0] Sound play failed:', e));
            }
        }
        
        function toggleMute() {
            isMuted = !isMuted;
            localStorage.setItem('keno_sound_muted', isMuted);
            
            const volumeControl = document.getElementById('volumeControl');
            volumeControl.textContent = isMuted ? '🔇' : '🔊';
            volumeControl.classList.toggle('muted', isMuted);
            
            if (isMuted) {
                sounds.bgMusic.pause();
            } else {
                if (!isPlaying) {
                    sounds.bgMusic.play().catch(e => console.log('[v0] Music play failed:', e));
                }
            }
        }
        
        // Initialize volume control state
        document.addEventListener('DOMContentLoaded', () => {
            const volumeControl = document.getElementById('volumeControl');
            if (isMuted) {
                volumeControl.textContent = '🔇';
                volumeControl.classList.add('muted');
            }
            
            // Start background music on page load
            if (!isMuted) {
                setTimeout(() => {
                    sounds.bgMusic.play().catch(e => {
                        console.log('[v0] Auto-play blocked, waiting for user interaction');
                    });
                }, 500);
            }
        });
        
        function createParticles() {
            const particlesContainer = document.getElementById('particles');
            for (let i = 0; i < 20; i++) {
                const particle = document.createElement('div');
                particle.className = 'particle';
                particle.style.left = Math.random() * 100 + '%';
                particle.style.animationDelay = Math.random() * 10 + 's';
                particle.style.animationDuration = (Math.random() * 10 + 10) + 's';
                particlesContainer.appendChild(particle);
            }
        }
        
        createParticles();
        
        function initKenoGrid() {
            const grid = document.getElementById('kenoGrid');
            for (let i = 1; i <= 80; i++) {
                const numberDiv = document.createElement('div');
                numberDiv.className = 'keno-number';
                numberDiv.textContent = i;
                numberDiv.dataset.number = i;
                numberDiv.onclick = () => toggleNumber(i);
                grid.appendChild(numberDiv);
            }
        }
        
        function toggleNumber(num) {
            if (isPlaying) return;
            
            const numberDiv = document.querySelector(`[data-number="${num}"]`);
            
            if (selectedNumbers.has(num)) {
                selectedNumbers.delete(num);
                numberDiv.classList.remove('selected');
            } else {
                if (selectedNumbers.size < 10) {
                    selectedNumbers.add(num);
                    numberDiv.classList.add('selected');
                }
            }
            
            /* Play selection sound when number is selected/deselected */
            playSound('selection');
            
            updateSelectedCount();
        }
        
        function updateSelectedCount() {
            document.getElementById('selectedCount').textContent = selectedNumbers.size;
        }
        
        function quickPick() {
            if (isPlaying) return;
            clearSelection();
            
            while (selectedNumbers.size < 10) {
                const randomNum = Math.floor(Math.random() * 80) + 1;
                if (!selectedNumbers.has(randomNum)) {
                    selectedNumbers.add(randomNum);
                    document.querySelector(`[data-number="${randomNum}"]`).classList.add('selected');
                }
            }
            
            /* Play review selection sound for quick pick */
            playSound('review');
            
            updateSelectedCount();
        }
        
        function clearSelection() {
            if (isPlaying) return;
            
            selectedNumbers.forEach(num => {
                const numberDiv = document.querySelector(`[data-number="${num}"]`);
                numberDiv.classList.remove('selected', 'drawn', 'matched');
            });
            
            selectedNumbers.clear();
            updateSelectedCount();
        }
        
        /* Show tutorial on first visit */
        if (!hasSeenTutorial) {
            setTimeout(() => {
                const modal = document.getElementById('tutorialModal');
                modal.style.display = 'flex';
                setTimeout(() => modal.classList.add('active'), 10);
            }, 500);
        }
        
        function showTutorial() {
            currentTutorialStep = 1;
            updateTutorialDisplay();
            /* Fixed tutorial modal not showing by ensuring display is set */
            const modal = document.getElementById('tutorialModal');
            modal.style.display = 'flex';
            setTimeout(() => modal.classList.add('active'), 10);
        }
        
        function nextTutorialStep() {
            if (currentTutorialStep < totalTutorialSteps) {
                currentTutorialStep++;
                updateTutorialDisplay();
            } else {
                closeTutorial();
            }
        }
        
        function previousTutorialStep() {
            if (currentTutorialStep > 1) {
                currentTutorialStep--;
                updateTutorialDisplay();
            }
        }
        
        function updateTutorialDisplay() {
            document.querySelectorAll('.tutorial-step').forEach((step, index) => {
                step.classList.toggle('active', index + 1 === currentTutorialStep);
            });
            
            document.querySelectorAll('.tutorial-dot').forEach((dot, index) => {
                dot.classList.toggle('active', index + 1 === currentTutorialStep);
            });
            
            document.getElementById('tutorialStepText').textContent = `Step ${currentTutorialStep} of ${totalTutorialSteps}`;
            
            document.getElementById('tutorialPrevBtn').disabled = currentTutorialStep === 1;
            document.getElementById('tutorialNextBtn').textContent = currentTutorialStep === totalTutorialSteps ? "Let's Play! 🎮" : "Next →";
            
            const icons = ['🎓', '💰', '🎯', '🏆'];
            document.getElementById('tutorialIcon').textContent = icons[currentTutorialStep - 1];
        }
        
        function closeTutorial() {
            localStorage.setItem('keno_tutorial_seen', 'true');
            const modal = document.getElementById('tutorialModal');
            modal.classList.remove('active');
            /* Hide modal after transition */
            setTimeout(() => modal.style.display = 'none', 300);
        }
        
        function increaseBet() {
            betAmount = Math.min(betAmount + 5, 100);
            updateBetDisplay();
        }
        
        function decreaseBet() {
            betAmount = Math.max(betAmount - 5, 1);
            updateBetDisplay();
        }
        
        function increaseBetSmall() {
            betAmount = Math.min(betAmount + 1, 100);
            updateBetDisplay();
        }
        
        function decreaseBetSmall() {
            betAmount = Math.max(betAmount - 1, 1);
            updateBetDisplay();
        }
        
        function updateBetDisplay() {
            document.getElementById('betDisplay').textContent = '₦' + (betAmount * 1000).toLocaleString();
        }
        
        function showNotification(title, message, icon = 'ℹ️') {
            const modal = document.getElementById('notificationModal');
            document.getElementById('notificationIcon').textContent = icon;
            document.getElementById('notificationTitle').textContent = title;
            document.getElementById('notificationMessage').innerHTML = message; // Use innerHTML to allow for <br> and <strong> tags
            modal.style.display = 'flex';
            setTimeout(() => modal.classList.add('active'), 10);
        }
        
        function closeNotificationModal() {
            const modal = document.getElementById('notificationModal');
            modal.classList.remove('active');
            setTimeout(() => modal.style.display = 'none', 300);
        }

        async function playGame() {
            if (isPlaying) return;
            
            if (!IS_PREMIUM) {
                document.getElementById('upgradeModal').classList.add('active');
                return;
            }
            
            if (selectedNumbers.size !== 10) {
                showNotification('Selection Required', 'Please select exactly 10 numbers to play!', '⚠️');
                return;
            }
            
            const actualBetAmount = betAmount * 1000;
            
            const balanceText = document.getElementById('gameBalance').textContent.replace('₦', '').replace(/,/g, '');
            const currentBalance = Number(balanceText);
            
            console.log('[v0] Keno Balance Check:', {
                currentBalance: currentBalance,
                actualBetAmount: actualBetAmount,
                hasEnough: currentBalance >= actualBetAmount
            });
            
            if (currentBalance < actualBetAmount) {
                console.log('[v0] Insufficient balance for Keno');
                showInsufficientBalanceModal(actualBetAmount, currentBalance);
                return;
            }
            
            isPlaying = true;
            document.getElementById('playBtn').disabled = true;
            
            sounds.bgMusic.pause();
            
            try {
                const response = await fetch('api/keno-play.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ 
                        bet_amount: actualBetAmount,
                        selected_numbers: Array.from(selectedNumbers)
                    })
                });
                
                const data = await response.json();
                
                if (data.success) {
                    await animateDrawnNumbers(data.drawn_numbers, data.matched_numbers);
                    document.getElementById('gameBalance').textContent = '₦' + parseFloat(data.game_earnings).toLocaleString('en-NG', {minimumFractionDigits: 2, maximumFractionDigits: 2});
                    showResult(data.win_amount, data.matches, data.multiplier);
                } else {
                    if (data.upgrade_required) {
                        document.getElementById('upgradeModal').classList.add('active');
                    } else if (data.insufficient_balance) {
                        // This case is now handled by showInsufficientBalanceModal which redirects to membership.php
                        console.log("Insufficient balance detected, redirection should occur.");
                    } else {
                        console.error('[v0] Keno Error:', data);
                        let errorMsg = data.message || 'An error occurred';
                        if (data.error_details) {
                            // Corrected JSON stringify to replace newline characters for HTML display
                            errorMsg += '<br><br><strong>Details:</strong><br>' + JSON.stringify(data.error_details, null, 2).replace(/\n/g, '<br>');
                        }
                        showNotification('Error', errorMsg, '⚠️');
                    }
                    
                    if (!isMuted) {
                        sounds.bgMusic.play().catch(e => console.log('[v0] Music resume failed:', e));
                    }
                }
            } catch (error) {
                console.error('[v0] Keno Connection Error:', error);
                showNotification('Connection Error', 'Connection error: ' + error.message + '<br><br>Please check your internet connection and try again.', '⚠️');
                
                if (!isMuted) {
                    sounds.bgMusic.play().catch(e => console.log('[v0] Music resume failed:', e));
                }
            }
            
            isPlaying = false;
            document.getElementById('playBtn').disabled = false;
        }
        
        function showInsufficientBalanceModal(requiredAmount, currentBalance) {
            const deficit = requiredAmount - currentBalance;
            const message = `Insufficient Balance!<br><br>You need ₦${requiredAmount.toLocaleString('en-NG')} to play, but you only have ₦${currentBalance.toLocaleString('en-NG', {minimumFractionDigits: 2, maximumFractionDigits: 2})} in your Play Balance.<br><br>You need ₦${deficit.toLocaleString('en-NG', {minimumFractionDigits: 2, maximumFractionDigits: 2})} more.<br><br>Click OK to go to the deposit page.`;
            
            // Replaced alert() with showNotification() and handled confirmation logic
            showNotification('Insufficient Balance', message, '⚠️');
            
            // Need to wait for the modal to be visible and then use a confirm-like logic
            // For now, we'll use a simpler approach by checking the button click after the notification is shown
            // A more robust solution would involve custom modal buttons with callbacks.
            // This temporary solution uses a slightly delayed confirmation.
            setTimeout(() => {
                const userConfirmed = confirm("Redirect to deposit page?"); // Fallback for confirmation
                if (userConfirmed) {
                    window.location.href = 'membership.php';
                }
            }, 500); // Give the modal time to appear
        }

        async function animateDrawnNumbers(drawnNumbers, matchedNumbers) {
            for (let i = 0; i < drawnNumbers.length; i++) {
                await new Promise(resolve => setTimeout(resolve, 200));
                
                const num = drawnNumbers[i];
                const numberDiv = document.querySelector(`[data-number="${num}"]`);
                
                /* Play draw sound for each number drawn */
                playSound('draw');
                
                if (matchedNumbers.includes(num)) {
                    numberDiv.classList.add('matched');
                } else {
                    numberDiv.classList.add('drawn');
                }
            }
        }
        
        function showResult(amount, matches, multiplier) {
            const resultModal = document.getElementById('resultModal');
            const resultIcon = document.getElementById('resultIcon');
            const resultTitle = document.getElementById('resultTitle');
            const resultAmount = document.getElementById('resultAmount');
            const resultMessage = document.getElementById('resultMessage');
            
            /* Play win or lose sound based on matches */
            if (matches >= 3) {
                playSound('win');
            } else {
                playSound('lose');
            }
            
            if (matches >= 7) {
                resultIcon.textContent = '🎰';
                resultTitle.textContent = 'JACKPOT!';
            } else if (matches >= 5) {
                resultIcon.textContent = '🎉';
                resultTitle.textContent = 'Big Win!';
            } else if (matches >= 3) {
                resultIcon.textContent = '✨';
                resultTitle.textContent = 'You Won!';
            } else {
                resultIcon.textContent = '😔';
                resultTitle.textContent = 'Try Again!';
            }
            
            resultAmount.textContent = '₦' + parseFloat(amount).toLocaleString('en-NG', {minimumFractionDigits: 2, maximumFractionDigits: 2});
            resultMessage.textContent = matches > 0 ? `You matched ${matches} numbers! (${multiplier}x)` : 'Better luck next time!';
            
            // Make result modal visible
            resultModal.style.display = 'flex';
            setTimeout(() => resultModal.classList.add('active'), 10);
            
            /* Resume background music after showing result */
            setTimeout(() => {
                if (!isMuted) {
                    sounds.bgMusic.play().catch(e => console.log('[v0] Music resume failed:', e));
                }
            }, 2000);
        }
        
        function closeResultModal() {
            const modal = document.getElementById('resultModal');
            modal.classList.remove('active');
            setTimeout(() => modal.style.display = 'none', 300);
        }
        
        function playAgain() {
            closeResultModal();
            clearSelection();
        }
        
        function openBalanceModal(type) {
            if (type === 'game') {
                const gameBalance = document.getElementById('gameBalance').textContent.replace('₦', '').replace(/,/g, '');
                document.getElementById('availableGameEarnings').textContent = '₦' + parseFloat(gameBalance).toLocaleString('en-NG', {minimumFractionDigits: 2, maximumFractionDigits: 2});
                /* Fixed exchange modal not showing */
                const modal = document.getElementById('exchangeModal');
                modal.style.display = 'flex';
                setTimeout(() => modal.classList.add('active'), 10);
            }
        }
        
        function closeExchangeModal() {
            const modal = document.getElementById('exchangeModal');
            modal.classList.remove('active');
            /* Hide modal after transition */
            setTimeout(() => modal.style.display = 'none', 300);
        }
        
        async function exchangeBalance() {
            const amount = parseFloat(document.getElementById('exchangeAmount').value);
            
            if (isNaN(amount) || amount <= 0) {
                showNotification('Invalid Amount', 'Please enter a valid amount', '⚠️');
                return;
            }
            
            try {
                const response = await fetch('api/exchange-balance-keno.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ amount })
                });
                
                const data = await response.json();
                
                if (data.success) {
                    document.getElementById('gameBalance').textContent = '₦' + parseFloat(data.game_earnings).toLocaleString('en-NG', {minimumFractionDigits: 2, maximumFractionDigits: 2});
                    
                    showNotification('Success', 'Balance exchanged successfully to Task Balance!', '✅');
                    closeExchangeModal();
                    
                    setTimeout(() => location.reload(), 1000);
                } else {
                    showNotification('Exchange Failed', data.message || 'Exchange failed', '⚠️');
                }
            } catch (error) {
                console.error('Error:', error);
                showNotification('Connection Error', 'Connection error. Please check your internet and try again.', '⚠️');
            }
        }
        
        function closeUpgradeModal() {
            const modal = document.getElementById('upgradeModal');
            modal.classList.remove('active');
            setTimeout(() => modal.style.display = 'none', 300);
        }
        
        // Deposits are now handled in membership.php
        
        initKenoGrid();
        updateBetDisplay();
        
    </script>
</body>
</html>
