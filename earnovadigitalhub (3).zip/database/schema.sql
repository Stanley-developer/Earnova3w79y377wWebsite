-- phpMyAdmin SQL Dump
-- version 5.2.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Dec 15, 2025 at 10:41 AM
-- Server version: 8.0.43-cll-lve
-- PHP Version: 8.4.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `workwave_enova`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_messages`
--

CREATE TABLE `admin_messages` (
  `id` int NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `message` text COLLATE utf8mb4_general_ci NOT NULL,
  `is_active` tinyint(1) DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `target_type` enum('all','specific') COLLATE utf8mb4_general_ci DEFAULT 'all'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin_messages`
--

INSERT INTO `admin_messages` (`id`, `title`, `message`, `is_active`, `created_at`, `updated_at`, `target_type`) VALUES
(18, 'Country Support Coming Soon', 'Dear Steven, Earnova Digital Hub will be available for Burkina Faso (XOF) in the next 30 days. Continue using our default Nigerian account (NGN). Your account will be upgraded when we support Burkina Faso and XOF.', 1, '2025-12-09 17:47:02', '2025-12-09 17:47:02', 'specific');

-- --------------------------------------------------------

--
-- Table structure for table `admin_notifications`
--

CREATE TABLE `admin_notifications` (
  `id` int NOT NULL,
  `title` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `message` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `notification_type` enum('popup','banner','telegram') COLLATE utf8mb4_unicode_ci NOT NULL,
  `target_audience` enum('all','new_users','premium','free') COLLATE utf8mb4_unicode_ci DEFAULT 'all',
  `is_active` tinyint(1) DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `advertisements`
--

CREATE TABLE `advertisements` (
  `id` int NOT NULL,
  `user_id` int NOT NULL,
  `title` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `ad_type` enum('social_media','website','other') COLLATE utf8mb4_unicode_ci NOT NULL,
  `target_url` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `budget` decimal(10,2) NOT NULL,
  `cost_per_action` decimal(10,2) NOT NULL,
  `total_actions` int DEFAULT '0',
  `remaining_budget` decimal(10,2) NOT NULL,
  `is_active` tinyint(1) DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `advertisements`
--

INSERT INTO `advertisements` (`id`, `user_id`, `title`, `description`, `ad_type`, `target_url`, `budget`, `cost_per_action`, `total_actions`, `remaining_budget`, `is_active`, `created_at`, `updated_at`) VALUES
(1, 1, 'Follow Obodo', 'Follow me please', 'social_media', 'https://tiktok.com', 500.00, 40.00, 0, 500.00, 1, '2025-10-05 19:20:15', '2025-10-05 19:20:15'),
(2, 1, 'Follow my tiktok account', 'Please Follow Obodo', 'social_media', 'https://tiktok.com', 500.00, 40.00, 0, 500.00, 1, '2025-10-06 21:09:31', '2025-10-06 21:09:31'),
(3, 1, 'Testing my error and success Message', 'Testing the Testing', 'social_media', 'https://tiktok.com', 600.00, 48.00, 0, 600.00, 1, '2025-10-06 21:15:15', '2025-10-06 21:15:15'),
(4, 1, 'sihckjldcio jdmlx', 'gfghjkli;oiuytrfvhbjnk', 'social_media', 'https://tiktok.com', 450.00, 36.00, 0, 450.00, 1, '2025-10-06 21:18:31', '2025-10-06 21:18:31'),
(5, 1, 'wdsckjx oi p;lso[x-l', 'zk,ml zsnxlpoklzm snxpik;', 'social_media', 'https://instagram.com', 600.00, 48.00, 0, 600.00, 1, '2025-10-06 21:24:07', '2025-10-06 21:24:07'),
(6, 1, 'dgfghjkl;\'', 'zdxfghujijkolk;,l\'.', 'social_media', 'https://tiktok.com', 400.00, 32.00, 0, 400.00, 1, '2025-10-06 21:34:57', '2025-10-06 21:34:57'),
(7, 1, 'Follow my instagram account', 'Follow Instagram account', 'social_media', 'https://whatsapp.com', 2400.00, 32.00, 0, 2400.00, 1, '2025-10-07 13:49:01', '2025-10-07 13:49:01'),
(8, 1, 'Obodo Dike', 'Descrie me nigga', 'social_media', 'https://pinterest.com', 500.00, 40.00, 0, 500.00, 1, '2025-10-09 19:06:41', '2025-10-09 19:06:41'),
(9, 1, 'Obodo Dike', 'Descrie me nigga', 'social_media', 'https://pinterest.com', 500.00, 40.00, 0, 500.00, 1, '2025-10-09 19:07:00', '2025-10-09 19:07:00'),
(24, 1, 'Website Task', 'Testing, don’t click please', 'social_media', 'https://tiktok.co.uk', 30000.00, 24.00, 0, 30000.00, 1, '2025-11-18 13:30:29', '2025-11-18 13:30:29'),
(25, 1, 'Testing', 'Testing', 'social_media', 'https://facebook.com', 30000.00, 24.00, 0, 30000.00, 1, '2025-11-18 17:09:23', '2025-12-01 13:01:32'),
(26, 1, 'Eidicck', 'Wyeth wyeyshehwuwhehwhwhwjw ejeidiwiwie ejeidieie sjdisieie sjdjdkeke sjdjdksks sjejdjejejjejejejekk', 'social_media', 'https://facebook.com', 300.00, 24.00, 0, 300.00, 1, '2025-11-18 17:27:35', '2025-11-18 17:27:35'),
(27, 1, 'Xmxkxkkxkx', 'Shshsjejjejsjs disk disk di sjdjdjsj sndjsjs1—11', 'social_media', 'https://youtube.com', 30000.00, 24.00, 0, 30000.00, 1, '2025-11-18 17:29:28', '2025-11-18 17:29:28'),
(28, 1, 'Testing task', 'testing reward calculation logic', 'social_media', 'https://soundcloud.com', 40000.00, 2.40, 0, 40000.00, 1, '2025-11-18 18:22:36', '2025-11-18 18:22:36'),
(29, 1, 'Follow me', '45', 'social_media', 'https://tiktok.com', 6800.00, 1.20, 0, 6800.00, 1, '2025-11-18 18:40:40', '2025-11-18 18:40:40'),
(30, 1, 'Sksksj snsjsjs sjsjsjs sjsjsj', 'Sisisis sjsjsjsjsj sjsjsjs', 'social_media', 'https://tiktok.com', 400.00, 1.20, 0, 400.00, 1, '2025-11-19 13:09:54', '2025-11-19 13:09:54'),
(31, 1, 'Sjsjddj', 'nzjzkxkxk', 'social_media', 'https://tikok.com', 25600.00, 1.92, 0, 25600.00, 1, '2025-11-19 14:25:07', '2025-11-24 15:37:49'),
(32, 1, 'Foolow sound cloud', 'Sound-God Runtown', 'social_media', 'https://soundcloud.com/', 400.00, 2.40, 0, 400.00, 1, '2025-11-19 20:14:56', '2025-11-19 20:14:56'),
(33, 1, 'Follow Me Emeka name', 'Follow Obodo', 'social_media', 'https://tikn.com', 640.00, 1.92, 0, 640.00, 1, '2025-11-21 11:46:15', '2025-11-24 15:37:12'),
(34, 50, 'Subscribe my channel', 'Make sure you subscribe', 'social_media', 'https://www.youtube.com/@StoriesTheBible_Told', 4000.00, 2.40, 0, 4000.00, 1, '2025-11-21 12:30:55', '2025-11-21 12:30:55'),
(35, 54, 'Cghgcg', 'Bbffhggx kc', 'social_media', 'https://www.youtube.com/@RossSmith-b4x', 4000.00, 2.40, 0, 4000.00, 1, '2025-11-21 20:20:42', '2025-11-21 20:20:42'),
(36, 54, 'Big kc', 'Hhshhsjhs bhdbhsdhhhhd', 'social_media', 'https://www.facebook.com/share/1Berhwq94c/', 1785.00, 2.10, 0, 1785.00, 1, '2025-11-22 07:09:00', '2025-11-24 21:43:25'),
(37, 46, 'Make sure you engage on it', 'Earnova has been exited for the past 3 years ago in Europe country. The company decided to bring it', 'social_media', 'https://vt.tiktok.com/ZSfBTTSbX/', 3200.00, 1.92, 0, 3200.00, 1, '2025-11-23 10:56:20', '2025-11-23 10:56:20'),
(38, 46, 'Audio', 'Audio mack', 'social_media', 'https://audiomack.com/obinnabest44/song/obi-odogwu-igala-soundwela?share-user-id=116106754', 1500.00, 1.80, 0, 1500.00, 1, '2025-11-24 11:38:16', '2025-11-24 11:38:16'),
(39, 46, 'Paly', 'Store', 'social_media', 'https://play.google.com/store/apps/details?id=com.adobe.photoshop.retail', 3500.00, 4.20, 0, 3500.00, 1, '2025-11-24 11:44:50', '2025-11-24 11:44:50'),
(40, 46, 'Pinterest', 'Pinterest', 'social_media', 'https://pin.it/7N49SqjAa', 1750.00, 2.10, 0, 1750.00, 1, '2025-11-24 11:46:42', '2025-11-24 11:46:42'),
(41, 46, 'Spotify', 'Spotify', 'social_media', 'https://open.spotify.com/track/09KqpiC1s599qgsbhcudgu?si=ndZyFyz5QEWy9felFWB9EQ&context=spotify%3Aplaylist%3A37i9dQZF1EIY57FUPBHiEp', 2000.00, 2.40, 0, 2000.00, 1, '2025-11-24 11:48:11', '2025-11-24 11:48:11'),
(42, 46, 'Boomplay', 'Boomplay', 'social_media', 'https://www.boomplay.com/share/music/219845356?srModel=COPYLINK&srList=ANDROID', 2250.00, 2.70, 0, 2250.00, 1, '2025-11-24 11:50:59', '2025-11-24 11:50:59'),
(43, 54, 'Follow the page', 'Make sure you follow', 'social_media', 'https://www.facebook.com/profile.php?id=61584270685508&mibextid=ZbWKwL', 700.00, 2.10, 0, 700.00, 1, '2025-11-24 21:40:09', '2025-11-24 21:44:50'),
(44, 59, 'Join', 'Fast fast', 'social_media', 'https://chat.whatsapp.com/EXp3ZVGrSrEB0KaZNt6HgH?mode=wwt', 640.00, 1.92, 0, 640.00, 1, '2025-11-25 07:39:30', '2025-11-25 07:39:30'),
(45, 1, 'Follow emeka', 'folow ngozi testing', 'social_media', 'https://facebook.com', 1400.00, 2.10, 0, 1400.00, 1, '2025-11-29 22:50:59', '2025-11-29 22:50:59'),
(46, 1, 'follow us', 'Follow testing', 'social_media', 'https://tiktok.com', 320.00, 1.92, 0, 320.00, 1, '2025-11-30 19:53:25', '2025-11-30 19:53:25'),
(47, 47, 'Hjyg', 'Join', 'social_media', 'https://whatsapp.com/channel/0029Vb3Ig8NCBtxBUVlOuB2n', 320.00, 1.92, 0, 320.00, 1, '2025-11-30 22:25:32', '2025-11-30 22:25:32'),
(48, 47, 'Now', 'Fast', 'social_media', 'https://t.me/earnovadigitalhub', 320.00, 1.92, 0, 320.00, 1, '2025-11-30 22:27:39', '2025-11-30 22:27:39'),
(49, 54, 'Good day', 'Please join', 'social_media', 'https://whatsapp.com/channel/0029Vb3Ig8NCBtxBUVlOuB2n', 1600.00, 1.92, 0, 1600.00, 1, '2025-12-01 08:13:21', '2025-12-01 08:13:21'),
(50, 54, 'My Joy', 'Go ahead', 'social_media', 'https://whatsapp.com/channel/0029Vb3Ig8NCBtxBUVlOuB2n', 3200.00, 1.92, 0, 3200.00, 1, '2025-12-01 08:14:30', '2025-12-01 08:14:30'),
(51, 1, 'follow emeka', 'follow', 'social_media', 'https://tiktok.com', 320.00, 1.92, 0, 320.00, 1, '2025-12-01 11:00:15', '2025-12-01 11:00:15'),
(52, 1, 'Testing', 'Testing', 'social_media', 'https://facebook.com', 350.00, 2.10, 0, 350.00, 1, '2025-12-01 11:37:55', '2025-12-01 11:37:55'),
(53, 1, 'Testing post task', 'Testing Post Task', 'social_media', 'https://instagram.com', 700.00, 2.10, 0, 700.00, 1, '2025-12-01 11:40:39', '2025-12-01 13:52:55'),
(54, 54, 'Good day Chief please download up', 'Nm.  Jjejdjjdjdjd. Hudhbdhduhrbdd buhbbhdb. Hh. Hjdhhdhdhdjhrbdbhdhd make sure you download my app', 'social_media', 'https://play.google.com', 10500.00, 4.20, 0, 10500.00, 1, '2025-12-02 16:43:56', '2025-12-02 16:43:56'),
(55, 47, 'Hhgffd good on', 'Please make sure to join', 'social_media', 'https://chat.whatsapp.com/EXp3ZVGrSrEB0KaZNt6HgH?mode=wwt', 3200.00, 1.92, 0, 3200.00, 1, '2025-12-04 06:15:08', '2025-12-04 06:15:08'),
(56, 64, 'Testing upline reward', 'Testing upline reward', 'social_media', 'https://wa.link', 32000.00, 1.92, 0, 32000.00, 1, '2025-12-05 16:45:05', '2025-12-05 16:45:05'),
(57, 64, 'Testing upline company', 'Testing', 'social_media', 'https://youtube.com/obodo', 20000.00, 2.40, 0, 20000.00, 1, '2025-12-05 16:51:21', '2025-12-05 16:51:21'),
(58, 47, 'Join', 'Fast', 'social_media', 'https://wa.link', 3200.00, 1.92, 0, 3200.00, 1, '2025-12-09 16:03:38', '2025-12-09 16:03:38'),
(59, 54, 'Bbffff', 'E sharp', 'social_media', 'https://wa.link/iei044', 35200.00, 1.92, 0, 35200.00, 1, '2025-12-10 13:42:42', '2025-12-11 23:13:47'),
(60, 1, 'testing kora pay', 'testing kora pay', 'social_media', 'https://instagram.com', 350.00, 2.10, 0, 350.00, 1, '2025-12-11 16:12:11', '2025-12-11 16:12:11'),
(61, 1, 'follow me tesing', 'testing testing', 'social_media', 'https://facebook.com', 6300.00, 2.10, 0, 6300.00, 1, '2025-12-11 16:19:19', '2025-12-11 16:19:19'),
(62, 1, 'kora kora', 'kora kora', 'social_media', 'https://wa.me', 28480.00, 1.92, 0, 28480.00, 1, '2025-12-11 17:02:35', '2025-12-11 17:02:35'),
(63, 1, 'kora kora', 'kora kora', 'social_media', 'https://t.me', 320.00, 1.92, 0, 320.00, 1, '2025-12-11 17:05:21', '2025-12-11 17:05:21'),
(64, 1, 'kora kora', 'kora kora', 'social_media', 'https://t.me', 320.00, 1.92, 0, 320.00, 1, '2025-12-11 17:20:48', '2025-12-11 17:20:48'),
(65, 1, 'follow kora', 'follow kora', 'social_media', 'https://tiktok.com', 25600.00, 1.92, 0, 25600.00, 1, '2025-12-11 17:23:50', '2025-12-11 17:23:50'),
(66, 1, 'kota kora kora', 'kora testing kora pay', 'social_media', 'https://instagram.com', 6615.00, 2.10, 0, 6615.00, 1, '2025-12-11 18:27:11', '2025-12-11 18:27:11'),
(67, 1, 'kora testing 56', 'kora testing 56', 'social_media', 'https://tiktok.com', 9600.00, 1.92, 0, 9600.00, 1, '2025-12-11 18:29:53', '2025-12-11 18:29:53'),
(68, 1, 'tiktok', 'tiktok kora pay', 'social_media', 'https://tiktok.com', 16000.00, 1.92, 0, 16000.00, 1, '2025-12-11 21:45:05', '2025-12-11 21:45:05'),
(69, 47, 'Join me', 'Good day', 'social_media', 'https://chat.whatsapp.com/EXp3ZVGrSrEB0KaZNt6HgH?mode=wwt', 3200.00, 1.92, 0, 3200.00, 1, '2025-12-11 22:24:51', '2025-12-11 22:24:51'),
(70, 1, 'Kora Pay Post Task Admin Testing', 'Kora Pay Post Task Admin Testing', 'social_media', 'https://soundcloud.com/', 500.00, 3.00, 0, 500.00, 1, '2025-12-12 12:07:35', '2025-12-12 12:07:35'),
(71, 1, 'follow emenekam', 'follow kora pay testing', 'social_media', 'https://wa.me', 28800.00, 1.92, 0, 28800.00, 1, '2025-12-12 12:26:11', '2025-12-12 12:26:11'),
(72, 1, 'testing kora pay', 'kora pay testing testing', 'social_media', 'https://fak.com', 25000.00, 3.00, 0, 25000.00, 1, '2025-12-12 12:31:34', '2025-12-12 12:31:34'),
(73, 1, 'kora pay 2', 'kora pay 2', 'social_media', 'https://wa.me', 28800.00, 1.92, 0, 28800.00, 1, '2025-12-12 13:35:01', '2025-12-12 13:35:01'),
(74, 1, 'follow testing', 'testing testing', 'social_media', 'https://facebook.com', 21000.00, 2.10, 0, 21000.00, 1, '2025-12-12 13:47:32', '2025-12-12 13:47:32'),
(75, 1, 'kora 31', 'kora 45', 'social_media', 'https://in.com', 45000.00, 3.00, 0, 45000.00, 1, '2025-12-12 13:54:54', '2025-12-12 13:54:54'),
(76, 1, 'follow kora', 'follow kora', 'social_media', 'https://website.com/', 45000.00, 3.00, 0, 45000.00, 1, '2025-12-12 13:57:29', '2025-12-12 13:57:29'),
(77, 1, 'kora testing 2', 'testing kora 3', 'social_media', 'https://menan.com', 50000.00, 3.00, 0, 50000.00, 1, '2025-12-12 14:00:30', '2025-12-12 14:00:30'),
(78, 1, 'follo pay stack', 'paystack', 'social_media', 'https://menan.com', 39450.00, 3.00, 0, 39450.00, 1, '2025-12-12 14:03:00', '2025-12-12 14:03:00'),
(79, 64, 'Follow me testing', 'Follow testing', 'social_media', 'https://t.me', 28128.00, 1.92, 0, 28128.00, 1, '2025-12-12 14:09:13', '2025-12-12 14:09:13'),
(80, 64, 'Testing 2', 'Testing 2', 'social_media', 'https://play.google.com', 70000.00, 4.20, 0, 70000.00, 1, '2025-12-12 14:14:23', '2025-12-12 14:14:23'),
(81, 64, 'Testing 3', 'Testing 3', 'social_media', 'https://play.google.com', 70000.00, 4.20, 0, 70000.00, 1, '2025-12-12 14:16:03', '2025-12-12 14:16:03'),
(82, 64, 'Paystack task', 'Paystack task', 'social_media', 'https://play.google.com', 69230.00, 4.20, 0, 69230.00, 1, '2025-12-12 14:46:36', '2025-12-12 14:46:36'),
(83, 64, 'Follow my ig', 'Follow Og posting', 'social_media', 'https://earnova-digital-hub.com', 50000.00, 3.00, 0, 50000.00, 1, '2025-12-12 17:22:05', '2025-12-12 17:22:05'),
(84, 64, 'Follow me obodo', 'Follow emenekam', 'social_media', 'https://play.google.com', 11830.00, 4.20, 0, 11830.00, 1, '2025-12-13 08:18:50', '2025-12-13 08:18:50'),
(85, 64, 'Follow God and me eche', 'Follow me eche', 'social_media', 'https://reddit.com', 35000.00, 2.10, 0, 35000.00, 1, '2025-12-13 08:28:34', '2025-12-13 08:28:34'),
(86, 64, 'Testing paystack', 'Testing paystack', 'social_media', 'https://x.com', 37962.00, 2.28, 0, 37962.00, 1, '2025-12-13 08:48:14', '2025-12-13 08:48:14'),
(87, 64, 'Follow chi chi', 'Follow chi chi', 'social_media', 'https://Facebook.com', 34965.00, 2.10, 0, 34965.00, 1, '2025-12-13 08:51:45', '2025-12-13 08:51:45'),
(88, 64, 'Uche', 'Uche', 'social_media', 'https://t.me/obodo', 3264.00, 1.92, 0, 3264.00, 1, '2025-12-13 08:55:34', '2025-12-13 08:55:34'),
(89, 64, 'Testing kora', 'Testing again', 'social_media', 'https://play.google.com', 7280.00, 4.20, 0, 7280.00, 1, '2025-12-13 09:30:26', '2025-12-13 09:30:26'),
(90, 64, 'Testing testing paystavk', 'Testing paystavk', 'social_media', 'https://play.google.com', 700.00, 4.20, 0, 700.00, 1, '2025-12-13 09:32:06', '2025-12-13 09:32:06'),
(91, 64, 'testing Upline 5% reward', 'testing Upline 5% reward', 'social_media', 'https://igital-hub.com', 50000.00, 3.00, 0, 50000.00, 1, '2025-12-13 10:27:01', '2025-12-13 11:45:00'),
(92, 64, 'Testing x.com', 'Testing x.com', 'social_media', 'https://x.com', 380000.00, 2.28, 0, 380000.00, 1, '2025-12-13 11:59:28', '2025-12-13 11:59:28'),
(93, 64, 'Follow my x account', 'Follow x or twitter account', 'social_media', 'https://x.com', 380000.00, 2.28, 0, 380000.00, 1, '2025-12-13 12:02:54', '2025-12-13 12:02:54'),
(94, 1, 'Follow twitter account', 'Follow twitter account', 'social_media', 'https://x.com', 60800.00, 2.28, 0, 60800.00, 1, '2025-12-13 15:42:17', '2025-12-13 15:42:17');

-- --------------------------------------------------------

--
-- Table structure for table `advertiser_payments`
--

CREATE TABLE `advertiser_payments` (
  `id` int NOT NULL,
  `user_id` int NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `plan_duration` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'yearly or monthly',
  `payment_method` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payment_reference` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('pending','completed','failed') COLLATE utf8mb4_unicode_ci DEFAULT 'pending',
  `is_renewal` tinyint(1) DEFAULT '0' COMMENT '1 if this is a renewal payment',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `advertiser_payments`
--

INSERT INTO `advertiser_payments` (`id`, `user_id`, `amount`, `plan_duration`, `payment_method`, `payment_reference`, `status`, `is_renewal`, `created_at`) VALUES
(19, 50, 2500.00, 'yearly', 'paystack', 'SENIOR_ADVERTISER_UPGRADE-cdf9t8imr35', 'completed', 0, '2025-11-21 12:19:46'),
(20, 1, 2500.00, 'yearly', 'paystack', 'SENIOR_ADVERTISER_UPGRADE-hjlu9lhd64', 'completed', 0, '2025-11-21 23:09:42'),
(21, 1, 2500.00, 'yearly', 'paystack', 'SENIOR_ADVERTISER_UPGRADE-t6fkbof1oc', 'completed', 1, '2025-11-21 23:13:59'),
(22, 51, 2500.00, 'yearly', 'paystack', 'SENIOR_ADVERTISER_UPGRADE-8gttoghnwsi', 'completed', 0, '2025-11-22 06:54:36'),
(23, 54, 2500.00, 'yearly', 'paystack', 'SENIOR_ADVERTISER_UPGRADE-twz4jpwh26', 'completed', 0, '2025-11-23 15:40:06'),
(24, 53, 2500.00, 'yearly', 'paystack', 'SENIOR_ADVERTISER_UPGRADE-2bay7zw3zrl', 'completed', 0, '2025-11-23 16:06:28'),
(25, 57, 2500.00, 'yearly', 'paystack', 'SENIOR_ADVERTISER_UPGRADE-dz6qfq2qs2f', 'completed', 0, '2025-11-24 13:58:24'),
(26, 59, 2500.00, 'yearly', 'paystack', 'SENIOR_ADVERTISER_UPGRADE-yp8ywg0l31t', 'completed', 0, '2025-11-25 07:43:54'),
(27, 60, 2500.00, 'yearly', 'paystack', 'SENIOR_ADVERTISER_UPGRADE-ivt8n1tkhb', 'completed', 0, '2025-11-25 08:21:42'),
(29, 52, 2500.00, 'yearly', 'paystack', 'SENIOR_ADVERTISER_UPGRADE-ht6ecskw13', 'completed', 0, '2025-11-27 11:34:43'),
(30, 61, 2500.00, 'yearly', 'paystack', 'SENIOR_ADVERTISER_UPGRADE-el5vfg7aynp', 'completed', 0, '2025-11-27 18:02:40'),
(31, 62, 2500.00, 'yearly', 'paystack', 'PREMIUM_PLUS_UPGRADE-ncvxj2xvwd', 'completed', 0, '2025-11-27 18:30:25'),
(32, 58, 2500.00, 'yearly', 'paystack', 'PREMIUM_PLUS_UPGRADE-cdb1s5h9ce', 'completed', 0, '2025-11-27 19:23:05'),
(33, 63, 2500.00, 'yearly', 'paystack', 'PREMIUM_PLUS_UPGRADE-g54t3lrdhte', 'completed', 0, '2025-11-27 20:06:43'),
(34, 64, 2500.00, 'yearly', 'paystack', 'PREMIUM_PLUS_UPGRADE-fge2jheqsn5', 'completed', 0, '2025-11-28 10:56:21'),
(35, 64, 2500.00, 'yearly', 'paystack', 'PREMIUM_PLUS_UPGRADE-5ek2bk8jl9k', 'completed', 1, '2025-11-29 19:45:09'),
(36, 54, 2500.00, 'yearly', 'paystack', 'PREMIUM_PLUS_UPGRADE-uhvih920xe', 'completed', 1, '2025-12-02 14:36:11'),
(37, 54, 2500.00, 'yearly', 'paystack', 'PREMIUM_PLUS_UPGRADE-uk63neq6igl', 'completed', 1, '2025-12-02 14:44:05'),
(38, 67, 2500.00, 'yearly', 'paystack', 'PREMIUM_PLUS_UPGRADE-6w0og61vwvx', 'completed', 0, '2025-12-03 09:02:58'),
(39, 69, 2500.00, 'yearly', 'paystack', 'PREMIUM_PLUS_UPGRADE-838jqe6yf6b', 'completed', 0, '2025-12-03 21:24:03'),
(40, 64, 2500.00, 'yearly', 'paystack', 'PREMIUM_PLUS_UPGRADE-q7v8e6ftyhn', 'completed', 1, '2025-12-04 20:37:17'),
(41, 54, 2500.00, 'yearly', 'paystack', 'PREMIUM_PLUS_UPGRADE-mtehh8jcza9', 'completed', 1, '2025-12-05 06:03:04'),
(43, 1, 2500.00, 'yearly', 'paystack', 'PREMIUM_PLUS_UPGRADE-n01vfl1z95s', 'completed', 1, '2025-12-11 12:17:46'),
(44, 54, 2500.00, 'yearly', 'paystack', 'EARNOVA-premium_plus_upgrade-54-1765543707-2609', 'completed', 1, '2025-12-12 12:49:13'),
(45, 1, 2500.00, 'yearly', 'paystack', 'EARNOVA-premium_plus_upgrade-1-1765621403-6878', 'completed', 1, '2025-12-13 10:23:58');

-- --------------------------------------------------------

--
-- Table structure for table `ad_invite_commissions`
--

CREATE TABLE `ad_invite_commissions` (
  `id` int NOT NULL,
  `referrer_id` int NOT NULL,
  `referred_user_id` int NOT NULL,
  `ad_purchase_amount` decimal(10,2) NOT NULL,
  `commission_amount` decimal(10,2) NOT NULL,
  `commission_percentage` decimal(5,2) DEFAULT '5.00',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `ad_invite_commissions`
--

INSERT INTO `ad_invite_commissions` (`id`, `referrer_id`, `referred_user_id`, `ad_purchase_amount`, `commission_amount`, `commission_percentage`, `created_at`) VALUES
(2, 1, 64, 20000.00, 1000.00, 5.00, '2025-12-05 16:51:21'),
(3, 47, 54, 32000.00, 1600.00, 5.00, '2025-12-10 13:42:42'),
(4, 1, 64, 50000.00, 2500.00, 5.00, '2025-12-13 10:27:01'),
(5, 1, 64, 380000.00, 19000.00, 5.00, '2025-12-13 11:59:28'),
(6, 1, 64, 380000.00, 19000.00, 5.00, '2025-12-13 12:02:54');

-- --------------------------------------------------------

--
-- Table structure for table `available_music`
--

CREATE TABLE `available_music` (
  `id` int NOT NULL,
  `music_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `artist` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `music_url` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `thumbnail_url` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `duration` int NOT NULL COMMENT 'Duration in seconds',
  `free_reward` decimal(10,2) DEFAULT '150.00',
  `premium_reward` decimal(10,2) DEFAULT '700.00',
  `is_active` tinyint(1) DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `available_music`
--

INSERT INTO `available_music` (`id`, `music_id`, `title`, `artist`, `music_url`, `thumbnail_url`, `duration`, `free_reward`, `premium_reward`, `is_active`, `created_at`) VALUES
(1, 'music_001', 'Obodo songs', 'FlowEarner Music', 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3', NULL, 240, 150.00, 700.00, 1, '2025-10-05 09:41:27'),
(2, 'music_002', 'Demo songs', 'FlowEarner Music', 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-2.mp3', NULL, 300, 150.00, 700.00, 1, '2025-10-05 09:41:27'),
(3, 'music_003', 'Obodo Song....', 'FlowEarner Music', 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-3.mp3', NULL, 280, 150.00, 700.00, 1, '2025-10-05 09:41:27');

-- --------------------------------------------------------

--
-- Table structure for table `available_videos`
--

CREATE TABLE `available_videos` (
  `id` int NOT NULL,
  `video_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `video_url` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `platform` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT 'youtube',
  `thumbnail_url` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `duration` int NOT NULL COMMENT 'Duration in seconds',
  `free_reward` decimal(10,2) DEFAULT '100.00',
  `premium_reward` decimal(10,2) DEFAULT '500.00',
  `is_active` tinyint(1) DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `is_compulsory` tinyint(1) DEFAULT '0' COMMENT 'Whether video is compulsory (1) or optional (0)',
  `uploaded_by_user_id` int DEFAULT NULL COMMENT 'User ID if uploaded by a user (NULL if admin)',
  `video_file_path` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'Path to uploaded MP4 file if any',
  `post_cost` decimal(10,2) DEFAULT '0.00' COMMENT 'Cost paid by user to post this video',
  `platform_price_per_10` decimal(10,2) DEFAULT '0.00' COMMENT 'Platform price per 10 participants at time of posting'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `available_videos`
--

INSERT INTO `available_videos` (`id`, `video_id`, `title`, `description`, `video_url`, `platform`, `thumbnail_url`, `duration`, `free_reward`, `premium_reward`, `is_active`, `created_at`, `is_compulsory`, `uploaded_by_user_id`, `video_file_path`, `post_cost`, `platform_price_per_10`) VALUES
(1, 'video_001', 'Ewo', 'Ewo By Ozama', 'https://youtube.com/embed/u_t7IpdSQ3A?si=70B0uyJp1jFtUeSz', 'youtube', NULL, 300, 100.00, 500.00, 1, '2025-10-05 09:41:27', 0, NULL, NULL, 0.00, 0.00),
(5, 'video_1764427950_692b08aecedbc', 'Testing Again', 'describe Testing again', 'https://x.com/testing.again', 'twitter', 'uploads/stream_thumbnails/thumbnail_1764427950_692b08aececb2.jpeg', 0, 50.00, 900.00, 1, '2025-11-29 14:52:30', 1, NULL, NULL, 0.00, 0.00),
(6, 'video_1764674278_692ecae6aa9b2', 'Watch well', 'Take notes', 'https://tiktok.com/testing', 'tiktok', 'uploads/stream_thumbnails/thumbnail_1764674278_692ecae6aa8a2.jpg', 0, 10.00, 75.00, 1, '2025-12-02 11:17:58', 0, NULL, NULL, 0.00, 0.00),
(7, 'video_1764674909_692ecd5d101b6', 'Good', 'Video', 'https://linkedIn.com/testing', 'linkedin', 'uploads/stream_thumbnails/thumbnail_1764674909_692ecd5d100a8.jpg', 0, 100.00, 75.00, 1, '2025-12-02 11:28:29', 0, NULL, NULL, 0.00, 0.00),
(8, 'video_1765743508_693f1b94e575f', 'Obodo Obodo', 'Obodo Nwoke', 'https://youtube.com/testing', 'tiktok', 'uploads/video_thumbnails/thumb_1765743508_693f1b94e2dfe.png', 30, 1.92, 2.88, 1, '2025-12-14 20:18:28', 0, 1, 'uploads/user_videos/video_1765743508_693f1b947f8b6.mp4', 0.00, 0.00),
(9, 'video_1765787835_693fc8bba83eb', 'follow Follow follow follow', 'follow Follow follow follow', 'https://x.com/testing.again', 'instagram', 'uploads/video_thumbnails/thumb_1765787835_693fc8bba71d6.jpeg', 30, 2.10, 3.15, 1, '2025-12-15 08:37:15', 0, 1, 'uploads/user_videos/video_1765787835_693fc8bb456c1.mp4', 0.00, 0.00);

-- --------------------------------------------------------

--
-- Table structure for table `balances`
--

CREATE TABLE `balances` (
  `id` int NOT NULL,
  `user_id` int NOT NULL,
  `total_balance` decimal(15,2) DEFAULT '0.00',
  `task_earnings` decimal(15,2) DEFAULT '1000.00',
  `referral_earnings` decimal(15,2) DEFAULT '0.00',
  `game_earnings` decimal(10,2) DEFAULT '0.00',
  `ad_commission_earnings` decimal(10,2) DEFAULT '0.00',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `balances`
--

INSERT INTO `balances` (`id`, `user_id`, `total_balance`, `task_earnings`, `referral_earnings`, `game_earnings`, `ad_commission_earnings`, `created_at`, `updated_at`) VALUES
(1, 1, 1569679.21, 9097.20, 1111740.01, 52507.00, 0.00, '2025-10-02 00:52:12', '2025-12-15 08:37:15'),
(45, 46, 912670.00, 250570.00, 556100.00, 0.00, 0.00, '2025-11-18 08:08:10', '2025-12-12 12:51:05'),
(46, 47, 162159.35, 90262.60, 37296.75, 0.00, 0.00, '2025-11-18 08:22:27', '2025-12-14 21:31:04'),
(50, 50, 2142.00, 2142.00, 0.00, 0.00, 0.00, '2025-11-20 16:12:51', '2025-11-28 06:45:37'),
(51, 51, 1298.00, 1298.00, 0.00, 0.00, 0.00, '2025-11-21 17:33:22', '2025-11-23 16:22:43'),
(52, 52, 700.00, 700.00, 0.00, 0.00, 0.00, '2025-11-21 18:27:01', '2025-11-27 11:44:51'),
(53, 53, 0.00, 0.00, 0.00, 0.00, 0.00, '2025-11-21 19:32:45', '2025-11-21 19:32:45'),
(54, 54, 177375.00, 45120.00, 94655.00, 5000.00, 0.00, '2025-11-21 20:08:05', '2025-12-14 05:38:34'),
(56, 56, 0.00, 0.00, 0.00, 0.00, 0.00, '2025-11-22 18:08:37', '2025-11-22 18:08:37'),
(57, 57, 70.00, 70.00, 0.00, 0.00, 0.00, '2025-11-24 13:57:42', '2025-11-24 14:08:55'),
(58, 58, 825.00, 325.00, 500.00, 0.00, 0.00, '2025-11-25 07:00:51', '2025-11-27 19:19:01'),
(59, 59, 2604.00, 1604.00, 1000.00, 0.00, 0.00, '2025-11-25 07:23:18', '2025-11-27 19:16:12'),
(60, 60, 0.00, 0.00, 0.00, 0.00, 0.00, '2025-11-25 08:20:57', '2025-11-25 08:20:57'),
(61, 61, 0.00, 0.00, 0.00, 0.00, 0.00, '2025-11-27 18:02:00', '2025-11-27 18:02:00'),
(62, 62, 0.00, 0.00, 0.00, 0.00, 0.00, '2025-11-27 18:12:28', '2025-11-27 18:12:28'),
(63, 63, 11522.00, 11522.00, 0.00, 0.00, 0.00, '2025-11-27 19:52:19', '2025-12-02 16:51:56'),
(64, 64, 2735948.00, 1460.00, 1717071.00, 0.00, 0.00, '2025-11-28 10:53:38', '2025-12-13 12:21:51'),
(65, 65, 0.00, 0.00, 0.00, 0.00, 0.00, '2025-11-30 11:21:59', '2025-11-30 11:21:59'),
(66, 66, 0.00, 0.00, 0.00, 0.00, 0.00, '2025-11-30 11:39:08', '2025-11-30 11:39:08'),
(67, 67, 0.00, 0.00, 0.00, 0.00, 0.00, '2025-12-03 08:24:52', '2025-12-03 08:24:52'),
(68, 68, 0.00, 0.00, 0.00, 0.00, 0.00, '2025-12-03 20:06:15', '2025-12-03 20:06:15'),
(69, 69, 0.00, 0.00, 0.00, 0.00, 0.00, '2025-12-03 21:20:44', '2025-12-03 21:20:44'),
(70, 70, 250000.00, 100000.00, 150000.00, 0.00, 0.00, '2025-12-04 10:03:06', '2025-12-04 10:27:55'),
(73, 73, 1000.00, 0.00, 500.00, 0.00, 0.00, '2025-12-10 11:03:53', '2025-12-14 12:46:07'),
(74, 74, 0.00, 0.00, 0.00, 0.00, 0.00, '2025-12-10 13:07:20', '2025-12-10 13:07:20'),
(75, 75, 0.00, 0.00, 0.00, 0.00, 0.00, '2025-12-10 13:10:42', '2025-12-10 13:10:42'),
(76, 76, 0.00, 0.00, 0.00, 0.00, 0.00, '2025-12-14 18:01:17', '2025-12-14 18:01:17');

-- --------------------------------------------------------

--
-- Table structure for table `billing_information`
--

CREATE TABLE `billing_information` (
  `id` int NOT NULL,
  `user_id` int NOT NULL,
  `full_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `city` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `state` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `country` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nigeria',
  `postal_code` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `chat_earn_emojis`
--

CREATE TABLE `chat_earn_emojis` (
  `id` int NOT NULL,
  `message_id` int NOT NULL,
  `emoji` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` int NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `chat_earn_history`
--

CREATE TABLE `chat_earn_history` (
  `id` int NOT NULL,
  `user_id` int NOT NULL,
  `paired_user_id` int NOT NULL,
  `paired_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `reward_claimed` tinyint(1) DEFAULT '0',
  `reward_claimed_at` datetime DEFAULT NULL,
  `first_message_sent` tinyint(1) DEFAULT '0',
  `first_message_sent_at` datetime DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `is_premium_pair` tinyint(1) DEFAULT '1' COMMENT 'TRUE if user was premium when paired',
  `can_view_details` tinyint(1) DEFAULT '1' COMMENT 'TRUE if user can see full details (premium)',
  `is_active` tinyint(1) DEFAULT '1' COMMENT 'TRUE if chat is still active, FALSE if expired or closed'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `chat_earn_history`
--

INSERT INTO `chat_earn_history` (`id`, `user_id`, `paired_user_id`, `paired_at`, `reward_claimed`, `reward_claimed_at`, `first_message_sent`, `first_message_sent_at`, `expires_at`, `is_premium_pair`, `can_view_details`, `is_active`) VALUES
(38, 46, 47, '2025-11-20 20:24:10', 0, NULL, 0, NULL, '2025-11-21 20:24:10', 1, 1, 1),
(39, 1, 47, '2025-11-21 12:13:03', 0, NULL, 0, NULL, '2025-11-22 12:13:03', 1, 1, 1),
(40, 50, 46, '2025-11-21 12:20:50', 0, NULL, 0, NULL, '2025-11-22 12:20:50', 1, 1, 1),
(42, 51, 47, '2025-11-22 07:00:05', 0, NULL, 0, NULL, '2025-11-23 07:00:05', 1, 1, 1),
(43, 47, 46, '2025-11-23 10:24:03', 0, NULL, 0, NULL, '2025-11-24 10:24:03', 1, 1, 1),
(45, 50, 51, '2025-11-23 10:39:06', 0, NULL, 0, NULL, '2025-11-24 10:39:06', 1, 1, 1),
(46, 1, 46, '2025-11-23 13:31:10', 0, NULL, 0, NULL, '2025-11-24 13:31:10', 1, 1, 1),
(47, 54, 51, '2025-11-23 15:43:05', 0, NULL, 0, NULL, '2025-11-24 15:43:05', 1, 1, 1),
(48, 51, 46, '2025-11-23 15:55:12', 0, NULL, 0, NULL, '2025-11-24 15:55:12', 1, 1, 1),
(49, 53, 51, '2025-11-23 16:13:01', 0, NULL, 0, NULL, '2025-11-24 16:13:01', 1, 1, 1),
(51, 47, 54, '2025-11-25 14:47:03', 0, NULL, 0, NULL, '2025-11-26 14:47:03', 1, 1, 1),
(52, 50, 47, '2025-11-28 05:26:41', 0, NULL, 0, NULL, '2025-11-29 05:26:41', 1, 1, 1),
(53, 1, 54, '2025-11-28 09:01:48', 0, NULL, 0, NULL, '2025-11-29 09:01:48', 1, 1, 1),
(54, 47, 50, '2025-11-28 15:50:36', 0, NULL, 0, NULL, '2025-11-29 15:50:36', 1, 1, 1),
(55, 54, 53, '2025-11-28 16:34:43', 0, NULL, 0, NULL, '2025-11-29 16:34:43', 1, 1, 1),
(56, 54, 46, '2025-11-30 09:11:04', 0, NULL, 0, NULL, '2025-12-01 09:11:04', 1, 1, 1),
(57, 47, 51, '2025-12-02 11:45:24', 0, NULL, 0, NULL, '2025-12-03 11:45:24', 1, 1, 1),
(58, 47, 53, '2025-12-04 06:25:38', 0, NULL, 0, NULL, '2025-12-05 06:25:38', 1, 1, 1),
(59, 54, 63, '2025-12-05 06:10:55', 0, NULL, 0, NULL, '2025-12-06 06:10:55', 1, 1, 1),
(60, 47, 1, '2025-12-09 16:00:01', 0, NULL, 0, NULL, '2025-12-10 16:00:01', 1, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `chat_earn_messages`
--

CREATE TABLE `chat_earn_messages` (
  `id` int NOT NULL,
  `user_id` int NOT NULL,
  `paired_user_id` int NOT NULL,
  `message_text` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `sent_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `is_from_user` tinyint(1) DEFAULT '1' COMMENT 'TRUE if message is from user, FALSE if from paired user'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `color_predictor_games`
--

CREATE TABLE `color_predictor_games` (
  `id` int NOT NULL,
  `user_id` int NOT NULL,
  `bet_amount` decimal(10,2) NOT NULL DEFAULT '0.00',
  `selected_color` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `result_color` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `multiplier` decimal(5,2) NOT NULL DEFAULT '0.00',
  `win_amount` decimal(10,2) NOT NULL DEFAULT '0.00',
  `is_free_play` tinyint(1) DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `color_predictor_stats`
--

CREATE TABLE `color_predictor_stats` (
  `id` int NOT NULL,
  `user_id` int NOT NULL,
  `total_games` int DEFAULT '0',
  `total_wins` int DEFAULT '0',
  `total_losses` int DEFAULT '0',
  `total_wagered` decimal(15,2) DEFAULT '0.00',
  `total_won` decimal(15,2) DEFAULT '0.00',
  `total_profit` decimal(15,2) DEFAULT '0.00',
  `biggest_win` decimal(10,2) DEFAULT '0.00',
  `win_streak` int DEFAULT '0',
  `best_win_streak` int DEFAULT '0',
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `daily_rewards`
--

CREATE TABLE `daily_rewards` (
  `id` int NOT NULL,
  `user_id` int NOT NULL,
  `reward_date` date NOT NULL,
  `reward_amount` decimal(10,2) NOT NULL,
  `claimed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `daily_rewards`
--

INSERT INTO `daily_rewards` (`id`, `user_id`, `reward_date`, `reward_amount`, `claimed_at`) VALUES
(1, 1, '2025-10-02', 50.00, '2025-10-02 01:18:47'),
(2, 1, '2025-10-05', 100.00, '2025-10-05 16:36:18'),
(26, 1, '2025-10-09', 50.00, '2025-10-09 17:24:12'),
(27, 1, '2025-10-12', 100.00, '2025-10-12 16:31:32'),
(28, 1, '2025-10-13', 100.00, '2025-10-12 22:31:27'),
(43, 50, '2025-11-21', 100.00, '2025-11-21 12:15:10'),
(44, 47, '2025-11-25', 100.00, '2025-11-25 14:52:00'),
(45, 50, '2025-11-28', 100.00, '2025-11-28 05:29:02');

-- --------------------------------------------------------

--
-- Table structure for table `device_login_verifications`
--

CREATE TABLE `device_login_verifications` (
  `id` int NOT NULL,
  `user_id` int NOT NULL,
  `device_fingerprint` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `verification_code` varchar(6) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `location` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `browser` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `os` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `expires_at` datetime NOT NULL,
  `is_used` tinyint(1) DEFAULT '0',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `device_registration_log`
--

CREATE TABLE `device_registration_log` (
  `id` int NOT NULL,
  `device_fingerprint` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` int NOT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `browser` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `os` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `registered_at` datetime DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `device_registration_log`
--

INSERT INTO `device_registration_log` (`id`, `device_fingerprint`, `user_id`, `ip_address`, `browser`, `os`, `registered_at`) VALUES
(24, '8b88e8c0ebaf12d815df4044c015119aedcf858ff28481a3557cf27694a0505b', 47, '102.90.100.163', 'Chrome 138', 'Android 10', '2025-11-18 08:22:27'),
(27, '3a95fcd553e316e3c841aef4eff0fb35e546b55507ed24c6e4f596de51decdf5', 50, '102.90.100.204', 'Chrome 138', 'Android 10', '2025-11-20 16:12:51'),
(28, '9e961b0f7a0f22d4b0a349ffc916e9fcfb02856e37aee199e6efe3015eace77d', 51, '102.90.117.164', 'Chrome 138', 'Android 10', '2025-11-21 17:33:22'),
(29, 'd3dad8e0d202d20eba11ed1e64f2c51657a40b3831543bd442783f1759cbcae1', 52, '191.96.227.90', 'Chrome 142', 'Windows 10', '2025-11-21 18:27:01'),
(30, '86beb3b48bc0c8fd617f794189f108d8c471d7f341aa91b4f1181409ea7a21f7', 53, '105.120.129.83', 'Chrome 140', 'Android 10', '2025-11-21 19:32:45'),
(31, '86beb3b48bc0c8fd617f794189f108d8c471d7f341aa91b4f1181409ea7a21f7', 54, '102.90.81.210', 'Chrome 140', 'Android 10', '2025-11-21 20:08:05'),
(33, '91da33a75eceef449451cbd093fd190d247f99665757de8acf98df3163bdc2d5', 56, '102.90.118.114', 'Chrome 142', 'Android 8', '2025-11-22 18:08:37'),
(34, '99efe2befafe1c449357a0958f47319f39e4dd906164cdebea0854875459f0fa', 58, '105.113.35.29', 'Chrome 138', 'Android 10', '2025-11-25 07:00:51'),
(35, '99efe2befafe1c449357a0958f47319f39e4dd906164cdebea0854875459f0fa', 59, '105.113.36.133', 'Chrome 138', 'Android 10', '2025-11-25 07:23:18'),
(36, 'd3dad8e0d202d20eba11ed1e64f2c51657a40b3831543bd442783f1759cbcae1', 62, '102.90.82.223', 'Chrome 142', 'Windows 10', '2025-11-27 18:12:28'),
(37, '40763d2070307251c7f3cd66df3d5f5dab9c82e5289017f8ee894110b529d845', 63, '102.90.82.194', 'Chrome 131', 'Android 10', '2025-11-27 19:52:19'),
(38, '18e99da0b2b1c6f38b136c76132524d8a273df91d31c3dceeb5e0aff9ec2f60c', 65, '102.90.82.223', 'Chrome 142', 'Android 10', '2025-11-30 11:21:59'),
(39, '40763d2070307251c7f3cd66df3d5f5dab9c82e5289017f8ee894110b529d845', 68, '102.90.118.177', 'Chrome 131', 'Android 10', '2025-12-03 20:06:15'),
(40, '5d70f8d71602a690116b4e3e549ae5930d432eac944290be5c40a82a6b3bcc99', 70, '102.88.110.186', 'Chrome 142', 'Android 10', '2025-12-04 10:03:06'),
(42, '9edb4e17ee4a49b3edb1ea908baa098d5a7aa04f0cdf25cc5ef33982d6903bae', 73, '102.90.117.247', 'Chrome 138', 'Android 10', '2025-12-10 12:03:53'),
(43, '6428b185d9a1d9af7b49f82a90aaf3360cfa17a495f1b629e1da0275fa1fe686', 74, '105.112.220.23', 'Chrome 136', 'Android 10', '2025-12-10 14:07:20'),
(44, '6428b185d9a1d9af7b49f82a90aaf3360cfa17a495f1b629e1da0275fa1fe686', 75, '105.112.220.23', 'Chrome 136', 'Android 10', '2025-12-10 14:10:42'),
(45, 'e9041ff33b1a686346141b4588e03860bb8b6a33029026625792deb80d1bd52a', 76, '102.90.97.11', 'Chrome 143', 'Android 8', '2025-12-14 19:01:17');

-- --------------------------------------------------------

--
-- Table structure for table `game_wins`
--

CREATE TABLE `game_wins` (
  `id` int NOT NULL,
  `user_id` int NOT NULL,
  `game_type` varchar(100) COLLATE utf8mb4_general_ci NOT NULL,
  `amount_won` decimal(10,2) NOT NULL DEFAULT '0.00',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `jobs`
--

CREATE TABLE `jobs` (
  `id` int NOT NULL,
  `title` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `career_category` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `requirements` text COLLATE utf8mb4_unicode_ci,
  `budget` decimal(15,2) NOT NULL,
  `payment_amount` decimal(15,2) NOT NULL DEFAULT '0.00',
  `duration_days` int NOT NULL DEFAULT '7',
  `location` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `job_type` enum('full-time','part-time','contract','freelance') COLLATE utf8mb4_unicode_ci NOT NULL,
  `contact_number` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `contact_email` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `supporting_file` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `slots_available` int DEFAULT '1',
  `slots_filled` int DEFAULT '0',
  `is_active` tinyint(1) DEFAULT '1',
  `created_by` int NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deadline` datetime DEFAULT NULL,
  `admin_contact_number` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('active','inactive','completed') COLLATE utf8mb4_unicode_ci DEFAULT 'active',
  `approval_status` enum('pending','approved','rejected') COLLATE utf8mb4_unicode_ci DEFAULT 'pending',
  `approved_by` int DEFAULT NULL,
  `approved_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `job_bids`
--

CREATE TABLE `job_bids` (
  `id` int NOT NULL,
  `job_id` int NOT NULL,
  `user_id` int NOT NULL,
  `cover_letter` text COLLATE utf8mb4_unicode_ci,
  `proposed_rate` decimal(15,2) DEFAULT NULL,
  `payment_amount` decimal(10,2) DEFAULT '0.00',
  `payment_source` enum('refbalance','taskbalance') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bid_status` enum('pending','approved','rejected') COLLATE utf8mb4_unicode_ci DEFAULT 'pending',
  `admin_notes` text COLLATE utf8mb4_unicode_ci,
  `bid_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `status` enum('pending','accepted','rejected') COLLATE utf8mb4_unicode_ci DEFAULT 'pending'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `korapay_post_task_payloads`
--

CREATE TABLE `korapay_post_task_payloads` (
  `id` int NOT NULL,
  `reference` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` int NOT NULL,
  `payload` json NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `korapay_post_task_payloads`
--

INSERT INTO `korapay_post_task_payloads` (`id`, `reference`, `user_id`, `payload`, `created_at`) VALUES
(1, 'EARNOVA-TASK-1-1765472464-3184', 1, '{\"title\": \"kora kora\", \"platform\": \"Earnova Digital Hub - Post Task\", \"task_url\": \"https://wa.me\", \"total_cost\": 28480, \"description\": \"kora kora\", \"participants\": 890, \"task_platform\": \"whatsapp\"}', '2025-12-11 17:01:04'),
(2, 'EARNOVA-TASK-1-1765472699-9096', 1, '{\"title\": \"kora kora\", \"platform\": \"Earnova Digital Hub - Post Task\", \"task_url\": \"https://t.me\", \"total_cost\": 320, \"description\": \"kora kora\", \"participants\": 10, \"task_platform\": \"telegram\"}', '2025-12-11 17:04:59'),
(3, 'EARNOVA-TASK-1-1765473795-6362', 1, '{\"title\": \"follow kora\", \"platform\": \"Earnova Digital Hub - Post Task\", \"task_url\": \"https://tiktok.com\", \"total_cost\": 25600, \"description\": \"follow kora\", \"participants\": 800, \"task_platform\": \"tiktok\"}', '2025-12-11 17:23:15'),
(4, 'EARNOVA-TASK-1-1765477552-9441', 1, '{\"title\": \"kota kora kora\", \"platform\": \"Earnova Digital Hub - Post Task\", \"task_url\": \"https://instagram.com\", \"total_cost\": 6614.999999999999, \"description\": \"kora testing kora pay\", \"participants\": 189, \"task_platform\": \"instagram\"}', '2025-12-11 18:25:52'),
(5, 'EARNOVA-TASK-1-1765477754-0132', 1, '{\"title\": \"kora testing 56\", \"platform\": \"Earnova Digital Hub - Post Task\", \"task_url\": \"https://tiktok.com\", \"total_cost\": 9600, \"description\": \"kora testing 56\", \"participants\": 300, \"task_platform\": \"tiktok\"}', '2025-12-11 18:29:14'),
(7, 'EARNOVA-TASK-47-1765491812-2338', 47, '{\"title\": \"Join me\", \"platform\": \"Earnova Digital Hub - Post Task\", \"task_url\": \"https://chat.whatsapp.com/EXp3ZVGrSrEB0KaZNt6HgH?mode=wwt\", \"total_cost\": 3200, \"description\": \"Good day\", \"participants\": 100, \"task_platform\": \"whatsapp\"}', '2025-12-11 22:23:32'),
(8, 'EARNOVA-TASK-47-1765491813-2528', 47, '{\"title\": \"Join me\", \"platform\": \"Earnova Digital Hub - Post Task\", \"task_url\": \"https://chat.whatsapp.com/EXp3ZVGrSrEB0KaZNt6HgH?mode=wwt\", \"total_cost\": 3200, \"description\": \"Good day\", \"participants\": 100, \"task_platform\": \"whatsapp\"}', '2025-12-11 22:23:33');

-- --------------------------------------------------------

--
-- Table structure for table `korapay_post_task_payments`
--

CREATE TABLE `korapay_post_task_payments` (
  `id` int NOT NULL,
  `user_id` int NOT NULL,
  `reference` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `status` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'success, pending, failed',
  `metadata` json DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `korapay_post_task_payments`
--

INSERT INTO `korapay_post_task_payments` (`id`, `user_id`, `reference`, `amount`, `status`, `metadata`, `created_at`, `updated_at`) VALUES
(1, 1, 'EARNOVA-TASK-1-1765469589-7453', 35000.00, 'success', '{\"user_id\": \"1\", \"platform\": \"Earnova Digital Hub - Post Task\", \"payment_type\": \"post_task_deposit\"}', '2025-12-11 16:13:37', '2025-12-11 16:13:37'),
(2, 1, 'EARNOVA-TASK-1-1765470098-0036', 320.00, 'success', '{\"user_id\": \"1\", \"platform\": \"Earnova Digital Hub - Post Task\", \"payment_type\": \"post_task_deposit\"}', '2025-12-11 16:22:06', '2025-12-11 16:22:06'),
(3, 1, 'EARNOVA-TASK-1-1765472464-3184', 28480.00, 'success', '{\"title\": \"kora kora\", \"user_id\": \"1\", \"platform\": \"Earnova Digital Hub - Post Task\", \"task_url\": \"https://wa.me\", \"total_cost\": 28480, \"description\": \"kora kora\", \"participants\": 890, \"payment_type\": \"post_task_deposit\", \"task_platform\": \"whatsapp\"}', '2025-12-11 17:02:35', '2025-12-11 17:02:35'),
(4, 1, 'EARNOVA-TASK-1-1765472699-9096', 320.00, 'success', '{\"title\": \"kora kora\", \"user_id\": \"1\", \"platform\": \"Earnova Digital Hub - Post Task\", \"task_url\": \"https://t.me\", \"total_cost\": 320, \"description\": \"kora kora\", \"participants\": 10, \"payment_type\": \"post_task_deposit\", \"task_platform\": \"telegram\"}', '2025-12-11 17:05:21', '2025-12-11 17:05:21'),
(5, 1, 'EARNOVA-TASK-1-1765473795-6362', 25600.00, 'success', '{\"title\": \"follow kora\", \"user_id\": \"1\", \"platform\": \"Earnova Digital Hub - Post Task\", \"task_url\": \"https://tiktok.com\", \"total_cost\": 25600, \"description\": \"follow kora\", \"participants\": 800, \"payment_type\": \"post_task_deposit\", \"task_platform\": \"tiktok\"}', '2025-12-11 17:23:50', '2025-12-11 17:23:50'),
(6, 1, 'EARNOVA-TASK-1-1765477552-9441', 6615.00, 'success', '{\"title\": \"kota kora kora\", \"user_id\": \"1\", \"platform\": \"Earnova Digital Hub - Post Task\", \"task_url\": \"https://instagram.com\", \"total_cost\": 6614.999999999999, \"description\": \"kora testing kora pay\", \"participants\": 189, \"payment_type\": \"post_task_deposit\", \"task_platform\": \"instagram\"}', '2025-12-11 18:27:11', '2025-12-11 18:27:11'),
(7, 1, 'EARNOVA-TASK-1-1765477754-0132', 9600.00, 'success', '{\"title\": \"kora testing 56\", \"user_id\": \"1\", \"platform\": \"Earnova Digital Hub - Post Task\", \"task_url\": \"https://tiktok.com\", \"total_cost\": 9600, \"description\": \"kora testing 56\", \"participants\": 300, \"payment_type\": \"post_task_deposit\", \"task_platform\": \"tiktok\"}', '2025-12-11 18:29:53', '2025-12-11 18:29:53'),
(8, 1, 'EARNOVA-TASK-1-1765489402-3486', 16000.00, 'success', '{\"title\": \"tiktok\", \"user_id\": \"1\", \"platform\": \"Earnova Digital Hub - Post Task\", \"task_url\": \"https://tiktok.com\", \"total_cost\": 16000, \"description\": \"tiktok kora pay\", \"participants\": 500, \"payment_type\": \"post_task_deposit\", \"task_platform\": \"tiktok\"}', '2025-12-11 21:45:05', '2025-12-11 21:45:05'),
(9, 47, 'EARNOVA-TASK-47-1765491873-4796', 3200.00, 'success', '{\"title\": \"Join me\", \"user_id\": \"47\", \"platform\": \"Earnova Digital Hub - Post Task\", \"task_url\": \"https://chat.whatsapp.com/EXp3ZVGrSrEB0KaZNt6HgH?mode=wwt\", \"total_cost\": 3200, \"description\": \"Good day\", \"participants\": 100, \"payment_type\": \"post_task_deposit\", \"task_platform\": \"whatsapp\"}', '2025-12-11 22:24:51', '2025-12-11 22:24:51'),
(10, 1, 'EARNOVA-TASK-1-1765541224-2822', 500.00, 'success', '{\"title\": \"Kora Pay Post Task Admin Testing\", \"user_id\": \"1\", \"platform\": \"Earnova Digital Hub - Post Task\", \"task_url\": \"https://soundcloud.com/\", \"total_cost\": 500, \"description\": \"Kora Pay Post Task Admin Testing\", \"participants\": 10, \"payment_type\": \"post_task_deposit\", \"task_platform\": \"website\"}', '2025-12-12 12:07:35', '2025-12-12 12:07:35'),
(11, 1, 'EARNOVA-TASK-1-1765542354-1669', 28800.00, 'success', '{\"title\": \"follow emenekam\", \"user_id\": \"1\", \"platform\": \"Earnova Digital Hub - Post Task\", \"task_url\": \"https://wa.me\", \"total_cost\": 28800, \"description\": \"follow kora pay testing\", \"participants\": 900, \"payment_type\": \"post_task_deposit\", \"task_platform\": \"whatsapp\"}', '2025-12-12 12:26:11', '2025-12-12 12:26:11'),
(12, 1, 'EARNOVA-TASK-1-1765542675-0903', 25000.00, 'success', '{\"title\": \"testing kora pay\", \"user_id\": \"1\", \"platform\": \"Earnova Digital Hub - Post Task\", \"task_url\": \"https://fak.com\", \"total_cost\": 25000, \"description\": \"kora pay testing testing\", \"participants\": 500, \"payment_type\": \"post_task_deposit\", \"task_platform\": \"website\"}', '2025-12-12 12:31:34', '2025-12-12 12:31:34'),
(13, 1, 'EARNOVA-TASK-1-1765542935-9222', 25600.00, 'success', '{\"title\": \"testing kora pay #21\", \"user_id\": \"1\", \"platform\": \"Earnova Digital Hub - Post Task\", \"task_url\": \"https://wa.me\", \"total_cost\": 25600, \"description\": \"testing kora pay #21\", \"participants\": 800, \"payment_type\": \"post_task_deposit\", \"task_platform\": \"whatsapp\"}', '2025-12-12 12:35:53', '2025-12-12 12:35:53'),
(14, 1, 'EARNOVA-TASK-1-1765547234-5443', 21000.00, 'success', '{\"title\": \"follow testing\", \"user_id\": \"1\", \"platform\": \"Earnova Digital Hub - Post Task\", \"task_url\": \"https://facebook.com\", \"total_cost\": 21000, \"description\": \"testing testing\", \"participants\": 600, \"payment_type\": \"post_task_deposit\", \"task_platform\": \"facebook\"}', '2025-12-12 13:47:32', '2025-12-12 13:47:32'),
(15, 1, 'EARNOVA-TASK-1-1765547992-7351', 50000.00, 'success', '{\"title\": \"kora testing 2\", \"user_id\": \"1\", \"platform\": \"Earnova Digital Hub - Post Task\", \"task_url\": \"https://menan.com\", \"total_cost\": 50000, \"description\": \"testing kora 3\", \"participants\": 1000, \"payment_type\": \"post_task_deposit\", \"task_platform\": \"website\"}', '2025-12-12 14:00:30', '2025-12-12 14:00:30'),
(16, 64, 'EARNOVA-TASK-64-1765548534-8879', 28128.00, 'success', '{\"title\": \"Follow me testing\", \"user_id\": \"64\", \"platform\": \"Earnova Digital Hub - Post Task\", \"task_url\": \"https://t.me\", \"total_cost\": 28128, \"description\": \"Follow testing\", \"participants\": 879, \"payment_type\": \"post_task_deposit\", \"task_platform\": \"telegram\"}', '2025-12-12 14:09:13', '2025-12-12 14:09:13'),
(17, 64, 'EARNOVA-TASK-64-1765548838-1556', 70000.00, 'success', '{\"title\": \"Testing 2\", \"user_id\": \"64\", \"platform\": \"Earnova Digital Hub - Post Task\", \"task_url\": \"https://play.google.com\", \"total_cost\": 70000, \"description\": \"Testing 2\", \"participants\": 1000, \"payment_type\": \"post_task_deposit\", \"task_platform\": \"playstore\"}', '2025-12-12 14:14:23', '2025-12-12 14:14:23'),
(18, 64, 'EARNOVA-TASK-64-1765613903-4059', 11830.00, 'success', '{\"title\": \"Follow me obodo\", \"user_id\": \"64\", \"platform\": \"Earnova Digital Hub - Post Task\", \"task_url\": \"https://play.google.com\", \"total_cost\": 11829.999999999998, \"description\": \"Follow emenekam\", \"participants\": 169, \"payment_type\": \"post_task_deposit\", \"task_platform\": \"playstore\"}', '2025-12-13 08:18:50', '2025-12-13 08:18:50'),
(19, 64, 'EARNOVA-TASK-64-1765618193-8020', 7280.00, 'success', '{\"title\": \"Testing kora\", \"user_id\": \"64\", \"platform\": \"Earnova Digital Hub - Post Task\", \"task_url\": \"https://play.google.com\", \"total_cost\": 7280, \"description\": \"Testing again\", \"participants\": 104, \"payment_type\": \"post_task_deposit\", \"task_platform\": \"playstore\"}', '2025-12-13 09:30:26', '2025-12-13 09:30:26');

-- --------------------------------------------------------

--
-- Table structure for table `korapay_transactions`
--

CREATE TABLE `korapay_transactions` (
  `id` int NOT NULL,
  `user_id` int NOT NULL,
  `korapay_reference` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Kora Pay transaction reference',
  `amount` decimal(15,2) NOT NULL,
  `currency` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT 'NGN',
  `payer_account_number` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'Payer bank account number',
  `payer_account_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'Payer name',
  `payer_bank_name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'Payer bank name',
  `transaction_narration` text COLLATE utf8mb4_unicode_ci,
  `status` enum('pending','success','failed') COLLATE utf8mb4_unicode_ci DEFAULT 'pending',
  `payment_type` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'Type: premium_upgrade, premium_plus_upgrade, or deposit',
  `deposit_purpose` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT 'general' COMMENT 'For deposits: ads, games, or general',
  `description` text COLLATE utf8mb4_unicode_ci,
  `received_at` datetime DEFAULT NULL COMMENT 'When payment was received',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `korapay_transactions`
--

INSERT INTO `korapay_transactions` (`id`, `user_id`, `korapay_reference`, `amount`, `currency`, `payer_account_number`, `payer_account_name`, `payer_bank_name`, `transaction_narration`, `status`, `payment_type`, `deposit_purpose`, `description`, `received_at`, `created_at`, `updated_at`) VALUES
(1, 1, 'EARNOVA-deposit-1-1765540091-3274', 4200.00, 'NGN', NULL, NULL, NULL, NULL, 'success', 'deposit', 'general', NULL, '2025-12-12 12:48:36', '2025-12-12 11:48:36', '2025-12-12 11:48:36'),
(2, 1, 'EARNOVA-deposit-1-1765540680-1652', 1300.00, 'NGN', NULL, NULL, NULL, 'Deposit for General Balance', 'success', 'deposit', 'general', 'Deposit for General Balance', '2025-12-12 12:58:19', '2025-12-12 11:58:19', '2025-12-12 11:58:19'),
(3, 64, 'EARNOVA-deposit-64-1765559761-7945', 1000000.00, 'NGN', NULL, NULL, NULL, 'Deposit for General Balance', 'success', 'deposit', 'general', 'Deposit for General Balance', '2025-12-12 18:16:35', '2025-12-12 17:16:35', '2025-12-12 17:16:35'),
(4, 64, 'EARNOVA-deposit-64-1765559817-5176', 500000.00, 'NGN', NULL, NULL, NULL, 'Deposit for General Balance', 'success', 'deposit', 'general', 'Deposit for General Balance', '2025-12-12 18:17:20', '2025-12-12 17:17:20', '2025-12-12 17:17:20'),
(5, 64, 'EARNOVA-deposit-64-1765559948-8584', 500000.00, 'NGN', NULL, NULL, NULL, 'Deposit for General Balance', 'success', 'deposit', 'general', 'Deposit for General Balance', '2025-12-12 18:19:41', '2025-12-12 17:19:41', '2025-12-12 17:19:41'),
(6, 64, 'EARNOVA-deposit-64-1765613053-2639', 2000.00, 'NGN', NULL, NULL, NULL, 'Deposit for General Balance', 'success', 'deposit', 'general', 'Deposit for General Balance', '2025-12-13 09:04:50', '2025-12-13 08:04:50', '2025-12-13 08:04:50'),
(7, 64, 'EARNOVA-deposit-64-1765613144-2285', 2300.00, 'NGN', NULL, NULL, NULL, 'Deposit for General Balance', 'success', 'deposit', 'general', 'Deposit for General Balance', '2025-12-13 09:06:04', '2025-12-13 08:06:04', '2025-12-13 08:06:04'),
(8, 64, 'EARNOVA-deposit-64-1765625588-0677', 7000.00, 'NGN', NULL, NULL, NULL, 'Deposit for General Balance', 'success', 'deposit', 'general', 'Deposit for General Balance', '2025-12-13 12:33:27', '2025-12-13 11:33:27', '2025-12-13 11:33:27'),
(9, 54, 'EARNOVA-deposit-54-1765690051-0176', 10000.00, 'NGN', NULL, NULL, NULL, 'Deposit for General Balance', 'success', 'deposit', 'general', 'Deposit for General Balance', '2025-12-14 06:28:17', '2025-12-14 05:28:17', '2025-12-14 05:28:17'),
(10, 73, 'EARNOVA-deposit-73-1765716026-8582', 1000.00, 'NGN', NULL, NULL, NULL, 'Deposit for General Balance', 'success', 'deposit', 'general', 'Deposit for General Balance', '2025-12-14 13:41:42', '2025-12-14 12:41:42', '2025-12-14 12:41:42');

-- --------------------------------------------------------

--
-- Table structure for table `korapay_webhooks`
--

CREATE TABLE `korapay_webhooks` (
  `id` int NOT NULL,
  `event_type` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `webhook_reference` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payload` json DEFAULT NULL,
  `processed` tinyint(1) DEFAULT '0',
  `processed_at` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `leaderboards`
--

CREATE TABLE `leaderboards` (
  `id` int NOT NULL,
  `user_id` int NOT NULL,
  `leaderboard_type` enum('top_earners','top_referrers') COLLATE utf8mb4_unicode_ci NOT NULL,
  `score` decimal(15,2) NOT NULL,
  `rank_position` int NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `music_earnings`
--

CREATE TABLE `music_earnings` (
  `id` int NOT NULL,
  `user_id` int NOT NULL,
  `music_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `music_title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `amount_earned` decimal(10,2) NOT NULL,
  `listened_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `music_earnings`
--

INSERT INTO `music_earnings` (`id`, `user_id`, `music_id`, `music_title`, `amount_earned`, `listened_at`) VALUES
(1, 1, 'music_001', 'Obodo Song', 150.00, '2025-10-05 09:49:58');

-- --------------------------------------------------------

--
-- Table structure for table `mystery_box_games`
--

CREATE TABLE `mystery_box_games` (
  `id` int NOT NULL,
  `user_id` int NOT NULL,
  `bet_amount` decimal(10,2) NOT NULL,
  `multiplier` decimal(5,2) NOT NULL,
  `win_amount` decimal(10,2) NOT NULL,
  `is_free_play` tinyint(1) DEFAULT '0',
  `box_selected` int NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mystery_box_stats`
--

CREATE TABLE `mystery_box_stats` (
  `user_id` int NOT NULL,
  `total_games` int DEFAULT '0',
  `total_wins` int DEFAULT '0',
  `total_profit` decimal(15,2) DEFAULT '0.00',
  `biggest_win` decimal(10,2) DEFAULT '0.00',
  `last_played` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `newsletters_subscribers`
--

CREATE TABLE `newsletters_subscribers` (
  `id` int NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `full_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` int DEFAULT NULL,
  `subscription_status` enum('active','unsubscribed','bounced') COLLATE utf8mb4_unicode_ci DEFAULT 'active',
  `confirmation_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_confirmed` tinyint(1) DEFAULT '0',
  `confirmed_at` datetime DEFAULT NULL,
  `subscribed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `unsubscribed_at` datetime DEFAULT NULL,
  `last_email_sent_at` datetime DEFAULT NULL,
  `email_open_count` int DEFAULT '0',
  `is_admin` tinyint(1) DEFAULT '0' COMMENT 'Flag to identify admin subscriptions',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `newsletters_subscribers`
--

INSERT INTO `newsletters_subscribers` (`id`, `email`, `full_name`, `user_id`, `subscription_status`, `confirmation_token`, `is_confirmed`, `confirmed_at`, `subscribed_at`, `unsubscribed_at`, `last_email_sent_at`, `email_open_count`, `is_admin`, `created_at`, `updated_at`) VALUES
(1, 'steveneloit122@gmail.com', 'Obodo', 0, 'active', NULL, 1, '2025-11-22 18:33:44', '2025-11-22 18:30:23', NULL, NULL, 0, 0, '2025-11-22 18:30:23', '2025-11-22 18:33:44'),
(2, 'karinayuken@gmail.com', 'Franklin', 0, 'active', NULL, 1, '2025-11-24 08:17:44', '2025-11-24 08:16:08', NULL, NULL, 0, 0, '2025-11-24 08:16:08', '2025-11-24 08:17:44'),
(3, 'demi@gmail.com', '', 0, 'active', '92aee86a69320c82b0614f2f3f7925e6af7671051966f9655b2810ea0a592045', 0, NULL, '2025-11-24 08:33:57', NULL, NULL, 0, 0, '2025-11-24 08:33:57', '2025-11-24 08:33:57'),
(4, 'ifeoluwatemilorun@gmail.com', 'Obodo', 0, 'active', '97e496e68e6a59c732345c3577abc216b4d9336651feb933d94390d91b5227f1', 0, NULL, '2025-11-24 11:20:36', NULL, NULL, 0, 0, '2025-11-24 11:20:36', '2025-11-24 11:20:36'),
(5, 'chinecheremmechackifeama@gmail.com', 'Mechack', 0, 'active', NULL, 1, '2025-11-24 11:23:30', '2025-11-24 11:21:36', NULL, NULL, 0, 0, '2025-11-24 11:21:36', '2025-11-24 11:23:30'),
(6, 'chidubemifeama@gmail.com', 'Chidume', 0, 'active', NULL, 1, '2025-11-29 13:25:39', '2025-11-29 13:22:39', NULL, NULL, 0, 0, '2025-11-29 13:22:39', '2025-11-29 13:25:39');

-- --------------------------------------------------------

--
-- Table structure for table `newsletter_campaigns`
--

CREATE TABLE `newsletter_campaigns` (
  `id` int NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `subject` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('draft','scheduled','sent','failed') COLLATE utf8mb4_unicode_ci DEFAULT 'draft',
  `total_recipients` int DEFAULT '0',
  `sent_count` int DEFAULT '0',
  `failed_count` int DEFAULT '0',
  `open_count` int DEFAULT '0',
  `created_by` int NOT NULL,
  `scheduled_at` datetime DEFAULT NULL,
  `sent_at` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `notification_recipients`
--

CREATE TABLE `notification_recipients` (
  `id` int NOT NULL,
  `message_id` int NOT NULL,
  `user_id` int NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int NOT NULL,
  `user_id` int NOT NULL,
  `order_type` enum('premium_upgrade','senior_advertiser','deposit') COLLATE utf8mb4_unicode_ci NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `payment_gateway` enum('paystack','flutterwave') COLLATE utf8mb4_unicode_ci NOT NULL,
  `payment_reference` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('pending','paid','failed','cancelled') COLLATE utf8mb4_unicode_ci DEFAULT 'pending',
  `billing_info_id` int DEFAULT NULL,
  `metadata` text COLLATE utf8mb4_unicode_ci COMMENT 'JSON data for order details',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `password_reset_codes`
--

CREATE TABLE `password_reset_codes` (
  `id` int NOT NULL,
  `user_id` int NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `reset_code` varchar(6) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_used` tinyint(1) DEFAULT '0',
  `expires_at` datetime NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `password_reset_codes`
--

INSERT INTO `password_reset_codes` (`id`, `user_id`, `email`, `reset_code`, `is_used`, `expires_at`, `created_at`) VALUES
(2, 1, 'obodo@gmail.com', '001928', 0, '2025-10-29 19:00:52', '2025-10-29 17:45:52'),
(25, 47, 'karinayuken@gmail.com', '148553', 0, '2025-11-24 09:41:48', '2025-11-24 09:26:48'),
(26, 47, 'karinayuken@gmail.com', '563867', 0, '2025-11-25 14:41:08', '2025-11-25 14:26:08'),
(27, 47, 'karinayuken@gmail.com', '234375', 0, '2025-11-25 14:48:55', '2025-11-25 14:33:55'),
(28, 47, 'karinayuken@gmail.com', '463387', 0, '2025-11-25 14:49:51', '2025-11-25 14:34:51'),
(29, 47, 'karinayuken@gmail.com', '641449', 0, '2025-11-29 15:01:59', '2025-11-29 14:46:59'),
(53, 47, 'karinayuken@gmail.com', '886953', 0, '2025-12-02 13:51:53', '2025-12-02 13:36:53'),
(54, 51, 'socialnooktech@gmail.com', '875521', 0, '2025-12-02 13:54:33', '2025-12-02 13:39:33'),
(55, 51, 'socialnooktech@gmail.com', '221059', 0, '2025-12-02 13:56:10', '2025-12-02 13:41:10'),
(56, 47, 'karinayuken@gmail.com', '897535', 0, '2025-12-09 20:17:05', '2025-12-09 19:02:05');

-- --------------------------------------------------------

--
-- Table structure for table `paystack_transfer_logs`
--

CREATE TABLE `paystack_transfer_logs` (
  `id` int NOT NULL,
  `withdrawal_id` int NOT NULL,
  `user_id` int NOT NULL,
  `transfer_amount` decimal(15,2) NOT NULL,
  `paystack_transfer_id` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `recipient_code` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `api_request` longtext COLLATE utf8mb4_unicode_ci,
  `api_response` longtext COLLATE utf8mb4_unicode_ci,
  `api_status_code` int DEFAULT NULL,
  `error_message` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `paystack_transfer_logs`
--

INSERT INTO `paystack_transfer_logs` (`id`, `withdrawal_id`, `user_id`, `transfer_amount`, `paystack_transfer_id`, `recipient_code`, `api_request`, `api_response`, `api_status_code`, `error_message`, `created_at`, `updated_at`) VALUES
(1, 59, 1, 200.00, NULL, 'RCP_5l9l54zj9g8y7db', '{\"source\":\"balance\",\"reason\":\"Prime Earnings Withdrawal - WD-59\",\"amount\":20000,\"recipient\":\"RCP_5l9l54zj9g8y7db\",\"reference\":\"WD-59-1764368736\"}', '{\"status\":true,\"message\":\"Transfer requires OTP to continue\",\"data\":{\"transfersessionid\":[],\"transfertrials\":[],\"domain\":\"live\",\"amount\":20000,\"currency\":\"NGN\",\"reference\":\"WD-59-1764368736\",\"source\":\"balance\",\"source_details\":null,\"reason\":\"Prime Earnings Withdrawal - WD-59\",\"status\":\"otp\",\"failures\":null,\"transfer_code\":\"TRF_u0syk3qf63vsqded\",\"titan_code\":null,\"transferred_at\":null,\"id\":921078321,\"integration\":1606789,\"request\":1156164600,\"recipient\":116473253,\"createdAt\":\"2025-11-28T22:25:37.000Z\",\"updatedAt\":\"2025-11-28T22:25:37.000Z\"}}', 200, '{\"status\":true,\"message\":\"Transfer requires OTP to continue\",\"data\":{\"transfersessionid\":[],\"transfertrials\":[],\"domain\":\"live\",\"amount\":20000,\"currency\":\"NGN\",\"reference\":\"WD-59-1764368736\",\"source\":\"balance\",\"source_details\":null,\"reason\":\"Prime Earnings Withdrawal - WD-59\",\"status\":\"otp\",\"failures\":null,\"transfer_code\":\"TRF_u0syk3qf63vsqded\",\"titan_code\":null,\"transferred_at\":null,\"id\":921078321,\"integration\":1606789,\"request\":1156164600,\"recipient\":116473253,\"createdAt\":\"2025-11-28T22:25:37.000Z\",\"updatedAt\":\"2025-11-28T22:25:37.000Z\"}}', '2025-11-28 22:25:37', '2025-11-28 22:25:37'),
(2, 60, 1, 500.00, NULL, 'RCP_d8vwb0x3tor3a22', '{\"source\":\"balance\",\"reason\":\"Prime Earnings Withdrawal - WD-60\",\"amount\":50000,\"recipient\":\"RCP_d8vwb0x3tor3a22\",\"reference\":\"WD-60-1764368737\"}', '{\"status\":true,\"message\":\"Transfer requires OTP to continue\",\"data\":{\"transfersessionid\":[],\"transfertrials\":[],\"domain\":\"live\",\"amount\":50000,\"currency\":\"NGN\",\"reference\":\"WD-60-1764368737\",\"source\":\"balance\",\"source_details\":null,\"reason\":\"Prime Earnings Withdrawal - WD-60\",\"status\":\"otp\",\"failures\":null,\"transfer_code\":\"TRF_ggkz4p1j33is9uc6\",\"titan_code\":null,\"transferred_at\":null,\"id\":921078329,\"integration\":1606789,\"request\":1156164607,\"recipient\":116473254,\"createdAt\":\"2025-11-28T22:25:38.000Z\",\"updatedAt\":\"2025-11-28T22:25:38.000Z\"}}', 200, '{\"status\":true,\"message\":\"Transfer requires OTP to continue\",\"data\":{\"transfersessionid\":[],\"transfertrials\":[],\"domain\":\"live\",\"amount\":50000,\"currency\":\"NGN\",\"reference\":\"WD-60-1764368737\",\"source\":\"balance\",\"source_details\":null,\"reason\":\"Prime Earnings Withdrawal - WD-60\",\"status\":\"otp\",\"failures\":null,\"transfer_code\":\"TRF_ggkz4p1j33is9uc6\",\"titan_code\":null,\"transferred_at\":null,\"id\":921078329,\"integration\":1606789,\"request\":1156164607,\"recipient\":116473254,\"createdAt\":\"2025-11-28T22:25:38.000Z\",\"updatedAt\":\"2025-11-28T22:25:38.000Z\"}}', '2025-11-28 22:25:38', '2025-11-28 22:25:38'),
(3, 61, 1, 500.00, NULL, 'RCP_d8vwb0x3tor3a22', '{\"source\":\"balance\",\"reason\":\"Prime Earnings Withdrawal - WD-61\",\"amount\":50000,\"recipient\":\"RCP_d8vwb0x3tor3a22\",\"reference\":\"WD-61-1764368738\"}', '{\"status\":true,\"message\":\"Transfer requires OTP to continue\",\"data\":{\"transfersessionid\":[],\"transfertrials\":[],\"domain\":\"live\",\"amount\":50000,\"currency\":\"NGN\",\"reference\":\"WD-61-1764368738\",\"source\":\"balance\",\"source_details\":null,\"reason\":\"Prime Earnings Withdrawal - WD-61\",\"status\":\"otp\",\"failures\":null,\"transfer_code\":\"TRF_3nmadaas0srb1h38\",\"titan_code\":null,\"transferred_at\":null,\"id\":921078333,\"integration\":1606789,\"request\":1156164611,\"recipient\":116473254,\"createdAt\":\"2025-11-28T22:25:39.000Z\",\"updatedAt\":\"2025-11-28T22:25:39.000Z\"}}', 200, '{\"status\":true,\"message\":\"Transfer requires OTP to continue\",\"data\":{\"transfersessionid\":[],\"transfertrials\":[],\"domain\":\"live\",\"amount\":50000,\"currency\":\"NGN\",\"reference\":\"WD-61-1764368738\",\"source\":\"balance\",\"source_details\":null,\"reason\":\"Prime Earnings Withdrawal - WD-61\",\"status\":\"otp\",\"failures\":null,\"transfer_code\":\"TRF_3nmadaas0srb1h38\",\"titan_code\":null,\"transferred_at\":null,\"id\":921078333,\"integration\":1606789,\"request\":1156164611,\"recipient\":116473254,\"createdAt\":\"2025-11-28T22:25:39.000Z\",\"updatedAt\":\"2025-11-28T22:25:39.000Z\"}}', '2025-11-28 22:25:39', '2025-11-28 22:25:39'),
(4, 62, 1, 300.00, NULL, 'RCP_d8vwb0x3tor3a22', '{\"source\":\"balance\",\"reason\":\"Prime Earnings Withdrawal - WD-62\",\"amount\":30000,\"recipient\":\"RCP_d8vwb0x3tor3a22\",\"reference\":\"WD-62-1764368739\"}', '{\"status\":true,\"message\":\"Transfer requires OTP to continue\",\"data\":{\"transfersessionid\":[],\"transfertrials\":[],\"domain\":\"live\",\"amount\":30000,\"currency\":\"NGN\",\"reference\":\"WD-62-1764368739\",\"source\":\"balance\",\"source_details\":null,\"reason\":\"Prime Earnings Withdrawal - WD-62\",\"status\":\"otp\",\"failures\":null,\"transfer_code\":\"TRF_fsd7i27gdvtik3rm\",\"titan_code\":null,\"transferred_at\":null,\"id\":921078340,\"integration\":1606789,\"request\":1156164618,\"recipient\":116473254,\"createdAt\":\"2025-11-28T22:25:40.000Z\",\"updatedAt\":\"2025-11-28T22:25:40.000Z\"}}', 200, '{\"status\":true,\"message\":\"Transfer requires OTP to continue\",\"data\":{\"transfersessionid\":[],\"transfertrials\":[],\"domain\":\"live\",\"amount\":30000,\"currency\":\"NGN\",\"reference\":\"WD-62-1764368739\",\"source\":\"balance\",\"source_details\":null,\"reason\":\"Prime Earnings Withdrawal - WD-62\",\"status\":\"otp\",\"failures\":null,\"transfer_code\":\"TRF_fsd7i27gdvtik3rm\",\"titan_code\":null,\"transferred_at\":null,\"id\":921078340,\"integration\":1606789,\"request\":1156164618,\"recipient\":116473254,\"createdAt\":\"2025-11-28T22:25:40.000Z\",\"updatedAt\":\"2025-11-28T22:25:40.000Z\"}}', '2025-11-28 22:25:40', '2025-11-28 22:25:40'),
(5, 63, 1, 350.00, NULL, 'RCP_d8vwb0x3tor3a22', '{\"source\":\"balance\",\"reason\":\"Prime Earnings Withdrawal - WD-63\",\"amount\":35000,\"recipient\":\"RCP_d8vwb0x3tor3a22\",\"reference\":\"WD-63-1764368740\"}', '{\"status\":true,\"message\":\"Transfer requires OTP to continue\",\"data\":{\"transfersessionid\":[],\"transfertrials\":[],\"domain\":\"live\",\"amount\":35000,\"currency\":\"NGN\",\"reference\":\"WD-63-1764368740\",\"source\":\"balance\",\"source_details\":null,\"reason\":\"Prime Earnings Withdrawal - WD-63\",\"status\":\"otp\",\"failures\":null,\"transfer_code\":\"TRF_rs6hz1100kmz58kb\",\"titan_code\":null,\"transferred_at\":null,\"id\":921078346,\"integration\":1606789,\"request\":1156164623,\"recipient\":116473254,\"createdAt\":\"2025-11-28T22:25:41.000Z\",\"updatedAt\":\"2025-11-28T22:25:41.000Z\"}}', 200, '{\"status\":true,\"message\":\"Transfer requires OTP to continue\",\"data\":{\"transfersessionid\":[],\"transfertrials\":[],\"domain\":\"live\",\"amount\":35000,\"currency\":\"NGN\",\"reference\":\"WD-63-1764368740\",\"source\":\"balance\",\"source_details\":null,\"reason\":\"Prime Earnings Withdrawal - WD-63\",\"status\":\"otp\",\"failures\":null,\"transfer_code\":\"TRF_rs6hz1100kmz58kb\",\"titan_code\":null,\"transferred_at\":null,\"id\":921078346,\"integration\":1606789,\"request\":1156164623,\"recipient\":116473254,\"createdAt\":\"2025-11-28T22:25:41.000Z\",\"updatedAt\":\"2025-11-28T22:25:41.000Z\"}}', '2025-11-28 22:25:41', '2025-11-28 22:25:41'),
(6, 64, 54, 360.00, NULL, 'RCP_d581789pmena3gn', '{\"source\":\"balance\",\"reason\":\"Prime Earnings Withdrawal - WD-64\",\"amount\":36000,\"recipient\":\"RCP_d581789pmena3gn\",\"reference\":\"WD-64-1764391621\"}', '{\"status\":true,\"message\":\"Transfer has been queued\",\"data\":{\"transfersessionid\":[],\"transfertrials\":[],\"domain\":\"live\",\"amount\":36000,\"currency\":\"NGN\",\"reference\":\"WD-64-1764391621\",\"source\":\"balance\",\"source_details\":null,\"reason\":\"Prime Earnings Withdrawal - WD-64\",\"status\":\"pending\",\"failures\":null,\"transfer_code\":\"TRF_5hbydl52bl8nj4wz\",\"titan_code\":null,\"transferred_at\":null,\"id\":921133154,\"integration\":1606789,\"request\":1156295143,\"recipient\":116480867,\"createdAt\":\"2025-11-29T04:47:02.000Z\",\"updatedAt\":\"2025-11-29T04:47:02.000Z\"}}', 200, '{\"status\":true,\"message\":\"Transfer has been queued\",\"data\":{\"transfersessionid\":[],\"transfertrials\":[],\"domain\":\"live\",\"amount\":36000,\"currency\":\"NGN\",\"reference\":\"WD-64-1764391621\",\"source\":\"balance\",\"source_details\":null,\"reason\":\"Prime Earnings Withdrawal - WD-64\",\"status\":\"pending\",\"failures\":null,\"transfer_code\":\"TRF_5hbydl52bl8nj4wz\",\"titan_code\":null,\"transferred_at\":null,\"id\":921133154,\"integration\":1606789,\"request\":1156295143,\"recipient\":116480867,\"createdAt\":\"2025-11-29T04:47:02.000Z\",\"updatedAt\":\"2025-11-29T04:47:02.000Z\"}}', '2025-11-29 04:47:06', '2025-11-29 04:47:06'),
(7, 65, 46, 200.00, NULL, 'RCP_534mc9ff21ca11p', '{\"source\":\"balance\",\"reason\":\"Prime Earnings Withdrawal - WD-65\",\"amount\":20000,\"recipient\":\"RCP_534mc9ff21ca11p\",\"reference\":\"WD-65-1764396554\"}', '{\"status\":true,\"message\":\"Transfer has been queued\",\"data\":{\"transfersessionid\":[],\"transfertrials\":[],\"domain\":\"live\",\"amount\":20000,\"currency\":\"NGN\",\"reference\":\"WD-65-1764396554\",\"source\":\"balance\",\"source_details\":null,\"reason\":\"Prime Earnings Withdrawal - WD-65\",\"status\":\"pending\",\"failures\":null,\"transfer_code\":\"TRF_p46369ahzb6fhi0j\",\"titan_code\":null,\"transferred_at\":null,\"id\":921149382,\"integration\":1606789,\"request\":1156317181,\"recipient\":116482705,\"createdAt\":\"2025-11-29T06:09:14.000Z\",\"updatedAt\":\"2025-11-29T06:09:14.000Z\"}}', 200, '{\"status\":true,\"message\":\"Transfer has been queued\",\"data\":{\"transfersessionid\":[],\"transfertrials\":[],\"domain\":\"live\",\"amount\":20000,\"currency\":\"NGN\",\"reference\":\"WD-65-1764396554\",\"source\":\"balance\",\"source_details\":null,\"reason\":\"Prime Earnings Withdrawal - WD-65\",\"status\":\"pending\",\"failures\":null,\"transfer_code\":\"TRF_p46369ahzb6fhi0j\",\"titan_code\":null,\"transferred_at\":null,\"id\":921149382,\"integration\":1606789,\"request\":1156317181,\"recipient\":116482705,\"createdAt\":\"2025-11-29T06:09:14.000Z\",\"updatedAt\":\"2025-11-29T06:09:14.000Z\"}}', '2025-11-29 06:09:18', '2025-11-29 06:09:18'),
(8, 66, 54, 2000.00, NULL, 'RCP_d581789pmena3gn', '{\"source\":\"balance\",\"reason\":\"Prime Earnings Withdrawal - WD-66\",\"amount\":200000,\"recipient\":\"RCP_d581789pmena3gn\",\"reference\":\"WD-66-1764408401\"}', '{\"status\":true,\"message\":\"Transfer has been queued\",\"data\":{\"transfersessionid\":[],\"transfertrials\":[],\"domain\":\"live\",\"amount\":200000,\"currency\":\"NGN\",\"reference\":\"WD-66-1764408401\",\"source\":\"balance\",\"source_details\":null,\"reason\":\"Prime Earnings Withdrawal - WD-66\",\"status\":\"pending\",\"failures\":null,\"transfer_code\":\"TRF_nsxr3el7vhxfkuac\",\"titan_code\":null,\"transferred_at\":null,\"id\":921216202,\"integration\":1606789,\"request\":1156395994,\"recipient\":116480867,\"createdAt\":\"2025-11-29T09:26:42.000Z\",\"updatedAt\":\"2025-11-29T09:26:42.000Z\"}}', 200, '{\"status\":true,\"message\":\"Transfer has been queued\",\"data\":{\"transfersessionid\":[],\"transfertrials\":[],\"domain\":\"live\",\"amount\":200000,\"currency\":\"NGN\",\"reference\":\"WD-66-1764408401\",\"source\":\"balance\",\"source_details\":null,\"reason\":\"Prime Earnings Withdrawal - WD-66\",\"status\":\"pending\",\"failures\":null,\"transfer_code\":\"TRF_nsxr3el7vhxfkuac\",\"titan_code\":null,\"transferred_at\":null,\"id\":921216202,\"integration\":1606789,\"request\":1156395994,\"recipient\":116480867,\"createdAt\":\"2025-11-29T09:26:42.000Z\",\"updatedAt\":\"2025-11-29T09:26:42.000Z\"}}', '2025-11-29 09:26:47', '2025-11-29 09:26:47'),
(9, 62, 1, 300.00, NULL, 'RCP_d8vwb0x3tor3a22', '{\"source\":\"balance\",\"reason\":\"Prime Earnings Withdrawal - WD-62\",\"amount\":30000,\"recipient\":\"RCP_d8vwb0x3tor3a22\",\"reference\":\"WD-62-1764414086\"}', '{\"status\":false,\"message\":\"Your balance is not enough to fulfil this request\",\"meta\":{\"nextStep\":\"Topup your Paystack Balance and try again.\"},\"type\":\"api_error\",\"code\":\"insufficient_balance\"}', 400, '{\"status\":false,\"message\":\"Your balance is not enough to fulfil this request\",\"meta\":{\"nextStep\":\"Topup your Paystack Balance and try again.\"},\"type\":\"api_error\",\"code\":\"insufficient_balance\"}', '2025-11-29 11:01:26', '2025-11-29 11:01:26'),
(10, 62, 1, 300.00, NULL, 'RCP_d8vwb0x3tor3a22', '{\"source\":\"balance\",\"reason\":\"Prime Earnings Withdrawal - WD-62\",\"amount\":30000,\"recipient\":\"RCP_d8vwb0x3tor3a22\",\"reference\":\"WD-62-1764428878\"}', '{\"status\":false,\"message\":\"Your balance is not enough to fulfil this request\",\"meta\":{\"nextStep\":\"Topup your Paystack Balance and try again.\"},\"type\":\"api_error\",\"code\":\"insufficient_balance\"}', 400, '{\"status\":false,\"message\":\"Your balance is not enough to fulfil this request\",\"meta\":{\"nextStep\":\"Topup your Paystack Balance and try again.\"},\"type\":\"api_error\",\"code\":\"insufficient_balance\"}', '2025-11-29 15:07:58', '2025-11-29 15:07:58'),
(11, 73, 54, 3200.00, NULL, 'RCP_d581789pmena3gn', '{\"source\":\"balance\",\"reason\":\"Prime Earnings Withdrawal - WD-73\",\"amount\":320000,\"recipient\":\"RCP_d581789pmena3gn\",\"reference\":\"WD-73-1764428878\"}', '{\"status\":false,\"message\":\"Your balance is not enough to fulfil this request\",\"meta\":{\"nextStep\":\"Topup your Paystack Balance and try again.\"},\"type\":\"api_error\",\"code\":\"insufficient_balance\"}', 400, '{\"status\":false,\"message\":\"Your balance is not enough to fulfil this request\",\"meta\":{\"nextStep\":\"Topup your Paystack Balance and try again.\"},\"type\":\"api_error\",\"code\":\"insufficient_balance\"}', '2025-11-29 15:07:59', '2025-11-29 15:07:59'),
(12, 62, 1, 300.00, NULL, 'RCP_d8vwb0x3tor3a22', '{\"source\":\"balance\",\"reason\":\"Prime Earnings Withdrawal - WD-62\",\"amount\":30000,\"recipient\":\"RCP_d8vwb0x3tor3a22\",\"reference\":\"WD-62-1764433043\"}', '{\"status\":false,\"message\":\"You cannot initiate third party payouts at this time\",\"meta\":{\"nextStep\":\"Try again later\"},\"type\":\"api_error\",\"code\":\"unknown\"}', 400, '{\"status\":false,\"message\":\"You cannot initiate third party payouts at this time\",\"meta\":{\"nextStep\":\"Try again later\"},\"type\":\"api_error\",\"code\":\"unknown\"}', '2025-11-29 16:17:24', '2025-11-29 16:17:24'),
(13, 73, 54, 3200.00, NULL, 'RCP_d581789pmena3gn', '{\"source\":\"balance\",\"reason\":\"Prime Earnings Withdrawal - WD-73\",\"amount\":320000,\"recipient\":\"RCP_d581789pmena3gn\",\"reference\":\"WD-73-1764433044\"}', '{\"status\":false,\"message\":\"You cannot initiate third party payouts at this time\",\"meta\":{\"nextStep\":\"Try again later\"},\"type\":\"api_error\",\"code\":\"unknown\"}', 400, '{\"status\":false,\"message\":\"You cannot initiate third party payouts at this time\",\"meta\":{\"nextStep\":\"Try again later\"},\"type\":\"api_error\",\"code\":\"unknown\"}', '2025-11-29 16:17:24', '2025-11-29 16:17:24'),
(14, 62, 1, 300.00, NULL, 'RCP_d8vwb0x3tor3a22', '{\"source\":\"balance\",\"reason\":\"Prime Earnings Withdrawal - WD-62\",\"amount\":30000,\"recipient\":\"RCP_d8vwb0x3tor3a22\",\"reference\":\"WD-62-1764433105\"}', '{\"status\":false,\"message\":\"You cannot initiate third party payouts at this time\",\"meta\":{\"nextStep\":\"Try again later\"},\"type\":\"api_error\",\"code\":\"unknown\"}', 400, '{\"status\":false,\"message\":\"You cannot initiate third party payouts at this time\",\"meta\":{\"nextStep\":\"Try again later\"},\"type\":\"api_error\",\"code\":\"unknown\"}', '2025-11-29 16:18:26', '2025-11-29 16:18:26'),
(15, 73, 54, 3200.00, NULL, 'RCP_d581789pmena3gn', '{\"source\":\"balance\",\"reason\":\"Prime Earnings Withdrawal - WD-73\",\"amount\":320000,\"recipient\":\"RCP_d581789pmena3gn\",\"reference\":\"WD-73-1764433106\"}', '{\"status\":false,\"message\":\"You cannot initiate third party payouts at this time\",\"meta\":{\"nextStep\":\"Try again later\"},\"type\":\"api_error\",\"code\":\"unknown\"}', 400, '{\"status\":false,\"message\":\"You cannot initiate third party payouts at this time\",\"meta\":{\"nextStep\":\"Try again later\"},\"type\":\"api_error\",\"code\":\"unknown\"}', '2025-11-29 16:18:26', '2025-11-29 16:18:26'),
(16, 62, 1, 300.00, NULL, 'RCP_d8vwb0x3tor3a22', '{\"source\":\"balance\",\"reason\":\"Prime Earnings Withdrawal - WD-62\",\"amount\":30000,\"recipient\":\"RCP_d8vwb0x3tor3a22\",\"reference\":\"WD-62-1764433107\"}', '{\"status\":false,\"message\":\"You cannot initiate third party payouts at this time\",\"meta\":{\"nextStep\":\"Try again later\"},\"type\":\"api_error\",\"code\":\"unknown\"}', 400, '{\"status\":false,\"message\":\"You cannot initiate third party payouts at this time\",\"meta\":{\"nextStep\":\"Try again later\"},\"type\":\"api_error\",\"code\":\"unknown\"}', '2025-11-29 16:18:27', '2025-11-29 16:18:27'),
(17, 73, 54, 3200.00, NULL, 'RCP_d581789pmena3gn', '{\"source\":\"balance\",\"reason\":\"Prime Earnings Withdrawal - WD-73\",\"amount\":320000,\"recipient\":\"RCP_d581789pmena3gn\",\"reference\":\"WD-73-1764433107\"}', '{\"status\":false,\"message\":\"You cannot initiate third party payouts at this time\",\"meta\":{\"nextStep\":\"Try again later\"},\"type\":\"api_error\",\"code\":\"unknown\"}', 400, '{\"status\":false,\"message\":\"You cannot initiate third party payouts at this time\",\"meta\":{\"nextStep\":\"Try again later\"},\"type\":\"api_error\",\"code\":\"unknown\"}', '2025-11-29 16:18:28', '2025-11-29 16:18:28'),
(18, 62, 1, 300.00, NULL, 'RCP_d8vwb0x3tor3a22', '{\"source\":\"balance\",\"reason\":\"Prime Earnings Withdrawal - WD-62\",\"amount\":30000,\"recipient\":\"RCP_d8vwb0x3tor3a22\",\"reference\":\"WD-62-1764433114\"}', '{\"status\":false,\"message\":\"You cannot initiate third party payouts at this time\",\"meta\":{\"nextStep\":\"Try again later\"},\"type\":\"api_error\",\"code\":\"unknown\"}', 400, '{\"status\":false,\"message\":\"You cannot initiate third party payouts at this time\",\"meta\":{\"nextStep\":\"Try again later\"},\"type\":\"api_error\",\"code\":\"unknown\"}', '2025-11-29 16:18:34', '2025-11-29 16:18:34'),
(19, 73, 54, 3200.00, NULL, 'RCP_d581789pmena3gn', '{\"source\":\"balance\",\"reason\":\"Prime Earnings Withdrawal - WD-73\",\"amount\":320000,\"recipient\":\"RCP_d581789pmena3gn\",\"reference\":\"WD-73-1764433114\"}', '{\"status\":false,\"message\":\"You cannot initiate third party payouts at this time\",\"meta\":{\"nextStep\":\"Try again later\"},\"type\":\"api_error\",\"code\":\"unknown\"}', 400, '{\"status\":false,\"message\":\"You cannot initiate third party payouts at this time\",\"meta\":{\"nextStep\":\"Try again later\"},\"type\":\"api_error\",\"code\":\"unknown\"}', '2025-11-29 16:18:34', '2025-11-29 16:18:34'),
(20, 62, 1, 300.00, NULL, 'RCP_d8vwb0x3tor3a22', '{\"source\":\"balance\",\"reason\":\"Prime Earnings Withdrawal - WD-62\",\"amount\":30000,\"recipient\":\"RCP_d8vwb0x3tor3a22\",\"reference\":\"WD-62-1764433139\"}', '{\"status\":false,\"message\":\"You cannot initiate third party payouts at this time\",\"meta\":{\"nextStep\":\"Try again later\"},\"type\":\"api_error\",\"code\":\"unknown\"}', 400, '{\"status\":false,\"message\":\"You cannot initiate third party payouts at this time\",\"meta\":{\"nextStep\":\"Try again later\"},\"type\":\"api_error\",\"code\":\"unknown\"}', '2025-11-29 16:18:59', '2025-11-29 16:18:59'),
(21, 73, 54, 3200.00, NULL, 'RCP_d581789pmena3gn', '{\"source\":\"balance\",\"reason\":\"Prime Earnings Withdrawal - WD-73\",\"amount\":320000,\"recipient\":\"RCP_d581789pmena3gn\",\"reference\":\"WD-73-1764433139\"}', '{\"status\":false,\"message\":\"You cannot initiate third party payouts at this time\",\"meta\":{\"nextStep\":\"Try again later\"},\"type\":\"api_error\",\"code\":\"unknown\"}', 400, '{\"status\":false,\"message\":\"You cannot initiate third party payouts at this time\",\"meta\":{\"nextStep\":\"Try again later\"},\"type\":\"api_error\",\"code\":\"unknown\"}', '2025-11-29 16:18:59', '2025-11-29 16:18:59'),
(22, 62, 1, 300.00, NULL, 'RCP_d8vwb0x3tor3a22', '{\"source\":\"balance\",\"reason\":\"Prime Earnings Withdrawal - WD-62\",\"amount\":30000,\"recipient\":\"RCP_d8vwb0x3tor3a22\",\"reference\":\"WD-62-1764433278\"}', '{\"status\":false,\"message\":\"You cannot initiate third party payouts at this time\",\"meta\":{\"nextStep\":\"Try again later\"},\"type\":\"api_error\",\"code\":\"unknown\"}', 400, '{\"status\":false,\"message\":\"You cannot initiate third party payouts at this time\",\"meta\":{\"nextStep\":\"Try again later\"},\"type\":\"api_error\",\"code\":\"unknown\"}', '2025-11-29 16:21:18', '2025-11-29 16:21:18'),
(23, 73, 54, 3200.00, NULL, 'RCP_d581789pmena3gn', '{\"source\":\"balance\",\"reason\":\"Prime Earnings Withdrawal - WD-73\",\"amount\":320000,\"recipient\":\"RCP_d581789pmena3gn\",\"reference\":\"WD-73-1764433278\"}', '{\"status\":false,\"message\":\"You cannot initiate third party payouts at this time\",\"meta\":{\"nextStep\":\"Try again later\"},\"type\":\"api_error\",\"code\":\"unknown\"}', 400, '{\"status\":false,\"message\":\"You cannot initiate third party payouts at this time\",\"meta\":{\"nextStep\":\"Try again later\"},\"type\":\"api_error\",\"code\":\"unknown\"}', '2025-11-29 16:21:19', '2025-11-29 16:21:19'),
(24, 74, 47, 300.00, NULL, 'RCP_dxsnwbkh5zee54x', '{\"source\":\"balance\",\"reason\":\"Prime Earnings Withdrawal - WD-74\",\"amount\":30000,\"recipient\":\"RCP_dxsnwbkh5zee54x\",\"reference\":\"WD-74-1764433279\"}', '{\"status\":false,\"message\":\"You cannot initiate third party payouts at this time\",\"meta\":{\"nextStep\":\"Try again later\"},\"type\":\"api_error\",\"code\":\"unknown\"}', 400, '{\"status\":false,\"message\":\"You cannot initiate third party payouts at this time\",\"meta\":{\"nextStep\":\"Try again later\"},\"type\":\"api_error\",\"code\":\"unknown\"}', '2025-11-29 16:21:19', '2025-11-29 16:21:19'),
(25, 62, 1, 300.00, NULL, 'RCP_d8vwb0x3tor3a22', '{\"source\":\"balance\",\"reason\":\"Prime Earnings Withdrawal - WD-62\",\"amount\":30000,\"recipient\":\"RCP_d8vwb0x3tor3a22\",\"reference\":\"WD-62-1764446443\"}', '{\"status\":false,\"message\":\"You cannot initiate third party payouts at this time\",\"meta\":{\"nextStep\":\"Try again later\"},\"type\":\"api_error\",\"code\":\"unknown\"}', 400, '{\"status\":false,\"message\":\"You cannot initiate third party payouts at this time\",\"meta\":{\"nextStep\":\"Try again later\"},\"type\":\"api_error\",\"code\":\"unknown\"}', '2025-11-29 20:00:44', '2025-11-29 20:00:44'),
(26, 74, 47, 300.00, NULL, 'RCP_dxsnwbkh5zee54x', '{\"source\":\"balance\",\"reason\":\"Prime Earnings Withdrawal - WD-74\",\"amount\":30000,\"recipient\":\"RCP_dxsnwbkh5zee54x\",\"reference\":\"WD-74-1764446444\"}', '{\"status\":false,\"message\":\"You cannot initiate third party payouts at this time\",\"meta\":{\"nextStep\":\"Try again later\"},\"type\":\"api_error\",\"code\":\"unknown\"}', 400, '{\"status\":false,\"message\":\"You cannot initiate third party payouts at this time\",\"meta\":{\"nextStep\":\"Try again later\"},\"type\":\"api_error\",\"code\":\"unknown\"}', '2025-11-29 20:00:44', '2025-11-29 20:00:44'),
(27, 75, 1, 200.00, NULL, 'RCP_d8vwb0x3tor3a22', '{\"source\":\"balance\",\"reason\":\"Prime Earnings Withdrawal - WD-75\",\"amount\":20000,\"recipient\":\"RCP_d8vwb0x3tor3a22\",\"reference\":\"WD-75-1764446444\"}', '{\"status\":false,\"message\":\"You cannot initiate third party payouts at this time\",\"meta\":{\"nextStep\":\"Try again later\"},\"type\":\"api_error\",\"code\":\"unknown\"}', 400, '{\"status\":false,\"message\":\"You cannot initiate third party payouts at this time\",\"meta\":{\"nextStep\":\"Try again later\"},\"type\":\"api_error\",\"code\":\"unknown\"}', '2025-11-29 20:00:44', '2025-11-29 20:00:44'),
(28, 62, 1, 300.00, NULL, 'RCP_d8vwb0x3tor3a22', '{\"source\":\"balance\",\"reason\":\"Prime Earnings Withdrawal - WD-62\",\"amount\":30000,\"recipient\":\"RCP_d8vwb0x3tor3a22\",\"reference\":\"WD-62-1764446575\"}', '{\"status\":false,\"message\":\"You cannot initiate third party payouts at this time\",\"meta\":{\"nextStep\":\"Try again later\"},\"type\":\"api_error\",\"code\":\"unknown\"}', 400, '{\"status\":false,\"message\":\"You cannot initiate third party payouts at this time\",\"meta\":{\"nextStep\":\"Try again later\"},\"type\":\"api_error\",\"code\":\"unknown\"}', '2025-11-29 20:02:55', '2025-11-29 20:02:55'),
(29, 74, 47, 300.00, NULL, 'RCP_dxsnwbkh5zee54x', '{\"source\":\"balance\",\"reason\":\"Prime Earnings Withdrawal - WD-74\",\"amount\":30000,\"recipient\":\"RCP_dxsnwbkh5zee54x\",\"reference\":\"WD-74-1764446575\"}', '{\"status\":false,\"message\":\"You cannot initiate third party payouts at this time\",\"meta\":{\"nextStep\":\"Try again later\"},\"type\":\"api_error\",\"code\":\"unknown\"}', 400, '{\"status\":false,\"message\":\"You cannot initiate third party payouts at this time\",\"meta\":{\"nextStep\":\"Try again later\"},\"type\":\"api_error\",\"code\":\"unknown\"}', '2025-11-29 20:02:55', '2025-11-29 20:02:55'),
(30, 75, 1, 200.00, NULL, 'RCP_d8vwb0x3tor3a22', '{\"source\":\"balance\",\"reason\":\"Prime Earnings Withdrawal - WD-75\",\"amount\":20000,\"recipient\":\"RCP_d8vwb0x3tor3a22\",\"reference\":\"WD-75-1764446575\"}', '{\"status\":false,\"message\":\"You cannot initiate third party payouts at this time\",\"meta\":{\"nextStep\":\"Try again later\"},\"type\":\"api_error\",\"code\":\"unknown\"}', 400, '{\"status\":false,\"message\":\"You cannot initiate third party payouts at this time\",\"meta\":{\"nextStep\":\"Try again later\"},\"type\":\"api_error\",\"code\":\"unknown\"}', '2025-11-29 20:02:55', '2025-11-29 20:02:55'),
(31, 76, 1, 200.00, NULL, 'RCP_d8vwb0x3tor3a22', '{\"source\":\"balance\",\"reason\":\"Prime Earnings Withdrawal - WD-76\",\"amount\":20000,\"recipient\":\"RCP_d8vwb0x3tor3a22\",\"reference\":\"WD-76-1764446575\"}', '{\"status\":false,\"message\":\"You cannot initiate third party payouts at this time\",\"meta\":{\"nextStep\":\"Try again later\"},\"type\":\"api_error\",\"code\":\"unknown\"}', 400, '{\"status\":false,\"message\":\"You cannot initiate third party payouts at this time\",\"meta\":{\"nextStep\":\"Try again later\"},\"type\":\"api_error\",\"code\":\"unknown\"}', '2025-11-29 20:02:56', '2025-11-29 20:02:56'),
(32, 62, 1, 300.00, NULL, 'RCP_d8vwb0x3tor3a22', '{\"source\":\"balance\",\"reason\":\"Prime Earnings Withdrawal - WD-62\",\"amount\":30000,\"recipient\":\"RCP_d8vwb0x3tor3a22\",\"reference\":\"WD-62-1764482309\"}', '{\"status\":false,\"message\":\"You cannot initiate third party payouts at this time\",\"meta\":{\"nextStep\":\"Try again later\"},\"type\":\"api_error\",\"code\":\"unknown\"}', 400, '{\"status\":false,\"message\":\"You cannot initiate third party payouts at this time\",\"meta\":{\"nextStep\":\"Try again later\"},\"type\":\"api_error\",\"code\":\"unknown\"}', '2025-11-30 05:58:29', '2025-11-30 05:58:29'),
(33, 74, 47, 300.00, NULL, 'RCP_dxsnwbkh5zee54x', '{\"source\":\"balance\",\"reason\":\"Prime Earnings Withdrawal - WD-74\",\"amount\":30000,\"recipient\":\"RCP_dxsnwbkh5zee54x\",\"reference\":\"WD-74-1764482309\"}', '{\"status\":false,\"message\":\"You cannot initiate third party payouts at this time\",\"meta\":{\"nextStep\":\"Try again later\"},\"type\":\"api_error\",\"code\":\"unknown\"}', 400, '{\"status\":false,\"message\":\"You cannot initiate third party payouts at this time\",\"meta\":{\"nextStep\":\"Try again later\"},\"type\":\"api_error\",\"code\":\"unknown\"}', '2025-11-30 05:58:29', '2025-11-30 05:58:29'),
(34, 75, 1, 200.00, NULL, 'RCP_d8vwb0x3tor3a22', '{\"source\":\"balance\",\"reason\":\"Prime Earnings Withdrawal - WD-75\",\"amount\":20000,\"recipient\":\"RCP_d8vwb0x3tor3a22\",\"reference\":\"WD-75-1764482309\"}', '{\"status\":false,\"message\":\"You cannot initiate third party payouts at this time\",\"meta\":{\"nextStep\":\"Try again later\"},\"type\":\"api_error\",\"code\":\"unknown\"}', 400, '{\"status\":false,\"message\":\"You cannot initiate third party payouts at this time\",\"meta\":{\"nextStep\":\"Try again later\"},\"type\":\"api_error\",\"code\":\"unknown\"}', '2025-11-30 05:58:29', '2025-11-30 05:58:29'),
(35, 76, 1, 200.00, NULL, 'RCP_d8vwb0x3tor3a22', '{\"source\":\"balance\",\"reason\":\"Prime Earnings Withdrawal - WD-76\",\"amount\":20000,\"recipient\":\"RCP_d8vwb0x3tor3a22\",\"reference\":\"WD-76-1764482309\"}', '{\"status\":false,\"message\":\"You cannot initiate third party payouts at this time\",\"meta\":{\"nextStep\":\"Try again later\"},\"type\":\"api_error\",\"code\":\"unknown\"}', 400, '{\"status\":false,\"message\":\"You cannot initiate third party payouts at this time\",\"meta\":{\"nextStep\":\"Try again later\"},\"type\":\"api_error\",\"code\":\"unknown\"}', '2025-11-30 05:58:30', '2025-11-30 05:58:30'),
(36, 62, 1, 300.00, NULL, 'RCP_d8vwb0x3tor3a22', '{\"source\":\"balance\",\"reason\":\"Prime Earnings Withdrawal - WD-62\",\"amount\":30000,\"recipient\":\"RCP_d8vwb0x3tor3a22\",\"reference\":\"WD-62-1764482319\"}', '{\"status\":false,\"message\":\"You cannot initiate third party payouts at this time\",\"meta\":{\"nextStep\":\"Try again later\"},\"type\":\"api_error\",\"code\":\"unknown\"}', 400, '{\"status\":false,\"message\":\"You cannot initiate third party payouts at this time\",\"meta\":{\"nextStep\":\"Try again later\"},\"type\":\"api_error\",\"code\":\"unknown\"}', '2025-11-30 05:58:39', '2025-11-30 05:58:39'),
(37, 74, 47, 300.00, NULL, 'RCP_dxsnwbkh5zee54x', '{\"source\":\"balance\",\"reason\":\"Prime Earnings Withdrawal - WD-74\",\"amount\":30000,\"recipient\":\"RCP_dxsnwbkh5zee54x\",\"reference\":\"WD-74-1764482319\"}', '{\"status\":false,\"message\":\"You cannot initiate third party payouts at this time\",\"meta\":{\"nextStep\":\"Try again later\"},\"type\":\"api_error\",\"code\":\"unknown\"}', 400, '{\"status\":false,\"message\":\"You cannot initiate third party payouts at this time\",\"meta\":{\"nextStep\":\"Try again later\"},\"type\":\"api_error\",\"code\":\"unknown\"}', '2025-11-30 05:58:39', '2025-11-30 05:58:39'),
(38, 75, 1, 200.00, NULL, 'RCP_d8vwb0x3tor3a22', '{\"source\":\"balance\",\"reason\":\"Prime Earnings Withdrawal - WD-75\",\"amount\":20000,\"recipient\":\"RCP_d8vwb0x3tor3a22\",\"reference\":\"WD-75-1764482319\"}', '{\"status\":false,\"message\":\"You cannot initiate third party payouts at this time\",\"meta\":{\"nextStep\":\"Try again later\"},\"type\":\"api_error\",\"code\":\"unknown\"}', 400, '{\"status\":false,\"message\":\"You cannot initiate third party payouts at this time\",\"meta\":{\"nextStep\":\"Try again later\"},\"type\":\"api_error\",\"code\":\"unknown\"}', '2025-11-30 05:58:40', '2025-11-30 05:58:40'),
(39, 76, 1, 200.00, NULL, 'RCP_d8vwb0x3tor3a22', '{\"source\":\"balance\",\"reason\":\"Prime Earnings Withdrawal - WD-76\",\"amount\":20000,\"recipient\":\"RCP_d8vwb0x3tor3a22\",\"reference\":\"WD-76-1764482320\"}', '{\"status\":false,\"message\":\"You cannot initiate third party payouts at this time\",\"meta\":{\"nextStep\":\"Try again later\"},\"type\":\"api_error\",\"code\":\"unknown\"}', 400, '{\"status\":false,\"message\":\"You cannot initiate third party payouts at this time\",\"meta\":{\"nextStep\":\"Try again later\"},\"type\":\"api_error\",\"code\":\"unknown\"}', '2025-11-30 05:58:40', '2025-11-30 05:58:40'),
(40, 62, 1, 300.00, NULL, 'RCP_d8vwb0x3tor3a22', '{\"source\":\"balance\",\"reason\":\"Prime Earnings Withdrawal - WD-62\",\"amount\":30000,\"recipient\":\"RCP_d8vwb0x3tor3a22\",\"reference\":\"WD-62-1764493235\"}', '{\"status\":false,\"message\":\"You cannot initiate third party payouts at this time\",\"meta\":{\"nextStep\":\"Try again later\"},\"type\":\"api_error\",\"code\":\"unknown\"}', 400, '{\"status\":false,\"message\":\"You cannot initiate third party payouts at this time\",\"meta\":{\"nextStep\":\"Try again later\"},\"type\":\"api_error\",\"code\":\"unknown\"}', '2025-11-30 09:00:36', '2025-11-30 09:00:36'),
(41, 74, 47, 300.00, NULL, 'RCP_dxsnwbkh5zee54x', '{\"source\":\"balance\",\"reason\":\"Prime Earnings Withdrawal - WD-74\",\"amount\":30000,\"recipient\":\"RCP_dxsnwbkh5zee54x\",\"reference\":\"WD-74-1764493236\"}', '{\"status\":false,\"message\":\"You cannot initiate third party payouts at this time\",\"meta\":{\"nextStep\":\"Try again later\"},\"type\":\"api_error\",\"code\":\"unknown\"}', 400, '{\"status\":false,\"message\":\"You cannot initiate third party payouts at this time\",\"meta\":{\"nextStep\":\"Try again later\"},\"type\":\"api_error\",\"code\":\"unknown\"}', '2025-11-30 09:00:36', '2025-11-30 09:00:36'),
(42, 75, 1, 200.00, NULL, 'RCP_d8vwb0x3tor3a22', '{\"source\":\"balance\",\"reason\":\"Prime Earnings Withdrawal - WD-75\",\"amount\":20000,\"recipient\":\"RCP_d8vwb0x3tor3a22\",\"reference\":\"WD-75-1764493236\"}', '{\"status\":false,\"message\":\"You cannot initiate third party payouts at this time\",\"meta\":{\"nextStep\":\"Try again later\"},\"type\":\"api_error\",\"code\":\"unknown\"}', 400, '{\"status\":false,\"message\":\"You cannot initiate third party payouts at this time\",\"meta\":{\"nextStep\":\"Try again later\"},\"type\":\"api_error\",\"code\":\"unknown\"}', '2025-11-30 09:00:36', '2025-11-30 09:00:36'),
(43, 76, 1, 200.00, NULL, 'RCP_d8vwb0x3tor3a22', '{\"source\":\"balance\",\"reason\":\"Prime Earnings Withdrawal - WD-76\",\"amount\":20000,\"recipient\":\"RCP_d8vwb0x3tor3a22\",\"reference\":\"WD-76-1764493236\"}', '{\"status\":false,\"message\":\"You cannot initiate third party payouts at this time\",\"meta\":{\"nextStep\":\"Try again later\"},\"type\":\"api_error\",\"code\":\"unknown\"}', 400, '{\"status\":false,\"message\":\"You cannot initiate third party payouts at this time\",\"meta\":{\"nextStep\":\"Try again later\"},\"type\":\"api_error\",\"code\":\"unknown\"}', '2025-11-30 09:00:36', '2025-11-30 09:00:36'),
(44, 62, 1, 300.00, NULL, 'RCP_d8vwb0x3tor3a22', '{\"source\":\"balance\",\"reason\":\"Prime Earnings Withdrawal - WD-62\",\"amount\":30000,\"recipient\":\"RCP_d8vwb0x3tor3a22\",\"reference\":\"WD-62-1764493323\"}', '{\"status\":false,\"message\":\"You cannot initiate third party payouts at this time\",\"meta\":{\"nextStep\":\"Try again later\"},\"type\":\"api_error\",\"code\":\"unknown\"}', 400, '{\"status\":false,\"message\":\"You cannot initiate third party payouts at this time\",\"meta\":{\"nextStep\":\"Try again later\"},\"type\":\"api_error\",\"code\":\"unknown\"}', '2025-11-30 09:02:04', '2025-11-30 09:02:04'),
(45, 74, 47, 300.00, NULL, 'RCP_dxsnwbkh5zee54x', '{\"source\":\"balance\",\"reason\":\"Prime Earnings Withdrawal - WD-74\",\"amount\":30000,\"recipient\":\"RCP_dxsnwbkh5zee54x\",\"reference\":\"WD-74-1764493324\"}', '{\"status\":false,\"message\":\"You cannot initiate third party payouts at this time\",\"meta\":{\"nextStep\":\"Try again later\"},\"type\":\"api_error\",\"code\":\"unknown\"}', 400, '{\"status\":false,\"message\":\"You cannot initiate third party payouts at this time\",\"meta\":{\"nextStep\":\"Try again later\"},\"type\":\"api_error\",\"code\":\"unknown\"}', '2025-11-30 09:02:04', '2025-11-30 09:02:04'),
(46, 75, 1, 200.00, NULL, 'RCP_d8vwb0x3tor3a22', '{\"source\":\"balance\",\"reason\":\"Prime Earnings Withdrawal - WD-75\",\"amount\":20000,\"recipient\":\"RCP_d8vwb0x3tor3a22\",\"reference\":\"WD-75-1764493324\"}', '{\"status\":false,\"message\":\"You cannot initiate third party payouts at this time\",\"meta\":{\"nextStep\":\"Try again later\"},\"type\":\"api_error\",\"code\":\"unknown\"}', 400, '{\"status\":false,\"message\":\"You cannot initiate third party payouts at this time\",\"meta\":{\"nextStep\":\"Try again later\"},\"type\":\"api_error\",\"code\":\"unknown\"}', '2025-11-30 09:02:04', '2025-11-30 09:02:04'),
(47, 76, 1, 200.00, NULL, 'RCP_d8vwb0x3tor3a22', '{\"source\":\"balance\",\"reason\":\"Prime Earnings Withdrawal - WD-76\",\"amount\":20000,\"recipient\":\"RCP_d8vwb0x3tor3a22\",\"reference\":\"WD-76-1764493324\"}', '{\"status\":false,\"message\":\"You cannot initiate third party payouts at this time\",\"meta\":{\"nextStep\":\"Try again later\"},\"type\":\"api_error\",\"code\":\"unknown\"}', 400, '{\"status\":false,\"message\":\"You cannot initiate third party payouts at this time\",\"meta\":{\"nextStep\":\"Try again later\"},\"type\":\"api_error\",\"code\":\"unknown\"}', '2025-11-30 09:02:04', '2025-11-30 09:02:04'),
(48, 62, 1, 300.00, NULL, 'RCP_d8vwb0x3tor3a22', '{\"source\":\"balance\",\"reason\":\"Prime Earnings Withdrawal - WD-62\",\"amount\":30000,\"recipient\":\"RCP_d8vwb0x3tor3a22\",\"reference\":\"WD-62-1764496280\"}', '{\"status\":true,\"message\":\"Transfer has been queued\",\"data\":{\"transfersessionid\":[],\"transfertrials\":[],\"domain\":\"live\",\"amount\":30000,\"currency\":\"NGN\",\"reference\":\"WD-62-1764496280\",\"source\":\"balance\",\"source_details\":null,\"reason\":\"Prime Earnings Withdrawal - WD-62\",\"status\":\"pending\",\"failures\":null,\"transfer_code\":\"TRF_mlsdbcu401f8puwj\",\"titan_code\":null,\"transferred_at\":null,\"id\":921828719,\"integration\":1606789,\"request\":1157103772,\"recipient\":116473254,\"createdAt\":\"2025-11-30T09:51:21.000Z\",\"updatedAt\":\"2025-11-30T09:51:21.000Z\"}}', 200, '{\"status\":true,\"message\":\"Transfer has been queued\",\"data\":{\"transfersessionid\":[],\"transfertrials\":[],\"domain\":\"live\",\"amount\":30000,\"currency\":\"NGN\",\"reference\":\"WD-62-1764496280\",\"source\":\"balance\",\"source_details\":null,\"reason\":\"Prime Earnings Withdrawal - WD-62\",\"status\":\"pending\",\"failures\":null,\"transfer_code\":\"TRF_mlsdbcu401f8puwj\",\"titan_code\":null,\"transferred_at\":null,\"id\":921828719,\"integration\":1606789,\"request\":1157103772,\"recipient\":116473254,\"createdAt\":\"2025-11-30T09:51:21.000Z\",\"updatedAt\":\"2025-11-30T09:51:21.000Z\"}}', '2025-11-30 09:51:23', '2025-11-30 09:51:23'),
(49, 74, 47, 300.00, NULL, 'RCP_dxsnwbkh5zee54x', '{\"source\":\"balance\",\"reason\":\"Prime Earnings Withdrawal - WD-74\",\"amount\":30000,\"recipient\":\"RCP_dxsnwbkh5zee54x\",\"reference\":\"WD-74-1764496283\"}', '{\"status\":true,\"message\":\"Transfer has been queued\",\"data\":{\"transfersessionid\":[],\"transfertrials\":[],\"domain\":\"live\",\"amount\":30000,\"currency\":\"NGN\",\"reference\":\"WD-74-1764496283\",\"source\":\"balance\",\"source_details\":null,\"reason\":\"Prime Earnings Withdrawal - WD-74\",\"status\":\"pending\",\"failures\":null,\"transfer_code\":\"TRF_mg257hrmo54wctly\",\"titan_code\":null,\"transferred_at\":null,\"id\":921828739,\"integration\":1606789,\"request\":1157103792,\"recipient\":116524974,\"createdAt\":\"2025-11-30T09:51:24.000Z\",\"updatedAt\":\"2025-11-30T09:51:24.000Z\"}}', 200, '{\"status\":true,\"message\":\"Transfer has been queued\",\"data\":{\"transfersessionid\":[],\"transfertrials\":[],\"domain\":\"live\",\"amount\":30000,\"currency\":\"NGN\",\"reference\":\"WD-74-1764496283\",\"source\":\"balance\",\"source_details\":null,\"reason\":\"Prime Earnings Withdrawal - WD-74\",\"status\":\"pending\",\"failures\":null,\"transfer_code\":\"TRF_mg257hrmo54wctly\",\"titan_code\":null,\"transferred_at\":null,\"id\":921828739,\"integration\":1606789,\"request\":1157103792,\"recipient\":116524974,\"createdAt\":\"2025-11-30T09:51:24.000Z\",\"updatedAt\":\"2025-11-30T09:51:24.000Z\"}}', '2025-11-30 09:51:26', '2025-11-30 09:51:26'),
(50, 75, 1, 200.00, NULL, 'RCP_d8vwb0x3tor3a22', '{\"source\":\"balance\",\"reason\":\"Prime Earnings Withdrawal - WD-75\",\"amount\":20000,\"recipient\":\"RCP_d8vwb0x3tor3a22\",\"reference\":\"WD-75-1764496286\"}', '{\"status\":true,\"message\":\"Transfer has been queued\",\"data\":{\"transfersessionid\":[],\"transfertrials\":[],\"domain\":\"live\",\"amount\":20000,\"currency\":\"NGN\",\"reference\":\"WD-75-1764496286\",\"source\":\"balance\",\"source_details\":null,\"reason\":\"Prime Earnings Withdrawal - WD-75\",\"status\":\"pending\",\"failures\":null,\"transfer_code\":\"TRF_n2cyuzpq8z3mkvkw\",\"titan_code\":null,\"transferred_at\":null,\"id\":921828748,\"integration\":1606789,\"request\":1157103801,\"recipient\":116473254,\"createdAt\":\"2025-11-30T09:51:26.000Z\",\"updatedAt\":\"2025-11-30T09:51:26.000Z\"}}', 200, '{\"status\":true,\"message\":\"Transfer has been queued\",\"data\":{\"transfersessionid\":[],\"transfertrials\":[],\"domain\":\"live\",\"amount\":20000,\"currency\":\"NGN\",\"reference\":\"WD-75-1764496286\",\"source\":\"balance\",\"source_details\":null,\"reason\":\"Prime Earnings Withdrawal - WD-75\",\"status\":\"pending\",\"failures\":null,\"transfer_code\":\"TRF_n2cyuzpq8z3mkvkw\",\"titan_code\":null,\"transferred_at\":null,\"id\":921828748,\"integration\":1606789,\"request\":1157103801,\"recipient\":116473254,\"createdAt\":\"2025-11-30T09:51:26.000Z\",\"updatedAt\":\"2025-11-30T09:51:26.000Z\"}}', '2025-11-30 09:51:28', '2025-11-30 09:51:28'),
(51, 76, 1, 200.00, NULL, 'RCP_d8vwb0x3tor3a22', '{\"source\":\"balance\",\"reason\":\"Prime Earnings Withdrawal - WD-76\",\"amount\":20000,\"recipient\":\"RCP_d8vwb0x3tor3a22\",\"reference\":\"WD-76-1764496288\"}', '{\"status\":true,\"message\":\"Transfer has been queued\",\"data\":{\"transfersessionid\":[],\"transfertrials\":[],\"domain\":\"live\",\"amount\":20000,\"currency\":\"NGN\",\"reference\":\"WD-76-1764496288\",\"source\":\"balance\",\"source_details\":null,\"reason\":\"Prime Earnings Withdrawal - WD-76\",\"status\":\"pending\",\"failures\":null,\"transfer_code\":\"TRF_qymg5hgqprm2dk6t\",\"titan_code\":null,\"transferred_at\":null,\"id\":921828760,\"integration\":1606789,\"request\":1157103813,\"recipient\":116473254,\"createdAt\":\"2025-11-30T09:51:29.000Z\",\"updatedAt\":\"2025-11-30T09:51:29.000Z\"}}', 200, '{\"status\":true,\"message\":\"Transfer has been queued\",\"data\":{\"transfersessionid\":[],\"transfertrials\":[],\"domain\":\"live\",\"amount\":20000,\"currency\":\"NGN\",\"reference\":\"WD-76-1764496288\",\"source\":\"balance\",\"source_details\":null,\"reason\":\"Prime Earnings Withdrawal - WD-76\",\"status\":\"pending\",\"failures\":null,\"transfer_code\":\"TRF_qymg5hgqprm2dk6t\",\"titan_code\":null,\"transferred_at\":null,\"id\":921828760,\"integration\":1606789,\"request\":1157103813,\"recipient\":116473254,\"createdAt\":\"2025-11-30T09:51:29.000Z\",\"updatedAt\":\"2025-11-30T09:51:29.000Z\"}}', '2025-11-30 09:51:31', '2025-11-30 09:51:31'),
(52, 77, 54, 200.00, NULL, 'RCP_d581789pmena3gn', '{\"source\":\"balance\",\"reason\":\"Prime Earnings Withdrawal - WD-77\",\"amount\":20000,\"recipient\":\"RCP_d581789pmena3gn\",\"reference\":\"WD-77-1764496291\"}', '{\"status\":true,\"message\":\"Transfer has been queued\",\"data\":{\"transfersessionid\":[],\"transfertrials\":[],\"domain\":\"live\",\"amount\":20000,\"currency\":\"NGN\",\"reference\":\"WD-77-1764496291\",\"source\":\"balance\",\"source_details\":null,\"reason\":\"Prime Earnings Withdrawal - WD-77\",\"status\":\"pending\",\"failures\":null,\"transfer_code\":\"TRF_yonlh4x8n21ecy4m\",\"titan_code\":null,\"transferred_at\":null,\"id\":921828771,\"integration\":1606789,\"request\":1157103825,\"recipient\":116480867,\"createdAt\":\"2025-11-30T09:51:31.000Z\",\"updatedAt\":\"2025-11-30T09:51:31.000Z\"}}', 200, '{\"status\":true,\"message\":\"Transfer has been queued\",\"data\":{\"transfersessionid\":[],\"transfertrials\":[],\"domain\":\"live\",\"amount\":20000,\"currency\":\"NGN\",\"reference\":\"WD-77-1764496291\",\"source\":\"balance\",\"source_details\":null,\"reason\":\"Prime Earnings Withdrawal - WD-77\",\"status\":\"pending\",\"failures\":null,\"transfer_code\":\"TRF_yonlh4x8n21ecy4m\",\"titan_code\":null,\"transferred_at\":null,\"id\":921828771,\"integration\":1606789,\"request\":1157103825,\"recipient\":116480867,\"createdAt\":\"2025-11-30T09:51:31.000Z\",\"updatedAt\":\"2025-11-30T09:51:31.000Z\"}}', '2025-11-30 09:51:34', '2025-11-30 09:51:34'),
(53, 78, 54, 1000.00, NULL, 'RCP_d581789pmena3gn', '{\"source\":\"balance\",\"reason\":\"Prime Earnings Withdrawal - WD-78\",\"amount\":100000,\"recipient\":\"RCP_d581789pmena3gn\",\"reference\":\"WD-78-1764573739\"}', '{\"status\":true,\"message\":\"Transfer has been queued\",\"data\":{\"transfersessionid\":[],\"transfertrials\":[],\"domain\":\"live\",\"amount\":100000,\"currency\":\"NGN\",\"reference\":\"WD-78-1764573739\",\"source\":\"balance\",\"source_details\":null,\"reason\":\"Prime Earnings Withdrawal - WD-78\",\"status\":\"pending\",\"failures\":null,\"transfer_code\":\"TRF_odwrb9cfrqwyiz2b\",\"titan_code\":null,\"transferred_at\":null,\"id\":922315050,\"integration\":1606789,\"request\":1157764827,\"recipient\":116480867,\"createdAt\":\"2025-12-01T07:22:20.000Z\",\"updatedAt\":\"2025-12-01T07:22:20.000Z\"}}', 200, '{\"status\":true,\"message\":\"Transfer has been queued\",\"data\":{\"transfersessionid\":[],\"transfertrials\":[],\"domain\":\"live\",\"amount\":100000,\"currency\":\"NGN\",\"reference\":\"WD-78-1764573739\",\"source\":\"balance\",\"source_details\":null,\"reason\":\"Prime Earnings Withdrawal - WD-78\",\"status\":\"pending\",\"failures\":null,\"transfer_code\":\"TRF_odwrb9cfrqwyiz2b\",\"titan_code\":null,\"transferred_at\":null,\"id\":922315050,\"integration\":1606789,\"request\":1157764827,\"recipient\":116480867,\"createdAt\":\"2025-12-01T07:22:20.000Z\",\"updatedAt\":\"2025-12-01T07:22:20.000Z\"}}', '2025-12-01 07:22:23', '2025-12-01 07:22:23'),
(54, 79, 54, 1000.00, NULL, 'RCP_d581789pmena3gn', '{\"source\":\"balance\",\"reason\":\"Prime Earnings Withdrawal - WD-79\",\"amount\":100000,\"recipient\":\"RCP_d581789pmena3gn\",\"reference\":\"WD-79-1764579458\"}', '{\"status\":true,\"message\":\"Transfer has been queued\",\"data\":{\"transfersessionid\":[],\"transfertrials\":[],\"domain\":\"live\",\"amount\":100000,\"currency\":\"NGN\",\"reference\":\"WD-79-1764579458\",\"source\":\"balance\",\"source_details\":null,\"reason\":\"Prime Earnings Withdrawal - WD-79\",\"status\":\"pending\",\"failures\":null,\"transfer_code\":\"TRF_u1y0rjdqq64ioo7q\",\"titan_code\":null,\"transferred_at\":null,\"id\":922353333,\"integration\":1606789,\"request\":1157810490,\"recipient\":116480867,\"createdAt\":\"2025-12-01T08:57:39.000Z\",\"updatedAt\":\"2025-12-01T08:57:39.000Z\"}}', 200, '{\"status\":true,\"message\":\"Transfer has been queued\",\"data\":{\"transfersessionid\":[],\"transfertrials\":[],\"domain\":\"live\",\"amount\":100000,\"currency\":\"NGN\",\"reference\":\"WD-79-1764579458\",\"source\":\"balance\",\"source_details\":null,\"reason\":\"Prime Earnings Withdrawal - WD-79\",\"status\":\"pending\",\"failures\":null,\"transfer_code\":\"TRF_u1y0rjdqq64ioo7q\",\"titan_code\":null,\"transferred_at\":null,\"id\":922353333,\"integration\":1606789,\"request\":1157810490,\"recipient\":116480867,\"createdAt\":\"2025-12-01T08:57:39.000Z\",\"updatedAt\":\"2025-12-01T08:57:39.000Z\"}}', '2025-12-01 08:57:42', '2025-12-01 08:57:42'),
(55, 80, 54, 20000.00, NULL, 'RCP_d581789pmena3gn', '{\"source\":\"balance\",\"reason\":\"Prime Earnings Withdrawal - WD-80\",\"amount\":2000000,\"recipient\":\"RCP_d581789pmena3gn\",\"reference\":\"WD-80-1764595606\"}', '{\"status\":false,\"message\":\"Your balance is not enough to fulfil this request\",\"meta\":{\"nextStep\":\"Topup your Paystack Balance and try again.\"},\"type\":\"api_error\",\"code\":\"insufficient_balance\"}', 400, '{\"status\":false,\"message\":\"Your balance is not enough to fulfil this request\",\"meta\":{\"nextStep\":\"Topup your Paystack Balance and try again.\"},\"type\":\"api_error\",\"code\":\"insufficient_balance\"}', '2025-12-01 13:26:46', '2025-12-01 13:26:46'),
(56, 81, 54, 30000.00, NULL, 'RCP_d581789pmena3gn', '{\"source\":\"balance\",\"reason\":\"Prime Earnings Withdrawal - WD-81\",\"amount\":3000000,\"recipient\":\"RCP_d581789pmena3gn\",\"reference\":\"WD-81-1764595945\"}', '{\"status\":false,\"message\":\"Your balance is not enough to fulfil this request\",\"meta\":{\"nextStep\":\"Topup your Paystack Balance and try again.\"},\"type\":\"api_error\",\"code\":\"insufficient_balance\"}', 400, '{\"status\":false,\"message\":\"Your balance is not enough to fulfil this request\",\"meta\":{\"nextStep\":\"Topup your Paystack Balance and try again.\"},\"type\":\"api_error\",\"code\":\"insufficient_balance\"}', '2025-12-01 13:32:25', '2025-12-01 13:32:25'),
(57, 82, 54, 10000.00, NULL, 'RCP_d581789pmena3gn', '{\"source\":\"balance\",\"reason\":\"Prime Earnings Withdrawal - WD-82\",\"amount\":1000000,\"recipient\":\"RCP_d581789pmena3gn\",\"reference\":\"WD-82-1764596149\"}', '{\"status\":false,\"message\":\"Your balance is not enough to fulfil this request\",\"meta\":{\"nextStep\":\"Topup your Paystack Balance and try again.\"},\"type\":\"api_error\",\"code\":\"insufficient_balance\"}', 400, '{\"status\":false,\"message\":\"Your balance is not enough to fulfil this request\",\"meta\":{\"nextStep\":\"Topup your Paystack Balance and try again.\"},\"type\":\"api_error\",\"code\":\"insufficient_balance\"}', '2025-12-01 13:35:49', '2025-12-01 13:35:49');
INSERT INTO `paystack_transfer_logs` (`id`, `withdrawal_id`, `user_id`, `transfer_amount`, `paystack_transfer_id`, `recipient_code`, `api_request`, `api_response`, `api_status_code`, `error_message`, `created_at`, `updated_at`) VALUES
(58, 83, 54, 23000.00, NULL, 'RCP_d581789pmena3gn', '{\"source\":\"balance\",\"reason\":\"Prime Earnings Withdrawal - WD-83\",\"amount\":2300000,\"recipient\":\"RCP_d581789pmena3gn\",\"reference\":\"WD-83-1764596440\"}', '{\"status\":false,\"message\":\"Your balance is not enough to fulfil this request\",\"meta\":{\"nextStep\":\"Topup your Paystack Balance and try again.\"},\"type\":\"api_error\",\"code\":\"insufficient_balance\"}', 400, '{\"status\":false,\"message\":\"Your balance is not enough to fulfil this request\",\"meta\":{\"nextStep\":\"Topup your Paystack Balance and try again.\"},\"type\":\"api_error\",\"code\":\"insufficient_balance\"}', '2025-12-01 13:40:40', '2025-12-01 13:40:40'),
(59, 83, 54, 23000.00, NULL, 'RCP_d581789pmena3gn', '{\"source\":\"balance\",\"reason\":\"Prime Earnings Withdrawal - WD-83\",\"amount\":2300000,\"recipient\":\"RCP_d581789pmena3gn\",\"reference\":\"WD-83-1764596546\"}', '{\"status\":false,\"message\":\"Your balance is not enough to fulfil this request\",\"meta\":{\"nextStep\":\"Topup your Paystack Balance and try again.\"},\"type\":\"api_error\",\"code\":\"insufficient_balance\"}', 400, '{\"status\":false,\"message\":\"Your balance is not enough to fulfil this request\",\"meta\":{\"nextStep\":\"Topup your Paystack Balance and try again.\"},\"type\":\"api_error\",\"code\":\"insufficient_balance\"}', '2025-12-01 13:42:27', '2025-12-01 13:42:27'),
(60, 84, 54, 20000.00, NULL, 'RCP_d581789pmena3gn', '{\"source\":\"balance\",\"reason\":\"Prime Earnings Withdrawal - WD-84\",\"amount\":2000000,\"recipient\":\"RCP_d581789pmena3gn\",\"reference\":\"WD-84-1764596547\"}', '{\"status\":false,\"message\":\"Your balance is not enough to fulfil this request\",\"meta\":{\"nextStep\":\"Topup your Paystack Balance and try again.\"},\"type\":\"api_error\",\"code\":\"insufficient_balance\"}', 400, '{\"status\":false,\"message\":\"Your balance is not enough to fulfil this request\",\"meta\":{\"nextStep\":\"Topup your Paystack Balance and try again.\"},\"type\":\"api_error\",\"code\":\"insufficient_balance\"}', '2025-12-01 13:42:27', '2025-12-01 13:42:27'),
(61, 83, 54, 23000.00, NULL, 'RCP_d581789pmena3gn', '{\"source\":\"balance\",\"reason\":\"Prime Earnings Withdrawal - WD-83\",\"amount\":2300000,\"recipient\":\"RCP_d581789pmena3gn\",\"reference\":\"WD-83-1764596625\"}', '{\"status\":false,\"message\":\"Your balance is not enough to fulfil this request\",\"meta\":{\"nextStep\":\"Topup your Paystack Balance and try again.\"},\"type\":\"api_error\",\"code\":\"insufficient_balance\"}', 400, '{\"status\":false,\"message\":\"Your balance is not enough to fulfil this request\",\"meta\":{\"nextStep\":\"Topup your Paystack Balance and try again.\"},\"type\":\"api_error\",\"code\":\"insufficient_balance\"}', '2025-12-01 13:43:45', '2025-12-01 13:43:45'),
(62, 84, 54, 20000.00, NULL, 'RCP_d581789pmena3gn', '{\"source\":\"balance\",\"reason\":\"Prime Earnings Withdrawal - WD-84\",\"amount\":2000000,\"recipient\":\"RCP_d581789pmena3gn\",\"reference\":\"WD-84-1764596625\"}', '{\"status\":false,\"message\":\"Your balance is not enough to fulfil this request\",\"meta\":{\"nextStep\":\"Topup your Paystack Balance and try again.\"},\"type\":\"api_error\",\"code\":\"insufficient_balance\"}', 400, '{\"status\":false,\"message\":\"Your balance is not enough to fulfil this request\",\"meta\":{\"nextStep\":\"Topup your Paystack Balance and try again.\"},\"type\":\"api_error\",\"code\":\"insufficient_balance\"}', '2025-12-01 13:43:45', '2025-12-01 13:43:45'),
(63, 85, 54, 10000.00, NULL, 'RCP_d581789pmena3gn', '{\"source\":\"balance\",\"reason\":\"Prime Earnings Withdrawal - WD-85\",\"amount\":1000000,\"recipient\":\"RCP_d581789pmena3gn\",\"reference\":\"WD-85-1764596625\"}', '{\"status\":false,\"message\":\"Your balance is not enough to fulfil this request\",\"meta\":{\"nextStep\":\"Topup your Paystack Balance and try again.\"},\"type\":\"api_error\",\"code\":\"insufficient_balance\"}', 400, '{\"status\":false,\"message\":\"Your balance is not enough to fulfil this request\",\"meta\":{\"nextStep\":\"Topup your Paystack Balance and try again.\"},\"type\":\"api_error\",\"code\":\"insufficient_balance\"}', '2025-12-01 13:43:46', '2025-12-01 13:43:46'),
(64, 83, 54, 23000.00, NULL, 'RCP_d581789pmena3gn', '{\"source\":\"balance\",\"reason\":\"Prime Earnings Withdrawal - WD-83\",\"amount\":2300000,\"recipient\":\"RCP_d581789pmena3gn\",\"reference\":\"WD-83-1764596654\"}', '{\"status\":false,\"message\":\"Your balance is not enough to fulfil this request\",\"meta\":{\"nextStep\":\"Topup your Paystack Balance and try again.\"},\"type\":\"api_error\",\"code\":\"insufficient_balance\"}', 400, '{\"status\":false,\"message\":\"Your balance is not enough to fulfil this request\",\"meta\":{\"nextStep\":\"Topup your Paystack Balance and try again.\"},\"type\":\"api_error\",\"code\":\"insufficient_balance\"}', '2025-12-01 13:44:15', '2025-12-01 13:44:15'),
(65, 84, 54, 20000.00, NULL, 'RCP_d581789pmena3gn', '{\"source\":\"balance\",\"reason\":\"Prime Earnings Withdrawal - WD-84\",\"amount\":2000000,\"recipient\":\"RCP_d581789pmena3gn\",\"reference\":\"WD-84-1764596655\"}', '{\"status\":false,\"message\":\"Your balance is not enough to fulfil this request\",\"meta\":{\"nextStep\":\"Topup your Paystack Balance and try again.\"},\"type\":\"api_error\",\"code\":\"insufficient_balance\"}', 400, '{\"status\":false,\"message\":\"Your balance is not enough to fulfil this request\",\"meta\":{\"nextStep\":\"Topup your Paystack Balance and try again.\"},\"type\":\"api_error\",\"code\":\"insufficient_balance\"}', '2025-12-01 13:44:15', '2025-12-01 13:44:15'),
(66, 85, 54, 10000.00, NULL, 'RCP_d581789pmena3gn', '{\"source\":\"balance\",\"reason\":\"Prime Earnings Withdrawal - WD-85\",\"amount\":1000000,\"recipient\":\"RCP_d581789pmena3gn\",\"reference\":\"WD-85-1764596655\"}', '{\"status\":false,\"message\":\"Your balance is not enough to fulfil this request\",\"meta\":{\"nextStep\":\"Topup your Paystack Balance and try again.\"},\"type\":\"api_error\",\"code\":\"insufficient_balance\"}', 400, '{\"status\":false,\"message\":\"Your balance is not enough to fulfil this request\",\"meta\":{\"nextStep\":\"Topup your Paystack Balance and try again.\"},\"type\":\"api_error\",\"code\":\"insufficient_balance\"}', '2025-12-01 13:44:15', '2025-12-01 13:44:15'),
(67, 86, 54, 10000.00, NULL, 'RCP_d581789pmena3gn', '{\"source\":\"balance\",\"reason\":\"Prime Earnings Withdrawal - WD-86\",\"amount\":1000000,\"recipient\":\"RCP_d581789pmena3gn\",\"reference\":\"WD-86-1764596655\"}', '{\"status\":false,\"message\":\"Your balance is not enough to fulfil this request\",\"meta\":{\"nextStep\":\"Topup your Paystack Balance and try again.\"},\"type\":\"api_error\",\"code\":\"insufficient_balance\"}', 400, '{\"status\":false,\"message\":\"Your balance is not enough to fulfil this request\",\"meta\":{\"nextStep\":\"Topup your Paystack Balance and try again.\"},\"type\":\"api_error\",\"code\":\"insufficient_balance\"}', '2025-12-01 13:44:16', '2025-12-01 13:44:16'),
(68, 83, 54, 23000.00, NULL, 'RCP_d581789pmena3gn', '{\"source\":\"balance\",\"reason\":\"Prime Earnings Withdrawal - WD-83\",\"amount\":2300000,\"recipient\":\"RCP_d581789pmena3gn\",\"reference\":\"WD-83-1764686854\"}', '{\"status\":false,\"message\":\"Your balance is not enough to fulfil this request\",\"meta\":{\"nextStep\":\"Topup your Paystack Balance and try again.\"},\"type\":\"api_error\",\"code\":\"insufficient_balance\"}', 400, '{\"status\":false,\"message\":\"Your balance is not enough to fulfil this request\",\"meta\":{\"nextStep\":\"Topup your Paystack Balance and try again.\"},\"type\":\"api_error\",\"code\":\"insufficient_balance\"}', '2025-12-02 14:47:34', '2025-12-02 14:47:34'),
(69, 84, 54, 20000.00, NULL, 'RCP_d581789pmena3gn', '{\"source\":\"balance\",\"reason\":\"Prime Earnings Withdrawal - WD-84\",\"amount\":2000000,\"recipient\":\"RCP_d581789pmena3gn\",\"reference\":\"WD-84-1764686854\"}', '{\"status\":false,\"message\":\"Your balance is not enough to fulfil this request\",\"meta\":{\"nextStep\":\"Topup your Paystack Balance and try again.\"},\"type\":\"api_error\",\"code\":\"insufficient_balance\"}', 400, '{\"status\":false,\"message\":\"Your balance is not enough to fulfil this request\",\"meta\":{\"nextStep\":\"Topup your Paystack Balance and try again.\"},\"type\":\"api_error\",\"code\":\"insufficient_balance\"}', '2025-12-02 14:47:34', '2025-12-02 14:47:34'),
(70, 87, 54, 10000.00, NULL, 'RCP_d581789pmena3gn', '{\"source\":\"balance\",\"reason\":\"Prime Earnings Withdrawal - WD-87\",\"amount\":1000000,\"recipient\":\"RCP_d581789pmena3gn\",\"reference\":\"WD-87-1764686854\"}', '{\"status\":false,\"message\":\"Your balance is not enough to fulfil this request\",\"meta\":{\"nextStep\":\"Topup your Paystack Balance and try again.\"},\"type\":\"api_error\",\"code\":\"insufficient_balance\"}', 400, '{\"status\":false,\"message\":\"Your balance is not enough to fulfil this request\",\"meta\":{\"nextStep\":\"Topup your Paystack Balance and try again.\"},\"type\":\"api_error\",\"code\":\"insufficient_balance\"}', '2025-12-02 14:47:35', '2025-12-02 14:47:35'),
(71, 83, 54, 23000.00, NULL, 'RCP_d581789pmena3gn', '{\"source\":\"balance\",\"reason\":\"Prime Earnings Withdrawal - WD-83\",\"amount\":2300000,\"recipient\":\"RCP_d581789pmena3gn\",\"reference\":\"WD-83-1764800045\"}', '{\"status\":false,\"message\":\"Your balance is not enough to fulfil this request\",\"meta\":{\"nextStep\":\"Topup your Paystack Balance and try again.\"},\"type\":\"api_error\",\"code\":\"insufficient_balance\"}', 400, '{\"status\":false,\"message\":\"Your balance is not enough to fulfil this request\",\"meta\":{\"nextStep\":\"Topup your Paystack Balance and try again.\"},\"type\":\"api_error\",\"code\":\"insufficient_balance\"}', '2025-12-03 22:14:05', '2025-12-03 22:14:05'),
(72, 84, 54, 20000.00, NULL, 'RCP_d581789pmena3gn', '{\"source\":\"balance\",\"reason\":\"Prime Earnings Withdrawal - WD-84\",\"amount\":2000000,\"recipient\":\"RCP_d581789pmena3gn\",\"reference\":\"WD-84-1764800045\"}', '{\"status\":false,\"message\":\"Your balance is not enough to fulfil this request\",\"meta\":{\"nextStep\":\"Topup your Paystack Balance and try again.\"},\"type\":\"api_error\",\"code\":\"insufficient_balance\"}', 400, '{\"status\":false,\"message\":\"Your balance is not enough to fulfil this request\",\"meta\":{\"nextStep\":\"Topup your Paystack Balance and try again.\"},\"type\":\"api_error\",\"code\":\"insufficient_balance\"}', '2025-12-03 22:14:06', '2025-12-03 22:14:06'),
(73, 89, 47, 10000.00, NULL, 'RCP_dxsnwbkh5zee54x', '{\"source\":\"balance\",\"reason\":\"Prime Earnings Withdrawal - WD-89\",\"amount\":1000000,\"recipient\":\"RCP_dxsnwbkh5zee54x\",\"reference\":\"WD-89-1764800046\"}', '{\"status\":false,\"message\":\"Your balance is not enough to fulfil this request\",\"meta\":{\"nextStep\":\"Topup your Paystack Balance and try again.\"},\"type\":\"api_error\",\"code\":\"insufficient_balance\"}', 400, '{\"status\":false,\"message\":\"Your balance is not enough to fulfil this request\",\"meta\":{\"nextStep\":\"Topup your Paystack Balance and try again.\"},\"type\":\"api_error\",\"code\":\"insufficient_balance\"}', '2025-12-03 22:14:06', '2025-12-03 22:14:06'),
(74, 83, 54, 23000.00, NULL, 'RCP_d581789pmena3gn', '{\"source\":\"balance\",\"reason\":\"Prime Earnings Withdrawal - WD-83\",\"amount\":2300000,\"recipient\":\"RCP_d581789pmena3gn\",\"reference\":\"WD-83-1764843654\"}', '{\"status\":false,\"message\":\"Your balance is not enough to fulfil this request\",\"meta\":{\"nextStep\":\"Topup your Paystack Balance and try again.\"},\"type\":\"api_error\",\"code\":\"insufficient_balance\"}', 400, '{\"status\":false,\"message\":\"Your balance is not enough to fulfil this request\",\"meta\":{\"nextStep\":\"Topup your Paystack Balance and try again.\"},\"type\":\"api_error\",\"code\":\"insufficient_balance\"}', '2025-12-04 10:20:54', '2025-12-04 10:20:54'),
(75, 84, 54, 20000.00, NULL, 'RCP_d581789pmena3gn', '{\"source\":\"balance\",\"reason\":\"Prime Earnings Withdrawal - WD-84\",\"amount\":2000000,\"recipient\":\"RCP_d581789pmena3gn\",\"reference\":\"WD-84-1764843654\"}', '{\"status\":false,\"message\":\"Your balance is not enough to fulfil this request\",\"meta\":{\"nextStep\":\"Topup your Paystack Balance and try again.\"},\"type\":\"api_error\",\"code\":\"insufficient_balance\"}', 400, '{\"status\":false,\"message\":\"Your balance is not enough to fulfil this request\",\"meta\":{\"nextStep\":\"Topup your Paystack Balance and try again.\"},\"type\":\"api_error\",\"code\":\"insufficient_balance\"}', '2025-12-04 10:20:54', '2025-12-04 10:20:54'),
(76, 89, 47, 10000.00, NULL, 'RCP_dxsnwbkh5zee54x', '{\"source\":\"balance\",\"reason\":\"Prime Earnings Withdrawal - WD-89\",\"amount\":1000000,\"recipient\":\"RCP_dxsnwbkh5zee54x\",\"reference\":\"WD-89-1764843654\"}', '{\"status\":false,\"message\":\"Your balance is not enough to fulfil this request\",\"meta\":{\"nextStep\":\"Topup your Paystack Balance and try again.\"},\"type\":\"api_error\",\"code\":\"insufficient_balance\"}', 400, '{\"status\":false,\"message\":\"Your balance is not enough to fulfil this request\",\"meta\":{\"nextStep\":\"Topup your Paystack Balance and try again.\"},\"type\":\"api_error\",\"code\":\"insufficient_balance\"}', '2025-12-04 10:20:55', '2025-12-04 10:20:55'),
(77, 90, 46, 50000.00, NULL, 'RCP_534mc9ff21ca11p', '{\"source\":\"balance\",\"reason\":\"Prime Earnings Withdrawal - WD-90\",\"amount\":5000000,\"recipient\":\"RCP_534mc9ff21ca11p\",\"reference\":\"WD-90-1764843655\"}', '{\"status\":false,\"message\":\"Your balance is not enough to fulfil this request\",\"meta\":{\"nextStep\":\"Topup your Paystack Balance and try again.\"},\"type\":\"api_error\",\"code\":\"insufficient_balance\"}', 400, '{\"status\":false,\"message\":\"Your balance is not enough to fulfil this request\",\"meta\":{\"nextStep\":\"Topup your Paystack Balance and try again.\"},\"type\":\"api_error\",\"code\":\"insufficient_balance\"}', '2025-12-04 10:20:55', '2025-12-04 10:20:55'),
(78, 89, 47, 10000.00, NULL, 'RCP_dxsnwbkh5zee54x', '{\"source\":\"balance\",\"reason\":\"Prime Earnings Withdrawal - WD-89\",\"amount\":1000000,\"recipient\":\"RCP_dxsnwbkh5zee54x\",\"reference\":\"WD-89-1765216245\"}', '{\"status\":false,\"message\":\"Your balance is not enough to fulfil this request\",\"meta\":{\"nextStep\":\"Topup your Paystack Balance and try again.\"},\"type\":\"api_error\",\"code\":\"insufficient_balance\"}', 400, '{\"status\":false,\"message\":\"Your balance is not enough to fulfil this request\",\"meta\":{\"nextStep\":\"Topup your Paystack Balance and try again.\"},\"type\":\"api_error\",\"code\":\"insufficient_balance\"}', '2025-12-08 17:50:45', '2025-12-08 17:50:45'),
(79, 90, 46, 50000.00, NULL, 'RCP_534mc9ff21ca11p', '{\"source\":\"balance\",\"reason\":\"Prime Earnings Withdrawal - WD-90\",\"amount\":5000000,\"recipient\":\"RCP_534mc9ff21ca11p\",\"reference\":\"WD-90-1765216245\"}', '{\"status\":false,\"message\":\"Your balance is not enough to fulfil this request\",\"meta\":{\"nextStep\":\"Topup your Paystack Balance and try again.\"},\"type\":\"api_error\",\"code\":\"insufficient_balance\"}', 400, '{\"status\":false,\"message\":\"Your balance is not enough to fulfil this request\",\"meta\":{\"nextStep\":\"Topup your Paystack Balance and try again.\"},\"type\":\"api_error\",\"code\":\"insufficient_balance\"}', '2025-12-08 17:50:46', '2025-12-08 17:50:46'),
(80, 91, 47, 1500.00, NULL, 'RCP_dxsnwbkh5zee54x', '{\"source\":\"balance\",\"reason\":\"Prime Earnings Withdrawal - WD-91\",\"amount\":150000,\"recipient\":\"RCP_dxsnwbkh5zee54x\",\"reference\":\"WD-91-1765216246\"}', '{\"status\":true,\"message\":\"Transfer has been queued\",\"data\":{\"transfersessionid\":[],\"transfertrials\":[],\"domain\":\"live\",\"amount\":150000,\"currency\":\"NGN\",\"reference\":\"WD-91-1765216246\",\"source\":\"balance\",\"source_details\":null,\"reason\":\"Prime Earnings Withdrawal - WD-91\",\"status\":\"pending\",\"failures\":null,\"transfer_code\":\"TRF_nmg5rzs7q8nu4g9z\",\"titan_code\":null,\"transferred_at\":null,\"id\":925796289,\"integration\":1606789,\"request\":1162392587,\"recipient\":116524974,\"createdAt\":\"2025-12-08T17:50:47.000Z\",\"updatedAt\":\"2025-12-08T17:50:47.000Z\"}}', 200, '{\"status\":true,\"message\":\"Transfer has been queued\",\"data\":{\"transfersessionid\":[],\"transfertrials\":[],\"domain\":\"live\",\"amount\":150000,\"currency\":\"NGN\",\"reference\":\"WD-91-1765216246\",\"source\":\"balance\",\"source_details\":null,\"reason\":\"Prime Earnings Withdrawal - WD-91\",\"status\":\"pending\",\"failures\":null,\"transfer_code\":\"TRF_nmg5rzs7q8nu4g9z\",\"titan_code\":null,\"transferred_at\":null,\"id\":925796289,\"integration\":1606789,\"request\":1162392587,\"recipient\":116524974,\"createdAt\":\"2025-12-08T17:50:47.000Z\",\"updatedAt\":\"2025-12-08T17:50:47.000Z\"}}', '2025-12-08 17:50:48', '2025-12-08 17:50:48'),
(81, 89, 47, 10000.00, NULL, 'RCP_dxsnwbkh5zee54x', '{\"source\":\"balance\",\"reason\":\"Prime Earnings Withdrawal - WD-89\",\"amount\":1000000,\"recipient\":\"RCP_dxsnwbkh5zee54x\",\"reference\":\"WD-89-1765265341\"}', '{\"status\":false,\"message\":\"Your balance is not enough to fulfil this request\",\"meta\":{\"nextStep\":\"Topup your Paystack Balance and try again.\"},\"type\":\"api_error\",\"code\":\"insufficient_balance\"}', 400, '{\"status\":false,\"message\":\"Your balance is not enough to fulfil this request\",\"meta\":{\"nextStep\":\"Topup your Paystack Balance and try again.\"},\"type\":\"api_error\",\"code\":\"insufficient_balance\"}', '2025-12-09 07:29:01', '2025-12-09 07:29:01'),
(82, 90, 46, 50000.00, NULL, 'RCP_534mc9ff21ca11p', '{\"source\":\"balance\",\"reason\":\"Prime Earnings Withdrawal - WD-90\",\"amount\":5000000,\"recipient\":\"RCP_534mc9ff21ca11p\",\"reference\":\"WD-90-1765265341\"}', '{\"status\":false,\"message\":\"Your balance is not enough to fulfil this request\",\"meta\":{\"nextStep\":\"Topup your Paystack Balance and try again.\"},\"type\":\"api_error\",\"code\":\"insufficient_balance\"}', 400, '{\"status\":false,\"message\":\"Your balance is not enough to fulfil this request\",\"meta\":{\"nextStep\":\"Topup your Paystack Balance and try again.\"},\"type\":\"api_error\",\"code\":\"insufficient_balance\"}', '2025-12-09 07:29:02', '2025-12-09 07:29:02'),
(83, 92, 47, 300.00, NULL, 'RCP_dxsnwbkh5zee54x', '{\"source\":\"balance\",\"reason\":\"Prime Earnings Withdrawal - WD-92\",\"amount\":30000,\"recipient\":\"RCP_dxsnwbkh5zee54x\",\"reference\":\"WD-92-1765265342\"}', '{\"status\":true,\"message\":\"Transfer has been queued\",\"data\":{\"transfersessionid\":[],\"transfertrials\":[],\"domain\":\"live\",\"amount\":30000,\"currency\":\"NGN\",\"reference\":\"WD-92-1765265342\",\"source\":\"balance\",\"source_details\":null,\"reason\":\"Prime Earnings Withdrawal - WD-92\",\"status\":\"pending\",\"failures\":null,\"transfer_code\":\"TRF_tp94mjiuehzn2csw\",\"titan_code\":null,\"transferred_at\":null,\"id\":926006677,\"integration\":1606789,\"request\":1162718694,\"recipient\":116524974,\"createdAt\":\"2025-12-09T07:29:02.000Z\",\"updatedAt\":\"2025-12-09T07:29:02.000Z\"}}', 200, '{\"status\":true,\"message\":\"Transfer has been queued\",\"data\":{\"transfersessionid\":[],\"transfertrials\":[],\"domain\":\"live\",\"amount\":30000,\"currency\":\"NGN\",\"reference\":\"WD-92-1765265342\",\"source\":\"balance\",\"source_details\":null,\"reason\":\"Prime Earnings Withdrawal - WD-92\",\"status\":\"pending\",\"failures\":null,\"transfer_code\":\"TRF_tp94mjiuehzn2csw\",\"titan_code\":null,\"transferred_at\":null,\"id\":926006677,\"integration\":1606789,\"request\":1162718694,\"recipient\":116524974,\"createdAt\":\"2025-12-09T07:29:02.000Z\",\"updatedAt\":\"2025-12-09T07:29:02.000Z\"}}', '2025-12-09 07:29:04', '2025-12-09 07:29:04'),
(84, 89, 47, 10000.00, NULL, 'RCP_dxsnwbkh5zee54x', '{\"source\":\"balance\",\"reason\":\"Prime Earnings Withdrawal - WD-89\",\"amount\":1000000,\"recipient\":\"RCP_dxsnwbkh5zee54x\",\"reference\":\"WD-89-1765275693\"}', '{\"status\":false,\"message\":\"Your balance is not enough to fulfil this request\",\"meta\":{\"nextStep\":\"Topup your Paystack Balance and try again.\"},\"type\":\"api_error\",\"code\":\"insufficient_balance\"}', 400, '{\"status\":false,\"message\":\"Your balance is not enough to fulfil this request\",\"meta\":{\"nextStep\":\"Topup your Paystack Balance and try again.\"},\"type\":\"api_error\",\"code\":\"insufficient_balance\"}', '2025-12-09 10:21:34', '2025-12-09 10:21:34'),
(85, 90, 46, 50000.00, NULL, 'RCP_534mc9ff21ca11p', '{\"source\":\"balance\",\"reason\":\"Prime Earnings Withdrawal - WD-90\",\"amount\":5000000,\"recipient\":\"RCP_534mc9ff21ca11p\",\"reference\":\"WD-90-1765275694\"}', '{\"status\":false,\"message\":\"Your balance is not enough to fulfil this request\",\"meta\":{\"nextStep\":\"Topup your Paystack Balance and try again.\"},\"type\":\"api_error\",\"code\":\"insufficient_balance\"}', 400, '{\"status\":false,\"message\":\"Your balance is not enough to fulfil this request\",\"meta\":{\"nextStep\":\"Topup your Paystack Balance and try again.\"},\"type\":\"api_error\",\"code\":\"insufficient_balance\"}', '2025-12-09 10:21:34', '2025-12-09 10:21:34'),
(86, 94, 1, 200.00, NULL, 'RCP_d8vwb0x3tor3a22', '{\"source\":\"balance\",\"reason\":\"Prime Earnings Withdrawal - WD-94\",\"amount\":20000,\"recipient\":\"RCP_d8vwb0x3tor3a22\",\"reference\":\"WD-94-1765275694\"}', '{\"status\":false,\"message\":\"Your balance is not enough to fulfil this request\",\"meta\":{\"nextStep\":\"Topup your Paystack Balance and try again.\"},\"type\":\"api_error\",\"code\":\"insufficient_balance\"}', 400, '{\"status\":false,\"message\":\"Your balance is not enough to fulfil this request\",\"meta\":{\"nextStep\":\"Topup your Paystack Balance and try again.\"},\"type\":\"api_error\",\"code\":\"insufficient_balance\"}', '2025-12-09 10:21:35', '2025-12-09 10:21:35'),
(87, 89, 47, 10000.00, NULL, 'RCP_dxsnwbkh5zee54x', '{\"source\":\"balance\",\"reason\":\"Prime Earnings Withdrawal - WD-89\",\"amount\":1000000,\"recipient\":\"RCP_dxsnwbkh5zee54x\",\"reference\":\"WD-89-1765370998\"}', '{\"status\":false,\"message\":\"Your balance is not enough to fulfil this request\",\"meta\":{\"nextStep\":\"Topup your Paystack Balance and try again.\"},\"type\":\"api_error\",\"code\":\"insufficient_balance\"}', 400, '{\"status\":false,\"message\":\"Your balance is not enough to fulfil this request\",\"meta\":{\"nextStep\":\"Topup your Paystack Balance and try again.\"},\"type\":\"api_error\",\"code\":\"insufficient_balance\"}', '2025-12-10 12:49:58', '2025-12-10 12:49:58'),
(88, 90, 46, 50000.00, NULL, 'RCP_534mc9ff21ca11p', '{\"source\":\"balance\",\"reason\":\"Prime Earnings Withdrawal - WD-90\",\"amount\":5000000,\"recipient\":\"RCP_534mc9ff21ca11p\",\"reference\":\"WD-90-1765370998\"}', '{\"status\":false,\"message\":\"Your balance is not enough to fulfil this request\",\"meta\":{\"nextStep\":\"Topup your Paystack Balance and try again.\"},\"type\":\"api_error\",\"code\":\"insufficient_balance\"}', 400, '{\"status\":false,\"message\":\"Your balance is not enough to fulfil this request\",\"meta\":{\"nextStep\":\"Topup your Paystack Balance and try again.\"},\"type\":\"api_error\",\"code\":\"insufficient_balance\"}', '2025-12-10 12:49:58', '2025-12-10 12:49:58'),
(89, 94, 1, 200.00, NULL, 'RCP_d8vwb0x3tor3a22', '{\"source\":\"balance\",\"reason\":\"Prime Earnings Withdrawal - WD-94\",\"amount\":20000,\"recipient\":\"RCP_d8vwb0x3tor3a22\",\"reference\":\"WD-94-1765370998\"}', '{\"status\":true,\"message\":\"Transfer has been queued\",\"data\":{\"transfersessionid\":[],\"transfertrials\":[],\"domain\":\"live\",\"amount\":20000,\"currency\":\"NGN\",\"reference\":\"WD-94-1765370998\",\"source\":\"balance\",\"source_details\":null,\"reason\":\"Prime Earnings Withdrawal - WD-94\",\"status\":\"pending\",\"failures\":null,\"transfer_code\":\"TRF_6ite98fd5dmz2msq\",\"titan_code\":null,\"transferred_at\":null,\"id\":926519132,\"integration\":1606789,\"request\":1163432370,\"recipient\":116473254,\"createdAt\":\"2025-12-10T12:49:59.000Z\",\"updatedAt\":\"2025-12-10T12:49:59.000Z\"}}', 200, '{\"status\":true,\"message\":\"Transfer has been queued\",\"data\":{\"transfersessionid\":[],\"transfertrials\":[],\"domain\":\"live\",\"amount\":20000,\"currency\":\"NGN\",\"reference\":\"WD-94-1765370998\",\"source\":\"balance\",\"source_details\":null,\"reason\":\"Prime Earnings Withdrawal - WD-94\",\"status\":\"pending\",\"failures\":null,\"transfer_code\":\"TRF_6ite98fd5dmz2msq\",\"titan_code\":null,\"transferred_at\":null,\"id\":926519132,\"integration\":1606789,\"request\":1163432370,\"recipient\":116473254,\"createdAt\":\"2025-12-10T12:49:59.000Z\",\"updatedAt\":\"2025-12-10T12:49:59.000Z\"}}', '2025-12-10 12:50:00', '2025-12-10 12:50:00'),
(90, 96, 47, 200.00, NULL, 'RCP_dxsnwbkh5zee54x', '{\"source\":\"balance\",\"reason\":\"Prime Earnings Withdrawal - WD-96\",\"amount\":20000,\"recipient\":\"RCP_dxsnwbkh5zee54x\",\"reference\":\"WD-96-1765371001\"}', '{\"status\":true,\"message\":\"Transfer has been queued\",\"data\":{\"transfersessionid\":[],\"transfertrials\":[],\"domain\":\"live\",\"amount\":20000,\"currency\":\"NGN\",\"reference\":\"WD-96-1765371001\",\"source\":\"balance\",\"source_details\":null,\"reason\":\"Prime Earnings Withdrawal - WD-96\",\"status\":\"pending\",\"failures\":null,\"transfer_code\":\"TRF_kavc0ejgjtgkar3b\",\"titan_code\":null,\"transferred_at\":null,\"id\":926519146,\"integration\":1606789,\"request\":1163432386,\"recipient\":116524974,\"createdAt\":\"2025-12-10T12:50:02.000Z\",\"updatedAt\":\"2025-12-10T12:50:02.000Z\"}}', 200, '{\"status\":true,\"message\":\"Transfer has been queued\",\"data\":{\"transfersessionid\":[],\"transfertrials\":[],\"domain\":\"live\",\"amount\":20000,\"currency\":\"NGN\",\"reference\":\"WD-96-1765371001\",\"source\":\"balance\",\"source_details\":null,\"reason\":\"Prime Earnings Withdrawal - WD-96\",\"status\":\"pending\",\"failures\":null,\"transfer_code\":\"TRF_kavc0ejgjtgkar3b\",\"titan_code\":null,\"transferred_at\":null,\"id\":926519146,\"integration\":1606789,\"request\":1163432386,\"recipient\":116524974,\"createdAt\":\"2025-12-10T12:50:02.000Z\",\"updatedAt\":\"2025-12-10T12:50:02.000Z\"}}', '2025-12-10 12:50:05', '2025-12-10 12:50:05'),
(91, 89, 47, 10000.00, NULL, 'RCP_dxsnwbkh5zee54x', '{\"source\":\"balance\",\"reason\":\"Prime Earnings Withdrawal - WD-89\",\"amount\":1000000,\"recipient\":\"RCP_dxsnwbkh5zee54x\",\"reference\":\"WD-89-1765372472\"}', '{\"status\":false,\"message\":\"Your balance is not enough to fulfil this request\",\"meta\":{\"nextStep\":\"Topup your Paystack Balance and try again.\"},\"type\":\"api_error\",\"code\":\"insufficient_balance\"}', 400, '{\"status\":false,\"message\":\"Your balance is not enough to fulfil this request\",\"meta\":{\"nextStep\":\"Topup your Paystack Balance and try again.\"},\"type\":\"api_error\",\"code\":\"insufficient_balance\"}', '2025-12-10 13:14:33', '2025-12-10 13:14:33'),
(92, 90, 46, 50000.00, NULL, 'RCP_534mc9ff21ca11p', '{\"source\":\"balance\",\"reason\":\"Prime Earnings Withdrawal - WD-90\",\"amount\":5000000,\"recipient\":\"RCP_534mc9ff21ca11p\",\"reference\":\"WD-90-1765372473\"}', '{\"status\":false,\"message\":\"Your balance is not enough to fulfil this request\",\"meta\":{\"nextStep\":\"Topup your Paystack Balance and try again.\"},\"type\":\"api_error\",\"code\":\"insufficient_balance\"}', 400, '{\"status\":false,\"message\":\"Your balance is not enough to fulfil this request\",\"meta\":{\"nextStep\":\"Topup your Paystack Balance and try again.\"},\"type\":\"api_error\",\"code\":\"insufficient_balance\"}', '2025-12-10 13:14:33', '2025-12-10 13:14:33'),
(93, 97, 54, 200.00, NULL, 'RCP_d581789pmena3gn', '{\"source\":\"balance\",\"reason\":\"Prime Earnings Withdrawal - WD-97\",\"amount\":20000,\"recipient\":\"RCP_d581789pmena3gn\",\"reference\":\"WD-97-1765372473\"}', '{\"status\":true,\"message\":\"Transfer has been queued\",\"data\":{\"transfersessionid\":[],\"transfertrials\":[],\"domain\":\"live\",\"amount\":20000,\"currency\":\"NGN\",\"reference\":\"WD-97-1765372473\",\"source\":\"balance\",\"source_details\":null,\"reason\":\"Prime Earnings Withdrawal - WD-97\",\"status\":\"pending\",\"failures\":null,\"transfer_code\":\"TRF_g5ujdm2oh788v9dc\",\"titan_code\":null,\"transferred_at\":null,\"id\":926525923,\"integration\":1606789,\"request\":1163441289,\"recipient\":116480867,\"createdAt\":\"2025-12-10T13:14:34.000Z\",\"updatedAt\":\"2025-12-10T13:14:34.000Z\"}}', 200, '{\"status\":true,\"message\":\"Transfer has been queued\",\"data\":{\"transfersessionid\":[],\"transfertrials\":[],\"domain\":\"live\",\"amount\":20000,\"currency\":\"NGN\",\"reference\":\"WD-97-1765372473\",\"source\":\"balance\",\"source_details\":null,\"reason\":\"Prime Earnings Withdrawal - WD-97\",\"status\":\"pending\",\"failures\":null,\"transfer_code\":\"TRF_g5ujdm2oh788v9dc\",\"titan_code\":null,\"transferred_at\":null,\"id\":926525923,\"integration\":1606789,\"request\":1163441289,\"recipient\":116480867,\"createdAt\":\"2025-12-10T13:14:34.000Z\",\"updatedAt\":\"2025-12-10T13:14:34.000Z\"}}', '2025-12-10 13:14:40', '2025-12-10 13:14:40'),
(94, 98, 47, 200.00, NULL, 'RCP_dxsnwbkh5zee54x', '{\"source\":\"balance\",\"reason\":\"Prime Earnings Withdrawal - WD-98\",\"amount\":20000,\"recipient\":\"RCP_dxsnwbkh5zee54x\",\"reference\":\"WD-98-1765493965\"}', '{\"status\":true,\"message\":\"Transfer has been queued\",\"data\":{\"transfersessionid\":[],\"transfertrials\":[],\"domain\":\"live\",\"amount\":20000,\"currency\":\"NGN\",\"reference\":\"WD-98-1765493965\",\"source\":\"balance\",\"source_details\":null,\"reason\":\"Prime Earnings Withdrawal - WD-98\",\"status\":\"pending\",\"failures\":null,\"transfer_code\":\"TRF_hdbfoc5yh5xjcat3\",\"titan_code\":null,\"transferred_at\":null,\"id\":927170582,\"integration\":1606789,\"request\":1164298115,\"recipient\":116524974,\"createdAt\":\"2025-12-11T22:59:26.000Z\",\"updatedAt\":\"2025-12-11T22:59:26.000Z\"}}', 200, '{\"status\":true,\"message\":\"Transfer has been queued\",\"data\":{\"transfersessionid\":[],\"transfertrials\":[],\"domain\":\"live\",\"amount\":20000,\"currency\":\"NGN\",\"reference\":\"WD-98-1765493965\",\"source\":\"balance\",\"source_details\":null,\"reason\":\"Prime Earnings Withdrawal - WD-98\",\"status\":\"pending\",\"failures\":null,\"transfer_code\":\"TRF_hdbfoc5yh5xjcat3\",\"titan_code\":null,\"transferred_at\":null,\"id\":927170582,\"integration\":1606789,\"request\":1164298115,\"recipient\":116524974,\"createdAt\":\"2025-12-11T22:59:26.000Z\",\"updatedAt\":\"2025-12-11T22:59:26.000Z\"}}', '2025-12-11 22:59:28', '2025-12-11 22:59:28'),
(95, 99, 54, 200.00, NULL, 'RCP_d581789pmena3gn', '{\"source\":\"balance\",\"reason\":\"Prime Earnings Withdrawal - WD-99\",\"amount\":20000,\"recipient\":\"RCP_d581789pmena3gn\",\"reference\":\"WD-99-1765494303\"}', '{\"status\":true,\"message\":\"Transfer has been queued\",\"data\":{\"transfersessionid\":[],\"transfertrials\":[],\"domain\":\"live\",\"amount\":20000,\"currency\":\"NGN\",\"reference\":\"WD-99-1765494303\",\"source\":\"balance\",\"source_details\":null,\"reason\":\"Prime Earnings Withdrawal - WD-99\",\"status\":\"pending\",\"failures\":null,\"transfer_code\":\"TRF_1ui6s5dgv88sm1xn\",\"titan_code\":null,\"transferred_at\":null,\"id\":927172932,\"integration\":1606789,\"request\":1164302200,\"recipient\":116480867,\"createdAt\":\"2025-12-11T23:05:04.000Z\",\"updatedAt\":\"2025-12-11T23:05:04.000Z\"}}', 200, '{\"status\":true,\"message\":\"Transfer has been queued\",\"data\":{\"transfersessionid\":[],\"transfertrials\":[],\"domain\":\"live\",\"amount\":20000,\"currency\":\"NGN\",\"reference\":\"WD-99-1765494303\",\"source\":\"balance\",\"source_details\":null,\"reason\":\"Prime Earnings Withdrawal - WD-99\",\"status\":\"pending\",\"failures\":null,\"transfer_code\":\"TRF_1ui6s5dgv88sm1xn\",\"titan_code\":null,\"transferred_at\":null,\"id\":927172932,\"integration\":1606789,\"request\":1164302200,\"recipient\":116480867,\"createdAt\":\"2025-12-11T23:05:04.000Z\",\"updatedAt\":\"2025-12-11T23:05:04.000Z\"}}', '2025-12-11 23:05:07', '2025-12-11 23:05:07'),
(96, 100, 46, 6000.00, NULL, 'RCP_534mc9ff21ca11p', '{\"source\":\"balance\",\"reason\":\"Prime Earnings Withdrawal - WD-100\",\"amount\":600000,\"recipient\":\"RCP_534mc9ff21ca11p\",\"reference\":\"WD-100-1765543803\"}', '{\"status\":false,\"message\":\"Your balance is not enough to fulfil this request\",\"meta\":{\"nextStep\":\"Topup your Paystack Balance and try again.\"},\"type\":\"api_error\",\"code\":\"insufficient_balance\"}', 400, '{\"status\":false,\"message\":\"Your balance is not enough to fulfil this request\",\"meta\":{\"nextStep\":\"Topup your Paystack Balance and try again.\"},\"type\":\"api_error\",\"code\":\"insufficient_balance\"}', '2025-12-12 12:50:04', '2025-12-12 12:50:04'),
(97, 100, 46, 6000.00, NULL, 'RCP_534mc9ff21ca11p', '{\"source\":\"balance\",\"reason\":\"Prime Earnings Withdrawal - WD-100\",\"amount\":600000,\"recipient\":\"RCP_534mc9ff21ca11p\",\"reference\":\"WD-100-1765690714\"}', '{\"status\":false,\"message\":\"Your balance is not enough to fulfil this request\",\"meta\":{\"nextStep\":\"Topup your Paystack Balance and try again.\"},\"type\":\"api_error\",\"code\":\"insufficient_balance\"}', 400, '{\"status\":false,\"message\":\"Your balance is not enough to fulfil this request\",\"meta\":{\"nextStep\":\"Topup your Paystack Balance and try again.\"},\"type\":\"api_error\",\"code\":\"insufficient_balance\"}', '2025-12-14 05:38:34', '2025-12-14 05:38:34'),
(98, 102, 54, 200.00, NULL, 'RCP_d581789pmena3gn', '{\"source\":\"balance\",\"reason\":\"Prime Earnings Withdrawal - WD-102\",\"amount\":20000,\"recipient\":\"RCP_d581789pmena3gn\",\"reference\":\"WD-102-1765690714\"}', '{\"status\":true,\"message\":\"Transfer has been queued\",\"data\":{\"transfersessionid\":[],\"transfertrials\":[],\"domain\":\"live\",\"amount\":20000,\"currency\":\"NGN\",\"reference\":\"WD-102-1765690714\",\"source\":\"balance\",\"source_details\":null,\"reason\":\"Prime Earnings Withdrawal - WD-102\",\"status\":\"pending\",\"failures\":null,\"transfer_code\":\"TRF_d5t85ub23lmkxi7m\",\"titan_code\":null,\"transferred_at\":null,\"id\":928402044,\"integration\":1606789,\"request\":1165977605,\"recipient\":116480867,\"createdAt\":\"2025-12-14T05:38:35.000Z\",\"updatedAt\":\"2025-12-14T05:38:35.000Z\"}}', 200, '{\"status\":true,\"message\":\"Transfer has been queued\",\"data\":{\"transfersessionid\":[],\"transfertrials\":[],\"domain\":\"live\",\"amount\":20000,\"currency\":\"NGN\",\"reference\":\"WD-102-1765690714\",\"source\":\"balance\",\"source_details\":null,\"reason\":\"Prime Earnings Withdrawal - WD-102\",\"status\":\"pending\",\"failures\":null,\"transfer_code\":\"TRF_d5t85ub23lmkxi7m\",\"titan_code\":null,\"transferred_at\":null,\"id\":928402044,\"integration\":1606789,\"request\":1165977605,\"recipient\":116480867,\"createdAt\":\"2025-12-14T05:38:35.000Z\",\"updatedAt\":\"2025-12-14T05:38:35.000Z\"}}', '2025-12-14 05:38:37', '2025-12-14 05:38:37'),
(99, 100, 46, 6000.00, NULL, 'RCP_534mc9ff21ca11p', '{\"source\":\"balance\",\"reason\":\"Prime Earnings Withdrawal - WD-100\",\"amount\":600000,\"recipient\":\"RCP_534mc9ff21ca11p\",\"reference\":\"WD-100-1765716181\"}', '{\"status\":false,\"message\":\"Your balance is not enough to fulfil this request\",\"meta\":{\"nextStep\":\"Topup your Paystack Balance and try again.\"},\"type\":\"api_error\",\"code\":\"insufficient_balance\"}', 400, '{\"status\":false,\"message\":\"Your balance is not enough to fulfil this request\",\"meta\":{\"nextStep\":\"Topup your Paystack Balance and try again.\"},\"type\":\"api_error\",\"code\":\"insufficient_balance\"}', '2025-12-14 12:43:01', '2025-12-14 12:43:01'),
(100, 103, 73, 300.00, NULL, 'RCP_eqkd6i1ia4hovjy', '{\"source\":\"balance\",\"reason\":\"Prime Earnings Withdrawal - WD-103\",\"amount\":30000,\"recipient\":\"RCP_eqkd6i1ia4hovjy\",\"reference\":\"WD-103-1765716182\"}', '{\"status\":true,\"message\":\"Transfer has been queued\",\"data\":{\"transfersessionid\":[],\"transfertrials\":[],\"domain\":\"live\",\"amount\":30000,\"currency\":\"NGN\",\"reference\":\"WD-103-1765716182\",\"source\":\"balance\",\"source_details\":null,\"reason\":\"Prime Earnings Withdrawal - WD-103\",\"status\":\"pending\",\"failures\":null,\"transfer_code\":\"TRF_e2x7oys9texaqg4u\",\"titan_code\":null,\"transferred_at\":null,\"id\":928593220,\"integration\":1606789,\"request\":1166182265,\"recipient\":117483505,\"createdAt\":\"2025-12-14T12:43:03.000Z\",\"updatedAt\":\"2025-12-14T12:43:03.000Z\"}}', 200, '{\"status\":true,\"message\":\"Transfer has been queued\",\"data\":{\"transfersessionid\":[],\"transfertrials\":[],\"domain\":\"live\",\"amount\":30000,\"currency\":\"NGN\",\"reference\":\"WD-103-1765716182\",\"source\":\"balance\",\"source_details\":null,\"reason\":\"Prime Earnings Withdrawal - WD-103\",\"status\":\"pending\",\"failures\":null,\"transfer_code\":\"TRF_e2x7oys9texaqg4u\",\"titan_code\":null,\"transferred_at\":null,\"id\":928593220,\"integration\":1606789,\"request\":1166182265,\"recipient\":117483505,\"createdAt\":\"2025-12-14T12:43:03.000Z\",\"updatedAt\":\"2025-12-14T12:43:03.000Z\"}}', '2025-12-14 12:43:06', '2025-12-14 12:43:06'),
(101, 100, 46, 6000.00, NULL, 'RCP_534mc9ff21ca11p', '{\"source\":\"balance\",\"reason\":\"Prime Earnings Withdrawal - WD-100\",\"amount\":600000,\"recipient\":\"RCP_534mc9ff21ca11p\",\"reference\":\"WD-100-1765716367\"}', '{\"status\":false,\"message\":\"Your balance is not enough to fulfil this request\",\"meta\":{\"nextStep\":\"Topup your Paystack Balance and try again.\"},\"type\":\"api_error\",\"code\":\"insufficient_balance\"}', 400, '{\"status\":false,\"message\":\"Your balance is not enough to fulfil this request\",\"meta\":{\"nextStep\":\"Topup your Paystack Balance and try again.\"},\"type\":\"api_error\",\"code\":\"insufficient_balance\"}', '2025-12-14 12:46:07', '2025-12-14 12:46:07'),
(102, 104, 73, 200.00, NULL, 'RCP_eqkd6i1ia4hovjy', '{\"source\":\"balance\",\"reason\":\"Prime Earnings Withdrawal - WD-104\",\"amount\":20000,\"recipient\":\"RCP_eqkd6i1ia4hovjy\",\"reference\":\"WD-104-1765716367\"}', '{\"status\":true,\"message\":\"Transfer has been queued\",\"data\":{\"transfersessionid\":[],\"transfertrials\":[],\"domain\":\"live\",\"amount\":20000,\"currency\":\"NGN\",\"reference\":\"WD-104-1765716367\",\"source\":\"balance\",\"source_details\":null,\"reason\":\"Prime Earnings Withdrawal - WD-104\",\"status\":\"pending\",\"failures\":null,\"transfer_code\":\"TRF_i6tuzb3s4siwaqxe\",\"titan_code\":null,\"transferred_at\":null,\"id\":928594609,\"integration\":1606789,\"request\":1166183763,\"recipient\":117483505,\"createdAt\":\"2025-12-14T12:46:08.000Z\",\"updatedAt\":\"2025-12-14T12:46:08.000Z\"}}', 200, '{\"status\":true,\"message\":\"Transfer has been queued\",\"data\":{\"transfersessionid\":[],\"transfertrials\":[],\"domain\":\"live\",\"amount\":20000,\"currency\":\"NGN\",\"reference\":\"WD-104-1765716367\",\"source\":\"balance\",\"source_details\":null,\"reason\":\"Prime Earnings Withdrawal - WD-104\",\"status\":\"pending\",\"failures\":null,\"transfer_code\":\"TRF_i6tuzb3s4siwaqxe\",\"titan_code\":null,\"transferred_at\":null,\"id\":928594609,\"integration\":1606789,\"request\":1166183763,\"recipient\":117483505,\"createdAt\":\"2025-12-14T12:46:08.000Z\",\"updatedAt\":\"2025-12-14T12:46:08.000Z\"}}', '2025-12-14 12:46:10', '2025-12-14 12:46:10');

-- --------------------------------------------------------

--
-- Table structure for table `pending_payments`
--

CREATE TABLE `pending_payments` (
  `id` int NOT NULL,
  `pending_ref` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` int NOT NULL,
  `payment_type` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'task_post',
  `title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `platform_key` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `task_url` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `participants` int DEFAULT '0',
  `total_cost` decimal(10,2) DEFAULT '0.00',
  `amount_expected` decimal(10,2) DEFAULT '0.00',
  `status` enum('pending','paid','failed') COLLATE utf8mb4_unicode_ci DEFAULT 'pending',
  `korapay_reference` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pending_payments`
--

INSERT INTO `pending_payments` (`id`, `pending_ref`, `user_id`, `payment_type`, `title`, `description`, `platform_key`, `task_url`, `participants`, `total_cost`, `amount_expected`, `status`, `korapay_reference`, `created_at`, `updated_at`) VALUES
(1, 'PENDING-TASK-1-1765468453-5611', 1, 'task_post', 'Testing Kora Pay', 'testing Kora Pay', 'instagram', 'https://instagram.com', 10, 350.00, 350.00, 'pending', 'Array', '2025-12-11 15:54:13', '2025-12-11 15:54:14');

-- --------------------------------------------------------

--
-- Table structure for table `platform_video_prices`
--

CREATE TABLE `platform_video_prices` (
  `id` int NOT NULL,
  `platform` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price_per_10_participants` decimal(10,2) NOT NULL,
  `effective_from` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `is_active` tinyint(1) DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `platform_video_prices`
--

INSERT INTO `platform_video_prices` (`id`, `platform`, `price_per_10_participants`, `effective_from`, `is_active`) VALUES
(1, 'youtube', 400.00, '2025-12-14 19:37:24', 1),
(2, 'tiktok', 320.00, '2025-12-14 19:37:24', 1),
(3, 'instagram', 350.00, '2025-12-14 19:37:24', 1),
(4, 'facebook', 350.00, '2025-12-14 19:37:24', 1),
(5, 'twitter', 380.00, '2025-12-14 19:37:24', 1),
(6, 'linkedin', 350.00, '2025-12-14 19:37:24', 1);

-- --------------------------------------------------------

--
-- Table structure for table `plinko_games`
--

CREATE TABLE `plinko_games` (
  `id` int NOT NULL,
  `user_id` int NOT NULL,
  `bet_amount` decimal(10,2) NOT NULL,
  `win_amount` decimal(10,2) NOT NULL,
  `multiplier` decimal(5,2) NOT NULL,
  `is_free_play` tinyint(1) DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Stand-in structure for view `plinko_leaderboard`
-- (See below for the actual view)
--
CREATE TABLE `plinko_leaderboard` (
`biggest_win` decimal(10,2)
,`full_name` varchar(100)
,`id` int
,`profile_picture` varchar(255)
,`total_profit` decimal(33,2)
,`total_wins` bigint
,`username` varchar(50)
);

-- --------------------------------------------------------

--
-- Table structure for table `premium_payments`
--

CREATE TABLE `premium_payments` (
  `id` int NOT NULL,
  `user_id` int NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `payment_method` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payment_reference` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('pending','completed','failed') COLLATE utf8mb4_unicode_ci DEFAULT 'pending',
  `referrer_commission` decimal(10,2) DEFAULT '0.00',
  `company_amount` decimal(10,2) DEFAULT '0.00',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `premium_payments`
--

INSERT INTO `premium_payments` (`id`, `user_id`, `amount`, `payment_method`, `payment_reference`, `status`, `referrer_commission`, `company_amount`, `created_at`) VALUES
(23, 50, 1500.00, 'paystack', 'PREMIUM_UPGRADE-s94e3bty26', 'completed', 500.00, 1000.00, '2025-11-21 11:12:16'),
(24, 54, 1500.00, 'paystack', 'PREMIUM_UPGRADE-1dhhubcpwq8', 'completed', 500.00, 1000.00, '2025-11-21 20:23:29'),
(25, 51, 1500.00, 'paystack', 'PREMIUM_UPGRADE-su6nhcfughl', 'completed', 500.00, 1000.00, '2025-11-22 06:29:55'),
(26, 53, 1500.00, 'paystack', 'PREMIUM_UPGRADE-5k58t5m6mzs', 'completed', 500.00, 1000.00, '2025-11-22 08:04:20'),
(27, 59, 1500.00, 'paystack', 'PREMIUM_UPGRADE-tqkxlqnl8mc', 'completed', 500.00, 1000.00, '2025-11-25 07:24:51'),
(28, 58, 1500.00, 'paystack', 'PREMIUM_UPGRADE-p5fb1foqb6k', 'completed', 500.00, 1000.00, '2025-11-25 07:26:43'),
(29, 60, 1500.00, 'paystack', 'PREMIUM_UPGRADE-3g8d5nhbths', 'completed', 500.00, 1000.00, '2025-11-25 08:21:28'),
(30, 67, 1500.00, 'paystack', 'PREMIUM_UPGRADE-my35qwqe89k', 'completed', 500.00, 1000.00, '2025-12-03 08:57:35'),
(31, 64, 1500.00, 'paystack', 'PREMIUM_UPGRADE-ewo3mppnchh', 'completed', 500.00, 1000.00, '2025-12-04 20:24:53'),
(32, 64, 1500.00, 'paystack', 'PREMIUM_UPGRADE-etnbazceadn', 'completed', 500.00, 1000.00, '2025-12-04 20:42:31'),
(33, 1, 1500.00, 'paystack', 'EARNOVA-premium_upgrade-1-1765455418-5195', 'completed', 500.00, 1000.00, '2025-12-11 12:17:18'),
(34, 1, 1500.00, 'paystack', 'EARNOVA-premium_upgrade-1-1765468251-1265', 'completed', 500.00, 1000.00, '2025-12-11 15:51:19'),
(35, 1, 1500.00, 'paystack', 'EARNOVA-premium_upgrade-1-1765468251-1265', 'completed', 500.00, 1000.00, '2025-12-11 15:51:19');

-- --------------------------------------------------------

--
-- Table structure for table `referral_commissions`
--

CREATE TABLE `referral_commissions` (
  `id` int NOT NULL,
  `referrer_id` int NOT NULL,
  `referred_user_id` int NOT NULL,
  `commission_type` enum('signup','premium_upgrade','premium_plus_upgrade') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `commission_amount` decimal(10,2) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `referral_commissions`
--

INSERT INTO `referral_commissions` (`id`, `referrer_id`, `referred_user_id`, `commission_type`, `commission_amount`, `created_at`, `description`) VALUES
(25, 47, 50, 'premium_upgrade', 500.00, '2025-11-21 11:12:16', 'Franklin# upgraded to Premium'),
(26, 47, 50, 'premium_plus_upgrade', 500.00, '2025-11-21 12:19:46', 'Franklin# upgraded to Premium Plus plan'),
(27, 47, 54, 'premium_upgrade', 500.00, '2025-11-21 20:23:29', 'Cat020 upgraded to Premium'),
(30, 47, 51, '', 0.00, '2025-11-22 06:29:55', 'Word upgraded to Premium'),
(31, 47, 51, '', 0.00, '2025-11-22 06:54:36', 'Word upgraded to Premium Plus plan'),
(32, 46, 53, '', 0.00, '2025-11-22 08:04:20', 'Mechack001 upgraded to Premium'),
(33, 47, 54, '', 0.00, '2025-11-23 15:40:06', 'Cat020 upgraded to Premium Plus plan'),
(34, 46, 53, '', 0.00, '2025-11-23 16:06:28', 'Mechack001 upgraded to Premium Plus plan'),
(35, 58, 59, '', 0.00, '2025-11-25 07:43:54', 'Busy upgraded to Premium Plus plan'),
(36, 1, 61, '', 0.00, '2025-11-27 18:02:40', '@Ebere123 upgraded to Premium Plus plan'),
(37, 1, 62, '', 0.00, '2025-11-27 18:30:25', 'testingpremiumPlus upgraded to Premium Plus plan'),
(38, 46, 63, '', 0.00, '2025-11-27 20:06:43', 'King1 upgraded to Premium Plus plan'),
(39, 1, 64, '', 0.00, '2025-11-28 10:56:21', 'Stream&Earn upgraded to Premium Plus plan'),
(40, 1, 64, '', 0.00, '2025-11-29 19:45:09', 'Stream&Earn upgraded to Premium Plus plan'),
(41, 47, 54, '', 0.00, '2025-12-02 14:36:11', 'Cat020 upgraded to Premium Plus plan'),
(42, 47, 54, '', 0.00, '2025-12-02 14:44:05', 'Cat020 upgraded to Premium Plus plan'),
(43, 47, 67, '', 0.00, '2025-12-03 08:57:35', 'Kenechukwu upgraded to Premium'),
(44, 47, 67, '', 0.00, '2025-12-03 09:02:58', 'Kenechukwu upgraded to Premium Plus plan'),
(45, 47, 69, '', 0.00, '2025-12-03 21:24:03', 'Karen upgraded to Premium Plus plan'),
(46, 1, 64, '', 0.00, '2025-12-04 20:24:53', 'Stream&Earn upgraded to Premium'),
(47, 1, 64, 'premium_plus_upgrade', 1000.00, '2025-12-04 20:37:17', 'Stream&Earn upgraded to Premium Plus plan'),
(48, 1, 64, 'premium_upgrade', 500.00, '2025-12-04 20:42:31', 'Stream&Earn upgraded to Premium'),
(49, 47, 54, 'premium_plus_upgrade', 1000.00, '2025-12-05 06:03:04', 'Cat020 upgraded to Premium Plus plan'),
(50, 47, 54, 'premium_plus_upgrade', 1000.00, '2025-12-12 12:49:13', 'Cat020 upgraded to Premium Plus plan');

-- --------------------------------------------------------

--
-- Table structure for table `skills`
--

CREATE TABLE `skills` (
  `id` int NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `professor_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `external_link` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image_url` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `promo_badge` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `active_hours` int DEFAULT NULL COMMENT 'Hours the skill is active (e.g., 2, 3, etc.)',
  `clicks` int DEFAULT '0',
  `is_active` tinyint(1) DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `skills`
--

INSERT INTO `skills` (`id`, `title`, `description`, `professor_name`, `external_link`, `image_url`, `promo_badge`, `active_hours`, `clicks`, `is_active`, `created_at`, `updated_at`) VALUES
(1, 'Advanced Web development Learning', 'Obodo Learning, New Learning Unlocked, Potentials', 'John EkwuEme', 'https://earnova.org', 'uploads/skills/skill_1760611122_68f0cb3231e5c.jpeg', 'HOT', 8, 19, 1, '2025-10-16 10:38:42', '2025-12-12 08:43:00'),
(2, 'Testing Admin Skill Require', 'Testing Admin Skill Require', 'Testing Professor', 'https://earnova-digital-hub.com', 'uploads/skills/skill_1764424340_692afa9499f0c.jpeg', 'LIMITED', 30, 4, 1, '2025-11-29 13:52:20', '2025-12-12 08:42:52');

-- --------------------------------------------------------

--
-- Table structure for table `skill_clicks`
--

CREATE TABLE `skill_clicks` (
  `id` int NOT NULL,
  `skill_id` int NOT NULL,
  `user_id` int NOT NULL,
  `clicked_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `skill_clicks`
--

INSERT INTO `skill_clicks` (`id`, `skill_id`, `user_id`, `clicked_at`) VALUES
(17, 1, 51, '2025-11-22 06:42:33'),
(19, 2, 46, '2025-11-29 16:52:38'),
(20, 2, 54, '2025-12-01 07:52:18'),
(21, 2, 63, '2025-12-01 17:33:36'),
(22, 2, 47, '2025-12-12 08:42:52'),
(23, 1, 47, '2025-12-12 08:43:00');

-- --------------------------------------------------------

--
-- Table structure for table `spin_win_games`
--

CREATE TABLE `spin_win_games` (
  `id` int NOT NULL,
  `user_id` int NOT NULL,
  `bet_amount` decimal(10,2) NOT NULL,
  `multiplier` decimal(5,2) NOT NULL,
  `win_amount` decimal(10,2) NOT NULL,
  `is_free_play` tinyint(1) DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `spin_win_stats`
--

CREATE TABLE `spin_win_stats` (
  `user_id` int NOT NULL,
  `total_spins` int DEFAULT '0',
  `total_wins` int DEFAULT '0',
  `total_bet` decimal(10,2) DEFAULT '0.00',
  `total_won` decimal(10,2) DEFAULT '0.00',
  `total_profit` decimal(10,2) DEFAULT '0.00',
  `biggest_win` decimal(10,2) DEFAULT '0.00',
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `stream_ads_earnings`
--

CREATE TABLE `stream_ads_earnings` (
  `id` int NOT NULL,
  `user_id` int NOT NULL,
  `track_id` varchar(100) NOT NULL,
  `track_title` varchar(255) NOT NULL,
  `proof_email` varchar(255) NOT NULL,
  `stream_duration` int NOT NULL,
  `completion_percentage` decimal(5,2) NOT NULL,
  `payout_amount` decimal(10,2) DEFAULT '0.00',
  `is_eligible` tinyint(1) DEFAULT '0',
  `payout_status` enum('pending','paid','rejected') DEFAULT 'pending',
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text,
  `verified_at` timestamp NULL DEFAULT NULL,
  `streamed_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `stream_ads_logs`
--

CREATE TABLE `stream_ads_logs` (
  `id` int NOT NULL,
  `user_id` int NOT NULL,
  `track_id` varchar(100) NOT NULL,
  `event_type` enum('start','progress','complete','visit_link','verify') DEFAULT 'start',
  `stream_duration` int DEFAULT '0',
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `stream_ad_verified_emails`
--

CREATE TABLE `stream_ad_verified_emails` (
  `id` int NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `verified_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `track_id` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` int DEFAULT NULL,
  `username` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `stream_ad_verified_emails`
--

INSERT INTO `stream_ad_verified_emails` (`id`, `email`, `verified_at`, `track_id`, `user_id`, `username`) VALUES
(14, 'steveneloit122@gmail.com', '2025-12-02 15:24:19', 'track_1764344572_6929c2fc5cb01', 1, 'Obodonwoke'),
(15, 'steveneloit12@gmail.com', '2025-12-02 15:33:07', 'track_1764344572_6929c2fc5cb01', 64, 'Stream&Earn'),
(16, 'karinayuken@gmail.com', '2025-12-08 11:14:25', 'track_1764344572_6929c2fc5cb01', 47, 'Yuken92');

-- --------------------------------------------------------

--
-- Table structure for table `stream_daily_stats`
--

CREATE TABLE `stream_daily_stats` (
  `id` int NOT NULL,
  `user_id` int NOT NULL,
  `stream_date` date NOT NULL,
  `total_streams` int DEFAULT '0',
  `total_payouts` decimal(10,2) DEFAULT '0.00',
  `eligible_streams` int DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `stream_daily_stats`
--

INSERT INTO `stream_daily_stats` (`id`, `user_id`, `stream_date`, `total_streams`, `total_payouts`, `eligible_streams`, `created_at`, `updated_at`) VALUES
(1, 9, '2025-10-16', 1, 200.00, 1, '2025-10-16 08:14:40', '2025-10-16 08:14:40'),
(2, 1, '2025-10-17', 1, 200.00, 1, '2025-10-17 19:27:34', '2025-10-17 19:27:34'),
(3, 8, '2025-10-20', 1, 200.00, 1, '2025-10-20 16:44:19', '2025-10-20 16:44:19'),
(4, 12, '2025-11-09', 1, 200.00, 1, '2025-11-09 09:10:53', '2025-11-09 09:10:53'),
(5, 35, '2025-11-09', 1, 700.00, 1, '2025-11-09 10:13:50', '2025-11-09 10:13:50'),
(6, 39, '2025-11-12', 1, 700.00, 1, '2025-11-12 11:55:54', '2025-11-12 11:55:54'),
(7, 21, '2025-11-13', 2, 1400.00, 2, '2025-11-13 13:01:02', '2025-11-13 13:03:43'),
(9, 39, '2025-11-13', 1, 700.00, 1, '2025-11-13 13:52:05', '2025-11-13 13:52:05'),
(10, 2, '2025-11-20', 1, 700.00, 1, '2025-11-20 15:49:45', '2025-11-20 15:49:45'),
(11, 50, '2025-11-21', 1, 700.00, 1, '2025-11-21 12:23:14', '2025-11-21 12:23:14'),
(12, 47, '2025-11-21', 1, 700.00, 1, '2025-11-21 21:21:14', '2025-11-21 21:21:14'),
(13, 51, '2025-11-22', 1, 700.00, 1, '2025-11-22 06:55:18', '2025-11-22 06:55:18'),
(14, 59, '2025-11-25', 1, 700.00, 1, '2025-11-25 08:06:29', '2025-11-25 08:06:29'),
(15, 55, '2025-11-27', 1, 700.00, 1, '2025-11-27 08:17:37', '2025-11-27 08:17:37'),
(16, 52, '2025-11-27', 1, 700.00, 1, '2025-11-27 11:44:51', '2025-11-27 11:44:51'),
(17, 63, '2025-11-27', 2, 1400.00, 2, '2025-11-27 21:20:33', '2025-11-27 21:28:20'),
(19, 50, '2025-11-28', 1, 700.00, 1, '2025-11-28 06:45:37', '2025-11-28 06:45:37'),
(20, 1, '2025-11-29', 1, 1200.00, 1, '2025-11-29 19:42:56', '2025-11-29 19:42:56'),
(21, 63, '2025-12-01', 2, 100.00, 2, '2025-12-01 17:24:39', '2025-12-01 17:31:06'),
(23, 1, '2025-12-01', 2, 100.00, 2, '2025-12-01 23:14:48', '2025-12-01 23:43:11'),
(25, 55, '2025-12-02', 2, 100.00, 2, '2025-12-02 14:01:40', '2025-12-02 14:04:06'),
(27, 64, '2025-12-02', 2, 100.00, 2, '2025-12-02 14:27:53', '2025-12-02 15:33:13'),
(28, 1, '2025-12-02', 1, 50.00, 1, '2025-12-02 15:24:28', '2025-12-02 15:24:28'),
(30, 1, '2025-12-06', 1, 50.00, 1, '2025-12-06 16:33:50', '2025-12-06 16:33:50'),
(31, 47, '2025-12-08', 1, 50.00, 1, '2025-12-08 11:14:36', '2025-12-08 11:14:36');

-- --------------------------------------------------------

--
-- Table structure for table `stream_earnings`
--

CREATE TABLE `stream_earnings` (
  `id` int NOT NULL,
  `user_id` int NOT NULL,
  `track_id` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `track_title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `stream_duration` int NOT NULL COMMENT 'How long user streamed in seconds',
  `completion_percentage` decimal(5,2) NOT NULL,
  `payout_amount` decimal(10,2) DEFAULT '0.00',
  `is_eligible` tinyint(1) DEFAULT '0' COMMENT '1 if eligible for payout',
  `payout_status` enum('pending','paid','revoked') COLLATE utf8mb4_unicode_ci DEFAULT 'pending',
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text COLLATE utf8mb4_unicode_ci,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `streamed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `stream_earnings`
--

INSERT INTO `stream_earnings` (`id`, `user_id`, `track_id`, `track_title`, `stream_duration`, `completion_percentage`, `payout_amount`, `is_eligible`, `payout_status`, `ip_address`, `user_agent`, `email`, `streamed_at`) VALUES
(28, 1, 'track_1764344572_6929c2fc5cb01', 'Testing', 70, 100.00, 50.00, 1, 'paid', '102.90.99.178', 'Mozilla/5.0 (Linux; Android 8.0.0; SM-G955U Build/R16NW) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36', 'steveneloit122@gmail.com', '2025-12-02 15:24:28'),
(29, 64, 'track_1764344572_6929c2fc5cb01', 'Testing', 70, 100.00, 50.00, 1, 'paid', '102.90.99.178', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', 'steveneloit12@gmail.com', '2025-12-02 15:33:13'),
(30, 1, 'track_1764344450_6929c282519c6', 'Obodo Dev', 70, 100.00, 50.00, 1, 'paid', '102.90.101.210', 'Mozilla/5.0 (iPhone; CPU iPhone OS 18_5_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/133.0.6943.84 Mobile/15E148 Safari/604.1', NULL, '2025-12-06 16:33:50'),
(31, 47, 'track_1764344572_6929c2fc5cb01', 'Testing', 70, 100.00, 50.00, 1, 'paid', '102.90.100.16', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36', 'karinayuken@gmail.com', '2025-12-08 11:14:36');

-- --------------------------------------------------------

--
-- Table structure for table `stream_logs`
--

CREATE TABLE `stream_logs` (
  `id` int NOT NULL,
  `user_id` int NOT NULL,
  `track_id` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `event_type` enum('play','pause','seek','complete','payout_attempt') COLLATE utf8mb4_unicode_ci NOT NULL,
  `stream_duration` int DEFAULT '0',
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `stream_logs`
--

INSERT INTO `stream_logs` (`id`, `user_id`, `track_id`, `event_type`, `stream_duration`, `ip_address`, `user_agent`, `created_at`) VALUES
(1, 9, 'track_1760499215_68ef160fa7932', 'complete', 71, '::1', 'Mozilla/5.0 (Linux; Android 8.0.0; SM-G955U Build/R16NW) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36', '2025-10-16 08:14:40'),
(2, 1, 'track_1760499215_68ef160fa7932', 'complete', 71, '::1', 'Mozilla/5.0 (Linux; Android 8.0.0; SM-G955U Build/R16NW) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36', '2025-10-17 19:27:34'),
(3, 8, 'track_1760978533_68f66665394b2', 'complete', 70, '::1', 'Mozilla/5.0 (Linux; Android 8.0.0; SM-G955U Build/R16NW) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36', '2025-10-20 16:44:19'),
(4, 12, 'track_1760499215_68ef160fa7932', 'complete', 4, '102.90.97.52', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36', '2025-11-09 09:10:53'),
(5, 35, 'track_1760499215_68ef160fa7932', 'complete', 4, '102.90.97.52', 'Mozilla/5.0 (iPhone; CPU iPhone OS 18_5_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/133.0.6943.84 Mobile/15E148 Safari/604.1', '2025-11-09 10:13:50'),
(6, 39, 'track_1760978533_68f66665394b2', 'complete', 70, '102.90.80.31', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36', '2025-11-12 11:55:54'),
(7, 21, 'track_1760499215_68ef160fa7932', 'complete', 4, '102.90.82.94', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36', '2025-11-13 13:01:02'),
(8, 21, 'track_1760978533_68f66665394b2', 'complete', 70, '102.90.82.94', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36', '2025-11-13 13:03:43'),
(9, 39, 'track_1760499215_68ef160fa7932', 'complete', 4, '102.90.82.94', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36', '2025-11-13 13:52:05'),
(10, 2, 'track_1760499215_68ef160fa7932', 'complete', 4, '102.90.102.166', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', '2025-11-20 15:49:45'),
(11, 50, 'track_1760499215_68ef160fa7932', 'complete', 4, '102.90.97.134', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36', '2025-11-21 12:23:14'),
(12, 47, 'track_1760499215_68ef160fa7932', 'complete', 4, '102.90.117.101', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36', '2025-11-21 21:21:14'),
(13, 51, 'track_1760499215_68ef160fa7932', 'complete', 4, '102.90.97.181', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36', '2025-11-22 06:55:18'),
(14, 59, 'track_1760499215_68ef160fa7932', 'complete', 4, '105.113.36.133', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36', '2025-11-25 08:06:29'),
(15, 55, 'track_1760499215_68ef160fa7932', 'complete', 4, '102.90.103.73', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36', '2025-11-27 08:17:37'),
(16, 52, 'track_1760499215_68ef160fa7932', 'complete', 4, '102.90.103.73', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36', '2025-11-27 11:44:51'),
(17, 63, 'track_1760499215_68ef160fa7932', 'complete', 4, '102.90.98.220', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36', '2025-11-27 21:20:33'),
(18, 63, 'track_1760978533_68f66665394b2', 'complete', 70, '102.90.98.220', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36', '2025-11-27 21:28:20'),
(19, 50, 'track_1760978533_68f66665394b2', 'complete', 70, '102.90.100.184', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36', '2025-11-28 06:45:37'),
(20, 1, 'track_1764428225_692b09c12cb1d', 'complete', 70, '102.90.82.223', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', '2025-11-29 19:42:56'),
(21, 63, 'track_1764344450_6929c282519c6', 'complete', 70, '102.90.118.156', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36', '2025-12-01 17:24:39'),
(22, 63, 'track_1764344572_6929c2fc5cb01', 'complete', 70, '102.90.118.156', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36', '2025-12-01 17:31:06'),
(23, 1, 'track_1764344450_6929c282519c6', 'complete', 70, '102.90.81.145', 'Mozilla/5.0 (Linux; Android 8.0.0; SM-G955U Build/R16NW) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36', '2025-12-01 23:14:48'),
(24, 1, 'track_1764344572_6929c2fc5cb01', 'complete', 70, '102.90.81.145', 'Mozilla/5.0 (Linux; Android 8.0.0; SM-G955U Build/R16NW) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36', '2025-12-01 23:43:11'),
(25, 55, 'track_1764344572_6929c2fc5cb01', 'complete', 70, '102.90.99.178', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', '2025-12-02 14:01:40'),
(26, 55, 'track_1764344450_6929c282519c6', 'complete', 70, '102.90.99.178', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', '2025-12-02 14:04:06'),
(27, 64, 'track_1764344572_6929c2fc5cb01', 'complete', 70, '102.90.99.178', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', '2025-12-02 14:27:53'),
(28, 1, 'track_1764344572_6929c2fc5cb01', 'complete', 70, '102.90.99.178', 'Mozilla/5.0 (Linux; Android 8.0.0; SM-G955U Build/R16NW) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Mobile Safari/537.36', '2025-12-02 15:24:28'),
(29, 64, 'track_1764344572_6929c2fc5cb01', 'complete', 70, '102.90.99.178', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36', '2025-12-02 15:33:13'),
(30, 1, 'track_1764344450_6929c282519c6', 'complete', 70, '102.90.101.210', 'Mozilla/5.0 (iPhone; CPU iPhone OS 18_5_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/133.0.6943.84 Mobile/15E148 Safari/604.1', '2025-12-06 16:33:50'),
(31, 47, 'track_1764344572_6929c2fc5cb01', 'complete', 70, '102.90.100.16', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36', '2025-12-08 11:14:36');

-- --------------------------------------------------------

--
-- Table structure for table `stream_tracks`
--

CREATE TABLE `stream_tracks` (
  `id` int NOT NULL,
  `track_id` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `artist` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `album` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `duration` int NOT NULL COMMENT 'Duration in seconds',
  `cover_image` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `audio_file` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `stream_link` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_ad_track` tinyint(1) DEFAULT '0',
  `track_link` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'External link to redirect users after listening to audio ad',
  `free_reward` decimal(10,2) NOT NULL DEFAULT '150.00',
  `premium_reward` decimal(10,2) NOT NULL DEFAULT '700.00',
  `upload_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `uploaded_by` int NOT NULL COMMENT 'Admin user ID',
  `is_active` tinyint(1) DEFAULT '1',
  `play_count` int DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `stream_tracks`
--

INSERT INTO `stream_tracks` (`id`, `track_id`, `title`, `artist`, `album`, `duration`, `cover_image`, `audio_file`, `stream_link`, `is_ad_track`, `track_link`, `free_reward`, `premium_reward`, `upload_date`, `uploaded_by`, `is_active`, `play_count`) VALUES
(1, 'track_1760499215_68ef160fa7932', 'Billionaires Club', 'Olamide', 'Olamide ft Obodo', 4, 'uploads/stream_covers/cover_1760499215_68ef160fa71c5.jpeg', 'uploads/stream_tracks/track_1760499215_68ef160fa68a7.mp3', NULL, 0, 'https://earnova.org', 150.00, 700.00, '2025-10-15 03:33:35', 9, 1, 14),
(2, 'track_1760736285_68f2b41d7d3f4', 'Olamide Badoo', 'Olamide', 'Olamide ft Obodo', 190, 'uploads/stream_covers/cover_1760736285_68f2b41d7ccc7.jpeg', 'uploads/stream_tracks/track_1760736285_68f2b41d7c32a.mp3', NULL, 0, 'https://earnova-digital-hub.com', 150.00, 700.00, '2025-10-17 21:24:45', 1, 1, 0),
(3, 'track_1760978533_68f66665394b2', 'Olamide', 'Olamide', 'Olamide ft Obodo', 70, 'uploads/stream_covers/cover_1760978533_68f6666538f7f.jpeg', 'uploads/stream_tracks/track_1760978533_68f6666538706.mp3', NULL, 0, 'https://earnova-digital-hub.xom', 150.00, 700.00, '2025-10-20 16:42:13', 8, 1, 5),
(4, 'track_1764344450_6929c282519c6', 'Obodo Dev', 'Testing', 'Testing By Obodo Dev', 70, 'uploads/stream_covers/cover_1764344450_6929c28251858.jpeg', 'uploads/stream_tracks/track_1764344450_6929c282512f8.mp3', NULL, 0, NULL, 50.00, 50.00, '2025-11-28 15:40:50', 1, 1, 4),
(5, 'track_1764344572_6929c2fc5cb01', 'Testing', 'Testing', 'Testing By Obodo Dev', 70, 'uploads/stream_covers/cover_1764344572_6929c2fc5c990.jpeg', 'uploads/stream_tracks/track_1764344572_6929c2fc5c44c.mp3', NULL, 0, 'https://earnova.org/testing', 50.00, 50.00, '2025-11-28 15:42:52', 1, 1, 7);

-- --------------------------------------------------------

--
-- Table structure for table `tasks`
--

CREATE TABLE `tasks` (
  `id` int NOT NULL,
  `title` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `task_type` enum('social_media','website_visit','group_join','like_comment','other') COLLATE utf8mb4_unicode_ci NOT NULL,
  `platform` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT 'tiktok',
  `reward_amount` decimal(10,2) NOT NULL,
  `participants_count` int DEFAULT '10',
  `task_url` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT '1',
  `is_premium_only` tinyint(1) DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `is_pinned` tinyint(1) DEFAULT '0' COMMENT 'Whether task is pinned/compulsory for all users',
  `posted_by_admin` tinyint(1) DEFAULT '0' COMMENT 'Whether task was posted by admin',
  `user_id` int DEFAULT NULL,
  `posted_by_username` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `posted_by_fullname` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `member_reward` decimal(10,2) DEFAULT '0.00' COMMENT 'Reward amount for membership users',
  `non_member_reward` decimal(10,2) DEFAULT '0.00' COMMENT 'Reward amount for non-membership users',
  `completed_count` int DEFAULT '0' COMMENT 'Number of users who have completed this task',
  `is_completed` tinyint(1) DEFAULT '0' COMMENT 'Whether task has reached participant limit',
  `is_permanently_disabled` tinyint(1) DEFAULT '0' COMMENT 'Whether task is permanently disabled (user cannot reactivate)'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tasks`
--

INSERT INTO `tasks` (`id`, `title`, `description`, `task_type`, `platform`, `reward_amount`, `participants_count`, `task_url`, `is_active`, `is_premium_only`, `created_at`, `updated_at`, `is_pinned`, `posted_by_admin`, `user_id`, `posted_by_username`, `posted_by_fullname`, `member_reward`, `non_member_reward`, `completed_count`, `is_completed`, `is_permanently_disabled`) VALUES
(52, 'Hjyg', 'Join', 'social_media', 'whatsapp', 1.92, 10, 'https://whatsapp.com/channel/0029Vb3Ig8NCBtxBUVlOuB2n', 1, 0, '2025-11-30 22:25:32', '2025-12-02 14:24:15', 0, 0, 47, 'Yuken92', NULL, 0.00, 0.00, 3, 0, 0),
(53, 'Now', 'Fast', 'social_media', 'telegram', 1.92, 10, 'https://t.me/earnovadigitalhub', 1, 0, '2025-11-30 22:27:39', '2025-12-02 14:22:33', 0, 0, 47, 'Yuken92', NULL, 0.00, 0.00, 1, 0, 0),
(54, 'Good day', 'Please join', 'social_media', 'whatsapp', 1.92, 50, 'https://whatsapp.com/channel/0029Vb3Ig8NCBtxBUVlOuB2n', 1, 0, '2025-12-01 08:13:21', '2025-12-01 08:13:21', 0, 0, 54, 'Cat020', NULL, 0.00, 0.00, 0, 0, 0),
(55, 'My Joy', 'Go ahead', 'social_media', 'whatsapp', 1.92, 100, 'https://whatsapp.com/channel/0029Vb3Ig8NCBtxBUVlOuB2n', 1, 0, '2025-12-01 08:14:30', '2025-12-04 06:17:05', 0, 0, 54, 'Cat020', NULL, 0.00, 0.00, 0, 0, 0),
(56, 'follow emeka', 'follow', 'social_media', 'tiktok', 1.92, 10, 'https://tiktok.com', 1, 0, '2025-12-01 11:00:15', '2025-12-02 11:58:56', 0, 0, 1, 'Obodonwoke', NULL, 0.00, 0.00, 1, 0, 0),
(57, 'Testing', 'Testing', 'social_media', 'facebook', 2.10, 10, 'https://facebook.com', 0, 0, '2025-12-01 11:37:55', '2025-12-01 12:22:38', 0, 0, 1, 'Obodonwoke', NULL, 0.00, 0.00, 0, 0, 1),
(58, 'Testing post task', 'Testing Post Task', 'social_media', 'instagram', 2.10, 20, 'https://instagram.com', 0, 0, '2025-12-01 11:40:39', '2025-12-01 13:52:55', 0, 0, 1, 'Obodonwoke', NULL, 0.00, 0.00, 0, 0, 0),
(59, 'Good day Chief please download up', 'Nm.  Jjejdjjdjdjd. Hudhbdhduhrbdd buhbbhdb. Hh. Hjdhhdhdhdjhrbdbhdhd make sure you download my app', 'social_media', 'playstore', 4.20, 150, 'https://play.google.com', 1, 0, '2025-12-02 16:43:56', '2025-12-03 15:50:20', 0, 0, 54, 'Cat020', NULL, 0.00, 0.00, 1, 0, 0),
(60, 'Hhgffd good on', 'Please make sure to join', 'social_media', 'whatsapp', 1.92, 100, 'https://chat.whatsapp.com/EXp3ZVGrSrEB0KaZNt6HgH?mode=wwt', 1, 0, '2025-12-04 06:15:08', '2025-12-04 15:52:05', 0, 0, 47, 'Yuken92', NULL, 0.00, 0.00, 1, 0, 0),
(61, 'Testing upline reward', 'Testing upline reward', 'social_media', 'whatsapp', 1.92, 1000, 'https://wa.link', 1, 0, '2025-12-05 16:45:05', '2025-12-13 12:21:51', 0, 0, 64, 'Stream&Earn', NULL, 0.00, 0.00, 1, 0, 0),
(62, 'Testing upline company', 'Testing', 'social_media', 'youtube', 2.40, 500, 'https://youtube.com/obodo', 1, 0, '2025-12-05 16:51:21', '2025-12-05 16:51:21', 0, 0, 64, 'Stream&Earn', NULL, 0.00, 0.00, 0, 0, 0),
(63, 'Join', 'Fast', 'social_media', 'whatsapp', 1.92, 100, 'https://wa.link', 1, 0, '2025-12-09 16:03:38', '2025-12-09 16:03:38', 0, 0, 47, 'Yuken92', NULL, 0.00, 0.00, 0, 0, 0),
(64, 'Bbffff', 'E sharp', 'social_media', 'whatsapp', 1.92, 1100, 'https://wa.link/iei044', 1, 0, '2025-12-10 13:42:42', '2025-12-11 23:13:47', 0, 0, 54, 'Cat020', NULL, 0.00, 0.00, 0, 0, 0),
(65, 'testing kora pay', 'testing kora pay', 'social_media', 'instagram', 2.10, 10, 'https://instagram.com', 1, 0, '2025-12-11 16:12:11', '2025-12-11 16:12:11', 0, 0, 1, 'Obodonwoke', NULL, 0.00, 0.00, 0, 0, 0),
(66, 'follow me tesing', 'testing testing', 'social_media', 'facebook', 2.10, 180, 'https://facebook.com', 1, 0, '2025-12-11 16:19:19', '2025-12-11 16:19:19', 0, 0, 1, 'Obodonwoke', NULL, 0.00, 0.00, 0, 0, 0),
(67, 'kora kora', 'kora kora', 'social_media', 'whatsapp', 1.92, 890, 'https://wa.me', 1, 0, '2025-12-11 17:02:35', '2025-12-11 17:02:35', 0, 0, 1, 'Obodonwoke', '', 0.00, 0.00, 0, 0, 0),
(68, 'kora kora', 'kora kora', 'social_media', 'telegram', 1.92, 10, 'https://t.me', 1, 0, '2025-12-11 17:05:21', '2025-12-11 17:05:21', 0, 0, 1, 'Obodonwoke', '', 0.00, 0.00, 0, 0, 0),
(69, 'kora kora', 'kora kora', 'social_media', 'telegram', 1.92, 10, 'https://t.me', 1, 0, '2025-12-11 17:20:48', '2025-12-11 17:20:48', 0, 0, 1, 'Obodonwoke', '', 0.00, 0.00, 0, 0, 0),
(70, 'follow kora', 'follow kora', 'social_media', 'tiktok', 1.92, 800, 'https://tiktok.com', 1, 0, '2025-12-11 17:23:50', '2025-12-11 17:23:50', 0, 0, 1, 'Obodonwoke', '', 0.00, 0.00, 0, 0, 0),
(71, 'kota kora kora', 'kora testing kora pay', 'social_media', 'instagram', 2.10, 189, 'https://instagram.com', 1, 0, '2025-12-11 18:27:11', '2025-12-11 18:27:11', 0, 0, 1, 'Obodonwoke', '', 0.00, 0.00, 0, 0, 0),
(72, 'kora testing 56', 'kora testing 56', 'social_media', 'tiktok', 1.92, 300, 'https://tiktok.com', 1, 0, '2025-12-11 18:29:53', '2025-12-11 18:29:53', 0, 0, 1, 'Obodonwoke', '', 0.00, 0.00, 0, 0, 0),
(73, 'tiktok', 'tiktok kora pay', 'social_media', 'tiktok', 1.92, 500, 'https://tiktok.com', 1, 0, '2025-12-11 21:45:05', '2025-12-11 21:45:05', 0, 0, 1, 'Obodonwoke', '', 0.00, 0.00, 0, 0, 0),
(74, 'Join me', 'Good day', 'social_media', 'whatsapp', 1.92, 100, 'https://chat.whatsapp.com/EXp3ZVGrSrEB0KaZNt6HgH?mode=wwt', 1, 0, '2025-12-11 22:24:51', '2025-12-11 22:24:51', 0, 0, 47, 'Yuken92', '', 0.00, 0.00, 0, 0, 0),
(75, 'Kora Pay Post Task Admin Testing', 'Kora Pay Post Task Admin Testing', 'social_media', 'website', 3.00, 10, 'https://soundcloud.com/', 1, 0, '2025-12-12 12:07:35', '2025-12-12 12:07:35', 0, 0, 1, 'Obodonwoke', '', 0.00, 0.00, 0, 0, 0),
(76, 'follow emenekam', 'follow kora pay testing', 'social_media', 'whatsapp', 1.92, 900, 'https://wa.me', 1, 0, '2025-12-12 12:26:11', '2025-12-12 12:26:11', 0, 0, 1, 'Obodonwoke', '', 0.00, 0.00, 0, 0, 0),
(77, 'testing kora pay', 'kora pay testing testing', 'social_media', 'website', 3.00, 500, 'https://fak.com', 1, 0, '2025-12-12 12:31:34', '2025-12-12 12:31:34', 0, 0, 1, 'Obodonwoke', '', 0.00, 0.00, 0, 0, 0),
(78, 'kora pay 2', 'kora pay 2', 'social_media', 'whatsapp', 1.92, 900, 'https://wa.me', 1, 0, '2025-12-12 13:35:01', '2025-12-12 13:35:01', 0, 0, 1, 'Obodonwoke', NULL, 0.00, 0.00, 0, 0, 0),
(79, 'follow testing', 'testing testing', 'social_media', 'facebook', 2.10, 600, 'https://facebook.com', 1, 0, '2025-12-12 13:47:32', '2025-12-12 13:47:32', 0, 0, 1, 'Obodonwoke', '', 0.00, 0.00, 0, 0, 0),
(80, 'kora 31', 'kora 45', 'social_media', 'website', 3.00, 900, 'https://in.com', 1, 0, '2025-12-12 13:54:54', '2025-12-12 13:54:54', 0, 0, 1, 'Obodonwoke', NULL, 0.00, 0.00, 0, 0, 0),
(81, 'follow kora', 'follow kora', 'social_media', 'website', 3.00, 900, 'https://website.com/', 1, 0, '2025-12-12 13:57:29', '2025-12-12 13:57:29', 0, 0, 1, 'Obodonwoke', NULL, 0.00, 0.00, 0, 0, 0),
(82, 'kora testing 2', 'testing kora 3', 'social_media', 'website', 3.00, 1000, 'https://menan.com', 1, 0, '2025-12-12 14:00:30', '2025-12-12 14:00:30', 0, 0, 1, 'Obodonwoke', '', 0.00, 0.00, 0, 0, 0),
(83, 'follo pay stack', 'paystack', 'social_media', 'website', 3.00, 789, 'https://menan.com', 1, 0, '2025-12-12 14:03:00', '2025-12-12 14:03:00', 0, 0, 1, 'Obodonwoke', NULL, 0.00, 0.00, 0, 0, 0),
(84, 'Follow me testing', 'Follow testing', 'social_media', 'telegram', 1.92, 879, 'https://t.me', 1, 0, '2025-12-12 14:09:13', '2025-12-12 14:09:13', 0, 0, 64, 'Stream&Earn', '', 0.00, 0.00, 0, 0, 0),
(85, 'Testing 2', 'Testing 2', 'social_media', 'playstore', 4.20, 1000, 'https://play.google.com', 1, 0, '2025-12-12 14:14:23', '2025-12-12 14:14:23', 0, 0, 64, 'Stream&Earn', '', 0.00, 0.00, 0, 0, 0),
(86, 'Testing 3', 'Testing 3', 'social_media', 'playstore', 4.20, 1000, 'https://play.google.com', 1, 0, '2025-12-12 14:16:03', '2025-12-12 14:16:03', 0, 0, 64, 'Stream&Earn', NULL, 0.00, 0.00, 0, 0, 0),
(87, 'Paystack task', 'Paystack task', 'social_media', 'playstore', 4.20, 989, 'https://play.google.com', 1, 0, '2025-12-12 14:46:36', '2025-12-12 14:46:36', 0, 0, 64, 'Stream&Earn', NULL, 0.00, 0.00, 0, 0, 0),
(88, 'Follow my ig', 'Follow Og posting', 'social_media', 'website', 3.00, 1000, 'https://earnova-digital-hub.com', 1, 0, '2025-12-12 17:22:05', '2025-12-12 17:22:05', 0, 0, 64, 'Stream&Earn', NULL, 0.00, 0.00, 0, 0, 0),
(89, 'Follow me obodo', 'Follow emenekam', 'social_media', 'playstore', 4.20, 169, 'https://play.google.com', 1, 0, '2025-12-13 08:18:50', '2025-12-13 08:18:50', 0, 0, 64, 'Stream&Earn', '', 0.00, 0.00, 0, 0, 0),
(90, 'Follow God and me eche', 'Follow me eche', 'social_media', 'reddit', 2.10, 1000, 'https://reddit.com', 1, 0, '2025-12-13 08:28:34', '2025-12-13 08:28:34', 0, 0, 64, 'Stream&Earn', NULL, 0.00, 0.00, 0, 0, 0),
(91, 'Testing paystack', 'Testing paystack', 'social_media', 'twitter', 2.28, 999, 'https://x.com', 1, 0, '2025-12-13 08:48:14', '2025-12-13 08:48:14', 0, 0, 64, 'Stream&Earn', NULL, 0.00, 0.00, 0, 0, 0),
(92, 'Follow chi chi', 'Follow chi chi', 'social_media', 'facebook', 2.10, 999, 'https://Facebook.com', 1, 0, '2025-12-13 08:51:45', '2025-12-13 08:51:45', 0, 0, 64, 'Stream&Earn', NULL, 0.00, 0.00, 0, 0, 0),
(93, 'Uche', 'Uche', 'social_media', 'telegram', 1.92, 102, 'https://t.me/obodo', 1, 0, '2025-12-13 08:55:34', '2025-12-13 08:55:34', 0, 0, 64, 'Stream&Earn', NULL, 0.00, 0.00, 0, 0, 0),
(94, 'Testing kora', 'Testing again', 'social_media', 'playstore', 4.20, 104, 'https://play.google.com', 1, 0, '2025-12-13 09:30:26', '2025-12-13 09:30:26', 0, 0, 64, 'Stream&Earn', '', 0.00, 0.00, 0, 0, 0),
(95, 'Testing testing paystavk', 'Testing paystavk', 'social_media', 'playstore', 4.20, 10, 'https://play.google.com', 1, 0, '2025-12-13 09:32:06', '2025-12-14 21:31:04', 0, 0, 64, 'Stream&Earn', NULL, 0.00, 0.00, 1, 0, 0),
(96, 'testing Upline 5% reward', 'testing Upline 5% reward', 'social_media', 'website', 3.00, 1000, 'https://igital-hub.com', 1, 0, '2025-12-13 10:27:01', '2025-12-13 11:45:00', 0, 0, 64, 'Stream&Earn', NULL, 0.00, 0.00, 0, 0, 0),
(97, 'Testing x.com', 'Testing x.com', 'social_media', 'twitter', 2.28, 10000, 'https://x.com', 1, 0, '2025-12-13 11:59:28', '2025-12-13 11:59:28', 0, 0, 64, 'Stream&Earn', NULL, 0.00, 0.00, 0, 0, 0),
(98, 'Follow my x account', 'Follow x or twitter account', 'social_media', 'twitter', 2.28, 10000, 'https://x.com', 1, 0, '2025-12-13 12:02:54', '2025-12-13 12:02:54', 0, 0, 64, 'Stream&Earn', NULL, 0.00, 0.00, 0, 0, 0),
(99, 'Follow twitter account', 'Follow twitter account', 'social_media', 'twitter', 2.28, 1600, 'https://x.com', 1, 0, '2025-12-13 15:42:17', '2025-12-13 15:42:17', 0, 0, 1, 'Obodonwoke', NULL, 0.00, 0.00, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `task_count_sync_log`
--

CREATE TABLE `task_count_sync_log` (
  `id` int NOT NULL,
  `action_type` enum('task_completed','task_added') NOT NULL,
  `task_id` int NOT NULL,
  `user_id` int DEFAULT NULL,
  `fake_count_before` int DEFAULT NULL,
  `fake_count_after` int DEFAULT NULL,
  `real_count_before` int DEFAULT NULL,
  `real_count_after` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `task_count_sync_log`
--

INSERT INTO `task_count_sync_log` (`id`, `action_type`, `task_id`, `user_id`, `fake_count_before`, `fake_count_after`, `real_count_before`, `real_count_after`, `created_at`) VALUES
(103, 'task_completed', 52, 63, NULL, NULL, NULL, NULL, '2025-12-01 17:41:33'),
(104, 'task_completed', 52, 47, NULL, NULL, NULL, NULL, '2025-12-02 10:53:15'),
(105, 'task_completed', 56, 47, NULL, NULL, NULL, NULL, '2025-12-02 11:58:56'),
(106, 'task_completed', 53, 54, NULL, NULL, NULL, NULL, '2025-12-02 14:22:33'),
(107, 'task_completed', 52, 54, NULL, NULL, NULL, NULL, '2025-12-02 14:24:15'),
(108, 'task_completed', 59, 47, NULL, NULL, NULL, NULL, '2025-12-03 15:50:20'),
(109, 'task_completed', 60, 1, NULL, NULL, NULL, NULL, '2025-12-04 15:52:05'),
(110, 'task_completed', 61, 64, NULL, NULL, NULL, NULL, '2025-12-13 12:21:51'),
(111, 'task_completed', 95, 47, NULL, NULL, NULL, NULL, '2025-12-14 21:31:04');

-- --------------------------------------------------------

--
-- Table structure for table `task_display_settings`
--

CREATE TABLE `task_display_settings` (
  `id` int NOT NULL,
  `setting_key` varchar(100) NOT NULL,
  `setting_value` text NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `task_display_settings`
--

INSERT INTO `task_display_settings` (`id`, `setting_key`, `setting_value`, `description`, `updated_at`, `created_at`) VALUES
(1, 'fake_total_tasks', '88', 'Fake total available tasks shown to free users', '2025-12-13 15:42:17', '2025-11-08 16:30:34');

-- --------------------------------------------------------

--
-- Table structure for table `transactions`
--

CREATE TABLE `transactions` (
  `id` int NOT NULL,
  `user_id` int NOT NULL,
  `transaction_type` enum('deposit','withdrawal','task_reward','invite_commission','daily_reward','premium_upgrade','ad_purchase','whot_bet','chat_earn_reward','video_earning','stream_earning','advertise_commission') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `amount` decimal(15,2) NOT NULL,
  `balance_type` enum('total','game_earnings','activity_earnings','prime_earnings') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `reference_id` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` enum('pending','completed','failed') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `transactions`
--

INSERT INTO `transactions` (`id`, `user_id`, `transaction_type`, `amount`, `balance_type`, `description`, `reference_id`, `created_at`, `status`) VALUES
(1, 1, 'daily_reward', 50.00, '', 'Daily login reward claimed - Day 1', NULL, '2025-10-02 01:18:47', 'pending'),
(2, 1, '', 150.00, '', 'Listened to music: Motivational Beats', NULL, '2025-10-05 09:49:58', 'pending'),
(3, 1, 'daily_reward', 100.00, '', 'Daily login reward claimed - Day 2', NULL, '2025-10-05 16:36:18', 'pending'),
(4, 1, 'ad_purchase', 500.00, '', 'Posted task: Follow Obodo on TikTok for 10 participants', 'TASK-1', '2025-10-05 19:20:15', 'pending'),
(5, 1, 'daily_reward', 100.00, '', 'Daily login reward claimed - Day 3', NULL, '2025-10-06 16:49:54', 'pending'),
(6, 1, 'ad_purchase', 500.00, '', 'Posted task: Follow my tiktok account on TikTok for 10 participants', 'TASK-2', '2025-10-06 21:09:31', 'pending'),
(7, 1, 'ad_purchase', 600.00, '', 'Posted task: Testing my error and success Message on Instagram for 10 participants', 'TASK-3', '2025-10-06 21:15:15', 'pending'),
(8, 1, 'ad_purchase', 450.00, '', 'Posted task: sihckjldcio jdmlx on Discord for 10 participants', 'TASK-4', '2025-10-06 21:18:31', 'pending'),
(9, 1, 'ad_purchase', 600.00, '', 'Posted task: wdsckjx oi p;lso[x-l on Instagram for 10 participants', 'TASK-5', '2025-10-06 21:24:07', 'pending'),
(10, 1, 'ad_purchase', 400.00, '', 'Posted task: dgfghjkl;\' on WhatsApp for 10 participants', 'TASK-6', '2025-10-06 21:34:57', 'pending'),
(11, 1, 'ad_purchase', 2400.00, '', 'Posted task: Follow my instagram account on WhatsApp for 60 participants', 'TASK-8', '2025-10-07 13:49:01', 'pending'),
(12, 1, 'task_reward', 0.00, '', 'Completed task: wdsckjx oi p;lso[x-l', 'TASK-12', '2025-10-07 14:31:42', 'pending'),
(13, 1, 'daily_reward', 50.00, '', 'Daily login reward claimed - Day 4', NULL, '2025-10-07 16:05:33', 'pending'),
(14, 1, 'daily_reward', 50.00, '', 'Daily login reward claimed - Day 5', NULL, '2025-10-09 12:27:30', 'pending'),
(15, 1, 'daily_reward', 50.00, '', 'Daily login reward claimed - Day 5', NULL, '2025-10-09 12:31:30', 'pending'),
(16, 1, 'daily_reward', 50.00, '', 'Daily login reward claimed - Day 5', NULL, '2025-10-09 12:34:27', 'pending'),
(17, 1, 'daily_reward', 50.00, '', 'Daily login reward claimed - Day 5', NULL, '2025-10-09 12:36:25', 'pending'),
(18, 1, 'daily_reward', 50.00, '', 'Daily login reward claimed - Day 5', NULL, '2025-10-09 12:52:17', 'pending'),
(19, 1, 'daily_reward', 50.00, '', 'Daily login reward claimed - Day 4', NULL, '2025-10-09 12:57:24', 'pending'),
(20, 1, 'daily_reward', 50.00, '', 'Daily login reward claimed - Day 4', NULL, '2025-10-09 13:01:25', 'pending'),
(21, 1, 'daily_reward', 50.00, '', 'Daily login reward claimed - Day 4', NULL, '2025-10-09 13:06:28', 'pending'),
(22, 1, 'daily_reward', 50.00, '', 'Daily login reward claimed - Day 4', NULL, '2025-10-09 13:08:01', 'pending'),
(23, 1, 'daily_reward', 50.00, '', 'Daily login reward claimed - Day 4', NULL, '2025-10-09 13:12:56', 'pending'),
(24, 1, 'daily_reward', 50.00, '', 'Daily login reward claimed - Day 4', NULL, '2025-10-09 13:15:55', 'pending'),
(25, 1, 'daily_reward', 50.00, '', 'Daily login reward claimed - Day 4', NULL, '2025-10-09 13:23:29', 'pending'),
(26, 1, 'daily_reward', 50.00, '', 'Daily login reward claimed - Day 4', NULL, '2025-10-09 13:25:45', 'pending'),
(27, 1, 'daily_reward', 50.00, '', 'Daily login reward claimed - Day 4', NULL, '2025-10-09 13:27:12', 'pending'),
(28, 1, 'daily_reward', 50.00, '', 'Daily login reward claimed - Day 4', NULL, '2025-10-09 13:29:25', 'pending'),
(29, 1, 'daily_reward', 50.00, '', 'Daily login reward claimed - Day 4', NULL, '2025-10-09 13:32:35', 'pending'),
(30, 1, 'daily_reward', 50.00, '', 'Daily login reward claimed - Day 4', NULL, '2025-10-09 13:35:50', 'pending'),
(31, 1, 'daily_reward', 50.00, '', 'Daily login reward claimed - Day 4', NULL, '2025-10-09 13:36:49', 'pending'),
(32, 1, 'daily_reward', 50.00, '', 'Daily login reward claimed - Day 3', NULL, '2025-10-09 13:43:48', 'pending'),
(33, 1, 'daily_reward', 50.00, '', 'Daily login reward claimed - Day 3', NULL, '2025-10-09 17:24:12', 'pending'),
(34, 1, 'task_reward', 0.00, '', 'Completed task: dgfghjkl;\'', 'TASK-16', '2025-10-09 17:34:58', 'pending'),
(35, 1, 'task_reward', 0.00, '', 'Completed task: sihckjldcio jdmlx', 'TASK-32', '2025-10-09 17:54:09', 'pending'),
(36, 1, 'ad_purchase', 500.00, '', 'Posted task: Obodo Dike on Pinterest for 10 participants', 'TASK-10', '2025-10-09 19:06:41', 'pending'),
(37, 1, 'ad_purchase', 500.00, '', 'Posted task: Obodo Dike on Pinterest for 10 participants', 'TASK-11', '2025-10-09 19:07:00', 'pending'),
(38, 1, 'task_reward', 0.00, '', 'Completed task: Obodo Dike', 'TASK-86', '2025-10-09 20:08:02', 'pending'),
(39, 1, 'task_reward', 0.00, '', 'Completed task: Obodo Dike', 'TASK-88', '2025-10-10 08:47:20', 'pending'),
(40, 1, 'task_reward', 0.00, '', 'Completed task: Testing my error and success Message', 'TASK-92', '2025-10-10 08:49:28', 'pending'),
(41, 1, 'withdrawal', 4000.00, '', 'Referral withdrawal of ₦4,000.00', 'WD-1', '2025-10-10 11:28:32', 'pending'),
(42, 1, 'withdrawal', 3000.00, '', 'Referral withdrawal of ₦3,000.00', 'WD-2', '2025-10-12 15:42:12', 'pending'),
(43, 1, 'withdrawal', 3000.00, '', 'Referral withdrawal of ₦3,000.00', 'WD-3', '2025-10-12 15:57:09', 'pending'),
(44, 1, 'withdrawal', 4000.00, '', 'Referral withdrawal of ₦4,000.00', 'WD-4', '2025-10-12 16:06:23', 'pending'),
(45, 1, 'withdrawal', 4000.00, '', 'Referral withdrawal of ₦4,000.00', 'WD-5', '2025-10-12 16:13:30', 'pending'),
(46, 1, 'withdrawal', 4000.00, '', 'Referral withdrawal of ₦4,000.00', 'WD-6', '2025-10-12 16:15:37', 'pending'),
(47, 1, 'withdrawal', 4000.00, '', 'Referral withdrawal of ₦4,000.00', 'WD-7', '2025-10-12 16:20:35', 'pending'),
(48, 1, 'withdrawal', 4000.00, '', 'Referral withdrawal of ₦4,000.00', 'WD-8', '2025-10-12 16:21:48', 'pending'),
(49, 1, 'withdrawal', 4000.00, '', 'Referral withdrawal of ₦4,000.00', 'WD-9', '2025-10-12 16:23:17', 'pending'),
(50, 1, 'withdrawal', 4000.00, '', 'Referral withdrawal of ₦4,000.00', 'WD-10', '2025-10-12 16:25:26', 'pending'),
(51, 1, 'withdrawal', 4000.00, '', 'Referral withdrawal of ₦4,000.00', 'WD-11', '2025-10-12 16:26:12', 'pending'),
(52, 1, 'daily_reward', 100.00, '', 'Daily login reward claimed - Day 3', NULL, '2025-10-12 16:31:32', 'pending'),
(53, 1, 'withdrawal', 4999.99, '', 'Referral withdrawal of ₦4,999.99', 'WD-12', '2025-10-12 22:29:13', 'pending'),
(54, 1, 'daily_reward', 100.00, '', 'Daily login reward claimed - Day 4', NULL, '2025-10-12 22:31:27', 'pending'),
(57, 1, 'task_reward', 0.00, '', 'Completed task: Follow my tiktok account', 'TASK-94', '2025-10-17 08:43:44', 'pending'),
(58, 1, '', 200.00, '', 'Streamed: Billionaires Club', NULL, '2025-10-17 19:27:34', 'pending'),
(443, 1, 'task_reward', 57.60, '', 'Completed task: Folloe Ogenedo', 'TASK-281', '2025-11-17 10:54:42', 'pending'),
(460, 47, 'task_reward', 50.00, 'activity_earnings', 'Completed task: Follow up', 'TASK-423', '2025-11-18 10:12:32', 'pending'),
(461, 47, 'task_reward', 300.00, 'activity_earnings', 'Completed task: Follow Me Obodo', 'TASK-424', '2025-11-18 10:13:31', 'pending'),
(462, 47, 'task_reward', 50.00, 'activity_earnings', 'Completed task: Whatsapp', 'TASK-426', '2025-11-18 10:15:16', 'pending'),
(463, 47, 'task_reward', 50.00, 'activity_earnings', 'Completed task: Tino', 'TASK-427', '2025-11-18 10:16:22', 'pending'),
(464, 1, 'task_reward', 50.00, 'activity_earnings', 'Completed task: Ggb', 'TASK-429', '2025-11-18 10:37:44', 'pending'),
(465, 47, 'task_reward', 50.00, 'activity_earnings', 'Completed task: Ggb', 'TASK-431', '2025-11-18 10:40:56', 'pending'),
(466, 47, 'task_reward', 57.60, 'activity_earnings', 'Completed task: Folloe Ogenedo', 'TASK-434', '2025-11-18 10:42:37', 'pending'),
(467, 47, 'task_reward', 50.00, 'activity_earnings', 'Completed task: Just testing', 'TASK-435', '2025-11-18 10:44:29', 'pending'),
(468, 1, 'ad_purchase', 30000.00, 'prime_earnings', 'Posted task: Website Task on Website for 1000 participants', 'TASK-26', '2025-11-18 13:30:29', 'pending'),
(469, 1, 'ad_purchase', 30000.00, 'prime_earnings', 'Posted task: Testing on Website for 1000 participants', 'TASK-27', '2025-11-18 17:09:23', 'pending'),
(470, 1, 'ad_purchase', 300.00, 'prime_earnings', 'Posted task: Eidicck on Facebook for 10 participants', 'TASK-28', '2025-11-18 17:27:35', 'pending'),
(471, 1, 'ad_purchase', 30000.00, 'prime_earnings', 'Posted task: Xmxkxkkxkx on YouTube for 1000 participants', 'TASK-29', '2025-11-18 17:29:28', 'pending'),
(472, 1, 'ad_purchase', 40000.00, 'prime_earnings', 'Posted task: Testing task on SoundCloud for 1000 participants', 'TASK-30', '2025-11-18 18:22:36', 'pending'),
(473, 1, 'ad_purchase', 6800.00, 'prime_earnings', 'Posted task: Follow me on TikTok for 340 participants', 'TASK-31', '2025-11-18 18:40:40', 'pending'),
(474, 1, 'ad_purchase', 400.00, 'prime_earnings', 'Posted task: Sksksj snsjsjs sjsjsjs sjsjsj on TikTok for 20 participants', 'TASK-32', '2025-11-19 13:09:54', 'pending'),
(475, 1, 'ad_purchase', 25600.00, 'prime_earnings', 'Posted task: Sjsjddj on TikTok for 800 participants', 'TASK-33', '2025-11-19 14:25:07', 'pending'),
(476, 1, 'task_reward', 1.20, 'activity_earnings', 'Completed task: Follow me', 'TASK-451', '2025-11-19 17:09:54', 'pending'),
(477, 1, 'task_reward', 24.00, 'activity_earnings', 'Completed task: Eidicck', 'TASK-454', '2025-11-19 17:22:52', 'pending'),
(478, 1, 'task_reward', 300.00, 'activity_earnings', 'Completed task: Follow Me Obodo', 'TASK-463', '2025-11-19 17:58:45', 'pending'),
(479, 1, 'task_reward', 36.00, 'activity_earnings', 'Completed task: Just testing', 'TASK-464', '2025-11-19 18:01:37', 'pending'),
(480, 1, 'task_reward', 2.40, 'activity_earnings', 'Completed task: Testing task', 'TASK-470', '2025-11-19 19:23:35', 'pending'),
(481, 1, 'task_reward', 32.00, 'activity_earnings', 'Completed task: Follow my instagram account', 'TASK-471', '2025-11-19 19:42:52', 'pending'),
(482, 1, 'ad_purchase', 400.00, 'prime_earnings', 'Posted task: Foolow sound cloud on SoundCloud for 10 participants', 'TASK-34', '2025-11-19 20:14:56', 'pending'),
(483, 47, 'task_reward', 60.00, 'activity_earnings', 'Completed task: Subscribe me now', 'TASK-476', '2025-11-19 20:31:15', 'pending'),
(484, 1, 'task_reward', 60.00, 'activity_earnings', 'Completed task: Please subscribe to my channels', 'TASK-479', '2025-11-19 21:56:21', 'pending'),
(485, 1, 'task_reward', 32.00, 'activity_earnings', 'Completed task: Tino', 'TASK-480', '2025-11-19 21:58:20', 'pending'),
(486, 1, 'task_reward', 36.00, 'activity_earnings', 'Completed task: Tino', 'TASK-482', '2025-11-19 22:03:21', 'pending'),
(488, 46, 'chat_earn_reward', 250.00, NULL, 'Chat & Earn  Reward', NULL, '2025-11-20 20:24:10', 'completed'),
(489, 47, '', 500.00, '', 'Franklin# upgraded to Premium plan - Commission', 'PREMIUM_UPGRADE-s94e3bty26', '2025-11-21 11:12:16', 'pending'),
(490, 50, 'premium_upgrade', 1500.00, 'total', 'Premium membership upgrade', 'PREMIUM_UPGRADE-s94e3bty26', '2025-11-21 11:12:16', 'pending'),
(491, 1, 'ad_purchase', 640.00, 'prime_earnings', 'Posted task: Follow Me Emeka on TikTok for 20 participants', 'TASK-35', '2025-11-21 11:46:15', 'pending'),
(492, 1, 'chat_earn_reward', 250.00, NULL, 'Chat & Earn  Reward', NULL, '2025-11-21 12:13:03', 'completed'),
(493, 50, 'daily_reward', 100.00, '', 'Daily login reward claimed - Day 1', NULL, '2025-11-21 12:15:10', 'pending'),
(494, 47, '', 500.00, '', 'Franklin# upgraded to Premium Plus plan - Commission', 'SENIOR_ADVERTISER_UPGRADE-cdf9t8imr35', '2025-11-21 12:19:46', 'pending'),
(495, 50, 'premium_upgrade', 2500.00, 'total', 'Senior Advertiser plan upgrade (yearly)', 'SENIOR_ADVERTISER_UPGRADE-cdf9t8imr35', '2025-11-21 12:19:46', 'pending'),
(496, 50, 'chat_earn_reward', 250.00, NULL, 'Chat & Earn  Reward', NULL, '2025-11-21 12:20:50', 'completed'),
(497, 50, '', 700.00, '', 'Streamed: Billionaires Club', NULL, '2025-11-21 12:23:14', 'pending'),
(498, 50, '', 4000.00, 'prime_earnings', 'Posted task: Subscribe my channel on YouTube for 100 participants', 'TASK_26209664', '2025-11-21 12:30:55', 'pending'),
(499, 47, '', 200.00, '', '5% Advertisement Commission - Downline task posting (₦4000) on YouTube', 'UPLINE-AD-COMM-36', '2025-11-21 12:30:55', 'pending'),
(500, 1, 'task_reward', 20.00, 'activity_earnings', 'Completed task: Follow Us on twitter', 'TASK-508', '2025-11-21 13:12:04', 'pending'),
(501, 1, 'task_reward', 20.00, 'activity_earnings', 'Completed task: Whatsapp', 'TASK-509', '2025-11-21 13:13:12', 'pending'),
(502, 1, 'task_reward', 20.00, 'activity_earnings', 'Completed task: Follow Me Emeka', 'TASK-510', '2025-11-21 13:15:26', 'pending'),
(503, 1, 'task_reward', 20.00, 'activity_earnings', 'Completed task: Follow my tiktok account', 'TASK-511', '2025-11-21 13:25:23', 'pending'),
(504, 1, 'task_reward', 20.00, 'activity_earnings', 'Completed task: Testing my error and success Message', 'TASK-512', '2025-11-21 13:35:04', 'pending'),
(505, 54, '', 4000.00, 'prime_earnings', 'Posted task: Cghgcg on YouTube for 100 participants', 'TASK_6313362', '2025-11-21 20:20:42', 'pending'),
(506, 47, '', 200.00, '', '5% Advertisement Commission - Downline task posting (₦4000) on YouTube', 'UPLINE-AD-COMM-37', '2025-11-21 20:20:42', 'pending'),
(507, 46, 'deposit', 1000.00, 'prime_earnings', 'Deposit for General Balance', 'DEPOSIT-cagt8q06x0n', '2025-11-21 20:21:32', 'pending'),
(508, 1, 'deposit', 1000.00, 'prime_earnings', 'Deposit for General Balance', 'DEPOSIT-kwqepyz4iie', '2025-11-21 20:22:41', 'pending'),
(509, 47, '', 500.00, '', 'Cat020 upgraded to Premium plan - Commission', 'PREMIUM_UPGRADE-1dhhubcpwq8', '2025-11-21 20:23:29', 'pending'),
(510, 54, 'premium_upgrade', 1500.00, 'total', 'Premium membership upgrade', 'PREMIUM_UPGRADE-1dhhubcpwq8', '2025-11-21 20:23:29', 'pending'),
(511, 54, 'task_reward', 300.00, 'activity_earnings', 'Completed task: Follow Me Obodo', 'TASK-522', '2025-11-21 20:25:07', 'pending'),
(512, 54, 'task_reward', 28.00, 'activity_earnings', 'Completed task: Cghgcg', 'TASK-523', '2025-11-21 20:26:40', 'pending'),
(513, 54, 'task_reward', 28.00, 'activity_earnings', 'Completed task: Subscribe my channel', 'TASK-524', '2025-11-21 20:27:38', 'pending'),
(514, 47, '', 700.00, '', 'Streamed: Billionaires Club', NULL, '2025-11-21 21:21:14', 'pending'),
(515, 54, 'deposit', 100000.00, 'prime_earnings', 'Deposit for General Balance', 'DEPOSIT-aimiyzgk2ku', '2025-11-21 21:36:37', 'pending'),
(516, 54, 'task_reward', 25.00, 'activity_earnings', 'Completed task: Eidicck', 'TASK-526', '2025-11-21 22:04:28', 'pending'),
(517, 1, 'deposit', 70000.00, 'prime_earnings', 'Deposit for General Balance', 'DEPOSIT-db8pd1ndo3d', '2025-11-21 23:07:33', 'pending'),
(519, 1, 'premium_upgrade', 2500.00, 'total', 'Senior Advertiser plan upgrade (yearly)', 'SENIOR_ADVERTISER_UPGRADE-hjlu9lhd64', '2025-11-21 23:09:42', 'pending'),
(521, 1, 'premium_upgrade', 2500.00, 'total', 'Senior Advertiser plan upgrade (yearly)', 'SENIOR_ADVERTISER_UPGRADE-t6fkbof1oc', '2025-11-21 23:13:59', 'pending'),
(522, 47, 'invite_commission', 500.00, '', 'Word upgraded to Premium plan - Commission', 'PREMIUM_UPGRADE-su6nhcfughl', '2025-11-22 06:29:55', 'pending'),
(523, 51, 'premium_upgrade', 1500.00, 'total', 'Premium membership upgrade', 'PREMIUM_UPGRADE-su6nhcfughl', '2025-11-22 06:29:55', 'pending'),
(524, 51, 'task_reward', 28.00, 'activity_earnings', 'Completed task: Cghgcg', 'TASK-527', '2025-11-22 06:31:52', 'pending'),
(525, 51, 'task_reward', 300.00, 'activity_earnings', 'Completed task: Follow Me Obodo', 'TASK-528', '2025-11-22 06:34:06', 'pending'),
(526, 47, 'chat_earn_reward', 250.00, NULL, 'Chat & Earn  Reward', NULL, '2025-11-22 06:46:11', 'completed'),
(527, 47, 'task_reward', 28.00, 'activity_earnings', 'Completed task: Cghgcg', 'TASK-529', '2025-11-22 06:51:01', 'pending'),
(528, 47, 'invite_commission', 1000.00, '', 'Word upgraded to Premium Plus plan - Commission', 'SENIOR_ADVERTISER_UPGRADE-8gttoghnwsi', '2025-11-22 06:54:36', 'pending'),
(529, 51, 'premium_upgrade', 2500.00, 'total', 'Senior Advertiser plan upgrade (yearly)', 'SENIOR_ADVERTISER_UPGRADE-8gttoghnwsi', '2025-11-22 06:54:36', 'pending'),
(530, 51, 'stream_earning', 700.00, '', 'Streamed: Billionaires Club', NULL, '2025-11-22 06:55:18', 'pending'),
(531, 51, 'chat_earn_reward', 250.00, NULL, 'Chat & Earn  Reward', NULL, '2025-11-22 07:00:05', 'completed'),
(532, 54, 'ad_purchase', 1085.00, 'prime_earnings', 'Posted task: Big kc on Facebook for 31 participants', 'TASK-38', '2025-11-22 07:09:00', 'pending'),
(533, 47, '', 54.25, '', '5% Advertisement Commission - Downline task posting (₦1085) on Facebook', 'UPLINE-AD-COMM-38', '2025-11-22 07:09:00', 'pending'),
(534, 47, 'task_reward', 25.00, 'activity_earnings', 'Completed task: Big kc', 'TASK-530', '2025-11-22 07:15:02', 'pending'),
(535, 46, 'invite_commission', 500.00, '', 'Mechack001 upgraded to Premium plan - Commission', 'PREMIUM_UPGRADE-5k58t5m6mzs', '2025-11-22 08:04:20', 'pending'),
(536, 53, 'premium_upgrade', 1500.00, 'total', 'Premium membership upgrade', 'PREMIUM_UPGRADE-5k58t5m6mzs', '2025-11-22 08:04:20', 'pending'),
(537, 46, 'deposit', 400000.00, 'prime_earnings', 'Deposit for General Balance', 'DEPOSIT-4jv59dnebn', '2025-11-22 15:47:15', 'pending'),
(538, 46, 'deposit', 101000.00, 'prime_earnings', 'Deposit for General Balance', 'DEPOSIT-lbdqzjkmo5i', '2025-11-22 15:52:05', 'pending'),
(539, 47, 'chat_earn_reward', 250.00, NULL, 'Chat & Earn  Reward', NULL, '2025-11-23 10:24:03', 'completed'),
(540, 46, 'chat_earn_reward', 250.00, NULL, 'Chat & Earn  Reward', NULL, '2025-11-23 10:32:51', 'completed'),
(541, 50, 'chat_earn_reward', 250.00, NULL, 'Chat & Earn  Reward', NULL, '2025-11-23 10:39:06', 'completed'),
(542, 46, 'ad_purchase', 3200.00, 'prime_earnings', 'Posted task: Make sure you engage on it on TikTok for 100 participants', 'TASK-39', '2025-11-23 10:56:20', 'pending'),
(543, 1, 'chat_earn_reward', 250.00, NULL, 'Chat & Earn  Reward', NULL, '2025-11-23 13:31:10', 'completed'),
(544, 47, 'invite_commission', 1000.00, '', 'Cat020 upgraded to Premium Plus plan - Commission', 'SENIOR_ADVERTISER_UPGRADE-twz4jpwh26', '2025-11-23 15:40:06', 'pending'),
(545, 54, 'premium_upgrade', 2500.00, 'total', 'Senior Advertiser plan upgrade (yearly)', 'SENIOR_ADVERTISER_UPGRADE-twz4jpwh26', '2025-11-23 15:40:06', 'pending'),
(546, 46, 'invite_commission', 1000.00, '', 'Mechack001 upgraded to Premium Plus plan - Commission', 'SENIOR_ADVERTISER_UPGRADE-2bay7zw3zrl', '2025-11-23 16:06:28', 'pending'),
(547, 53, 'premium_upgrade', 2500.00, 'total', 'Senior Advertiser plan upgrade (yearly)', 'SENIOR_ADVERTISER_UPGRADE-2bay7zw3zrl', '2025-11-23 16:06:28', 'pending'),
(548, 51, 'task_reward', 20.00, 'activity_earnings', 'Completed task: Follow my tiktok account', 'TASK-533', '2025-11-23 16:22:43', 'pending'),
(549, 50, 'task_reward', 20.00, 'activity_earnings', 'Completed task: Follow my tiktok account', 'TASK-534', '2025-11-23 16:30:24', 'pending'),
(550, 50, 'task_reward', 22.00, 'activity_earnings', 'Completed task: Just testing', 'TASK-535', '2025-11-23 16:32:55', 'pending'),
(551, 46, 'ad_purchase', 1500.00, 'prime_earnings', 'Posted task: Audio on Audiomack for 50 participants', 'TASK-40', '2025-11-24 11:38:16', 'pending'),
(552, 46, 'ad_purchase', 3500.00, 'prime_earnings', 'Posted task: Paly on PlayStore for 50 participants', 'TASK-41', '2025-11-24 11:44:50', 'pending'),
(553, 46, 'ad_purchase', 1750.00, 'prime_earnings', 'Posted task: Pinterest on Pinterest for 50 participants', 'TASK-42', '2025-11-24 11:46:42', 'pending'),
(554, 46, 'ad_purchase', 2000.00, 'prime_earnings', 'Posted task: Spotify on Spotify for 50 participants', 'TASK-43', '2025-11-24 11:48:11', 'pending'),
(555, 46, 'ad_purchase', 2250.00, 'prime_earnings', 'Posted task: Boomplay on Boomplay for 50 participants', 'TASK-44', '2025-11-24 11:50:59', 'pending'),
(556, 1, 'task_reward', 37.00, 'activity_earnings', 'Completed task: Testing', 'TASK-546', '2025-11-24 12:31:44', 'pending'),
(557, 1, 'task_reward', 20.00, 'activity_earnings', 'Completed task: Make sure you engage on it', 'TASK-548', '2025-11-24 12:39:13', 'pending'),
(558, 1, 'task_reward', 37.00, 'activity_earnings', 'Completed task: Website Task', 'TASK-551', '2025-11-24 12:44:40', 'pending'),
(560, 57, 'premium_upgrade', 2500.00, 'total', 'Senior Advertiser plan upgrade (yearly)', 'SENIOR_ADVERTISER_UPGRADE-dz6qfq2qs2f', '2025-11-24 13:58:24', 'pending'),
(561, 57, 'task_reward', 30.00, 'activity_earnings', 'Completed task: Testing task', 'TASK-555', '2025-11-24 13:59:27', 'pending'),
(562, 57, 'task_reward', 20.00, 'activity_earnings', 'Completed task: Audio', 'TASK-556', '2025-11-24 14:04:56', 'pending'),
(563, 57, 'task_reward', 20.00, 'activity_earnings', 'Completed task: Follow Me Emeka', 'TASK-557', '2025-11-24 14:08:55', 'pending'),
(564, 1, 'video_earning', 500.00, '', 'Watched video: Ewo', NULL, '2025-11-24 17:35:59', 'pending'),
(565, 1, 'video_earning', 500.00, '', 'Watched video: Sometimes', NULL, '2025-11-24 18:16:45', 'pending'),
(566, 1, 'video_earning', 500.00, 'activity_earnings', 'Watched video: Jelo', NULL, '2025-11-24 18:43:44', 'pending'),
(568, 54, 'task_reward', 30.00, 'activity_earnings', 'Completed task: Boomplay', 'TASK-558', '2025-11-24 20:50:22', 'pending'),
(569, 54, 'ad_purchase', 350.00, 'prime_earnings', 'Posted task: Follow the page on Facebook for 10 participants', 'TASK-45', '2025-11-24 21:40:09', 'pending'),
(570, 47, '', 17.50, '', '5% Advertisement Commission - Downline task posting (₦350) on Facebook', 'UPLINE-AD-COMM-45', '2025-11-24 21:40:09', 'pending'),
(571, 54, 'ad_purchase', 700.00, 'prime_earnings', 'Extended task: Big kc by 20 participants', 'EXTEND-38', '2025-11-24 21:43:25', 'pending'),
(572, 54, 'ad_purchase', 350.00, 'prime_earnings', 'Extended task: Follow the page by 10 participants', 'EXTEND-45', '2025-11-24 21:44:50', 'pending'),
(573, 54, 'task_reward', 25.00, 'activity_earnings', 'Completed task: Big kc', 'TASK-561', '2025-11-24 22:02:01', 'pending'),
(574, 47, 'task_reward', 30.00, 'activity_earnings', 'Completed task: Boomplay', 'TASK-563', '2025-11-24 22:15:34', 'pending'),
(575, 47, 'task_reward', 20.00, 'activity_earnings', 'Completed task: Follow Me Emeka name', 'TASK-564', '2025-11-24 22:17:16', 'pending'),
(576, 59, 'premium_upgrade', 1500.00, 'total', 'Premium membership upgrade', 'PREMIUM_UPGRADE-tqkxlqnl8mc', '2025-11-25 07:24:51', 'pending'),
(577, 58, 'premium_upgrade', 1500.00, 'total', 'Premium membership upgrade', 'PREMIUM_UPGRADE-p5fb1foqb6k', '2025-11-25 07:26:43', 'pending'),
(578, 59, '', 640.00, 'prime_earnings', 'Posted task: Join on WhatsApp for 20 participants', 'TASK_729220867', '2025-11-25 07:39:30', 'pending'),
(579, 58, 'invite_commission', 500.00, '', 'Busy upgraded to Premium Plus plan - Commission', 'SENIOR_ADVERTISER_UPGRADE-yp8ywg0l31t', '2025-11-25 07:43:54', 'pending'),
(580, 59, 'premium_upgrade', 2500.00, 'total', 'Senior Advertiser plan upgrade (yearly)', 'SENIOR_ADVERTISER_UPGRADE-yp8ywg0l31t', '2025-11-25 07:43:54', 'pending'),
(581, 58, 'task_reward', 25.00, 'activity_earnings', 'Completed task: Follow the page', 'TASK-569', '2025-11-25 07:54:56', 'pending'),
(582, 59, 'task_reward', 25.00, 'activity_earnings', 'Completed task: Follow the page', 'TASK-570', '2025-11-25 07:59:03', 'pending'),
(583, 59, 'task_reward', 22.00, 'activity_earnings', 'Completed task: Tino', 'TASK-571', '2025-11-25 08:02:43', 'pending'),
(584, 59, 'video_earning', 500.00, 'activity_earnings', 'Watched video: Ewo', NULL, '2025-11-25 08:05:43', 'pending'),
(585, 59, 'stream_earning', 700.00, '', 'Streamed: Billionaires Club', NULL, '2025-11-25 08:06:29', 'pending'),
(586, 60, 'premium_upgrade', 1500.00, 'total', 'Premium membership upgrade', 'PREMIUM_UPGRADE-3g8d5nhbths', '2025-11-25 08:21:28', 'pending'),
(587, 60, 'premium_upgrade', 2500.00, 'total', 'Senior Advertiser plan upgrade (yearly)', 'SENIOR_ADVERTISER_UPGRADE-ivt8n1tkhb', '2025-11-25 08:21:42', 'pending'),
(588, 47, 'daily_reward', 100.00, '', 'Daily login reward claimed - Day 1', NULL, '2025-11-25 14:52:00', 'pending'),
(589, 47, 'deposit', 10000.00, 'prime_earnings', 'Deposit for General Balance', 'DEPOSIT-gcbyfvoie3m', '2025-11-25 15:22:47', 'pending'),
(590, 59, 'task_reward', 20.00, 'activity_earnings', 'Completed task: Sksksj snsjsjs sjsjsjs sjsjsj', 'TASK-572', '2025-11-26 17:41:33', 'pending'),
(591, 59, 'task_reward', 37.00, 'activity_earnings', 'Completed task: Website Task', 'TASK-573', '2025-11-26 17:42:41', 'pending'),
(594, 52, 'premium_upgrade', 2500.00, 'total', 'Senior Advertiser plan upgrade (yearly)', 'SENIOR_ADVERTISER_UPGRADE-ht6ecskw13', '2025-11-27 11:34:43', 'pending'),
(595, 52, 'stream_earning', 700.00, '', 'Streamed: Billionaires Club', NULL, '2025-11-27 11:44:51', 'pending'),
(596, 1, 'invite_commission', 500.00, '', '@Ebere123 upgraded to Premium Plus plan - Commission', 'SENIOR_ADVERTISER_UPGRADE-el5vfg7aynp', '2025-11-27 18:02:40', 'pending'),
(597, 61, 'premium_upgrade', 2500.00, 'total', 'Premium Plus plan upgrade (yearly)', 'SENIOR_ADVERTISER_UPGRADE-el5vfg7aynp', '2025-11-27 18:02:40', 'pending'),
(598, 1, 'invite_commission', 500.00, '', 'testingpremiumPlus upgraded to Premium Plus plan - Commission', 'PREMIUM_PLUS_UPGRADE-ncvxj2xvwd', '2025-11-27 18:30:25', 'pending'),
(599, 62, 'premium_upgrade', 2500.00, 'total', 'Premium Plus plan upgrade (yearly)', 'PREMIUM_PLUS_UPGRADE-ncvxj2xvwd', '2025-11-27 18:30:25', 'pending'),
(600, 59, 'deposit', 1000.00, 'prime_earnings', 'Deposit for General Balance', 'DEPOSIT-ebxkg3bwjul', '2025-11-27 19:10:07', 'pending'),
(601, 59, 'task_reward', 300.00, 'activity_earnings', 'Completed task: Follow Me Obodo', 'TASK-574', '2025-11-27 19:16:12', 'pending'),
(602, 58, 'task_reward', 300.00, 'activity_earnings', 'Completed task: Follow Me Obodo', 'TASK-575', '2025-11-27 19:19:01', 'pending'),
(603, 58, 'premium_upgrade', 2500.00, 'total', 'Premium Plus plan upgrade (yearly)', 'PREMIUM_PLUS_UPGRADE-cdb1s5h9ce', '2025-11-27 19:23:05', 'pending'),
(604, 46, 'invite_commission', 1000.00, '', 'King1 upgraded to Premium Plus plan - Commission', 'PREMIUM_PLUS_UPGRADE-g54t3lrdhte', '2025-11-27 20:06:43', 'pending'),
(605, 63, 'premium_upgrade', 2500.00, 'total', 'Premium Plus plan upgrade (yearly)', 'PREMIUM_PLUS_UPGRADE-g54t3lrdhte', '2025-11-27 20:06:43', 'pending'),
(606, 63, 'stream_earning', 700.00, 'activity_earnings', 'Streamed: Billionaires Club', NULL, '2025-11-27 21:20:33', 'pending'),
(607, 1, '', 0.00, '', 'Plinko Game - Bet: ₦1,000.00 | Multiplier: 0x | Win: ₦0.00', 'PLINKO_1764278813_1', '2025-11-27 21:26:53', 'pending'),
(608, 63, 'stream_earning', 700.00, 'activity_earnings', 'Streamed: Olamide', NULL, '2025-11-27 21:28:20', 'pending'),
(609, 1, '', 2500.00, '', 'Plinko Game - Bet: ₦1,000.00 | Multiplier: 2.5x | Win: ₦2,500.00', 'PLINKO_1764279576_1', '2025-11-27 21:39:36', 'pending'),
(610, 1, '', 500.00, '', 'Plinko Game - Bet: ₦1,000.00 | Multiplier: 0.5x | Win: ₦500.00', 'PLINKO_1764279619_1', '2025-11-27 21:40:19', 'pending'),
(611, 1, '', 2500.00, '', 'Plinko Game - Bet: ₦1,000.00 | Multiplier: 2.5x | Win: ₦2,500.00', 'PLINKO_1764279637_1', '2025-11-27 21:40:37', 'pending'),
(612, 1, '', 250.00, '', 'Plinko Game - Bet: ₦1,000.00 | Multiplier: 0.25x | Win: ₦250.00', 'PLINKO_1764279653_1', '2025-11-27 21:40:53', 'pending'),
(613, 1, '', 250.00, '', 'Plinko Game - Bet: ₦1,000.00 | Multiplier: 0.25x | Win: ₦250.00', 'PLINKO_1764279677_1', '2025-11-27 21:41:17', 'pending'),
(614, 1, '', 1500.00, '', 'Plinko Game - Bet: ₦1,000.00 | Multiplier: 1.5x | Win: ₦1,500.00', 'PLINKO_1764279752_1', '2025-11-27 21:42:32', 'pending'),
(615, 1, '', 1500.00, '', 'Plinko Game - Bet: ₦1,000.00 | Multiplier: 1.5x | Win: ₦1,500.00', 'PLINKO_1764279779_1', '2025-11-27 21:42:59', 'pending'),
(616, 1, '', 250.00, '', 'Plinko Game - Bet: ₦1,000.00 | Multiplier: 0.25x | Win: ₦250.00', 'PLINKO_1764280133_1', '2025-11-27 21:48:53', 'pending'),
(617, 1, '', 1500.00, '', 'Plinko Game - Bet: ₦1,000.00 | Multiplier: 1.5x | Win: ₦1,500.00', 'PLINKO_1764280153_1', '2025-11-27 21:49:13', 'pending'),
(618, 1, '', 1500.00, '', 'Plinko Game - Bet: ₦1,000.00 | Multiplier: 1.5x | Win: ₦1,500.00', 'PLINKO_1764280172_1', '2025-11-27 21:49:32', 'pending'),
(619, 1, '', 500.00, '', 'Plinko Game - Bet: ₦1,000.00 | Multiplier: 0.5x | Win: ₦500.00', 'PLINKO_1764280188_1', '2025-11-27 21:49:48', 'pending'),
(620, 1, '', 4000.00, '', 'Plinko Game - Bet: ₦1,000.00 | Multiplier: 4x | Win: ₦4,000.00', 'PLINKO_1764280764_1', '2025-11-27 21:59:24', 'pending'),
(621, 1, '', 500.00, '', 'Plinko Game - Bet: ₦1,000.00 | Multiplier: 0.5x | Win: ₦500.00', 'PLINKO_1764280859_1', '2025-11-27 22:00:59', 'pending'),
(622, 1, '', 1500.00, '', 'Plinko Game - Bet: ₦1,000.00 | Multiplier: 1.5x | Win: ₦1,500.00', 'PLINKO_1764280875_1', '2025-11-27 22:01:15', 'pending'),
(623, 1, '', 1500.00, '', 'Plinko Game - Bet: ₦1,000.00 | Multiplier: 1.5x | Win: ₦1,500.00', 'PLINKO_1764280887_1', '2025-11-27 22:01:27', 'pending'),
(624, 1, '', 500.00, '', 'Plinko Game - Bet: ₦1,000.00 | Multiplier: 0.5x | Win: ₦500.00', 'PLINKO_1764280909_1', '2025-11-27 22:01:49', 'pending'),
(625, 1, '', 1000.00, '', 'Keno Game - Bet: ₦1,000.00 | Matches: 3 | Win: ₦1,000.00', 'KENO_1764281391_1', '2025-11-27 22:09:51', 'pending'),
(626, 1, '', 0.00, '', 'Keno Game - Bet: ₦1,000.00 | Matches: 1 | Win: ₦0.00', 'KENO_1764281406_1', '2025-11-27 22:10:06', 'pending'),
(627, 1, '', 1500.00, '', 'Keno Game - Bet: ₦1,000.00 | Matches: 4 | Win: ₦1,500.00', 'KENO_1764281418_1', '2025-11-27 22:10:18', 'pending'),
(628, 1, '', 1500.00, '', 'Keno Game - Bet: ₦1,000.00 | Matches: 4 | Win: ₦1,500.00', 'KENO_1764281452_1', '2025-11-27 22:10:52', 'pending'),
(629, 1, '', 0.00, '', 'Keno Game - Bet: ₦1,000.00 | Matches: 2 | Win: ₦0.00', 'KENO_1764281477_1', '2025-11-27 22:11:17', 'pending'),
(630, 1, '', 3000.00, '', 'Spin & Win - Bet: ₦1,000.00 | Result: x3.0 | Win: ₦3,000.00', 'SPIN_1764281661_1', '2025-11-27 22:14:21', 'pending'),
(631, 1, '', 0.00, '', 'Spin & Win - Bet: ₦1,000.00 | Result: Empty | Win: ₦0.00', 'SPIN_1764282215_1', '2025-11-27 22:23:35', 'pending'),
(632, 1, '', 1200.00, '', 'Spin & Win - Bet: ₦1,000.00 | Result: x1.2 | Win: ₦1,200.00', 'SPIN_1764282323_1', '2025-11-27 22:25:23', 'pending'),
(633, 1, '', 0.00, '', 'Spin & Win - Bet: ₦1,000.00 | Result: Empty | Win: ₦0.00', 'SPIN_1764282353_1', '2025-11-27 22:25:53', 'pending'),
(634, 1, '', 1200.00, '', 'Spin & Win - Bet: ₦1,000.00 | Result: x1.2 | Win: ₦1,200.00', 'SPIN_1764283696_1', '2025-11-27 22:48:16', 'pending'),
(635, 1, '', 2000.00, '', 'Spin & Win - Bet: ₦1,000.00 | Result: x2.0 | Win: ₦2,000.00', 'SPIN_1764283759_1', '2025-11-27 22:49:19', 'pending'),
(636, 1, '', 1500.00, '', 'Spin & Win - Bet: ₦1,000.00 | Result: x1.5 | Win: ₦1,500.00', 'SPIN_1764284112_1', '2025-11-27 22:55:12', 'pending'),
(637, 1, '', 0.00, '', 'Spin & Win - Bet: ₦1,000.00 | Result: Empty | Win: ₦0.00', 'SPIN_1764284164_1', '2025-11-27 22:56:04', 'pending'),
(638, 1, '', 0.00, '', 'Spin & Win - Bet: ₦1,000.00 | Result: Empty | Win: ₦0.00', 'SPIN_1764284460_1', '2025-11-27 23:01:00', 'pending'),
(639, 1, '', 2000.00, '', 'Coin Toss - Bet: ₦1,000.00 | Choice: Tails | Result: Tails | Win: ₦2,000.00', 'COINTOSS_1764285323_1', '2025-11-27 23:15:23', 'pending'),
(640, 1, '', 0.00, '', 'Coin Toss - Bet: ₦1,000.00 | Choice: Heads | Result: Tails | Win: ₦0.00', 'COINTOSS_1764286230_1', '2025-11-27 23:30:30', 'pending'),
(641, 1, '', 2000.00, '', 'Coin Toss - Bet: ₦1,000.00 | Choice: Tails | Result: Tails | Win: ₦2,000.00', 'COINTOSS_1764286753_1', '2025-11-27 23:39:13', 'pending'),
(642, 1, '', 0.00, '', 'Dice Roll - Bet: ₦1,000.00 | Choice: Low | Result: 5 + 5 = 10 | Win: ₦0.00', 'DICEROLL_1764287711_1', '2025-11-27 23:55:11', 'pending'),
(643, 1, '', 0.00, '', 'Dice Roll - Bet: ₦1,000.00 | Choice: High | Result: 2 + 2 = 4 | Win: ₦0.00', 'DICEROLL_1764287759_1', '2025-11-27 23:55:59', 'pending'),
(644, 1, '', 284.00, '', 'Temple Run - Distance: 284m | Coins: ₦0.00 | Total Reward: ₦284.00', 'TEMPLERUN_1764289369_1', '2025-11-28 00:22:49', 'pending'),
(645, 1, '', 384.00, '', 'Temple Run - Distance: 284m | Coins: ₦100.00 | Total Reward: ₦384.00', 'TEMPLERUN_1764289379_1', '2025-11-28 00:22:59', 'pending'),
(646, 1, '', 1189.00, '', 'Temple Run - Distance: 889m | Coins: ₦300.00 | Total Reward: ₦1,189.00', 'TEMPLERUN_1764289447_1', '2025-11-28 00:24:07', 'pending'),
(647, 1, '', 2000.00, '', 'Mega Bingo - Bet: ₦1,000.00 | Pattern: Diagonal | Win: ₦2,000.00', 'BINGO_1764290799_1', '2025-11-28 00:46:39', 'pending'),
(648, 50, 'daily_reward', 100.00, '', 'Daily login reward claimed - Day 2', NULL, '2025-11-28 05:29:02', 'pending'),
(649, 50, 'stream_earning', 700.00, 'activity_earnings', 'Streamed: Olamide', NULL, '2025-11-28 06:45:37', 'pending'),
(650, 1, 'invite_commission', 1000.00, '', 'Stream&Earn upgraded to Premium Plus plan - Commission', 'PREMIUM_PLUS_UPGRADE-fge2jheqsn5', '2025-11-28 10:56:21', 'pending'),
(651, 64, 'premium_upgrade', 2500.00, 'total', 'Premium Plus plan upgrade (yearly)', 'PREMIUM_PLUS_UPGRADE-fge2jheqsn5', '2025-11-28 10:56:21', 'pending'),
(652, 64, 'task_reward', 300.00, 'activity_earnings', 'Completed task: Follow Me Obodo', 'TASK-576', '2025-11-28 11:05:13', 'pending'),
(653, 64, 'task_reward', 22.00, 'activity_earnings', 'Completed task: Follow my instagram account', 'TASK-577', '2025-11-28 11:06:12', 'pending'),
(654, 54, 'video_earning', 70.00, 'activity_earnings', 'Watched video: ObodoNwoke', NULL, '2025-11-28 16:40:51', 'pending'),
(655, 1, 'withdrawal', 200.00, 'prime_earnings', 'Prime_earnings withdrawal of ₦200.00', 'WD-59', '2025-11-28 20:35:17', 'pending'),
(656, 1, 'withdrawal', 500.00, 'prime_earnings', 'Prime_earnings withdrawal of ₦500.00', 'WD-60', '2025-11-28 21:18:56', 'pending'),
(657, 1, 'withdrawal', 500.00, 'prime_earnings', 'Prime_earnings withdrawal of ₦500.00', 'WD-61', '2025-11-28 21:35:46', 'pending'),
(658, 1, 'withdrawal', 300.00, 'prime_earnings', 'Prime_earnings withdrawal of ₦300.00', 'WD-62', '2025-11-28 22:11:56', 'pending'),
(659, 1, 'withdrawal', 350.00, 'prime_earnings', 'Prime_earnings withdrawal of ₦350.00', 'WD-63', '2025-11-28 22:25:36', 'pending'),
(660, 54, 'withdrawal', 360.00, 'prime_earnings', 'Prime_earnings withdrawal of ₦360.00', 'WD-64', '2025-11-29 04:47:01', 'pending'),
(661, 46, 'withdrawal', 200.00, 'prime_earnings', 'Prime_earnings withdrawal of ₦200.00', 'WD-65', '2025-11-29 06:09:13', 'pending'),
(662, 54, 'withdrawal', 2000.00, 'prime_earnings', 'Prime_earnings withdrawal of ₦2,000.00', 'WD-66', '2025-11-29 09:26:41', 'pending'),
(663, 54, 'withdrawal', 3200.00, 'prime_earnings', 'Prime_earnings withdrawal of ₦3,200.00', 'WD-73', '2025-11-29 15:07:58', 'pending'),
(664, 47, 'withdrawal', 300.00, 'prime_earnings', 'Prime_earnings withdrawal of ₦300.00', 'WD-74', '2025-11-29 16:21:18', 'pending'),
(665, 46, 'video_earning', 70.00, 'activity_earnings', 'Watched video: ObodoNwoke', NULL, '2025-11-29 16:57:54', 'pending'),
(666, 1, 'stream_earning', 1200.00, 'activity_earnings', 'Streamed: Testing admin track again', NULL, '2025-11-29 19:42:56', 'pending'),
(667, 1, 'invite_commission', 1000.00, '', 'Stream&Earn upgraded to Premium Plus plan - Commission', 'PREMIUM_PLUS_UPGRADE-5ek2bk8jl9k', '2025-11-29 19:45:09', 'pending'),
(668, 64, 'premium_upgrade', 2500.00, 'total', 'Premium Plus plan upgrade (yearly)', 'PREMIUM_PLUS_UPGRADE-5ek2bk8jl9k', '2025-11-29 19:45:09', 'pending'),
(669, 1, 'withdrawal', 200.00, 'prime_earnings', 'Prime_earnings withdrawal of ₦200.00', 'WD-75', '2025-11-29 20:00:43', 'pending'),
(670, 1, 'withdrawal', 200.00, 'prime_earnings', 'Prime_earnings withdrawal of ₦200.00', 'WD-76', '2025-11-29 20:02:54', 'pending'),
(671, 1, 'ad_purchase', 1400.00, 'prime_earnings', 'Posted task: Follow emeka on Facebook for 40 participants', 'TASK-50', '2025-11-29 22:50:59', 'pending'),
(672, 54, 'task_reward', 20.00, 'activity_earnings', 'Completed task: Follow fast', 'TASK-578', '2025-11-30 09:49:18', 'pending'),
(673, 54, 'withdrawal', 200.00, 'prime_earnings', 'Prime_earnings withdrawal of ₦200.00', 'WD-77', '2025-11-30 09:51:20', 'pending'),
(674, 1, '', 320.00, 'prime_earnings', 'Posted task: follow us on TikTok for 10 participants', 'TASK_682410748', '2025-11-30 19:53:25', 'pending'),
(675, 47, 'ad_purchase', 320.00, 'prime_earnings', 'Posted task: Hjyg on WhatsApp for 10 participants', 'TASK-52', '2025-11-30 22:25:32', 'pending'),
(676, 47, 'ad_purchase', 320.00, 'prime_earnings', 'Posted task: Now on Telegram for 10 participants', 'TASK-53', '2025-11-30 22:27:39', 'pending'),
(677, 54, 'withdrawal', 1000.00, 'prime_earnings', 'Prime_earnings withdrawal of ₦1,000.00', 'WD-78', '2025-12-01 07:22:18', 'pending'),
(678, 54, 'video_earning', 900.00, 'activity_earnings', 'Watched video: Testing Again', NULL, '2025-12-01 07:49:42', 'pending'),
(679, 54, 'ad_purchase', 1600.00, 'prime_earnings', 'Posted task: Good day on WhatsApp for 50 participants', 'TASK-54', '2025-12-01 08:13:21', 'pending'),
(680, 47, '', 80.00, '', '5% Advertisement Commission - Downline task posting (₦1600) on WhatsApp', 'UPLINE-AD-COMM-54', '2025-12-01 08:13:21', 'pending'),
(681, 54, 'ad_purchase', 3200.00, 'prime_earnings', 'Posted task: My Joy on WhatsApp for 100 participants', 'TASK-55', '2025-12-01 08:14:30', 'pending'),
(682, 47, '', 160.00, '', '5% Advertisement Commission - Downline task posting (₦3200) on WhatsApp', 'UPLINE-AD-COMM-55', '2025-12-01 08:14:30', 'pending'),
(683, 54, 'withdrawal', 1000.00, 'prime_earnings', 'Prime_earnings withdrawal of ₦1,000.00', 'WD-79', '2025-12-01 08:57:38', 'pending'),
(684, 1, 'ad_purchase', 320.00, 'prime_earnings', 'Posted task: follow emeka on TikTok for 10 participants', 'TASK-56', '2025-12-01 11:00:15', 'pending'),
(685, 1, 'ad_purchase', 350.00, 'prime_earnings', 'Posted task: Testing on Facebook for 10 participants', 'TASK-57', '2025-12-01 11:37:55', 'pending'),
(686, 1, 'ad_purchase', 350.00, 'prime_earnings', 'Posted task: Testing post task on Instagram for 10 participants', 'TASK-58', '2025-12-01 11:40:39', 'pending'),
(687, 54, 'withdrawal', 20000.00, 'prime_earnings', 'Prime_earnings withdrawal of ₦20,000.00', 'WD-80', '2025-12-01 13:26:46', 'pending'),
(688, 54, 'withdrawal', 30000.00, 'prime_earnings', 'Prime_earnings withdrawal of ₦30,000.00', 'WD-81', '2025-12-01 13:32:25', 'pending'),
(689, 54, 'withdrawal', 10000.00, 'prime_earnings', 'Prime_earnings withdrawal of ₦10,000.00', 'WD-82', '2025-12-01 13:35:49', 'pending'),
(690, 54, 'withdrawal', 23000.00, 'prime_earnings', 'Prime_earnings withdrawal of ₦23,000.00', 'WD-83', '2025-12-01 13:40:40', 'pending'),
(691, 54, 'withdrawal', 20000.00, 'prime_earnings', 'Prime_earnings withdrawal of ₦20,000.00', 'WD-84', '2025-12-01 13:42:26', 'pending'),
(692, 54, 'withdrawal', 10000.00, 'prime_earnings', 'Prime_earnings withdrawal of ₦10,000.00', 'WD-85', '2025-12-01 13:43:44', 'pending'),
(693, 54, 'withdrawal', 10000.00, 'prime_earnings', 'Prime_earnings withdrawal of ₦10,000.00', 'WD-86', '2025-12-01 13:44:14', 'pending'),
(694, 1, 'ad_purchase', 350.00, 'prime_earnings', 'Extended task: Testing post task by 10 participants', 'EXTEND-58', '2025-12-01 13:52:55', 'pending'),
(695, 47, 'deposit', 10000.00, 'prime_earnings', 'Deposit for Publishing Advertisements', 'DEPOSIT-qna107bxgkj', '2025-12-01 15:33:22', 'pending'),
(696, 63, 'stream_earning', 50.00, 'activity_earnings', 'Streamed: Obodo Dev', NULL, '2025-12-01 17:24:39', 'pending'),
(697, 63, 'stream_earning', 50.00, 'activity_earnings', 'Streamed: Testing', NULL, '2025-12-01 17:31:06', 'pending'),
(698, 63, 'task_reward', 22.00, 'activity_earnings', 'Completed task: Hjyg', 'TASK-579', '2025-12-01 17:41:33', 'pending'),
(699, 1, 'stream_earning', 50.00, 'activity_earnings', 'Streamed: Obodo Dev', NULL, '2025-12-01 23:14:48', 'pending'),
(700, 1, 'stream_earning', 50.00, 'activity_earnings', 'Streamed: Testing', NULL, '2025-12-01 23:43:11', 'pending'),
(701, 47, 'task_reward', 22.00, 'activity_earnings', 'Completed task: Hjyg', 'TASK-580', '2025-12-02 10:53:15', 'pending'),
(702, 54, 'video_earning', 75.00, 'activity_earnings', 'Watched video: Watch well', NULL, '2025-12-02 11:24:13', 'pending'),
(703, 54, 'video_earning', 500.00, 'activity_earnings', 'Watched video: Ewo', NULL, '2025-12-02 11:30:27', 'pending'),
(704, 54, 'video_earning', 75.00, 'activity_earnings', 'Watched video: Good', NULL, '2025-12-02 11:33:16', 'pending'),
(705, 47, 'task_reward', 20.00, 'activity_earnings', 'Completed task: follow emeka', 'TASK-581', '2025-12-02 11:58:56', 'pending'),
(708, 47, 'deposit', 10000.00, 'prime_earnings', 'Deposit for General Balance', 'DEPOSIT-abbap0anvae', '2025-12-02 14:11:12', 'pending'),
(709, 54, 'task_reward', 22.00, 'activity_earnings', 'Completed task: Now', 'TASK-582', '2025-12-02 14:22:33', 'pending'),
(710, 54, 'task_reward', 22.00, 'activity_earnings', 'Completed task: Hjyg', 'TASK-583', '2025-12-02 14:24:15', 'pending'),
(711, 64, 'stream_earning', 50.00, 'activity_earnings', 'Streamed: Testing', NULL, '2025-12-02 14:27:53', 'pending'),
(712, 47, 'invite_commission', 1000.00, '', 'Cat020 upgraded to Premium Plus plan - Commission', 'PREMIUM_PLUS_UPGRADE-uhvih920xe', '2025-12-02 14:36:11', 'pending'),
(713, 54, 'premium_upgrade', 2500.00, 'total', 'Premium Plus plan upgrade (yearly)', 'PREMIUM_PLUS_UPGRADE-uhvih920xe', '2025-12-02 14:36:11', 'pending'),
(714, 47, 'invite_commission', 1000.00, '', 'Cat020 upgraded to Premium Plus plan - Commission', 'PREMIUM_PLUS_UPGRADE-uk63neq6igl', '2025-12-02 14:44:05', 'pending'),
(715, 54, 'premium_upgrade', 2500.00, 'total', 'Premium Plus plan upgrade (yearly)', 'PREMIUM_PLUS_UPGRADE-uk63neq6igl', '2025-12-02 14:44:05', 'pending'),
(716, 54, 'withdrawal', 10000.00, 'prime_earnings', 'Prime_earnings withdrawal of ₦10,000.00', 'WD-87', '2025-12-02 14:47:34', 'pending'),
(717, 54, 'deposit', 10000.00, 'prime_earnings', 'Deposit for General Balance', 'DEPOSIT-hlrtaf9j5q', '2025-12-02 14:54:44', 'pending'),
(718, 1, 'stream_earning', 50.00, 'activity_earnings', 'Streamed: Testing', NULL, '2025-12-02 15:24:28', 'pending'),
(719, 64, 'stream_earning', 50.00, 'activity_earnings', 'Streamed: Testing', NULL, '2025-12-02 15:33:13', 'pending'),
(720, 54, 'ad_purchase', 10500.00, 'prime_earnings', 'Posted task: Good day Chief please download up on PlayStore for 150 participants', 'TASK-59', '2025-12-02 16:43:56', 'pending'),
(721, 47, '', 525.00, '', '5% Advertisement Commission - Downline task posting (₦10500) on PlayStore', 'UPLINE-AD-COMM-59', '2025-12-02 16:43:56', 'pending'),
(722, 47, 'invite_commission', 500.00, '', 'Kenechukwu upgraded to Premium plan - Commission', 'PREMIUM_UPGRADE-my35qwqe89k', '2025-12-03 08:57:35', 'pending'),
(723, 67, 'premium_upgrade', 1500.00, 'total', 'Premium membership upgrade', 'PREMIUM_UPGRADE-my35qwqe89k', '2025-12-03 08:57:35', 'pending'),
(724, 47, 'invite_commission', 1000.00, '', 'Kenechukwu upgraded to Premium Plus plan - Commission', 'PREMIUM_PLUS_UPGRADE-6w0og61vwvx', '2025-12-03 09:02:58', 'pending'),
(725, 67, 'premium_upgrade', 2500.00, 'total', 'Premium Plus plan upgrade (yearly)', 'PREMIUM_PLUS_UPGRADE-6w0og61vwvx', '2025-12-03 09:02:58', 'pending'),
(726, 47, 'task_reward', 50.00, 'activity_earnings', 'Completed task: Good day Chief please download up', 'TASK-584', '2025-12-03 15:50:20', 'pending'),
(727, 47, 'invite_commission', 1000.00, '', 'Karen upgraded to Premium Plus plan - Commission', 'PREMIUM_PLUS_UPGRADE-838jqe6yf6b', '2025-12-03 21:24:03', 'pending'),
(728, 69, 'premium_upgrade', 2500.00, 'total', 'Premium Plus plan upgrade (yearly)', 'PREMIUM_PLUS_UPGRADE-838jqe6yf6b', '2025-12-03 21:24:03', 'pending'),
(729, 47, 'withdrawal', 26000.00, 'activity_earnings', 'Activity_earnings withdrawal of ₦26,000.00', 'WD-88', '2025-12-03 21:28:40', 'pending'),
(730, 47, 'withdrawal', 10000.00, 'prime_earnings', 'Prime_earnings withdrawal of ₦10,000.00', 'WD-89', '2025-12-03 22:14:05', 'pending'),
(731, 47, 'ad_purchase', 3200.00, 'prime_earnings', 'Posted task: Hhgffd good on on WhatsApp for 100 participants', 'TASK-60', '2025-12-04 06:15:08', 'pending'),
(732, 46, 'withdrawal', 50000.00, 'prime_earnings', 'Prime_earnings withdrawal of ₦50,000.00', 'WD-90', '2025-12-04 10:20:54', 'pending'),
(733, 1, 'task_reward', 22.00, 'activity_earnings', 'Completed task: Hhgffd good on', 'TASK-585', '2025-12-04 15:52:05', 'pending'),
(734, 1, 'invite_commission', 500.00, '', 'Stream&Earn upgraded to Premium plan - Commission', 'PREMIUM_UPGRADE-ewo3mppnchh', '2025-12-04 20:24:53', 'pending'),
(735, 64, 'premium_upgrade', 1500.00, 'total', 'Premium membership upgrade', 'PREMIUM_UPGRADE-ewo3mppnchh', '2025-12-04 20:24:53', 'pending'),
(736, 1, 'invite_commission', 1000.00, '', 'Stream&Earn upgraded to Premium Plus plan - Commission', 'PREMIUM_PLUS_UPGRADE-q7v8e6ftyhn', '2025-12-04 20:37:17', 'pending'),
(737, 64, 'premium_upgrade', 2500.00, 'total', 'Premium Plus plan upgrade (yearly)', 'PREMIUM_PLUS_UPGRADE-q7v8e6ftyhn', '2025-12-04 20:37:17', 'pending'),
(738, 1, 'invite_commission', 500.00, '', 'Stream&Earn upgraded to Premium plan - Commission', 'PREMIUM_UPGRADE-etnbazceadn', '2025-12-04 20:42:31', 'pending'),
(739, 64, 'premium_upgrade', 1500.00, 'total', 'Premium membership upgrade', 'PREMIUM_UPGRADE-etnbazceadn', '2025-12-04 20:42:31', 'pending'),
(740, 47, 'invite_commission', 1000.00, '', 'Cat020 upgraded to Premium Plus plan - Commission', 'PREMIUM_PLUS_UPGRADE-mtehh8jcza9', '2025-12-05 06:03:04', 'pending'),
(741, 54, 'premium_upgrade', 2500.00, 'total', 'Premium Plus plan upgrade (yearly)', 'PREMIUM_PLUS_UPGRADE-mtehh8jcza9', '2025-12-05 06:03:04', 'pending'),
(742, 64, 'deposit', 100000.00, 'prime_earnings', 'Deposit for General Balance', 'DEPOSIT-rp3wb0sidjr', '2025-12-05 16:43:46', 'pending'),
(743, 64, 'ad_purchase', 32000.00, 'prime_earnings', 'Posted task: Testing upline reward on WhatsApp for 1000 participants', 'TASK-61', '2025-12-05 16:45:05', 'pending'),
(744, 1, 'advertise_commission', 1600.00, '', '5% Advertisement Commission - Downline task posting (₦32000) on WhatsApp', 'UPLINE-AD-COMM-61', '2025-12-05 16:45:05', 'pending'),
(745, 64, 'ad_purchase', 20000.00, 'prime_earnings', 'Posted task: Testing upline company on YouTube for 500 participants', 'TASK-62', '2025-12-05 16:51:21', 'pending'),
(746, 1, 'advertise_commission', 1000.00, '', '5% Advertisement Commission - Downline task posting (₦20000) on YouTube', 'UPLINE-AD-COMM-62', '2025-12-05 16:51:21', 'pending'),
(747, 1, 'stream_earning', 50.00, 'activity_earnings', 'Streamed: Obodo Dev', NULL, '2025-12-06 16:33:50', 'pending'),
(748, 47, 'stream_earning', 50.00, 'activity_earnings', 'Streamed: Testing', NULL, '2025-12-08 11:14:36', 'pending'),
(749, 47, 'withdrawal', 1500.00, 'prime_earnings', 'Prime_earnings withdrawal of ₦1,500.00', 'WD-91', '2025-12-08 17:50:45', 'pending'),
(750, 47, 'withdrawal', 300.00, 'prime_earnings', 'Prime_earnings withdrawal of ₦300.00', 'WD-92', '2025-12-09 07:29:01', 'pending'),
(751, 1, 'withdrawal', 500.00, 'activity_earnings', 'Activity_earnings withdrawal of ₦500.00', 'WD-93', '2025-12-09 08:21:37', 'pending'),
(752, 1, 'withdrawal', 200.00, 'prime_earnings', 'Prime_earnings withdrawal of ₦200.00', 'WD-94', '2025-12-09 10:21:33', 'pending'),
(753, 47, 'ad_purchase', 3200.00, 'prime_earnings', 'Posted task: Join on WhatsApp for 100 participants', 'TASK-63', '2025-12-09 16:03:38', 'pending'),
(754, 47, 'withdrawal', 26000.00, 'activity_earnings', 'Activity_earnings withdrawal of ₦26,000.00', 'WD-95', '2025-12-09 19:07:56', 'pending'),
(756, 47, 'withdrawal', 200.00, 'prime_earnings', 'Prime_earnings withdrawal of ₦200.00', 'WD-96', '2025-12-10 12:49:58', 'pending'),
(757, 54, 'withdrawal', 200.00, 'prime_earnings', 'Prime_earnings withdrawal of ₦200.00', 'WD-97', '2025-12-10 13:14:32', 'pending'),
(758, 54, 'ad_purchase', 32000.00, 'prime_earnings', 'Posted task: Bbffff on WhatsApp for 1000 participants', 'TASK-64', '2025-12-10 13:42:42', 'pending'),
(759, 47, 'advertise_commission', 1600.00, '', '5% Advertisement Commission - Downline task posting (₦32000) on WhatsApp', 'UPLINE-AD-COMM-64', '2025-12-10 13:42:42', 'pending'),
(760, 1, 'deposit', 1000.00, 'prime_earnings', 'Deposit for General Balance', 'DEPOSIT-dkwzsrwfdt4', '2025-12-10 14:49:27', 'pending'),
(761, 1, 'deposit', 4000.00, 'prime_earnings', 'Deposit for General Balance', 'DEPOSIT-bh01ckts2a', '2025-12-10 14:50:07', 'pending'),
(762, 1, 'deposit', 1000.00, 'prime_earnings', 'Deposit for General Balance', 'DEPOSIT-le45mkdzps', '2025-12-10 15:07:56', 'pending'),
(763, 1, 'deposit', 2000.00, 'prime_earnings', 'Deposit for General Balance', 'DEPOSIT-z5ojuksel8p', '2025-12-11 11:21:09', 'pending'),
(764, 1, 'deposit', 19000.00, 'prime_earnings', 'Deposit for General Balance', 'EARNOVA-deposit-1-1765455143-5838', '2025-12-11 12:12:46', 'pending'),
(765, 1, 'deposit', 90000.00, 'prime_earnings', 'Deposit for General Balance', 'DEPOSIT-9bznzfw74p6', '2025-12-11 12:14:37', 'pending'),
(766, 1, 'premium_upgrade', 1500.00, 'total', 'Premium membership upgrade', 'EARNOVA-premium_upgrade-1-1765455418-5195', '2025-12-11 12:17:18', 'pending'),
(767, 1, 'premium_upgrade', 2500.00, 'total', 'Premium Plus plan upgrade (yearly)', 'PREMIUM_PLUS_UPGRADE-n01vfl1z95s', '2025-12-11 12:17:46', 'pending'),
(768, 1, 'deposit', 51000.00, 'prime_earnings', 'Deposit for General Balance', 'EARNOVA-deposit-1-1765456769-3847', '2025-12-11 12:39:50', 'pending'),
(769, 1, 'deposit', 51000.00, 'prime_earnings', 'Deposit for General Balance', 'EARNOVA-deposit-1-1765456769-3847', '2025-12-11 12:39:51', 'pending'),
(770, 1, 'premium_upgrade', 1500.00, 'total', 'Premium membership upgrade', 'EARNOVA-premium_upgrade-1-1765468251-1265', '2025-12-11 15:51:19', 'pending'),
(771, 1, 'premium_upgrade', 1500.00, 'total', 'Premium membership upgrade', 'EARNOVA-premium_upgrade-1-1765468251-1265', '2025-12-11 15:51:19', 'pending'),
(772, 1, 'ad_purchase', 350.00, 'prime_earnings', 'Posted task: testing kora pay on Instagram for 10 participants', 'TASK-65', '2025-12-11 16:12:11', 'pending'),
(773, 1, '', 35000.00, '', 'Korapay Deposit for Post Task - Ref: EARNOVA-TASK-1-1765469589-7453', 'EARNOVA-TASK-1-1765469589-7453', '2025-12-11 16:13:37', 'pending'),
(774, 1, 'ad_purchase', 6300.00, 'prime_earnings', 'Posted task: follow me tesing on Facebook for 180 participants', 'TASK-66', '2025-12-11 16:19:19', 'pending');
INSERT INTO `transactions` (`id`, `user_id`, `transaction_type`, `amount`, `balance_type`, `description`, `reference_id`, `created_at`, `status`) VALUES
(775, 1, '', 320.00, '', 'Korapay Deposit for Post Task - Ref: EARNOVA-TASK-1-1765470098-0036', 'EARNOVA-TASK-1-1765470098-0036', '2025-12-11 16:22:06', 'pending'),
(776, 1, '', 28480.00, '', 'Korapay Deposit for Post Task - Ref: EARNOVA-TASK-1-1765472464-3184', 'EARNOVA-TASK-1-1765472464-3184', '2025-12-11 17:02:35', 'pending'),
(777, 1, '', 320.00, '', 'Korapay Deposit for Post Task - Ref: EARNOVA-TASK-1-1765472699-9096', 'EARNOVA-TASK-1-1765472699-9096', '2025-12-11 17:05:21', 'pending'),
(778, 1, '', 25600.00, '', 'Korapay Deposit for Post Task - Ref: EARNOVA-TASK-1-1765473795-6362', 'EARNOVA-TASK-1-1765473795-6362', '2025-12-11 17:23:50', 'pending'),
(779, 1, '', 6615.00, '', 'Korapay Deposit for Post Task - Ref: EARNOVA-TASK-1-1765477552-9441', 'EARNOVA-TASK-1-1765477552-9441', '2025-12-11 18:27:11', 'pending'),
(780, 1, '', 9600.00, '', 'Korapay Deposit for Post Task - Ref: EARNOVA-TASK-1-1765477754-0132', 'EARNOVA-TASK-1-1765477754-0132', '2025-12-11 18:29:53', 'pending'),
(781, 1, '', 16000.00, '', 'Korapay Deposit for Post Task - Ref: EARNOVA-TASK-1-1765489402-3486', 'EARNOVA-TASK-1-1765489402-3486', '2025-12-11 21:45:05', 'pending'),
(782, 47, 'deposit', 1000.00, 'prime_earnings', 'Deposit for General Balance', 'EARNOVA-deposit-47-1765491537-2888', '2025-12-11 22:20:03', 'pending'),
(783, 47, 'deposit', 2000.00, 'prime_earnings', 'Deposit for General Balance', 'EARNOVA-deposit-47-1765491655-6316', '2025-12-11 22:21:44', 'pending'),
(784, 47, '', 3200.00, '', 'Korapay Deposit for Post Task - Ref: EARNOVA-TASK-47-1765491873-4796', 'EARNOVA-TASK-47-1765491873-4796', '2025-12-11 22:24:51', 'pending'),
(785, 47, 'deposit', 10000.00, 'prime_earnings', 'Deposit for General Balance', 'EARNOVA-deposit-47-1765492356-1204', '2025-12-11 22:32:51', 'pending'),
(786, 47, 'withdrawal', 200.00, 'prime_earnings', 'Prime_earnings withdrawal of ₦200.00', 'WD-98', '2025-12-11 22:59:25', 'pending'),
(787, 54, 'withdrawal', 200.00, 'prime_earnings', 'Prime_earnings withdrawal of ₦200.00', 'WD-99', '2025-12-11 23:05:03', 'pending'),
(788, 54, 'ad_purchase', 3200.00, 'prime_earnings', 'Extended task: Bbffff by 100 participants', 'EXTEND-64', '2025-12-11 23:13:47', 'pending'),
(789, 1, 'deposit', 8900.00, 'prime_earnings', 'Deposit for General Balance', 'EARNOVA-deposit-1-1765535898-4405', '2025-12-12 10:38:37', 'pending'),
(790, 1, 'deposit', 8900.00, 'prime_earnings', 'Deposit for General Balance', 'EARNOVA-deposit-1-1765535898-4405', '2025-12-12 10:38:38', 'pending'),
(791, 1, 'deposit', 4200.00, 'prime_earnings', 'Deposit for General Balance', 'EARNOVA-deposit-1-1765540091-3274', '2025-12-12 11:48:36', 'pending'),
(792, 1, 'deposit', 1300.00, 'prime_earnings', 'Deposit for General Balance', 'EARNOVA-deposit-1-1765540680-1652', '2025-12-12 11:58:19', 'pending'),
(793, 1, 'deposit', 1300.00, 'prime_earnings', 'Deposit for General Balance', 'EARNOVA-deposit-1-1765540680-1652', '2025-12-12 11:58:19', 'pending'),
(794, 1, 'deposit', 4000.00, 'prime_earnings', 'Deposit for General Balance', 'DEPOSIT-5t2ezhua8ey', '2025-12-12 12:04:19', 'pending'),
(795, 1, '', 500.00, '', 'Korapay Deposit for Post Task - Ref: EARNOVA-TASK-1-1765541224-2822', 'EARNOVA-TASK-1-1765541224-2822', '2025-12-12 12:07:35', 'pending'),
(796, 1, '', 28800.00, '', 'Korapay Deposit for Post Task - Ref: EARNOVA-TASK-1-1765542354-1669', 'EARNOVA-TASK-1-1765542354-1669', '2025-12-12 12:26:11', 'pending'),
(797, 1, '', 25000.00, '', 'Korapay Deposit for Post Task - Ref: EARNOVA-TASK-1-1765542675-0903', 'EARNOVA-TASK-1-1765542675-0903', '2025-12-12 12:31:34', 'pending'),
(798, 1, '', 25600.00, '', 'Korapay Deposit for Post Task - Ref: EARNOVA-TASK-1-1765542935-9222', 'EARNOVA-TASK-1-1765542935-9222', '2025-12-12 12:35:53', 'pending'),
(799, 46, 'deposit', 2000.00, 'prime_earnings', 'Deposit for General Balance', 'DEPOSIT-xijflz8kqci', '2025-12-12 12:47:30', 'pending'),
(800, 47, 'invite_commission', 1000.00, '', 'Cat020 upgraded to Premium Plus plan - Commission', 'EARNOVA-premium_plus_upgrade-54-1765543707-2609', '2025-12-12 12:49:13', 'pending'),
(801, 54, 'premium_upgrade', 2500.00, 'total', 'Premium Plus plan upgrade (yearly)', 'EARNOVA-premium_plus_upgrade-54-1765543707-2609', '2025-12-12 12:49:13', 'pending'),
(802, 46, 'withdrawal', 6000.00, 'prime_earnings', 'Prime_earnings withdrawal of ₦6,000.00', 'WD-100', '2025-12-12 12:50:03', 'pending'),
(803, 46, 'withdrawal', 50000.00, 'activity_earnings', 'Activity_earnings withdrawal of ₦50,000.00', 'WD-101', '2025-12-12 12:51:05', 'pending'),
(804, 1, 'ad_purchase', 28800.00, 'prime_earnings', 'Posted task: kora pay 2 on WhatsApp for 900 participants', 'TASK-78', '2025-12-12 13:35:01', 'pending'),
(805, 1, '', 21000.00, '', 'Korapay Deposit for Post Task - Ref: EARNOVA-TASK-1-1765547234-5443', 'EARNOVA-TASK-1-1765547234-5443', '2025-12-12 13:47:32', 'pending'),
(806, 1, 'ad_purchase', 45000.00, 'prime_earnings', 'Posted task: kora 31 on Website for 900 participants', 'TASK-80', '2025-12-12 13:54:54', 'pending'),
(807, 1, 'ad_purchase', 45000.00, 'prime_earnings', 'Posted task: follow kora on Website for 900 participants', 'TASK-81', '2025-12-12 13:57:29', 'pending'),
(808, 1, '', 50000.00, '', 'Korapay Deposit for Post Task - Ref: EARNOVA-TASK-1-1765547992-7351', 'EARNOVA-TASK-1-1765547992-7351', '2025-12-12 14:00:30', 'pending'),
(809, 1, '', 39450.00, 'prime_earnings', 'Posted task: follo pay stack on Website for 789 participants', 'TASK_770036800', '2025-12-12 14:03:00', 'pending'),
(810, 64, '', 28128.00, '', 'Korapay Deposit for Post Task - Ref: EARNOVA-TASK-64-1765548534-8879', 'EARNOVA-TASK-64-1765548534-8879', '2025-12-12 14:09:13', 'pending'),
(811, 64, '', 70000.00, '', 'Korapay Deposit for Post Task - Ref: EARNOVA-TASK-64-1765548838-1556', 'EARNOVA-TASK-64-1765548838-1556', '2025-12-12 14:14:23', 'pending'),
(812, 64, '', 70000.00, 'prime_earnings', 'Posted task: Testing 3 on PlayStore for 1000 participants', 'TASK_5526686', '2025-12-12 14:16:03', 'pending'),
(813, 64, '', 69230.00, 'prime_earnings', 'Posted task: Paystack task on PlayStore for 989 participants', 'TASK_180903991', '2025-12-12 14:46:36', 'pending'),
(814, 64, 'deposit', 500000.00, 'prime_earnings', 'Deposit for General Balance', 'DEPOSIT-29ve81gziwr', '2025-12-12 17:12:02', 'pending'),
(815, 64, 'deposit', 1000000.00, 'prime_earnings', 'Deposit for General Balance', 'EARNOVA-deposit-64-1765559761-7945', '2025-12-12 17:16:35', 'pending'),
(816, 64, 'deposit', 500000.00, 'prime_earnings', 'Deposit for General Balance', 'EARNOVA-deposit-64-1765559817-5176', '2025-12-12 17:17:20', 'pending'),
(817, 64, 'deposit', 500000.00, 'prime_earnings', 'Deposit for General Balance', 'EARNOVA-deposit-64-1765559948-8584', '2025-12-12 17:19:41', 'pending'),
(818, 64, '', 50000.00, 'prime_earnings', 'Posted task: Follow my ig on Website for 1000 participants', 'TASK_192876354', '2025-12-12 17:22:05', 'pending'),
(819, 64, 'deposit', 2000.00, 'prime_earnings', 'Deposit for General Balance', 'EARNOVA-deposit-64-1765613053-2639', '2025-12-13 08:04:50', 'pending'),
(820, 64, 'deposit', 2300.00, 'prime_earnings', 'Deposit for General Balance', 'EARNOVA-deposit-64-1765613144-2285', '2025-12-13 08:06:04', 'pending'),
(821, 64, 'deposit', 2300.00, 'prime_earnings', 'Deposit for General Balance', 'EARNOVA-deposit-64-1765613144-2285', '2025-12-13 08:06:04', 'pending'),
(822, 64, 'deposit', 3200.00, 'prime_earnings', 'Deposit for General Balance', 'DEPOSIT-vhnd5it1b7', '2025-12-13 08:07:04', 'pending'),
(823, 64, '', 11830.00, '', 'Korapay Deposit for Post Task - Ref: EARNOVA-TASK-64-1765613903-4059', 'EARNOVA-TASK-64-1765613903-4059', '2025-12-13 08:18:50', 'pending'),
(824, 64, '', 35000.00, 'prime_earnings', 'Posted task: Follow God and me eche on Reddit for 1000 participants', 'TASK_155885810', '2025-12-13 08:28:34', 'pending'),
(825, 64, '', 37962.00, '', 'Posted task: Testing paystack on Twitter/X for 999 participants', 'TASK_130753692', '2025-12-13 08:48:14', 'pending'),
(826, 64, 'deposit', 37962.00, '', 'Paystack deposit for task posting', 'TASK_130753692', '2025-12-13 08:48:14', 'pending'),
(827, 64, 'ad_purchase', 34965.00, 'prime_earnings', 'Posted task: Follow chi chi on Facebook for 999 participants', 'TASK-92', '2025-12-13 08:51:45', 'pending'),
(828, 64, 'ad_purchase', 3264.00, 'prime_earnings', 'Posted task: Uche on Telegram for 102 participants', 'TASK-93', '2025-12-13 08:55:34', 'pending'),
(829, 64, '', 7280.00, '', 'Korapay Deposit for Post Task - Ref: EARNOVA-TASK-64-1765618193-8020', 'EARNOVA-TASK-64-1765618193-8020', '2025-12-13 09:30:26', 'pending'),
(830, 64, '', 700.00, '', 'Posted task: Testing testing paystavk on PlayStore for 10 participants', 'TASK_492565732', '2025-12-13 09:32:06', 'pending'),
(831, 64, 'deposit', 700.00, '', 'Paystack deposit for task posting', 'TASK_492565732', '2025-12-13 09:32:06', 'pending'),
(832, 1, 'premium_upgrade', 2500.00, 'total', 'Premium Plus plan upgrade (yearly)', 'EARNOVA-premium_plus_upgrade-1-1765621403-6878', '2025-12-13 10:23:58', 'pending'),
(833, 64, 'ad_purchase', 50000.00, 'prime_earnings', 'Posted task: testing Upline 5% reward on Website for 1000 participants', 'TASK-96', '2025-12-13 10:27:01', 'pending'),
(834, 1, 'advertise_commission', 2500.00, '', '5% Advertisement Commission - Downline task posting (₦50000) on Website', 'UPLINE-AD-COMM-96', '2025-12-13 10:27:01', 'pending'),
(835, 64, 'deposit', 7000.00, 'prime_earnings', 'Deposit for General Balance', 'EARNOVA-deposit-64-1765625588-0677', '2025-12-13 11:33:27', 'pending'),
(836, 64, 'ad_purchase', 380000.00, 'prime_earnings', 'Posted task: Testing x.com on Twitter/X for 10000 participants', 'TASK-97', '2025-12-13 11:59:28', 'pending'),
(837, 1, 'advertise_commission', 19000.00, '', '5% Advertisement Commission - Downline task posting (₦380000) on Twitter/X', 'UPLINE-AD-COMM-97', '2025-12-13 11:59:28', 'pending'),
(838, 64, 'ad_purchase', 380000.00, 'prime_earnings', 'Posted task: Follow my x account on Twitter/X for 10000 participants', 'TASK-98', '2025-12-13 12:02:54', 'pending'),
(839, 1, 'advertise_commission', 19000.00, '', '5% Advertisement Commission - Downline task posting (₦380000) on Twitter/X', 'UPLINE-AD-COMM-98', '2025-12-13 12:02:54', 'pending'),
(840, 64, 'task_reward', 22.00, 'activity_earnings', 'Completed task: Testing upline reward', 'TASK-586', '2025-12-13 12:21:51', 'pending'),
(841, 1, 'ad_purchase', 60800.00, 'prime_earnings', 'Posted task: Follow twitter account on Twitter/X for 1600 participants', 'TASK-99', '2025-12-13 15:42:17', 'pending'),
(842, 54, 'deposit', 10000.00, 'prime_earnings', 'Deposit for General Balance', 'EARNOVA-deposit-54-1765690051-0176', '2025-12-14 05:28:17', 'pending'),
(843, 54, 'withdrawal', 200.00, 'prime_earnings', 'Prime_earnings withdrawal of ₦200.00', 'WD-102', '2025-12-14 05:38:34', 'pending'),
(844, 73, 'deposit', 1000.00, 'prime_earnings', 'Deposit for General Balance', 'EARNOVA-deposit-73-1765716026-8582', '2025-12-14 12:41:42', 'pending'),
(845, 73, 'withdrawal', 300.00, 'prime_earnings', 'Prime_earnings withdrawal of ₦300.00', 'WD-103', '2025-12-14 12:43:01', 'pending'),
(846, 73, 'withdrawal', 200.00, 'prime_earnings', 'Prime_earnings withdrawal of ₦200.00', 'WD-104', '2025-12-14 12:46:07', 'pending'),
(847, 1, '', 320.00, 'prime_earnings', 'Posted video: Obodo Obodo on TikTok', 'VIDEO-video_1765743508_693f1b94e575f', '2025-12-14 20:18:28', 'pending'),
(848, 47, 'task_reward', 50.00, 'activity_earnings', 'Completed task: Testing testing paystavk', 'TASK-587', '2025-12-14 21:31:04', 'pending'),
(849, 1, '', 350.00, 'prime_earnings', 'Posted video: follow Follow follow follow on Instagram', 'VIDEO-video_1765787835_693fc8bba83eb', '2025-12-15 08:37:15', 'pending');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int NOT NULL,
  `username` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `gender` enum('male','female') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `how_heard` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `country` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Nigeria',
  `interests` text COLLATE utf8mb4_unicode_ci,
  `career1` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `career2` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bid_fee_paid` tinyint(1) DEFAULT '0',
  `password_hash` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `full_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `whatsapp_number` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `chat_earn_enabled` tinyint(1) DEFAULT '0',
  `chat_earn_last_paired` datetime DEFAULT NULL,
  `last_referral_withdrawal` datetime DEFAULT NULL,
  `referral_withdrawal_count_today` int DEFAULT '0',
  `last_withdrawal_reset_date` date DEFAULT NULL,
  `profile_picture` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `instagram_link` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `twitter_link` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `discord_link` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `referral_code` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `referred_by` int DEFAULT NULL,
  `membership_type` enum('free','premium') COLLATE utf8mb4_unicode_ci DEFAULT 'free',
  `membership_expires_at` datetime DEFAULT NULL,
  `membership_start_date` datetime DEFAULT NULL COMMENT 'Date when membership started',
  `advertiser_plan` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'Advertiser plan type (e.g., senior)',
  `advertiser_plan_start_date` datetime DEFAULT NULL COMMENT 'Date when advertiser plan started',
  `is_active` tinyint(1) DEFAULT '1',
  `is_admin` tinyint(1) DEFAULT '0',
  `email_verified` tinyint(1) DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `whot_games_played` int DEFAULT '0',
  `whot_games_won` int DEFAULT '0',
  `whot_rank` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT 'Rookie',
  `status` enum('active','banned') COLLATE utf8mb4_unicode_ci DEFAULT 'active',
  `withdrawal_account_number` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `withdrawal_account_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `withdrawal_bank_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `withdrawal_bank_code` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `paystack_recipient_code` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `withdrawal_banks_json` text COLLATE utf8mb4_unicode_ci COMMENT 'JSON array of multiple banks if account has multiple banks',
  `theme_preference` enum('dark','light') COLLATE utf8mb4_unicode_ci DEFAULT 'dark' COMMENT 'User theme preference',
  `plinko_free_plays` int DEFAULT '2',
  `plinko_last_reset` date DEFAULT NULL,
  `color_predictor_free_plays` int DEFAULT '2',
  `color_predictor_last_reset` date DEFAULT NULL,
  `mystery_box_free_plays` int DEFAULT '2',
  `mystery_box_last_reset` date DEFAULT NULL,
  `spin_win_free_plays` int DEFAULT '2',
  `spin_win_last_reset` date DEFAULT NULL,
  `chat_earn_progress` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'Tracks user progress: gender_selected, requirements_checked, paired',
  `chat_earn_selected_gender` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'Stores selected gender for resume functionality',
  `full_name_last_updated` datetime DEFAULT NULL,
  `profile_picture_last_updated` datetime DEFAULT NULL,
  `phone_last_updated` datetime DEFAULT NULL,
  `username_last_updated` datetime DEFAULT NULL,
  `withdrawal_method_last_updated` datetime DEFAULT NULL,
  `welcome_email_sent` tinyint(1) DEFAULT '0' COMMENT 'Tracks if welcome email has been sent to user (0=not sent, 1=sent)',
  `remember_me_token` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `remember_me_expires` datetime DEFAULT NULL,
  `last_activity` datetime DEFAULT NULL,
  `country_popup_dismissed` tinyint(1) DEFAULT '0',
  `korapay_vba_account_number` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'Kora Pay Virtual Bank Account number',
  `korapay_account_reference` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'Kora Pay unique account reference',
  `korapay_vba_created_at` datetime DEFAULT NULL COMMENT 'When VBA was created',
  `korapay_vba_bank_code` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'Bank code for VBA',
  `korapay_vba_bank_name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'Bank name for VBA'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `gender`, `how_heard`, `country`, `interests`, `career1`, `career2`, `bid_fee_paid`, `password_hash`, `full_name`, `phone`, `whatsapp_number`, `chat_earn_enabled`, `chat_earn_last_paired`, `last_referral_withdrawal`, `referral_withdrawal_count_today`, `last_withdrawal_reset_date`, `profile_picture`, `instagram_link`, `twitter_link`, `discord_link`, `referral_code`, `referred_by`, `membership_type`, `membership_expires_at`, `membership_start_date`, `advertiser_plan`, `advertiser_plan_start_date`, `is_active`, `is_admin`, `email_verified`, `created_at`, `updated_at`, `whot_games_played`, `whot_games_won`, `whot_rank`, `status`, `withdrawal_account_number`, `withdrawal_account_name`, `withdrawal_bank_name`, `withdrawal_bank_code`, `paystack_recipient_code`, `withdrawal_banks_json`, `theme_preference`, `plinko_free_plays`, `plinko_last_reset`, `color_predictor_free_plays`, `color_predictor_last_reset`, `mystery_box_free_plays`, `mystery_box_last_reset`, `spin_win_free_plays`, `spin_win_last_reset`, `chat_earn_progress`, `chat_earn_selected_gender`, `full_name_last_updated`, `profile_picture_last_updated`, `phone_last_updated`, `username_last_updated`, `withdrawal_method_last_updated`, `welcome_email_sent`, `remember_me_token`, `remember_me_expires`, `last_activity`, `country_popup_dismissed`, `korapay_vba_account_number`, `korapay_account_reference`, `korapay_vba_created_at`, `korapay_vba_bank_code`, `korapay_vba_bank_name`) VALUES
(1, 'Obodonwoke', 'obodo@gmail.com', 'female', NULL, 'Nigeria', NULL, NULL, NULL, 0, '$2y$10$HDfACszssddP/OiyF9K1w.0iKrd2XaN4kjCdqXe3IS5vwo5Iq13A6', 'Obodo Nwoke', '', '09132482782', 1, '2025-11-28 09:01:48', NULL, 0, NULL, 'uploads/avatars/avatar_1_1760633267.jpeg', NULL, NULL, NULL, 'FB44C438', NULL, 'premium', '2026-12-11 16:51:19', '2025-11-22 00:09:42', 'senior', '2025-12-13 12:41:24', 1, 1, 0, '2025-10-02 00:45:00', '2025-12-15 09:41:25', 0, 0, 'Rookie', 'active', '9132482782', 'CHIBUEZE STANLEY EBERECHUKWU', 'OPay Digital Services Limited (OPay)', '999992', 'RCP_d8vwb0x3tor3a22', NULL, 'dark', 2, '2025-12-04', 2, NULL, 2, '2025-10-17', 2, '2025-10-17', 'requirements_complete', 'female', NULL, '2025-10-16 09:47:47', NULL, '2025-10-16 09:46:53', '2025-11-28 22:30:02', 1, '63f479a4adf89b30518f0eae065e37fe78945a1b2ec581e6b68e5fd0f85c9383', '2025-12-15 11:07:25', '2025-12-15 10:41:25', 0, NULL, NULL, NULL, NULL, NULL),
(46, 'Tino', 'chinecheremmechackifeama@gmail.com', 'female', 'tiktok', 'Nigeria', NULL, NULL, NULL, 0, '$2y$10$32IcvYOCjv5PbK71cX1mP.Rp9sQ98yV.oegDFgVoZHxiBICfXgrSu', 'Chinecherem', NULL, '09041346099', 1, '2025-11-23 10:32:51', NULL, 0, NULL, 'uploads/avatars/avatar_46_1763457171.jpg', NULL, NULL, NULL, 'TINO', NULL, 'premium', NULL, NULL, 'senior', '2025-12-01 22:55:13', 1, 1, 0, '2025-11-18 08:08:10', '2025-12-14 09:11:39', 0, 0, 'Rookie', 'active', '9133600755', 'CHINECHEREM MECHACK IFEAMA', 'PalmPay', '999991', 'RCP_534mc9ff21ca11p', NULL, 'dark', 2, '2025-12-12', 2, NULL, 2, NULL, 2, NULL, 'paired', 'male', '2025-11-18 08:08:10', '2025-11-18 10:12:51', '2025-11-18 08:08:10', '2025-11-18 08:08:10', NULL, 1, 'c27b216459f7f3031c27fd9840c0639ed4d2828bbb0004ed8bbc891391517d53', '2025-12-14 10:41:39', '2025-12-14 10:11:39', 0, NULL, NULL, NULL, NULL, NULL),
(47, 'Yuken92', 'karinayuken@gmail.com', 'female', 'youtube', 'Nigeria', NULL, NULL, NULL, 0, '$2y$10$80CyqJ.LD7KZSv9sTV5rL.m0yqX90u2DkQIJ9ZZg.20CZa3maII/S', 'Karina yuken', NULL, '09138427475', 1, '2025-12-09 17:00:01', NULL, 0, NULL, 'uploads/avatars/avatar_47_1763459562.jpg', NULL, NULL, NULL, 'YUKEN92', NULL, 'premium', NULL, NULL, 'senior', NULL, 1, 1, 0, '2025-11-18 08:22:27', '2025-12-15 05:07:14', 0, 0, 'Rookie', 'active', '1692977784', 'KENECHUKWU FRANKLIN IFEAMAH', 'Access Bank', '044', 'RCP_dxsnwbkh5zee54x', NULL, 'dark', 2, '2025-12-12', 2, NULL, 2, NULL, 2, NULL, 'paired', 'female', '2025-11-18 08:22:27', '2025-11-18 10:52:42', '2025-11-18 08:22:27', '2025-11-18 08:22:27', '2025-12-11 23:59:02', 1, 'e7fbd2a436dcca647e237833d09af4f5d7dec040c9d508846470efdf09dac74e', '2025-12-15 06:37:14', '2025-12-15 06:07:14', 0, NULL, NULL, NULL, NULL, NULL),
(50, 'Franklin#', 'karinayukev@gmail.com', 'female', 'tiktok', 'Nigeria', NULL, NULL, NULL, 0, '$2y$10$T/gRV97CSQInx6aBBSr./.rdNTrhydGM/tP2ZgRK/KmB60NGExNlG', 'Ebuka', NULL, '09138427470', 1, '2025-11-28 05:26:41', NULL, 0, NULL, 'uploads/avatars/avatar_50_1763725865.jpg', NULL, NULL, NULL, 'FRANKLIN#', 47, 'premium', '2026-11-21 12:12:16', '2025-11-21 12:12:16', 'senior', '2025-11-21 13:19:46', 1, 0, 0, '2025-11-20 16:12:51', '2025-11-30 07:53:19', 0, 0, 'Rookie', 'active', NULL, NULL, NULL, NULL, NULL, NULL, 'dark', 2, '2025-11-21', 2, NULL, 2, NULL, 2, NULL, 'paired', 'female', '2025-11-20 16:12:51', '2025-11-21 12:51:05', '2025-11-20 16:12:51', '2025-11-20 16:12:51', NULL, 1, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(51, 'Word', 'socialnooktech@gmail.com', 'male', 'tiktok', 'Nigeria', NULL, NULL, NULL, 0, '$2y$10$NaAvthbWfGGtShL60hnCQO2wjwTXciffiFHjQGS76pQKg6TpfJkeW', 'Digital', NULL, '09138427478', 1, '2025-11-23 15:55:12', NULL, 0, NULL, 'uploads/avatars/avatar_51_1763794649.jpg', NULL, NULL, NULL, 'WORD', 47, 'premium', '2026-11-22 07:29:55', '2025-11-22 07:29:55', 'senior', '2025-11-22 07:54:36', 1, 0, 0, '2025-11-21 17:33:22', '2025-11-30 07:53:19', 0, 0, 'Rookie', 'active', NULL, NULL, NULL, NULL, NULL, NULL, 'dark', 2, '2025-11-22', 2, NULL, 2, NULL, 2, NULL, 'paired', 'female', '2025-11-21 17:33:22', '2025-11-22 07:57:29', '2025-11-21 17:33:22', '2025-11-21 17:33:22', NULL, 1, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(52, 'Username', 'username@gmail.com', NULL, 'blog_article', 'Nigeria', NULL, NULL, NULL, 0, '$2y$10$2g2vAWJCRLwauM2SfMP0rO28FZozDG3Fk2auJ84wEHeRcj/C4sW.O', 'premium Uswr', NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'USERNAME', NULL, 'premium', '2026-11-27 12:34:43', '2025-11-27 12:34:43', 'senior', '2025-11-27 12:34:43', 1, 0, 0, '2025-11-21 18:27:01', '2025-11-30 07:53:19', 0, 0, 'Rookie', 'active', NULL, NULL, NULL, NULL, NULL, NULL, 'dark', 2, NULL, 2, NULL, 2, NULL, 2, NULL, NULL, NULL, '2025-11-21 18:27:01', NULL, '2025-11-21 18:27:01', '2025-11-21 18:27:01', NULL, 1, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(53, 'Mechack001', 'earnova001@gmail.com', 'male', 'friend_referral', 'Nigeria', NULL, NULL, NULL, 0, '$2y$10$ts2yfhKuLNlXOfLrJeuxVOxgEKZOqECrPD1aFr3iTbAvFU2y93p1C', 'Mechack Tino', NULL, '09041346009', 1, '2025-11-23 16:13:01', NULL, 0, NULL, 'uploads/avatars/avatar_53_1763914059.jpg', NULL, NULL, NULL, 'MECHACK001', 46, 'premium', '2026-11-22 09:04:20', '2025-11-22 09:04:20', 'senior', '2025-11-23 17:06:28', 0, 0, 0, '2025-11-21 19:32:45', '2025-12-04 20:21:48', 0, 0, 'Rookie', 'active', NULL, NULL, NULL, NULL, NULL, NULL, 'dark', 2, '2025-12-04', 2, NULL, 2, NULL, 2, NULL, 'paired', 'male', '2025-11-21 19:32:45', '2025-11-23 17:07:39', '2025-11-21 19:32:45', '2025-11-21 19:32:45', NULL, 1, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(54, 'Cat020', 'chidubemifeama@gmail.com', 'female', 'search_engine', 'Nigeria', NULL, NULL, NULL, 0, '$2y$10$aqRpaDtOx1qbmjaRmz9VbeGYn6Kz1dnqXHZPhUN/4H1rFe9FyM77i', 'Bbbbvg', NULL, '09138427411', 1, '2025-12-05 06:10:55', NULL, 0, NULL, 'uploads/avatars/avatar_54_1763912495.jpg', NULL, NULL, NULL, 'CAT020', 47, 'free', '2026-12-12 13:49:13', '2025-11-21 21:23:29', NULL, '2025-12-01 08:53:06', 0, 0, 0, '2025-11-21 20:08:05', '2025-12-14 23:40:36', 0, 0, 'Rookie', 'active', '1692977784', 'KENECHUKWU FRANKLIN IFEAMAH', 'Access Bank', '044', 'RCP_d581789pmena3gn', NULL, 'dark', 2, '2025-12-14', 2, NULL, 2, NULL, 2, NULL, 'requirements_complete', 'female', '2025-11-21 20:08:05', '2025-11-23 16:41:35', '2025-11-21 20:08:05', '2025-11-21 20:08:05', NULL, 1, NULL, NULL, '2025-12-15 00:40:36', 0, NULL, NULL, NULL, NULL, NULL),
(56, 'stanley01', 'steven211@gmail.com', NULL, 'friend_referral', 'Nigeria', NULL, NULL, NULL, 0, '$2y$10$DSkw8NcFvKmOJAqCjTbg6u21KvI8i0OobrJ8F3vghelm06Jg2SOMK', 'GodAbeg', NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'STANLEY01', NULL, 'free', NULL, NULL, NULL, NULL, 1, 0, 0, '2025-11-22 18:08:37', '2025-11-30 07:53:19', 0, 0, 'Rookie', 'active', NULL, NULL, NULL, NULL, NULL, NULL, 'dark', 2, NULL, 2, NULL, 2, NULL, 2, NULL, NULL, NULL, '2025-11-22 18:08:37', NULL, '2025-11-22 18:08:37', '2025-11-22 18:08:37', NULL, 1, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(57, 'Developer', 'developer@gmail.com', NULL, 'tiktok', 'Nigeria', NULL, NULL, NULL, 0, '$2y$10$8hovvrF23E2rC90xaRvozOwdzUZF3iAzn3wQXwiXc73pH.sWvclbm', 'Developer', NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'DEVELOPER', NULL, 'premium', '2026-11-24 14:58:24', '2025-11-24 14:58:24', 'senior', '2025-11-24 14:58:24', 1, 0, 0, '2025-11-24 13:57:42', '2025-11-30 07:53:19', 0, 0, 'Rookie', 'active', NULL, NULL, NULL, NULL, NULL, NULL, 'dark', 2, NULL, 2, NULL, 2, NULL, 2, NULL, NULL, NULL, '2025-11-24 13:57:42', NULL, '2025-11-24 13:57:42', '2025-11-24 13:57:42', NULL, 1, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(58, 'Bigboss', 'socialnooktechs@gmail.com', NULL, 'friend_referral', 'Nigeria', NULL, NULL, NULL, 0, '$2y$10$PGYv36v3W/sz6x76LBedSuaYXGXRbT1uqibdJBFpJz0gBR1F6VjGC', 'Biggie', NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'BIGBOSS', NULL, 'premium', '2026-11-25 08:26:43', '2025-11-25 08:26:43', 'senior', '2025-11-27 20:23:05', 1, 0, 0, '2025-11-25 07:00:51', '2025-11-30 07:53:19', 0, 0, 'Rookie', 'active', NULL, NULL, NULL, NULL, NULL, NULL, 'dark', 2, '2025-11-25', 2, NULL, 2, NULL, 2, NULL, NULL, NULL, '2025-11-25 07:00:51', NULL, '2025-11-25 07:00:51', '2025-11-25 07:00:51', NULL, 1, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(59, 'Busy', 'karinayun@gmail.com', NULL, 'search_engine', 'Nigeria', NULL, NULL, NULL, 0, '$2y$10$VwGrd47fkahkpvE1nPtHCuBYX31gv5FLtGEZDrLWwHTW4e9EsLSJe', 'Bigguy', NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'BUSY', 58, 'premium', '2026-11-25 08:24:51', '2025-11-25 08:24:51', 'senior', '2025-11-25 08:43:54', 1, 0, 0, '2025-11-25 07:23:18', '2025-11-30 07:53:19', 0, 0, 'Rookie', 'active', NULL, NULL, NULL, NULL, NULL, NULL, 'dark', 2, '2025-11-25', 2, NULL, 2, NULL, 2, NULL, NULL, NULL, '2025-11-25 07:23:18', NULL, '2025-11-25 07:23:18', '2025-11-25 07:23:18', NULL, 1, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(60, 'Meandgod4', 'Obodonwoke1uw7@gmail.com', NULL, 'telegram', 'Nigeria', NULL, NULL, NULL, 0, '$2y$10$u3JWXzUiCqPS4s7ZhulzPedm2K8XbDo.2SnuABahh84EFlA4QZ6EK', 'Uche EbereChukwu Gerald', NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'MEANDGOD4', NULL, 'premium', '2026-11-25 09:21:28', '2025-11-25 09:21:28', 'senior', '2025-11-25 09:21:42', 1, 0, 0, '2025-11-25 08:20:57', '2025-11-30 07:53:19', 0, 0, 'Rookie', 'active', NULL, NULL, NULL, NULL, NULL, NULL, 'dark', 2, NULL, 2, NULL, 2, NULL, 2, NULL, NULL, NULL, '2025-11-25 08:20:57', NULL, '2025-11-25 08:20:57', '2025-11-25 08:20:57', NULL, 1, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(61, '@Ebere123', 'a@gmail.com', NULL, 'advertisement', 'Nigeria', NULL, NULL, NULL, 0, '$2y$10$apIB661wuKNBphoY4GBlp.ewQEbbtDPBpXjmJma5KfvolS1topOKm', 'ObodoTesting', NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, '@EBERE123', 1, 'premium', '2026-11-27 19:02:40', '2025-11-27 19:02:40', 'senior', '2025-11-27 19:02:40', 1, 0, 0, '2025-11-27 18:02:00', '2025-11-30 07:53:19', 0, 0, 'Rookie', 'active', NULL, NULL, NULL, NULL, NULL, NULL, 'dark', 2, NULL, 2, NULL, 2, NULL, 2, NULL, NULL, NULL, '2025-11-27 18:02:00', NULL, '2025-11-27 18:02:00', '2025-11-27 18:02:00', NULL, 1, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(62, 'testingpremiumPlus', 'premium@gmail.com', NULL, 'advertisement', 'Nigeria', NULL, NULL, NULL, 0, '$2y$10$dcF49fpnL6/PemPizExj8u4stJWWXU9Dvvc9TOnJWYaE4VyuRi0W.', 'Testing Premium Plus', NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'TESTINGPREMIUMPLUS', 1, 'premium', '2026-11-27 19:30:25', '2025-11-27 19:30:25', 'senior', '2025-11-27 19:30:25', 1, 0, 0, '2025-11-27 18:12:28', '2025-11-30 07:53:19', 0, 0, 'Rookie', 'active', NULL, NULL, NULL, NULL, NULL, NULL, 'dark', 2, NULL, 2, NULL, 2, NULL, 2, NULL, NULL, NULL, '2025-11-27 18:12:28', NULL, '2025-11-27 18:12:28', '2025-11-27 18:12:28', NULL, 1, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(63, 'King1', 'mechacktino@gmail.com', 'male', 'friend_referral', 'Nigeria', NULL, NULL, NULL, 0, '$2y$10$kwXRsnKM3yYPXLhIRbX.f.YgUPKTAuuKha6W5knN8LUdRPNl6msg2', 'Chinecherem mechack', NULL, '09138421470', 1, NULL, NULL, 0, NULL, 'uploads/avatars/avatar_63_1764914615.jpg', NULL, NULL, NULL, 'KING1', 46, 'premium', '2026-11-27 21:06:43', '2025-11-27 21:06:43', 'senior', '2025-11-27 21:06:43', 0, 0, 0, '2025-11-27 19:52:19', '2025-12-05 13:46:05', 0, 0, 'Rookie', 'active', NULL, NULL, NULL, NULL, NULL, NULL, 'dark', 2, '2025-11-27', 2, NULL, 2, NULL, 2, NULL, 'requirements_check', 'male', '2025-11-27 19:52:19', '2025-12-05 07:03:35', '2025-11-27 19:52:19', '2025-11-27 19:52:19', NULL, 1, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(64, 'Stream&Earn', 'stream@gmail.com', NULL, 'advertisement', 'Nigeria', NULL, NULL, NULL, 0, '$2y$10$M.QHF99IwMLGcTSJG/8Xh.VILlmVTIaM60UcKIMsWO56JRYtxoZj2', 'StreamTesting', NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'STREAM&EARN', 1, 'premium', '2026-12-04 21:42:31', '2025-11-28 11:56:21', NULL, '2025-11-29 14:32:45', 1, 0, 0, '2025-11-28 10:53:38', '2025-12-13 18:03:15', 0, 0, 'Rookie', 'active', NULL, NULL, NULL, NULL, NULL, NULL, 'dark', 2, NULL, 2, NULL, 2, NULL, 2, NULL, NULL, NULL, '2025-11-28 10:53:38', NULL, '2025-11-28 10:53:38', '2025-11-28 10:53:38', NULL, 1, 'c57369e15dfc3009f29fdeeccde45bae581068f03ba5724bd8f3ab47bbab26ff', '2025-12-13 19:30:44', '2025-12-13 19:03:15', 0, NULL, NULL, NULL, NULL, NULL),
(65, 'Obodo90', 'obodoobodo90@gmail.com', NULL, 'telegram', 'Nigeria', NULL, NULL, NULL, 0, '$2y$10$PXsQjZelnhZvjtGAVxdAK.a8X4cP4vNJh9eOB4cB55pk6I0RAXqs.', 'Obodo90', NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'OBODO90', NULL, 'free', NULL, NULL, NULL, NULL, 1, 0, 0, '2025-11-30 11:21:59', '2025-11-30 12:13:27', 0, 0, 'Rookie', 'active', NULL, NULL, NULL, NULL, NULL, NULL, 'dark', 2, NULL, 2, NULL, 2, NULL, 2, NULL, NULL, NULL, '2025-11-30 11:21:59', NULL, '2025-11-30 11:21:59', '2025-11-30 11:21:59', NULL, 1, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(66, 'emenekam', 'emenekam@gmail.com', NULL, 'blog_article', 'Nigeria', NULL, NULL, NULL, 0, '$2y$10$Znh9jh9Ofo.dOeTD5wtGhubKFjdjj4HqFTTE.zKGwmLolDCOSClV.', 'Emenekam', NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'EMENEKAM', NULL, 'free', NULL, NULL, NULL, NULL, 1, 0, 0, '2025-11-30 11:39:08', '2025-11-30 11:39:16', 0, 0, 'Rookie', 'active', NULL, NULL, NULL, NULL, NULL, NULL, 'dark', 2, NULL, 2, NULL, 2, NULL, 2, NULL, NULL, NULL, '2025-11-30 11:39:08', NULL, '2025-11-30 11:39:08', '2025-11-30 11:39:08', NULL, 1, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(67, 'Kenechukwu', 'rs9726158@gmail.com', NULL, 'friend_referral', 'Nigeria', NULL, NULL, NULL, 0, '$2y$10$YqOm8UlPRf61Wrmf5.T.OOlyU0pRKO/j2B2MJ4ZF9xQ5RhKcfVtGq', 'Kosi', NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'KENECHUKWU', 47, 'premium', '2026-12-03 09:57:35', '2025-12-03 09:57:35', 'senior', '2025-12-03 10:02:58', 1, 0, 0, '2025-12-03 08:24:52', '2025-12-03 09:02:58', 0, 0, 'Rookie', 'active', NULL, NULL, NULL, NULL, NULL, NULL, 'dark', 2, '2025-12-03', 2, NULL, 2, NULL, 2, NULL, 'requirements_check', 'female', '2025-12-03 08:24:52', NULL, '2025-12-03 08:24:52', '2025-12-03 08:24:52', NULL, 1, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(68, 'Tino1', 'mechacktino9653@gmail.com', NULL, 'tiktok', 'Nigeria', NULL, NULL, NULL, 0, '$2y$10$5POWL9FKs6C/ywhE9AWsEONeNn0dCst1KXDdhkDhZJXhJA6emW7bW', 'Chinecherem mechack', NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'TINO1', 46, 'free', NULL, NULL, NULL, NULL, 1, 0, 0, '2025-12-03 20:06:15', '2025-12-03 20:06:47', 0, 0, 'Rookie', 'active', NULL, NULL, NULL, NULL, NULL, NULL, 'dark', 2, NULL, 2, NULL, 2, NULL, 2, NULL, NULL, NULL, '2025-12-03 20:06:15', NULL, '2025-12-03 20:06:15', '2025-12-03 20:06:15', NULL, 1, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(69, 'Karen', 'rs972618@gmail.com', NULL, 'friend_referral', 'Nigeria', NULL, NULL, NULL, 0, '$2y$10$GX75SG2g0KCEoaVKM.F2FeUbo6Yx8y9L.pXJIeJzvIg7wI6YTgVZa', 'Nhhhhhg', NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'KAREN', 47, 'premium', '2026-12-03 22:24:03', '2025-12-03 22:24:03', 'senior', '2025-12-03 22:24:03', 1, 0, 0, '2025-12-03 21:20:44', '2025-12-03 21:24:03', 0, 0, 'Rookie', 'active', NULL, NULL, NULL, NULL, NULL, NULL, 'dark', 2, NULL, 2, NULL, 2, NULL, 2, NULL, NULL, NULL, '2025-12-03 21:20:44', NULL, '2025-12-03 21:20:44', '2025-12-03 21:20:44', NULL, 1, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(70, 'Bariola', 'barioladigitalconcepts@gmail.com', NULL, 'other', 'Nigeria', NULL, NULL, NULL, 0, '$2y$10$Hn2mDGnTDqczOFhY4mbQ/evgDFxID/qarj.zaQMeocdlbnWmd8/tC', 'Badejo Oladeji Richard', NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'BARIOLA', NULL, 'premium', NULL, NULL, 'senior', '2025-12-04 11:26:58', 1, 0, 0, '2025-12-04 10:03:06', '2025-12-05 20:45:50', 0, 0, 'Rookie', 'active', NULL, NULL, NULL, NULL, NULL, NULL, 'dark', 2, NULL, 2, NULL, 2, NULL, 2, NULL, NULL, NULL, '2025-12-04 10:03:06', NULL, '2025-12-04 10:03:06', '2025-12-04 10:03:06', NULL, 1, '8f66d6e361a044def7a8a02020c8331db2473b371f2e116141101d8c8f24c0db', '2026-03-04 10:30:32', NULL, 0, NULL, NULL, NULL, NULL, NULL),
(73, 'Ggghhh', 'kanayuken@gmail.com', NULL, 'tiktok', 'Cameroon', NULL, NULL, NULL, 0, '$2y$10$Ns7zEu.5IcS9SvqxFrlR9OX2mq7efjZm3iGolsUNJs8PFxUE3zer.', 'Biggie', NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'GGGHHH', NULL, 'free', NULL, NULL, NULL, NULL, 1, 0, 0, '2025-12-10 11:03:53', '2025-12-14 13:34:40', 0, 0, 'Rookie', 'active', '9138427470', 'KENECHUKWU FRANKLIN IFEAMAH', 'OPay Digital Services Limited (OPay)', '999992', 'RCP_eqkd6i1ia4hovjy', NULL, 'dark', 2, NULL, 2, NULL, 2, NULL, 2, NULL, NULL, NULL, '2025-12-10 12:03:53', NULL, '2025-12-10 12:03:53', '2025-12-10 12:03:53', NULL, 1, 'c5e64eb5c99cdd652c394d8a1ba20ff2d17064125655e1b0e35c685b9eae768a', '2025-12-14 15:04:39', '2025-12-14 14:34:40', 0, NULL, NULL, NULL, NULL, NULL),
(74, 'Steven', 'steveneloit122@gmail.com', NULL, NULL, 'Nigeria', NULL, NULL, NULL, 0, '$2y$10$UvAL84kg/Xyrfk4ErBbFm.c7X4LLfgD37tyPISqQPHLaPQbagnYoK', 'Steven', NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'STEVEN', NULL, 'free', NULL, NULL, NULL, NULL, 0, 0, 0, '2025-12-10 13:07:20', '2025-12-10 13:19:01', 0, 0, 'Rookie', 'active', NULL, NULL, NULL, NULL, NULL, NULL, 'dark', 2, NULL, 2, NULL, 2, NULL, 2, NULL, NULL, NULL, '2025-12-10 14:07:20', NULL, '2025-12-10 14:07:20', '2025-12-10 14:07:20', NULL, 1, NULL, NULL, '2025-12-10 14:19:01', 0, NULL, NULL, NULL, NULL, NULL),
(75, 'Steven23', 'obodosteven@gmail.com', NULL, 'blog_article', 'Burkina Faso', NULL, NULL, NULL, 0, '$2y$10$Jkmkfh0xNRdtLJMeWC28qehKAMn3bB6zLloSGLbSCXyQNUJzM7J9y', 'Steven23', NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'STEVEN23', NULL, 'free', NULL, NULL, NULL, NULL, 1, 0, 0, '2025-12-10 13:10:42', '2025-12-10 13:12:29', 0, 0, 'Rookie', 'active', NULL, NULL, NULL, NULL, NULL, NULL, 'dark', 2, NULL, 2, NULL, 2, NULL, 2, NULL, NULL, NULL, '2025-12-10 14:10:42', NULL, '2025-12-10 14:10:42', '2025-12-10 14:10:42', NULL, 1, NULL, NULL, '2025-12-10 14:12:29', 0, NULL, NULL, NULL, NULL, NULL),
(76, 'tanley', 'tanley@gmail.com', NULL, 'whatsapp', 'Burkina Faso', NULL, NULL, NULL, 0, '$2y$10$v8tBcEgK2xkRoqZfGHG4WO48dheH2MEZxOy/p3fGSLu4joL5zbiyi', 'tanley Ikem', NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 'TANLEY', NULL, 'free', NULL, NULL, NULL, NULL, 0, 0, 0, '2025-12-14 18:01:17', '2025-12-14 18:03:35', 0, 0, 'Rookie', 'active', NULL, NULL, NULL, NULL, NULL, NULL, 'dark', 2, NULL, 2, NULL, 2, NULL, 2, NULL, NULL, NULL, '2025-12-14 19:01:17', NULL, '2025-12-14 19:01:17', '2025-12-14 19:01:17', NULL, 1, NULL, NULL, '2025-12-14 19:03:35', 0, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `user_completed_music`
--

CREATE TABLE `user_completed_music` (
  `id` int NOT NULL,
  `user_id` int NOT NULL,
  `music_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `completed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `user_completed_tasks`
--

CREATE TABLE `user_completed_tasks` (
  `id` int NOT NULL,
  `user_id` int NOT NULL,
  `task_id` int NOT NULL,
  `reward_amount` decimal(10,2) NOT NULL DEFAULT '0.00',
  `completed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `user_completed_tasks`
--

INSERT INTO `user_completed_tasks` (`id`, `user_id`, `task_id`, `reward_amount`, `completed_at`) VALUES
(124, 63, 52, 0.00, '2025-12-01 17:41:33'),
(125, 47, 52, 0.00, '2025-12-02 10:53:15'),
(126, 47, 56, 0.00, '2025-12-02 11:58:56'),
(127, 54, 53, 0.00, '2025-12-02 14:22:33'),
(128, 54, 52, 0.00, '2025-12-02 14:24:15'),
(129, 47, 59, 0.00, '2025-12-03 15:50:20'),
(130, 1, 60, 22.00, '2025-12-04 15:52:05'),
(131, 64, 61, 22.00, '2025-12-13 12:21:51'),
(132, 47, 95, 50.00, '2025-12-14 21:31:04');

-- --------------------------------------------------------

--
-- Table structure for table `user_completed_videos`
--

CREATE TABLE `user_completed_videos` (
  `id` int NOT NULL,
  `user_id` int NOT NULL,
  `video_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `completed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `user_completed_videos`
--

INSERT INTO `user_completed_videos` (`id`, `user_id`, `video_id`, `completed_at`) VALUES
(3, 1, 'video_001', '2025-11-24 17:35:59'),
(4, 1, 'video_003', '2025-11-24 18:16:45'),
(5, 1, 'video_002', '2025-11-24 18:43:44'),
(7, 59, 'video_001', '2025-11-25 08:05:43'),
(8, 54, 'video_1764347473_6929ce512bfdc', '2025-11-28 16:40:51'),
(9, 46, 'video_1764347473_6929ce512bfdc', '2025-11-29 16:57:54'),
(10, 54, 'video_1764427950_692b08aecedbc', '2025-12-01 07:49:42'),
(11, 54, 'video_1764674278_692ecae6aa9b2', '2025-12-02 11:24:13'),
(12, 54, 'video_001', '2025-12-02 11:30:27'),
(13, 54, 'video_1764674909_692ecd5d101b6', '2025-12-02 11:33:16');

-- --------------------------------------------------------

--
-- Table structure for table `user_devices`
--

CREATE TABLE `user_devices` (
  `id` int NOT NULL,
  `user_id` int NOT NULL,
  `device_fingerprint` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `device_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `browser` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `os` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `screen_resolution` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `timezone` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_verified` tinyint(1) DEFAULT '0',
  `first_login` datetime DEFAULT CURRENT_TIMESTAMP,
  `last_login` datetime DEFAULT CURRENT_TIMESTAMP,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `user_devices`
--

INSERT INTO `user_devices` (`id`, `user_id`, `device_fingerprint`, `device_name`, `browser`, `os`, `ip_address`, `screen_resolution`, `timezone`, `is_verified`, `first_login`, `last_login`, `created_at`) VALUES
(28, 47, '8b88e8c0ebaf12d815df4044c015119aedcf858ff28481a3557cf27694a0505b', 'Chrome 138 on Android 10', 'Chrome 138', 'Android 10', '102.90.100.163', NULL, NULL, 1, '2025-11-18 08:22:27', '2025-11-18 08:22:27', '2025-11-18 08:22:27'),
(31, 50, '3a95fcd553e316e3c841aef4eff0fb35e546b55507ed24c6e4f596de51decdf5', 'Chrome 138 on Android 10', 'Chrome 138', 'Android 10', '102.90.100.204', NULL, NULL, 1, '2025-11-20 16:12:51', '2025-11-20 16:12:51', '2025-11-20 16:12:51'),
(32, 51, '9e961b0f7a0f22d4b0a349ffc916e9fcfb02856e37aee199e6efe3015eace77d', 'Chrome 138 on Android 10', 'Chrome 138', 'Android 10', '102.90.117.164', NULL, NULL, 1, '2025-11-21 17:33:22', '2025-11-21 17:33:22', '2025-11-21 17:33:22'),
(33, 52, 'd3dad8e0d202d20eba11ed1e64f2c51657a40b3831543bd442783f1759cbcae1', 'Chrome 142 on Windows 10', 'Chrome 142', 'Windows 10', '191.96.227.90', NULL, NULL, 1, '2025-11-21 18:27:01', '2025-11-21 18:27:01', '2025-11-21 18:27:01'),
(34, 53, '86beb3b48bc0c8fd617f794189f108d8c471d7f341aa91b4f1181409ea7a21f7', 'Chrome 140 on Android 10', 'Chrome 140', 'Android 10', '105.120.129.83', NULL, NULL, 1, '2025-11-21 19:32:45', '2025-11-21 19:32:45', '2025-11-21 19:32:45'),
(35, 54, '86beb3b48bc0c8fd617f794189f108d8c471d7f341aa91b4f1181409ea7a21f7', 'Chrome 140 on Android 10', 'Chrome 140', 'Android 10', '102.90.81.210', NULL, NULL, 1, '2025-11-21 20:08:05', '2025-11-21 20:08:05', '2025-11-21 20:08:05'),
(37, 56, '91da33a75eceef449451cbd093fd190d247f99665757de8acf98df3163bdc2d5', 'Chrome 142 on Android 8', 'Chrome 142', 'Android 8', '102.90.118.114', NULL, NULL, 1, '2025-11-22 18:08:37', '2025-11-22 18:08:37', '2025-11-22 18:08:37'),
(38, 58, '99efe2befafe1c449357a0958f47319f39e4dd906164cdebea0854875459f0fa', 'Chrome 138 on Android 10', 'Chrome 138', 'Android 10', '105.113.35.29', NULL, NULL, 1, '2025-11-25 07:00:51', '2025-11-25 07:00:51', '2025-11-25 07:00:51'),
(39, 59, '99efe2befafe1c449357a0958f47319f39e4dd906164cdebea0854875459f0fa', 'Chrome 138 on Android 10', 'Chrome 138', 'Android 10', '105.113.36.133', NULL, NULL, 1, '2025-11-25 07:23:18', '2025-11-25 07:23:18', '2025-11-25 07:23:18'),
(40, 62, 'd3dad8e0d202d20eba11ed1e64f2c51657a40b3831543bd442783f1759cbcae1', 'Chrome 142 on Windows 10', 'Chrome 142', 'Windows 10', '102.90.82.223', NULL, NULL, 1, '2025-11-27 18:12:28', '2025-11-27 18:12:28', '2025-11-27 18:12:28'),
(41, 63, '40763d2070307251c7f3cd66df3d5f5dab9c82e5289017f8ee894110b529d845', 'Chrome 131 on Android 10', 'Chrome 131', 'Android 10', '102.90.82.194', NULL, NULL, 1, '2025-11-27 19:52:19', '2025-11-27 19:52:19', '2025-11-27 19:52:19'),
(42, 65, '18e99da0b2b1c6f38b136c76132524d8a273df91d31c3dceeb5e0aff9ec2f60c', 'Chrome 142 on Android 10', 'Chrome 142', 'Android 10', '102.90.82.223', NULL, NULL, 1, '2025-11-30 11:21:59', '2025-11-30 11:21:59', '2025-11-30 11:21:59'),
(43, 68, '40763d2070307251c7f3cd66df3d5f5dab9c82e5289017f8ee894110b529d845', 'Chrome 131 on Android 10', 'Chrome 131', 'Android 10', '102.90.118.177', NULL, NULL, 1, '2025-12-03 20:06:15', '2025-12-03 20:06:15', '2025-12-03 20:06:15'),
(44, 70, '5d70f8d71602a690116b4e3e549ae5930d432eac944290be5c40a82a6b3bcc99', 'Chrome 142 on Android 10', 'Chrome 142', 'Android 10', '102.88.110.186', NULL, NULL, 1, '2025-12-04 10:03:06', '2025-12-04 10:03:06', '2025-12-04 10:03:06'),
(46, 73, '9edb4e17ee4a49b3edb1ea908baa098d5a7aa04f0cdf25cc5ef33982d6903bae', 'Chrome 138 on Android 10', 'Chrome 138', 'Android 10', '102.90.117.247', NULL, NULL, 1, '2025-12-10 12:03:53', '2025-12-10 12:03:53', '2025-12-10 12:03:53'),
(47, 74, '6428b185d9a1d9af7b49f82a90aaf3360cfa17a495f1b629e1da0275fa1fe686', 'Chrome 136 on Android 10', 'Chrome 136', 'Android 10', '105.112.220.23', NULL, NULL, 1, '2025-12-10 14:07:20', '2025-12-10 14:07:20', '2025-12-10 14:07:20'),
(48, 75, '6428b185d9a1d9af7b49f82a90aaf3360cfa17a495f1b629e1da0275fa1fe686', 'Chrome 136 on Android 10', 'Chrome 136', 'Android 10', '105.112.220.23', NULL, NULL, 1, '2025-12-10 14:10:42', '2025-12-10 14:10:42', '2025-12-10 14:10:42'),
(49, 76, 'e9041ff33b1a686346141b4588e03860bb8b6a33029026625792deb80d1bd52a', 'Chrome 143 on Android 8', 'Chrome 143', 'Android 8', '102.90.97.11', NULL, NULL, 1, '2025-12-14 19:01:17', '2025-12-14 19:01:17', '2025-12-14 19:01:17');

-- --------------------------------------------------------

--
-- Table structure for table `user_message_reads`
--

CREATE TABLE `user_message_reads` (
  `id` int NOT NULL,
  `user_id` int NOT NULL,
  `message_id` int NOT NULL,
  `read_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `user_notification_views`
--

CREATE TABLE `user_notification_views` (
  `id` int NOT NULL,
  `user_id` int NOT NULL,
  `notification_id` int NOT NULL,
  `viewed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `user_playlists`
--

CREATE TABLE `user_playlists` (
  `id` int NOT NULL,
  `user_id` int NOT NULL,
  `track_id` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `track_title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `artist` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cover_image` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `audio_file` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `duration` int NOT NULL,
  `added_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `user_playlists`
--

INSERT INTO `user_playlists` (`id`, `user_id`, `track_id`, `track_title`, `artist`, `cover_image`, `audio_file`, `duration`, `added_at`) VALUES
(1, 1, 'track_1760736285_68f2b41d7d3f4', 'Olamide Badoo', 'Olamide', 'uploads/stream_covers/cover_1760736285_68f2b41d7ccc7.jpeg', 'uploads/stream_tracks/track_1760736285_68f2b41d7c32a.mp3', 190, '2025-10-17 21:25:50'),
(20, 52, 'track_1760499215_68ef160fa7932', 'Billionaires Club', 'Olamide', 'uploads/stream_covers/cover_1760499215_68ef160fa71c5.jpeg', 'uploads/stream_tracks/track_1760499215_68ef160fa68a7.mp3', 4, '2025-11-27 11:36:08'),
(23, 52, 'track_1760736285_68f2b41d7d3f4', 'Olamide Badoo', 'Olamide', 'uploads/stream_covers/cover_1760736285_68f2b41d7ccc7.jpeg', 'uploads/stream_tracks/track_1760736285_68f2b41d7c32a.mp3', 190, '2025-11-27 11:46:15'),
(25, 63, 'track_1760499215_68ef160fa7932', 'Billionaires Club', 'Olamide', 'uploads/stream_covers/cover_1760499215_68ef160fa71c5.jpeg', 'uploads/stream_tracks/track_1760499215_68ef160fa68a7.mp3', 4, '2025-11-27 21:17:54'),
(26, 63, 'track_1760978533_68f66665394b2', 'Olamide', 'Olamide', 'uploads/stream_covers/cover_1760978533_68f6666538f7f.jpeg', 'uploads/stream_tracks/track_1760978533_68f6666538706.mp3', 70, '2025-11-27 21:23:21'),
(27, 50, 'track_1760978533_68f66665394b2', 'Olamide', 'Olamide', 'uploads/stream_covers/cover_1760978533_68f6666538f7f.jpeg', 'uploads/stream_tracks/track_1760978533_68f6666538706.mp3', 70, '2025-11-28 05:33:23'),
(29, 64, 'track_1760499215_68ef160fa7932', 'Billionaires Club', 'Olamide', 'uploads/stream_covers/cover_1760499215_68ef160fa71c5.jpeg', 'uploads/stream_tracks/track_1760499215_68ef160fa68a7.mp3', 4, '2025-11-28 10:58:38'),
(30, 46, 'track_1764344572_6929c2fc5cb01', 'Testing', 'Testing', 'uploads/stream_covers/cover_1764344572_6929c2fc5c990.jpeg', 'uploads/stream_tracks/track_1764344572_6929c2fc5c44c.mp3', 70, '2025-11-28 19:01:25'),
(31, 1, 'track_1764428225_692b09c12cb1d', 'Testing admin track again', 'Testing Admin Track', 'uploads/stream_covers/cover_1764428225_692b09c12ca62.png', 'uploads/stream_tracks/track_1764428225_692b09c12c462.mp3', 70, '2025-11-29 19:33:38'),
(32, 64, 'track_1764428225_692b09c12cb1d', 'Testing admin track again', 'Testing Admin Track', 'uploads/stream_covers/cover_1764428225_692b09c12ca62.png', 'uploads/stream_tracks/track_1764428225_692b09c12c462.mp3', 70, '2025-11-29 19:46:44'),
(33, 54, 'track_1764428225_692b09c12cb1d', 'Testing admin track again', 'Testing Admin Track', 'uploads/stream_covers/cover_1764428225_692b09c12ca62.png', 'uploads/stream_tracks/track_1764428225_692b09c12c462.mp3', 70, '2025-11-30 09:42:23'),
(34, 63, 'track_1764344450_6929c282519c6', 'Obodo Dev', 'Testing', 'uploads/stream_covers/cover_1764344450_6929c28251858.jpeg', 'uploads/stream_tracks/track_1764344450_6929c282512f8.mp3', 70, '2025-12-01 17:24:33'),
(35, 63, 'track_1764344572_6929c2fc5cb01', 'Testing', 'Testing', 'uploads/stream_covers/cover_1764344572_6929c2fc5c990.jpeg', 'uploads/stream_tracks/track_1764344572_6929c2fc5c44c.mp3', 70, '2025-12-01 17:26:31'),
(36, 1, 'track_1764344450_6929c282519c6', 'Obodo Dev', 'Testing', 'uploads/stream_covers/cover_1764344450_6929c28251858.jpeg', 'uploads/stream_tracks/track_1764344450_6929c282512f8.mp3', 70, '2025-12-01 23:14:46'),
(37, 1, 'track_1764344572_6929c2fc5cb01', 'Testing', 'Testing', 'uploads/stream_covers/cover_1764344572_6929c2fc5c990.jpeg', 'uploads/stream_tracks/track_1764344572_6929c2fc5c44c.mp3', 70, '2025-12-01 23:17:12'),
(44, 64, 'track_1764344572_6929c2fc5cb01', 'Testing', 'Testing', 'uploads/stream_covers/cover_1764344572_6929c2fc5c990.jpeg', 'uploads/stream_tracks/track_1764344572_6929c2fc5c44c.mp3', 70, '2025-12-02 14:25:18'),
(48, 47, 'track_1764344572_6929c2fc5cb01', 'Testing', 'Testing', 'uploads/stream_covers/cover_1764344572_6929c2fc5c990.jpeg', 'uploads/stream_tracks/track_1764344572_6929c2fc5c44c.mp3', 70, '2025-12-08 11:09:59'),
(49, 47, 'track_1760499215_68ef160fa7932', 'Billionaires Club', 'Olamide', 'uploads/stream_covers/cover_1760499215_68ef160fa71c5.jpeg', 'uploads/stream_tracks/track_1760499215_68ef160fa68a7.mp3', 4, '2025-12-08 11:16:13');

-- --------------------------------------------------------

--
-- Table structure for table `user_tasks`
--

CREATE TABLE `user_tasks` (
  `id` int NOT NULL,
  `user_id` int NOT NULL,
  `task_id` int NOT NULL,
  `status` enum('pending','in_progress','completed','rejected') COLLATE utf8mb4_unicode_ci DEFAULT 'pending',
  `proof_url` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `completed_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `user_tasks`
--

INSERT INTO `user_tasks` (`id`, `user_id`, `task_id`, `status`, `proof_url`, `completed_at`, `created_at`, `updated_at`) VALUES
(579, 63, 52, 'completed', '+2349138427470', '2025-12-01 17:41:33', '2025-12-01 17:40:28', '2025-12-01 17:41:33'),
(580, 47, 52, 'completed', '+2349138427471', '2025-12-02 10:53:15', '2025-12-02 10:51:48', '2025-12-02 10:53:15'),
(581, 47, 56, 'completed', 'https://www.tiktok.com/@stories.thebibletoldai?_r=1&_t=ZM-91C7WIZPgqZ', '2025-12-02 11:58:56', '2025-12-02 11:54:52', '2025-12-02 11:58:56'),
(582, 54, 53, 'completed', '+2349138427470', '2025-12-02 14:22:33', '2025-12-02 14:17:13', '2025-12-02 14:22:33'),
(583, 54, 52, 'completed', '+2349138427473', '2025-12-02 14:24:15', '2025-12-02 14:23:24', '2025-12-02 14:24:15'),
(584, 47, 59, 'completed', 'karinayuken@gmail.com', '2025-12-03 15:50:20', '2025-12-03 15:49:10', '2025-12-03 15:50:20'),
(585, 1, 60, 'completed', '+2349132482782', '2025-12-04 15:52:05', '2025-12-04 15:51:23', '2025-12-04 15:52:05'),
(586, 64, 61, 'completed', '+2349132482782', '2025-12-13 12:21:51', '2025-12-13 12:21:07', '2025-12-13 13:21:51'),
(587, 47, 95, 'completed', 'karinayuken@gmail.com', '2025-12-14 21:31:04', '2025-12-14 21:30:04', '2025-12-14 22:31:04');

-- --------------------------------------------------------

--
-- Table structure for table `user_verification`
--

CREATE TABLE `user_verification` (
  `id` int NOT NULL,
  `user_id` int NOT NULL,
  `nin` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `full_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `date_of_birth` date NOT NULL,
  `location` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone_number` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `profile_picture` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `portfolio_cv` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `recent_jobs` text COLLATE utf8mb4_unicode_ci,
  `verification_status` enum('pending','approved','rejected') COLLATE utf8mb4_unicode_ci DEFAULT 'pending',
  `admin_notes` text COLLATE utf8mb4_unicode_ci,
  `submitted_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `verified_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `video_earnings`
--

CREATE TABLE `video_earnings` (
  `id` int NOT NULL,
  `user_id` int NOT NULL,
  `video_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `video_title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `amount_earned` decimal(10,2) NOT NULL,
  `profile_link` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `watched_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `video_earnings`
--

INSERT INTO `video_earnings` (`id`, `user_id`, `video_id`, `video_title`, `amount_earned`, `profile_link`, `watched_at`) VALUES
(3, 1, 'video_001', 'Ewo', 500.00, 'https://youtube.com/profileme', '2025-11-24 17:35:59'),
(4, 1, 'video_003', 'Sometimes', 500.00, 'https://youtube.com/profileme', '2025-11-24 18:16:45'),
(5, 1, 'video_002', 'Jelo', 500.00, 'https://youtube.com/emeka', '2025-11-24 18:43:44'),
(7, 59, 'video_001', 'Ewo', 500.00, 'https://www.youtube.com/@StiriesTheBible_Told', '2025-11-25 08:05:43'),
(8, 54, 'video_1764347473_6929ce512bfdc', 'ObodoNwoke', 70.00, 'https://www.tiktok.com/@stories.thebibletoldai?_r=1&_t=ZM-91dxirl8szA', '2025-11-28 16:40:51'),
(9, 46, 'video_1764347473_6929ce512bfdc', 'ObodoNwoke', 70.00, 'https://www.tiktok.com/@story_of_lights?_r=1&_t=ZS-91oCXB2m8Yi', '2025-11-29 16:57:54'),
(10, 54, 'video_1764427950_692b08aecedbc', 'Testing Again', 900.00, 'https://www.twitter.com/@stories.thebibletoldai?_r=1&_t=ZM-91C7WIZPgqZ', '2025-12-01 07:49:42'),
(11, 54, 'video_1764674278_692ecae6aa9b2', 'Watch well', 75.00, 'https://www.tiktok.com/@stories.thebibletoldai?_r=1&_t=ZM-91C7WIZPgqZ', '2025-12-02 11:24:13'),
(12, 54, 'video_001', 'Ewo', 500.00, 'https://www.youtube.com/@stories.thebibletoldai?_r=1&_t=ZM-91C7WIZPgqZ', '2025-12-02 11:30:27'),
(13, 54, 'video_1764674909_692ecd5d101b6', 'Good', 75.00, 'https://www.linkedIn.com/@stories.thebibletoldai?_r=1&_t=ZM-91C7WIZPgqZ', '2025-12-02 11:33:16');

-- --------------------------------------------------------

--
-- Table structure for table `whot_bets`
--

CREATE TABLE `whot_bets` (
  `id` int NOT NULL,
  `game_id` int NOT NULL,
  `user_id` int NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `result` enum('win','lose','draw','pending') COLLATE utf8mb4_unicode_ci DEFAULT 'pending',
  `processed` tinyint(1) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `whot_games`
--

CREATE TABLE `whot_games` (
  `id` int NOT NULL,
  `game_mode` enum('local','multiplayer','bet_ai','bet_multiplayer') COLLATE utf8mb4_unicode_ci NOT NULL,
  `ai_difficulty` enum('easy','medium','hard') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bet_amount` decimal(10,2) DEFAULT '0.00',
  `status` enum('waiting','in_progress','completed','cancelled') COLLATE utf8mb4_unicode_ci DEFAULT 'waiting',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `ended_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `whot_game_moves`
--

CREATE TABLE `whot_game_moves` (
  `id` int NOT NULL,
  `game_id` int NOT NULL,
  `player_id` int NOT NULL,
  `card_played` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `action` enum('play','pick','whot_call') COLLATE utf8mb4_unicode_ci NOT NULL,
  `turn_time` decimal(8,2) DEFAULT '0.00',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `whot_game_players`
--

CREATE TABLE `whot_game_players` (
  `id` int NOT NULL,
  `game_id` int NOT NULL,
  `user_id` int DEFAULT NULL,
  `is_ai` tinyint(1) DEFAULT '0',
  `ai_level` enum('easy','medium','hard') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cards_left` int DEFAULT '0',
  `moves` int DEFAULT '0',
  `is_winner` tinyint(1) DEFAULT '0',
  `joined_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `withdrawals`
--

CREATE TABLE `withdrawals` (
  `id` int NOT NULL,
  `user_id` int NOT NULL,
  `withdrawal_type` enum('prime_earnings','activity_earnings') COLLATE utf8mb4_unicode_ci NOT NULL,
  `amount` decimal(15,2) NOT NULL,
  `status` enum('pending','processing','completed','rejected') COLLATE utf8mb4_unicode_ci DEFAULT 'pending',
  `payment_method` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `account_details` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `admin_notes` text COLLATE utf8mb4_unicode_ci,
  `requested_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `processed_at` timestamp NULL DEFAULT NULL,
  `paystack_transfer_id` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `paystack_status` enum('not_initiated','pending','success','failed','reversed') COLLATE utf8mb4_unicode_ci DEFAULT 'not_initiated',
  `paystack_error_message` text COLLATE utf8mb4_unicode_ci,
  `paystack_initiated_at` timestamp NULL DEFAULT NULL,
  `paystack_completed_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `withdrawals`
--

INSERT INTO `withdrawals` (`id`, `user_id`, `withdrawal_type`, `amount`, `status`, `payment_method`, `account_details`, `admin_notes`, `requested_at`, `processed_at`, `paystack_transfer_id`, `paystack_status`, `paystack_error_message`, `paystack_initiated_at`, `paystack_completed_at`) VALUES
(1, 1, '', 4000.00, 'completed', 'bank_transfer', '{\"account_name\":\"obodo\",\"account_number\":\"1790196559\",\"bank_name\":\"Access Bank\",\"payment_method\":\"bank_transfer\"}', NULL, '2025-10-10 11:28:32', '2025-11-30 14:46:48', NULL, '', 'Manually completed by admin', NULL, NULL),
(2, 1, '', 3000.00, 'completed', 'bank_transfer', '{\"account_name\":\"Obodo Nwoke\",\"account_number\":\"1790196559\",\"bank_name\":\"Opay\",\"payment_method\":\"bank_transfer\"}', NULL, '2025-10-12 15:42:12', '2025-12-04 10:08:25', NULL, '', 'Manually completed by admin', NULL, NULL),
(3, 1, '', 3000.00, 'processing', 'bank_transfer', '{\"account_name\":\"Obodo Nwoke\",\"account_number\":\"1790196559\",\"bank_name\":\"Opay\",\"payment_method\":\"bank_transfer\"}', NULL, '2025-10-12 15:57:09', NULL, NULL, 'not_initiated', NULL, NULL, NULL),
(4, 1, '', 4000.00, 'processing', 'bank_transfer', '{\"account_name\":\"Obodo Nwoke\",\"account_number\":\"1790196559\",\"bank_name\":\"Opay\",\"payment_method\":\"bank_transfer\"}', NULL, '2025-10-12 16:06:23', NULL, NULL, 'not_initiated', NULL, NULL, NULL),
(5, 1, '', 4000.00, 'processing', 'bank_transfer', '{\"account_name\":\"Obodo Nwoke\",\"account_number\":\"1790196559\",\"bank_name\":\"Opay\",\"payment_method\":\"bank_transfer\"}', NULL, '2025-10-12 16:13:30', NULL, NULL, 'not_initiated', NULL, NULL, NULL),
(6, 1, '', 4000.00, 'processing', 'bank_transfer', '{\"account_name\":\"Obodo Nwoke\",\"account_number\":\"1790196559\",\"bank_name\":\"Opay\",\"payment_method\":\"bank_transfer\"}', NULL, '2025-10-12 16:15:37', NULL, NULL, 'not_initiated', NULL, NULL, NULL),
(7, 1, '', 4000.00, 'processing', 'bank_transfer', '{\"account_name\":\"Obodo Nwoke\",\"account_number\":\"1790196559\",\"bank_name\":\"Opay\",\"payment_method\":\"bank_transfer\"}', NULL, '2025-10-12 16:20:35', NULL, NULL, 'not_initiated', NULL, NULL, NULL),
(8, 1, '', 4000.00, 'processing', 'bank_transfer', '{\"account_name\":\"Obodo Nwoke\",\"account_number\":\"1790196559\",\"bank_name\":\"Opay\",\"payment_method\":\"bank_transfer\"}', NULL, '2025-10-12 16:21:48', NULL, NULL, 'not_initiated', NULL, NULL, NULL),
(9, 1, '', 4000.00, 'processing', 'bank_transfer', '{\"account_name\":\"Obodo Nwoke\",\"account_number\":\"1790196559\",\"bank_name\":\"Opay\",\"payment_method\":\"bank_transfer\"}', NULL, '2025-10-12 16:23:17', NULL, NULL, 'not_initiated', NULL, NULL, NULL),
(10, 1, '', 4000.00, 'processing', 'bank_transfer', '{\"account_name\":\"Obodo Nwoke\",\"account_number\":\"1790196559\",\"bank_name\":\"Opay\",\"payment_method\":\"bank_transfer\"}', NULL, '2025-10-12 16:25:26', NULL, NULL, 'not_initiated', NULL, NULL, NULL),
(11, 1, '', 4000.00, 'processing', 'bank_transfer', '{\"account_name\":\"Obodo Nwoke\",\"account_number\":\"1790196559\",\"bank_name\":\"Opay\",\"payment_method\":\"bank_transfer\"}', NULL, '2025-10-12 16:26:12', NULL, NULL, 'not_initiated', NULL, NULL, NULL),
(12, 1, '', 4999.99, 'processing', 'bank_transfer', '{\"account_name\":\"Obodo Nwoke\",\"account_number\":\"1790196559\",\"bank_name\":\"Opay\",\"payment_method\":\"bank_transfer\"}', NULL, '2025-10-12 22:29:13', NULL, NULL, 'not_initiated', NULL, NULL, NULL),
(59, 1, 'prime_earnings', 200.00, 'processing', 'mobile_money', '{\"account_name\":\"CHIBUEZE STANLEY EBERECHUKWU\",\"account_number\":\"9132482782\",\"bank_name\":\"OPay Digital Services Limited (OPay)\",\"bank_code\":\"999992\",\"payment_method\":\"mobile_money\"}', NULL, '2025-11-28 20:35:17', NULL, 'TRF_u0syk3qf63vsqded', 'pending', NULL, '2025-11-28 22:25:37', NULL),
(60, 1, 'prime_earnings', 500.00, 'processing', 'mobile_money', '{\"account_name\":\"CHIBUEZE STANLEY EBERECHUKWU\",\"account_number\":\"1790196559\",\"bank_name\":\"Access Bank\",\"bank_code\":\"044\",\"payment_method\":\"mobile_money\"}', NULL, '2025-11-28 21:18:56', NULL, 'TRF_ggkz4p1j33is9uc6', 'pending', NULL, '2025-11-28 22:25:38', NULL),
(61, 1, 'prime_earnings', 500.00, 'processing', 'bank_transfer', '{\"account_name\":\"CHIBUEZE STANLEY EBERECHUKWU\",\"account_number\":\"1790196559\",\"bank_name\":\"Access Bank\",\"bank_code\":\"044\",\"payment_method\":\"bank_transfer\"}', NULL, '2025-11-28 21:35:46', NULL, 'TRF_3nmadaas0srb1h38', 'pending', NULL, '2025-11-28 22:25:39', NULL),
(62, 1, 'prime_earnings', 300.00, 'completed', 'bank_transfer', '{\"account_name\":\"CHIBUEZE STANLEY EBERECHUKWU\",\"account_number\":\"1790196559\",\"bank_name\":\"Access Bank\",\"bank_code\":\"044\",\"payment_method\":\"bank_transfer\"}', NULL, '2025-11-28 22:11:56', '2025-11-30 09:57:03', 'TRF_mlsdbcu401f8puwj', 'success', 'You cannot initiate third party payouts at this time', '2025-11-30 09:51:23', '2025-11-30 09:57:03'),
(63, 1, 'prime_earnings', 350.00, 'completed', 'bank_transfer', '{\"account_name\":\"CHIBUEZE STANLEY EBERECHUKWU\",\"account_number\":\"1790196559\",\"bank_name\":\"Access Bank\",\"bank_code\":\"044\",\"payment_method\":\"bank_transfer\"}', NULL, '2025-11-28 22:25:36', '2025-11-29 11:00:42', 'TRF_rs6hz1100kmz58kb', '', 'Manually completed by admin', '2025-11-28 22:25:41', NULL),
(64, 54, 'prime_earnings', 360.00, 'completed', 'bank_transfer', '{\"account_name\":\"KENECHUKWU FRANKLIN IFEAMAH\",\"account_number\":\"9138427470\",\"bank_name\":\"PalmPay\",\"bank_code\":\"999991\",\"payment_method\":\"bank_transfer\"}', NULL, '2025-11-29 04:47:01', '2025-11-29 04:47:06', 'TRF_5hbydl52bl8nj4wz', 'success', NULL, '2025-11-29 04:47:06', '2025-11-29 04:47:06'),
(65, 46, 'prime_earnings', 200.00, 'completed', 'bank_transfer', '{\"account_name\":\"CHINECHEREM MECHACK IFEAMA\",\"account_number\":\"9133600755\",\"bank_name\":\"PalmPay\",\"bank_code\":\"999991\",\"payment_method\":\"bank_transfer\"}', NULL, '2025-11-29 06:09:13', '2025-11-29 06:09:17', 'TRF_p46369ahzb6fhi0j', 'pending', NULL, '2025-11-29 06:09:18', '2025-11-29 06:09:17'),
(66, 54, 'prime_earnings', 2000.00, 'completed', 'bank_transfer', '{\"account_name\":\"KENECHUKWU FRANKLIN IFEAMAH\",\"account_number\":\"9138427470\",\"bank_name\":\"PalmPay\",\"bank_code\":\"999991\",\"payment_method\":\"bank_transfer\"}', NULL, '2025-11-29 09:26:41', '2025-11-29 09:26:47', 'TRF_nsxr3el7vhxfkuac', 'pending', NULL, '2025-11-29 09:26:47', '2025-11-29 09:26:47'),
(73, 54, 'prime_earnings', 3200.00, 'completed', 'bank_transfer', '{\"account_name\":\"KENECHUKWU FRANKLIN IFEAMAH\",\"account_number\":\"9138427470\",\"bank_name\":\"PalmPay\",\"bank_code\":\"999991\",\"payment_method\":\"bank_transfer\"}', NULL, '2025-11-29 15:07:58', '2025-11-29 18:18:47', NULL, '', 'Manually completed by admin', NULL, NULL),
(74, 47, 'prime_earnings', 300.00, 'completed', 'bank_transfer', '{\"account_name\":\"KENECHUKWU FRANKLIN IFEAMAH\",\"account_number\":\"9138427470\",\"bank_name\":\"OPay Digital Services Limited (OPay)\",\"bank_code\":\"999992\",\"payment_method\":\"bank_transfer\"}', NULL, '2025-11-29 16:21:18', '2025-11-30 09:52:05', 'TRF_mg257hrmo54wctly', 'success', 'You cannot initiate third party payouts at this time', '2025-11-30 09:51:26', '2025-11-30 09:52:05'),
(75, 1, 'prime_earnings', 200.00, 'completed', 'mobile_money', '{\"account_name\":\"CHIBUEZE STANLEY EBERECHUKWU\",\"account_number\":\"1790196559\",\"bank_name\":\"\",\"bank_code\":\"044\",\"payment_method\":\"mobile_money\"}', NULL, '2025-11-29 20:00:43', '2025-11-30 09:57:03', 'TRF_n2cyuzpq8z3mkvkw', 'success', 'You cannot initiate third party payouts at this time', '2025-11-30 09:51:28', '2025-11-30 09:57:03'),
(76, 1, 'prime_earnings', 200.00, 'completed', 'bank_transfer', '{\"account_name\":\"CHIBUEZE STANLEY EBERECHUKWU\",\"account_number\":\"1790196559\",\"bank_name\":\"Access Bank\",\"bank_code\":\"044\",\"payment_method\":\"bank_transfer\"}', NULL, '2025-11-29 20:02:54', '2025-11-30 09:57:03', 'TRF_qymg5hgqprm2dk6t', 'success', 'You cannot initiate third party payouts at this time', '2025-11-30 09:51:31', '2025-11-30 09:57:03'),
(77, 54, 'prime_earnings', 200.00, 'completed', 'bank_transfer', '{\"account_name\":\"KENECHUKWU FRANKLIN IFEAMAH\",\"account_number\":\"9138427470\",\"bank_name\":\"PalmPay\",\"bank_code\":\"999991\",\"payment_method\":\"bank_transfer\"}', NULL, '2025-11-30 09:51:20', '2025-11-30 09:57:04', 'TRF_yonlh4x8n21ecy4m', 'success', NULL, '2025-11-30 09:51:34', '2025-11-30 09:57:04'),
(78, 54, 'prime_earnings', 1000.00, 'completed', 'bank_transfer', '{\"account_name\":\"KENECHUKWU FRANKLIN IFEAMAH\",\"account_number\":\"9138427470\",\"bank_name\":\"PalmPay\",\"bank_code\":\"999991\",\"payment_method\":\"bank_transfer\"}', NULL, '2025-12-01 07:22:18', '2025-12-01 07:22:22', 'TRF_odwrb9cfrqwyiz2b', 'pending', NULL, '2025-12-01 07:22:23', '2025-12-01 07:22:22'),
(79, 54, 'prime_earnings', 1000.00, 'completed', 'bank_transfer', '{\"account_name\":\"KENECHUKWU FRANKLIN IFEAMAH\",\"account_number\":\"9138427470\",\"bank_name\":\"PalmPay\",\"bank_code\":\"999991\",\"payment_method\":\"bank_transfer\"}', NULL, '2025-12-01 08:57:38', '2025-12-01 08:57:42', 'TRF_u1y0rjdqq64ioo7q', 'success', NULL, '2025-12-01 08:57:42', '2025-12-01 08:57:42'),
(80, 54, 'prime_earnings', 20000.00, 'rejected', 'bank_transfer', '{\"account_name\":\"KENECHUKWU FRANKLIN IFEAMAH\",\"account_number\":\"9138427470\",\"bank_name\":\"PalmPay\",\"bank_code\":\"999991\",\"payment_method\":\"bank_transfer\"}', NULL, '2025-12-01 13:26:46', '2025-12-01 13:33:13', NULL, 'failed', 'Your balance is not enough to fulfil this request', NULL, NULL),
(81, 54, 'prime_earnings', 30000.00, 'rejected', 'bank_transfer', '{\"account_name\":\"KENECHUKWU FRANKLIN IFEAMAH\",\"account_number\":\"9138427470\",\"bank_name\":\"PalmPay\",\"bank_code\":\"999991\",\"payment_method\":\"bank_transfer\"}', NULL, '2025-12-01 13:32:25', '2025-12-01 13:39:11', NULL, 'failed', 'Your balance is not enough to fulfil this request', NULL, NULL),
(82, 54, 'prime_earnings', 10000.00, 'rejected', 'bank_transfer', '{\"account_name\":\"KENECHUKWU FRANKLIN IFEAMAH\",\"account_number\":\"9138427470\",\"bank_name\":\"PalmPay\",\"bank_code\":\"999991\",\"payment_method\":\"bank_transfer\"}', NULL, '2025-12-01 13:35:49', '2025-12-01 13:36:39', NULL, 'failed', 'Your balance is not enough to fulfil this request', NULL, NULL),
(83, 54, 'prime_earnings', 23000.00, 'processing', 'mobile_money', '{\"account_name\":\"KENECHUKWU FRANKLIN IFEAMAH\",\"account_number\":\"9138427470\",\"bank_name\":\"\",\"bank_code\":\"999991\",\"payment_method\":\"mobile_money\"}', NULL, '2025-12-01 13:40:40', NULL, NULL, 'failed', 'Your balance is not enough to fulfil this request', NULL, NULL),
(84, 54, 'prime_earnings', 20000.00, 'processing', 'bank_transfer', '{\"account_name\":\"KENECHUKWU FRANKLIN IFEAMAH\",\"account_number\":\"9138427470\",\"bank_name\":\"PalmPay\",\"bank_code\":\"999991\",\"payment_method\":\"bank_transfer\"}', NULL, '2025-12-01 13:42:26', NULL, NULL, 'failed', 'Your balance is not enough to fulfil this request', NULL, NULL),
(85, 54, 'prime_earnings', 10000.00, 'completed', 'bank_transfer', '{\"account_name\":\"KENECHUKWU FRANKLIN IFEAMAH\",\"account_number\":\"9138427470\",\"bank_name\":\"PalmPay\",\"bank_code\":\"999991\",\"payment_method\":\"bank_transfer\"}', NULL, '2025-12-01 13:43:44', '2025-12-01 17:57:31', NULL, '', 'Manually completed by admin', NULL, NULL),
(86, 54, 'prime_earnings', 10000.00, 'rejected', 'mobile_money', '{\"account_name\":\"KENECHUKWU FRANKLIN IFEAMAH\",\"account_number\":\"9138427470\",\"bank_name\":\"\",\"bank_code\":\"999991\",\"payment_method\":\"mobile_money\"}', NULL, '2025-12-01 13:44:14', '2025-12-01 13:47:29', NULL, 'failed', 'Your balance is not enough to fulfil this request', NULL, NULL),
(87, 54, 'prime_earnings', 10000.00, 'completed', 'bank_transfer', '{\"account_name\":\"KENECHUKWU FRANKLIN IFEAMAH\",\"account_number\":\"9138427470\",\"bank_name\":\"PalmPay\",\"bank_code\":\"999991\",\"payment_method\":\"bank_transfer\"}', NULL, '2025-12-02 14:47:34', '2025-12-02 14:49:29', NULL, '', 'Manually completed by admin', NULL, NULL),
(88, 47, 'activity_earnings', 26000.00, 'completed', 'bank_transfer', '{\"account_name\":\"KENECHUKWU FRANKLIN IFEAMAH\",\"account_number\":\"9138427470\",\"bank_name\":\"OPay Digital Services Limited (OPay)\",\"bank_code\":\"999992\",\"payment_method\":\"bank_transfer\"}', NULL, '2025-12-03 21:28:40', '2025-12-03 21:35:01', NULL, 'not_initiated', NULL, NULL, NULL),
(89, 47, 'prime_earnings', 10000.00, 'processing', 'bank_transfer', '{\"account_name\":\"KENECHUKWU FRANKLIN IFEAMAH\",\"account_number\":\"9138427470\",\"bank_name\":\"OPay Digital Services Limited (OPay)\",\"bank_code\":\"999992\",\"payment_method\":\"bank_transfer\"}', NULL, '2025-12-03 22:14:05', NULL, NULL, 'failed', 'Your balance is not enough to fulfil this request', NULL, NULL),
(90, 46, 'prime_earnings', 50000.00, 'processing', 'bank_transfer', '{\"account_name\":\"CHINECHEREM MECHACK IFEAMA\",\"account_number\":\"9133600755\",\"bank_name\":\"PalmPay\",\"bank_code\":\"999991\",\"payment_method\":\"bank_transfer\"}', NULL, '2025-12-04 10:20:54', NULL, NULL, 'failed', 'Your balance is not enough to fulfil this request', NULL, NULL),
(91, 47, 'prime_earnings', 1500.00, 'completed', 'bank_transfer', '{\"account_name\":\"KENECHUKWU FRANKLIN IFEAMAH\",\"account_number\":\"9138427470\",\"bank_name\":\"PalmPay\",\"bank_code\":\"999991\",\"payment_method\":\"bank_transfer\"}', NULL, '2025-12-08 17:50:45', '2025-12-08 17:50:48', 'TRF_nmg5rzs7q8nu4g9z', 'success', NULL, '2025-12-08 17:50:48', '2025-12-08 17:50:48'),
(92, 47, 'prime_earnings', 300.00, 'completed', 'bank_transfer', '{\"account_name\":\"KENECHUKWU FRANKLIN IFEAMAH\",\"account_number\":\"9138427470\",\"bank_name\":\"PalmPay\",\"bank_code\":\"999991\",\"payment_method\":\"bank_transfer\"}', NULL, '2025-12-09 07:29:01', '2025-12-09 07:29:04', 'TRF_tp94mjiuehzn2csw', 'success', NULL, '2025-12-09 07:29:04', '2025-12-09 07:29:04'),
(93, 1, 'activity_earnings', 500.00, 'pending', 'bank_transfer', '{\"account_name\":\"CHIBUEZE STANLEY EBERECHUKWU\",\"account_number\":\"1790196559\",\"bank_name\":\"Access Bank\",\"bank_code\":\"044\",\"payment_method\":\"bank_transfer\"}', NULL, '2025-12-09 08:21:37', NULL, NULL, 'not_initiated', NULL, NULL, NULL),
(94, 1, 'prime_earnings', 200.00, 'completed', 'bank_transfer', '{\"account_name\":\"CHIBUEZE STANLEY EBERECHUKWU\",\"account_number\":\"9132482782\",\"bank_name\":\"OPay Digital Services Limited (OPay)\",\"bank_code\":\"999992\",\"payment_method\":\"bank_transfer\"}', NULL, '2025-12-09 10:21:33', '2025-12-10 12:50:00', 'TRF_6ite98fd5dmz2msq', 'pending', 'Your balance is not enough to fulfil this request', '2025-12-10 12:50:00', '2025-12-10 12:50:00'),
(95, 47, 'activity_earnings', 26000.00, 'pending', 'bank_transfer', '{\"account_name\":\"KENECHUKWU FRANKLIN IFEAMAH\",\"account_number\":\"9138427470\",\"bank_name\":\"PalmPay\",\"bank_code\":\"999991\",\"payment_method\":\"bank_transfer\"}', NULL, '2025-12-09 19:07:56', NULL, NULL, 'not_initiated', NULL, NULL, NULL),
(96, 47, 'prime_earnings', 200.00, 'completed', 'bank_transfer', '{\"account_name\":\"KENECHUKWU FRANKLIN IFEAMAH\",\"account_number\":\"9138427470\",\"bank_name\":\"PalmPay\",\"bank_code\":\"999991\",\"payment_method\":\"bank_transfer\"}', NULL, '2025-12-10 12:49:58', '2025-12-10 12:50:04', 'TRF_kavc0ejgjtgkar3b', 'pending', NULL, '2025-12-10 12:50:05', '2025-12-10 12:50:04'),
(97, 54, 'prime_earnings', 200.00, 'completed', 'bank_transfer', '{\"account_name\":\"KENECHUKWU FRANKLIN IFEAMAH\",\"account_number\":\"9138427470\",\"bank_name\":\"OPay Digital Services Limited (OPay)\",\"bank_code\":\"999992\",\"payment_method\":\"bank_transfer\"}', NULL, '2025-12-10 13:14:32', '2025-12-10 13:14:40', 'TRF_g5ujdm2oh788v9dc', 'success', NULL, '2025-12-10 13:14:40', '2025-12-10 13:14:40'),
(98, 47, 'prime_earnings', 200.00, 'completed', 'bank_transfer', '{\"account_name\":\"KENECHUKWU FRANKLIN IFEAMAH\",\"account_number\":\"1692977784\",\"bank_name\":\"Access Bank\",\"bank_code\":\"044\",\"payment_method\":\"bank_transfer\"}', NULL, '2025-12-11 22:59:25', '2025-12-11 22:59:28', 'TRF_hdbfoc5yh5xjcat3', 'success', NULL, '2025-12-11 22:59:28', '2025-12-11 22:59:28'),
(99, 54, 'prime_earnings', 200.00, 'completed', 'bank_transfer', '{\"account_name\":\"KENECHUKWU FRANKLIN IFEAMAH\",\"account_number\":\"1692977784\",\"bank_name\":\"Access Bank\",\"bank_code\":\"044\",\"payment_method\":\"bank_transfer\"}', NULL, '2025-12-11 23:05:03', '2025-12-11 23:05:06', 'TRF_1ui6s5dgv88sm1xn', 'pending', NULL, '2025-12-11 23:05:07', '2025-12-11 23:05:06'),
(100, 46, 'prime_earnings', 6000.00, 'processing', 'bank_transfer', '{\"account_name\":\"CHINECHEREM MECHACK IFEAMA\",\"account_number\":\"9133600755\",\"bank_name\":\"PalmPay\",\"bank_code\":\"999991\",\"payment_method\":\"bank_transfer\"}', NULL, '2025-12-12 12:50:03', NULL, NULL, 'failed', 'Your balance is not enough to fulfil this request', NULL, NULL),
(101, 46, 'activity_earnings', 50000.00, 'pending', 'bank_transfer', '{\"account_name\":\"CHINECHEREM MECHACK IFEAMA\",\"account_number\":\"9133600755\",\"bank_name\":\"PalmPay\",\"bank_code\":\"999991\",\"payment_method\":\"bank_transfer\"}', NULL, '2025-12-12 12:51:05', NULL, NULL, 'not_initiated', NULL, NULL, NULL),
(102, 54, 'prime_earnings', 200.00, 'completed', 'bank_transfer', '{\"account_name\":\"KENECHUKWU FRANKLIN IFEAMAH\",\"account_number\":\"1692977784\",\"bank_name\":\"Access Bank\",\"bank_code\":\"044\",\"payment_method\":\"bank_transfer\"}', NULL, '2025-12-14 05:38:34', '2025-12-14 05:38:37', 'TRF_d5t85ub23lmkxi7m', 'success', NULL, '2025-12-14 05:38:37', '2025-12-14 05:38:37'),
(103, 73, 'prime_earnings', 300.00, 'completed', 'bank_transfer', '{\"account_name\":\"KENECHUKWU FRANKLIN IFEAMAH\",\"account_number\":\"1692977784\",\"bank_name\":\"Access Bank\",\"bank_code\":\"044\",\"payment_method\":\"bank_transfer\"}', NULL, '2025-12-14 12:43:01', '2025-12-14 12:43:05', 'TRF_e2x7oys9texaqg4u', 'pending', NULL, '2025-12-14 12:43:06', '2025-12-14 12:43:05'),
(104, 73, 'prime_earnings', 200.00, 'completed', 'bank_transfer', '{\"account_name\":\"KENECHUKWU FRANKLIN IFEAMAH\",\"account_number\":\"9138427470\",\"bank_name\":\"OPay Digital Services Limited (OPay)\",\"bank_code\":\"999992\",\"payment_method\":\"bank_transfer\"}', NULL, '2025-12-14 12:46:07', '2025-12-14 12:46:10', 'TRF_i6tuzb3s4siwaqxe', 'success', NULL, '2025-12-14 12:46:10', '2025-12-14 12:46:10');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_messages`
--
ALTER TABLE `admin_messages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `admin_notifications`
--
ALTER TABLE `admin_notifications`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_active` (`is_active`);

--
-- Indexes for table `advertisements`
--
ALTER TABLE `advertisements`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_active` (`is_active`),
  ADD KEY `idx_user` (`user_id`);

--
-- Indexes for table `advertiser_payments`
--
ALTER TABLE `advertiser_payments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_user` (`user_id`),
  ADD KEY `idx_status` (`status`);

--
-- Indexes for table `ad_invite_commissions`
--
ALTER TABLE `ad_invite_commissions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_referrer` (`referrer_id`),
  ADD KEY `idx_referred` (`referred_user_id`),
  ADD KEY `idx_created` (`created_at`);

--
-- Indexes for table `available_music`
--
ALTER TABLE `available_music`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `music_id` (`music_id`),
  ADD KEY `idx_active` (`is_active`);

--
-- Indexes for table `available_videos`
--
ALTER TABLE `available_videos`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `video_id` (`video_id`),
  ADD KEY `idx_active` (`is_active`),
  ADD KEY `idx_is_compulsory` (`is_compulsory`),
  ADD KEY `idx_platform` (`platform`),
  ADD KEY `idx_uploaded_by_user` (`uploaded_by_user_id`);

--
-- Indexes for table `balances`
--
ALTER TABLE `balances`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_user_balance` (`user_id`),
  ADD KEY `idx_user_id` (`user_id`),
  ADD KEY `idx_game_earnings` (`game_earnings`);

--
-- Indexes for table `billing_information`
--
ALTER TABLE `billing_information`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `chat_earn_emojis`
--
ALTER TABLE `chat_earn_emojis`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `idx_message` (`message_id`);

--
-- Indexes for table `chat_earn_history`
--
ALTER TABLE `chat_earn_history`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_pairing` (`user_id`,`paired_user_id`),
  ADD KEY `idx_user_id` (`user_id`),
  ADD KEY `idx_paired_user_id` (`paired_user_id`);

--
-- Indexes for table `chat_earn_messages`
--
ALTER TABLE `chat_earn_messages`
  ADD PRIMARY KEY (`id`),
  ADD KEY `paired_user_id` (`paired_user_id`),
  ADD KEY `idx_user_paired` (`user_id`,`paired_user_id`),
  ADD KEY `idx_sent_at` (`sent_at`);

--
-- Indexes for table `color_predictor_games`
--
ALTER TABLE `color_predictor_games`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_user_id` (`user_id`),
  ADD KEY `idx_created_at` (`created_at`);

--
-- Indexes for table `color_predictor_stats`
--
ALTER TABLE `color_predictor_stats`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `user_id` (`user_id`),
  ADD KEY `idx_total_profit` (`total_profit`),
  ADD KEY `idx_total_wins` (`total_wins`);

--
-- Indexes for table `daily_rewards`
--
ALTER TABLE `daily_rewards`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_daily_claim` (`user_id`,`reward_date`),
  ADD KEY `idx_user_date` (`user_id`,`reward_date`);

--
-- Indexes for table `device_login_verifications`
--
ALTER TABLE `device_login_verifications`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_user_device` (`user_id`,`device_fingerprint`),
  ADD KEY `idx_verification_code` (`verification_code`),
  ADD KEY `idx_expires_at` (`expires_at`);

--
-- Indexes for table `device_registration_log`
--
ALTER TABLE `device_registration_log`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `idx_device_fingerprint` (`device_fingerprint`);

--
-- Indexes for table `game_wins`
--
ALTER TABLE `game_wins`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `jobs`
--
ALTER TABLE `jobs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_active` (`is_active`),
  ADD KEY `idx_created_by` (`created_by`),
  ADD KEY `idx_approval_status` (`approval_status`,`is_active`);

--
-- Indexes for table `job_bids`
--
ALTER TABLE `job_bids`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_user_job_bid` (`user_id`,`job_id`),
  ADD KEY `idx_job` (`job_id`),
  ADD KEY `idx_user` (`user_id`),
  ADD KEY `idx_status` (`bid_status`);

--
-- Indexes for table `korapay_post_task_payloads`
--
ALTER TABLE `korapay_post_task_payloads`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `reference` (`reference`),
  ADD KEY `idx_reference` (`reference`),
  ADD KEY `idx_user_id` (`user_id`);

--
-- Indexes for table `korapay_post_task_payments`
--
ALTER TABLE `korapay_post_task_payments`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `reference` (`reference`),
  ADD KEY `idx_user_id` (`user_id`),
  ADD KEY `idx_reference` (`reference`),
  ADD KEY `idx_status` (`status`),
  ADD KEY `idx_created_at` (`created_at`);

--
-- Indexes for table `korapay_transactions`
--
ALTER TABLE `korapay_transactions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `korapay_reference` (`korapay_reference`),
  ADD KEY `idx_user_id` (`user_id`),
  ADD KEY `idx_korapay_reference` (`korapay_reference`),
  ADD KEY `idx_status` (`status`),
  ADD KEY `idx_created_at` (`created_at`);

--
-- Indexes for table `korapay_webhooks`
--
ALTER TABLE `korapay_webhooks`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_webhook_reference` (`webhook_reference`),
  ADD KEY `idx_event_type` (`event_type`),
  ADD KEY `idx_processed` (`processed`);

--
-- Indexes for table `leaderboards`
--
ALTER TABLE `leaderboards`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_user_type` (`user_id`,`leaderboard_type`),
  ADD KEY `idx_type_rank` (`leaderboard_type`,`rank_position`);

--
-- Indexes for table `music_earnings`
--
ALTER TABLE `music_earnings`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_user_music` (`user_id`,`music_id`),
  ADD KEY `idx_listened_at` (`listened_at`);

--
-- Indexes for table `mystery_box_games`
--
ALTER TABLE `mystery_box_games`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_user_games` (`user_id`,`created_at`),
  ADD KEY `idx_created_at` (`created_at`);

--
-- Indexes for table `mystery_box_stats`
--
ALTER TABLE `mystery_box_stats`
  ADD PRIMARY KEY (`user_id`),
  ADD KEY `idx_total_profit` (`total_profit`),
  ADD KEY `idx_total_wins` (`total_wins`);

--
-- Indexes for table `newsletters_subscribers`
--
ALTER TABLE `newsletters_subscribers`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD KEY `idx_subscription_status` (`subscription_status`),
  ADD KEY `idx_is_confirmed` (`is_confirmed`),
  ADD KEY `idx_user_id` (`user_id`),
  ADD KEY `idx_subscribed_at` (`subscribed_at`);

--
-- Indexes for table `newsletter_campaigns`
--
ALTER TABLE `newsletter_campaigns`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_status` (`status`),
  ADD KEY `idx_created_by` (`created_by`),
  ADD KEY `idx_sent_at` (`sent_at`);

--
-- Indexes for table `notification_recipients`
--
ALTER TABLE `notification_recipients`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_notification_recipient` (`message_id`,`user_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `billing_info_id` (`billing_info_id`);

--
-- Indexes for table `password_reset_codes`
--
ALTER TABLE `password_reset_codes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `idx_email` (`email`),
  ADD KEY `idx_reset_code` (`reset_code`),
  ADD KEY `idx_expires_at` (`expires_at`);

--
-- Indexes for table `paystack_transfer_logs`
--
ALTER TABLE `paystack_transfer_logs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_withdrawal_id` (`withdrawal_id`),
  ADD KEY `idx_user_id` (`user_id`),
  ADD KEY `idx_paystack_transfer_id` (`paystack_transfer_id`);

--
-- Indexes for table `pending_payments`
--
ALTER TABLE `pending_payments`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `pending_ref_unique` (`pending_ref`);

--
-- Indexes for table `platform_video_prices`
--
ALTER TABLE `platform_video_prices`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_platform` (`platform`),
  ADD KEY `idx_active` (`is_active`);

--
-- Indexes for table `plinko_games`
--
ALTER TABLE `plinko_games`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_user_games` (`user_id`,`created_at`);

--
-- Indexes for table `premium_payments`
--
ALTER TABLE `premium_payments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_user` (`user_id`),
  ADD KEY `idx_status` (`status`);

--
-- Indexes for table `referral_commissions`
--
ALTER TABLE `referral_commissions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_referrer` (`referrer_id`),
  ADD KEY `idx_referred` (`referred_user_id`);

--
-- Indexes for table `skills`
--
ALTER TABLE `skills`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_is_active` (`is_active`),
  ADD KEY `idx_created_at` (`created_at`);

--
-- Indexes for table `skill_clicks`
--
ALTER TABLE `skill_clicks`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `idx_skill_user` (`skill_id`,`user_id`),
  ADD KEY `idx_clicked_at` (`clicked_at`);

--
-- Indexes for table `spin_win_games`
--
ALTER TABLE `spin_win_games`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_user_id` (`user_id`),
  ADD KEY `idx_created_at` (`created_at`);

--
-- Indexes for table `spin_win_stats`
--
ALTER TABLE `spin_win_stats`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `stream_ads_earnings`
--
ALTER TABLE `stream_ads_earnings`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_user_track` (`user_id`,`track_id`),
  ADD KEY `idx_proof_email` (`proof_email`),
  ADD KEY `idx_streamed_at` (`streamed_at`);

--
-- Indexes for table `stream_ads_logs`
--
ALTER TABLE `stream_ads_logs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_user_track` (`user_id`,`track_id`),
  ADD KEY `idx_created_at` (`created_at`);

--
-- Indexes for table `stream_ad_verified_emails`
--
ALTER TABLE `stream_ad_verified_emails`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD KEY `idx_stream_ad_verified_emails_user_track` (`user_id`,`track_id`);

--
-- Indexes for table `stream_daily_stats`
--
ALTER TABLE `stream_daily_stats`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_user_date` (`user_id`,`stream_date`),
  ADD KEY `idx_stream_date` (`stream_date`);

--
-- Indexes for table `stream_earnings`
--
ALTER TABLE `stream_earnings`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_user_track_payout` (`user_id`,`track_id`) COMMENT 'One payout per track per user',
  ADD KEY `idx_user_id` (`user_id`),
  ADD KEY `idx_track_id` (`track_id`),
  ADD KEY `idx_streamed_at` (`streamed_at`),
  ADD KEY `idx_payout_status` (`payout_status`),
  ADD KEY `idx_is_eligible` (`is_eligible`);

--
-- Indexes for table `stream_logs`
--
ALTER TABLE `stream_logs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_user_id` (`user_id`),
  ADD KEY `idx_track_id` (`track_id`),
  ADD KEY `idx_created_at` (`created_at`),
  ADD KEY `idx_event_type` (`event_type`);

--
-- Indexes for table `stream_tracks`
--
ALTER TABLE `stream_tracks`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `track_id` (`track_id`),
  ADD KEY `idx_track_id` (`track_id`),
  ADD KEY `idx_is_active` (`is_active`),
  ADD KEY `idx_upload_date` (`upload_date`),
  ADD KEY `idx_track_rewards` (`free_reward`,`premium_reward`);

--
-- Indexes for table `tasks`
--
ALTER TABLE `tasks`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_active` (`is_active`),
  ADD KEY `idx_premium` (`is_premium_only`),
  ADD KEY `idx_pinned_admin` (`is_pinned`,`posted_by_admin`,`is_active`),
  ADD KEY `idx_tasks_platform` (`platform`),
  ADD KEY `idx_completed_count` (`completed_count`),
  ADD KEY `idx_task_completion` (`is_completed`,`is_active`);

--
-- Indexes for table `task_count_sync_log`
--
ALTER TABLE `task_count_sync_log`
  ADD PRIMARY KEY (`id`),
  ADD KEY `task_id` (`task_id`);

--
-- Indexes for table `task_display_settings`
--
ALTER TABLE `task_display_settings`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `setting_key` (`setting_key`);

--
-- Indexes for table `transactions`
--
ALTER TABLE `transactions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_user_type` (`user_id`,`transaction_type`),
  ADD KEY `idx_created` (`created_at`),
  ADD KEY `idx_user_transaction` (`user_id`,`created_at`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `referral_code` (`referral_code`),
  ADD UNIQUE KEY `remember_me_token` (`remember_me_token`),
  ADD KEY `idx_referral_code` (`referral_code`),
  ADD KEY `idx_email` (`email`),
  ADD KEY `idx_referred_by` (`referred_by`),
  ADD KEY `idx_profile_picture` (`profile_picture`),
  ADD KEY `idx_gender` (`gender`),
  ADD KEY `idx_chat_earn_enabled` (`chat_earn_enabled`),
  ADD KEY `idx_last_referral_withdrawal` (`last_referral_withdrawal`),
  ADD KEY `idx_advertiser_plan` (`advertiser_plan`),
  ADD KEY `idx_advertiser_start_date` (`advertiser_plan_start_date`),
  ADD KEY `idx_membership_start_date` (`membership_start_date`),
  ADD KEY `idx_career` (`career1`,`career2`),
  ADD KEY `idx_withdrawal_account` (`withdrawal_account_number`),
  ADD KEY `idx_membership_type` (`membership_type`),
  ADD KEY `idx_full_name_last_updated` (`full_name_last_updated`),
  ADD KEY `idx_profile_picture_last_updated` (`profile_picture_last_updated`),
  ADD KEY `idx_phone_last_updated` (`phone_last_updated`),
  ADD KEY `idx_username_last_updated` (`username_last_updated`),
  ADD KEY `idx_withdrawal_method_last_updated` (`withdrawal_method_last_updated`),
  ADD KEY `idx_paystack_recipient_code` (`paystack_recipient_code`),
  ADD KEY `idx_remember_me_token` (`remember_me_token`);

--
-- Indexes for table `user_completed_music`
--
ALTER TABLE `user_completed_music`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_user_music` (`user_id`,`music_id`),
  ADD KEY `idx_user_id` (`user_id`),
  ADD KEY `idx_music_id` (`music_id`);

--
-- Indexes for table `user_completed_tasks`
--
ALTER TABLE `user_completed_tasks`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_user_task` (`user_id`,`task_id`),
  ADD KEY `idx_user_id` (`user_id`),
  ADD KEY `idx_task_id` (`task_id`);

--
-- Indexes for table `user_completed_videos`
--
ALTER TABLE `user_completed_videos`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_user_video` (`user_id`,`video_id`),
  ADD KEY `idx_user_id` (`user_id`),
  ADD KEY `idx_video_id` (`video_id`);

--
-- Indexes for table `user_devices`
--
ALTER TABLE `user_devices`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_user_device` (`user_id`,`device_fingerprint`),
  ADD KEY `idx_device_fingerprint` (`device_fingerprint`),
  ADD KEY `idx_user_id` (`user_id`);

--
-- Indexes for table `user_message_reads`
--
ALTER TABLE `user_message_reads`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_user_message` (`user_id`,`message_id`),
  ADD KEY `message_id` (`message_id`);

--
-- Indexes for table `user_notification_views`
--
ALTER TABLE `user_notification_views`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_user_notification` (`user_id`,`notification_id`),
  ADD KEY `notification_id` (`notification_id`);

--
-- Indexes for table `user_playlists`
--
ALTER TABLE `user_playlists`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_user_track` (`user_id`,`track_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `user_tasks`
--
ALTER TABLE `user_tasks`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_user_task` (`user_id`,`task_id`),
  ADD KEY `task_id` (`task_id`),
  ADD KEY `idx_user_status` (`user_id`,`status`),
  ADD KEY `idx_user_task_completion` (`user_id`,`task_id`,`status`),
  ADD KEY `idx_user_tasks_completion` (`user_id`,`task_id`,`status`);

--
-- Indexes for table `user_verification`
--
ALTER TABLE `user_verification`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_user_verification` (`user_id`),
  ADD KEY `idx_status` (`verification_status`);

--
-- Indexes for table `video_earnings`
--
ALTER TABLE `video_earnings`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_user_video` (`user_id`,`video_id`),
  ADD KEY `idx_watched_at` (`watched_at`);

--
-- Indexes for table `whot_bets`
--
ALTER TABLE `whot_bets`
  ADD PRIMARY KEY (`id`),
  ADD KEY `game_id` (`game_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `whot_games`
--
ALTER TABLE `whot_games`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `whot_game_moves`
--
ALTER TABLE `whot_game_moves`
  ADD PRIMARY KEY (`id`),
  ADD KEY `game_id` (`game_id`),
  ADD KEY `player_id` (`player_id`);

--
-- Indexes for table `whot_game_players`
--
ALTER TABLE `whot_game_players`
  ADD PRIMARY KEY (`id`),
  ADD KEY `game_id` (`game_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `withdrawals`
--
ALTER TABLE `withdrawals`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_user_status` (`user_id`,`status`),
  ADD KEY `idx_status` (`status`),
  ADD KEY `idx_paystack_status` (`paystack_status`),
  ADD KEY `idx_withdrawal_type_status` (`withdrawal_type`,`status`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_messages`
--
ALTER TABLE `admin_messages`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `admin_notifications`
--
ALTER TABLE `admin_notifications`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `advertisements`
--
ALTER TABLE `advertisements`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=95;

--
-- AUTO_INCREMENT for table `advertiser_payments`
--
ALTER TABLE `advertiser_payments`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=46;

--
-- AUTO_INCREMENT for table `ad_invite_commissions`
--
ALTER TABLE `ad_invite_commissions`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `available_music`
--
ALTER TABLE `available_music`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `available_videos`
--
ALTER TABLE `available_videos`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `balances`
--
ALTER TABLE `balances`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=77;

--
-- AUTO_INCREMENT for table `billing_information`
--
ALTER TABLE `billing_information`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `chat_earn_emojis`
--
ALTER TABLE `chat_earn_emojis`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `chat_earn_history`
--
ALTER TABLE `chat_earn_history`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=61;

--
-- AUTO_INCREMENT for table `chat_earn_messages`
--
ALTER TABLE `chat_earn_messages`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `color_predictor_games`
--
ALTER TABLE `color_predictor_games`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `color_predictor_stats`
--
ALTER TABLE `color_predictor_stats`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `daily_rewards`
--
ALTER TABLE `daily_rewards`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=46;

--
-- AUTO_INCREMENT for table `device_login_verifications`
--
ALTER TABLE `device_login_verifications`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=120;

--
-- AUTO_INCREMENT for table `device_registration_log`
--
ALTER TABLE `device_registration_log`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=46;

--
-- AUTO_INCREMENT for table `game_wins`
--
ALTER TABLE `game_wins`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `jobs`
--
ALTER TABLE `jobs`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `job_bids`
--
ALTER TABLE `job_bids`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `korapay_post_task_payloads`
--
ALTER TABLE `korapay_post_task_payloads`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `korapay_post_task_payments`
--
ALTER TABLE `korapay_post_task_payments`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `korapay_transactions`
--
ALTER TABLE `korapay_transactions`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `korapay_webhooks`
--
ALTER TABLE `korapay_webhooks`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `leaderboards`
--
ALTER TABLE `leaderboards`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `music_earnings`
--
ALTER TABLE `music_earnings`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `mystery_box_games`
--
ALTER TABLE `mystery_box_games`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `newsletters_subscribers`
--
ALTER TABLE `newsletters_subscribers`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `newsletter_campaigns`
--
ALTER TABLE `newsletter_campaigns`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `notification_recipients`
--
ALTER TABLE `notification_recipients`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `password_reset_codes`
--
ALTER TABLE `password_reset_codes`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=57;

--
-- AUTO_INCREMENT for table `paystack_transfer_logs`
--
ALTER TABLE `paystack_transfer_logs`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=103;

--
-- AUTO_INCREMENT for table `pending_payments`
--
ALTER TABLE `pending_payments`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `platform_video_prices`
--
ALTER TABLE `platform_video_prices`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `plinko_games`
--
ALTER TABLE `plinko_games`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT for table `premium_payments`
--
ALTER TABLE `premium_payments`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- AUTO_INCREMENT for table `referral_commissions`
--
ALTER TABLE `referral_commissions`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=51;

--
-- AUTO_INCREMENT for table `skills`
--
ALTER TABLE `skills`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `skill_clicks`
--
ALTER TABLE `skill_clicks`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `spin_win_games`
--
ALTER TABLE `spin_win_games`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `stream_ads_earnings`
--
ALTER TABLE `stream_ads_earnings`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `stream_ads_logs`
--
ALTER TABLE `stream_ads_logs`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `stream_ad_verified_emails`
--
ALTER TABLE `stream_ad_verified_emails`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `stream_daily_stats`
--
ALTER TABLE `stream_daily_stats`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT for table `stream_earnings`
--
ALTER TABLE `stream_earnings`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT for table `stream_logs`
--
ALTER TABLE `stream_logs`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT for table `stream_tracks`
--
ALTER TABLE `stream_tracks`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `tasks`
--
ALTER TABLE `tasks`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=100;

--
-- AUTO_INCREMENT for table `task_count_sync_log`
--
ALTER TABLE `task_count_sync_log`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=112;

--
-- AUTO_INCREMENT for table `task_display_settings`
--
ALTER TABLE `task_display_settings`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `transactions`
--
ALTER TABLE `transactions`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=850;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=77;

--
-- AUTO_INCREMENT for table `user_completed_music`
--
ALTER TABLE `user_completed_music`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `user_completed_tasks`
--
ALTER TABLE `user_completed_tasks`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=133;

--
-- AUTO_INCREMENT for table `user_completed_videos`
--
ALTER TABLE `user_completed_videos`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `user_devices`
--
ALTER TABLE `user_devices`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=50;

--
-- AUTO_INCREMENT for table `user_message_reads`
--
ALTER TABLE `user_message_reads`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `user_notification_views`
--
ALTER TABLE `user_notification_views`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `user_playlists`
--
ALTER TABLE `user_playlists`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=51;

--
-- AUTO_INCREMENT for table `user_tasks`
--
ALTER TABLE `user_tasks`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=588;

--
-- AUTO_INCREMENT for table `user_verification`
--
ALTER TABLE `user_verification`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `video_earnings`
--
ALTER TABLE `video_earnings`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `whot_bets`
--
ALTER TABLE `whot_bets`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `whot_games`
--
ALTER TABLE `whot_games`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `whot_game_moves`
--
ALTER TABLE `whot_game_moves`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `whot_game_players`
--
ALTER TABLE `whot_game_players`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `withdrawals`
--
ALTER TABLE `withdrawals`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=105;

-- --------------------------------------------------------

--
-- Structure for view `plinko_leaderboard`
--
DROP TABLE IF EXISTS `plinko_leaderboard`;

CREATE ALGORITHM=UNDEFINED DEFINER=`workwave`@`localhost` SQL SECURITY DEFINER VIEW `plinko_leaderboard`  AS SELECT `u`.`id` AS `id`, `u`.`username` AS `username`, `u`.`full_name` AS `full_name`, `u`.`profile_picture` AS `profile_picture`, count(`pg`.`id`) AS `total_wins`, sum((`pg`.`win_amount` - `pg`.`bet_amount`)) AS `total_profit`, max(`pg`.`win_amount`) AS `biggest_win` FROM (`users` `u` join `plinko_games` `pg` on((`u`.`id` = `pg`.`user_id`))) WHERE (`pg`.`win_amount` > `pg`.`bet_amount`) GROUP BY `u`.`id`, `u`.`username`, `u`.`full_name`, `u`.`profile_picture` ORDER BY sum((`pg`.`win_amount` - `pg`.`bet_amount`)) DESC LIMIT 0, 10 ;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `advertisements`
--
ALTER TABLE `advertisements`
  ADD CONSTRAINT `advertisements_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `advertiser_payments`
--
ALTER TABLE `advertiser_payments`
  ADD CONSTRAINT `advertiser_payments_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `ad_invite_commissions`
--
ALTER TABLE `ad_invite_commissions`
  ADD CONSTRAINT `ad_invite_commissions_ibfk_1` FOREIGN KEY (`referrer_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `ad_invite_commissions_ibfk_2` FOREIGN KEY (`referred_user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `balances`
--
ALTER TABLE `balances`
  ADD CONSTRAINT `balances_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `billing_information`
--
ALTER TABLE `billing_information`
  ADD CONSTRAINT `fk_billing_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `chat_earn_emojis`
--
ALTER TABLE `chat_earn_emojis`
  ADD CONSTRAINT `chat_earn_emojis_ibfk_1` FOREIGN KEY (`message_id`) REFERENCES `chat_earn_messages` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `chat_earn_emojis_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `chat_earn_history`
--
ALTER TABLE `chat_earn_history`
  ADD CONSTRAINT `chat_earn_history_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `chat_earn_history_ibfk_2` FOREIGN KEY (`paired_user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `chat_earn_messages`
--
ALTER TABLE `chat_earn_messages`
  ADD CONSTRAINT `chat_earn_messages_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `chat_earn_messages_ibfk_2` FOREIGN KEY (`paired_user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `color_predictor_games`
--
ALTER TABLE `color_predictor_games`
  ADD CONSTRAINT `color_predictor_games_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `color_predictor_stats`
--
ALTER TABLE `color_predictor_stats`
  ADD CONSTRAINT `color_predictor_stats_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `daily_rewards`
--
ALTER TABLE `daily_rewards`
  ADD CONSTRAINT `daily_rewards_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `device_login_verifications`
--
ALTER TABLE `device_login_verifications`
  ADD CONSTRAINT `device_login_verifications_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `device_registration_log`
--
ALTER TABLE `device_registration_log`
  ADD CONSTRAINT `device_registration_log_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `game_wins`
--
ALTER TABLE `game_wins`
  ADD CONSTRAINT `game_wins_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `jobs`
--
ALTER TABLE `jobs`
  ADD CONSTRAINT `jobs_ibfk_1` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `job_bids`
--
ALTER TABLE `job_bids`
  ADD CONSTRAINT `job_bids_ibfk_1` FOREIGN KEY (`job_id`) REFERENCES `jobs` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `job_bids_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `korapay_post_task_payments`
--
ALTER TABLE `korapay_post_task_payments`
  ADD CONSTRAINT `korapay_post_task_payments_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `korapay_transactions`
--
ALTER TABLE `korapay_transactions`
  ADD CONSTRAINT `korapay_transactions_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `leaderboards`
--
ALTER TABLE `leaderboards`
  ADD CONSTRAINT `leaderboards_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `music_earnings`
--
ALTER TABLE `music_earnings`
  ADD CONSTRAINT `music_earnings_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `mystery_box_games`
--
ALTER TABLE `mystery_box_games`
  ADD CONSTRAINT `mystery_box_games_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `mystery_box_stats`
--
ALTER TABLE `mystery_box_stats`
  ADD CONSTRAINT `mystery_box_stats_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `newsletter_campaigns`
--
ALTER TABLE `newsletter_campaigns`
  ADD CONSTRAINT `fk_newsletter_campaigns_user` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `notification_recipients`
--
ALTER TABLE `notification_recipients`
  ADD CONSTRAINT `notification_recipients_ibfk_1` FOREIGN KEY (`message_id`) REFERENCES `admin_messages` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `notification_recipients_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `fk_order_billing` FOREIGN KEY (`billing_info_id`) REFERENCES `billing_information` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_order_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `password_reset_codes`
--
ALTER TABLE `password_reset_codes`
  ADD CONSTRAINT `password_reset_codes_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `paystack_transfer_logs`
--
ALTER TABLE `paystack_transfer_logs`
  ADD CONSTRAINT `paystack_transfer_logs_ibfk_1` FOREIGN KEY (`withdrawal_id`) REFERENCES `withdrawals` (`id`);

--
-- Constraints for table `plinko_games`
--
ALTER TABLE `plinko_games`
  ADD CONSTRAINT `plinko_games_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `premium_payments`
--
ALTER TABLE `premium_payments`
  ADD CONSTRAINT `premium_payments_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `referral_commissions`
--
ALTER TABLE `referral_commissions`
  ADD CONSTRAINT `referral_commissions_ibfk_1` FOREIGN KEY (`referrer_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `referral_commissions_ibfk_2` FOREIGN KEY (`referred_user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `skill_clicks`
--
ALTER TABLE `skill_clicks`
  ADD CONSTRAINT `skill_clicks_ibfk_1` FOREIGN KEY (`skill_id`) REFERENCES `skills` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `skill_clicks_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `spin_win_games`
--
ALTER TABLE `spin_win_games`
  ADD CONSTRAINT `spin_win_games_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `spin_win_stats`
--
ALTER TABLE `spin_win_stats`
  ADD CONSTRAINT `spin_win_stats_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `task_count_sync_log`
--
ALTER TABLE `task_count_sync_log`
  ADD CONSTRAINT `task_count_sync_log_ibfk_1` FOREIGN KEY (`task_id`) REFERENCES `tasks` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `transactions`
--
ALTER TABLE `transactions`
  ADD CONSTRAINT `transactions_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `users_ibfk_1` FOREIGN KEY (`referred_by`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `user_completed_music`
--
ALTER TABLE `user_completed_music`
  ADD CONSTRAINT `user_completed_music_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `user_completed_tasks`
--
ALTER TABLE `user_completed_tasks`
  ADD CONSTRAINT `user_completed_tasks_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `user_completed_tasks_ibfk_2` FOREIGN KEY (`task_id`) REFERENCES `tasks` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `user_completed_videos`
--
ALTER TABLE `user_completed_videos`
  ADD CONSTRAINT `user_completed_videos_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `user_devices`
--
ALTER TABLE `user_devices`
  ADD CONSTRAINT `user_devices_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `user_message_reads`
--
ALTER TABLE `user_message_reads`
  ADD CONSTRAINT `user_message_reads_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `user_message_reads_ibfk_2` FOREIGN KEY (`message_id`) REFERENCES `admin_messages` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `user_notification_views`
--
ALTER TABLE `user_notification_views`
  ADD CONSTRAINT `user_notification_views_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `user_notification_views_ibfk_2` FOREIGN KEY (`notification_id`) REFERENCES `admin_notifications` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `user_playlists`
--
ALTER TABLE `user_playlists`
  ADD CONSTRAINT `user_playlists_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `user_tasks`
--
ALTER TABLE `user_tasks`
  ADD CONSTRAINT `user_tasks_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `user_tasks_ibfk_2` FOREIGN KEY (`task_id`) REFERENCES `tasks` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `user_verification`
--
ALTER TABLE `user_verification`
  ADD CONSTRAINT `user_verification_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `video_earnings`
--
ALTER TABLE `video_earnings`
  ADD CONSTRAINT `video_earnings_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `whot_bets`
--
ALTER TABLE `whot_bets`
  ADD CONSTRAINT `whot_bets_ibfk_1` FOREIGN KEY (`game_id`) REFERENCES `whot_games` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `whot_bets_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `whot_game_moves`
--
ALTER TABLE `whot_game_moves`
  ADD CONSTRAINT `whot_game_moves_ibfk_1` FOREIGN KEY (`game_id`) REFERENCES `whot_games` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `whot_game_moves_ibfk_2` FOREIGN KEY (`player_id`) REFERENCES `whot_game_players` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `whot_game_players`
--
ALTER TABLE `whot_game_players`
  ADD CONSTRAINT `whot_game_players_ibfk_1` FOREIGN KEY (`game_id`) REFERENCES `whot_games` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `whot_game_players_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `withdrawals`
--
ALTER TABLE `withdrawals`
  ADD CONSTRAINT `withdrawals_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
