-- Migration to add new features: gender, survey fields, chat & earn, withdrawal limits

USE flowearner;

-- Add new fields to users table
ALTER TABLE users 
ADD COLUMN gender ENUM('male', 'female') NULL AFTER email,
ADD COLUMN how_heard VARCHAR(255) NULL AFTER gender,
ADD COLUMN interests TEXT NULL AFTER how_heard,
ADD COLUMN whatsapp_number VARCHAR(20) NULL AFTER phone,
ADD COLUMN chat_earn_enabled TINYINT(1) DEFAULT 0 AFTER whatsapp_number,
ADD COLUMN chat_earn_last_paired DATETIME NULL AFTER chat_earn_enabled,
ADD COLUMN last_referral_withdrawal DATETIME NULL AFTER chat_earn_last_paired,
ADD COLUMN referral_withdrawal_count_today INT DEFAULT 0 AFTER last_referral_withdrawal,
ADD COLUMN last_withdrawal_reset_date DATE NULL AFTER referral_withdrawal_count_today;

-- Create chat_earn_history table to track pairings
CREATE TABLE IF NOT EXISTS `chat_earn_history` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `user_id` INT(11) NOT NULL,
  `paired_user_id` INT(11) NOT NULL,
  `paired_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_pairing` (`user_id`, `paired_user_id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_paired_user_id` (`paired_user_id`),
  CONSTRAINT `chat_earn_history_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `chat_earn_history_ibfk_2` FOREIGN KEY (`paired_user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Create indexes for better performance
CREATE INDEX idx_gender ON users(gender);
CREATE INDEX idx_chat_earn_enabled ON users(chat_earn_enabled);
CREATE INDEX idx_last_referral_withdrawal ON users(last_referral_withdrawal);
