-- Kora Pay Integration Migration
-- Adds columns to support Kora Pay virtual bank accounts and transactions

-- Add Kora Pay columns to users table
ALTER TABLE `users` ADD COLUMN `korapay_vba_account_number` VARCHAR(50) DEFAULT NULL COMMENT 'Kora Pay Virtual Bank Account number';
ALTER TABLE `users` ADD COLUMN `korapay_account_reference` VARCHAR(100) DEFAULT NULL COMMENT 'Kora Pay unique account reference';
ALTER TABLE `users` ADD COLUMN `korapay_vba_created_at` DATETIME DEFAULT NULL COMMENT 'When VBA was created';
ALTER TABLE `users` ADD COLUMN `korapay_vba_bank_code` VARCHAR(10) DEFAULT NULL COMMENT 'Bank code for VBA';
ALTER TABLE `users` ADD COLUMN `korapay_vba_bank_name` VARCHAR(100) DEFAULT NULL COMMENT 'Bank name for VBA';

-- Create korapay_transactions table to track deposits
CREATE TABLE IF NOT EXISTS `korapay_transactions` (
  `id` INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `user_id` INT NOT NULL,
  `korapay_reference` VARCHAR(100) NOT NULL UNIQUE COMMENT 'Kora Pay transaction reference',
  `amount` DECIMAL(15, 2) NOT NULL,
  `currency` VARCHAR(10) DEFAULT 'NGN',
  `payer_account_number` VARCHAR(50) DEFAULT NULL COMMENT 'Payer bank account number',
  `payer_account_name` VARCHAR(255) DEFAULT NULL COMMENT 'Payer name',
  `payer_bank_name` VARCHAR(100) DEFAULT NULL COMMENT 'Payer bank name',
  `transaction_narration` TEXT DEFAULT NULL,
  `status` ENUM('pending', 'success', 'failed') DEFAULT 'pending',
  `payment_type` VARCHAR(50) DEFAULT NULL COMMENT 'Type: premium_upgrade, premium_plus_upgrade, or deposit',
  `deposit_purpose` VARCHAR(50) DEFAULT 'general' COMMENT 'For deposits: ads, games, or general',
  `description` TEXT,
  `received_at` DATETIME DEFAULT NULL COMMENT 'When payment was received',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
  KEY `idx_user_id` (`user_id`),
  KEY `idx_korapay_reference` (`korapay_reference`),
  KEY `idx_status` (`status`),
  KEY `idx_created_at` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Create korapay_webhooks table to track received webhooks
CREATE TABLE IF NOT EXISTS `korapay_webhooks` (
  `id` INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `event_type` VARCHAR(100) NOT NULL,
  `webhook_reference` VARCHAR(100) DEFAULT NULL,
  `payload` JSON,
  `processed` TINYINT(1) DEFAULT 0,
  `processed_at` DATETIME DEFAULT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  KEY `idx_webhook_reference` (`webhook_reference`),
  KEY `idx_event_type` (`event_type`),
  KEY `idx_processed` (`processed`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Add korapay_payment_method column to existing payment tables
ALTER TABLE `premium_payments` ADD COLUMN `payment_method` VARCHAR(50) DEFAULT 'paystack' COMMENT 'paystack or korapay';
ALTER TABLE `advertiser_payments` ADD COLUMN `payment_method` VARCHAR(50) DEFAULT 'paystack' COMMENT 'paystack or korapay';
