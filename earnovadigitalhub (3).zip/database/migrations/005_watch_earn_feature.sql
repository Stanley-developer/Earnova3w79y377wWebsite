-- Add tables for Watch & Earn feature

-- Table to track video earnings
CREATE TABLE IF NOT EXISTS video_earnings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    video_id VARCHAR(255) NOT NULL,
    video_title VARCHAR(255) NOT NULL,
    amount_earned DECIMAL(10, 2) NOT NULL,
    watched_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_user_video (user_id, video_id),
    INDEX idx_watched_at (watched_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table to track music earnings
CREATE TABLE IF NOT EXISTS music_earnings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    music_id VARCHAR(255) NOT NULL,
    music_title VARCHAR(255) NOT NULL,
    amount_earned DECIMAL(10, 2) NOT NULL,
    listened_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_user_music (user_id, music_id),
    INDEX idx_listened_at (listened_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table to store available videos
CREATE TABLE IF NOT EXISTS available_videos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    video_id VARCHAR(255) UNIQUE NOT NULL,
    title VARCHAR(255) NOT NULL,
    description TEXT,
    video_url VARCHAR(500) NOT NULL,
    thumbnail_url VARCHAR(500),
    duration INT NOT NULL COMMENT 'Duration in seconds',
    free_reward DECIMAL(10, 2) DEFAULT 100.00,
    premium_reward DECIMAL(10, 2) DEFAULT 500.00,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_active (is_active)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table to store available music
CREATE TABLE IF NOT EXISTS available_music (
    id INT AUTO_INCREMENT PRIMARY KEY,
    music_id VARCHAR(255) UNIQUE NOT NULL,
    title VARCHAR(255) NOT NULL,
    artist VARCHAR(255),
    music_url VARCHAR(500) NOT NULL,
    thumbnail_url VARCHAR(500),
    duration INT NOT NULL COMMENT 'Duration in seconds',
    free_reward DECIMAL(10, 2) DEFAULT 150.00,
    premium_reward DECIMAL(10, 2) DEFAULT 700.00,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_active (is_active)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Insert sample videos
INSERT INTO available_videos (video_id, title, description, video_url, duration, free_reward, premium_reward) VALUES
('video_001', 'How to Earn Money Online', 'Learn the best strategies to earn money online in 2025', 'https://www.youtube.com/embed/dQw4w9WgXcQ', 300, 100.00, 500.00),
('video_002', 'Financial Freedom Tips', 'Top 10 tips for achieving financial freedom', 'https://www.youtube.com/embed/dQw4w9WgXcQ', 420, 100.00, 500.00),
('video_003', 'Passive Income Ideas', 'Best passive income ideas for beginners', 'https://www.youtube.com/embed/dQw4w9WgXcQ', 360, 100.00, 500.00);

-- Insert sample music
INSERT INTO available_music (music_id, title, artist, music_url, duration, free_reward, premium_reward) VALUES
('music_001', 'Motivational Beats', 'FlowEarner Music', 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3', 240, 150.00, 700.00),
('music_002', 'Success Vibes', 'FlowEarner Music', 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-2.mp3', 300, 150.00, 700.00),
('music_003', 'Hustle Mode', 'FlowEarner Music', 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-3.mp3', 280, 150.00, 700.00);
