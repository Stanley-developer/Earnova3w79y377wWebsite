-- Migration for Chat & Earn feature
USE flowearner;

-- Add new fields to users table for Chat & Earn
ALTER TABLE users 
ADD COLUMN gender ENUM('male', 'female') DEFAULT NULL AFTER phone,
ADD COLUMN whatsapp_number VARCHAR(20) DEFAULT NULL AFTER gender,
ADD COLUMN chat_earn_enabled TINYINT(1) DEFAULT 0 AFTER whatsapp_number,
ADD COLUMN chat_earn_last_paired DATETIME DEFAULT NULL AFTER chat_earn_enabled;

-- Create chat_earn_history table to track pairings
CREATE TABLE IF NOT EXISTS chat_earn_history (
  id INT(11) NOT NULL AUTO_INCREMENT,
  user_id INT(11) NOT NULL,
  paired_user_id INT(11) NOT NULL,
  paired_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_user_paired (user_id, paired_user_id),
  KEY idx_paired_at (paired_at),
  CONSTRAINT fk_chat_earn_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  CONSTRAINT fk_chat_earn_paired FOREIGN KEY (paired_user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Add index for faster queries
CREATE INDEX idx_chat_earn_enabled ON users(chat_earn_enabled, gender);
CREATE INDEX idx_whatsapp_number ON users(whatsapp_number);
