-- Migration: create pending_payments table
-- Run: mysql -u user -p database < 20251211_create_pending_payments.sql

CREATE TABLE IF NOT EXISTS `pending_payments` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `pending_ref` VARCHAR(100) NOT NULL,
  `user_id` INT NOT NULL,
  `payment_type` VARCHAR(50) NOT NULL DEFAULT 'task_post',
  `title` VARCHAR(255) DEFAULT NULL,
  `description` TEXT DEFAULT NULL,
  `platform_key` VARCHAR(50) DEFAULT NULL,
  `task_url` VARCHAR(500) DEFAULT NULL,
  `participants` INT DEFAULT 0,
  `total_cost` DECIMAL(10,2) DEFAULT 0.00,
  `amount_expected` DECIMAL(10,2) DEFAULT 0.00,
  `status` ENUM('pending','paid','failed') DEFAULT 'pending',
  `korapay_reference` VARCHAR(200) DEFAULT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `pending_ref_unique` (`pending_ref`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
