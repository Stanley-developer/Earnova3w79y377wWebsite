-- Add admin role to users table
ALTER TABLE users ADD COLUMN is_admin TINYINT(1) DEFAULT 0 AFTER is_active;

-- Create user verification table
CREATE TABLE IF NOT EXISTS user_verification (
  id INT(11) NOT NULL AUTO_INCREMENT,
  user_id INT(11) NOT NULL,
  nin VARCHAR(20) NOT NULL,
  full_name VARCHAR(100) NOT NULL,
  date_of_birth DATE NOT NULL,
  location VARCHAR(200) NOT NULL,
  phone_number VARCHAR(20) NOT NULL,
  email VARCHAR(100) NOT NULL,
  profile_picture VARCHAR(255) DEFAULT NULL,
  portfolio_cv VARCHAR(255) DEFAULT NULL,
  recent_jobs TEXT DEFAULT NULL,
  verification_status ENUM('pending', 'approved', 'rejected') DEFAULT 'pending',
  admin_notes TEXT DEFAULT NULL,
  submitted_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  verified_at TIMESTAMP NULL DEFAULT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY unique_user_verification (user_id),
  KEY idx_status (verification_status),
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Create jobs table
CREATE TABLE IF NOT EXISTS jobs (
  id INT(11) NOT NULL AUTO_INCREMENT,
  title VARCHAR(200) NOT NULL,
  description TEXT NOT NULL,
  requirements TEXT DEFAULT NULL,
  budget DECIMAL(15,2) NOT NULL,
  location VARCHAR(200) DEFAULT NULL,
  job_type ENUM('full-time', 'part-time', 'contract', 'freelance') NOT NULL,
  contact_number VARCHAR(20) NOT NULL,
  contact_email VARCHAR(100) DEFAULT NULL,
  slots_available INT(11) DEFAULT 1,
  slots_filled INT(11) DEFAULT 0,
  is_active TINYINT(1) DEFAULT 1,
  created_by INT(11) NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_active (is_active),
  KEY idx_created_by (created_by),
  FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Create job bids table
CREATE TABLE IF NOT EXISTS job_bids (
  id INT(11) NOT NULL AUTO_INCREMENT,
  job_id INT(11) NOT NULL,
  user_id INT(11) NOT NULL,
  cover_letter TEXT DEFAULT NULL,
  proposed_rate DECIMAL(15,2) DEFAULT NULL,
  bid_status ENUM('pending', 'approved', 'rejected') DEFAULT 'pending',
  admin_notes TEXT DEFAULT NULL,
  bid_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY unique_user_job_bid (user_id, job_id),
  KEY idx_job (job_id),
  KEY idx_user (user_id),
  KEY idx_status (bid_status),
  FOREIGN KEY (job_id) REFERENCES jobs(id) ON DELETE CASCADE,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Insert sample admin user (password: admin123)
INSERT INTO users (username, email, password_hash, full_name, referral_code, is_admin, membership_type) 
VALUES ('admin', 'admin@flowearner.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'FlowEarner Admin', 'ADMIN001', 1, 'premium')
ON DUPLICATE KEY UPDATE is_admin = 1;
