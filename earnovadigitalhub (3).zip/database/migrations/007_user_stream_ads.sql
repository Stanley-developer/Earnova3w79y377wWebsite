-- Migration to add columns for user-posted stream ads
-- This allows users to post their own audio ads with custom parameters

ALTER TABLE `stream_tracks` 
ADD COLUMN `uploaded_by_user_id` INT DEFAULT NULL COMMENT 'NULL for admin uploads, user ID for user uploads' AFTER `uploaded_by`,
ADD COLUMN `participants_target` INT DEFAULT 10 COMMENT 'Number of participants the ad should reach' AFTER `uploaded_by_user_id`,
ADD COLUMN `post_cost` DECIMAL(10,2) DEFAULT 0.00 COMMENT 'Amount paid by user to post this ad' AFTER `participants_target`,
ADD COLUMN `platform_type` VARCHAR(50) DEFAULT NULL COMMENT 'Platform type for user ads (spotify, audiomack, etc.)' AFTER `post_cost`;

-- Create index for user uploaded tracks
ALTER TABLE `stream_tracks` 
ADD INDEX `idx_user_uploads` (`uploaded_by_user_id`, `is_active`);
