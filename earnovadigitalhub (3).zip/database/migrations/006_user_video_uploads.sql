-- Migration: Add user video upload functionality
-- This migration adds support for users to upload videos with platform-specific pricing

-- Add new columns to available_videos table for user uploads
ALTER TABLE `available_videos`
ADD COLUMN `uploaded_by_user_id` INT DEFAULT NULL COMMENT 'User ID if uploaded by a user (NULL if admin)',
ADD COLUMN `video_file_path` VARCHAR(500) DEFAULT NULL COMMENT 'Path to uploaded MP4 file if any',
ADD COLUMN `post_cost` DECIMAL(10,2) DEFAULT 0.00 COMMENT 'Cost paid by user to post this video',
ADD INDEX `idx_uploaded_by_user` (`uploaded_by_user_id`);

-- Add platform_price_per_10 to track pricing at time of upload
ALTER TABLE `available_videos`
ADD COLUMN `platform_price_per_10` DECIMAL(10,2) DEFAULT 0.00 COMMENT 'Platform price per 10 participants at time of posting';

-- Note: The duration column already exists in available_videos table (stores seconds)
-- It will be used to store video length automatically detected from uploaded MP4 files

-- Create a table to track platform pricing history (for admin reference)
CREATE TABLE IF NOT EXISTS `platform_video_prices` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `platform` VARCHAR(50) NOT NULL,
  `price_per_10_participants` DECIMAL(10,2) NOT NULL,
  `effective_from` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `is_active` TINYINT(1) DEFAULT 1,
  INDEX `idx_platform` (`platform`),
  INDEX `idx_active` (`is_active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Insert initial platform prices
INSERT INTO `platform_video_prices` (`platform`, `price_per_10_participants`, `is_active`) VALUES
('youtube', 400.00, 1),
('tiktok', 320.00, 1),
('instagram', 350.00, 1),
('facebook', 350.00, 1),
('twitter', 380.00, 1),
('linkedin', 350.00, 1);

-- Add comment to transactions table for video_post transaction type
-- (no ALTER needed, just documenting the new transaction type: 'video_post')

-- Migration complete
-- Users can now upload videos and pay from their Prime Earnings (referral_earnings)
-- Videos are automatically trimmed to 15 seconds if they exceed the limit
-- Platform-specific pricing is applied per 10 participants
-- Video length is logged to the database in the duration column
