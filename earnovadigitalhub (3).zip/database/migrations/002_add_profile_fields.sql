-- Added migration to add profile picture and social links fields to users table

USE flowearner;

-- Add profile picture and social links columns to users table
ALTER TABLE users 
ADD COLUMN profile_picture VARCHAR(255) NULL AFTER phone,
ADD COLUMN instagram_link VARCHAR(255) NULL AFTER profile_picture,
ADD COLUMN twitter_link VARCHAR(255) NULL AFTER instagram_link,
ADD COLUMN discord_link VARCHAR(255) NULL AFTER twitter_link;

-- Create index for faster profile queries
CREATE INDEX idx_profile_picture ON users(profile_picture);
