<?php
/**
 * Setup Korapay Post Task Database Tables
 * Run this file once to create the necessary tables
 * Access: /database/setup-korapay-post-task.php
 */

require_once __DIR__ . '/../config/database.php';

try {
    $pdo = getDBConnection();
    
    // Create korapay_post_task_payments table
    $sql = "
    CREATE TABLE IF NOT EXISTS korapay_post_task_payments (
        id INT PRIMARY KEY AUTO_INCREMENT,
        user_id INT NOT NULL,
        reference VARCHAR(100) NOT NULL UNIQUE,
        amount DECIMAL(10, 2) NOT NULL,
        status VARCHAR(50) NOT NULL COMMENT 'success, pending, failed',
        metadata JSON,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id),
        INDEX idx_user_id (user_id),
        INDEX idx_reference (reference),
        INDEX idx_status (status),
        INDEX idx_created_at (created_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
    ";
    
    $pdo->exec($sql);
    echo "✓ Table 'korapay_post_task_payments' created successfully\n";
    
    // Verify transactions table has 'korapay_deposit_post_task' transaction type support
    // (it should, as it uses VARCHAR for transaction_type)
    $result = "✓ Setup complete. Tables are ready for Korapay post-task payments.\n";
    echo $result;
    
} catch (PDOException $e) {
    if (strpos($e->getMessage(), 'already exists') !== false) {
        echo "✓ Table 'korapay_post_task_payments' already exists\n";
    } else {
        echo "Error: " . $e->getMessage() . "\n";
        exit(1);
    }
}
?>
