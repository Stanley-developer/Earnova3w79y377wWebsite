<?php
/**
 * Setup Korapay Post Task Payloads Table
 * Run this once to create the table that stores full task payloads keyed by reference
 */
require_once __DIR__ . '/../config/database.php';

try {
    $pdo = getDBConnection();
    $sql = "
    CREATE TABLE IF NOT EXISTS korapay_post_task_payloads (
        id INT PRIMARY KEY AUTO_INCREMENT,
        reference VARCHAR(100) NOT NULL UNIQUE,
        user_id INT NOT NULL,
        payload JSON NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        INDEX idx_reference (reference),
        INDEX idx_user_id (user_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
    ";
    $pdo->exec($sql);
    echo "✓ Table 'korapay_post_task_payloads' created successfully\n";
} catch (PDOException $e) {
    echo "Error creating table: " . $e->getMessage() . "\n";
    exit(1);
}
?>
