<?php include "doctype.php"; ?>
  
  <!-- SEO Meta Tags -->
  <title>Privacy Policy | Earnova</title>
  <meta name="description" content="Learn how Earnova protects your privacy and handles your data. Read our comprehensive privacy policy." />
  <meta name="keywords" content="privacy policy, data protection, earnova privacy, user data" />
  
  <!-- Preconnect for Performance -->
  <link rel="preconnect" href="https://fonts.googleapis.com" />
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
  
  <!-- Google Fonts: Poppins (primary) + Inter (secondary) with font-display:swap -->
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet" />
  
  <!-- External Stylesheet (controls background colors via CSS variables) -->
  <link rel="stylesheet" href="styles.css" />
  <style>
    /* Minimal inline styles for layout scaffolding only */
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }
    
    body {
      font-family: 'Poppins', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
      line-height: 1.6;
      overflow-x: hidden;
    }
    
    /* Smooth scroll behavior */
    html {
      scroll-behavior: smooth;
    }
    
    /* Accessibility: Respect reduced motion preference */
    @media (prefers-reduced-motion: reduce) {
      *,
      *::before,
      *::after {
        animation-duration: 0.01ms !important;
        animation-iteration-count: 1 !important;
        transition-duration: 0.01ms !important;
      }
      
      html {
        scroll-behavior: auto;
      }
    }
    
    /* Container utility */
    .container {
      max-width: 1280px;
      margin: 0 auto;
      padding: 0 24px;
    }
    
    @media (min-width: 768px) {
      .container {
        padding: 0 48px;
      }
    }
    
    /* Header / Navigation */
    header {
      position: fixed;
      top: 0;
      left: 0;
      right: 0;
      z-index: 1000;
      backdrop-filter: blur(12px);
      border-bottom: 1px solid rgba(255, 255, 255, 0.1);
      transition: all 0.3s ease;
    }
    
    .nav-container {
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 16px 24px;
      max-width: 1280px;
      margin: 0 auto;
    }
    
    .logo-link {
      display: flex;
      align-items: center;
      gap: 12px;
      text-decoration: none;
      color: inherit;
      transition: opacity 0.3s ease;
    }
    
    .logo-link:hover {
      opacity: 0.8;
    }
    
    .logo-link:focus-visible {
      outline: 2px solid currentColor;
      outline-offset: 4px;
      border-radius: 8px;
    }
    
    .logo-img {
      height: 40px;
      width: auto;
    }
    
    .logo-text {
      font-size: 24px;
      font-weight: 700;
      letter-spacing: -0.02em;
    }
    
    nav ul {
      display: none;
      list-style: none;
      gap: 32px;
    }
    
    @media (min-width: 768px) {
      nav ul {
        display: flex;
      }
    }
    
    nav a {
      text-decoration: none;
      color: inherit;
      opacity: 0.8;
      transition: opacity 0.3s ease;
      font-weight: 500;
      font-size: 15px;
    }
    
    nav a:hover {
      opacity: 1;
    }
    
    nav a:focus-visible {
      outline: 2px solid currentColor;
      outline-offset: 4px;
      border-radius: 4px;
    }
    
    /* Highlight active page */
    nav a.active {
      opacity: 1;
      color: #4de1c1;
      font-weight: 600;
    }
    
    .nav-cta {
      display: flex;
      gap: 12px;
      align-items: center;
    }
    
    /* Hide Get Started button on mobile */
    @media (max-width: 767px) {
      .nav-cta .btn-primary {
        display: none;
      }
    }
    
    /* Hamburger menu styles */
    .hamburger-menu {
      display: flex;
      flex-direction: column;
      gap: 5px;
      cursor: pointer;
      padding: 8px;
      background: transparent;
      border: none;
      z-index: 1001;
    }
    
    .hamburger-menu span {
      width: 25px;
      height: 3px;
      background: #f5f9ff;
      border-radius: 2px;
      transition: all 0.3s ease;
    }
    
    .hamburger-menu.active span:nth-child(1) {
      transform: rotate(45deg) translate(8px, 8px);
    }
    
    .hamburger-menu.active span:nth-child(2) {
      opacity: 0;
    }
    
    .hamburger-menu.active span:nth-child(3) {
      transform: rotate(-45deg) translate(7px, -7px);
    }
    
    @media (min-width: 768px) {
      .hamburger-menu {
        display: none;
      }
    }
    
    /* Mobile menu dropdown with staircase animation */
    .mobile-menu {
      position: fixed;
      top: 72px;
      left: 0;
      right: 0;
      background: rgba(3, 9, 34, 0.98);
      backdrop-filter: blur(12px);
      border-bottom: 1px solid rgba(255, 255, 255, 0.1);
      max-height: 0;
      overflow: hidden;
      transition: max-height 0.5s ease;
      z-index: 999;
    }
    
    .mobile-menu.active {
      max-height: 400px;
    }
    
    .mobile-menu ul {
      list-style: none;
      padding: 20px 24px;
    }
    
    .mobile-menu li {
      opacity: 0;
      transform: translateX(-20px);
      transition: all 0.3s ease;
    }
    
    .mobile-menu.active li:nth-child(1) {
      opacity: 1;
      transform: translateX(0);
      transition-delay: 0.1s;
    }
    
    .mobile-menu.active li:nth-child(2) {
      opacity: 1;
      transform: translateX(0);
      transition-delay: 0.2s;
    }
    
    .mobile-menu.active li:nth-child(3) {
      opacity: 1;
      transform: translateX(0);
      transition-delay: 0.3s;
    }
    
    .mobile-menu.active li:nth-child(4) {
      opacity: 1;
      transform: translateX(0);
      transition-delay: 0.4s;
    }
    
    .mobile-menu.active li:nth-child(5) {
      opacity: 1;
      transform: translateX(0);
      transition-delay: 0.5s;
    }
    
    .mobile-menu a {
      display: block;
      padding: 12px 0;
      color: #f5f9ff;
      text-decoration: none;
      font-size: 16px;
      font-weight: 500;
      border-bottom: 1px solid rgba(255, 255, 255, 0.05);
      transition: color 0.3s ease;
    }
    
    .mobile-menu a:hover,
    .mobile-menu a.active {
      color: #4de1c1;
    }
    
    @media (min-width: 768px) {
      .mobile-menu {
        display: none;
      }
    }
    
    /* Button Styles */
    .btn {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      padding: 12px 24px;
      border-radius: 12px;
      font-weight: 600;
      font-size: 15px;
      text-decoration: none;
      transition: all 0.3s ease;
      border: none;
      cursor: pointer;
      font-family: inherit;
    }
    
    .btn:focus-visible {
      outline: 2px solid currentColor;
      outline-offset: 4px;
    }
    
    .btn-primary {
      background: linear-gradient(135deg, #2c5bf5, #4de1c1);
      color: #030922;
      box-shadow: 0 4px 16px rgba(44, 91, 245, 0.3);
    }
    
    .btn-primary:hover {
      transform: translateY(-2px);
      box-shadow: 0 6px 24px rgba(44, 91, 245, 0.4);
    }
    
    .btn-ghost {
      background: transparent;
      color: inherit;
      border: 2px solid rgba(255, 255, 255, 0.2);
    }
    
    .btn-ghost:hover {
      border-color: rgba(255, 255, 255, 0.4);
      background: rgba(255, 255, 255, 0.05);
    }
    
    /* Hero Section */
    .hero-section {
      min-height: 30vh;
      display: flex;
      align-items: center;
      padding-top: 120px;
      position: relative;
    }
    
    .hero-content {
      text-align: center;
      max-width: 900px;
      margin: 0 auto;
    }
    
    .hero-title {
      font-size: clamp(40px, 6vw, 64px);
      font-weight: 800;
      line-height: 1.1;
      margin-bottom: 24px;
      letter-spacing: -0.02em;
    }
    
    .hero-subtitle {
      font-size: clamp(16px, 2.5vw, 20px);
      opacity: 0.8;
      font-weight: 400;
      line-height: 1.5;
      font-family: 'Inter', sans-serif;
    }
    
    /* Privacy Policy Content Section */
    .policy-section {
      padding: 80px 0;
      position: relative;
    }
    
    .policy-container {
      max-width: 900px;
      margin: 0 auto;
      padding: 0 24px;
    }
    
    @media (min-width: 768px) {
      .policy-container {
        padding: 0 48px;
      }
    }
    
    .policy-card {
      padding: 48px;
      border-radius: 24px;
      backdrop-filter: blur(10px);
      border: 1px solid rgba(255, 255, 255, 0.1);
      margin-bottom: 32px;
      transition: all 0.3s ease;
    }
    
    .policy-card:hover {
      border-color: rgba(255, 255, 255, 0.2);
      box-shadow: 0 8px 32px rgba(77, 225, 193, 0.1);
    }
    
    @media (max-width: 767px) {
      .policy-card {
        padding: 32px 24px;
      }
    }
    
    .policy-card h2 {
      font-size: clamp(24px, 3vw, 32px);
      font-weight: 700;
      margin-bottom: 20px;
      letter-spacing: -0.02em;
      background: linear-gradient(135deg, #2c5bf5, #4de1c1);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
      background-clip: text;
    }
    
    .policy-card h3 {
      font-size: clamp(18px, 2.5vw, 22px);
      font-weight: 600;
      margin-top: 24px;
      margin-bottom: 12px;
      color: #4de1c1;
    }
    
    .policy-card p {
      font-size: 16px;
      line-height: 1.8;
      opacity: 0.85;
      margin-bottom: 16px;
      font-family: 'Inter', sans-serif;
    }
    
    .policy-card ul {
      list-style: none;
      margin: 16px 0;
      padding-left: 0;
    }
    
    .policy-card li {
      padding: 8px 0 8px 32px;
      position: relative;
      font-family: 'Inter', sans-serif;
      font-size: 15px;
      line-height: 1.7;
      opacity: 0.85;
    }
    
    .policy-card li::before {
      content: "•";
      position: absolute;
      left: 12px;
      color: #4de1c1;
      font-weight: 700;
      font-size: 20px;
    }
    
    .policy-card a {
      color: #4de1c1;
      text-decoration: none;
      font-weight: 600;
      transition: opacity 0.3s ease;
    }
    
    .policy-card a:hover {
      opacity: 0.8;
      text-decoration: underline;
    }
    
    /* Scroll to top button */
    .scroll-to-top {
      
      
      display: none;
  
    }
    
    .scroll-to-top.visible {
      opacity: 1;
      visibility: visible;
    }
    
    .scroll-to-top:hover {
      transform: translateY(-4px);
      box-shadow: 0 6px 24px rgba(44, 91, 245, 0.4);
    }
    
    .scroll-to-top:focus-visible {
      outline: 2px solid #4de1c1;
      outline-offset: 4px;
    }
    
    .scroll-to-top svg {
      width: 24px;
      height: 24px;
    }
    
    /* Footer */
    footer {
      padding: 80px 0 40px;
      border-top: 1px solid rgba(255, 255, 255, 0.1);
      background-color: #030922;
    }
    
    .footer-content {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
      gap: 48px;
      margin-bottom: 48px;
    }
    
    .footer-brand h3 {
      font-size: 24px;
      margin-bottom: 16px;
    }
    
    .footer-brand p {
      font-size: 14px;
      opacity: 0.7;
      line-height: 1.6;
      font-family: 'Inter', sans-serif;
    }
    
    .footer-links h4 {
      font-size: 16px;
      margin-bottom: 20px;
      font-weight: 600;
    }
    
    .footer-links ul {
      list-style: none;
      display: flex;
      flex-direction: column;
      gap: 12px;
    }
    
    .footer-links a {
      color: inherit;
      text-decoration: none;
      opacity: 0.7;
      transition: opacity 0.3s ease;
      font-size: 14px;
      font-family: 'Inter', sans-serif;
    }
    
    .footer-links a:hover {
      opacity: 1;
    }
    
    .footer-links a:focus-visible {
      outline: 2px solid currentColor;
      outline-offset: 4px;
      border-radius: 4px;
    }
    
    .footer-social {
      display: flex;
      gap: 16px;
      margin-top: 20px;
    }
    
    .social-link {
      width: 40px;
      height: 40px;
      border-radius: 50%;
      border: 1px solid rgba(255, 255, 255, 0.2);
      display: flex;
      align-items: center;
      justify-content: center;
      text-decoration: none;
      color: inherit;
      transition: all 0.3s ease;
    }
    
    .social-link:hover {
      border-color: #4de1c1;
      background: rgba(77, 225, 193, 0.1);
      transform: translateY(-2px);
    }
    
    .social-link:focus-visible {
      outline: 2px solid currentColor;
      outline-offset: 4px;
    }
    
    .social-link svg {
      width: 20px;
      height: 20px;
    }
    
    .footer-bottom {
      text-align: center;
      padding-top: 32px;
      border-top: 1px solid rgba(255, 255, 255, 0.1);
      font-size: 14px;
      opacity: 0.6;
      font-family: 'Inter', sans-serif;
    }
    
    .footer-developer {
      margin-top: 16px;
      font-size: 13px;
      opacity: 0.7;
    }
    
    .footer-developer a {
      color: #4de1c1;
      text-decoration: none;
      font-weight: 600;
      transition: opacity 0.3s ease;
    }
    
    .footer-developer a:hover {
      opacity: 0.8;
      text-decoration: underline;
    }
    
    /* Utility Classes */
    .text-gradient {
      background: linear-gradient(135deg, #2c5bf5, #4de1c1);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
      background-clip: text;
    }
  </style>
</head>
<body>
  
  <!-- Header / Navigation -->
  <header role="banner">
    <div class="nav-container">
      <a href="index.php" class="logo-link" aria-label="Earnova Home">
        <img src="logo.png" alt="Earnova Logo" class="logo-img" />
        <!-- <span class="logo-text">Earnova</span> -->
      </a>
      
      <nav role="navigation" aria-label="Main navigation">
        <ul>
        <li><a href="index.php">Home</a></li>
                <li><a href="about-us.php">About Us</a></li>
                <li><a href="terms.php">Privacy Policy</a></li>
                <li><a href="login.php">Login</a></li>
        </ul>
      </nav>
      
      <div class="nav-cta">
        <a href="register.php" class="btn btn-ghost">Get Started</a>
        <a href="login.php" class="btn btn-primary">Sign In</a>
        <button class="hamburger-menu" aria-label="Toggle mobile menu" aria-expanded="false">
          <span></span>
          <span></span>
          <span></span>
        </button>
      </div>
    </div>
    
    <!-- Mobile menu dropdown -->
    <div class="mobile-menu">
      <ul>
        <li><a href="index.php">Home</a></li>
                <li><a href="about-us.php">About Us</a></li>
                <li><a href="terms.php">Privacy Policy</a></li>
                <li><a href="login.php">Login</a></li>
          
      </ul>
    </div>
  </header>

  <!-- Main Content -->
  <main role="main">
    <!-- Hero Section -->
    <section class="hero-section" aria-labelledby="hero-title">
      <div class="container">
        <div class="hero-content">
          <h1 id="hero-title" class="hero-title">
            <span class="text-gradient">Privacy Policy</span>
          </h1>
          <p class="hero-subtitle">
            Your privacy and data security are important to us at Earnova.
          </p>
        </div>
      </div>
    </section>

    <!-- Privacy Policy Content -->
    <section class="policy-section">
      <div class="policy-container">
        <!-- 1. Introduction -->
        <article class="policy-card">
          <h2>1. Introduction</h2>
          <p>
            Welcome to Earnova. This Privacy Policy describes how Earnova ("we", "us", or "our") collects, 
            uses, stores, and protects your personal information when you use our platform and services. 
            By accessing or using Earnova, you agree to the terms outlined in this Privacy Policy.
          </p>
          <p>
            We are committed to protecting your privacy and ensuring that your personal data is handled 
            responsibly and in compliance with applicable data protection laws. This policy applies to all 
            users of our platform, including earners, advertisers, and visitors.
          </p>
        </article>

        <!-- 2. Information We Collect -->
        <article class="policy-card">
          <h2>2. Information We Collect</h2>
          <p>
            To provide you with the best possible experience on Earnova, we collect various types of 
            information when you register, use our services, or interact with our platform:
          </p>
          
          <h3>Personal Information</h3>
          <ul>
            <li>Name, email address, and contact details provided during registration</li>
            <li>Account credentials (username and encrypted password)</li>
            <li>Payment information and withdrawal details (bank account, mobile money, etc.)</li>
            <li>Profile information including profile picture and bio (optional)</li>
            <li>Identity verification documents (for KYC compliance when required)</li>
          </ul>
          
          <h3>Usage Information</h3>
          <ul>
            <li>Tasks completed, games played, and rewards earned</li>
            <li>Platform activity logs and interaction history</li>
            <li>Device information (IP address, browser type, operating system)</li>
            <li>Location data (approximate location based on IP address)</li>
            <li>Referral and affiliate tracking data</li>
          </ul>
          
          <h3>Communication Data</h3>
          <ul>
            <li>Messages sent through our chat and support systems</li>
            <li>Feedback, reviews, and survey responses</li>
            <li>Email correspondence with our support team</li>
          </ul>
        </article>

        <!-- 3. How We Use Information -->
        <article class="policy-card">
          <h2>3. How We Use Information</h2>
          <p>
            The information we collect is used to provide, maintain, and improve our services, 
            as well as to ensure a safe and secure platform for all users. Specifically, we use your 
            information for the following purposes:
          </p>
          
          <ul>
            <li><strong>Account Management:</strong> To create and manage your Earnova account, verify your identity, and provide customer support</li>
            <li><strong>Service Delivery:</strong> To process tasks, track completions, calculate rewards, and facilitate payments</li>
            <li><strong>Platform Improvement:</strong> To analyze usage patterns, optimize user experience, and develop new features</li>
            <li><strong>Communication:</strong> To send important updates, notifications, promotional offers, and respond to inquiries</li>
            <li><strong>Security & Fraud Prevention:</strong> To detect and prevent fraudulent activities, abuse, and security threats</li>
            <li><strong>Compliance:</strong> To comply with legal obligations, enforce our terms of service, and protect our rights</li>
            <li><strong>Marketing:</strong> To personalize content, recommend relevant tasks, and send targeted marketing communications (with your consent)</li>
            <li><strong>Analytics:</strong> To generate aggregated, anonymized statistics about platform usage and performance</li>
          </ul>
          
          <p>
            We will never use your personal information for purposes beyond what is described in this 
            Privacy Policy without obtaining your explicit consent.
          </p>
        </article>

        <!-- 4. Data Protection -->
        <article class="policy-card">
          <h2>4. Data Protection</h2>
          <p>
            At Earnova, we take data security seriously and implement industry-standard measures to 
            protect your personal information from unauthorized access, disclosure, alteration, or destruction.
          </p>
          
          <h3>Security Measures</h3>
          <ul>
            <li><strong>Encryption:</strong> All sensitive data is encrypted both in transit (using SSL/TLS) and at rest</li>
            <li><strong>Access Controls:</strong> Strict access controls ensure only authorized personnel can access user data</li>
            <li><strong>Regular Audits:</strong> We conduct regular security audits and vulnerability assessments</li>
            <li><strong>Secure Infrastructure:</strong> Our servers are hosted in secure, certified data centers with 24/7 monitoring</li>
            <li><strong>Password Protection:</strong> User passwords are hashed using strong cryptographic algorithms</li>
            <li><strong>Two-Factor Authentication:</strong> Optional 2FA is available for enhanced account security</li>
          </ul>
          
          <h3>Data Sharing Policy</h3>
          <p>
            We do not sell, rent, or trade your personal information to third parties. Your data is only 
            shared in the following limited circumstances:
          </p>
          <ul>
            <li>With your explicit consent</li>
            <li>With trusted service providers who assist in operating our platform (under strict confidentiality agreements)</li>
            <li>When required by law or to comply with legal processes</li>
            <li>To protect the rights, property, or safety of Earnova, our users, or the public</li>
            <li>In connection with a business transfer (merger, acquisition, or sale of assets)</li>
          </ul>
        </article>

        <!-- 5. Cookies and Tracking -->
        <article class="policy-card">
          <h2>5. Cookies and Tracking</h2>
          <p>
            Earnova uses cookies and similar tracking technologies to enhance your experience, 
            analyze platform performance, and deliver personalized content. Cookies are small text 
            files stored on your device that help us recognize you and remember your preferences.
          </p>
          
          <h3>Types of Cookies We Use</h3>
          <ul>
            <li><strong>Essential Cookies:</strong> Required for the platform to function properly (login sessions, security features)</li>
            <li><strong>Performance Cookies:</strong> Help us understand how users interact with our platform (analytics, error tracking)</li>
            <li><strong>Functional Cookies:</strong> Remember your preferences and settings for a personalized experience</li>
            <li><strong>Marketing Cookies:</strong> Used to deliver relevant advertisements and track campaign effectiveness</li>
          </ul>
          
          <h3>Managing Cookies</h3>
          <p>
            You can control and manage cookies through your browser settings. Most browsers allow you to:
          </p>
          <ul>
            <li>View and delete cookies</li>
            <li>Block third-party cookies</li>
            <li>Block cookies from specific sites</li>
            <li>Block all cookies (note: this may affect platform functionality)</li>
          </ul>
          
          <p>
            We also use third-party analytics services (such as Google Analytics) to help us understand 
            user behavior and improve our services. These services may use cookies and collect data 
            according to their own privacy policies.
          </p>
        </article>

        <!-- 6. User Rights -->
        <article class="policy-card">
          <h2>6. User Rights</h2>
          <p>
            As a user of Earnova, you have certain rights regarding your personal data. We are committed 
            to honoring these rights and providing you with control over your information.
          </p>
          
          <h3>Your Rights Include:</h3>
          <ul>
            <li><strong>Right to Access:</strong> You can request a copy of all personal data we hold about you</li>
            <li><strong>Right to Rectification:</strong> You can update or correct inaccurate or incomplete information</li>
            <li><strong>Right to Erasure:</strong> You can request deletion of your personal data (subject to legal obligations)</li>
            <li><strong>Right to Restriction:</strong> You can request that we limit how we use your data</li>
            <li><strong>Right to Data Portability:</strong> You can request your data in a structured, machine-readable format</li>
            <li><strong>Right to Object:</strong> You can object to certain types of data processing (e.g., marketing communications)</li>
            <li><strong>Right to Withdraw Consent:</strong> You can withdraw consent for data processing at any time</li>
          </ul>
          
          <h3>How to Exercise Your Rights</h3>
          <p>
            To exercise any of these rights, you can:
          </p>
          <ul>
            <li>Access your account settings to update or delete information</li>
            <li>Contact our support team at <a href="mailto:privacy@earnova.com">privacy@earnova.com</a></li>
            <li>Submit a formal data request through our privacy portal</li>
          </ul>
          
          <p>
            We will respond to your request within 30 days. Please note that some requests may require 
            identity verification to protect your privacy and security.
          </p>
        </article>

        <!-- 7. Contact Us -->
        <article class="policy-card">
          <h2>7. Contact Us</h2>
          <p>
            If you have any questions, concerns, or requests regarding this Privacy Policy or how we 
            handle your personal data, we're here to help. Please don't hesitate to reach out to us.
          </p>
          
          <h3>Contact Information</h3>
          <ul>
            <li><strong>Email:</strong> <a href="mailto:privacy@earnova.com">info@earnova-digital-hub.com</a></li>
            <li><strong>Support:</strong> <a href="mailto:support@earnova.com">info@earnova-digital-hub.com</a></li>
            <li><strong>General Inquiries:</strong> <a href="mailto:info@earnova.com">info@earnova-digital-hub.com</a></li>
          </ul>
          
          <p>
            For urgent privacy concerns or data breach notifications, please mark your email as "URGENT" 
            in the subject line, and we will prioritize your request.
          </p>
          
          <h3>Updates to This Policy</h3>
          <p>
            We may update this Privacy Policy from time to time to reflect changes in our practices, 
            technology, legal requirements, or other factors. When we make significant changes, we will 
            notify you via email or through a prominent notice on our platform. We encourage you to 
            review this policy periodically to stay informed about how we protect your information.
          </p>
          
          <p>
            <strong>Last Updated:</strong> January 2025
          </p>
          
          <p>
            Thank you for trusting Earnova with your personal information. Your privacy is our priority, 
            and we are committed to maintaining that trust through transparent and responsible data practices.
          </p>
        </article>
      </div>
    </section>
  </main>

  <!-- Footer -->
  <footer id="contact" role="contentinfo">
   
      <div class="footer-bottom">
        <p>&copy; 2025 Earnova. All rights reserved. Built with care for earners and advertisers worldwide.</p>
      </div>
    </div>
  </footer>

  <!-- Scroll to top button -->
  <button class="scroll-to-top" aria-label="Scroll to top">
    <!-- <svg viewBox="0 0 24 24" fill="currentColor">
      <path d="M7.41 15.41L12 10.83l4.59 4.58L18 14l-6-6-6 6z"/>
    </svg> -->
  </button>

  <!-- GSAP + ScrollTrigger + ScrollToPlugin (deferred for performance) -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.5/gsap.min.js" defer></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.5/ScrollTrigger.min.js" defer></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.5/ScrollToPlugin.min.js" defer></script>
  
  <script defer>
    // Wait for GSAP to load
    window.addEventListener('load', function() {
      // Register GSAP plugins
      gsap.registerPlugin(ScrollTrigger, ScrollToPlugin);
      
      // Respect prefers-reduced-motion
      const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
      
      // Hamburger menu functionality
      const hamburger = document.querySelector('.hamburger-menu');
      const mobileMenu = document.querySelector('.mobile-menu');
      
      hamburger.addEventListener('click', function() {
        this.classList.toggle('active');
        mobileMenu.classList.toggle('active');
        const isExpanded = this.classList.contains('active');
        this.setAttribute('aria-expanded', isExpanded);
      });
      
      // Close mobile menu when clicking on a link
      const mobileLinks = document.querySelectorAll('.mobile-menu a');
      mobileLinks.forEach(link => {
        link.addEventListener('click', function() {
          hamburger.classList.remove('active');
          mobileMenu.classList.remove('active');
          hamburger.setAttribute('aria-expanded', 'false');
        });
      });
      
      // Scroll to top button functionality
      const scrollToTopBtn = document.querySelector('.scroll-to-top');
      
      window.addEventListener('scroll', function() {
        if (window.pageYOffset > 300) {
          scrollToTopBtn.classList.add('visible');
        } else {
          scrollToTopBtn.classList.remove('visible');
        }
      });
      
      scrollToTopBtn.addEventListener('click', function() {
        gsap.to(window, {
          duration: 1,
          scrollTo: { y: 0 },
          ease: 'power3.inOut'
        });
      });
      
      if (!prefersReducedMotion) {
        // Hero entrance animation
        gsap.from('.hero-title', {
          duration: 1,
          y: 50,
          opacity: 0,
          ease: 'power3.out'
        });
        
        gsap.from('.hero-subtitle', {
          duration: 1,
          y: 30,
          opacity: 0,
          delay: 0.2,
          ease: 'power3.out'
        });
        
        // Policy cards scroll animation
        gsap.utils.toArray('.policy-card').forEach((card, index) => {
          gsap.from(card, {
            scrollTrigger: {
              trigger: card,
              start: 'top 85%',
              toggleActions: 'play none none none'
            },
            duration: 0.8,
            y: 50,
            opacity: 0,
            delay: index * 0.1,
            ease: 'power3.out'
          });
        });
      }
      
      // Smooth scroll for anchor links
      document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
          e.preventDefault();
          const target = document.querySelector(this.getAttribute('href'));
          if (target) {
            gsap.to(window, {
              duration: 1,
              scrollTo: {
                y: target,
                offsetY: 80
              },
              ease: 'power3.inOut'
            });
          }
        });
      });
      
      // Header background on scroll
      const header = document.querySelector('header');
      ScrollTrigger.create({
        start: 'top -80',
        end: 99999,
        toggleClass: {
          className: 'scrolled',
          targets: header
        }
      });
      
      console.log('[v0] Privacy Policy page initialized with GSAP animations');
    });
  </script>
</body>
</html>
