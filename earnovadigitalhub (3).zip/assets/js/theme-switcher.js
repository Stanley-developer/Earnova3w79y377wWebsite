/**
 * FlowEarner Theme Switcher
 * Handles theme toggling with smooth animations
 */

class ThemeSwitcher {
  constructor() {
    this.currentTheme = document.documentElement.classList.contains("light") ? "light" : "dark"
    this.init()
  }

  init() {
    // Add theme toggle button if it doesn't exist
    this.createToggleButton()

    // Listen for theme changes
    this.setupEventListeners()

    // Apply saved theme
    this.applyTheme(this.currentTheme)
  }

  createToggleButton() {
    // Check if button already exists
    if (document.getElementById("theme-toggle-btn")) {
      return
    }

    const button = document.createElement("button")
    button.id = "theme-toggle-btn"
    button.className = "theme-toggle-button"
    button.setAttribute("aria-label", "Toggle theme")
    button.innerHTML = this.getButtonIcon()

    // Add styles
    const style = document.createElement("style")
    style.textContent = `
            .theme-toggle-button {
                position: fixed;
                bottom: 24px;
                right: 24px;
                width: 56px;
                height: 56px;
                border-radius: 50%;
                background: linear-gradient(135deg, var(--accent-mint), var(--primary-blue-300));
                border: none;
                cursor: pointer;
                display: flex;
                align-items: center;
                justify-content: center;
                box-shadow: 0 8px 24px rgba(77, 225, 193, 0.4);
                transition: transform 0.3s ease, box-shadow 0.3s ease;
                z-index: 1000;
            }
            
            .theme-toggle-button:hover {
                transform: translateY(-4px) scale(1.05);
                box-shadow: 0 12px 32px rgba(77, 225, 193, 0.6);
            }
            
            .theme-toggle-button svg {
                width: 24px;
                height: 24px;
                fill: white;
                transition: transform 0.3s ease;
            }
            
            .theme-toggle-button:active svg {
                transform: rotate(180deg);
            }
            
            @media (max-width: 768px) {
                .theme-toggle-button {
                    bottom: 100px;
                    right: 16px;
                    width: 48px;
                    height: 48px;
                }
                
                .theme-toggle-button svg {
                    width: 20px;
                    height: 20px;
                }
            }
        `
    document.head.appendChild(style)
    document.body.appendChild(button)
  }

  getButtonIcon() {
    if (this.currentTheme === "dark") {
      // Sun icon for switching to light mode
      return `<svg viewBox="0 0 24 24">
                <path d="M12 18a6 6 0 1 1 0-12 6 6 0 0 1 0 12zm0-2a4 4 0 1 0 0-8 4 4 0 0 0 0 8zM11 1h2v3h-2V1zm0 19h2v3h-2v-3zM3.515 4.929l1.414-1.414L7.05 5.636 5.636 7.05 3.515 4.93zM16.95 18.364l1.414-1.414 2.121 2.121-1.414 1.414-2.121-2.121zm2.121-14.85l1.414 1.415-2.121 2.121-1.414-1.414 2.121-2.121zM5.636 16.95l1.414 1.414-2.121 2.121-1.414-1.414 2.121-2.121zM23 11v2h-3v-2h3zM4 11v2H1v-2h3z"/>
            </svg>`
    } else {
      // Moon icon for switching to dark mode
      return `<svg viewBox="0 0 24 24">
                <path d="M10 7a7 7 0 0 0 12 4.9v.1c0 5.523-4.477 10-10 10S2 17.523 2 12 6.477 2 12 2h.1A6.979 6.979 0 0 0 10 7zm-6 5a8 8 0 0 0 15.062 3.762A9 9 0 0 1 8.238 4.938 7.999 7.999 0 0 0 4 12z"/>
            </svg>`
    }
  }

  setupEventListeners() {
    const button = document.getElementById("theme-toggle-btn")
    if (button) {
      button.addEventListener("click", () => this.toggleTheme())
    }
  }

  async toggleTheme() {
    const newTheme = this.currentTheme === "dark" ? "light" : "dark"

    // Add transition class
    document.documentElement.classList.add("theme-transitioning")

    // Update theme
    await this.applyTheme(newTheme)

    // Update server
    await this.updateServerTheme(newTheme)

    // Remove transition class
    setTimeout(() => {
      document.documentElement.classList.remove("theme-transitioning")
    }, 300)
  }

  async applyTheme(theme) {
    this.currentTheme = theme

    // Update HTML class
    document.documentElement.classList.remove("dark", "light")
    document.documentElement.classList.add(theme)

    // Update button icon
    const button = document.getElementById("theme-toggle-btn")
    if (button) {
      button.innerHTML = this.getButtonIcon()
    }

    // Store in localStorage
    localStorage.setItem("theme", theme)
  }

  async updateServerTheme(theme) {
    try {
      const formData = new FormData()
      formData.append("theme", theme)

      const response = await fetch("api/update-theme.php", {
        method: "POST",
        body: formData,
      })

      const data = await response.json()

      if (!data.success) {
        console.error("Failed to update theme on server")
      }
    } catch (error) {
      console.error("Error updating theme:", error)
    }
  }
}

// Initialize theme switcher when DOM is ready
if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", () => {
    new ThemeSwitcher()
  })
} else {
  new ThemeSwitcher()
}

// Add smooth theme transition styles
const transitionStyle = document.createElement("style")
transitionStyle.textContent = `
    html.theme-transitioning,
    html.theme-transitioning *,
    html.theme-transitioning *::before,
    html.theme-transitioning *::after {
        transition: background-color 0.3s ease, 
                    color 0.3s ease, 
                    border-color 0.3s ease,
                    box-shadow 0.3s ease !important;
    }
`
document.head.appendChild(transitionStyle)
