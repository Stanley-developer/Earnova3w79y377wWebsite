<?php
session_start();
require_once 'config/database.php';
require_once 'includes/session.php';
require_once 'includes/connect.php';



// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}


$_SESSION['last_activity'] = time();

$user_id = $_SESSION['user_id'];

try {
    $stmt = $pdo->prepare("
        SELECT u.*, 
               (SELECT COUNT(*) FROM users WHERE referred_by = u.id) as total_referrals,
               (SELECT COUNT(*) FROM users WHERE referred_by = u.id AND membership_type = 'premium') as premium_referrals,
               (SELECT COUNT(*) FROM users WHERE referred_by = u.id AND membership_type = 'free') as free_referrals,
               b.referral_earnings
        FROM users u
        LEFT JOIN balances b ON u.id = b.user_id
        WHERE u.id = ?
    ");
    $stmt->execute([$user_id]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$user) {
        session_destroy();
        header('Location: login.php');
        exit();
    }
    
    $stmt = $pdo->prepare("
      SELECT u.id, u.username, u.full_name, u.membership_type, u.advertiser_plan, u.created_at,
           (SELECT COUNT(*) FROM users WHERE referred_by = u.id) as sub_referrals,
               (SELECT COALESCE(SUM(rc.commission_amount), 0) FROM referral_commissions rc
              WHERE rc.referrer_id = ? AND rc.referred_user_id = u.id AND rc.commission_type IN ('premium_upgrade', 'premium_plus_upgrade')) as earned_from_this
      FROM users u
      WHERE u.referred_by = ?
      ORDER BY u.created_at DESC
    ");
    $stmt->execute([$user_id, $user_id]);
    $referrals = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    $stmt = $pdo->prepare("
        SELECT rc.commission_amount, rc.commission_type, rc.created_at,
               u.username, u.membership_type
        FROM referral_commissions rc
        JOIN users u ON rc.referred_user_id = u.id
        WHERE rc.referrer_id = ?
        ORDER BY rc.created_at DESC
        LIMIT 10
    ");
    $stmt->execute([$user_id]);
    $recent_commissions = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Ensure commission amounts are floats
    foreach ($recent_commissions as &$commission) {
        $commission['commission_amount'] = (float)$commission['commission_amount'];
    }
    unset($commission);
    
    $total_referrals = (int)$user['total_referrals'];
    $premium_referrals = (int)$user['premium_referrals'];
    $free_referrals = (int)$user['free_referrals'];
    $referral_earnings = (float)$user['referral_earnings'];
    
    // Calculate conversion rate
    $conversion_rate = $total_referrals > 0 ? round(($premium_referrals / $total_referrals) * 100) : 0;
    
    // Calculate pending payouts (commissions not yet withdrawn)
    $stmt = $pdo->prepare("
        SELECT SUM(commission_amount) as pending
        FROM referral_commissions
        WHERE referrer_id = ?
        AND id NOT IN (
            SELECT reference_id FROM transactions 
            WHERE user_id = ? AND transaction_type = 'referral_commission'
        )
    ");
    $stmt->execute([$user_id, $user_id]);
    $pending_result = $stmt->fetch(PDO::FETCH_ASSOC);
    $pending_payouts = (float)($pending_result['pending'] ?? 0);
    
} catch (PDOException $e) {
    error_log("Database error in referrals.php: " . $e->getMessage());
    die("An error occurred. Please try again later.");
}

function timeAgo($datetime) {
    $timestamp = strtotime($datetime);
    $diff = time() - $timestamp;
    
    if ($diff < 60) return 'just now';
    if ($diff < 3600) return floor($diff / 60) . ' minutes ago';
    if ($diff < 86400) return floor($diff / 3600) . ' hours ago';
    if ($diff < 604800) return floor($diff / 86400) . ' days ago';
    if ($diff < 2592000) return floor($diff / 604800) . ' weeks ago';
    return floor($diff / 2592000) . ' months ago';
}

$referral_link = "https://" . $_SERVER['HTTP_HOST'] . "/register.php?ref=" . htmlspecialchars($user['referral_code']);
?>
<?php include "doctype.php"; ?>
  <style>
    :root {
      --page-blue-900: #030922;
      --page-blue-700: #0a164a;
      --page-blue-500: #142a7e;
      --page-blue-300: #2c5bf5;
      --page-mint: #4de1c1;
      --page-white: #f5f9ff;
      --panel-glass: rgba(13, 24, 62, 0.84);
      --panel-border: rgba(86, 139, 241, 0.3);
      --shadow-heavy: 0 40px 120px rgba(4, 10, 36, 0.65);
      --transition-long: 0.85s cubic-bezier(0.19, 1, 0.22, 1);
      --transition-short: 0.4s ease;
      
      /* Added yellow/amber color scheme for referrals aside */
      --referral-primary: #ffb800;
      --referral-secondary: #ffd666;
      --referral-dark: #1a1200;
      --referral-glass: rgba(255, 184, 0, 0.15);
      
        /* Background Colors */
  --bg-primary: #030922;
  --bg-secondary: rgba(13, 24, 62, 0.5);
  --bg-glass: rgba(13, 24, 62, 0.78);
  --bg-hover: rgba(13, 24, 62, 0.7);
    }

    * { box-sizing: border-box; }

    body {
      margin: 0;
      font-family: "Titillium Web", "Segoe UI", sans-serif;
      background: #030922;
      color: var(--page-white);
      overflow-x: hidden;
    }

     aside {
      position: fixed;
      left: 0;
      top: 0;
      bottom: 0;
      width: 320px;
       background: rgba(13, 24, 62, 0.78);
      backdrop-filter: blur(18px);
      padding: clamp(1.25rem, 3vw, 2.25rem) clamp(1rem, 2.5vw, 2rem);
      display: flex;
      flex-direction: column;
      gap: clamp(1.25rem, 2.5vw, 2rem);
      border-right: 1px solid var(--panel-border);
      overflow-y: auto;
      z-index: 100;
      transition: transform var(--transition-short);
    }

    aside::before {
      content: "";
      position: absolute;
      inset: 0;
      background: 
        radial-gradient(circle at 20% 30%, rgba(251, 191, 36, 0.15), transparent 50%),
        radial-gradient(circle at 80% 70%, rgba(245, 158, 11, 0.12), transparent 45%);
      pointer-events: none;
    }

    main {
      margin-left: 320px;
      flex: 1;
      padding: clamp(2rem, 4vw, 2.625rem) clamp(1.5rem, 3vw, 3rem);
      display: grid;
      gap: clamp(1rem, 1.8vw, 1.2rem);
    }

    @media (max-width: 960px) {
      .page-shell {
        display: block;
      }

      aside {
        position: relative;
        top: 0;
        width: 100%;
        height: auto;
        border-right: none;
        border-bottom: 1px solid var(--panel-border);
        padding: clamp(1rem, 2.5vw, 1.75rem) clamp(0.875rem, 2vw, 1.25rem);
        gap: clamp(0.875rem, 2vw, 1.25rem);
      }

      aside.scrolled .page-title,
      aside.scrolled .side-description,
      aside.scrolled .vector-cluster {
        display: none;
      }

      aside.scrolled {
        padding: clamp(0.75rem, 1.5vw, 1rem) clamp(0.875rem, 2vw, 1.25rem);
      }

      aside.scrolled .aside-welcome {
        grid-template-columns: auto 1fr;
      }

      main {
        margin-left: 0;
        padding: clamp(1.5rem, 3vw, 2rem) clamp(0.625rem, 1.5vw, 1.25rem) 10rem;
      }

      .vector-cluster {
        display: none;
      }
    }

    .back-link {
      display: inline-flex;
      align-items: center;
      gap: 10px;
      font-weight: 600;
      font-size: clamp(0.75rem, 1.5vw, 0.875rem);
      letter-spacing: 0.1em;
      text-transform: uppercase;
      color: rgba(210, 226, 255, 0.78);
      transition: color var(--transition-short), transform var(--transition-short);
      text-decoration: none;
    }

    .back-link:hover { color: var(--page-white); transform: translateX(-4px); }

    .page-title {
      font-size: clamp(1rem, 3vw, 1.5rem);
      letter-spacing: 0.1em;
      text-transform: uppercase;
      margin: 0 0 clamp(0.5rem, 1vw, 0.75rem);
      font-weight: 700;
    }

    .side-description { 
      color: rgba(206, 224, 255, 0.74); 
      line-height: 1.7; 
      font-size: clamp(0.875rem, 1.5vw, 1rem);
    }

    .vector-cluster {
      position: relative;
      border-radius: 24px;
      padding: clamp(1rem, 2vw, 1.5rem);
      background: 
        linear-gradient(135deg, rgba(251, 191, 36, 0.3), rgba(217, 119, 6, 0.6)),
        rgba(12, 29, 82, 0.9);
      box-shadow: var(--shadow-heavy);
      overflow: hidden;
    }

    .vector-cluster::after {
      content: "";
      position: absolute;
      width: 320px;
      height: 320px;
      top: -150px;
      right: -120px;
      border-radius: 50%;
      background: radial-gradient(circle, rgba(245, 158, 11, 0.35), transparent 60%);
    }

    .vector-cluster img {
      width: 100%;
      border-radius: 18px;
      display: block;
      filter: drop-shadow(0 28px 80px rgba(251, 191, 36, 0.4));
    }

    .aside-welcome {
      display: grid;
      grid-template-columns: auto 1fr;
      align-items: center;
      gap: clamp(0.75rem, 1.5vw, 1rem);
      background: linear-gradient(135deg, rgba(44, 91, 245, 0.3), rgba(26, 58, 171, 0.2));
      border: 1px solid rgba(44, 91, 245, 0.5);
      box-shadow: 0 0 10px rgba(44, 91, 245, 0.6);
      border-radius: 20px;
      padding: clamp(0.875rem, 1.75vw, 1.125rem);
      
      position: relative;
      z-index: 2;
    }

    .aside-avatar {
      width: clamp(48px, 10vw, 64px);
      height: clamp(48px, 10vw, 64px);
      border-radius: 50%;
      overflow: hidden;
      border: 4px solid rgba(251, 191, 36, 0.35);
      box-shadow: 0 14px 34px rgba(3, 9, 30, 0.55);
    }

    .aside-avatar img {
      width: 100%;
      display: block;
    }

    .welcome-tag {
      margin: 0;
      font-size: clamp(0.6875rem, 1.25vw, 0.75rem);
      letter-spacing: 0.12em;
      text-transform: uppercase;
      color: rgba(205, 219, 255, 0.62);
    }

    .aside-welcome h3 {
      margin: clamp(0.25rem, 0.5vw, 0.375rem) 0 clamp(0.125rem, 0.25vw, 0.25rem);
      font-size: clamp(1rem, 2vw, 1.12rem);
      letter-spacing: 0.04em;
      color: var(--page-white);
      font-weight: 700;
    }

    .welcome-meta {
      font-size: clamp(0.75rem, 1.5vw, 0.8rem);
      letter-spacing: 0.08em;
      color: rgba(149, 183, 255, 0.7);
    }
    .referral-hero {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
      gap: 12px;
      align-items: center;
      background: var(--panel-glass);
      border-radius: 26px;
      border: 1px solid var(--panel-border);
      padding: 38px;
      box-shadow: var(--shadow-heavy);
      position: relative;
      overflow: hidden;
    }

    .referral-hero::before {
      content: "";
      position: absolute;
      inset: 0;
      background: url("front/assets/images/who-we-are-img.png") center/contain no-repeat;
      opacity: 0.06;
    }

    .referral-copy { position: relative; z-index: 2; }

    .referral-copy h1 { 
      margin: 0 0 12px; 
      font-size: clamp(1.8rem, 4vw, 2.4rem); 
    }

    .referral-copy p { 
      margin: 0; 
      color: rgba(218, 231, 255, 0.78); 
      line-height: 1.7; 
      font-size: clamp(0.875rem, 2vw, 1rem);
    }

    .referral-stats {
      background: rgba(9, 23, 66, 0.9);
      border: 1px solid var(--panel-border);
      border-radius: 24px;
      padding: 28px;
      box-shadow: var(--shadow-heavy);
      display: grid;
      gap: 18px;
    }

    .stats-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
      gap: 10px;
    }

    .stat-card {
      padding: 22px;
      border-radius: 18px;
      background: rgba(6, 16, 48, 0.9);
      border: 1px solid rgba(100, 154, 255, 0.24);
      box-shadow: var(--shadow-heavy);
      position: relative;
      overflow: hidden;
    }

    .stat-card::after {
      content: "";
      position: absolute;
      width: 110px;
      height: 110px;
      top: -24px;
      right: -16px;
      border-radius: 50%;
      background: radial-gradient(circle, rgba(77, 225, 193, 0.28), transparent 60%);
    }

    .stat-label { 
      font-size: clamp(0.75rem, 2vw, 0.85rem); 
      letter-spacing: 0.18em; 
      text-transform: uppercase; 
      color: rgba(205, 222, 255, 0.7); 
    }

    .stat-value { 
      font-size: clamp(1.5rem, 3vw, 1.9rem); 
      font-weight: 700; 
      margin: 12px 0; 
    }

    .stat-card > div:last-child {
      font-size: 0.65rem;
    }

    .code-panel {
      display: grid;
      gap: 10px;
      padding: 24px;
      border-radius: 18px;
      background: rgba(5, 15, 43, 0.9);
      border: 1px solid rgba(107, 162, 255, 0.3);
    }

    .code-box {
      display: flex;
      gap: 12px;
      align-items: center;
      padding: 14px 18px;
      border-radius: 16px;
      background: rgba(16, 34, 109, 0.62);
      border: 1px solid rgba(120, 170, 255, 0.35);
      font-weight: 600;
      letter-spacing: 0.1em;
      text-transform: uppercase;
      font-size: clamp(0.875rem, 2vw, 1rem);
      cursor: pointer;
      transition: background var(--transition-short), transform var(--transition-short);
      user-select: all;
    }

    .code-box:hover {
      background: rgba(16, 34, 109, 0.75);
      transform: translateY(-2px);
    }

    .code-box:active {
      transform: translateY(0);
    }

    .btn-copy {
      border: none;
      border-radius: 14px;
      padding: 10px 16px;
      font-weight: 600;
      letter-spacing: 0.05em;
      text-transform: uppercase;
      background: rgba(45, 92, 230, 0.72);
      color: var(--page-white);
      border: 1px solid rgba(115, 166, 255, 0.4);
      cursor: pointer;
      transition: transform var(--transition-short);
      font-size: clamp(0.8rem, 2vw, 0.9rem);
    }

    .btn-copy:hover { transform: translateY(-3px); }

    .referral-list {
      display: grid;
      gap: 10px;
    }

    .referral-entry {
      display: grid;
      grid-template-columns: 60px 1fr 120px;
      gap: 18px;
      align-items: center;
      padding: 18px 20px;
      border-radius: 18px;
      background: rgba(6, 16, 48, 0.88);
      border: 1px solid rgba(100, 154, 255, 0.24);
      box-shadow: var(--shadow-heavy);
    }

    .referral-entry img { width: 60px; border-radius: 50%; border: 4px solid rgba(75, 120, 255, 0.45); }

    .referral-entry strong { font-size: clamp(1rem, 2vw, 1.08rem); }

    .referral-entry span { 
      color: rgba(205, 219, 255, 0.72); 
      font-size: clamp(0.8rem, 2vw, 0.9rem);
    }

    .badge {
      padding: 8px 12px;
      border-radius: 12px;
      background: rgba(77, 225, 193, 0.22);
      color: var(--page-mint);
      font-weight: 600;
      letter-spacing: 0.08em;
      text-transform: uppercase;
      text-align: center;
      font-size: clamp(0.7rem, 2vw, 0.8rem);
    }

    .ticker {
      border-radius: 24px;
      border: 1px solid rgba(77, 225, 193, 0.32);
      background: rgba(8, 18, 52, 0.78);
      padding: 16px;
      box-shadow: var(--shadow-heavy);
      overflow: hidden;
    }

    .ticker-track {
      display: inline-flex;
      gap: 42px;
      animation: tickerMove 30s linear infinite;
      letter-spacing: 0.16em;
      text-transform: uppercase;
      color: rgba(204, 228, 255, 0.82);
      font-weight: 600;
      white-space: nowrap;
      font-size: clamp(0.75rem, 2vw, 0.9rem);
    }

    @keyframes tickerMove { from { transform: translateX(0); } to { transform: translateX(-50%); } }

    footer {
      padding: 48px 0 36px;
      background: linear-gradient(180deg, rgba(1, 5, 16, 0.95), rgba(1, 4, 12, 0.98));
      border-top: 1px solid rgba(86, 136, 230, 0.2);
    }

    .footer-grid {
      max-width: 1020px;
      margin: 0 auto;
      padding: 0 32px;
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(160px, 1fr));
      gap: 24px;
    }

    .footer-list h4 {
      text-transform: uppercase;
      letter-spacing: 0.12em;
      font-size: clamp(0.75rem, 2vw, 0.82rem);
      margin-bottom: 16px;
      color: rgba(181, 201, 240, 0.76);
    }

    .footer-list ul {
      list-style: none;
      padding: 0;
      margin: 0;
      display: grid;
      gap: 12px;
    }

    .footer-list a {
      color: rgba(210, 224, 253, 0.7);
      font-size: clamp(0.8rem, 2vw, 0.9rem);
      transition: color var(--transition-short);
    }

    .footer-list a:hover { color: var(--page-mint); }

    .footer-brand {
      text-align: center;
      text-transform: uppercase;
      letter-spacing: 0.14em;
      color: rgba(160, 180, 226, 0.68);
      margin-top: 32px;
      font-size: clamp(0.7rem, 2vw, 0.76rem);
    }

 .section-white {
      background: var(--panel-glass);
      border: 1px solid var(--panel-border);
      box-shadow: var(--shadow-heavy);
      border-radius: 26px;
      box-shadow: var(--shadow-heavy);
      padding: clamp(24px, 3.5vw, 36px);
      position: relative;
      overflow: hidden;
      color: #fff;
    }

    .section-white::before {
      content: "";
      position: absolute;
      inset: 0;
      color: #fff;
      background: radial-gradient(circle at 80% 20%, rgba(44, 92, 240, 0.14), transparent 60%);
    }

    .section-white h2 {
      margin-top: 0;
      color: #fff;
      font-size: 18px;
      font-weight: 700;
    }

    .section-white p {
      color: #fff;
      line-height: 1.7;
      font-size: 13px;
      margin-top: 20px;
    }

    .referral-chip-row {
      position: relative;
      z-index: 2;
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
      gap: 18px;
      margin-top: 24px;
    }

    .referral-chip {
      padding: 18px;
      border-radius: 18px;
      background: rgba(44, 92, 240, 0.08);
      border: 1px solid rgba(44, 92, 240, 0.18);
      color: var(--page-blue-500);
      font-weight: 600;
      letter-spacing: 0.02em;
      display: grid;
      gap: 6px;
    }

    .referral-chip span {
      font-size: clamp(0.7rem, 2vw, 0.75rem);
      letter-spacing: 0.1em;
      text-transform: uppercase;
      color: rgba(20, 42, 126, 0.6);
    }
 
    /* Updated mobile footer with 5 icons */
    .mobile-fintech-footer {
      display: none;
      position: fixed;
      left: 12px;
      right: 12px;
      bottom: 16px;
      padding: 10px;
      background: transparent;
      border: 1px solid rgba(86, 139, 241, 0.35);
      border-radius: 32px;
      backdrop-filter: blur(50px);
      box-shadow: 0 20px 60px rgba(4, 10, 36, 0.7);
      justify-content: space-around;
      align-items: center;
      z-index: 90;
    }

    .mobile-fintech-footer a {
      flex: 1;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      gap: 4px;
      text-decoration: none;
      color: rgba(205, 219, 255, 0.75);
      font-size: 0.45rem;
      letter-spacing: 0.06em;
      text-transform: uppercase;
      transition: all var(--transition-short);
      padding: 8px 4px;
      border-radius: 16px;
    }

    /* Special styling for middle icon (3rd icon - Withdraw) */
    /* .mobile-fintech-footer a:nth-child(3) {
      position: relative;
      transform: translateY(-12px);
    } */

    .mobile-fintech-footer a:nth-child(3) .icon-wrapper {
      width: 56px;
      height: 56px;
      border-radius: 50%;
      background: linear-gradient(135deg, rgba(77, 225, 193, 0.25), rgba(47, 91, 234, 0.25));
      backdrop-filter: blur(12px);
      border: 2px solid rgba(77, 225, 193, 0.4);
      display: flex;
      align-items: center;
      justify-content: center;
      box-shadow: 0 8px 24px rgba(77, 225, 193, 0.3);
    }

    .mobile-fintech-footer a:nth-child(3) svg {
      width: 28px;
      height: 28px;
    }

    .mobile-fintech-footer a.active {
      color: var(--page-mint);
    }

    .mobile-fintech-footer svg {
      width: 22px;
      height: 22px;
      fill: currentColor;
      filter: drop-shadow(0 4px 12px rgba(4, 10, 36, 0.4));
    }

    .mobile-fintech-footer a:hover {
      color: var(--page-mint);
      transform: translateY(-2px);
    }

    .mobile-fintech-footer a:nth-child(3):hover {
      transform: translateY(-14px);
    }

    @media (max-width: 680px) {
      body {
        padding-bottom: 160px;
      }

      aside {
        padding: 28px 20px;
      }

      main {
        padding: 32px 10px 160px;
      }

      .referral-hero,
      .referral-stats,
      .referral-list,
      .ticker,
      .section-white {
        margin-left: 0;
        margin-right: 0;
      }

      .referral-entry {
        margin: 0;
        grid-template-columns: 50px 1fr 100px;
      }

      .mobile-fintech-footer {
        display: flex;
      }

      .stats-grid {
        grid-template-columns: repeat(3, 1fr);
        gap: 8px;
      }

      .stat-card {
        padding: 12px 8px;
      }

      .stat-label {
        font-size: 0.6rem;
      }

      .stat-value {
        font-size: 1.1rem;
        margin: 6px 0;
      }

      .stat-card > div:last-child {
        font-size: 0.65rem;
      }
    }

    .copy-toast {
      position: fixed;
      top: 20px;
      right: 20px;
      background: rgba(77, 225, 193, 0.95);
      color: #030922;
      padding: 16px 24px;
      border-radius: 16px;
      display: flex;
      align-items: center;
      gap: 12px;
      box-shadow: 0 10px 40px rgba(77, 225, 193, 0.4);
      z-index: 1000;
      opacity: 0;
      transform: translateY(-20px);
      transition: all 0.4s ease;
      font-weight: 600;
      letter-spacing: 0.05em;
    }

    .copy-toast.show {
      opacity: 1;
      transform: translateY(0);
    }

    .copy-toast svg {
      width: 24px;
      height: 24px;
      fill: #030922;
    }

     .rewards-hero {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
      gap: clamp(1.25rem, 2.5vw, 1.75rem);
      align-items: center;
      background: var(--panel-glass);
      border-radius: 26px;
      border: 1px solid var(--panel-border);
      padding: clamp(1.75rem, 3vw, 2.375rem);
      box-shadow: var(--shadow-heavy);
      position: relative;
      overflow: hidden;
    }

    .rewards-hero::before {
      content: "";
      position: absolute;
      inset: 0;
      background: url("front/assets/images/header-right-img.png") right/contain no-repeat;
      opacity: 0.08;
    }

    .upgrade-banner {
      background: var(--panel-glass);
      border: 1px solid var(--panel-border);
      border-radius: 26px;
      padding: clamp(1.75rem, 3vw, 2.375rem);
      margin-bottom: clamp(0.75rem, 1.5vw, 1rem);
      box-shadow: var(--shadow-heavy);
      position: relative;
      overflow: hidden;
    }

    .upgrade-banner::before {
      content: "";
      position: absolute;
      inset: 0;
      background: radial-gradient(circle at 20% 30%, rgba(77, 225, 193, 0.15), transparent 50%),
                  radial-gradient(circle at 80% 70%, rgba(44, 92, 240, 0.12), transparent 45%);
      pointer-events: none;
    }

    .banner-content {
      position: relative;
      z-index: 2;
      display: grid;
      gap: clamp(0.75rem, 1.5vw, 1.25rem);
    }

    .banner-title {
      font-size: clamp(1.1rem, 2vw, 1.3rem);
      font-weight: 700;
      color: var(--page-mint);
      margin: 0;
      letter-spacing: 0.04em;
      line-height: 1.6;
    }

    .banner-subtitle {
      font-size: clamp(0.875rem, 1.6vw, 1rem);
      color: rgba(210, 224, 253, 0.82);
      line-height: 1.8;
      margin: 0;
      font-weight: 500;
      letter-spacing: 0.02em;
    }

    .banner-highlight {
      color: var(--referral-primary);
      font-weight: 700;
    }

    .downlines-container {
      border-radius: 24px;
      border: 1px solid var(--panel-border);
      background: rgba(6, 16, 48, 0.88);
      padding: 28px;
      box-shadow: var(--shadow-heavy);
      overflow: hidden;
    }

    .downlines-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 20px;
      position: relative;
      z-index: 2;
    }

    .downlines-header h3 {
      margin: 0;
      font-size: clamp(1.1rem, 2vw, 1.3rem);
      color: var(--page-white);
      font-weight: 700;
      letter-spacing: 0.04em;
    }

    .downlines-count {
      background: linear-gradient(135deg, rgba(77, 225, 193, 0.2), rgba(44, 92, 240, 0.2));
      border: 1px solid rgba(77, 225, 193, 0.3);
      border-radius: 12px;
      padding: 8px 16px;
      font-weight: 600;
      color: var(--page-mint);
      font-size: clamp(0.8rem, 1.5vw, 0.9rem);
      letter-spacing: 0.05em;
      text-transform: uppercase;
    }

    .downlines-scroll {
      overflow-x: auto;
      overflow-y: hidden;
      scroll-behavior: smooth;
      padding-bottom: 12px;
      margin-bottom: -12px;
    }

    .downlines-scroll::-webkit-scrollbar {
      height: 6px;
    }

    .downlines-scroll::-webkit-scrollbar-track {
      background: rgba(100, 154, 255, 0.1);
      border-radius: 3px;
    }

    .downlines-scroll::-webkit-scrollbar-thumb {
      background: rgba(77, 225, 193, 0.3);
      border-radius: 3px;
    }

    .downlines-scroll::-webkit-scrollbar-thumb:hover {
      background: rgba(77, 225, 193, 0.5);
    }

    .downlines-track {
      display: inline-flex;
      gap: 14px;
      min-width: min-content;
    }

    .downline-card {
      flex: 0 0 280px;
      background: linear-gradient(135deg, rgba(44, 92, 240, 0.15), rgba(77, 225, 193, 0.1));
      border: 1px solid rgba(100, 154, 255, 0.24);
      border-radius: 16px;
      padding: 18px;
      transition: all 0.3s ease;
      cursor: pointer;
      position: relative;
      overflow: hidden;
    }

    .downline-card::before {
      content: "";
      position: absolute;
      inset: 0;
      background: radial-gradient(circle at 80% 20%, rgba(77, 225, 193, 0.15), transparent 60%);
      pointer-events: none;
    }

    .downline-card:hover {
      background: linear-gradient(135deg, rgba(44, 92, 240, 0.25), rgba(77, 225, 193, 0.15));
      border-color: rgba(77, 225, 193, 0.4);
      transform: translateY(-4px);
      box-shadow: 0 12px 32px rgba(77, 225, 193, 0.2);
    }

    .downline-content {
      position: relative;
      z-index: 2;
      display: grid;
      gap: 12px;
    }

    .downline-username {
      font-size: clamp(0.95rem, 1.8vw, 1.05rem);
      font-weight: 700;
      color: var(--page-white);
      letter-spacing: 0.03em;
      word-break: break-word;
    }

    .downline-meta {
      display: grid;
      gap: 6px;
      font-size: clamp(0.75rem, 1.5vw, 0.85rem);
    }

    .downline-meta-row {
      display: flex;
      justify-content: space-between;
      align-items: center;
      color: rgba(205, 219, 255, 0.7);
    }

    .downline-meta-label {
      color: rgba(205, 219, 255, 0.6);
      font-size: 0.8rem;
      letter-spacing: 0.05em;
      text-transform: uppercase;
    }

    .downline-meta-value {
      font-weight: 600;
      color: var(--page-mint);
    }

    .downline-badge {
      display: inline-block;
      padding: 6px 10px;
      border-radius: 8px;
      font-size: 0.7rem;
      font-weight: 600;
      letter-spacing: 0.06em;
      text-transform: uppercase;
      width: fit-content;
    }

    .downline-badge.premium {
      background: rgba(77, 225, 193, 0.25);
      color: var(--page-mint);
    }

    .downline-badge.free {
      background: rgba(100, 154, 255, 0.25);
      color: rgba(100, 154, 255, 0.9);
    }
    
    .downline-badge.premium-plus {
      background: #FFD700; /* pure gold */
      color: #2b1b00; /* dark/good contrast */
      border: 1px solid rgba(255, 215, 0, 0.28);
      box-shadow: 0 8px 24px rgba(255,215,0,0.12), 0 2px 6px rgba(0,0,0,0.12) inset;
    }

    .downline-earnings {
      border-top: 1px solid rgba(100, 154, 255, 0.2);
      padding-top: 12px;
      margin-top: 12px;
    }

    .downline-earnings-value {
      font-size: clamp(1rem, 2vw, 1.2rem);
      font-weight: 700;
      color: var(--page-mint);
      letter-spacing: 0.02em;
    }

    .downlines-empty {
      text-align: center;
      padding: 40px 20px;
      color: rgba(205, 219, 255, 0.6);
    }

    .downlines-empty svg {
      width: 60px;
      height: 60px;
      margin-bottom: 16px;
      opacity: 0.3;
    }

    .downlines-empty p {
      margin: 0;
      font-size: 0.95rem;
      line-height: 1.6;
    }

  </style>

<body>
  <?php include "embed.php" ?>
  <?php include "header2.php"; ?>
  <div class="page-shell">
   
    <main>
      <!-- Dynamic upgrade banner based on membership type -->
      <?php if ($user['membership_type'] === 'free' && !$user['advertiser_plan']): ?>
        <div class="upgrade-banner">
          <div class="banner-content">
            <p class="banner-title">Hey, you earn nothing when your downline upgrades to Premium or Premium Plus.</p>
            <p class="banner-subtitle">Enjoy up to <span class="banner-highlight">₦500 commission bonus</span> when you upgrade to Premium and <span class="banner-highlight">₦1,000 commission bonus</span> when you upgrade to Premium Plus.</p>
          </div>
        </div>
      <?php elseif ($user['membership_type'] === 'premium' && $user['advertiser_plan'] !== 'senior'): ?>
        <div class="upgrade-banner">
          <div class="banner-content">
            <p class="banner-title">Keep climbing the rewards ladder!</p>
            <p class="banner-subtitle">Enjoy up to <span class="banner-highlight">₦1,000 commission bonus</span> when you upgrade to Premium Plus.</p>
          </div>
        </div>
      <?php endif; ?>

      <!-- Display actual Invite list from database -->
      <section class="referral-list" style="background: linear-gradient(135deg, rgba(77, 225, 193, 0.08), rgba(13, 24, 62, 0.78));">
          <div class="referral-stats" style="background: linear-gradient(135deg, rgba(77, 225, 193, 0.08), rgba(13, 24, 62, 0.78));">
          <div class="stats-grid">
            <article class="stat-card">
              <div class="stat-label">Network Invites</div>
              <!-- Display actual total referrals -->
              <div class="stat-value"><?php echo $total_referrals; ?></div>
              <div>
                <?php 
                // Calculate growth (simplified - you can enhance this with historical data)
                echo $total_referrals > 0 ? "Active network" : "Start inviting friends";
                ?>
              </div>
            </article>
            <article class="stat-card">
              <div class="stat-label">Premium Members</div>
              <!-- Display actual premium referrals -->
              <div class="stat-value"><?php echo $premium_referrals; ?></div>
              <div><?php echo $free_referrals; ?> free members active</div>
            </article>
            <article class="stat-card">
              <div class="stat-label">Rewards Earned</div>
              <!-- Display actual Invite earnings -->
              <div class="stat-value">₦<?php echo number_format($referral_earnings, 2); ?></div>
              <div>
                <?php 
                // Commission info based on membership
                if ($user['membership_type'] === 'premium') {
                    echo "₦500 per premium upgrade";
                } else {
                    echo "₦0 Invite Reward per premium upgrade";
                }
                ?>
              </div>
            </article>
          </div>

             <div class="code-panel" style="background: linear-gradient(135deg, rgba(77, 225, 193, 0.08), rgba(13, 24, 62, 0.78));">
            <span style="letter-spacing: 0.08em; text-transform: uppercase; color: rgba(205, 219, 255, 0.7);">Your Invitation Code</span>
            <!-- Display actual Invite code -->
            <div class="code-box" id="referralCode" onclick="copyReferralCode()"><?php echo htmlspecialchars($user['referral_code']); ?></div>
            <!-- Added copy functionality -->
            <button class="btn-copy" onclick="copyReferralCode()">Click to Copy Code</button>
            <button class="btn-copy" onclick="copyReferralLink()" style="margin-top: 8px;">Click to Copy Link</button>
            <button class="btn-copy" onclick="shareReferralLink()" style="margin-top: 8px;">Share</button>
          </div>
        </div>
      </section>

      <!-- Downlines Mega Box with Horizontal Scroll -->
      <div class="downlines-container">
        <div class="downlines-header">
          <h3>Your Network</h3>
          <span class="downlines-count"><?php echo count($referrals); ?> Downlines</span>
        </div>
        
        <?php if (!empty($referrals)): ?>
          <div class="downlines-scroll" id="downlinesScroll">
            <div class="downlines-track">
              <?php foreach ($referrals as $downline): ?>
                <div class="downline-card">
                  <div class="downline-content">
                    <div class="downline-username"><?php echo htmlspecialchars($downline['username']); ?></div>
                    
                    <?php
                      $badge_class = 'free';
                      $badge_label = 'Free';
                      if (!empty($downline['advertiser_plan']) && strtolower($downline['advertiser_plan']) === 'senior') {
                        $badge_class = 'premium-plus';
                        $badge_label = 'Premium Plus';
                      } elseif (!empty($downline['membership_type']) && strtolower($downline['membership_type']) === 'premium') {
                        $badge_class = 'premium';
                        $badge_label = 'Premium';
                      }
                    ?>
                    <div class="downline-badge <?php echo $badge_class; ?>">
                      <?php echo $badge_label; ?>
                    </div>
                    
                    <div class="downline-meta">
                      <div class="downline-meta-row">
                        <span class="downline-meta-label">Joined</span>
                        <span class="downline-meta-value"><?php echo timeAgo($downline['created_at']); ?></span>
                      </div>
                      <!-- <div class="downline-meta-row">
                        <span class="downline-meta-label">Sub-Referrals</span>
                        <span class="downline-meta-value"><?php echo (int)$downline['sub_referrals']; ?></span>
                      </div> -->
                    </div>
                    
                    <div class="downline-earnings">
                      <div style="font-size: 0.75rem; letter-spacing: 0.06em; text-transform: uppercase; color: rgba(205, 219, 255, 0.6); margin-bottom: 6px;">Reward from this invite</div>
                      <div class="downline-earnings-value">₦<?php echo number_format((float)($downline['earned_from_this'] ?? 0), 2); ?></div>
                    </div>
                  </div>
                </div>
              <?php endforeach; ?>
            </div>
          </div>
        <?php else: ?>
          <div class="downlines-empty">
            <svg viewBox="0 0 24 24" fill="currentColor">
              <path d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z"/>
            </svg>
            <p>No downlines yet. Share your referral code to start building your network!</p>
          </div>
        <?php endif; ?>
      </div>

      <section class="section-white">
        <div class="referral-chip-row">
          <!-- Display actual conversion rate -->
          <div class="referral-chip"  style="color: #fff;">
            <span style="color: #fff;">Conversion</span>
            <?php echo $conversion_rate; ?>% of invites upgraded
          </div>
          <!-- Display actual pending payouts -->
          <div class="referral-chip"  style="color: #fff;">
            <span  style="color: #fff;">Bonuses</span>
            ₦<?php echo number_format($pending_payouts, 2); ?> pending payouts
          </div>
        </div>
      </section>

      <!-- Display actual recent commissions in ticker -->
      <section class="ticker">
        <div class="ticker-track">
          <?php if (!empty($recent_commissions)): ?>
            <?php foreach ($recent_commissions as $commission): ?>
              NEW INVITE — <?php echo htmlspecialchars($commission['username']); ?> • 
              Tier <?php echo ucfirst($commission['membership_type']); ?> • 
              ₦<?php echo number_format((float)$commission['commission_amount'], 2); ?> bonus ✦ 
            <?php endforeach; ?>
            <?php // Duplicate for seamless loop ?>
            <?php foreach ($recent_commissions as $commission): ?>
              NEW INVITE — <?php echo htmlspecialchars($commission['username']); ?> • 
              Tier <?php echo ucfirst($commission['membership_type']); ?> • 
              ₦<?php echo number_format((float)$commission['commission_amount'], 2); ?> bonus ✦ 
            <?php endforeach; ?>
          <?php else: ?>
            WAITING FOR INVITES — Share your code to start earning ✦ 
            WAITING FOR INVITES — Share your code to start earning ✦ 
          <?php endif; ?>
        </div>
      </section>


  <nav class="mobile-fintech-footer">
    
  <a href="dashboard.php">
    <svg viewBox="0 0 24 24"><path d="M12 3a9 9 0 1 1 0 18 9 9 0 0 1 0-18Zm1 4h-2v6h6v-2h-4V7Z"/></svg>
    <span>Dashboard</span>
  </a>

  <!-- Premium (crown icon) -->
  <a href="membership.php">
    <svg viewBox="0 0 24 24"><path d="M5 7l2.5 5 4.5-4 4.5 4L19 7l2 13H3l2-13Z"/></svg>
    <span>Premium</span>
  </a>

  <a href="post-task.php">
<svg viewBox="0 0 24 24" aria-hidden="true">
  <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8l-6-6Zm1 14h-3v3h-2v-3H7v-2h3v-3h2v3h3v2Zm-3-9V3.5L18.5 8H12Z"/>
</svg>
    
    <span>Post Advert</span>
  </a>
  
  

  <a href="history.php">
  <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
    <path d="M13 3a9 9 0 1 0 9 9h-2a7 7 0 1 1-7-7V3l4 4-4 4V7a5 5 0 1 0 5 5h2a7 7 0 1 1-7-7z"/>
  </svg>
  <span>History</span>
</a>


  <a href="profile.php">
    <svg viewBox="0 0 24 24"><path d="M12 2a6 6 0 0 1 6 6c0 3.31-2.69 6-6 6s-6-2.69-6-6a6 6 0 0 1 6-6Zm0 14c4.42 0 8 1.79 8 4v2H4v-2c0-2.21 3.58-4 8-4Z"/></svg>
    <span>Profile</span>
  </a>
</nav>



    </main>
  </div>

  <!-- Added toast notification element -->
  <div class="copy-toast" id="copyToast">
    <svg viewBox="0 0 24 24">
      <path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41L9 16.17z"/>
    </svg>
    <span id="toastMessage">Copied!</span>
  </div>

  <!-- Added JavaScript for copy functionality with toast -->
  <script>
    // Make username available to JavaScript
    const username = '<?php echo htmlspecialchars($user["username"]); ?>';
    
    console.log('Referrals page loaded');
    console.log('Invite code element:', document.getElementById('referralCode'));
    console.log('Toast element:', document.getElementById('copyToast'));

    function showToast(message) {
      console.log('showToast called with message:', message);
      const toast = document.getElementById('copyToast');
      const toastMessage = document.getElementById('toastMessage');
      
      if (!toast || !toastMessage) {
        console.error('Toast elements not found');
        return;
      }
      
      toastMessage.textContent = message;
      toast.classList.add('show');
      console.log('Toast shown');
      
      setTimeout(() => {
        toast.classList.remove('show');
        console.log('Toast hidden');
      }, 3000);
    }

    function copyReferralCode() {
      console.log('copyReferralCode called');
      const codeElement = document.getElementById('referralCode');
      
      if (!codeElement) {
        console.error('Invite code element not found');
        alert('Error: Could not find Invite code element');
        return;
      }
      
      const code = codeElement.textContent.trim();
      const description = `Earnova Digital Hub has higher earning incentives when you sign up with ${username} invitation code. Use the code: ${code} to create an account on Earnova Digital Hub.`;
      const textToCopy = description;
      console.log('Copying code with description:', textToCopy);
      
      if (!navigator.clipboard) {
        console.error('Clipboard API not available');
        // Fallback for older browsers
        const textArea = document.createElement('textarea');
        textArea.value = textToCopy;
        textArea.style.position = 'fixed';
        textArea.style.left = '-999999px';
        document.body.appendChild(textArea);
        textArea.select();
        try {
          document.execCommand('copy');
          document.body.removeChild(textArea);
          showToast('Invitation code copied!');
          console.log('Code copied using fallback method');
        } catch (err) {
          console.error('Fallback copy failed:', err);
          alert('Failed to copy Invite code');
        }
        return;
      }
      
      navigator.clipboard.writeText(textToCopy).then(() => {
        console.log('Code copied successfully');
        showToast('Invitation code copied!');
      }).catch(err => {
        console.error('Failed to copy code:', err);
        alert('Failed to copy Invite code: ' + err.message);
      });
    }

    function copyReferralLink() {
      console.log('copyReferralLink called');
      const link = '<?php echo $referral_link; ?>';
      const description = `Earnova Digital Hub has higher earning incentives when you sign up with ${username} invitation link. Use the link: ${link} to create an account on Earnova Digital Hub.`;
      const textToCopy = description;
      console.log('Copying link with description:', textToCopy);
      
      if (!navigator.clipboard) {
        console.error('Clipboard API not available');
        // Fallback for older browsers
        const textArea = document.createElement('textarea');
        textArea.value = textToCopy;
        textArea.style.position = 'fixed';
        textArea.style.left = '-999999px';
        document.body.appendChild(textArea);
        textArea.select();
        try {
          document.execCommand('copy');
          document.body.removeChild(textArea);
          showToast('Invitation link copied!');
          console.log('Link copied using fallback method');
        } catch (err) {
          console.error('Fallback copy failed:', err);
          alert('Failed to copy invite link');
        }
        return;
      }
      
      navigator.clipboard.writeText(textToCopy).then(() => {
        console.log('Link copied successfully');
        showToast('Invite link copied!');
      }).catch(err => {
        console.error('Failed to copy link:', err);
        alert('Failed to copy Invite link: ' + err.message);
      });
    }

    function shareReferralLink() {
      console.log('shareReferralLink called');
      const link = '<?php echo $referral_link; ?>';
      const title = 'Join me on Earnova Hub and earn rewards!';
      const description = `Earnova Digital Hub has higher earning incentives when you sign up with ${username} invitation link. Use the link: ${link} to create an account on Earnova Digital Hub.`;
      const text = description;
      
      // Check if native Share API is available
      if (navigator.share) {
        console.log('Native Share API available');
        navigator.share({
          title: title,
          text: text,
          url: link
        }).then(() => {
          console.log('Share successful');
          showToast('Shared successfully!');
        }).catch(err => {
          if (err.name !== 'AbortError') {
            console.error('Share failed:', err);
          }
        });
      } else {
        console.log('Native Share API not available, showing manual share options');
        showShareOptions(link, description);
      }
    }

    function showShareOptions(link, description) {
      const encodedLink = encodeURIComponent(link);
      const encodedDescription = encodeURIComponent(description);
      const encodedShareText = encodedDescription;
      
      const shareOptions = {
        'WhatsApp': `https://api.whatsapp.com/send?text=${encodedShareText}`,
        'Twitter': `https://twitter.com/intent/tweet?text=${encodedShareText}`,
        'TikTok': `https://www.tiktok.com/share?url=${encodedLink}`,
        'Copy Link': null
      };
      
      // Create a simple prompt for manual sharing
      let message = 'Share your Invite link:\n\n';
      let optionNum = 1;
      const options = [];
      
      for (const [platform, url] of Object.entries(shareOptions)) {
        if (platform === 'Copy Link') {
          message += `${optionNum}. ${platform}\n`;
          options.push({ platform, url });
        } else {
          message += `${optionNum}. Open ${platform}: ${url}\n`;
          options.push({ platform, url });
        }
        optionNum++;
      }
      
      message += `\nInvite Link: ${link}\n\nOr manually copy and share the link above.`;
      
      // Create modal for share options
      const modal = document.createElement('div');
      modal.style.cssText = `
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background: rgba(3, 9, 34, 0.9);
        backdrop-filter: blur(10px);
        display: flex;
        justify-content: center;
        align-items: center;
        z-index: 10000;
      `;
      
      const modalContent = document.createElement('div');
      modalContent.style.cssText = `
        background: linear-gradient(180deg, rgba(13, 24, 62, 0.98), rgba(8, 18, 52, 0.98));
        border: 1px solid rgba(86, 139, 241, 0.28);
        border-radius: 16px;
        padding: 32px;
        max-width: 400px;
        box-shadow: 0 20px 60px rgba(4, 10, 36, 0.7);
        font-family: 'Poppins', sans-serif;
      `;
      
      const title_el = document.createElement('h2');
      title_el.textContent = 'Share Your Invite Link';
      title_el.style.cssText = `
        font-size: 1.5rem;
        color: #fff;
        margin: 0 0 24px 0;
        font-weight: 700;
      `;
      modalContent.appendChild(title_el);
      
      const optionsContainer = document.createElement('div');
      optionsContainer.style.cssText = `
        display: grid;
        gap: 12px;
        margin-bottom: 24px;
      `;
      
      options.forEach(option => {
        const btn = document.createElement('button');
        btn.textContent = option.platform;
        btn.style.cssText = `
          padding: 12px 16px;
          background: linear-gradient(135deg, rgba(77, 225, 193, 0.2), rgba(44, 92, 240, 0.2));
          color: #4de1c1;
          border: 1px solid rgba(77, 225, 193, 0.3);
          border-radius: 8px;
          font-family: 'Poppins', sans-serif;
          font-weight: 600;
          cursor: pointer;
          transition: all 0.3s ease;
          font-size: 0.95rem;
        `;
        btn.onmouseover = () => {
          btn.style.background = 'linear-gradient(135deg, rgba(77, 225, 193, 0.3), rgba(44, 92, 240, 0.3))';
        };
        btn.onmouseout = () => {
          btn.style.background = 'linear-gradient(135deg, rgba(77, 225, 193, 0.2), rgba(44, 92, 240, 0.2))';
        };
        
        if (option.platform === 'Copy Link') {
          btn.onclick = () => {
            navigator.clipboard.writeText(description).then(() => {
              showToast('Invite link copied!');
              modal.remove();
            });
          };
        } else {
          btn.onclick = () => {
            window.open(option.url, '_blank', 'width=600,height=400');
            modal.remove();
          };
        }
        optionsContainer.appendChild(btn);
      });
      
      modalContent.appendChild(optionsContainer);
      
      const closeBtn = document.createElement('button');
      closeBtn.textContent = 'Close';
      closeBtn.style.cssText = `
        width: 100%;
        padding: 12px 16px;
        background: rgba(44, 92, 240, 0.2);
        color: rgba(205, 219, 255, 0.85);
        border: 1px solid rgba(44, 92, 240, 0.3);
        border-radius: 8px;
        font-family: 'Poppins', sans-serif;
        font-weight: 600;
        cursor: pointer;
        transition: all 0.3s ease;
        font-size: 0.95rem;
      `;
      closeBtn.onmouseover = () => {
        closeBtn.style.background = 'rgba(44, 92, 240, 0.3)';
      };
      closeBtn.onmouseout = () => {
        closeBtn.style.background = 'rgba(44, 92, 240, 0.2)';
      };
      closeBtn.onclick = () => modal.remove();
      modalContent.appendChild(closeBtn);
      
      modal.appendChild(modalContent);
      modal.onclick = (e) => {
        if (e.target === modal) modal.remove();
      };
      
      document.body.appendChild(modal);
    }

    document.addEventListener('DOMContentLoaded', function() {
      console.log('DOM loaded, testing elements...');
      console.log('Invite code element exists:', !!document.getElementById('referralCode'));
      console.log('Copy toast exists:', !!document.getElementById('copyToast'));
      console.log('Copy buttons exist:', document.querySelectorAll('.btn-copy').length);
    });
  </script>
</body>
</html>
