<?php
ob_start();

require_once 'config/database.php';
require_once 'config/korapay.php';
require_once 'includes/session.php';
require_once 'includes/connect.php';

// Require authentication
requireLogin();
checkSessionTimeout();

// Get current user data
$user = getCurrentUser();
$user_id = $user['id'];

// Detect AJAX request
$isAjax =
    (!empty($_POST['ajax']) && $_POST['ajax']) ||
    (isset($_SERVER['HTTP_X_REQUESTED_WITH']) &&
     strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest');

// Check if user agreed to post-task terms
$post_agreed = isset($_SESSION['post_agreed_' . $user_id]) ? $_SESSION['post_agreed_' . $user_id] : false;

// Handle AJAX requests for agree_terms
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $isAjax && isset($_POST['action']) && $_POST['action'] === 'agree_terms') {
    ob_end_clean();
    header('Content-Type: application/json; charset=utf-8');
    $_SESSION['post_agreed_' . $user_id] = true;
    echo json_encode(['success' => true, 'message' => 'Post Task Instructions agreed']);
    exit;
}

// Handle Korapay redirect callback (checkout_url redirects here after payment)
// Korapay sends back: ?reference=EARNOVA-xxx&status=success (or failed)
$korapay_message = '';
$korapay_message_type = '';

if (isset($_GET['reference'])) {
    $reference = $_GET['reference'];
    
    // Check if this is a Korapay reference (format: EARNOVA-TASK-xxx)
    if (strpos($reference, 'EARNOVA-TASK-') === 0) {
        error_log("Korapay redirect callback received - Reference: $reference");
        
        try {
            $pdo = getDBConnection();
            $kp_verify = verifyKorapayCharge($reference);
            error_log("Korapay verify response: " . json_encode($kp_verify));
            
            // Check if charge was successful
            $is_success = false;
            $kp_data = $kp_verify['data'] ?? [];
            
            if (!empty($kp_verify['status']) && $kp_verify['status'] === true) {
                if (isset($kp_data['status']) && $kp_data['status'] === 'success') {
                    $is_success = true;
                }
            }
            
            if ($is_success) {
                // Record the payment (webhook may not have fired yet)
                $amount = floatval($kp_data['amount'] ?? 0);
                $metadata = $kp_data['metadata'] ?? [];
                // If Korapay metadata used the packed 'payload' key, decode it here
                if (!empty($metadata['payload'])) {
                  $decoded = json_decode($metadata['payload'], true);
                  if (is_array($decoded)) {
                    $metadata = array_merge($metadata, $decoded);
                  }
                }
                // If still missing detailed task fields, attempt to fetch server-side stored payload by reference
                if (empty($metadata['title']) || empty($metadata['task_url'])) {
                  try {
                    $stmt2 = $pdo->prepare("SELECT payload FROM korapay_post_task_payloads WHERE reference = ? LIMIT 1");
                    $stmt2->execute([$reference]);
                    $row = $stmt2->fetch();
                    if ($row && !empty($row['payload'])) {
                      $fetched = json_decode($row['payload'], true);
                      if (is_array($fetched)) {
                        $metadata = array_merge($metadata, $fetched);
                      }
                    }
                  } catch (Exception $e) {
                    error_log('KORAPAY_PAYLOAD_FETCH_ERROR (callback): ' . $e->getMessage());
                  }
                }
                
                // Check if already recorded
                $stmt = $pdo->prepare("SELECT id FROM korapay_post_task_payments WHERE reference = ? LIMIT 1");
                $stmt->execute([$reference]);
                $existing = $stmt->fetch();
                
                if (!$existing && $amount > 0) {
                    // Record payment
                    $stmt = $pdo->prepare("
                        INSERT INTO korapay_post_task_payments 
                        (user_id, reference, amount, status, metadata, created_at) 
                        VALUES (?, ?, ?, 'success', ?, NOW())
                    ");
                    $metadata_json = json_encode($metadata);
                    $stmt->execute([$user_id, $reference, $amount, $metadata_json]);
                    
                    // Add to user total balance only (do not credit referral earnings)
                    $stmt = $pdo->prepare("
                      UPDATE balances 
                      SET total_balance = total_balance + ?
                      WHERE user_id = ?
                    ");
                    $stmt->execute([$amount, $user_id]);

                    // Record transaction against total balance
                    $stmt = $pdo->prepare("
                      INSERT INTO transactions 
                      (user_id, transaction_type, amount, balance_type, description, reference_id, created_at) 
                      VALUES (?, ?, ?, ?, ?, ?, NOW())
                    ");
                    $desc = "Korapay Deposit for Post Task - Ref: " . $reference;
                    $stmt->execute([$user_id, 'korapay_deposit_post_task', $amount, 'total_balance', $desc, $reference]);
                }
                
                  // If metadata contains task details, try to auto-create the task (idempotent)
                  $task_created = false;
                  try {
                    if (!empty($metadata['title']) && !empty($metadata['task_url'])) {
                      $task_title = trim($metadata['title']);
                      $task_desc = trim($metadata['description'] ?? '');
                      $task_platform = trim($metadata['task_platform'] ?? ($metadata['platform'] ?? ''));
                      $task_url = trim($metadata['task_url']);
                      $participants = max(10, intval($metadata['participants'] ?? 10));
                      $total_cost_val = floatval($metadata['total_cost'] ?? $amount);

                      // Check for existing similar task posted recently to avoid duplicates
                      $chk = $pdo->prepare("SELECT id FROM tasks WHERE task_url = ? AND user_id = ? AND created_at >= DATE_SUB(NOW(), INTERVAL 10 MINUTE) LIMIT 1");
                      $chk->execute([$task_url, $user_id]);
                      $exists_task = $chk->fetch();

                      if (!$exists_task) {
                        $reward_total = $total_cost_val * 0.06;
                        $reward_per_user = ($participants > 0) ? ($reward_total / $participants) : 0;

                        $stmt = $pdo->prepare("INSERT INTO tasks (title, description, task_type, platform, reward_amount, task_url, participants_count, is_active, is_premium_only, created_at, user_id, posted_by_username, posted_by_fullname) VALUES (?, ?, 'social_media', ?, ?, ?, ?, 1, 0, NOW(), ?, ?, ?)");
                        $stmt->execute([$task_title, $task_desc, $task_platform, $reward_per_user, $task_url, $participants, $user_id, $user_data['username'] ?? '', $user_data['fullname'] ?? '']);
                        $task_id = $pdo->lastInsertId();

                        // Ensure tasks table has a korapay_reference column and store the reference for exact matching later
                        try {
                          $pdo->exec("ALTER TABLE tasks ADD COLUMN IF NOT EXISTS korapay_reference VARCHAR(200) DEFAULT NULL");
                          $upd = $pdo->prepare("UPDATE tasks SET korapay_reference = ? WHERE id = ?");
                          $upd->execute([$reference, $task_id]);
                        } catch (Exception $e) {
                          error_log('KORAPAY_TASK_REF_UPDATE_ERROR: ' . $e->getMessage());
                        }

                        // Create advertisement record
                        $stmt = $pdo->prepare("INSERT INTO advertisements (user_id, title, description, ad_type, target_url, budget, cost_per_action, total_actions, remaining_budget, is_active, created_at) VALUES (?, ?, ?, 'social_media', ?, ?, ?, 0, ?, 1, NOW())");
                        $stmt->execute([$user_id, $task_title, $task_desc, $task_url, $total_cost_val, $reward_per_user, $total_cost_val]);

                        // Handle upline commission (5% to senior referrer)
                        $stmt = $pdo->prepare("SELECT referred_by FROM users WHERE id = ?");
                        $stmt->execute([$user_id]);
                        $upline_result = $stmt->fetch();
                        if ($upline_result && !empty($upline_result['referred_by'])) {
                          $upline_id = $upline_result['referred_by'];
                          $stmt = $pdo->prepare("SELECT u.advertiser_plan, b.referral_earnings FROM users u LEFT JOIN balances b ON u.id = b.user_id WHERE u.id = ?");
                          $stmt->execute([$upline_id]);
                          $upline_data = $stmt->fetch();
                          if ($upline_data && $upline_data['advertiser_plan'] === 'senior') {
                            $upline_reward = ($total_cost_val * 0.05);
                            $stmt = $pdo->prepare("UPDATE balances SET referral_earnings = referral_earnings + ?, total_balance = total_balance + ? WHERE user_id = ?");
                            $stmt->execute([$upline_reward, $upline_reward, $upline_id]);

                            $stmt = $pdo->prepare("INSERT INTO transactions (user_id, transaction_type, amount, balance_type, description, reference_id, created_at) VALUES (?, ?, ?, ?, ?, ?, NOW())");
                            $reward_description = "5% Advertisement Commission - Downline task posting (₦{$total_cost_val}) on {$task_platform}";
                            $stmt->execute([$upline_id, 'advertise_commission', $upline_reward, 'referral_earnings', $reward_description, "UPLINE-AD-COMM-{$task_id}"]);

                            $commission_percentage = 5.00;
                            $stmt2 = $pdo->prepare("INSERT INTO ad_invite_commissions (referrer_id, referred_user_id, ad_purchase_amount, commission_amount, commission_percentage, created_at) VALUES (?, ?, ?, ?, ?, NOW())");
                            $stmt2->execute([$upline_id, $user_id, $total_cost_val, $upline_reward, $commission_percentage]);
                          }
                        }

                        $task_created = true;
                      } else {
                        $task_created = true; // it already exists
                      }
                    }
                  } catch (Exception $e) {
                    error_log('Auto-create task after Korapay callback failed: ' . $e->getMessage());
                  }

                  if ($task_created) {
                    $korapay_message = "Task posted successfully!";
                  } else {
                    $korapay_message = "Payment successful! Your balance has been updated.";
                  }
                  $korapay_message_type = 'success';

                  // Prevent reuse of the stored payload for this reference (idempotency)
                  try {
                    $stmt_del = $pdo->prepare("DELETE FROM korapay_post_task_payloads WHERE reference = ?");
                    $stmt_del->execute([$reference]);
                  } catch (Exception $e) {
                    error_log('KORAPAY_PAYLOAD_DELETE_ERROR: ' . $e->getMessage());
                  }

                  // If this was requested via AJAX, return JSON; otherwise use PRG to clear the URL
                  if ($isAjax) {
                    ob_end_clean();
                    header('Content-Type: application/json; charset=utf-8');
                    echo json_encode(['success' => true, 'message' => $korapay_message]);
                    exit;
                  }

                  // Store message in session and redirect to the same page to clear GET params
                  $_SESSION['post_task_msg'] = $korapay_message;
                  $_SESSION['post_task_msg_type'] = $korapay_message_type;
                  header('Location: post-task.php');
                  exit();
            } else {
                error_log("Korapay charge verification failed");
                $korapay_message = "Payment verification failed. Please try again.";
                $korapay_message_type = 'error';
            }
        } catch (Exception $e) {
            error_log('Korapay verification exception: ' . $e->getMessage());
            $korapay_message = "Payment verification error. Please contact support.";
            $korapay_message_type = 'error';
        }
    }
}

try {
    $pdo = getDBConnection();
    
    // Fetch user details with balances
    $stmt = $pdo->prepare("SELECT u.*, b.total_balance, b.task_earnings, b.referral_earnings FROM users u LEFT JOIN balances b ON u.id = b.user_id WHERE u.id = ?");
    $stmt->execute([$user_id]);
    $user_data = $stmt->fetch();
    
    if (!$user_data) {
        header('Location: login.php');
        exit;
    }
    
    $is_senior = ($user_data['advertiser_plan'] === 'senior');
    
   
    $platform_prices = [
        'tiktok' => ['name' => 'TikTok', 'price' => 320],
        'instagram' => ['name' => 'Instagram', 'price' => 350],
        'whatsapp' => ['name' => 'WhatsApp', 'price' => 320],
        'playstore' => ['name' => 'PlayStore', 'price' => 700],
        'appstore' => ['name' => 'AppStore', 'price' => 800],
        'telegram' => ['name' => 'Telegram', 'price' => 320],
        'twitter' => ['name' => 'Twitter/X', 'price' => 380],
        'facebook' => ['name' => 'Facebook', 'price' => 350],
        'linkedin' => ['name' => 'LinkedIn', 'price' => 350],
        'snapchat' => ['name' => 'Snapchat', 'price' => 340],
        'youtube' => ['name' => 'YouTube', 'price' => 400],
        'pinterest' => ['name' => 'Pinterest', 'price' => 350],
        'reddit' => ['name' => 'Reddit', 'price' => 350],
        'discord' => ['name' => 'Discord', 'price' => 300],
        'twitch' => ['name' => 'Twitch', 'price' => 400],
        'audiomack' => ['name' => 'Audiomack', 'price' => 300],
        'boomplay' => ['name' => 'Boomplay', 'price' => 450],
        'spotify' => ['name' => 'Spotify', 'price' => 400],
        'applemusic' => ['name' => 'Apple Music', 'price' => 400],
        'soundcloud' => ['name' => 'SoundCloud', 'price' => 450],
        'website' => ['name' => 'Website', 'price' => 500]
    ];
    
     $platform_url_patterns = [
        'tiktok' => ['tiktok.com', 'vm.tiktok.com'],
        'instagram' => ['instagram.com', 'instagr.am'],
        'whatsapp' => ['whatsapp.com', 'wa.me', 'wa.link', 'chat.whatsapp.com'],
        'playstore' => ['play.google.com'],
        'appstore' => ['apps.apple.com', 'itunes.apple.com'],
        'telegram' => ['t.me', 'telegram.me', 'telegram.org', 'tg://', 'tg:'],
        'twitter' => ['twitter.com', 'x.com'],
        'facebook' => ['facebook.com', 'fb.com', 'fb.me'],
        'linkedin' => ['linkedin.com'],
        'snapchat' => ['snapchat.com'],
        'youtube' => ['youtube.com', 'youtu.be'],
        'pinterest' => ['pinterest.com', 'pin.it'],
        'reddit' => ['reddit.com', 'redd.it'],
        'discord' => ['discord.com', 'discord.gg'],
        'twitch' => ['twitch.tv'],
        'audiomack' => ['audiomack.com'],
        'boomplay' => ['boomplay.com'],
        'spotify' => ['spotify.com', 'open.spotify.com'],
        'applemusic' => ['music.apple.com'],
        'soundcloud' => ['soundcloud.com'],
        'website' => ['http', 'https']
    ];
    
    // Removed is_member variable, as it's no longer needed with the new pricing structure. Senior members automatically get the set prices.
    
    // Handle form submission
    $message = '';
    $messageType = '';
    
    function validatePlatformUrl($url, $platform, $patterns) {
        $url_lower = strtolower($url);
        if (!isset($patterns[$platform])) {
            return false;
        }
        
        foreach ($patterns[$platform] as $pattern) {
            if (strpos($url_lower, $pattern) !== false) {
                return true;
            }
        }
        return false;
    }
    
    function validateDescriptionWordCount($description) {
        $word_count = str_word_count($description);
        return $word_count <= 100;
    }
    
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'post_task') {
        $title = trim($_POST['title'] ?? '');
        $description = trim($_POST['description'] ?? '');
        $platform = $_POST['platform'] ?? '';
        $task_url = trim($_POST['task_url'] ?? '');
        $participants = intval($_POST['participants'] ?? 10);
        $payment_source = $_POST['payment_source'] ?? 'task';
        $payment_reference = trim($_POST['payment_reference'] ?? '');
        
        // Validation
        if (empty($title) || empty($description) || empty($platform) || empty($task_url)) {
            $message = 'Please fill in all required fields';
            $messageType = 'error';
        } elseif (!filter_var($task_url, FILTER_VALIDATE_URL)) {
            $message = 'Please provide a valid URL';
            $messageType = 'error';
        } elseif (!isset($platform_prices[$platform])) {
            $message = 'Invalid platform selected';
            $messageType = 'error';
        } elseif (!validatePlatformUrl($task_url, $platform, $platform_url_patterns)) {
            $message = 'Task URL does not match selected platform.';
            $messageType = 'error';
        } elseif ($participants < 10 || $participants > 10000) {
            $message = 'Participants must be between 10 and 1000';
            $messageType = 'error';
        } elseif (!validateDescriptionWordCount($description)) {
            $message = 'Description must not exceed 100 words';
            $messageType = 'error';
        } else {
            $base_price = $platform_prices[$platform]['price'];
            $total_cost = ($participants / 10) * $base_price;
            
            // Check if user has sufficient balance (or if payment is via Paystack)
            $available_balance = $user_data['referral_earnings'];
            
            if ($payment_source !== 'paystack' && $available_balance < $total_cost) {
                $message = 'Insufficient balance. You need ₦' . number_format($total_cost, 2);
                $messageType = 'error';
            } else {
                // Begin transaction
                $pdo->beginTransaction();
                
                try {
                    $stmt = $pdo->prepare("INSERT INTO tasks (title, description, task_type, platform, reward_amount, task_url, participants_count, is_active, is_premium_only, created_at, user_id, posted_by_username, posted_by_fullname) VALUES (?, ?, 'social_media', ?, ?, ?, ?, 1, 0, NOW(), ?, ?, ?)");
                    $reward_total = $total_cost * 0.06;          // 6% of total cost
                    $reward_per_user = $reward_total / $participants; 
                    
                     $stmt->execute([$title, $description, $platform, $reward_per_user, $task_url, $participants, $user_id, $user_data['username'], $user_data['fullname']]);
                    $task_id = $pdo->lastInsertId();
                    
                    // Deduct from user's balance if not Paystack payment
                    if ($payment_source !== 'paystack') {
                        $stmt = $pdo->prepare("UPDATE balances SET referral_earnings = referral_earnings - ? WHERE user_id = ?");
                        $stmt->execute([$total_cost, $user_id]);
                    }
                    
                    // Record transaction for the ad purchase
                    $transaction_type = ($payment_source === 'paystack') ? 'ad_purchase_via_paystack' : 'ad_purchase';
                    $balance_type_for_purchase = ($payment_source === 'paystack') ? 'external' : 'prime_earnings';
                    $stmt = $pdo->prepare("INSERT INTO transactions (user_id, transaction_type, amount, balance_type, description, reference_id, created_at) VALUES (?, ?, ?, ?, ?, ?, NOW())");
                    $description_text = "Posted task: {$title} on {$platform_prices[$platform]['name']} for {$participants} participants";
                    $stmt->execute([$user_id, $transaction_type, $total_cost, $balance_type_for_purchase, $description_text, $payment_reference ?: "TASK-{$task_id}"]);

                    // If payment came from Paystack, also insert a companion deposit record so admin/track-deposit.php counts it
                    if ($payment_source === 'paystack') {
                      try {
                        $deposit_ref = $payment_reference ?: "TASK-{$task_id}";
                        $stmt2 = $pdo->prepare("INSERT INTO transactions (user_id, transaction_type, amount, balance_type, description, reference_id, created_at) VALUES (?, 'deposit', ?, ?, ?, ?, NOW())");
                        $deposit_description = 'Paystack deposit for task posting';
                        $stmt2->execute([$user_id, $total_cost, 'external', $deposit_description, $deposit_ref]);
                      } catch (Exception $e) {
                        error_log('Post-task: Failed to insert companion deposit record: ' . $e->getMessage());
                      }
                    }
                    
                    // Create advertisement record
                    $stmt = $pdo->prepare("INSERT INTO advertisements (user_id, title, description, ad_type, target_url, budget, cost_per_action, total_actions, remaining_budget, is_active, created_at) VALUES (?, ?, ?, 'social_media', ?, ?, ?, 0, ?, 1, NOW())");
                    $stmt->execute([$user_id, $title, $description, $task_url, $total_cost, $reward_per_user, $total_cost]);
                    
                    $stmt = $pdo->prepare("SELECT referred_by FROM users WHERE id = ?");
                    $stmt->execute([$user_id]);
                    $upline_result = $stmt->fetch();
                    
                    if ($upline_result && $upline_result['referred_by']) {
                        $upline_id = $upline_result['referred_by'];
                        
                        // Check if upline is also senior
                        $stmt = $pdo->prepare("SELECT u.advertiser_plan, b.referral_earnings FROM users u LEFT JOIN balances b ON u.id = b.user_id WHERE u.id = ?");
                        $stmt->execute([$upline_id]);
                        $upline_data = $stmt->fetch();
                        
                        // If upline is senior, award 5% of the task posting amount
                        if ($upline_data && $upline_data['advertiser_plan'] === 'senior') {
                            $upline_reward = ($total_cost * 0.05); // 5% commission
                            $stmt = $pdo->prepare("UPDATE balances SET referral_earnings = referral_earnings + ?, total_balance = total_balance + ? WHERE user_id = ?");
                            $stmt->execute([$upline_reward, $upline_reward, $upline_id]);
                            
                            $stmt = $pdo->prepare("INSERT INTO transactions (user_id, transaction_type, amount, balance_type, description, reference_id, created_at) VALUES (?, ?, ?, ?, ?, ?, NOW())");
                            $reward_description = "5% Advertisement Commission - Downline task posting (₦{$total_cost}) on {$platform_prices[$platform]['name']}";
                            $stmt->execute([$upline_id, 'advertise_commission', $upline_reward, 'referral_earnings', $reward_description, "UPLINE-AD-COMM-{$task_id}"]);
                            // Record the upline commission in ad_invite_commissions for admin visibility
                            $commission_percentage = 5.00;
                            $stmt2 = $pdo->prepare("INSERT INTO ad_invite_commissions (referrer_id, referred_user_id, ad_purchase_amount, commission_amount, commission_percentage, created_at) VALUES (?, ?, ?, ?, ?, NOW())");
                            $stmt2->execute([$upline_id, $user_id, $total_cost, $upline_reward, $commission_percentage]);
                        }
                    }
                    
                    $pdo->commit();

                    // Increase fake_total_tasks by 1
                    $stmt = $pdo->prepare("
                      UPDATE task_display_settings 
                      SET setting_value = setting_value + 1
                      WHERE setting_key = 'fake_total_tasks'
                    ");
                    $stmt->execute();

                    // Use Post-Redirect-Get to avoid duplicate submissions. Return JSON for AJAX.
                    if ($isAjax) {
                      ob_end_clean();
                      header('Content-Type: application/json; charset=utf-8');
                      echo json_encode(['success' => true, 'message' => 'Task posted successfully!']);
                      exit;
                    }

                    $_SESSION['post_task_msg'] = 'Task posted successfully!';
                    $_SESSION['post_task_msg_type'] = 'success';
                    header('Location: post-task.php');
                    exit();
                    
                    // Refresh user data
                    $stmt = $pdo->prepare("SELECT u.*, b.total_balance, b.task_earnings, b.referral_earnings FROM users u LEFT JOIN balances b ON u.id = b.user_id WHERE u.id = ?");
                    $stmt->execute([$user_id]);
                    $user_data = $stmt->fetch();
                    
                } catch (Exception $e) {
                    $pdo->rollBack();
                    $message = 'Failed to post task. Please try again.';
                    $messageType = 'error';
                    error_log("Post task error: " . $e->getMessage());
                }
            }
        }
    }
    
} catch (PDOException $e) {
    error_log("Post Task Error: " . $e->getMessage());
    $error_message = "Unable to load page data.";
}

$username = htmlspecialchars($user_data['username'] ?? 'User');
// Updated membership status to always reflect Senior Advertiser since the locked page handles non-seniors.
$membership_status = 'Senior Advertiser'; 
?>
<?php include "doctype.php"; ?>
  <link rel="stylesheet" href="social.css" />
   <!-- Added gamified fintech theme CSS -->
  <link rel="stylesheet" href="assets/css/gamified-fintech-theme.css" />
  <!-- Added Paystack inline script -->
  <script src="https://js.paystack.co/v1/inline.js"></script>
</head>
 <!-- Added theme class to body for dark/light mode -->
<body>

<?php include "embed.php"; ?>

<?php if (!empty($_SESSION['post_task_msg'])): ?>
  <div id="alert-toast" class="alert-message alert-<?php echo htmlspecialchars($_SESSION['post_task_msg_type']); ?>">
    <?php echo htmlspecialchars($_SESSION['post_task_msg']); ?>
  </div>
  <?php unset($_SESSION['post_task_msg'], $_SESSION['post_task_msg_type']); ?>
<?php elseif ($message): ?>
  <div id="alert-toast" class="alert-message alert-<?php echo $messageType; ?>">
    <?php echo htmlspecialchars($message); ?>
  </div>
<?php endif; ?>

<?php if ($korapay_message): ?>
  <div id="korapay-alert-toast" class="alert-message alert-<?php echo $korapay_message_type; ?>">
    <?php echo htmlspecialchars($korapay_message); ?>
  </div>
<?php endif; ?>

<style>
/* Toast Base Style */

body {
    background: var(--bg-primary);
}
.alert-message {
  position: fixed;
  top: 20px;
  right: -400px; /* start hidden off-screen */
  padding: 16px 24px;
  border-radius: 12px;
  font-family: 'Segoe UI', sans-serif;
  font-size: 15px;
  z-index: 1000;
  opacity: 0;
  box-shadow: 0 10px 40px rgba(0, 0, 0, 0.2);
  transition: right 0.6s ease, opacity 0.6s ease;
  color: #fff;
}

/* Success */
.alert-success {
  background: rgba(77, 225, 193, 0.95);
  color: #030922;
  box-shadow: 0 10px 40px rgba(77, 225, 193, 0.4);
}

/* Error */
.alert-error {
  background: rgba(255, 77, 77, 0.95);
  color: #fff;
  box-shadow: 0 10px 40px rgba(255, 77, 77, 0.4);
}

/* Info */
.alert-info {
  background: rgba(77, 136, 225, 0.95);
  color: #fff;
  box-shadow: 0 10px 40px rgba(77, 136, 225, 0.4);
}

/* Warning */
.alert-warning {
  background: rgba(255, 187, 77, 0.95);
  color: #000;
  box-shadow: 0 10px 40px rgba(255, 187, 77, 0.4);
}

/* Active State */
.alert-message.show {
  right: 20px;
  opacity: 1;
}

/* Word counter styling */
.word-count-container {
  margin-top: 8px;
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.word-counter {
  font-size: 0.9rem;
  color: rgba(245, 249, 255, 0.7);
  font-weight: 600;
}

.word-counter.warning {
  color: #FFB84D;
}

.word-counter.error {
  color: #FF6B6B;
}

/* Post Task Terms Modal Styles - Matching perform-task.php exactly */
.ts-modal {
  display: none;
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(3, 9, 34, 0.9);
  backdrop-filter: blur(8px);
  z-index: 2500;
  align-items: center;
  justify-content: center;
  padding: 20px;
  z-index: 99999;
}

.ts-modal.active {
  display: flex;
}

.ts-modal-content {
  background: rgba(6, 16, 48, 0.98);
  border: 1px solid rgba(100, 154, 255, 0.3);
  border-radius: 24px;
  padding: 32px;
  max-width: 600px;
  width: 100%;
  max-height: 80vh;
  overflow-y: auto;
  display: flex;
  flex-direction: column;
}

.ts-modal-header {
  margin-bottom: 24px;
  border-bottom: 1px solid rgba(100, 154, 255, 0.2);
  padding-bottom: 16px;
}

.ts-modal-header h2 {
  margin: 0;
  font-size: 1.5rem;
  color: var(--page-white, #f5f9ff);
}

.ts-modal-body {
  flex: 1;
  overflow-y: auto;
  margin-right: 8px;
  padding-right: 8px;
}

.ts-modal-body::-webkit-scrollbar {
  width: 6px;
}

.ts-modal-body::-webkit-scrollbar-track {
  background: rgba(100, 154, 255, 0.1);
  border-radius: 3px;
}

.ts-modal-body::-webkit-scrollbar-thumb {
  background: rgba(77, 225, 193, 0.3);
  border-radius: 3px;
}

.ts-modal-body::-webkit-scrollbar-thumb:hover {
  background: rgba(77, 225, 193, 0.5);
}

.ts-modal-body h3 {
  color: var(--page-white, #f5f9ff);
  margin-top: 20px;
  margin-bottom: 12px;
  font-size: 1.1rem;
}

.ts-modal-body p {
  color: rgba(205, 219, 255, 0.8);
  line-height: 1.6;
  margin-bottom: 12px;
  font-size: 0.95rem;
}

.ts-modal-body ul {
  color: rgba(205, 219, 255, 0.8);
  line-height: 1.6;
  margin-bottom: 12px;
  margin-left: 20px;
  font-size: 0.95rem;
}

.ts-modal-body li {
  margin-bottom: 8px;
}

.ts-modal-footer {
  display: flex;
  gap: 12px;
  justify-content: flex-end;
  align-items: center;
  border-top: 1px solid rgba(100, 154, 255, 0.2);
  padding-top: 20px;
}

.ts-checkbox-container {
  display: flex;
  align-items: center;
  gap: 8px;
}

.ts-checkbox {
  width: 20px;
  height: 20px;
  cursor: pointer;
  accent-color: var(--page-mint, #4de1c1);
}

.ts-checkbox-label {
  color: rgba(205, 219, 255, 0.8);
  font-size: 0.9rem;
  cursor: pointer;
}

.ts-modal-actions {
  display: flex;
  gap: 12px;
  justify-content: flex-end;
}

.ts-checkbox-wrapper {
  background: rgba(77, 225, 193, 0.08);
  border: 1px solid rgba(77, 225, 193, 0.3);
  border-radius: 12px;
  padding: 16px;
  margin-bottom: 24px;
  display: flex;
  align-items: center;
  gap: 12px;
}

.ts-checkbox-wrapper input[type="checkbox"]:disabled {
  opacity: 0.5;
  cursor: not-allowed;
}

.ts-checkbox-wrapper input[type="checkbox"]:disabled + label {
  opacity: 0.5;
  cursor: not-allowed;
}
</style>

<script>
document.addEventListener("DOMContentLoaded", () => {
  const alertToast = document.getElementById("alert-toast");
  if (alertToast) {
    setTimeout(() => alertToast.classList.add("show"), 100);   // slide in
    setTimeout(() => alertToast.classList.remove("show"), 4000); // auto hide
  }
  
  const korapayAlertToast = document.getElementById("korapay-alert-toast");
  if (korapayAlertToast) {
    setTimeout(() => korapayAlertToast.classList.add("show"), 100);   // slide in
    setTimeout(() => korapayAlertToast.classList.remove("show"), 4000); // auto hide
  }
});
</script>

<?php include "header2.php"; ?>

  <!-- Post Task Terms & Instructions Modal -->
  <div class="ts-modal" id="tsModal">
    <div class="ts-modal-content">
      <div class="ts-modal-header">
        <h2>Post Task Instructions</h2>
      </div>
      <div class="ts-modal-body">
        <p><strong>Earnova Digital – 2025 Post Task Guidelines</strong></p>

        <h3>1. Introduction</h3>
        <p>Welcome to our Advert Posting Platform. By using the Post Advert feature, you understand and accept that all adverts are automatically approved the moment they are submitted. Our system publishes your advert instantly so it can begin reaching users without delay.</p>
        <p>However, we may still manually review, remove, or edit any advert that violates our rules or legal requirements.</p>

        <h3>2. Advertiser Responsibilities</h3>
        <p>As an advertiser, you are responsible for:</p>
        <ul>
          <li>Providing accurate and truthful task information</li>
          <li>Ensuring your task URL is valid and accessible</li>
          <li>Not posting misleading or deceptive tasks</li>
          <li>Maintaining sufficient balance for task payments</li>
          <li>Complying with platform guidelines and policies</li>
        </ul>

        <h3>3. Task Posting Requirements</h3>
        <p>When posting tasks:</p>
        <ul>
          <li>Task titles must be clear and descriptive (max 45 characters)</li>
          <li>Task descriptions must accurately explain what users need to do</li>
          <li>Task URLs must match the selected platform</li>
          <li>Minimum participants is 10, maximum is 1000</li>
          <li>Tasks must not violate any platform policies</li>
        </ul>

        <h3>4. Payment and Billing</h3>
        <p>Task posting payments are handled as follows:</p>
        <ul>
          <li>Payment is deducted from your Prime Wallet or via Paystack</li>
          <li>Prices vary by platform and number of participants</li>
          <li>All payments are non-refundable once task is posted</li>
          <li>Senior advertisers may receive special pricing benefits</li>
        </ul>

        <h3>5. Prohibited Content</h3>
        <p>You agree not to post tasks that:</p>
        <ul>
          <li>Promote illegal activities or content</li>
          <li>Contain adult, violent, or offensive material</li>
          <li>Violate intellectual property rights</li>
          <li>Spread misinformation or fake news</li>
          <li>Engage in fraudulent or deceptive practices</li>
          <li>Violate the terms of external platforms</li>
        </ul>

        <h3>6. Task Moderation</h3>
        <p>We reserve the right to:</p>
        <ul>
          <li>Review and approve/reject task submissions</li>
          <li>Remove tasks that violate our policies</li>
          <li>Suspend accounts for policy violations</li>
          <li>Modify or cancel tasks without prior notice</li>
        </ul>

        <h3>7. Liability Disclaimer</h3>
        <p>The platform is provided "as is" without warranties. We are not liable for:</p>
        <ul>
          <li>Results or performance of posted tasks</li>
          <li>Actions of task performers</li>
          <li>Technical issues or platform downtime</li>
          <li>External platform policy changes</li>
        </ul>

        <h3>8. Changes to Terms</h3>
        <p>We reserve the right to modify these terms at any time. Your continued use of the platform constitutes acceptance of any changes.</p>

        <h3>9. Contact Information</h3>
        <p>For questions or concerns, please contact our support team through the help section of your account.</p>
      </div>
      <div class="ts-modal-footer">
        <div class="ts-checkbox-wrapper" style="margin-bottom: 0;">
          <input type="checkbox" id="tsCheckbox" class="ts-checkbox" <?php echo $post_agreed ? 'checked disabled' : ''; ?>>
          <label for="tsCheckbox" class="ts-checkbox-label"><span style="font-size: 13px;">I agree</span></label>
        </div>
        <div class="ts-modal-actions">
          <button class="btn-secondary" id="tsCloseBtn" onclick="closeTSModal()" style="<?php echo $post_agreed ? 'display: block;' : 'display: none;'; ?>">Close</button>
          <button class="btn-primary" id="tsAgreeBtn" onclick="agreeTSAndClose()" style="<?php echo $post_agreed ? 'display: none;' : 'display: block;'; ?>">Agree & Continue</button>
        </div>
      </div>
    </div>
  </div>

  <div class="page-shell">
   
    
    <main>
     

      <section class="hero-section" style="background: linear-gradient(135deg, rgba(77, 225, 193, 0.08), rgba(13, 24, 62, 0.78));">
        <div class="hero-content">
          <h1 style="font-size: 18px;">Publish Balance</h1>
<p>Choose your campaign, set the amount, and reach your target users efficiently.</p>

        </div>
        <div class="balance-display">
          <div class="balance-item">
            <span class="balance-label">Prime Wallet</span>
            <span class="balance-amount">₦<?php echo number_format($user_data['referral_earnings'], 2); ?></span>
          </div>
        </div>
        <!-- Added clickable checkbox to view post task instructions -->
        <div style="background: rgba(77, 225, 193, 0.08); border: 1px solid rgba(77, 225, 193, 0.3); border-radius: 12px; padding: 16px; margin-top: 16px; display: flex; align-items: center; gap: 12px; cursor: pointer;" onclick="openTSModal()">
          <input type="checkbox" id="postHeroCheckbox" style="width: 20px; height: 20px; cursor: pointer; accent-color: var(--page-mint, #4de1c1);" onclick="event.stopPropagation(); openTSModal();">
          <label for="postHeroCheckbox" style="color: rgba(205, 219, 255, 0.8); font-size: 0.9rem; cursor: pointer; margin: 0;">View Post Task Instructions</label>
        </div>
      </section>

      <section class="form-section">
        <form method="POST" class="task-form" id="taskForm">
          <input type="hidden" name="action" value="post_task">
          
           <div class="form-group">
            <!-- Add maxlength and character counter for title field (45 characters max) -->
            <label for="title">Task Title * (Max 45 Characters)</label>
            <input type="text" id="title" name="title" required placeholder="e.g., Follow my Instagram account" maxlength="45">
            <div class="word-count-container">
              <span class="word-counter" id="titleCounter">0 / 45</span>
            </div>
          </div>

          <div class="form-group">
            <!-- Added word counter display below description field -->
            <label for="description">Task Description * (Max 100 Words)</label>
            <textarea id="description" name="description" required rows="4" placeholder="Describe what users need to do to complete this task..."></textarea>
            <div class="word-count-container">
              <span class="word-counter" id="wordCounter">0 / 100</span>
            </div>
          </div>

          <div class="form-group">
            <label for="platform">Select Platform *</label>
            <select id="platform" name="platform" required onchange="updatePricing()">
              <option value="">-- Choose Platform --</option>
              <?php foreach ($platform_prices as $key => $platform): ?>
                <option value="<?php echo $key; ?>" data-price="<?php echo $platform['price']; ?>">
                  <?php echo $platform['name']; ?> (₦<?php echo number_format($platform['price']); ?>/10 participants)
                </option>
              <?php endforeach; ?>
            </select>
          </div>

          <div class="form-group">
            <label for="task_url">Task URL *</label>
            <input type="url" id="task_url" name="task_url" required placeholder="https://platform.com/yourprofile">
            <small>Provide the link where users will complete the task</small>
          </div>

          <div class="form-group">
            <label for="participants">Number of Participants *</label>
            <!-- Updated step to 1 to allow odd numbers for participants -->
            <input type="number" id="participants" name="participants" value="10" min="10" max="10000" step="1" required onchange="updatePricing()" oninput="updatePricing()">
            <!-- Updated small text to inform users about using odd numbers -->
            <small>Minimum 10, maximum 1000 participants (you can use odd numbers like 11, 12, 16, etc.)</small>
          </div>

          <div class="form-group">
            <label for="payment_source">Payment Source *</label>
            <select id="payment_source" name="payment_source" required>
              <option value="prime_earnings">Prime Wallet (₦<?php echo number_format($user_data['referral_earnings'], 2); ?>)</option>
              <!-- <option value="referral">Referral Earnings (₦<?php //echo number_format($user_data['referral_earnings'], 2); ?>)</option> -->
              <option value="paystack" style="display: none">Deposit via Paystack</option>
              <option value="korapay"  style="display: none">Deposit via Korapay</option>
            </select>
            <div id="payment-note" style="margin-top:6px;"></div>
            <?php $user_prime_earnings = floatval($user_data['referral_earnings'] ?? 0); ?>

            <script>
            (function(){
                // Platform prices from server
                var platformPrices = <?php echo json_encode($platform_prices); ?> || {};
                var userPrime = <?php echo json_encode($user_prime_earnings); ?> || 0;

                function fmt(n){ return new Intl.NumberFormat('en-US', {minimumFractionDigits:2, maximumFractionDigits:2}).format(n); }

                var platformEl = document.querySelector('[name="platform"]');
                var participantsEl = document.querySelector('[name="participants"]');
                var noteContainer = document.getElementById('payment-note');

                function computeTotal(){
                    try{
                        var platform = (platformEl && platformEl.value) ? platformEl.value : null;
                        var participants = participantsEl ? parseInt(participantsEl.value, 10) || 10 : 10;
                        var base = (platform && platformPrices[platform]) ? parseFloat(platformPrices[platform].price) : 0;
                        return (participants / 10) * base;
                    }catch(e){ return 0; }
                }

                function renderNote(){
                    var total = computeTotal();
                    // Insufficient prime earnings => red rectangle with deposit link
                    if (userPrime < total) {
                        noteContainer.innerHTML = ''+
                          '<div style="display:flex;align-items:center;gap:12px;padding:12px;border-radius:8px;background:#FEE2E2;border:1px solid #FCA5A5">'+
                            '<div style="width:40px;height:40px;display:flex;align-items:center;justify-content:center;background:#FCA5A5;border-radius:6px">'+
                              '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">'+
                                '<path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2z" fill="#DC2626"/>'+
                                '<path d="M11 7h2v7h-2zM11 16h2v2h-2z" fill="#FFF"/>'+
                              '</svg>'+
                            '</div>'+
                            '<div style="flex:1;line-height:1.1">'+
                              '<div style="font-weight:700;color:#991B1B">Your Prime earnings balance is low</div>'+
                              '<div style="font-size:13px;color:#7F1D1D">Prime Wallet: ₦'+fmt(userPrime)+' — Required: ₦'+fmt(total)+'. <a href="membership.php" style="color:#7C3AED;font-weight:700;text-decoration:none">Click to deposit funds</a></div>'+
                            '</div>'+
                          '</div>';
                    } else {
                        // Sufficient => green rectangle success
                        noteContainer.innerHTML = ''+
                          '<div style="display:flex;align-items:center;gap:12px;padding:12px;border-radius:8px;background:#ECFDF5;border:1px solid #A7F3D0">'+
                            '<div style="width:40px;height:40px;display:flex;align-items:center;justify-content:center;background:#10B981;border-radius:6px">'+
                              '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">'+
                                '<path d="M12 2a10 10 0 100 20 10 10 0 000-20z" fill="#059669"/>'+
                                '<path d="M16 8l-6.5 8L8 13" stroke="#fff" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" fill="none" />'+
                              '</svg>'+
                            '</div>'+
                            '<div style="flex:1;line-height:1.1">'+
                              '<div style="font-weight:700;color:#064E3B">Your balance is sufficient to post this advert</div>'+
                              '<div style="font-size:13px;color:#065F46">Prime Wallet: ₦'+fmt(userPrime)+' — You can proceed to post this advert.</div>'+
                            '</div>'+
                          '</div>';
                    }
                }

                // initial render and bind events
                document.addEventListener('DOMContentLoaded', function(){
                    // render once DOM ready
                    renderNote();
                    if (platformEl) platformEl.addEventListener('change', renderNote);
                    if (participantsEl) participantsEl.addEventListener('input', renderNote);
                });
            })();
            </script>
          </div>

          <div class="pricing-summary">
            <h3>Cost Summary</h3>
            <div class="summary-row">
              <span>Platform:</span>
              <span id="selected-platform">--</span>
            </div>
            <div class="summary-row">
              <span>Participants:</span>
              <span id="selected-participants">10</span>
            </div>
            <div class="summary-row">
              <span>Base Price (per 10):</span>
              <span id="base-price">₦0.00</span>
            </div>
            <div class="summary-row total">
              <span>Total Cost:</span>
              <span id="total-cost">₦0.00</span>
            </div>
            <!-- Removed upgrade notice as it's no longer relevant with the new pricing structure. -->
          </div>

          <button type="submit" class="submit-btn">Post Task Now</button>
        </form>
      </section>

      <!-- <section class="platform-grid">
  <h2>Available Platforms</h2>
  <div class="platforms">
    <?php 
      /*$platform_svgs = [
          'tiktok' => '<svg viewBox="0 0 24 24" fill="#000000" xmlns="http://www.w3.org/2000/svg"><path d="M9 2v7h3a3 3 0 0 0 3-3V2a5 5 0 0 1-5 0Z"/><path d="M12 2a3 3 0 0 0 3 3h3v3h-3a6 6 0 1 1-6-6v3a3 3 0 0 0 3 0Z"/></svg>',
          'instagram' => '<svg viewBox="0 0 24 24" fill="#E1306C" xmlns="http://www.w3.org/2000/svg"><path d="M7 2C4.24 2 2 4.24 2 7v10c0 2.76 2.24 5 5 5h10c2.76 0 5-2.24 5-5V7c0-2.76-2.24-5-5-5H7zm10 2c1.66 0 3 1.34 3 3v10c0 1.66-1.34 3-3 3H7c-1.66 0-3-1.34-3-3v10a3 3 0 0 0 3 3zm0-9a1.5 1.5 0 1 1 0-3 1.5 1.5 0 0 1 0 3zm7 0a1.5 1.5 0 1 1 0-3 1.5 1.5 0 0 1 0 3zm-7.5 3c0-1.3 4-1.3 5 0 .84.94-5 2-5 0z"/></svg>',
          'whatsapp' => '<svg viewBox="0 0 24 24" fill="#25D366" xmlns="http://www.w3.org/2000/svg"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.031-.967-.273-.099-.472-.149-.671.149-.198.297-.767.966-.94 1.164-.173.198-.347.223-.644.074-.297-.149-1.255-.462-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.297-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.372-.025-.52-.075-.148-.671-1.611-.92-2.207-.242-.579-.487-.5-.671-.51l-.573-.01c-.198 0-.52.074-.792.372s-1.04 1.016-1.213 1.214c-.149.198-2.095 3.2-5.076 4.487-.709.306-1.262.489-1.694.625-.712.226-1.36.194-1.872.118-.571-.085-1.758-.719-2.006-1.413-.248-.694-.248-1.29.173-1.414-.074-.124-.272-.198-.57-.347z"/></svg>',
          'playstore' => '<svg viewBox="0 0 24 24" fill="#3DDC84" xmlns="http://www.w3.org/2000/svg"><path d="M3 2l18 10-18 10V2zm15 10L6 4v16l12-8z"/></svg>',
          'appstore' => '<svg viewBox="0 0 24 24" fill="#0A84FF" xmlns="http://www.w3.org/2000/svg"><path d="M16.5 1H7.5C5.57 1 4 2.57 4 4.5v15C4 21.43 5.57 23 7.5 23h9c1.93 0 3.5-1.57 3.5-3.5v-15C20 2.57 18.43 1 16.5 1zm-4.5 19a1.5 1.5 0 1 1 0-3 1.5 1.5 0 0 1 0 3zm5-7H7V5h10v8z"/></svg>',
          'telegram' => '<svg viewBox="0 0 24 24" fill="#0088CC" xmlns="http://www.w3.org/2000/svg"><path d="M12 2c5.52 0 10 4.48 10 10s-4.48 10-10 10S2 17.52 2 12 6.48 2 12 2zm4.29 7.71L10.5 13l1.2 3.6 1.71-4.29 3.88-3.88-5.7 3.28z"/></svg>',
          'twitter' => '<svg viewBox="0 0 24 24" fill="#1DA1F2" xmlns="http://www.w3.org/2000/svg"><path d="M22 12c0-5.52-4.48-10-10-10S2 6.48 2 12c0 5 3.66 9.12 8.44 9.88v-6.99H8V12h2.44v-2.2c0-2.51 1.49-3.89 3.77-3.89 1.09 0 2.23.2 2.23.2v2.45h-1.25c-1.23 0-1.61.77-1.61 1.56V12h2.74l-.44 2.89h-2.3v6.99C18.34 21.12 22 17 22 12z"/></svg>',
          'facebook' => '<svg viewBox="0 0 24 24" fill="#1877F2" xmlns="http://www.w3.org/2000/svg"><path d="M2 9h6v12H2V9zm8 0h5.4v1.7h.08c.75-1.42 2.58-2.9 5.32-2.9 5.52 0 6.7 2.4 6.7 6.7V21h-6v-6.5c0-1.55-.03-3.55-2.17-3.55-2.17 0-2.5 1.69-2.5 3.44V21h-6V9z"/></svg>',
          'linkedin' => '<svg viewBox="0 0 24 24" fill="#0A66C2" xmlns="http://www.w3.org/2000/svg"><path d="M4.98 3.5a2.28 2.28 0 1 1 0 4.56 2.28 2.28 0 0 1 0-4.56zM2 9h6v12H2V9zm8 0h5.4v1.7h.08c.75-1.42 2.58-2.9 5.32-2.9 5.52 0 6.7 2.4 6.7 6.7V21h-6v-6.5c0-1.55-.03-3.55-2.17-3.55-2.17 0-2.5 1.69-2.5 3.44V21h-6V9z"/></svg>',
          'snapchat' => '<svg viewBox="0 0 24 24" fill="#FFFC00" xmlns="http://www.w3.org/2000/svg"><path d="M12 2C6.48 2 2 6.48 2 12c0 4.1 2.5 7.63 6 9.17v-1.88a4.37 4.37 0 0 1-2-3.29c0-.27.02-.54.06-.81 0 0 .77.18 1.94 1.12 1.21.97 2.97.81 3.49.75s1.75-.45 2.47-1.29c.57-.68.79-1.18.82-1.23a6.87 6.87 0 0 0 1.13-4.48c-.1-1.25-.51-2.28-1.22-3.07-.72-.79-1.69-1.21-2.88-1.27v-.01z"/></svg>',
          'youtube' => '<svg viewBox="0 0 24 24" fill="#FF0000" xmlns="http://www.w3.org/2000/svg"><path d="M10 15l5-3-5-3v6zm12-9.5c0-1.1-.9-2-2-2H4C2.9 3.5 2 4.4 2 5.5v13c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2v-13z"/></svg>',
          'pinterest' => '<svg viewBox="0 0 24 24" fill="#E60023" xmlns="http://www.w3.org/2000/svg"><path d="M12 2C6.48 2 2 6.48 2 12c0 4.42 3.58 8 8 8a7.99 7.99 0 0 0 3.26-.62c.44.37.84.79 1.2 1.26.35-.59.57-1.26.57-2 0-3.31-2.69-6-6-6S6 8.69 6 12c0 1.64.66 3.13 1.73 4.2a.998.998 0 0 0 .07-.26c0-.19.05-.38.12-.56.07-.18.15-.33.23-.48a.503.503 0 0 1 .27-.25c.43-.12.86-.24 1.28-.35.2-.05.45-.03.62.1.17.13.19.39.13.58-.06.19-.13.37-.22.55a2.5 2.5 0 0 1-.32.46c-.25.27-.46.57-.63.88z"/></svg>',
          'reddit' => '<svg viewBox="0 0 24 24" fill="#FF4500" xmlns="http://www.w3.org/2000/svg"><path d="M22 0H4a4 4 0 0 0-4 4v16a4 4 0 0 0 4 4h16a4 4 0 0 0 4-4V4a4 4 0 0 0-4-4zm-8 15s-1.5-1.5-1.5-3 1.5-3 1.5-3 1 0 2 0 1.5 1.5 1.5 3-1.5 3-1.5 3-1 0-2 0zm0-9a1.5 1.5 0 1 0 0 3 1.5 1.5 0 0 0 0-3zm7 0a1.5 1.5 0 1 1 0-3 1.5 1.5 0 0 1 0 3zm-7.5 3c0-1.3 4-1.3 5 0 .84.94-5 2-5 0z"/></svg>',
          'discord' => '<svg viewBox="0 0 24 24" fill="#5865F2" xmlns="http://www.w3.org/2000/svg"><path d="M20 0H4a4 4 0 0 0-4 4v16a4 4 0 0 0 4 4h16a4 4 0 0 0 4-4V4a4 4 0 0 0-4-4zm-8 15s-1.5-1.5-1.5-3 1.5-3 1.5-3 1 0 2 0 1.5 1.5 1.5 3-1.5 3-1.5 3-1 0-2 0zm0-9a1.5 1.5 0 1 0 0 3 1.5 1.5 0 0 0 0-3z"/></svg>',
          'twitch' => '<svg viewBox="0 0 24 24" fill="#9146FF" xmlns="http://www.w3.org/2000/svg"><path d="M4 2L2 6v16h6v2h6l4-4V2H4zm12 10h-2v4h-2v-4H8V6h8v6z"/></svg>',
      ];

      foreach ($platform_prices as $key => $platform):
        */
    ?>
      <div class="platform-card">
        <div class="platform-icon" style="background: #000; border-radius: 12px; padding: 12px;">
          <?php //echo $platform_svgs[$key] ?? '<span>'.strtoupper(substr($platform['name'],0,2)).'</span>'; ?>
        </div>
        <h4><?php //echo $platform['name']; ?></h4>
        <div class="platform-pricing">
          <?php //if ($is_member): ?>
            <p class="member-price">₦<?php //echo number_format($platform['member'], 2); ?></p>
            <p class="price-label">per 10 participants</p>
          <?php //else: ?>
            <p class="non-member-price">₦<?php //echo number_format($platform['non_member'], 2); ?></p>
            <p class="price-label">per 10 participants</p>
            <p class="member-price-small">Senior: ₦<?php //echo number_format($platform['member'], 2); ?></p>
          <?php //endif; ?>
        </div>
      </div>
    <?php //endforeach; ?>
  </div>
</section> -->

    </main>
  </div>

   <nav class="mobile-fintech-footer">
    
  <a href="dashboard.php">
    <svg viewBox="0 0 24 24"><path d="M12 3a9 9 0 1 1 0 18 9 9 0 0 1 0-18Zm1 4h-2v6h6v-2h-4V7Z"/></svg>
    <span>Dashboard</span>
  </a>

  <!-- Premium (crown icon) -->
  <a href="membership.php">
    <svg viewBox="0 0 24 24"><path d="M5 7l2.5 5 4.5-4 4.5 4L19 7l2 13H3l2-13Z"/></svg>
    <span>Premium</span>
  </a>

  <a href="post-task.php" class="active">
<svg viewBox="0 0 24 24" aria-hidden="true">
  <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8l-6-6Zm1 14h-3v3h-2v-3H7v-2h3v-3h2v3h3v2Zm-3-9V3.5L18.5 8H12Z"/>
</svg>
    
    <span>Post Advert</span>
  </a>
  
  

  <a href="history.php">
  <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
    <path d="M13 3a9 9 0 1 0 9 9h-2a7 7 0 1 1-7-7V3l4 4-4 4V7a5 5 0 1 0 5 5h2a7 7 0 1 1-7-7z"/>
  </svg>
  <span>History</span>
</a>


  <a href="profile.php">
    <svg viewBox="0 0 24 24"><path d="M12 2a6 6 0 0 1 6 6c0 3.31-2.69 6-6 6s-6-2.69-6-6a6 6 0 0 1 6-6Zm0 14c4.42 0 8 1.79 8 4v2H4v-2c0-2.21 3.58-4 8-4Z"/></svg>
    <span>Profile</span>
  </a>
</nav>

<!-- Added Paystack confirmation modal -->
<div id="paystackModal" class="paystack-modal">
  <div class="paystack-modal-content">
    <div class="modal-header">
      <h2>Confirm Payment</h2>
      <span class="close-modal" onclick="closePaystackModal()">&times;</span>
    </div>
    <div class="modal-body">
      <div class="payment-icon">
        <svg viewBox="0 0 24 24" fill="#4de1c1" width="64" height="64">
          <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/>
        </svg>
      </div>
      <p class="modal-message">You are about to deposit <strong id="modalAmount">₦0.00</strong> via Paystack to post this task.</p>
      <p class="modal-submessage">Click "Continue to Deposit" to proceed with the payment, or "Cancel" to go back.</p>
    </div>
    <div class="modal-footer">
      <button type="button" class="btn-cancel" onclick="closePaystackModal()">Cancel</button>
      <button type="button" class="btn-continue" onclick="proceedWithPaystack()">Continue to Deposit</button>
    </div>
  </div>
</div>

<!-- Added Korapay confirmation modal -->
<div id="korapayModal" class="paystack-modal">
  <div class="paystack-modal-content">
    <div class="modal-header">
      <h2>Confirm Payment</h2>
      <span class="close-modal" onclick="closeKorapayModal()">&times;</span>
    </div>
    <div class="modal-body">
      <div class="payment-icon">
        <svg viewBox="0 0 24 24" fill="#4de1c1" width="64" height="64">
          <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/>
        </svg>
      </div>
      <p class="modal-message">You are about to deposit <strong id="korapayModalAmount">₦0.00</strong> via Korapay to post this task.</p>
      <p class="modal-submessage">Click "Continue to Deposit" to proceed with the payment, or "Cancel" to go back.</p>
    </div>
    <div class="modal-footer">
      <button type="button" class="btn-cancel" onclick="closeKorapayModal()">Cancel</button>
      <button type="button" class="btn-continue" onclick="proceedWithKorapay()">Continue to Deposit</button>
    </div>
  </div>
</div>

<style>
/* Added Paystack modal styles */
.paystack-modal {
  display: none;
  position: fixed;
  z-index: 10000;
  left: 0;
  top: 0;
  width: 100%;
  height: 100%;
  background-color: rgba(3, 9, 34, 0.9);
  backdrop-filter: blur(8px);
  animation: fadeIn 0.3s ease;
}

@keyframes fadeIn {
  from { opacity: 0; }
  to { opacity: 1; }
}

.paystack-modal-content {
  position: relative;
  background: linear-gradient(135deg, rgba(13, 24, 62, 0.95), rgba(10, 22, 74, 0.95));
  margin: 10% auto;
  padding: 0;
  border: 1px solid rgba(77, 225, 193, 0.3);
  border-radius: 20px;
  width: 90%;
  max-width: 500px;
  box-shadow: 0 20px 60px rgba(0, 0, 0, 0.5);
  animation: slideDown 0.3s ease;
}

@keyframes slideDown {
  from {
    transform: translateY(-50px);
    opacity: 0;
  }
  to {
    transform: translateY(0);
    opacity: 1;
  }
}

.modal-header {
  padding: 24px 28px;
  border-bottom: 1px solid rgba(77, 225, 193, 0.2);
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.modal-header h2 {
  margin: 0;
  color: #f5f9ff;
  font-size: 1.5rem;
  font-weight: 700;
}

.close-modal {
  color: rgba(245, 249, 255, 0.6);
  font-size: 32px;
  font-weight: 300;
  cursor: pointer;
  transition: color 0.3s ease;
  line-height: 1;
}

.close-modal:hover {
  color: #4de1c1;
}

.modal-body {
  padding: 32px 28px;
  text-align: center;
}

.payment-icon {
  margin-bottom: 20px;
  display: flex;
  justify-content: center;
}

.modal-message {
  font-size: 1.1rem;
  color: #f5f9ff;
  margin-bottom: 12px;
  line-height: 1.6;
}

.modal-message strong {
  color: #4de1c1;
  font-size: 1.3rem;
}

.modal-submessage {
  font-size: 0.95rem;
  color: rgba(245, 249, 255, 0.7);
  line-height: 1.5;
}

.modal-footer {
  padding: 20px 28px 28px;
  display: flex;
  gap: 12px;
  justify-content: flex-end;
}

.btn-cancel,
.btn-continue {
  padding: 12px 28px;
  border: none;
  border-radius: 10px;
  font-size: 1rem;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.3s ease;
}

.btn-cancel {
  background: rgba(255, 77, 77, 0.15);
  color: #ff6b6b;
  border: 1px solid rgba(255, 77, 77, 0.3);
}

.btn-cancel:hover {
  background: rgba(255, 77, 77, 0.25);
  transform: translateY(-2px);
}

.btn-continue {
  background: linear-gradient(135deg, #4de1c1, #3bb89f);
  color: #030922;
  box-shadow: 0 4px 15px rgba(77, 225, 193, 0.3);
}

.btn-continue:hover {
  transform: translateY(-2px);
  box-shadow: 0 6px 20px rgba(77, 225, 193, 0.4);
}

@media (max-width: 600px) {
  .paystack-modal-content {
    width: 95%;
    margin: 20% auto;
  }
  
  .modal-footer {
    flex-direction: column;
  }
  
  .btn-cancel,
  .btn-continue {
    width: 100%;
  }
}
</style>

  <script>
    // Removed isMember from JS as it's no longer relevant
    const platformPrices = <?php echo json_encode($platform_prices); ?>;
    
    const platformUrlPatterns = <?php echo json_encode($platform_url_patterns); ?>;
    
    const PAYSTACK_PUBLIC_KEY = 'pk_test_40030e4aa08e323dc666117c50c698d2583a05df'; // Replace with your actual public key
    const userEmail = '<?php echo htmlspecialchars($user_data['email'] ?? ''); ?>';
    const userName = '<?php echo htmlspecialchars($user_data['username'] ?? ''); ?>';
    
    // Korapay configuration
    const KORAPAY_PUBLIC_KEY = '<?php echo htmlspecialchars(KORAPAY_PUBLIC_KEY); ?>';
    
    let pendingTaskData = null;
    
    function updateTitleCounter() {
      const titleInput = document.getElementById('title');
      const counter = document.getElementById('titleCounter');
      
      if (!titleInput || !counter) return;
      
      const text = titleInput.value;
      const charCount = text.length;
      
      counter.textContent = charCount + ' / 45';
      
      // Update color based on character count
      if (charCount >= 45) {
        counter.classList.add('error');
        counter.classList.remove('warning');
      } else if (charCount >= 38) {
        counter.classList.add('warning');
        counter.classList.remove('error');
      } else {
        counter.classList.remove('warning', 'error');
      }
    }

    function updateWordCounter() {
  const textarea = document.getElementById('description');
  const counter = document.getElementById('wordCounter');

  if (!textarea) return;

  const text = textarea.value;
  const charCount = text.length; // counts every character including spaces

  counter.textContent = charCount + ' / 100';

  // Update color based on limit
  if (charCount >= 100) {
    counter.classList.add('error');
    counter.classList.remove('warning');
  } else if (charCount >= 85) {
    counter.classList.add('warning');
    counter.classList.remove('error');
  } else {
    counter.classList.remove('warning', 'error');
  }

  // Prevent exceeding 100 characters
  if (charCount > 100) {
    textarea.value = text.slice(0, 100);
    counter.textContent = '100 / 100';
    counter.classList.add('error');
  }
}

 
    function updatePricing() {
      const platformSelect = document.getElementById('platform');
      const participantsInput = document.getElementById('participants');
      const selectedPlatform = platformSelect.value;
      const participants = parseInt(participantsInput.value) || 10;

      if (!selectedPlatform || !platformPrices[selectedPlatform]) {
        return;
      }

      const platform = platformPrices[selectedPlatform];
      const basePrice = platform.price;
      const totalCost = (participants / 10) * basePrice;
      // Removed premium price calculation, as it's no longer needed

      document.getElementById('selected-platform').textContent = platform.name;
      document.getElementById('selected-participants').textContent = participants;
      document.getElementById('base-price').textContent = '₦' + basePrice.toLocaleString('en-NG', {minimumFractionDigits: 2});
      document.getElementById('total-cost').textContent = '₦' + totalCost.toLocaleString('en-NG', {minimumFractionDigits: 2});
      
      // Removed upgrade notice logic
    }
    
    function validateTaskUrl() {
      const platformSelect = document.getElementById('platform');
      const taskUrlInput = document.getElementById('task_url');
      const platform = platformSelect.value;
      const url = taskUrlInput.value.toLowerCase();
      
      if (!platform || !url) return true;
      
      const patterns = platformUrlPatterns[platform];
      if (!patterns) return true;
      
      let isValid = false;
      for (let pattern of patterns) {
        if (url.includes(pattern.toLowerCase())) {
          isValid = true;
          break;
        }
      }
      
      if (!isValid) {
        taskUrlInput.setCustomValidity('URL must match the selected platform');
      } else {
        taskUrlInput.setCustomValidity('');
      }
      
      return isValid;
    }
    
    function showPaystackModal(amount) {
      document.getElementById('modalAmount').textContent = '₦' + amount.toLocaleString('en-NG', {minimumFractionDigits: 2});
      document.getElementById('paystackModal').style.display = 'block';
      document.body.style.overflow = 'hidden';
    }
    
    function showKorapayModal(amount) {
      document.getElementById('korapayModalAmount').textContent = '₦' + amount.toLocaleString('en-NG', {minimumFractionDigits: 2});
      document.getElementById('korapayModal').style.display = 'block';
      document.body.style.overflow = 'hidden';
    }
    
    function closePaystackModal() {
      document.getElementById('paystackModal').style.display = 'none';
      document.body.style.overflow = 'auto';
      pendingTaskData = null;
    }
    
    function closeKorapayModal() {
      document.getElementById('korapayModal').style.display = 'none';
      document.body.style.overflow = 'auto';
      pendingTaskData = null;
    }
    
    function proceedWithPaystack() {
      if (!pendingTaskData) return;
      
      const amount = pendingTaskData.totalCost * 100; // Convert to kobo
      
      const handler = PaystackPop.setup({
        key: PAYSTACK_PUBLIC_KEY,
        email: userEmail,
        amount: amount,
        currency: 'NGN',
        ref: 'TASK_' + Math.floor((Math.random() * 1000000000) + 1),
        metadata: {
          custom_fields: [
            {
              display_name: "Task Title",
              variable_name: "task_title",
              value: pendingTaskData.title
            },
            {
              display_name: "Platform",
              variable_name: "platform",
              value: pendingTaskData.platform
            },
            {
              display_name: "Participants",
              variable_name: "participants",
              value: pendingTaskData.participants
            }
          ]
        },
        callback: function(response) {
          closePaystackModal();
          // Payment successful
          showToast('Payment successful! Processing your task...', 'success');
          
          // Submit the form with payment reference
          const form = document.getElementById('taskForm');
          const paymentRefInput = document.createElement('input');
          paymentRefInput.type = 'hidden';
          paymentRefInput.name = 'payment_reference';
          paymentRefInput.value = response.reference;
          form.appendChild(paymentRefInput);
          
          // Change payment source to indicate paid via Paystack
          document.getElementById('payment_source').value = 'paystack';
          
          form.submit();
        },
        onClose: function() {
          closePaystackModal();
          showToast('Payment cancelled', 'info');
        }
      });
      
      handler.openIframe();
    }
    
    function proceedWithKorapay() {
      if (!pendingTaskData) return;
      
      const amount = Math.round(pendingTaskData.totalCost);
      
      showToast('Initializing Korapay payment...', 'info');
      
      fetch('/api/post-task-korapay-pay.php', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          payment_type: 'post_task_deposit',
          amount: amount,
          title: pendingTaskData.title,
          description: document.getElementById('description').value || '',
          platform: document.getElementById('platform').value || '',
          task_url: document.getElementById('task_url').value || '',
          participants: pendingTaskData.participants,
          total_cost: pendingTaskData.totalCost
        })
      })
      .then(response => response.json())
      .then(data => {
        if (data.status && data.checkout_url) {
          // Store payment reference before redirecting
          sessionStorage.setItem('korapay_payment_amount', amount);
          sessionStorage.setItem('korapay_task_title', pendingTaskData.title);
          sessionStorage.setItem('korapay_task_platform', pendingTaskData.platform);
          sessionStorage.setItem('korapay_task_participants', pendingTaskData.participants);
          
          // Redirect to Korapay checkout
          window.location.href = data.checkout_url;
        } else {
          closeKorapayModal();
          showToast(data.message || 'Failed to initialize Korapay payment', 'error');
        }
      })
      .catch(error => {
        console.error('Korapay initialization error:', error);
        closeKorapayModal();
        showToast('Error initializing payment: ' + error.message, 'error');
      });
    }
    
    function showToast(message, type) {
      const toast = document.createElement('div');
      toast.className = `alert-message alert-${type} show`;
      toast.textContent = message;
      document.body.appendChild(toast);
      
      setTimeout(() => {
        toast.classList.remove('show');
        setTimeout(() => toast.remove(), 600);
      }, 4000);
    }

    // Post Task Terms Modal Functions - Matching perform-task.php exactly
    function openTSModal() {
      const modal = document.getElementById('tsModal');
      if (modal) {
        modal.classList.add('active');
      }
    }

    function closeTSModal() {
      const modal = document.getElementById('tsModal');
      if (modal) {
        modal.classList.remove('active');
      }
      // Ensure checkbox is checked and buttons are reset if modal is closed without agreeing
      const tsCheckbox = document.getElementById('tsCheckbox');
      const tsAgreeBtn = document.getElementById('tsAgreeBtn');
      const tsCloseBtn = document.getElementById('tsCloseBtn');

      if (tsCheckbox && !tsCheckbox.disabled) { // Only reset if not permanently agreed
        tsCheckbox.checked = false;
        if(tsAgreeBtn) tsAgreeBtn.style.display = 'block';
        if(tsCloseBtn) tsCloseBtn.style.display = 'none';
      }
    }

    function agreeTSAndClose() {
      // Set checkbox as checked
      const tsCheckbox = document.getElementById('tsCheckbox');
      if(tsCheckbox) tsCheckbox.checked = true;
      
      // Disable checkbox and buttons after agreeing
      if(tsCheckbox) tsCheckbox.disabled = true;
      const tsAgreeBtn = document.getElementById('tsAgreeBtn');
      const tsCloseBtn = document.getElementById('tsCloseBtn');
      if(tsAgreeBtn) tsAgreeBtn.style.display = 'none';
      if(tsCloseBtn) tsCloseBtn.style.display = 'block';
      
      // Send AJAX request to store agreement in session
      fetch('post-task.php', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: 'ajax=1&action=agree_terms'
      })
      .then(response => response.json())
      .then(data => {
        if (data.success) {
          // Reload the page after successful agreement
          showToast('Post Task Instructions accepted!', 'success');
          setTimeout(() => {
            window.location.reload();
          }, 500);
        } else {
          // Re-enable buttons if AJAX fails
          if(tsCheckbox) tsCheckbox.disabled = false;
          if(tsCheckbox) tsCheckbox.checked = false;
          if(tsAgreeBtn) tsAgreeBtn.style.display = 'block';
          if(tsCloseBtn) tsCloseBtn.style.display = 'none';
          showToast('Failed to save agreement. Please try again.', 'error');
        }
      })
      .catch(error => {
        console.error('Error agreeing to T&S:', error);
        // Re-enable buttons if AJAX fails
        if(tsCheckbox) tsCheckbox.disabled = false;
        if(tsCheckbox) tsCheckbox.checked = false;
        if(tsAgreeBtn) tsAgreeBtn.style.display = 'block';
        if(tsCloseBtn) tsCloseBtn.style.display = 'none';
        showToast('Failed to save agreement. Please try again.', 'error');
      });
    }

    // Initialize pricing on page load
    document.addEventListener('DOMContentLoaded', function() {
      // Show modal on first visit if not agreed
      <?php if (!$post_agreed): ?>
      openTSModal();
      <?php endif; ?>
      updatePricing();
       updateTitleCounter()
      updateWordCounter();
      
      const platformSelect = document.getElementById('platform');
      const taskUrlInput = document.getElementById('task_url');
      const participantsInput = document.getElementById('participants');
      const titleInput = document.getElementById('title');
      const descriptionTextarea = document.getElementById('description');
      
      
      
       if (titleInput) {
        titleInput.addEventListener('input', updateTitleCounter);
        titleInput.addEventListener('paste', () => {
          setTimeout(updateTitleCounter, 10);
        });
      }
      
      if (descriptionTextarea) {
        descriptionTextarea.addEventListener('input', updateWordCounter);
        descriptionTextarea.addEventListener('paste', () => {
          setTimeout(updateWordCounter, 10);
        });
      }
      
      platformSelect.addEventListener('change', () => {
        validateTaskUrl();
        updatePricing();
      });
      
      participantsInput.addEventListener('input', updatePricing);
      participantsInput.addEventListener('change', updatePricing);
      
      taskUrlInput.addEventListener('input', validateTaskUrl);
      taskUrlInput.addEventListener('blur', validateTaskUrl);
      
      document.getElementById('taskForm').addEventListener('submit', function(e) {
        e.preventDefault();
        
        if (!validateTaskUrl()) {
          showToast('Please provide a valid URL matching the selected platform.', 'error');
          return false;
        }
        
        const paymentSource = document.getElementById('payment_source').value;
        
        if (paymentSource === 'paystack') {
          // Show Paystack modal
          const title = document.getElementById('title').value;
          const platform = document.getElementById('platform').value;
          const participants = parseInt(document.getElementById('participants').value);
          
          if (!platform || !platformPrices[platform]) {
            showToast('Please select a valid platform', 'error');
            return false;
          }
          
          const basePrice = platformPrices[platform].price;
          const totalCost = (participants / 10) * basePrice;
          
          pendingTaskData = {
            title: title,
            platform: platformPrices[platform].name,
            participants: participants,
            totalCost: totalCost
          };
          
          showPaystackModal(totalCost);
        } else if (paymentSource === 'korapay') {
          // Show Korapay modal
          const title = document.getElementById('title').value;
          const platform = document.getElementById('platform').value;
          const participants = parseInt(document.getElementById('participants').value);
          
          if (!platform || !platformPrices[platform]) {
            showToast('Please select a valid platform', 'error');
            return false;
          }
          
          const basePrice = platformPrices[platform].price;
          const totalCost = (participants / 10) * basePrice;
          
          pendingTaskData = {
            title: title,
            platform: platformPrices[platform].name,
            participants: participants,
            totalCost: totalCost
          };
          
          showKorapayModal(totalCost);
        } else {
          // Submit normally for wallet payment
          this.submit();
        }
      });
    });
  </script>
</body>
</html>
