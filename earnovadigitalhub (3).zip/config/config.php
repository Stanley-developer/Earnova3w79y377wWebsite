<?php
// FlowEarner Configuration File

// Start session
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Site configuration
define('SITE_NAME', 'FlowEarner');
define('SITE_URL', 'http://localhost/flowearner');
define('ADMIN_EMAIL', 'admin@flowearner.com');

// Security
define('PASSWORD_MIN_LENGTH', 8);
define('SESSION_TIMEOUT', 3600); // 1 hour

// Financial settings
define('WELCOME_BONUS', 1000.00); // ₦1,000
define('PREMIUM_COST', 1500.00); // ₦1,500
define('PREMIUM_REFERRER_COMMISSION', 500.00); // ₦500
define('PREMIUM_COMPANY_AMOUNT', 1000.00); // ₦1,000

// Referral commissions
define('FREE_USER_REFERRAL_COMMISSION', 250.00); // ₦250
define('PREMIUM_USER_REFERRAL_COMMISSION', 500.00); // ₦500

// Withdrawal limits
define('REFERRAL_WITHDRAWAL_MIN', 3000.00); // ₦3,000 (automatic)
define('TASK_WITHDRAWAL_MIN', 55000.00); // ₦55,000 (manual)

// Timezone
date_default_timezone_set('Africa/Lagos');

// Error reporting (disable in production)
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Include database config
require_once __DIR__ . '/database.php';

// Helper functions
function sanitizeInput($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data, ENT_QUOTES, 'UTF-8');
    return $data;
}

function generateReferralCode($length = 10) {
    $characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    $code = '';
    for ($i = 0; $i < $length; $i++) {
        $code .= $characters[rand(0, strlen($characters) - 1)];
    }
    return 'FE-' . $code;
}

function isLoggedIn() {
    return isset($_SESSION['user_id']) && !empty($_SESSION['user_id']);
}

function requireLogin() {
    if (!isLoggedIn()) {
        header('Location: signin.php');
        exit();
    }
}

function getCurrentUserId() {
    return $_SESSION['user_id'] ?? null;
}

function redirectTo($url) {
    header('Location: ' . $url);
    exit();
}

function jsonResponse($success, $message, $data = []) {
    header('Content-Type: application/json');
    echo json_encode([
        'success' => $success,
        'message' => $message,
        'data' => $data
    ]);
    exit();
}
?>
