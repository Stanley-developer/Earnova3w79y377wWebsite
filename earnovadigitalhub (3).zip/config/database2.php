<?php
// Database configuration
define('DB_HOST', 'localhost');
define('DB_NAME', 'workwave_enova');
define('DB_USER', 'workwave_enova');
define('DB_PASS', 'JO(J4Z~dW}???xdj');
define('DB_CHARSET', 'utf8mb4');

// Create PDO connection function
function getDBConnection() {
    try {
        $dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=" . DB_CHARSET;
        $options = [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ];
        
        return new PDO($dsn, DB_USER, DB_PASS, $options);
    } catch (PDOException $e) {
        error_log("Database Connection Error: " . $e->getMessage());
        die("Database connection failed. Please try again later.");
    }
}

// ✅ Create a global $pdo connection immediately
$pdo = getDBConnection();

// Ensure PDO session timezone matches application timezone (Nigeria / UTC+1)
try {
    $pdo->exec("SET time_zone = '+01:00'");
} catch (Exception $e) {
    error_log("Failed to set PDO session time_zone: " . $e->getMessage());
}

// Test connection
function testConnection() {
    try {
        $pdo = getDBConnection();
        return true;
    } catch (Exception $e) {
        return false;
    }
}

// Create MySQLi connection (for legacy code)
$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);

// Check connection
if ($conn->connect_error) {
    die("Database connection failed: " . $conn->connect_error);
}

// Set charset
$conn->set_charset(DB_CHARSET);

// Ensure MySQLi session timezone matches application timezone (Nigeria / UTC+1)
try {
    $conn->query("SET time_zone = '+01:00'");
} catch (Exception $e) {
    error_log("Failed to set MySQLi session time_zone: " . $e->getMessage());
}
