<?php
/**
 * Kora Pay Configuration
 * API Documentation: https://developers.korapay.com/docs
 */

// API Keys - Store these in environment variables for production
define('KORAPAY_PUBLIC_KEY', getenv('KORAPAY_PUBLIC_KEY') ?: 'pk_test_jr5yBKKmaSzcvTAYRjsUf1rMyWjPMRGr9UYerwqK');
define('KORAPAY_SECRET_KEY', getenv('KORAPAY_SECRET_KEY') ?: 'sk_test_KdLKEC3B94nRGDEhj8p3RBBkDaucaT8dc588uQb3');
define('KORAPAY_SANDBOX_MODE', getenv('KORAPAY_SANDBOX_MODE') ?: false); // Set to true for testing

// API Base URL
define('KORAPAY_API_BASE', KORAPAY_SANDBOX_MODE 
    ? 'https://api-sandbox.korapay.com/merchant/api/v1'
    : 'https://api.korapay.com/merchant/api/v1'
);

// Supported Banks for NGN Virtual Accounts
$KORAPAY_BANKS = [
    '000' => ['code' => '000', 'name' => 'Test Bank (Sandbox)'],
    '035' => ['code' => '035', 'name' => 'Wema Bank'],
    '103' => ['code' => '103', 'name' => 'Globus Bank'],
    '107' => ['code' => '107', 'name' => 'Optimus Bank'],
    '070' => ['code' => '070', 'name' => 'Fidelity Bank'],
];

// Default bank for VBA creation
define('KORAPAY_DEFAULT_BANK', KORAPAY_SANDBOX_MODE ? '000' : '035'); // Wema Bank in live, Test Bank in sandbox

/**
 * Create a Virtual Bank Account for a user
 * 
 * @param int $user_id User ID
 * @param string $customer_name Customer full name
 * @param string $customer_email Customer email
 * @param string $bvn Bank Verification Number (required in Nigeria)
 * @return array Response with account details
 */
function createKorapayVBA($user_id, $customer_name, $customer_email, $bvn = null) {
    $account_reference = 'EARNOVA-' . $user_id . '-' . time();
    
    $payload = [
        'account_name' => $customer_name,
        'account_reference' => $account_reference,
        'permanent' => true,
        'bank_code' => KORAPAY_DEFAULT_BANK,
        'customer' => [
            'name' => $customer_name,
            'email' => $customer_email,
        ],
        'kyc' => [
            'bvn' => $bvn ?? '',
        ],
    ];

    return korapayRequest('POST', '/virtual-bank-account', $payload);
}

/**
 * Get Virtual Bank Account details
 * 
 * @param string $account_reference Your unique reference for the account
 * @return array Account details
 */
function getKorapayVBA($account_reference) {
    return korapayRequest('GET', '/virtual-bank-account/' . $account_reference, null);
}

/**
 * Initialize a checkout for charge creation
 * Used for card payments and other direct charge methods
 * 
 * @param array $params Checkout parameters
 * @return array Response with checkout URL or reference
 */
function initializeKorapayCharge($params) {
    return korapayRequest('POST', '/charges/initialize', $params);
}

/**
 * Verify a charge/transaction
 * 
 * @param string $reference Transaction reference from Kora Pay
 * @return array Transaction details
 */
function verifyKorapayCharge($reference) {
    return korapayRequest('GET', '/charges/' . $reference, null);
}

/**
 * Make a request to Kora Pay API
 * 
 * @param string $method HTTP method (GET, POST, etc.)
 * @param string $endpoint API endpoint
 * @param array|null $data Request payload
 * @return array API response
 */
function korapayRequest($method, $endpoint, $data = null) {
    $url = KORAPAY_API_BASE . $endpoint;
    
    $curl = curl_init();
    $headers = [
        'Authorization: Bearer ' . KORAPAY_SECRET_KEY,
        'Content-Type: application/json',
    ];
    
    curl_setopt_array($curl, [
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_CUSTOMREQUEST => $method,
        CURLOPT_HTTPHEADER => $headers,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_SSL_VERIFYHOST => false,
        CURLOPT_TIMEOUT => 30,
    ]);
    
    $jsonData = null;
    if ($data !== null && in_array($method, ['POST', 'PUT', 'PATCH'])) {
        $jsonData = json_encode($data);
        curl_setopt($curl, CURLOPT_POSTFIELDS, $jsonData);
    }
    
    // Also write to a local debug log file so you can inspect requests/responses
    $logFile = __DIR__ . '/../logs/korapay_debug.log';
    $logEntry = date('c') . " | REQUEST: $method $url\n";
    if ($jsonData) {
        $logEntry .= "PAYLOAD: $jsonData\n";
    }
    // Ensure the directory is writable and append the entry
    @file_put_contents($logFile, $logEntry, FILE_APPEND | LOCK_EX);
    // Keep existing error_log calls (PHP error log)
    error_log(">>> Kora Pay Request: $method $url");
    if ($jsonData) {
        error_log(">>> Payload: $jsonData");
    }
    
    $response = curl_exec($curl);
    $curl_error = curl_error($curl);
    $http_code = curl_getinfo($curl, CURLINFO_HTTP_CODE);
    curl_close($curl);
    
    // Log to file and to PHP error log
    $respEntry = date('c') . " | RESPONSE: HTTP $http_code\nBODY: " . ($response ?? 'NULL') . "\n---\n";
    @file_put_contents($logFile, $respEntry, FILE_APPEND | LOCK_EX);
    error_log("<<< Kora Pay Response: HTTP $http_code");
    error_log("<<< Body: $response");

    if ($curl_error) {
        error_log("!!! Kora Pay CURL Error: " . $curl_error);
        return [
            'status' => false,
            'message' => 'Connection error: ' . $curl_error,
            'data' => null,
            'http_code' => $http_code,
            'raw_response' => $response
        ];
    }

    $result = json_decode($response, true);

    // Log API calls for debugging
    error_log("Kora Pay API [$method $endpoint] - HTTP $http_code: " . json_encode($result));

    // Return structured response including raw body and http code for diagnostics
    if (is_array($result)) {
        // If the API returns a structured response, include it
        $result['http_code'] = $http_code;
        $result['raw_response'] = $response;
        return $result;
    }

    return [
        'status' => false,
        'message' => 'Invalid response from Kora Pay',
        'data' => null,
        'http_code' => $http_code,
        'raw_response' => $response
    ];
}

/**
 * Generate a Kora Pay checkout link
 * 
 * @param array $params Checkout parameters including amount, email, metadata, etc.
 * @return string Checkout URL
 */
function generateKorapayCheckoutLink($params) {
    // Kora Pay uses embedded checkout or inline checkout
    // This returns a checkout reference that can be used to initialize the payment
    $response = initializeKorapayCharge($params);
    
    if ($response['status'] === true && isset($response['data']['checkout_url'])) {
        return $response['data']['checkout_url'];
    }
    
    return null;
}
?>
