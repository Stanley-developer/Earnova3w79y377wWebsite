<?php
require_once 'config/database.php';
require_once 'includes/session.php';
require_once 'includes/connect.php';
require_once 'includes/email.php';

// Require authentication
requireLogin();
checkSessionTimeout();

// Get current user data
$user = getCurrentUser();
$user_id = $user['id'];

try {
    $pdo = getDBConnection();
    
    // Fetch user details
    $stmt = $pdo->prepare("SELECT u.*, b.total_balance, b.task_earnings, b.referral_earnings FROM users u LEFT JOIN balances b ON u.id = b.user_id WHERE u.id = ?");
    $stmt->execute([$user_id]);
    $user_data = $stmt->fetch();
    
    if (!$user_data) {
        header('Location: login.php');
        exit;
    }
    
    $is_senior_advertiser = ($user_data['advertiser_plan'] === 'senior');
    
    if (!$is_senior_advertiser) {
        // Show locked page
        ?>
        <!DOCTYPE html>
        <html lang="en">
        <head>
          <meta charset="UTF-8" />
          <meta name="viewport" content="width=device-width, initial-scale=1.0" />
          <title>Post Jobs - Locked - FlowEarner</title>
          <link rel="stylesheet" href="post-task.css" />
        </head>
        <body>
          <div class="lock-container" style="max-width: 600px; margin: 100px auto; text-align: center; padding: 40px; background: rgba(13, 24, 62, 0.85); border-radius: 24px;">
            <div class="lock-icon" style="font-size: 80px; margin-bottom: 20px;">🔒</div>
            <h1 style="color: #f5f9ff; margin-bottom: 20px;">Post Jobs Access Locked</h1>
            <p style="color: rgba(216, 230, 255, 0.85); font-size: 1.1rem; line-height: 1.7; margin-bottom: 30px;">
              ⚠️ Only Senior Advertisers can post jobs. Upgrade your plan to continue.
            </p>
            <a href="membership.php" style="display: inline-block; padding: 16px 40px; background: linear-gradient(135deg, #fb923c, #f97316); color: #030922; font-size: 1.1rem; font-weight: 700; border-radius: 14px; text-decoration: none;">Upgrade to Senior Now</a>
            <br><br>
            <a href="dashboard.php" style="color: rgba(210, 226, 255, 0.7); text-decoration: none;">← Back to Dashboard</a>
          </div>
        </body>
        </html>
        <?php
        exit;
    }
    
    // Career categories
    $career_categories = [
        'Web Development',
        'Graphic Design',
        'Content Writing',
        'Digital Marketing',
        'Video Editing',
        'Data Entry',
        'Virtual Assistant',
        'Social Media Management',
        'SEO Specialist',
        'Mobile App Development',
        'Photography',
        'Voice Over',
        'Translation',
        'Customer Support',
        'Other'
    ];
    
    // Handle form submission
    $message = '';
    $messageType = '';
    
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'post_job') {
        $title = trim($_POST['title'] ?? '');
        $description = trim($_POST['description'] ?? '');
        $career_category = $_POST['career_category'] ?? '';
        $payment_amount = floatval($_POST['payment_amount'] ?? 0);
        $duration_days = intval($_POST['duration_days'] ?? 7);
        
        // Handle file upload
        $supporting_file = null;
        if (isset($_FILES['supporting_file']) && $_FILES['supporting_file']['error'] === UPLOAD_ERR_OK) {
            $upload_dir = 'uploads/job_files/';
            if (!is_dir($upload_dir)) {
                mkdir($upload_dir, 0777, true);
            }
            
            $file_extension = pathinfo($_FILES['supporting_file']['name'], PATHINFO_EXTENSION);
            $file_name = 'job_' . $user_id . '_' . time() . '.' . $file_extension;
            $file_path = $upload_dir . $file_name;
            
            if (move_uploaded_file($_FILES['supporting_file']['tmp_name'], $file_path)) {
                $supporting_file = $file_path;
            }
        }
        
        // Validation
        if (empty($title) || empty($description) || empty($career_category)) {
            $message = 'Please fill in all required fields';
            $messageType = 'error';
        } elseif ($payment_amount < 1000) {
            $message = 'Payment amount must be at least ₦1,000';
            $messageType = 'error';
        } elseif ($duration_days < 1 || $duration_days > 90) {
            $message = 'Duration must be between 1 and 90 days';
            $messageType = 'error';
        } else {
            try {
                // Insert job
                $stmt = $pdo->prepare("INSERT INTO jobs (title, description, career_category, payment_amount, duration_days, supporting_file, created_by, approval_status, is_active, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, 'pending', 1, NOW())");
                $stmt->execute([$title, $description, $career_category, $payment_amount, $duration_days, $supporting_file, $user_id]);
                
                $message = 'Job posted successfully! Your job is pending admin approval.';
                $messageType = 'success';
                
                // Send confirmation email
                sendJobPostedEmail($user_data['email'], $title);
                
            } catch (Exception $e) {
                $message = 'Failed to post job. Please try again.';
                $messageType = 'error';
                error_log("Post job error: " . $e->getMessage());
            }
        }
    }
    
} catch (PDOException $e) {
    error_log("Post Jobs Error: " . $e->getMessage());
    $error_message = "Unable to load page data.";
}

$username = htmlspecialchars($user_data['username'] ?? 'User');
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Post Jobs - FlowEarner</title>
  <link rel="stylesheet" href="post-task.css" />
</head>
<body>

<?php if ($message): ?>
  <div id="alert-toast" class="alert-message alert-<?php echo $messageType; ?>">
    <?php echo htmlspecialchars($message); ?>
  </div>
<?php endif; ?>

<style>
.alert-message {
  position: fixed;
  top: 20px;
  right: -400px;
  padding: 16px 24px;
  border-radius: 12px;
  font-family: 'Segoe UI', sans-serif;
  font-size: 15px;
  z-index: 1000;
  opacity: 0;
  box-shadow: 0 10px 40px rgba(0, 0, 0, 0.2);
  transition: right 0.6s ease, opacity 0.6s ease;
  color: #fff;
}

.alert-success {
  background: rgba(77, 225, 193, 0.95);
  color: #030922;
  box-shadow: 0 10px 40px rgba(77, 225, 193, 0.4);
}

.alert-error {
  background: rgba(255, 77, 77, 0.95);
  color: #fff;
  box-shadow: 0 10px 40px rgba(255, 77, 77, 0.4);
}

.alert-message.show {
  right: 20px;
  opacity: 1;
}
</style>

<script>
document.addEventListener("DOMContentLoaded", () => {
  const alertToast = document.getElementById("alert-toast");
  if (alertToast) {
    setTimeout(() => alertToast.classList.add("show"), 100);
    setTimeout(() => alertToast.classList.remove("show"), 4000);
  }
});
</script>

  <div class="page-shell">
    <aside id="sidebar">
      <a class="back-link" href="dashboard.php">← Dashboard</a>
      <div class="aside-welcome">
        <div class="aside-avatar">
          <img src="<?php echo !empty($user_data['profile_picture']) ? htmlspecialchars($user_data['profile_picture']) : 'front/assets/images/default-avatar.png'; ?>" alt="User avatar">
        </div>
        <div>
          <p class="welcome-tag">Welcome back</p>
          <h3><?php echo $username; ?></h3>
          <p class="welcome-meta">Senior Advertiser</p>
        </div>
      </div>
      <div>
        <h2 class="page-title">Post Jobs</h2>
        <p class="side-description">Create job opportunities for FlowEarner members. Post jobs and receive bids from qualified candidates.</p>
      </div>
    </aside>
    
    <main>
      <section class="hero-section">
        <div class="hero-content">
          <h1>Post a Job</h1>
          <p>Reach thousands of skilled members across multiple categories. Set your budget and find the perfect candidate.</p>
        </div>
      </section>

      <section class="form-section">
        <form method="POST" enctype="multipart/form-data" class="task-form">
          <input type="hidden" name="action" value="post_job">
          
          <div class="form-group">
            <label for="title">Job Title *</label>
            <input type="text" id="title" name="title" required placeholder="e.g., Need a Logo Designer for My Brand">
          </div>

          <div class="form-group">
            <label for="description">Job Description *</label>
            <textarea id="description" name="description" required rows="6" placeholder="Describe the job requirements, deliverables, and any specific instructions..."></textarea>
          </div>

          <div class="form-group">
            <label for="career_category">Career Category *</label>
            <select id="career_category" name="career_category" required>
              <option value="">-- Choose Category --</option>
              <?php foreach ($career_categories as $category): ?>
                <option value="<?php echo $category; ?>"><?php echo $category; ?></option>
              <?php endforeach; ?>
            </select>
          </div>

          <div class="form-group">
            <label for="payment_amount">Payment Amount (₦) *</label>
            <input type="number" id="payment_amount" name="payment_amount" required min="1000" step="100" placeholder="Minimum ₦1,000">
            <small>Amount you will pay to the selected candidate</small>
          </div>

          <div class="form-group">
            <label for="duration_days">Duration (Days) *</label>
            <input type="number" id="duration_days" name="duration_days" value="7" min="1" max="90" required>
            <small>How many days to complete the job (1-90 days)</small>
          </div>

          <div class="form-group">
            <label for="supporting_file">Upload Supporting File (Optional)</label>
            <input type="file" id="supporting_file" name="supporting_file" accept=".pdf,.doc,.docx,.jpg,.jpeg,.png,.zip">
            <small>Upload any reference files, briefs, or examples (Max 10MB)</small>
          </div>

          <button type="submit" class="submit-btn">Post Job Now</button>
        </form>
      </section>
    </main>
  </div>

  <nav class="mobile-fintech-footer">
    <a href="dashboard.php">
      <svg viewBox="0 0 24 24"><path d="M12 3a9 9 0 1 1 0 18 9 9 0 0 1 0-18Zm1 4h-2v6h6v-2h-4V7Z"/></svg>
      <span>Dashboard</span>
    </a>
    <a href="membership.php">
      <svg viewBox="0 0 24 24"><path d="M5 7l2.5 5 4.5-4 4.5 4L19 7l2 13H3l2-13Z"/></svg>
      <span>Premium</span>
    </a>
    <a href="find-jobs.php">
      <svg viewBox="0 0 24 24"><path d="M9 2h6a2 2 0 0 1 2 2v2h3v16H4V6h3V4a2 2 0 0 1 2-2zm0 4h6V4H9v2zm2 6h2v5h-2v-5z"/></svg>
      <span>Find Jobs</span>
    </a>
    <a href="view-bids.php">
      <svg viewBox="0 0 24 24"><path d="M13 2v8h8M12 2a10 10 0 1 0 10 10h-2a8 8 0 1 1-8-8V2z"/></svg>
      <span>My Bids</span>
    </a>
    <a href="profile.php">
      <svg viewBox="0 0 24 24"><path d="M12 2a6 6 0 0 1 6 6c0 3.31-2.69 6-6 6s-6-2.69-6-6a6 6 0 0 1 6-6Zm0 14c4.42 0 8 1.79 8 4v2H4v-2c0-2.21 3.58-4 8-4Z"/></svg>
      <span>Profile</span>
    </a>
  </nav>
</body>
</html>
