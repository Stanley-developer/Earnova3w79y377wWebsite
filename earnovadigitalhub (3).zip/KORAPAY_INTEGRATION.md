# Kora Pay Integration for Earnova Digital Hub

## Overview
This document describes the complete Kora Pay integration for automatic deposits and membership upgrades on the Earnova Digital Hub platform.

## Features Implemented

### 1. **Payment Gateway Selection**
- Users can choose between Kora Pay (recommended) and Paystack
- Payment modal displays product details before proceeding
- Clean, intuitive gateway selection interface

### 2. **Virtual Bank Accounts (VBA)**
- Each user can have a dedicated virtual bank account
- Users can deposit funds via their own VBA
- Automatic credit to user balance when deposit is received

### 3. **Membership Upgrades**
- Premium Membership upgrade via Kora Pay
- Premium Plus (Advertiser Plan) upgrade via Kora Pay
- Support for both first-time and renewal payments

### 4. **Webhook Handling**
- Automatic processing of payment notifications from Kora Pay
- Real-time balance updates when payments are received
- Secure webhook signature verification

## Installation

### 1. **Database Migration**
Apply the database migration to add necessary tables and columns:

```bash
mysql -u your_user -p your_database < database/migrations/20250210_add_korapay_integration.sql
```

Or manually run the SQL commands in:
- `database/migrations/20250210_add_korapay_integration.sql`

### 2. **Configuration**
Set up Kora Pay API credentials in your environment:

```bash
# Create a .env file or export these variables
export KORAPAY_PUBLIC_KEY="your_public_key"
export KORAPAY_SECRET_KEY="your_secret_key"
export KORAPAY_SANDBOX_MODE=true  # Set to false for production
```

Or update directly in `config/korapay.php`:

```php
define('KORAPAY_PUBLIC_KEY', 'your_public_key');
define('KORAPAY_SECRET_KEY', 'your_secret_key');
define('KORAPAY_SANDBOX_MODE', false); // Set to false for production
```

### 3. **Webhook Configuration**
In your Kora Pay dashboard:

1. Navigate to **Webhooks** settings
2. Add a new webhook endpoint:
   - **URL:** `https://yourdomain.com/api/korapay-webhook.php`
   - **Events:** Select `charge.success` event
3. Save and test the webhook

## Database Schema

### New Tables Added

#### `korapay_transactions`
Tracks all Kora Pay transactions (deposits and upgrades):
- `user_id` - User making the transaction
- `korapay_reference` - Unique Kora Pay reference
- `amount` - Transaction amount
- `currency` - Currency (NGN for Nigeria)
- `payer_account_number` - Payer's bank account
- `payer_account_name` - Payer's name
- `payer_bank_name` - Payer's bank
- `status` - pending, success, failed
- `payment_type` - premium_upgrade, premium_plus_upgrade, deposit
- `deposit_purpose` - ads, games, or general

#### `korapay_webhooks`
Logs all webhook events from Kora Pay:
- `event_type` - Event type (e.g., charge.success)
- `webhook_reference` - Unique webhook reference
- `payload` - Full JSON payload
- `processed` - Whether webhook was processed
- `processed_at` - When webhook was processed

### New Columns in Existing Tables

#### `users` table
- `korapay_vba_account_number` - User's virtual bank account number
- `korapay_account_reference` - Internal reference for VBA
- `korapay_vba_created_at` - When VBA was created
- `korapay_vba_bank_code` - Bank code (035 for Wema, etc.)
- `korapay_vba_bank_name` - Bank name

#### `premium_payments` & `advertiser_payments` tables
- `payment_method` - Tracks whether payment was via 'paystack' or 'korapay'

## API Endpoints

### 1. **Kora Pay Payment Initialization**
**POST** `/api/korapay-pay.php`

Request body:
```json
{
  "payment_type": "premium_upgrade|premium_plus_upgrade|deposit",
  "amount": 1500,
  "plan_duration": "yearly|monthly"
}
```

Response:
```json
{
  "status": true,
  "message": "Checkout initialized",
  "checkout_url": "https://checkout.korapay.com/...",
  "reference": "EARNOVA-premium_upgrade-123-..."
}
```

### 2. **Kora Pay Webhook**
**POST** `/api/korapay-webhook.php`

Receives and processes webhook events from Kora Pay:
- Verifies webhook signature
- Processes charge.success events
- Updates user balances
- Records transactions

## User Flow

### For Deposits via VBA:

1. User navigates to Membership page
2. Clicks "Deposit Funds" button
3. Enters amount and selects deposit type
4. Chooses payment method (Kora Pay or Paystack)
5. Kora Pay payment modal opens
6. User completes payment from their bank
7. Kora sends webhook notification
8. Webhook handler credits user's balance
9. User sees deposit in their wallet

### For Membership Upgrades:

1. User clicks "Upgrade to Premium" or "Premium Plus" button
2. Checkout modal opens with product details
3. User selects payment method
4. If Kora Pay:
   - Redirected to Kora Pay checkout
   - Completes payment
   - Webhook processes the upgrade
5. If Paystack:
   - Paystack modal opens
   - User completes payment
   - Paystack callback verifies transaction

## Testing

### Sandbox Mode
Set to sandbox for testing:
```php
define('KORAPAY_SANDBOX_MODE', true);
```

Use test bank code `000` for sandbox testing.

### Test Scenarios

1. **Successful Payment:**
   - Amount: ₦1,000+
   - Use test bank account

2. **Failed Payment:**
   - Amount: ₦0.01
   - Should fail payment

3. **Webhook Testing:**
   - Use Kora Pay dashboard to test webhook delivery
   - Check logs in `error_log` or `error_log.txt`

## Troubleshooting

### Issue: Webhook Not Being Called
**Solution:**
1. Verify webhook URL in Kora Pay dashboard
2. Check firewall/server logs for blocked requests
3. Ensure HTTPS is enabled
4. Test webhook delivery in Kora Pay dashboard

### Issue: VBA Not Created
**Solution:**
1. Verify BVN (Bank Verification Number) is valid
2. Check API keys are correct
3. Ensure account is approved for VBA creation in Kora Pay dashboard
4. Check error logs for API response messages

### Issue: Balance Not Updated After Payment
**Solution:**
1. Check `korapay_transactions` table for failed status
2. Verify webhook was received in `korapay_webhooks` table
3. Check database logs for transaction update errors
4. Ensure user account reference matches

### Issue: "Invalid API Key" Error
**Solution:**
1. Verify correct API keys are set
2. Check for copy-paste errors (extra spaces)
3. Confirm you're using the right keys (public vs secret)
4. In production, ensure KORAPAY_SANDBOX_MODE is false

## Security Considerations

1. **Webhook Signature Verification:** All webhooks are verified using HMAC-SHA256
2. **API Keys:** Store in environment variables, never in source code
3. **HTTPS:** Always use HTTPS in production
4. **Database:** Use prepared statements to prevent SQL injection
5. **User Verification:** Only process webhooks for authenticated users

## Currency Support

Currently configured for:
- **NGN** (Nigerian Naira) - Virtual Bank Accounts
- Other currencies via card/checkout (Kora Pay supports multiple currencies)

To add more currencies:
1. Update `KORAPAY_BANKS` array in `config/korapay.php`
2. Create additional VBA endpoints for new currencies
3. Update webhook handlers for new currency types

## Monitoring

### Log Files
Monitor these files for debugging:
- `error_log` - PHP errors and Kora Pay API calls
- `error_log.txt` - Additional error tracking

### Key Log Entries
```
Kora Pay Webhook Received: {...}
Processing Kora Pay Event: charge.success
Found user: 123
Transaction recorded successfully for user 123
User balance updated for user 123
```

### Database Queries for Monitoring

View all transactions:
```sql
SELECT * FROM korapay_transactions ORDER BY created_at DESC;
```

View pending transactions:
```sql
SELECT * FROM korapay_transactions WHERE status = 'pending';
```

View unprocessed webhooks:
```sql
SELECT * FROM korapay_webhooks WHERE processed = 0;
```

## Support

For Kora Pay integration issues:
- **Kora Pay Documentation:** https://developers.korapay.com/docs
- **Kora Pay Support:** support@korapay.com

For Earnova issues:
- Check error logs
- Review database transaction records
- Verify API keys and webhook configuration

## Version History

### v1.0 (2025-02-10)
- Initial Kora Pay integration
- Virtual Bank Account support
- Premium and Premium Plus upgrade support
- Webhook processing
- Payment gateway selection UI
