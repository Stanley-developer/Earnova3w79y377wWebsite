<?php
session_start();
require_once 'config/database.php';
require_once 'includes/session.php';
require_once 'includes/connect.php';


if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$user_id = $_SESSION['user_id'];

$stmt = $conn->prepare("
    SELECT u.*, b.total_balance, b.task_earnings, b.referral_earnings, v.verification_status 
    FROM users u 
    LEFT JOIN balances b ON u.id = b.user_id 
    LEFT JOIN user_verification v ON u.id = v.user_id
    WHERE u.id = ?
");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();
$stmt->close();

$is_premium = ($user['membership_type'] === 'premium');
if (!$is_premium) {
    header('Location: membership.php');
    exit();
}

$is_verified = ($user['verification_status'] === 'approved');

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['job_id'])) {
    if (!$is_verified) {
        $error_message = "Please complete profile verification before bidding on jobs.";
    } else {
        $job_id = intval($_POST['job_id']);
        $cover_letter = trim($_POST['cover_letter']);
        $proposed_rate = floatval($_POST['proposed_rate']);
        
        $stmt = $conn->prepare("INSERT INTO job_bids (job_id, user_id, cover_letter, proposed_rate) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("iisd", $job_id, $user_id, $cover_letter, $proposed_rate);
        
        if ($stmt->execute()) {
            $success_message = "Bid submitted successfully! Awaiting admin approval.";
        } else {
            $error_message = "Failed to submit bid. You may have already bid on this job.";
        }
        $stmt->close();
    }
}

$stmt = $conn->prepare("
    SELECT j.*, u.username as posted_by,
    (SELECT COUNT(*) FROM job_bids WHERE job_id = j.id AND user_id = ?) as user_has_bid
    FROM jobs j
    LEFT JOIN users u ON j.created_by = u.id
    WHERE j.is_active = 1 AND j.slots_filled < j.slots_available
    ORDER BY j.created_at DESC
");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$jobs = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Find Jobs - FlowEarner</title>
  <style>
    <?php include 'front/assets/css/shared-styles.css'; ?>
    
    .job-card {
      background: var(--panel-glass);
      border: 1px solid var(--panel-border);
      border-radius: 20px;
      padding: clamp(20px, 3vw, 28px);
      box-shadow: var(--shadow-heavy);
      transition: transform 0.3s;
      position: relative;
      overflow: hidden;
    }
    
    .job-card:hover {
      transform: translateY(-4px);
    }
    
    .job-badge {
      display: inline-block;
      padding: 6px 12px;
      background: rgba(77, 225, 193, 0.2);
      border: 1px solid rgba(77, 225, 193, 0.3);
      border-radius: 16px;
      font-size: 0.75rem;
      letter-spacing: 0.08em;
      text-transform: uppercase;
      color: var(--page-mint);
      margin-bottom: 12px;
    }
    
    .job-title {
      font-size: clamp(1.2rem, 2.5vw, 1.5rem);
      margin: 0 0 12px;
      color: var(--page-white);
    }
    
    .job-meta {
      display: flex;
      flex-wrap: wrap;
      gap: 16px;
      margin-bottom: 16px;
      font-size: 0.9rem;
      color: rgba(216, 230, 255, 0.7);
    }
    
    .job-description {
      color: rgba(216, 230, 255, 0.85);
      line-height: 1.7;
      margin-bottom: 16px;
    }
    
    .bid-btn {
      padding: 12px 24px;
      border: none;
      border-radius: 12px;
      background: linear-gradient(135deg, var(--page-mint), var(--page-blue-300));
      color: var(--page-blue-900);
      font-weight: 600;
      cursor: pointer;
      transition: transform 0.3s;
    }
    
    .bid-btn:hover {
      transform: translateY(-2px);
    }
    
    .bid-btn:disabled {
      background: rgba(100, 152, 255, 0.3);
      color: rgba(210, 224, 253, 0.5);
      cursor: not-allowed;
    }
    
    .modal {
      display: none;
      position: fixed;
      inset: 0;
      background: rgba(3, 9, 30, 0.9);
      backdrop-filter: blur(8px);
      z-index: 1000;
      align-items: center;
      justify-content: center;
      padding: 20px;
    }
    
    .modal.active {
      display: flex;
    }
    
    .modal-content {
      background: var(--panel-glass);
      border: 1px solid var(--panel-border);
      border-radius: 24px;
      padding: 32px;
      max-width: 600px;
      width: 100%;
      max-height: 90vh;
      overflow-y: auto;
    }
  </style>
</head>
<body>
  <div class="page-shell">
    <aside id="sidebar">
      <a class="back-link" href="dashboard.php">← Dashboard</a>
      <div class="aside-welcome">
        <div class="aside-avatar">
          <img src="<?php echo !empty($user['profile_picture']) ? htmlspecialchars($user['profile_picture']) : 'front/assets/images/default-avatar.png'; ?>" alt="User avatar">
        </div>
        <div>
          <p class="welcome-tag">Job Seeker</p>
          <h3><?php echo htmlspecialchars($user['username']); ?></h3>
          <p class="welcome-meta"><?php echo $is_verified ? '✓ Verified' : '⚠ Not Verified'; ?></p>
        </div>
      </div>
      <div>
        <h2 class="page-title">Find Jobs</h2>
        <p class="side-description">Browse available jobs and submit your bids. <?php echo !$is_verified ? 'Complete verification to start bidding.' : ''; ?></p>
      </div>
    </aside>
    
    <main>
      <?php if (isset($success_message)): ?>
        <div style="padding: 16px; background: rgba(77, 225, 193, 0.2); border: 1px solid rgba(77, 225, 193, 0.4); border-radius: 12px; color: var(--page-mint); margin-bottom: 24px;">
          ✓ <?php echo htmlspecialchars($success_message); ?>
        </div>
      <?php endif; ?>
      
      <?php if (isset($error_message)): ?>
        <div style="padding: 16px; background: rgba(239, 68, 68, 0.2); border: 1px solid rgba(239, 68, 68, 0.4); border-radius: 12px; color: #ef4444; margin-bottom: 24px;">
          ✗ <?php echo htmlspecialchars($error_message); ?>
        </div>
      <?php endif; ?>
      
      <?php if (!$is_verified): ?>
        <div style="padding: 20px; background: rgba(251, 191, 36, 0.2); border: 1px solid rgba(251, 191, 36, 0.4); border-radius: 12px; color: #fbbf24; margin-bottom: 24px;">
          <strong>⚠ Verification Required</strong><br>
          You must complete profile verification before bidding on jobs.
          <a href="verify-profile.php" style="display: inline-block; margin-top: 12px; padding: 10px 20px; background: rgba(251, 191, 36, 0.3); border-radius: 8px; color: #fbbf24; text-decoration: none; font-weight: 600;">Complete Verification →</a>
        </div>
      <?php endif; ?>
      
      <section>
        <h2 style="font-size: clamp(1.3rem, 3vw, 1.6rem); margin-bottom: 20px; color: var(--page-white);">💼 Available Jobs (<?php echo count($jobs); ?>)</h2>
        
        <div style="display: grid; gap: 24px;">
          <?php if (empty($jobs)): ?>
            <div style="padding: 40px; text-align: center; background: var(--panel-glass); border: 1px solid var(--panel-border); border-radius: 20px;">
              <p style="font-size: 1.2rem; color: rgba(216, 230, 255, 0.7);">No jobs available at the moment. Check back later!</p>
            </div>
          <?php else: ?>
            <?php foreach ($jobs as $job): ?>
              <article class="job-card">
                <span class="job-badge"><?php echo htmlspecialchars($job['job_type']); ?></span>
                <h3 class="job-title"><?php echo htmlspecialchars($job['title']); ?></h3>
                
                <div class="job-meta">
                  <span>💰 ₦<?php echo number_format($job['budget'], 2); ?></span>
                  <span>📍 <?php echo htmlspecialchars($job['location'] ?? 'Remote'); ?></span>
                  <span>👥 <?php echo $job['slots_available'] - $job['slots_filled']; ?> slots left</span>
                  <span>📅 <?php echo date('M d, Y', strtotime($job['created_at'])); ?></span>
                </div>
                
                <p class="job-description"><?php echo nl2br(htmlspecialchars($job['description'])); ?></p>
                
                <?php if ($job['requirements']): ?>
                  <div style="margin-bottom: 16px;">
                    <strong style="color: var(--page-white);">Requirements:</strong>
                    <p style="color: rgba(216, 230, 255, 0.85); margin-top: 8px;"><?php echo nl2br(htmlspecialchars($job['requirements'])); ?></p>
                  </div>
                <?php endif; ?>
                
                <?php if ($job['user_has_bid']): ?>
                  <button class="bid-btn" disabled>Already Bid</button>
                <?php else: ?>
                  <button class="bid-btn" onclick="openBidModal(<?php echo $job['id']; ?>, '<?php echo htmlspecialchars($job['title'], ENT_QUOTES); ?>')" <?php echo !$is_verified ? 'disabled' : ''; ?>>
                    <?php echo $is_verified ? 'Submit Bid' : 'Verification Required'; ?>
                  </button>
                <?php endif; ?>
              </article>
            <?php endforeach; ?>
          <?php endif; ?>
        </div>
      </section>
      
      <nav class="mobile-fintech-footer">
        <a href="dashboard.php">
          <svg viewBox="0 0 24 24"><path d="M12 3a9 9 0 1 1 0 18 9 9 0 0 1 0-18Zm1 4h-2v6h6v-2h-4V7Z"/></svg>
          <span>Dashboard</span>
        </a>
        <a href="find-jobs.php" class="active">
          <svg viewBox="0 0 24 24"><path d="M20 6h-4V4c0-1.1-.9-2-2-2h-4c-1.1 0-2 .9-2 2v2H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V8c0-1.1-.9-2-2-2zM10 4h4v2h-4V4zm10 16H4V8h16v12z"/></svg>
          <span>Jobs</span>
        </a>
        <a href="my-bids.php">
          <svg viewBox="0 0 24 24"><path d="M9 11H7v2h2v-2zm4 0h-2v2h2v-2zm4 0h-2v2h2v-2zm2-7h-1V2h-2v2H8V2H6v2H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 16H5V9h14v11z"/></svg>
          <span>My Bids</span>
        </a>
        <a href="profile.php">
          <svg viewBox="0 0 24 24"><path d="M12 2a6 6 0 0 1 6 6c0 3.31-2.69 6-6 6s-6-2.69-6-6a6 6 0 0 1 6-6Zm0 14c4.42 0 8 1.79 8 4v2H4v-2c0-2.21 3.58-4 8-4Z"/></svg>
          <span>Profile</span>
        </a>
      </nav>
    </main>
  </div>
  
   Bid Modal 
  <div id="bidModal" class="modal">
    <div class="modal-content">
      <h2 style="margin-top: 0; color: var(--page-white);">Submit Your Bid</h2>
      <p id="modalJobTitle" style="color: rgba(216, 230, 255, 0.7); margin-bottom: 24px;"></p>
      
      <form method="POST">
        <input type="hidden" name="job_id" id="modalJobId" />
        
        <div style="margin-bottom: 20px;">
          <label style="display: block; margin-bottom: 8px; color: rgba(216, 230, 255, 0.9); font-weight: 600;">Your Proposed Rate (₦)</label>
          <input type="number" name="proposed_rate" required min="0" step="0.01" style="width: 100%; padding: 12px; border-radius: 10px; border: 1px solid rgba(86, 139, 241, 0.3); background: rgba(13, 24, 62, 0.5); color: var(--page-white); font-size: 1rem;" />
        </div>
        
        <div style="margin-bottom: 20px;">
          <label style="display: block; margin-bottom: 8px; color: rgba(216, 230, 255, 0.9); font-weight: 600;">Cover Letter</label>
          <textarea name="cover_letter" required rows="6" placeholder="Explain why you're the best fit for this job..." style="width: 100%; padding: 12px; border-radius: 10px; border: 1px solid rgba(86, 139, 241, 0.3); background: rgba(13, 24, 62, 0.5); color: var(--page-white); font-size: 1rem; resize: vertical;"></textarea>
        </div>
        
        <div style="display: flex; gap: 12px;">
          <button type="button" onclick="closeBidModal()" style="flex: 1; padding: 12px; border: 1px solid rgba(86, 139, 241, 0.3); border-radius: 10px; background: transparent; color: var(--page-white); cursor: pointer;">Cancel</button>
          <button type="submit" style="flex: 1; padding: 12px; border: none; border-radius: 10px; background: linear-gradient(135deg, var(--page-mint), var(--page-blue-300)); color: var(--page-blue-900); font-weight: 600; cursor: pointer;">Submit Bid</button>
        </div>
      </form>
    </div>
  </div>
  
  <script>
    function openBidModal(jobId, jobTitle) {
      document.getElementById('modalJobId').value = jobId;
      document.getElementById('modalJobTitle').textContent = jobTitle;
      document.getElementById('bidModal').classList.add('active');
    }
    
    function closeBidModal() {
      document.getElementById('bidModal').classList.remove('active');
    }
    
    // Close modal on outside click
    document.getElementById('bidModal').addEventListener('click', function(e) {
      if (e.target === this) {
        closeBidModal();
      }
    });
  </script>
</body>
</html>
