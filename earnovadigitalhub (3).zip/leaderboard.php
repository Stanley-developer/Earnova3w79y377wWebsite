<?php
session_start();
require_once 'config/database.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: signin.php');
    exit();
}

$user_id = $_SESSION['user_id'];

// Fetch current user data
$user_query = "SELECT u.*, b.total_balance, b.task_earnings, b.referral_earnings 
               FROM users u 
               LEFT JOIN balances b ON u.id = b.user_id 
               WHERE u.id = ?";
$stmt = $conn->prepare($user_query);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$user_result = $stmt->get_result();
$user = $user_result->fetch_assoc();

// Fetch top earners (top 10 by total_balance)
$top_earners_query = "SELECT u.id, u.username, u.full_name, u.membership_type, u.profile_picture, b.total_balance 
                      FROM users u 
                      INNER JOIN balances b ON u.id = b.user_id 
                      ORDER BY b.total_balance DESC 
                      LIMIT 10";
$top_earners_result = $conn->query($top_earners_query);
$top_earners = [];
$rank = 1;
while ($row = $top_earners_result->fetch_assoc()) {
    $row['rank'] = $rank++;
    $top_earners[] = $row;
}

// Fetch top referrers (top 10 by referral count)
$top_referrers_query = "SELECT u.id, u.username, u.full_name, u.membership_type, u.profile_picture,
                        COUNT(r.id) as referral_count,
                        SUM(CASE WHEN r.membership_type = 'premium' THEN 1 ELSE 0 END) as premium_referrals,
                        b.referral_earnings
                        FROM users u 
                        LEFT JOIN users r ON r.referred_by = u.id
                        LEFT JOIN balances b ON u.id = b.user_id
                        GROUP BY u.id 
                        HAVING referral_count > 0
                        ORDER BY referral_count DESC 
                        LIMIT 10";
$top_referrers_result = $conn->query($top_referrers_query);
$top_referrers = [];
$rank = 1;
while ($row = $top_referrers_result->fetch_assoc()) {
    $row['rank'] = $rank++;
    $top_referrers[] = $row;
}

// Fetch recent top transactions for ticker
$recent_transactions_query = "SELECT u.username, t.amount, t.transaction_type, t.created_at 
                              FROM transactions t 
                              INNER JOIN users u ON t.user_id = u.id 
                              WHERE t.transaction_type IN ('withdrawal', 'referral_commission', 'task_reward')
                              ORDER BY t.created_at DESC 
                              LIMIT 10";
$recent_transactions_result = $conn->query($recent_transactions_query);
$recent_transactions = [];
while ($row = $recent_transactions_result->fetch_assoc()) {
    $recent_transactions[] = $row;
}

// Format currency
function formatCurrency($amount) {
    return '₦' . number_format($amount, 2);
}

// Format time ago
function timeAgo($datetime) {
    $timestamp = strtotime($datetime);
    $diff = time() - $timestamp;
    
    if ($diff < 60) return $diff . ' sec ago';
    if ($diff < 3600) return floor($diff / 60) . ' min ago';
    if ($diff < 86400) return floor($diff / 3600) . ' hr ago';
    return floor($diff / 86400) . ' days ago';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>FlowEarner Leaderboard</title>
  <style>
    :root {
      --page-blue-900: #030922;
      --page-blue-700: #0a164a;
      --page-blue-500: #142a7e;
      --page-blue-300: #2c5bf5;
      --page-mint: #4de1c1;
      --page-white: #f5f9ff;
      /* Added gold/yellow color scheme for leaderboard page */
      --leaderboard-gold: #fbbf24;
      --leaderboard-amber: #f59e0b;
      --leaderboard-yellow: #eab308;
      --panel-glass: rgba(13, 24, 62, 0.84);
      --panel-border: rgba(86, 139, 241, 0.3);
      --shadow-heavy: 0 40px 120px rgba(4, 10, 36, 0.65);
      --transition-long: 0.85s cubic-bezier(0.19, 1, 0.22, 1);
      --transition-short: 0.4s ease;
    }

    * { box-sizing: border-box; margin: 0; padding: 0; }

    body {
      font-family: "Titillium Web", "Segoe UI", sans-serif;
      background: radial-gradient(circle at 0% 0%, rgba(251, 191, 36, 0.28), transparent 55%),
                  radial-gradient(circle at 100% 0%, rgba(77, 225, 193, 0.18), transparent 45%),
                  linear-gradient(180deg, var(--page-blue-900), var(--page-blue-700));
      color: var(--page-white);
      overflow-x: hidden;
      min-height: 100vh;
    }

    /* Fixed sidebar layout structure */
    .page-shell {
      display: flex;
      min-height: 100vh;
    }

    aside {
      width: 320px;
      position: fixed;
      left: 0;
      top: 0;
      height: 100vh;
      overflow-y: auto;
      /* Unique gold/yellow gradient for leaderboard aside */
      background: linear-gradient(180deg, rgba(251, 191, 36, 0.15), rgba(245, 158, 11, 0.08)), rgba(5, 15, 44, 0.95);
      backdrop-filter: blur(18px);
      padding: clamp(20px, 3vw, 36px) clamp(16px, 2.5vw, 32px);
      display: flex;
      flex-direction: column;
      gap: clamp(20px, 2.5vw, 32px);
      border-right: 1px solid rgba(251, 191, 36, 0.3);
      z-index: 100;
      transition: transform var(--transition-short);
    }

    main {
      margin-left: 320px;
      flex: 1;
      padding: clamp(24px, 4vw, 42px) clamp(16px, 3vw, 48px);
      display: grid;
      gap: clamp(24px, 3vw, 42px);
    }

    .back-link {
      display: inline-flex;
      align-items: center;
      gap: 10px;
      font-weight: 600;
      font-size: clamp(0.7rem, 1.5vw, 0.85rem);
      letter-spacing: 0.1em;
      text-transform: uppercase;
      color: rgba(210, 226, 255, 0.78);
      text-decoration: none;
      transition: color var(--transition-short), transform var(--transition-short);
    }

    .back-link:hover { color: var(--leaderboard-gold); transform: translateX(-4px); }

    .aside-welcome {
      display: grid;
      grid-template-columns: auto 1fr;
      align-items: center;
      gap: clamp(12px, 1.5vw, 16px);
      /* Gold border for leaderboard page */
      background: rgba(8, 21, 64, 0.92);
      border: 1px solid rgba(251, 191, 36, 0.35);
      border-radius: 20px;
      padding: clamp(14px, 1.8vw, 18px);
      box-shadow: 0 18px 48px rgba(3, 9, 30, 0.5);
    }

    .aside-avatar {
      width: clamp(52px, 8vw, 64px);
      height: clamp(52px, 8vw, 64px);
      border-radius: 50%;
      overflow: hidden;
      /* Gold border for avatar */
      border: 4px solid rgba(251, 191, 36, 0.45);
      box-shadow: 0 14px 34px rgba(3, 9, 30, 0.55);
    }

    .aside-avatar img {
      width: 100%;
      display: block;
    }

    .welcome-tag {
      font-size: clamp(0.65rem, 1.2vw, 0.75rem);
      letter-spacing: 0.12em;
      text-transform: uppercase;
      color: rgba(205, 219, 255, 0.62);
    }

    .aside-welcome h3 {
      margin: 6px 0 4px;
      font-size: clamp(0.95rem, 1.8vw, 1.12rem);
      letter-spacing: 0.04em;
      color: var(--page-white);
    }

    .welcome-meta {
      font-size: clamp(0.7rem, 1.3vw, 0.8rem);
      letter-spacing: 0.08em;
      color: rgba(149, 183, 255, 0.7);
    }

    .page-title {
      font-size: clamp(1.5rem, 3.5vw, 2rem);
      letter-spacing: 0.1em;
      text-transform: uppercase;
      margin: 0 0 clamp(8px, 1.2vw, 12px);
      font-weight: 700;
    }

    .side-description {
      color: rgba(206, 224, 255, 0.74);
      line-height: 1.7;
      font-size: clamp(0.85rem, 1.5vw, 0.95rem);
    }

    .vector-cluster {
      position: relative;
      border-radius: 24px;
      padding: clamp(18px, 2.5vw, 24px);
      /* Gold gradient for leaderboard vector cluster */
      background: linear-gradient(135deg, rgba(251, 191, 36, 0.25), rgba(245, 158, 11, 0.15)), rgba(12, 29, 82, 0.9);
      box-shadow: var(--shadow-heavy);
      overflow: hidden;
    }

    .vector-cluster::after {
      content: "";
      position: absolute;
      width: 320px;
      height: 320px;
      top: -150px;
      right: -120px;
      border-radius: 50%;
      /* Gold glow effect */
      background: radial-gradient(circle, rgba(251, 191, 36, 0.35), transparent 60%);
    }

    .vector-cluster img {
      width: 100%;
      border-radius: 18px;
      display: block;
      filter: drop-shadow(0 28px 80px rgba(3, 8, 30, 0.6));
    }

    .leaderboard-hero {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
      gap: clamp(20px, 2.5vw, 28px);
      align-items: center;
      background: var(--panel-glass);
      border-radius: 26px;
      border: 1px solid var(--panel-border);
      padding: clamp(24px, 3.5vw, 38px);
      box-shadow: var(--shadow-heavy);
      position: relative;
      overflow: hidden;
    }

    .leaderboard-hero::before {
      content: "";
      position: absolute;
      inset: 0;
      background: url("front/assets/images/section2-left-img.png") center/contain no-repeat;
      opacity: 0.06;
    }

    .leaderboard-copy { position: relative; z-index: 2; }

    .leaderboard-copy h1 {
      margin: 0 0 clamp(8px, 1.5vw, 12px);
      font-size: clamp(1.8rem, 4vw, 2.4rem);
      font-weight: 700;
    }

    .leaderboard-copy p {
      margin: 0;
      color: rgba(218, 231, 255, 0.78);
      line-height: 1.7;
      font-size: clamp(0.9rem, 1.6vw, 1rem);
    }

    .leaderboard-tabs {
      display: flex;
      gap: clamp(12px, 2vw, 16px);
      margin-bottom: clamp(16px, 2vw, 20px);
    }

    .tab-btn {
      flex: 1;
      padding: clamp(12px, 2vw, 16px);
      border: none;
      border-radius: 16px;
      background: rgba(6, 16, 48, 0.9);
      border: 1px solid rgba(100, 154, 255, 0.24);
      color: rgba(205, 219, 255, 0.78);
      font-weight: 600;
      font-size: clamp(0.85rem, 1.5vw, 0.95rem);
      cursor: pointer;
      transition: all var(--transition-short);
    }

    .tab-btn.active {
      background: linear-gradient(135deg, rgba(251, 191, 36, 0.35), rgba(245, 158, 11, 0.25));
      border-color: rgba(251, 191, 36, 0.5);
      color: var(--page-white);
    }

    .tab-btn:hover {
      transform: translateY(-2px);
    }

    .leaderboard-list {
      display: grid;
      gap: clamp(16px, 2vw, 20px);
    }

    .leaderboard-card {
      padding: clamp(18px, 2.5vw, 24px);
      border-radius: 20px;
      background: rgba(6, 16, 48, 0.9);
      border: 1px solid rgba(100, 154, 255, 0.24);
      box-shadow: var(--shadow-heavy);
      position: relative;
      overflow: hidden;
      transition: transform var(--transition-short);
      display: grid;
      grid-template-columns: auto 1fr auto;
      align-items: center;
      gap: clamp(12px, 2vw, 16px);
    }

    .leaderboard-card:hover {
      transform: translateY(-2px);
    }

    .leaderboard-card::after {
      content: "";
      position: absolute;
      width: 100px;
      height: 100px;
      top: -20px;
      right: -14px;
      border-radius: 50%;
      background: radial-gradient(circle, rgba(251, 191, 36, 0.28), transparent 60%);
    }

    /* Special styling for top 3 */
    .leaderboard-card.rank-1 {
      border-color: rgba(251, 191, 36, 0.6);
      background: linear-gradient(135deg, rgba(251, 191, 36, 0.15), rgba(6, 16, 48, 0.9));
    }

    .leaderboard-card.rank-2 {
      border-color: rgba(192, 192, 192, 0.6);
      background: linear-gradient(135deg, rgba(192, 192, 192, 0.15), rgba(6, 16, 48, 0.9));
    }

    .leaderboard-card.rank-3 {
      border-color: rgba(205, 127, 50, 0.6);
      background: linear-gradient(135deg, rgba(205, 127, 50, 0.15), rgba(6, 16, 48, 0.9));
    }

    .rank-badge {
      width: clamp(48px, 8vw, 60px);
      height: clamp(48px, 8vw, 60px);
      border-radius: 50%;
      background: rgba(44, 92, 240, 0.62);
      display: grid;
      place-items: center;
      font-size: clamp(1.2rem, 2vw, 1.5rem);
      font-weight: 700;
      position: relative;
      z-index: 2;
    }

    .rank-1 .rank-badge {
      background: linear-gradient(135deg, rgba(251, 191, 36, 0.8), rgba(245, 158, 11, 0.8));
    }

    .rank-2 .rank-badge {
      background: linear-gradient(135deg, rgba(192, 192, 192, 0.8), rgba(169, 169, 169, 0.8));
    }

    .rank-3 .rank-badge {
      background: linear-gradient(135deg, rgba(205, 127, 50, 0.8), rgba(184, 115, 51, 0.8));
    }

    .user-info {
      position: relative;
      z-index: 2;
    }

    .user-info strong {
      font-size: clamp(0.95rem, 1.7vw, 1.1rem);
      font-weight: 600;
      display: block;
      margin-bottom: 4px;
    }

    .user-info span {
      color: rgba(205, 219, 255, 0.7);
      letter-spacing: 0.08em;
      text-transform: uppercase;
      font-size: clamp(0.7rem, 1.3vw, 0.8rem);
    }

    .user-stats {
      position: relative;
      z-index: 2;
      text-align: right;
    }

    .user-stats .amount {
      font-size: clamp(1rem, 1.8vw, 1.2rem);
      font-weight: 700;
      color: var(--leaderboard-gold);
      display: block;
      margin-bottom: 4px;
    }

    .user-stats .meta {
      color: rgba(205, 219, 255, 0.7);
      font-size: clamp(0.7rem, 1.3vw, 0.8rem);
    }

    .ticker {
      border-radius: 24px;
      border: 1px solid rgba(251, 191, 36, 0.32);
      background: rgba(8, 18, 52, 0.78);
      padding: clamp(12px, 1.8vw, 16px);
      box-shadow: var(--shadow-heavy);
      overflow: hidden;
    }

    .ticker-track {
      display: inline-flex;
      gap: 42px;
      animation: tickerMove 30s linear infinite;
      letter-spacing: 0.16em;
      text-transform: uppercase;
      color: rgba(204, 228, 255, 0.82);
      font-weight: 600;
      font-size: clamp(0.7rem, 1.3vw, 0.8rem);
      white-space: nowrap;
    }

    @keyframes tickerMove { from { transform: translateX(0); } to { transform: translateX(-50%); } }

    .section-white {
      background: var(--panel-glass);
      border: 1px solid var(--panel-border);
      box-shadow: var(--shadow-heavy);
      border-radius: 26px;
      box-shadow: var(--shadow-heavy);
      padding: clamp(24px, 3.5vw, 36px);
      position: relative;
      overflow: hidden;
    }

    .section-white::before {
      content: "";
      position: absolute;
      inset: 0;
      background: radial-gradient(circle at 80% 20%, rgba(44, 92, 240, 0.14), transparent 60%);
    }

    .section-white h2 {
      margin-top: 0;
      /* color: var(--page-blue-500); */
      font-size: 18px;
      font-weight: 700;
    }

    .section-white p {
      /* color: rgba(20, 42, 126, 0.68); */
      line-height: 1.7;
      font-size: 13px;
      margin-top: 20px;
    }

    .leaderboard-chip-row {
      position: relative;
      z-index: 2;
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
      gap: clamp(14px, 2vw, 18px);
      margin-top: clamp(18px, 2.5vw, 24px);
    }

    .leaderboard-chip {
      padding: clamp(14px, 2vw, 18px);
      border-radius: 18px;
      background: rgba(44, 92, 240, 0.08);
      border: 1px solid rgba(44, 92, 240, 0.18);
      /* color: var(--page-blue-500); */
      font-weight: 600;
      font-size: clamp(0.85rem, 1.5vw, 0.95rem);
      letter-spacing: 0.02em;
      display: grid;
      gap: 6px;
    }

    .leaderboard-chip span {
      font-size: clamp(0.65rem, 1.2vw, 0.75rem);
      letter-spacing: 0.1em;
      text-transform: uppercase;
      /* color: rgba(20, 42, 126, 0.6); */
    }

    
    /* Updated mobile footer with 5 icons */
    .mobile-fintech-footer {
      display: none;
      position: fixed;
      left: 12px;
      right: 12px;
      bottom: 16px;
      padding: 10px;
      background: rgba(5, 15, 44, 0.95);
      border: 1px solid rgba(86, 139, 241, 0.35);
      border-radius: 32px;
      backdrop-filter: blur(20px);
      box-shadow: 0 20px 60px rgba(4, 10, 36, 0.7);
      justify-content: space-around;
      align-items: center;
      z-index: 90;
    }

    .mobile-fintech-footer a {
      flex: 1;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      gap: 4px;
      text-decoration: none;
      color: rgba(205, 219, 255, 0.75);
      font-size: 0.65rem;
      letter-spacing: 0.06em;
      text-transform: uppercase;
      transition: all var(--transition-short);
      padding: 8px 4px;
      border-radius: 16px;
    }

    .card-badge {
      display: inline-block;
      padding: 8px 16px;
      background: rgba(77, 225, 193, 0.2);
      border: 1px solid rgba(77, 225, 193, 0.3);
      border-radius: 20px;
      font-size: clamp(0.7rem, 1.5vw, 0.75rem);
      letter-spacing: 0.1em;
      text-transform: uppercase;
      color: var(--page-mint);
      margin-bottom: 16px;
      font-weight: 600;
    }

    /* Special styling for middle icon (3rd icon - Withdraw) */
    /* .mobile-fintech-footer a:nth-child(3) {
      position: relative;
      transform: translateY(-12px);
    } */

    .mobile-fintech-footer a:nth-child(3) .icon-wrapper {
      width: 56px;
      height: 56px;
      border-radius: 50%;
      background: linear-gradient(135deg, rgba(77, 225, 193, 0.25), rgba(47, 91, 234, 0.25));
      backdrop-filter: blur(12px);
      border: 2px solid rgba(77, 225, 193, 0.4);
      display: flex;
      align-items: center;
      justify-content: center;
      box-shadow: 0 8px 24px rgba(77, 225, 193, 0.3);
    }

    .mobile-fintech-footer a:nth-child(3) svg {
      width: 28px;
      height: 28px;
    }

    .mobile-fintech-footer a.active {
      color: var(--page-mint);
    }

    .mobile-fintech-footer svg {
      width: 22px;
      height: 22px;
      fill: currentColor;
      filter: drop-shadow(0 4px 12px rgba(4, 10, 36, 0.4));
    }

    .mobile-fintech-footer a:hover {
      color: var(--page-mint);
      transform: translateY(-2px);
    }

    .mobile-fintech-footer a:nth-child(3):hover {
      transform: translateY(-14px);
    }
    footer {
      padding: clamp(32px, 5vw, 48px) 0 clamp(24px, 3.5vw, 36px);
      background: linear-gradient(180deg, rgba(1, 5, 16, 0.95), rgba(1, 4, 12, 0.98));
      border-top: 1px solid rgba(86, 136, 230, 0.2);
    }

    .footer-grid {
      max-width: 1020px;
      margin: 0 auto;
      padding: 0 clamp(16px, 3vw, 32px);
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(160px, 1fr));
      gap: clamp(18px, 2.5vw, 24px);
    }

    .footer-list h4 {
      text-transform: uppercase;
      letter-spacing: 0.12em;
      font-size: clamp(0.7rem, 1.3vw, 0.82rem);
      margin-bottom: clamp(12px, 1.8vw, 16px);
      color: rgba(181, 201, 240, 0.76);
      font-weight: 600;
    }

    .footer-list ul {
      list-style: none;
      display: grid;
      gap: clamp(8px, 1.5vw, 12px);
    }

    .footer-list a {
      color: rgba(210, 224, 253, 0.7);
      font-size: clamp(0.8rem, 1.4vw, 0.9rem);
      text-decoration: none;
      transition: color var(--transition-short);
    }

    .footer-list a:hover { color: var(--page-mint); }

    .footer-brand {
      text-align: center;
      text-transform: uppercase;
      letter-spacing: 0.14em;
      color: rgba(160, 180, 226, 0.68);
      margin-top: clamp(24px, 3.5vw, 32px);
      font-size: clamp(0.65rem, 1.2vw, 0.76rem);
    }

    /* Mobile responsive layout */
    @media (max-width: 960px) {
      .page-shell {
        flex-direction: column;
      }

      aside {
        width: 100%;
        height: auto;
        position: relative;
        top: 0;
        border-right: none;
        border-bottom: 1px solid rgba(251, 191, 36, 0.3);
        overflow-y: visible;
      }

     
      main {
        margin-left: 0;
        padding-bottom: 120px;
      }

      .mobile-fintech-footer {
        display: flex;
      }
    }

    @media (max-width: 640px) {
      .leaderboard-hero {
        grid-template-columns: 1fr;
      }

      .leaderboard-tabs {
        flex-direction: column;
      }
    }
    
    .aside-welcome {
      display: none;
    }

    .vector-cluster {
      display: none;
    }

    .tab-content {
      display: none;
    }

    .tab-content.active {
      display: block;
    }

    .bar-leaderboard {
  display: flex;
  align-items: flex-end;
  justify-content: center;
  gap: 20px;
  padding: 20px 0;
  height: 340px;
  position: relative;
  margin-top: 60px;
  margin: 0 auto;
  width: 40%;
}

.bar-item {
  position: relative;
  text-align: center;
  flex: 1;
  max-width: 180px;
  transition: transform 0.4s ease;
}

.bar-item:hover {
  transform: translateY(-8px);
}

.user-cap {
  position: relative;
  display: inline-block;
}

.user-image {
  width: 60px;
  height: 60px;
  border-radius: 50%;
  border: 4px solid rgba(255,255,255,0.2);
  box-shadow: 0 10px 30px rgba(0,0,0,0.4);
}

.rank-badge {
  position: absolute;
  top: -8px;
  right: -8px;
  background: gold;
  color: #111;
  font-weight: 700;
  font-size: 0.8rem;
  padding: 6px 8px;
  border-radius: 50%;
  box-shadow: 0 4px 12px rgba(0,0,0,0.3);
}

.rank-badge {
  position: absolute;
  top: -8px;
  right: -8px;
  background: gold;
  color: #111;
  font-weight: 700;
  font-size: 0.8rem;
  padding: 6px 8px;
  border-radius: 50%;
  box-shadow: 0 4px 12px rgba(0,0,0,0.3);
}


.rank-1 .rank-badge { background: #fbbf24; }
.rank-2 .rank-badge { background: #c0c0c0; }
.rank-3 .rank-badge { background: #cd7f32; }

.bar {
  width: 100%;
  height: 180px;
  background: rgba(255,255,255,0.08);
  border-radius: 12px;
  margin-top: 20px;
  position: relative;
  overflow: hidden;
}

.bar-fill {
  position: absolute;
  bottom: 0;
  left: 0;
  width: 100%;
  height: var(--bar-value);
  background: linear-gradient(180deg, #fbbf24, #f59e0b);
  border-radius: 12px 12px 0 0;
  transition: height 1s ease;
}

.rank-2 .bar-fill {
  background: linear-gradient(180deg, #c0c0c0, #999);
}

.rank-3 .bar-fill {
  background: linear-gradient(180deg, #cd7f32, #b87333);
}

.username {
  margin-top: 5px;
  font-weight: 500;
  color: #fff;
  font-size: 1rem;
  font-size: 12px;
}

.amount {
  color: #fbbf24;
  font-weight: 700;
  margin-top: 4px;
  font-size: 9.5px;
}

  </style>
</head>
<body>

<?php include "embed.php"; ?>
  <div class="page-shell">
    <aside id="sidebar">
      <a class="back-link" href="dashboard.php">← Prev</a>
      <div class="aside-welcome">
        <div class="aside-avatar">
          <img src="front/assets/images/partners-icon6.png" alt="User avatar" />
        </div>
        <div>
          <p class="welcome-tag">Welcome back</p>
          <h3><?php echo htmlspecialchars($user['username']); ?></h3>
          <p class="welcome-meta">Rank: <?php echo $user['membership_type'] === 'premium' ? 'Premium' : 'Free'; ?></p>
        </div>
      </div>
      <div>
        <h2 class="page-title" style="font-size: 18px;">Leaderboard</h2>
        <p class="side-description">See who's dominating the FlowEarner ecosystem. Track top earners and referrers in real-time.</p>
      </div>
      <div class="vector-cluster">
        <img src="front/assets/images/header-right-img.png" alt="Leaderboard vector" />
      </div>
    </aside>
    <main>
    

      <section>

      
          <div class="tab-content active" id="top-earners">
  <div class="bar-leaderboard">
    <?php if (!empty($top_earners)): ?>
      <?php foreach (array_slice($top_earners, 0, 3) as $earner): ?>
        <div class="bar-item rank-<?php echo $earner['rank']; ?>">
          <div class="user-cap">
            <img src="<?php echo !empty($earner['profile_picture']) ? htmlspecialchars($earner['profile_picture']) : 'front/assets/images/default-avatar.png'; ?>" alt="User Image" class="user-image">
            <div class="rank-badge">#<?php echo $earner['rank']; ?></div>
          </div>
           <h3 class="username"><?php echo htmlspecialchars($earner['username']); ?></h3>
          <p class="amount"><?php echo formatCurrency($earner['total_balance']); ?></p>
          <div class="bar" style="--bar-value: <?php echo $earner['total_balance'] / $top_earners[0]['total_balance'] * 100; ?>%">
            <div class="bar-fill"></div>
          </div>
         
        </div>
      <?php endforeach; ?>
    <?php else: ?>
      <p style="text-align:center;opacity:0.8;">No top earners yet.</p>
    <?php endif; ?>
  </div>


          <div class="leaderboard-list">
            <?php if (empty($top_earners)): ?>
              <div class="leaderboard-card">
                <p style="text-align: center; color: rgba(205, 219, 255, 0.7);">No top earners yet. Be the first!</p>
              </div>
            <?php else: ?>
              <?php foreach ($top_earners as $earner): ?>
                <article class="leaderboard-card rank-<?php echo $earner['rank']; ?>">
                  <div class="rank-badge">#<?php echo $earner['rank']; ?></div>
                  <div class="user-info">
                    <strong><?php echo htmlspecialchars($earner['username']); ?></strong>
                    <span><?php echo $earner['membership_type'] === 'premium' ? '⭐ Premium Member' : 'Free Member'; ?></span>
                  </div>
                  <div class="user-stats">
                    <span class="amount"><?php echo formatCurrency($earner['total_balance']); ?></span>
                    <span class="meta">Total Earnings</span>
                  </div>
                </article>
              <?php endforeach; ?>
            <?php endif; ?>
          </div>
        </div>

        </div>
      </section>

    

      <section class="section-white">
        <h2>Leaderboard Insights</h2>
        <p>The leaderboard updates in real-time as users earn and refer. Climb the ranks by completing tasks, referring friends, and upgrading to premium.</p>
        <div class="leaderboard-chip-row">
          <div class="leaderboard-chip"><span>Top Earner</span><?php echo !empty($top_earners) ? formatCurrency($top_earners[0]['total_balance']) : '₦0.00'; ?></div>
          <div class="leaderboard-chip"><span>Top Referrer</span><?php echo !empty($top_referrers) ? $top_referrers[0]['referral_count'] . ' referrals' : '0 referrals'; ?></div>
          <div class="leaderboard-chip"><span>Your Rank</span>Keep hustling!</div>
        </div>
      </section>
    </main>
  </div>

   <nav class="mobile-fintech-footer">
    
  <a href="dashboard.php">
    <svg viewBox="0 0 24 24"><path d="M12 3a9 9 0 1 1 0 18 9 9 0 0 1 0-18Zm1 4h-2v6h6v-2h-4V7Z"/></svg>
    <span>Dashboard</span>
  </a>

  <!-- Premium (crown icon) -->
  <a href="membership.php">
    <svg viewBox="0 0 24 24"><path d="M5 7l2.5 5 4.5-4 4.5 4L19 7l2 13H3l2-13Z"/></svg>
    <span>Premium</span>
  </a>

  <a href="daily-rewards.php">
    <svg viewBox="0 0 24 24"><path d="M20 3H4a1 1 0 0 0-1 1v16l5-3 5 3 5-3 5 3V4a1 1 0 0 0-1-1Zm-2 5-6.7 6.7L7 10.4l1.4-1.4 2.9 2.9L17.6 6 18 8Z"/></svg>
    <span>Rewards</span>
  </a>

  <!-- Referrals (users/people icon) -->
  <a href="refferrals.php">
    <svg viewBox="0 0 24 24"><path d="M12 12a4 4 0 1 0-4-4 4 4 0 0 0 4 4Zm0 2c-4 0-8 2-8 5v1h16v-1c0-3-4-5-8-5Zm7-6a3 3 0 1 0-3 3 3 3 0 0 0 3-3Zm-1 6a5 5 0 0 1 4 2.5v1.5h-4v-1.3a6.8 6.8 0 0 0-1.2-2.2A7.9 7.9 0 0 1 18 14Z"/></svg>
    <span>Referrals</span>
  </a>

  <a href="profile.php">
    <svg viewBox="0 0 24 24"><path d="M12 2a6 6 0 0 1 6 6c0 3.31-2.69 6-6 6s-6-2.69-6-6a6 6 0 0 1 6-6Zm0 14c4.42 0 8 1.79 8 4v2H4v-2c0-2.21 3.58-4 8-4Z"/></svg>
    <span>Profile</span>
  </a>
</nav>

  <script>
    let lastScrollTop = 0;
    const sidebar = document.getElementById('sidebar');
    
    window.addEventListener('scroll', function() {
      if (window.innerWidth <= 960) {
        let scrollTop = window.pageYOffset || document.documentElement.scrollTop;
        
        if (scrollTop > lastScrollTop && scrollTop > 100) {
          sidebar.classList.add('scrolled');
        } else if (scrollTop < lastScrollTop) {
          sidebar.classList.remove('scrolled');
        }
        
        lastScrollTop = scrollTop <= 0 ? 0 : scrollTop;
      }
    }, false);

    // Tab switching functionality
    const tabButtons = document.querySelectorAll('.tab-btn');
    const tabContents = document.querySelectorAll('.tab-content');

    tabButtons.forEach(button => {
      button.addEventListener('click', () => {
        // Remove active class from all buttons and contents
        tabButtons.forEach(btn => btn.classList.remove('active'));
        tabContents.forEach(content => content.classList.remove('active'));

        // Add active class to clicked button and corresponding content
        button.classList.add('active');
        const tabId = button.getAttribute('data-tab');
        document.getElementById(tabId).classList.add('active');
      });
    });
  </script>
</body>
</html>
