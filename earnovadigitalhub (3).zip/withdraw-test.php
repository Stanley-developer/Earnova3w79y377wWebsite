<?php
session_start();
require_once 'config/database.php';
require_once 'includes/session.php';
require_once 'includes/connect.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$user_id = $_SESSION['user_id'];
$success_message = '';
$error_message = '';

$stmt = $conn->prepare("SELECT username, full_name, email, membership_type, withdrawal_account_number, withdrawal_account_name, withdrawal_bank_name, withdrawal_bank_code FROM users WHERE id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();
$stmt->close();

// Fetch user balances
$stmt = $conn->prepare("SELECT total_balance, task_earnings, referral_earnings FROM balances WHERE user_id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$balance = $stmt->get_result()->fetch_assoc();
$stmt->close();

$stmt = $conn->prepare("SELECT COUNT(*) as referral_count FROM users WHERE referred_by = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$referral_data = $stmt->get_result()->fetch_assoc();
$referral_count = $referral_data['referral_count'];
$stmt->close();

$stmt = $conn->prepare("SELECT COUNT(*) as completed_task_withdrawals FROM withdrawals WHERE user_id = ? AND withdrawal_type = 'task' AND status = 'completed'");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$withdrawal_data = $stmt->get_result()->fetch_assoc();
$completed_task_withdrawals = $withdrawal_data['completed_task_withdrawals'];
$stmt->close();

// Fetch withdrawal statistics
$stmt = $conn->prepare("
    SELECT 
        COUNT(*) as total_withdrawals,
        COALESCE(SUM(CASE WHEN status = 'completed' THEN amount ELSE 0 END), 0) as total_withdrawn,
        COALESCE(SUM(CASE WHEN status = 'pending' OR status = 'processing' THEN amount ELSE 0 END), 0) as pending_amount
    FROM withdrawals 
    WHERE user_id = ?
");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$withdrawal_stats = $stmt->get_result()->fetch_assoc();
$stmt->close();

// Fetch recent withdrawals
$stmt = $conn->prepare("
    SELECT id, withdrawal_type, amount, status, payment_method, requested_at, processed_at
    FROM withdrawals 
    WHERE user_id = ? 
    ORDER BY requested_at DESC 
    LIMIT 10
");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$recent_withdrawals = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();

// Handle withdrawal request
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit_withdrawal'])) {
    $withdrawal_type = $_POST['withdrawal_type'];
    $amount = floatval($_POST['amount']);
    $payment_method = $_POST['payment_method'];
    $account_name = trim($_POST['account_name']);
    $account_number = trim($_POST['account_number']);
    $bank_code = $_POST['bank_code'] ?? '';
    $bank_name = $_POST['bank_name'];

    // Validation
    $errors = [];
    
    // Validate withdrawal type
    if (!in_array($withdrawal_type, ['referral', 'task'])) {
        $errors[] = "Invalid withdrawal type selected.";
    }
    
    if ($withdrawal_type === 'task') {
        // Rule 1: Free users cannot withdraw task earnings
        if ($user['membership_type'] === 'free') {
            $errors[] = "You need an account upgrade for withdrawal";
        }
        // Rule 2: Upgraded users need 5 referrals for first withdrawal
        elseif ($completed_task_withdrawals == 0 && $referral_count < 5) {
            $errors[] = "Please Refer 5 users to withdraw";
        }
        // Rule 3: After first withdrawal, need 5 additional referrals per withdrawal
        elseif ($completed_task_withdrawals > 0) {
            $required_referrals = ($completed_task_withdrawals + 1) * 5;
            if ($referral_count < $required_referrals) {
                $errors[] = "Please Refer additional 5 users to withdraw";
            }
        }
    }
    
    // Validate amount
    if ($amount <= 0) {
        $errors[] = "Please enter a valid amount.";
    }
    
    // Check minimum withdrawal amounts
    if ($withdrawal_type === 'referral' && $amount < 3000) {
        $errors[] = "Minimum referral withdrawal amount is ₦3,000.";
    }
    
    if ($withdrawal_type === 'task' && $amount < 55000) {
        $errors[] = "Minimum task earnings withdrawal amount is ₦55,000.";
    }
    
    // Check if user has sufficient balance
    $available_balance = ($withdrawal_type === 'referral') ? $balance['referral_earnings'] : $balance['task_earnings'];
    
    if ($amount > $available_balance) {
        $errors[] = "Insufficient balance";
    }
    
    // Validate payment details
    if (empty($account_name)) {
        $errors[] = "Account name is required.";
    }
    
    if (empty($account_number)) {
        $errors[] = "Account number is required.";
    }
    
    if ($payment_method === 'bank_transfer' && (empty($bank_code) || empty($bank_name))) {
        $errors[] = "Bank name is required for bank transfers.";
    }
    
    // If no errors, process withdrawal
    if (empty($errors)) {
        $conn->begin_transaction();
        
        try {
            // Create account details JSON
            $account_details = json_encode([
                'account_name' => $account_name,
                'account_number' => $account_number,
                'bank_name' => $bank_name,
                'bank_code' => $bank_code,
                'payment_method' => $payment_method
            ]);
            
            // Insert withdrawal request
            $status = ($withdrawal_type === 'referral') ? 'processing' : 'pending';
            $stmt = $conn->prepare("
                INSERT INTO withdrawals (user_id, withdrawal_type, amount, status, payment_method, account_details)
                VALUES (?, ?, ?, ?, ?, ?)
            ");
            $stmt->bind_param("isdsss", $user_id, $withdrawal_type, $amount, $status, $payment_method, $account_details);
            $stmt->execute();
            $withdrawal_id = $conn->insert_id;
            $stmt->close();
            
            // Deduct from user balance
            if ($withdrawal_type === 'referral') {
                $stmt = $conn->prepare("
                    UPDATE balances 
                    SET referral_earnings = referral_earnings - ?,
                        total_balance = total_balance - ?
                    WHERE user_id = ?
                ");
            } else {
                $stmt = $conn->prepare("
                    UPDATE balances 
                    SET task_earnings = task_earnings - ?,
                        total_balance = total_balance - ?
                    WHERE user_id = ?
                ");
            }
            $stmt->bind_param("ddi", $amount, $amount, $user_id);
            $stmt->execute();
            $stmt->close();
            
            // Record transaction
            $balance_type = ($withdrawal_type === 'referral') ? 'referral' : 'task';
            $description = ucfirst($withdrawal_type) . " withdrawal of ₦" . number_format($amount, 2);
            $stmt = $conn->prepare("
                INSERT INTO transactions (user_id, transaction_type, amount, balance_type, description, reference_id)
                VALUES (?, 'withdrawal', ?, ?, ?, ?)
            ");
            $reference = 'WD-' . $withdrawal_id;
            $stmt->bind_param("idsss", $user_id, $amount, $balance_type, $description, $reference);
            $stmt->execute();
            $stmt->close();
            
            $conn->commit();
            
            if ($withdrawal_type === 'referral') {
                $success_message = "Withdraw Successful";
            } else {
                $success_message = "Withdraw Successful";
            }
            
            // Refresh balances
            $stmt = $conn->prepare("SELECT total_balance, task_earnings, referral_earnings FROM balances WHERE user_id = ?");
            $stmt->bind_param("i", $user_id);
            $stmt->execute();
            $balance = $stmt->get_result()->fetch_assoc();
            $stmt->close();
            
        } catch (Exception $e) {
            $conn->rollback();
            $error_message = "An error occurred while processing your withdrawal. Please try again.";
        }
    } else {
        $error_message = reset($errors);

    }
}

// Fetch recent completed withdrawals for ticker
$stmt = $conn->prepare("
    SELECT u.username, w.amount, w.requested_at
    FROM withdrawals w
    JOIN users u ON w.user_id = u.id
    WHERE w.status = 'completed'
    ORDER BY w.processed_at DESC
    LIMIT 10
");
$stmt->execute();
$ticker_withdrawals = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();

$has_saved_method = !empty($user['withdrawal_account_number']);

// Fetch bank list from API or local file (example with placeholder)
// In a real scenario, this would involve an API call to get active bank codes and names.
$banks = [
    ['code' => '044', 'name' => 'Access Bank'],
    ['code' => '050', 'name' => 'ECOBANK NIGERIA'],
    ['code' => '070', 'name' => 'Fidelity Bank'],
    ['code' => '011', 'name' => 'First Bank of Nigeria'],
    ['code' => '058', 'name' => 'Guaranty Trust Bank'],
    ['code' => '030', 'name' => 'Keystone Bank'],
    ['code' => '001', 'name' => 'First City Monument Bank (FCMB)'],
    ['code' => '232', 'name' => 'Sterling Bank'],
    ['code' => '101', 'name' => 'Zenith Bank'],
    ['code' => '033', 'name' => 'United Bank for Africa (UBA)'],
    ['code' => '032', 'name' => 'Union Bank of Nigeria'],
    ['code' => '214', 'name' => 'First Central Credit Union'],
    // Add more banks as needed...
];
usort($banks, function($a, $b) { return strcmp($a['name'], $b['name']); }); // Sort alphabetically


?>
<?php include "doctype.php"; ?>
  <style>
    :root {
      --page-blue-900: #030922;
      --page-blue-700: #0a164a;
      --page-blue-500: #142a7e;
      --page-blue-300: #2c5bf5;
      --page-mint: #4de1c1;
      --page-white: #f5f9ff;
      --panel-glass: rgba(13, 24, 62, 0.84);
      --panel-border: rgba(86, 139, 241, 0.3);
      --shadow-heavy: 0 40px 120px rgba(4, 10, 36, 0.65);
      --transition-long: 0.85s cubic-bezier(0.19, 1, 0.22, 1);
      --transition-short: 0.4s ease;
      
      /* Added red/pink color scheme for withdrawal aside */
      --withdrawal-primary: #ff3366;
      --withdrawal-secondary: #ff6b8a;
      --withdrawal-dark: #1a0510;
      --withdrawal-glass: rgba(255, 51, 102, 0.15);
    }

    * { box-sizing: border-box; }

    body {
      margin: 0;
      font-family: "Titillium Web", "Segoe UI", sans-serif;
      background: radial-gradient(circle at 0% 0%, rgba(61, 116, 255, 0.28), transparent 55%),
                  radial-gradient(circle at 100% 0%, rgba(77, 225, 193, 0.2), transparent 45%),
                  linear-gradient(180deg, var(--page-blue-900), var(--page-blue-700));
      color: var(--page-white);
      overflow-x: hidden;
    }

     .page-shell {
      min-height: 100vh;
      display: flex;
    }

    aside {
      position: fixed;
      left: 0;
      top: 0;
      bottom: 0;
      width: 320px;
      background: rgba(5, 15, 44, 0.92);
      backdrop-filter: blur(18px);
      padding: clamp(1.25rem, 3vw, 2.25rem) clamp(1rem, 2.5vw, 2rem);
      display: flex;
      flex-direction: column;
      gap: clamp(1.25rem, 2.5vw, 2rem);
      border-right: 1px solid var(--panel-border);
      overflow-y: auto;
      z-index: 100;
      transition: transform var(--transition-short);
    }

    aside::before {
      content: "";
      position: absolute;
      inset: 0;
      background: 
        radial-gradient(circle at 20% 30%, rgba(251, 191, 36, 0.15), transparent 50%),
        radial-gradient(circle at 80% 70%, rgba(245, 158, 11, 0.12), transparent 45%);
      pointer-events: none;
    }

    main {
      margin-left: 320px;
      flex: 1;
      padding: clamp(2rem, 4vw, 2.625rem) clamp(1.5rem, 3vw, 3rem);
      display: grid;
      gap: clamp(2rem, 3.5vw, 2.625rem);
    }

    @media (max-width: 960px) {
      .page-shell {
        display: block;
      }

      aside {
        position: relative;
        top: 0;
        width: 100%;
        height: auto;
        border-right: none;
        border-bottom: 1px solid var(--panel-border);
        padding: clamp(1rem, 2.5vw, 1.75rem) clamp(0.875rem, 2vw, 1.25rem);
        gap: clamp(0.875rem, 2vw, 1.25rem);
      }

      aside.scrolled .page-title,
      aside.scrolled .side-description,
      aside.scrolled .vector-cluster {
        display: none;
      }

      aside.scrolled {
        padding: clamp(0.75rem, 1.5vw, 1rem) clamp(0.875rem, 2vw, 1.25rem);
      }

      aside.scrolled .aside-welcome {
        grid-template-columns: auto 1fr;
      }

      main {
        margin-left: 0;
        padding: clamp(1.5rem, 3vw, 2rem) clamp(0.625rem, 1.5vw, 1.25rem) 10rem;
      }

      .vector-cluster {
        display: none;
      }
    }

 .back-link {
      display: inline-flex;
      align-items: center;
      gap: 10px;
      font-weight: 600;
      font-size: clamp(0.75rem, 1.5vw, 0.875rem);
      letter-spacing: 0.1em;
      text-transform: uppercase;
      color: rgba(210, 226, 255, 0.78);
      transition: color var(--transition-short), transform var(--transition-short);
      text-decoration: none;
    }

    .back-link:hover { color: var(--page-white); transform: translateX(-4px); }

    .page-title {
      font-size: clamp(1rem, 3vw, 1.5rem);
      letter-spacing: 0.1em;
      text-transform: uppercase;
      margin: 0 0 clamp(0.5rem, 1vw, 0.75rem);
      font-weight: 700;
    }

    .side-description { 
      color: rgba(206, 224, 255, 0.74); 
      line-height: 1.7; 
      font-size: clamp(0.875rem, 1.5vw, 1rem);
    }

    .vector-cluster {
      position: relative;
      border-radius: 24px;
      padding: clamp(1rem, 2vw, 1.5rem);
      background: 
        linear-gradient(135deg, rgba(251, 191, 36, 0.3), rgba(217, 119, 6, 0.6)),
        rgba(12, 29, 82, 0.9);
      box-shadow: var(--shadow-heavy);
      overflow: hidden;
    }

    .vector-cluster::after {
      content: "";
      position: absolute;
      width: 320px;
      height: 320px;
      top: -150px;
      right: -120px;
      border-radius: 50%;
      background: radial-gradient(circle, rgba(245, 158, 11, 0.35), transparent 60%);
    }

    .vector-cluster img {
      width: 100%;
      border-radius: 18px;
      display: block;
      filter: drop-shadow(0 28px 80px rgba(251, 191, 36, 0.4));
    }


    main {
      padding: 42px;
      display: grid;
      gap: 42px;
    }

    .withdraw-hero {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
      gap: 28px;
      align-items: center;
      background: var(--panel-glass);
      border-radius: 26px;
      border: 1px solid var(--panel-border);
      padding: 38px;
      box-shadow: var(--shadow-heavy);
      position: relative;
      overflow: hidden;
    }

    .withdraw-hero::before {
      content: "";
      position: absolute;
      inset: 0;
      background: url("front/assets/images/section2-left-img.png") right/contain no-repeat;
      opacity: 0.08;
    }

    .withdraw-copy { position: relative; z-index: 2; }

    .withdraw-copy h1 {
      margin: 0 0 12px;
      font-size: clamp(1.8rem, 4vw, 2.4rem);
    }

    .withdraw-copy p {
      margin: 0;
      color: rgba(218, 231, 255, 0.78);
      line-height: 1.7;
      font-size: clamp(0.875rem, 2vw, 1rem);
    }

    .form-panel {
      background: rgba(9, 23, 66, 0.9);
      border: 1px solid var(--panel-border);
      border-radius: 24px;
      padding: 32px;
      box-shadow: var(--shadow-heavy);
    }

    .form-panel h2 {
      margin-top: 0;
      letter-spacing: 0.08em;
      text-transform: uppercase;
      font-size: clamp(1.2rem, 3vw, 1.5rem);
    }

    .form-row {
      display: grid;
      gap: 18px;
      margin-top: 24px;
    }

    label {
      font-size: clamp(0.8rem, 2vw, 0.9rem);
      letter-spacing: 0.08em;
      text-transform: uppercase;
      color: rgba(205, 219, 255, 0.7);
    }

    input, select, textarea {
      border: 1px solid rgba(99, 149, 255, 0.26);
      border-radius: 16px;
      padding: 14px 16px;
      background: rgba(5, 12, 36, 0.82);
      color: var(--page-white);
      font-size: clamp(0.875rem, 2vw, 1rem);
      transition: border-color var(--transition-short), box-shadow var(--transition-short);
    }

    input:focus, select:focus, textarea:focus {
      border-color: var(--page-mint);
      box-shadow: 0 0 0 3px rgba(77, 225, 193, 0.2);
      outline: none;
    }

    .action-buttons {
      margin-top: 24px;
      display: flex;
      gap: 16px;
      flex-wrap: wrap;
    }

    .btn-primary, .btn-ghost {
      border: none;
      border-radius: 18px;
      padding: 14px 26px;
      font-weight: 600;
      letter-spacing: 0.05em;
      text-transform: uppercase;
      cursor: pointer;
      transition: transform var(--transition-short), box-shadow var(--transition-short);
      font-size: clamp(0.8rem, 2vw, 0.9rem);
    }

    .btn-primary {
      background: linear-gradient(135deg, rgba(47, 91, 234, 0.95), rgba(77, 225, 193, 0.85));
      color: var(--page-blue-900);
      box-shadow: 0 24px 55px rgba(40, 90, 230, 0.45);
    }

    .btn-ghost {
      background: rgba(35, 70, 190, 0.62);
      color: var(--page-white);
      border: 1px solid rgba(115, 166, 255, 0.4);
    }

    .btn-primary:hover, .btn-ghost:hover { transform: translateY(-4px); }

    .status-panels {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
      gap: 22px;
    }

    .status-card {
      padding: 24px;
      border-radius: 20px;
      background: rgba(6, 16, 48, 0.9);
      border: 1px solid rgba(100, 154, 255, 0.24);
      box-shadow: var(--shadow-heavy);
      position: relative;
      overflow: hidden;
    }

    .status-card::after {
      content: "";
      position: absolute;
      width: 120px;
      height: 120px;
      top: -30px;
      right: -20px;
      border-radius: 50%;
      background: radial-gradient(circle, rgba(77, 225, 193, 0.28), transparent 60%);
    }

    .status-title {
      font-size: clamp(0.75rem, 2vw, 0.85rem);
      letter-spacing: 0.18em;
      text-transform: uppercase;
      color: rgba(205, 222, 255, 0.7);
    }

    .status-value {
      margin: 14px 0 6px;
      font-size: clamp(1.4rem, 3vw, 1.8rem);
      font-weight: 700;
    }

    .ticker {
      border-radius: 24px;
      border: 1px solid rgba(77, 225, 193, 0.32);
      background: rgba(8, 18, 52, 0.78);
      padding: 16px;
      box-shadow: var(--shadow-heavy);
      overflow: hidden;
    }

    .ticker-track {
      display: inline-flex;
      gap: 42px;
      animation: tickerMove 32s linear infinite;
      letter-spacing: 0.16em;
      text-transform: uppercase;
      color: rgba(204, 228, 255, 0.82);
      font-weight: 600;
      white-space: nowrap;
      font-size: clamp(0.75rem, 2vw, 0.9rem);
    }

    @keyframes tickerMove { from { transform: translateX(0); } to { transform: translateX(-50%); } }

    .vector-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
      gap: 20px;
    }

    .vector-panel {
      padding: 22px;
      border-radius: 18px;
      background: rgba(5, 15, 45, 0.88);
      border: 1px solid rgba(107, 162, 255, 0.25);
      box-shadow: 0 22px 60px rgba(3, 9, 30, 0.5);
    }

    .vector-panel img {
      width: 100%;
      border-radius: 14px;
      margin-top: 12px;
      filter: drop-shadow(0 20px 60px rgba(3, 8, 30, 0.6));
    }

    .timeline-box {
      margin-top: 30px;
      padding: 24px;
      border-radius: 20px;
      background: rgba(7, 18, 52, 0.86);
      border: 1px solid rgba(105, 156, 255, 0.3);
      box-shadow: 0 28px 80px rgba(3, 9, 30, 0.45);
      display: grid;
      gap: 18px;
    }

    .timeline-entry {
      display: flex;
      justify-content: space-between;
      align-items: center;
      gap: 12px;
      padding-bottom: 12px;
      border-bottom: 1px dashed rgba(103, 158, 255, 0.25);
    }

    .timeline-entry:last-child {
      border-bottom: none;
      padding-bottom: 0;
    }

    .timeline-entry strong {
      font-size: clamp(0.9rem, 2vw, 1rem);
    }

    .timeline-entry span {
      font-size: clamp(0.75rem, 2vw, 0.82rem);
      letter-spacing: 0.08em;
      text-transform: uppercase;
      color: rgba(202, 220, 255, 0.66);
    }

    .help-panel {
      position: sticky;
      top: 48px;
      border-radius: 20px;
      background: rgba(7, 18, 52, 0.86);
      border: 1px solid rgba(107, 162, 255, 0.3);
      padding: 24px;
      display: grid;
      gap: 14px;
    }

    .help-panel h4 {
      margin: 0;
      letter-spacing: 0.06em;
      text-transform: uppercase;
      font-size: clamp(1rem, 2vw, 1.1rem);
    }

    .help-panel a {
      color: rgba(77, 225, 193, 0.88);
      text-decoration: none;
      font-weight: 600;
    }

    footer {
      padding: 48px 0 36px;
      background: linear-gradient(180deg, rgba(1, 5, 16, 0.95), rgba(1, 4, 12, 0.98));
      border-top: 1px solid rgba(86, 136, 230, 0.2);
    }

    .footer-grid {
      max-width: 1020px;
      margin: 0 auto;
      padding: 0 32px;
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(160px, 1fr));
      gap: 24px;
    }

    .footer-list h4 {
      text-transform: uppercase;
      letter-spacing: 0.12em;
      font-size: clamp(0.75rem, 2vw, 0.82rem);
      margin-bottom: 16px;
      color: rgba(181, 201, 240, 0.76);
    }

    .footer-list ul {
      list-style: none;
      padding: 0;
      margin: 0;
      display: grid;
      gap: 12px;
    }

    .footer-list a {
      color: rgba(210, 224, 253, 0.7);
      font-size: clamp(0.8rem, 2vw, 0.9rem);
      transition: color var(--transition-short);
    }

    .footer-list a:hover { color: var(--page-mint); }

    .footer-brand {
      text-align: center;
      text-transform: uppercase;
      letter-spacing: 0.14em;
      color: rgba(160, 180, 226, 0.68);
      margin-top: 32px;
      font-size: clamp(0.7rem, 2vw, 0.76rem);
    }
.aside-welcome {
      display: grid;
      grid-template-columns: auto 1fr;
      align-items: center;
      gap: clamp(0.75rem, 1.5vw, 1rem);
      background: linear-gradient(135deg, rgba(44, 91, 245, 0.3), rgba(26, 58, 171, 0.2));
      border: 1px solid rgba(44, 91, 245, 0.5);
      box-shadow: 0 0 10px rgba(44, 91, 245, 0.6);
      border-radius: 20px;
      padding: clamp(0.875rem, 1.75vw, 1.125rem);
      
      position: relative;
      z-index: 2;
    }

    .aside-avatar {
      width: clamp(48px, 10vw, 64px);
      height: clamp(48px, 10vw, 64px);
      border-radius: 50%;
      overflow: hidden;
      border: 4px solid rgba(251, 191, 36, 0.35);
      box-shadow: 0 14px 34px rgba(3, 9, 30, 0.55);
    }

    .aside-avatar img {
      width: 100%;
      display: block;
    }

    .welcome-tag {
      margin: 0;
      font-size: clamp(0.6875rem, 1.25vw, 0.75rem);
      letter-spacing: 0.12em;
      text-transform: uppercase;
      color: rgba(205, 219, 255, 0.62);
    }

    .aside-welcome h3 {
      margin: clamp(0.25rem, 0.5vw, 0.375rem) 0 clamp(0.125rem, 0.25vw, 0.25rem);
      font-size: clamp(1rem, 2vw, 1.12rem);
      letter-spacing: 0.04em;
      color: var(--page-white);
      font-weight: 700;
    }

    .welcome-meta {
      font-size: clamp(0.75rem, 1.5vw, 0.8rem);
      letter-spacing: 0.08em;
      color: rgba(149, 183, 255, 0.7);
    }

    .section-white {
      background: rgba(245, 249, 255, 0.96);
      border: 1px solid rgba(60, 102, 212, 0.14);
      border-radius: 26px;
      box-shadow: var(--shadow-heavy);
      padding: 36px;
      color: var(--page-blue-700);
      position: relative;
      overflow: hidden;
    }

    .section-white h2,
    .section-white h3 {
      color: var(--page-blue-500);
      margin-top: 0;
      font-size: clamp(1.2rem, 3vw, 1.5rem);
    }

    .section-white p,
    .section-white span {
      color: rgba(20, 42, 126, 0.7);
      line-height: 1.7;
      font-size: clamp(0.875rem, 2vw, 1rem);
    }

    .white-pair-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
      gap: 20px;
      position: relative;
      z-index: 2;
    }

    .white-pair-card {
      padding: 20px;
      border-radius: 18px;
      background: rgba(44, 92, 240, 0.08);
      border: 1px solid rgba(44, 92, 240, 0.18);
      display: grid;
      gap: 10px;
    }

    .white-pair-card strong {
      font-size: clamp(1rem, 2vw, 1.1rem);
      color: var(--page-blue-500);
    }

     /* Updated mobile footer with 5 icons */
    .mobile-fintech-footer {
      display: none;
      position: fixed;
      left: 12px;
      right: 12px;
      bottom: 16px;
      padding: 10px;
      background: transparent;
      border: 1px solid rgba(86, 139, 241, 0.35);
      border-radius: 32px;
      backdrop-filter: blur(50px);
      box-shadow: 0 20px 60px rgba(4, 10, 36, 0.7);
      justify-content: space-around;
      align-items: center;
      z-index: 90;
    }

    .mobile-fintech-footer a {
      flex: 1;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      gap: 4px;
      text-decoration: none;
      color: rgba(205, 219, 255, 0.75);
      font-size: 0.45rem;
      letter-spacing: 0.06em;
      text-transform: uppercase;
      transition: all var(--transition-short);
      padding: 8px 4px;
      border-radius: 16px;
    }

    /* Special styling for middle icon (3rd icon - Withdraw) */
    /* .mobile-fintech-footer a:nth-child(3) {
      position: relative;
      transform: translateY(-12px);
    } */

    .mobile-fintech-footer a:nth-child(3) .icon-wrapper {
      width: 56px;
      height: 56px;
      border-radius: 50%;
      background: linear-gradient(135deg, rgba(77, 225, 193, 0.25), rgba(47, 91, 234, 0.25));
      backdrop-filter: blur(12px);
      border: 2px solid rgba(77, 225, 193, 0.4);
      display: flex;
      align-items: center;
      justify-content: center;
      box-shadow: 0 8px 24px rgba(77, 225, 193, 0.3);
    }

    .mobile-fintech-footer a:nth-child(3) svg {
      width: 28px;
      height: 28px;
    }

    .mobile-fintech-footer a.active {
      color: var(--page-mint);
    }

    .mobile-fintech-footer svg {
      width: 22px;
      height: 22px;
      fill: currentColor;
      filter: drop-shadow(0 4px 12px rgba(4, 10, 36, 0.4));
    }

    .mobile-fintech-footer a:hover {
      color: var(--page-mint);
      transform: translateY(-2px);
    }

    .mobile-fintech-footer a:nth-child(3):hover {
      transform: translateY(-14px);
    }

    @media (max-width: 680px) {
      body {
        padding-bottom: 100px;
      }

      .mobile-fintech-footer {
        display: flex;
      }
    }

    /* Reduce width of inputs, selects, and textareas in withdrawal forms */
form input,
form select,
form textarea {
  width: 80%;
  max-width: 420px;
  display: block;
  margin: 0 auto;
}

/* On smaller mobile screens, make them fit nicely */
@media (max-width: 600px) {
  form input,
  form select,
  form textarea {
    width: 100%;
    max-width: 100%;
  }
}


   
    @media (max-width: 860px) {
      .form-grid {
        grid-template-columns: 1fr;
      }

      .summary-panel {
        position: relative;
      }
    }

    @media (max-width: 680px) {
      body {
        padding-bottom: 160px;
      }

      aside {
        padding: 28px 20px;
      }

      main {
        padding: 32px 10px 160px;
      }

      .withdraw-hero,
      .form-panel,
      .status-panels,
      .ticker,
      .vector-grid,
      .timeline-box,
      .section-white {
        margin-left: 0;
        margin-right: 0;
      }

      .form-panel {
        padding: 28px 20px;
      }

      .status-card,
      .vector-panel {
        margin: 0;
      }

      
    }

    .receipt-overlay {
  position: fixed;
  inset: 0;
  backdrop-filter: blur(2px);
 width: 100%;
  display: flex;
  justify-content: center;
  align-items: center;
  opacity: 0;
  visibility: hidden;
  z-index: 9999;
  transition: all 0.4s ease;
  margin-top: 40px;
}

.receipt-overlay.show {
  opacity: 1;
  visibility: visible;
}

.receipt-card {
  background: #0a153d;
  border-radius: 22px;
  border: 1px solid rgba(100, 160, 255, 0.25);
  box-shadow: 0 25px 90px rgba(0,0,0,0.5);
  max-width: 450px;
  width: 90%;
  text-align: center;
  padding: 22px 17px;
  color: #f5f9ff;
  animation: popIn 0.5s ease forwards;
}

@keyframes popIn {
  from { transform: scale(0.8); opacity: 0; }
  to { transform: scale(1); opacity: 1; }
}

.receipt-logo {
  width: 90px;
  margin-bottom: 16px;
}

.success-check svg {
  width: 60px;
  margin: 8px auto;
  display: block;
  animation: checkPulse 1.3s ease;
}

@keyframes checkPulse {
  0% { transform: scale(0.5); opacity: 0; }
  100% { transform: scale(1); opacity: 1; }
}

.receipt-body h2 {
  color: #4de1c1;
  margin: 12px 0;
  font-size: 1.5rem;
}

.receipt-details {
  background: rgba(255,255,255,0.06);
  border-radius: 14px;
  padding: 13px;
  margin: 16px 0;
  text-align: left;
  line-height: 1.6;
  font-size: 12px;
}

.close-receipt {
  background: linear-gradient(135deg, #2c5bf5, #4de1c1);
  border: none;
  border-radius: 12px;
  padding: 10px 26px;
  font-weight: 600;
  color: #0a153d;
  cursor: pointer;
  transition: 0.3s;
}

.close-receipt:hover {
  transform: translateY(-3px);
  box-shadow: 0 6px 20px rgba(77, 225, 193, 0.3);
}


    
    /* Common toast styles */
.toast-message {
  position: fixed;
  top: 20px;
  right: -400px; /* start hidden off-screen */
  padding: 16px 24px;
  border-radius: 12px;
  color: white;
  font-family: 'Segoe UI', sans-serif;
  font-size: 15px;
  z-index: 1000;
  opacity: 0;
  box-shadow: 0 10px 40px rgba(0, 0, 0, 0.2);
  transition: right 0.6s ease, opacity 0.6s ease;
}

/* Success styling */
.toast-message.success {
  background: rgba(77, 225, 193, 0.95);
  color: #030922;
  box-shadow: 0 10px 40px rgba(77, 225, 193, 0.4);
  z-index: 99999;
}

/* Error styling */
.toast-message.error {
  background: rgba(255, 77, 77, 0.95);
  color: #fff;
  box-shadow: 0 10px 40px rgba(255, 77, 77, 0.4);
}

/* When visible */
.toast-message.show {
  right: 20px;
  opacity: 1;
}

  .rewards-hero {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
      gap: clamp(1.25rem, 2.5vw, 1.75rem);
      align-items: center;
      background: var(--panel-glass);
      border-radius: 26px;
      border: 1px solid var(--panel-border);
      padding: clamp(1.75rem, 3vw, 2.375rem);
      box-shadow: var(--shadow-heavy);
      position: relative;
      overflow: hidden;
    }

    .rewards-hero::before {
      content: "";
      position: absolute;
      inset: 0;
      background: url("front/assets/images/header-right-img.png") right/contain no-repeat;
      opacity: 0.08;
    }

    .rewards-copy { position: relative; z-index: 2; }

    .rewards-copy h1 { 
      margin: 0 0 clamp(0.5rem, 1vw, 0.75rem); 
      font-size: clamp(1.75rem, 4vw, 2.4rem);
      font-weight: 700;
    }

    .rewards-copy p { 
      margin: 0; 
      color: rgba(218, 231, 255, 0.78); 
      line-height: 1.7; 
      font-size: clamp(0.875rem, 1.5vw, 1rem);
    }
    
    /* Add modal styles for withdrawal rules */
    .withdrawal-modal {
      position: fixed;
      inset: 0;
      background: rgba(3, 9, 34, 0.92);
      backdrop-filter: blur(8px);
      display: none;
      justify-content: center;
      align-items: center;
      z-index: 9999;
      padding: 20px;
    }

    .withdrawal-modal.show {
      display: flex;
    }

    .modal-content {
      background: linear-gradient(135deg, rgba(13, 24, 62, 0.95), rgba(9, 18, 52, 0.98));
      border: 1px solid rgba(77, 225, 193, 0.3);
      border-radius: 24px;
      padding: 32px;
      max-width: 500px;
      width: 100%;
      box-shadow: 0 30px 90px rgba(4, 10, 36, 0.7);
      position: relative;
      animation: modalSlideIn 0.4s ease;
    }

    @keyframes modalSlideIn {
      from {
        transform: translateY(-50px);
        opacity: 0;
      }
      to {
        transform: translateY(0);
        opacity: 1;
      }
    }

    .modal-icon {
      width: 64px;
      height: 64px;
      margin: 0 auto 20px;
      display: flex;
      align-items: center;
      justify-content: center;
      border-radius: 50%;
      background: linear-gradient(135deg, rgba(77, 225, 193, 0.2), rgba(47, 91, 234, 0.2));
      border: 2px solid rgba(77, 225, 193, 0.4);
    }

    .modal-icon svg {
      width: 32px;
      height: 32px;
      fill: var(--page-mint);
    }

    .modal-content h2 {
      margin: 0 0 16px;
      font-size: clamp(1.3rem, 3vw, 1.6rem);
      text-align: center;
      color: var(--page-mint);
    }

    .modal-content p {
      margin: 0 0 24px;
      line-height: 1.7;
      color: rgba(218, 231, 255, 0.85);
      text-align: center;
      font-size: clamp(0.9rem, 2vw, 1rem);
    }

    .modal-actions {
      display: flex;
      gap: 12px;
      justify-content: center;
      flex-wrap: wrap;
    }

    .modal-btn {
      padding: 12px 28px;
      border-radius: 14px;
      border: none;
      font-weight: 600;
      font-size: clamp(0.85rem, 2vw, 0.95rem);
      cursor: pointer;
      transition: all 0.3s ease;
      text-decoration: none;
      display: inline-block;
      text-align: center;
    }

    .modal-btn-primary {
      background: linear-gradient(135deg, rgba(77, 225, 193, 0.9), rgba(47, 91, 234, 0.9));
      color: var(--page-blue-900);
      box-shadow: 0 8px 24px rgba(77, 225, 193, 0.3);
    }

    .modal-btn-primary:hover {
      transform: translateY(-2px);
      box-shadow: 0 12px 32px rgba(77, 225, 193, 0.4);
    }

    .modal-btn-secondary {
      background: rgba(99, 149, 255, 0.2);
      color: var(--page-white);
      border: 1px solid rgba(99, 149, 255, 0.3);
    }

    .modal-btn-secondary:hover {
      background: rgba(99, 149, 255, 0.3);
      transform: translateY(-2px);
    }

    .referral-progress {
      background: rgba(77, 225, 193, 0.1);
      border: 1px solid rgba(77, 225, 193, 0.2);
      border-radius: 12px;
      padding: 16px;
      margin: 20px 0;
      text-align: center;
    }

    .referral-progress strong {
      font-size: clamp(1.5rem, 3vw, 2rem);
      color: var(--page-mint);
      display: block;
      margin-bottom: 8px;
    }

    .referral-progress span {
      font-size: clamp(0.85rem, 2vw, 0.95rem);
      color: rgba(218, 231, 255, 0.7);
    }

  </style>
</head>
<body>
  <?php include "embed.php"; ?>
  <?php if ($success_message): ?>
  <div id="toast-success" class="toast-message success">
    <?php echo htmlspecialchars($success_message); ?>
  </div>
  <?php endif; ?>
  
  <?php if ($error_message): ?>
  <div id="toast-error" class="toast-message error">
    <?php echo htmlspecialchars($error_message); ?>
  </div>
  <?php endif; ?>

  <?php include "header2.php"; ?>
  <div class="page-shell">
   
    <main>
      <!-- <section class="rewards-hero" style="background: linear-gradient(135deg, rgba(77, 225, 193, 0.08), rgba(13, 24, 62, 0.78));">
        <div class="rewards-copy">
          <h1 style="font-size: clamp(1rem, 3vw, 1.5rem);">Daily Login Rewards</h1>
          <p>Claim your daily reward every 24 hours. Premium members earn double rewards! Build your streak and maximize your earnings.</p>
        </div>
      </section> -->

      <!-- Display saved withdrawal method if exists -->
      <?php if ($has_saved_method): ?>
      <section style="background: linear-gradient(135deg, rgba(77, 225, 193, 0.1), rgba(47, 91, 234, 0.05)); border: 1px solid rgba(77, 225, 193, 0.3); border-radius: 20px; padding: 24px; margin-bottom: 24px;">
        <h3 style="margin-top: 0; display: flex; align-items: center; gap: 8px;">
          <svg viewBox="0 0 24 24" width="20" height="20" fill="currentColor">
            <path d="M20 4H4c-1.11 0-1.99.89-1.99 2L2 18c0 1.11.89 2 2 2h16c1.11 0 2-.89 2-2V6c0-1.11-.89-2-2-2zm0 14H4v-6h16v6zm0-10H4V6h16v2z"/>
          </svg>
          Saved Withdrawal Method
        </h3>
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 16px; margin-top: 16px;">
          <div style="background: rgba(99, 102, 241, 0.1); border: 1px solid rgba(99, 102, 241, 0.2); border-radius: 12px; padding: 12px;">
            <p style="margin: 0; font-size: 0.85rem; opacity: 0.7;">Account Name</p>
            <p style="margin: 4px 0 0; font-weight: 600;"><?php echo htmlspecialchars($user['withdrawal_account_name']); ?></p>
          </div>
          <div style="background: rgba(99, 102, 241, 0.1); border: 1px solid rgba(99, 102, 241, 0.2); border-radius: 12px; padding: 12px;">
            <p style="margin: 0; font-size: 0.85rem; opacity: 0.7;">Account Number</p>
            <p style="margin: 4px 0 0; font-weight: 600;"><?php echo htmlspecialchars($user['withdrawal_account_number']); ?></p>
          </div>
          <div style="background: rgba(99, 102, 241, 0.1); border: 1px solid rgba(99, 102, 241, 0.2); border-radius: 12px; padding: 12px;">
            <p style="margin: 0; font-size: 0.85rem; opacity: 0.7;">Bank</p>
            <p style="margin: 4px 0 0; font-weight: 600;"><?php echo htmlspecialchars($user['withdrawal_bank_name']); ?></p>
          </div>
        </div>
        <button onclick="useSavedMethod()" style="margin-top: 16px; padding: 10px 20px; background: linear-gradient(135deg, #4de1c1, #2c5bf5); border: none; border-radius: 12px; color: #030922; font-weight: 600; cursor: pointer;">
          Use This Method
        </button>
      </section>
      <?php endif; ?>

      <section class="form-panel" style="background: linear-gradient(135deg, rgba(77, 225, 193, 0.08), rgba(13, 24, 62, 0.78));">
        <h2 style="font-size: 18px;">Initiate Withdrawal</h2>
        <form method="POST" action="">
          <div class="form-row">
            <div>
              <label for="withdrawal_type">Withdrawal Type *</label>
              <select id="withdrawal_type" name="withdrawal_type" required onchange="updateMinAmount(this.value)">
                <option value="">-- Select Withdrawal Type --</option>
                <option value="referral">Referral Earnings (Min: ₦3,000)</option>
                <option value="task">Task Earnings (Min: ₦55,000)</option>
              </select>
            </div>
            <div>
              <label for="amount">Amount (₦) *</label>
              <input id="amount" name="amount" type="number" step="0.01" min="0" placeholder="Enter amount" required />
              <small id="min-amount-hint" style="color: rgba(205, 219, 255, 0.6); font-size: 0.8rem; margin-top: 4px; display: block;"></small>
            </div>
            <div>
              <label for="payment_method">Payment Method *</label>
              <select id="payment_method" name="payment_method" required onchange="toggleBankField(this.value)">
                <option value="">-- Select Payment Method --</option>
                <option value="bank_transfer" selected>Bank Transfer</option>
                <option value="mobile_money">Mobile Money</option>
              </select>
            </div>
            <div id="account_name_display_withdrawal" style="display: none; padding: 16px; background: rgba(77, 225, 193, 0.1); border-radius: 12px; border: 1px solid rgba(77, 225, 193, 0.2);">
              <p style="margin: 0 0 8px; font-size: 0.85rem; opacity: 0.7;">✓ Verified Account Name</p>
              <p id="verified_account_name_withdrawal" style="margin: 0; font-size: 1.1rem; font-weight: 600; color: var(--page-mint);"></p>
            </div>
            <input id="account_name" name="account_name" type="hidden" value="<?php echo htmlspecialchars($user['withdrawal_account_name'] ?? ''); ?>" />
            <div>
              <label for="account_number">Account Number *</label>
              <input id="account_number" name="account_number" type="text" placeholder="Enter 10-digit account number" maxlength="10" value="<?php echo htmlspecialchars($user['withdrawal_account_number'] ?? ''); ?>" required />
              <div id="verification_loading_withdrawal" style="display: none; margin-top: 8px; color: var(--page-mint); font-size: 0.85rem;">
                <span>Verifying account...</span>
              </div>
            </div>
            <div id="bank_name_field">
              <label for="bank_code">Bank Name *</label>
              <select id="bank_code" name="bank_code" style="width: 100%; padding: 14px 16px; border-radius: 16px; background: rgba(5, 12, 36, 0.82); color: var(--page-white); border: 1px solid rgba(99, 149, 255, 0.26); font-size: 1rem; cursor: pointer;" required>
                <option value="">-- Select your bank --</option>
                <?php foreach ($banks as $bank): ?>
                  <option value="<?php echo htmlspecialchars($bank['code']); ?>" <?php echo (isset($user['withdrawal_bank_code']) && $user['withdrawal_bank_code'] == $bank['code']) ? 'selected' : ''; ?>>
                    <?php echo htmlspecialchars($bank['name']); ?>
                  </option>
                <?php endforeach; ?>
              </select>
              <input id="bank_name" name="bank_name" type="hidden" value="<?php echo htmlspecialchars($user['withdrawal_bank_name'] ?? ''); ?>" />
            </div>
            <div class="action-buttons">
              <button type="submit" name="submit_withdrawal" class="btn-primary">Confirm Transfer</button>
              <button type="reset" class="btn-ghost">Clear Form</button>
            </div>
          </div>
        </form>
      </section>

      <section class="status-panels">
        <article class="status-card">
          <div class="status-title">Total Withdrawn</div>
          <div class="status-value">₦<?php echo number_format($withdrawal_stats['total_withdrawn'], 2); ?></div>
          <div>Across <?php echo $withdrawal_stats['total_withdrawals']; ?> payouts</div>
        </article>
        <article class="status-card">
          <div class="status-title">Pending Queue</div>
          <div class="status-value">₦<?php echo number_format($withdrawal_stats['pending_amount'], 2); ?></div>
          <div>Currently being processed</div>
        </article>
        <article class="status-card">
          <div class="status-title">Referral Balance</div>
          <div class="status-value">₦<?php echo number_format($balance['referral_earnings'], 2); ?></div>
          <div>Available for instant withdrawal</div>
        </article>
        <article class="status-card">
          <div class="status-title">Task Balance</div>
          <div class="status-value">₦<?php echo number_format($balance['task_earnings'], 2); ?></div>
          <div>Available for withdrawal</div>
        </article>
      </section>

      <section class="ticker">
        <div class="ticker-track">
          <?php 
          if (!empty($ticker_withdrawals)) {
              foreach ($ticker_withdrawals as $tw) {
                  $time_ago = time_elapsed_string($tw['requested_at']);
                  echo "WITHDRAWAL CONFIRMED — " . htmlspecialchars($tw['username']) . " • ₦" . number_format($tw['amount'], 0) . " • " . $time_ago . " ✦ ";
              }
              // Duplicate for seamless loop
              foreach ($ticker_withdrawals as $tw) {
                  $time_ago = time_elapsed_string($tw['requested_at']);
                  echo "WITHDRAWAL CONFIRMED — " . htmlspecialchars($tw['username']) . " • ₦" . number_format($tw['amount'], 0) . " • " . $time_ago . " ✦ ";
              }
          } else {
              echo "WITHDRAWAL SYSTEM ACTIVE ✦ SECURE PAYMENTS ✦ INSTANT PROCESSING ✦ ";
          }
          ?>
        </div>
      </section>

     
      <?php if (!empty($recent_withdrawals)): ?>
      <section class="timeline-box">
        <h3 style="margin: 0 0 18px; letter-spacing: 0.08em; text-transform: uppercase;">Recent Withdrawals</h3>
        <?php foreach ($recent_withdrawals as $withdrawal): ?>
        <div class="timeline-entry">
          <div>
            <strong>₦<?php echo number_format($withdrawal['amount'], 2); ?></strong>
            <span style="display: block; margin-top: 4px; font-size: 0.75rem;">
              <?php echo ucfirst($withdrawal['withdrawal_type']); ?> • Bank Transfer
            </span>
          </div>
          <div style="text-align: right;">
            <span style="display: block; padding: 4px 12px; border-radius: 8px; font-size: 0.7rem; 
              background: <?php 
                echo $withdrawal['status'] === 'completed' ? 'rgba(77, 225, 193, 0.2)' : 
                     ($withdrawal['status'] === 'processing' ? 'rgba(44, 92, 240, 0.2)' : 
                     ($withdrawal['status'] === 'rejected' ? 'rgba(255, 51, 102, 0.2)' : 'rgba(255, 193, 7, 0.2)')); 
              ?>;">
              <?php echo strtoupper($withdrawal['status']); ?>
            </span>
            <span style="display: block; margin-top: 6px; font-size: 0.7rem;">
              <?php echo date('M d, Y', strtotime($withdrawal['requested_at'])); ?>
            </span>
          </div>
        </div>
        <?php endforeach; ?>
      </section>
      <?php endif; ?>
    </main>
  </div>

   <nav class="mobile-fintech-footer">
    
  <a href="dashboard.php">
    <svg viewBox="0 0 24 24"><path d="M12 3a9 9 0 1 1 0 18 9 9 0 0 1 0-18Zm1 4h-2v6h6v-2h-4V7Z"/></svg>
    <span>Dashboard</span>
  </a>

  <!-- Premium (crown icon) -->
  <a href="membership.php">
    <svg viewBox="0 0 24 24"><path d="M5 7l2.5 5 4.5-4 4.5 4L19 7l2 13H3l2-13Z"/></svg>
    <span>Premium</span>
  </a>

  <a href="daily-rewards.php">
    <svg viewBox="0 0 24 24"><path d="M20 3H4a1 1 0 0 0-1 1v16l5-3 5 3 5-3 5 3V4a1 1 0 0 0-1-1Zm-2 5-6.7 6.7L7 10.4l1.4-1.4 2.9 2.9L17.6 6 18 8Z"/></svg>
    <span>Rewards</span>
  </a>

  <!-- Referrals (users/people icon) -->
  <!-- <a href="refferrals.php">
    <svg viewBox="0 0 24 24"><path d="M12 12a4 4 0 1 0-4-4 4 4 0 0 0 4 4Zm0 2c-4 0-8 2-8 5v1h16v-1c0-3-4-5-8-5Zm7-6a3 3 0 1 0-3 3 3 3 0 0 0 3-3Zm-1 6a5 5 0 0 1 4 2.5v1.5h-4v-1.3a6.8 6.8 0 0 0-1.2-2.2A7.9 7.9 0 0 1 18 14Z"/></svg>
    <span>Referrals</span>
  </a> -->

  <a href="history.php">
  <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
    <path d="M13 3a9 9 0 1 0 9 9h-2a7 7 0 1 1-7-7V3l4 4-4 4V7a5 5 0 1 0 5 5h2a7 7 0 1 1-7-7z"/>
  </svg>
  <span>History</span>
</a>


  <a href="profile.php">
    <svg viewBox="0 0 24 24"><path d="M12 2a6 6 0 0 1 6 6c0 3.31-2.69 6-6 6s-6-2.69-6-6a6 6 0 0 1 6-6Zm0 14c4.42 0 8 1.79 8 4v2H4v-2c0-2.21 3.58-4 8-4Z"/></svg>
    <span>Profile</span>
  </a>
</nav>


  <!-- Add withdrawal rule modals -->
  <!-- Modal: Upgrade Required (Free Users) -->
  <div id="upgradeRequiredModal" class="withdrawal-modal">
    <div class="modal-content">
      <div class="modal-icon">
        <svg viewBox="0 0 24 24">
          <path d="M5 7l2.5 5 4.5-4 4.5 4L19 7l2 13H3l2-13Z"/>
        </svg>
      </div>
      <h2>Upgrade Required</h2>
      <p>To ensure fair usage and maintain a secure platform environment, withdrawal for task earnings is available only for upgraded accounts.</p>
      <p>Please upgrade your account to access withdrawal features.</p>
      <div class="modal-actions">
        <a href="membership.php" class="modal-btn modal-btn-primary">Upgrade Now</a>
        <button onclick="closeModal('upgradeRequiredModal')" class="modal-btn modal-btn-secondary">Close</button>
      </div>
    </div>
  </div>

  <!-- Modal: Referral Requirement (First Withdrawal) -->
  <div id="referralRequirementModal" class="withdrawal-modal">
    <div class="modal-content">
      <div class="modal-icon">
        <svg viewBox="0 0 24 24">
          <path d="M12 12a4 4 0 1 0-4-4 4 4 0 0 0 4 4Zm0 2c-4 0-8 2-8 5v1h16v-1c0-3-4-5-8-5Zm7-6a3 3 0 1 0-3 3 3 3 0 0 0 3-3Zm-1 6a5 5 0 0 1 4 2.5v1.5h-4v-1.3a6.8 6.8 0 0 0-1.2-2.2A7.9 7.9 0 0 1 18 14Z"/>
        </svg>
      </div>
      <h2>Referral Requirement</h2>
      <p>To activate withdrawal for activity earnings, please refer a minimum of 5 active users to the platform.</p>
      <p>This helps us confirm genuine engagement and maintain a healthy community.</p>
      <div class="referral-progress">
        <strong><?php echo $referral_count; ?> / 5</strong>
        <span>Active Referrals</span>
      </div>
      <div class="modal-actions">
        <a href="refferrals.php" class="modal-btn modal-btn-primary">Invite Friends</a>
        <button onclick="closeModal('referralRequirementModal')" class="modal-btn modal-btn-secondary">Close</button>
      </div>
    </div>
  </div>

  <!-- Modal: Additional Referrals Needed (Subsequent Withdrawals) -->
  <div id="additionalReferralsModal" class="withdrawal-modal">
    <div class="modal-content">
      <div class="modal-icon">
        <svg viewBox="0 0 24 24">
          <path d="M12 12a4 4 0 1 0-4-4 4 4 0 0 0 4 4Zm0 2c-4 0-8 2-8 5v1h16v-1c0-3-4-5-8-5Zm7-6a3 3 0 1 0-3 3 3 3 0 0 0 3-3Zm-1 6a5 5 0 0 1 4 2.5v1.5h-4v-1.3a6.8 6.8 0 0 0-1.2-2.2A7.9 7.9 0 0 1 18 14Z"/>
        </svg>
      </div>
      <h2>Additional Referrals Needed</h2>
      <p>To proceed with your next withdrawal, please refer 5 additional users.</p>
      <p>This requirement helps support our system and reward active community members.</p>
      <div class="referral-progress">
        <strong><?php echo $referral_count; ?> / <?php echo ($completed_task_withdrawals + 1) * 5; ?></strong>
        <span>Active Referrals Required</span>
      </div>
      <div class="modal-actions">
        <a href="refferrals.php" class="modal-btn modal-btn-primary">Invite Friends</a>
        <button onclick="closeModal('additionalReferralsModal')" class="modal-btn modal-btn-secondary">Close</button>
      </div>
    </div>
  </div>

  <!-- Modal: Withdrawal Request Sent -->
  <div id="withdrawalPendingModal" class="withdrawal-modal">
    <div class="modal-content">
      <div class="modal-icon">
        <svg viewBox="0 0 24 24">
          <path d="M9 16.2L4.8 12l-1.4 1.4L9 19 21 7l-1.4-1.4L9 16.2z"/>
        </svg>
      </div>
      <h2>Withdrawal Request Sent</h2>
      <p>Your withdrawal request has been received and is currently being reviewed by our team.</p>
      <p><strong>Processing time: up to 24 hours.</strong></p>
      <p>You will receive a notification once your withdrawal has been processed.</p>
      <div class="modal-actions">
        <button onclick="closeModal('withdrawalPendingModal')" class="modal-btn modal-btn-primary">Got It</button>
      </div>
    </div>
  </div>

  <!-- Modal: Instant Withdrawal (Referral/Deposit) -->
  <div id="withdrawalInstantModal" class="withdrawal-modal">
    <div class="modal-content">
      <div class="modal-icon">
        <svg viewBox="0 0 24 24">
          <path d="M9 16.2L4.8 12l-1.4 1.4L9 19 21 7l-1.4-1.4L9 16.2z"/>
        </svg>
      </div>
      <h2>Instant Withdrawal</h2>
      <p><strong>Minimum withdrawal: ₦3,000</strong></p>
      <p>Withdrawal is processed automatically and will be credited to your account shortly.</p>
      <p>Thank you for using our platform!</p>
      <div class="modal-actions">
        <button onclick="closeModal('withdrawalInstantModal')" class="modal-btn modal-btn-primary">Got It</button>
      </div>
    </div>
  </div>


  <script>
    document.addEventListener('DOMContentLoaded', function() {
      loadBanksForWithdrawal();
      
      const accountNumberInput = document.getElementById('account_number');
      const bankSelect = document.getElementById('bank_code');
      const bankField = document.getElementById('bank_name_field');
      
      bankField.style.display = 'none';
      
      accountNumberInput.addEventListener('input', handleAccountNumberInput);
      accountNumberInput.addEventListener('paste', function(e) {
        setTimeout(() => handleAccountNumberInput.call(this), 10);
      });
      
      function handleAccountNumberInput() {
        const accountNumber = this.value.replace(/\D/g, '');
        this.value = accountNumber;
        
        if (accountNumber.length === 10) {
          autoVerifyAccountWithoutBankWithdrawal(accountNumber);
        } else {
          document.getElementById('account_name_display_withdrawal').style.display = 'none';
          document.getElementById('account_name').value = '';
          bankField.style.display = 'none';
        }
      }
      
      bankSelect.addEventListener('change', function() {
        const accountNumber = accountNumberInput.value;
        const selectedOption = this.options[this.selectedIndex];
        
        document.getElementById('bank_name').value = selectedOption.text;
        
        if (accountNumber.length === 10 && this.value) {
          autoVerifyAccountWithdrawal(accountNumber, this.value);
        } else if (accountNumber.length !== 10) {
            document.getElementById('account_name_display_withdrawal').style.display = 'none';
            document.getElementById('account_name').value = '';
        }
      });
    });
    
    async function loadBanksForWithdrawal() {
      try {
        const response = await fetch('api/paystack-get-banks.php');
        const data = await response.json();
        
        if (data.success) {
          const bankSelect = document.getElementById('bank_code');
          bankSelect.innerHTML = '<option value="">-- Select your bank --</option>';
          
          data.banks.forEach(bank => {
            const option = document.createElement('option');
            option.value = bank.code;
            option.textContent = bank.name;
            
            <?php if (!empty($user['withdrawal_bank_code'])): ?>
            if (bank.code === '<?php echo $user['withdrawal_bank_code']; ?>') {
              option.selected = true;
              document.getElementById('bank_name').value = bank.name;
            }
            <?php endif; ?>
            
            bankSelect.appendChild(option);
          });
          
          <?php if (!empty($user['withdrawal_account_number']) && !empty($user['withdrawal_bank_code'])): ?>
          autoVerifyAccountWithdrawal('<?php echo $user['withdrawal_account_number']; ?>', '<?php echo $user['withdrawal_bank_code']; ?>');
          <?php endif; ?>
        }
      } catch (error) {
        console.error('Error loading banks:', error);
      }
    }
    
    async function autoVerifyAccountWithoutBankWithdrawal(accountNumber) {
      const loadingDiv = document.getElementById('verification_loading_withdrawal');
      const accountNameDisplay = document.getElementById('account_name_display_withdrawal');
      const verifiedNameEl = document.getElementById('verified_account_name_withdrawal');
      const hiddenAccountName = document.getElementById('account_name');
      const bankField = document.getElementById('bank_name_field');
      
      loadingDiv.style.display = 'block';
      accountNameDisplay.style.display = 'none';
      bankField.style.display = 'none';
      
      try {
        const formData = new FormData();
        formData.append('account_number', accountNumber);
        formData.append('resolve_only', 'true');
        
        const response = await fetch('api/paystack-verify-account.php', {
          method: 'POST',
          body: formData
        });
        
        const data = await response.json();
        
        loadingDiv.style.display = 'none';
        
        if (data.success) {
          verifiedNameEl.textContent = data.account_name;
          hiddenAccountName.value = data.account_name;
          accountNameDisplay.style.display = 'block';
          
          if (data.bank_code) {
            document.getElementById('bank_code').value = data.bank_code;
            document.getElementById('bank_name').value = data.bank_name || '';
            bankField.style.display = 'block'; // Show bank field if bank code is resolved
          }
        } else {
          accountNameDisplay.style.display = 'none';
          bankField.style.display = 'block';
        }
      } catch (error) {
        console.error('Error verifying account:', error);
        loadingDiv.style.display = 'none';
        bankField.style.display = 'block';
      }
    }
    
    async function autoVerifyAccountWithdrawal(accountNumber, bankCode) {
      const loadingDiv = document.getElementById('verification_loading_withdrawal');
      const accountNameDisplay = document.getElementById('account_name_display_withdrawal');
      const verifiedNameEl = document.getElementById('verified_account_name_withdrawal');
      const hiddenAccountName = document.getElementById('account_name');
      
      loadingDiv.style.display = 'block';
      accountNameDisplay.style.display = 'none';
      
      try {
        const formData = new FormData();
        formData.append('account_number', accountNumber);
        formData.append('bank_code', bankCode);
        
        const response = await fetch('api/paystack-verify-account.php', {
          method: 'POST',
          body: formData
        });
        
        const data = await response.json();
        
        loadingDiv.style.display = 'none';
        
        if (data.success) {
          verifiedNameEl.textContent = data.account_name;
          hiddenAccountName.value = data.account_name;
          accountNameDisplay.style.display = 'block';
        } else {
          accountNameDisplay.style.display = 'none';
          hiddenAccountName.value = '';
          console.warn("Account verification failed:", data.message || "Unknown error");
        }
      } catch (error) {
        console.error('Error verifying account:', error);
        loadingDiv.style.display = 'none';
      }
    }
    
    function useSavedMethod() {
      document.getElementById('account_number').value = "<?php echo htmlspecialchars($user['withdrawal_account_number'] ?? ''); ?>";
      document.getElementById('payment_method').value = "bank_transfer";
      
      // Trigger verification
      const accountNumber = document.getElementById('account_number').value;
      const bankCode = document.getElementById('bank_code').value; // This should be pre-filled by loadBanksForWithdrawal or user's data
      
      if (accountNumber.length === 10 && bankCode) {
        autoVerifyAccountWithdrawal(accountNumber, bankCode);
      }
      
      // Ensure bank name is also set if pre-filled
      const bankNameInput = document.getElementById('bank_name');
      if (bankNameInput.value) {
          document.getElementById('account_name_display_withdrawal').style.display = 'block';
          document.getElementById('verified_account_name_withdrawal').textContent = "<?php echo htmlspecialchars($user['withdrawal_account_name'] ?? ''); ?>";
      }

      document.querySelector('.form-panel').scrollIntoView({ behavior: 'smooth' });
    }

    function updateMinAmount(type) {
      const hint = document.getElementById('min-amount-hint');
      const amountInput = document.getElementById('amount');
      
      if (type === 'referral') {
        hint.textContent = 'Minimum withdrawal: ₦3,000';
        amountInput.min = '3000';
      } else if (type === 'task') {
        hint.textContent = 'Minimum withdrawal: ₦55,000';
        amountInput.min = '55000';
      } else {
        hint.textContent = '';
        amountInput.min = '0';
      }
    }

    function toggleBankField(method) {
      const bankField = document.getElementById('bank_name_field');
      const bankSelect = document.getElementById('bank_code');
      const bankNameInput = document.getElementById('bank_name'); // Hidden input for bank name
      
      if (method === 'bank_transfer') {
        bankField.style.display = 'block';
        bankSelect.required = true;
        
        // Update hidden bank_name input when bank_code changes
        bankSelect.onchange = function() {
          const selectedOption = this.options[this.selectedIndex];
          bankNameInput.value = selectedOption.text === '-- Select your bank --' ? '' : selectedOption.text;
          
          // Trigger verification if account number is already valid
          const accountNumberInput = document.getElementById('account_number');
          if (accountNumberInput.value.length === 10 && this.value) {
            autoVerifyAccountWithdrawal(accountNumberInput.value, this.value);
          }
        };
        // Trigger initial update if a bank is already selected (e.g., from useSavedMethod or pre-filled)
        bankSelect.dispatchEvent(new Event('change'));

      } else {
        bankField.style.display = 'none';
        bankSelect.required = false;
        bankNameInput.value = ''; // Clear bank name if not bank transfer
      }
    }

    // Auto-hide success/error messages after 8 seconds
    setTimeout(function() {
      const messages = document.querySelectorAll('[style*="position: fixed"]');
      messages.forEach(msg => {
        msg.style.transition = 'opacity 0.5s';
        msg.style.opacity = '0';
        setTimeout(() => msg.remove(), 500);
      });
    }, 8000);
  </script>

    <script>
document.addEventListener('DOMContentLoaded', () => {
  const successToast = document.getElementById("toast-success");
  const errorToast = document.getElementById("toast-error");

  // Function to show and hide a toast
  function showToast(toast) {
    if (!toast) return;
    setTimeout(() => toast.classList.add("show"), 100); // slide in
    setTimeout(() => toast.classList.remove("show"), 5000); // hide after 4s
  }

  showToast(successToast);
  showToast(errorToast);
});
</script>

<!-- Receipt Overlay -->
<div id="receiptOverlay" class="receipt-overlay">
  <div class="receipt-card">
    <img src="logo.png" class="receipt-logo" alt="Logo" />
   <div class="success-check">
        <svg viewBox="0 0 52 52">
          <path d="M26 0a26 26 0 1 0 0 52A26 26 0 0 0 26 0z" fill="#4de1c1"/>
          <path d="M38 18L22.6 33.4 14 25" fill="none" stroke="#fff" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"/>
        </svg>
    <div class="receipt-body">
      <h2 style="font-size: 20px;">Withdrawal Successful!</h2>
      <div class="receipt-details" id="receiptDetails">
        <!-- Details will be injected via JS -->
      </div>
      <button class="close-receipt" onclick="closeReceipt()">Close</button>
    </div>
  </div>
</div>

<script>
function showReceipt(details) {
  const receiptOverlay = document.getElementById('receiptOverlay');
  const receiptDetails = document.getElementById('receiptDetails');

  // Mask account number except last 5 digits
  let maskedAccount = details.account_number.slice(0, -5).replace(/\d/g, '*') + details.account_number.slice(-5);

  // Inject HTML
  receiptDetails.innerHTML = `
    <div style="display:grid; grid-template-columns:1fr 1fr; gap:20px; margin-bottom:12px;">
      <strong>Amount:</strong> <span>₦${parseFloat(details.amount).toLocaleString()}</span>
      <strong>Date:</strong> <span>${details.date}</span>

      <strong>Account Name:</strong> <span>${details.account_name}</span>
      <strong>Bank:</strong> <span>${details.bank_name}</span>

      <strong>Account No:</strong> <span>${maskedAccount}</span>
      <strong>Payment Method:</strong> <span>Bank Transfer</span>
    </div>
    <div style="text-align:center; margin-top:10px;">
      <img src="${details.qr_code}" alt="QR Code" style="width:70px;"/>
    </div>
  `;

  // Show overlay
  receiptOverlay.classList.add('show');

  // Blur main content
  document.querySelector('.page-shell').style.filter = 'blur(2px)';
}

function closeReceipt() {
  const receiptOverlay = document.getElementById('receiptOverlay');
  receiptOverlay.classList.remove('show');
  document.querySelector('.page-shell').style.filter = 'none';
}

// Show toast messages if any
window.addEventListener('DOMContentLoaded', () => {
  <?php if ($success_message): ?>
    showReceipt({
      amount: "<?php echo $amount ?? 0; ?>",
      date: "<?php echo date('d M Y H:i'); ?>",
      account_name: "<?php echo $account_name ?? ''; ?>",
      account_number: "<?php echo $account_number ?? ''; ?>",
      bank_name: "<?php echo $bank_name ?? ''; ?>",
      payment_method: "<?php echo $payment_method ?? ''; ?>",
      qr_code: "https://api.qrserver.com/v1/create-qr-code/?size=120x120&data=<?php echo urlencode($reference ?? ''); ?>"
    });
  <?php endif; ?>
});

function showModal(modalId) {
  const modal = document.getElementById(modalId);
  if (modal) {
    modal.classList.add('show');
    document.body.style.overflow = 'hidden';
  }
}

function closeModal(modalId) {
  const modal = document.getElementById(modalId);
  if (modal) {
    modal.classList.remove('show');
    document.body.style.overflow = '';
  }
}


document.addEventListener('DOMContentLoaded', function() {
  <?php if ($error_message === 'Upgrade Account to premium for withdrawal'): ?>
    showModal('upgradeRequiredModal');
  <?php elseif ($error_message === 'Please Refer 5 users to withdraw'): ?>
    showModal('referralRequirementModal');
  <?php elseif ($error_message === 'Please Refer additional 5 users to withdraw'): ?>
    showModal('additionalReferralsModal');
  <?php elseif ($success_message === 'Withdrawal Successful'): ?>
    showModal('withdrawalPendingModal');
  <?php elseif ($success_message === 'Withdrawal Successful'): ?>
    showModal('withdrawalInstantModal');
  <?php endif; ?>
});

// Close modal when clicking outside
document.querySelectorAll('.withdrawal-modal').forEach(modal => {
  modal.addEventListener('click', function(e) {
    if (e.target === this) {
      closeModal(this.id);
    }
  });
});

  </script>

</body>
</html>

<?php
// Helper function to calculate time elapsed
function time_elapsed_string($datetime, $full = false) {
    $now = new DateTime;
    $ago = new DateTime($datetime);
    $diff = $now->diff($ago);

    $string = array(
        'y' => 'year',
        'm' => 'month',
        'd' => 'day',
        'h' => 'hour',
        'i' => 'min',
        's' => 'sec',
    );
    
    foreach ($string as $k => &$v) {
        if ($diff->$k) {
            $v = $diff->$k . ' ' . $v . ($diff->$k > 1 ? 's' : '');
        } else {
            unset($string[$k]);
        }
    }

    if (!$full) $string = array_slice($string, 0, 1);
    return $string ? implode(', ', $string) . ' ago' : 'just now';
}
?>
