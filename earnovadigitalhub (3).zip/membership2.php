<?php
session_start();
require_once 'config/database.php';
require_once 'includes/session.php';
require_once 'includes/connect.php';

define('PAYSTACK_PUBLIC_KEY', 'pk_test_2889acc30e717c743676ced0e02e0e1ad4d274fe');
define('PAYSTACK_SECRET_KEY', 'sk_test_6a29ffe76f6118fde9f04cb80713d4393d13c1e2');
define('FLUTTERWAVE_PUBLIC_KEY', 'FLWPUBK_TEST-XXXXXXXXXXXXX-X'); // Replace with actual key
define('FLUTTERWAVE_SECRET_KEY', 'FLWSECK_TEST-XXXXXXXXXXXXX-X'); // Replace with actual key


// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$user_id = $_SESSION['user_id'];

// Fetch user data
$stmt = $conn->prepare("
    SELECT u.*, b.total_balance, b.task_earnings, b.referral_earnings 
    FROM users u 
    LEFT JOIN balances b ON u.id = b.user_id 
    WHERE u.id = ?
");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();
$stmt->close();

if (!$user) {
    header('Location: login.php');
    exit();
}

// Fetch user's full name for billing form
$user_data = null;
$stmt = $conn->prepare("SELECT full_name, email, profile_picture FROM users WHERE id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$user_data_result = $stmt->get_result();
if ($user_data_result->num_rows > 0) {
    $user_data = $user_data_result->fetch_assoc();
}
$stmt->close();

$billing_info = null;
$stmt = $conn->prepare("SELECT * FROM billing_information WHERE user_id = ? ORDER BY created_at DESC LIMIT 1");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$billing_result = $stmt->get_result();
if ($billing_result->num_rows > 0) {
    $billing_info = $billing_result->fetch_assoc();
}
$stmt->close();

function getRenewalPrice($start_date, $first_year_price, $normal_price) {
    if (!$start_date) {
        return $first_year_price; // First time subscriber
    }
    
    $start = new DateTime($start_date);
    $now = new DateTime();
    $diff = $start->diff($now);
    
    // If more than 1 year has passed, use normal price
    if ($diff->y >= 1) {
        return $normal_price;
    }
    
    return $first_year_price;
}

$premium_price = getRenewalPrice($user['membership_start_date'], 1500, 3500);
$senior_yearly_price = getRenewalPrice($user['advertiser_plan_start_date'], 2500, 5500);

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    if ($_POST['action'] === 'save_billing') {
        // Save or update billing information
        $full_name = $conn->real_escape_string($_POST['full_name']);
        $email = $conn->real_escape_string($_POST['email']);
        $phone = $conn->real_escape_string($_POST['phone']);
        $address = $conn->real_escape_string($_POST['address']);
        $city = $conn->real_escape_string($_POST['city']);
        $state = $conn->real_escape_string($_POST['state']);
        
        if ($billing_info) {
            // Update existing
            $stmt = $conn->prepare("UPDATE billing_information SET full_name=?, email=?, phone=?, address=?, city=?, state=? WHERE user_id=?");
            $stmt->bind_param("ssssssi", $full_name, $email, $phone, $address, $city, $state, $user_id);
        } else {
            // Insert new
            $stmt = $conn->prepare("INSERT INTO billing_information (user_id, full_name, email, phone, address, city, state) VALUES (?, ?, ?, ?, ?, ?, ?)");
            $stmt->bind_param("issssss", $user_id, $full_name, $email, $phone, $address, $city, $state);
        }
        $stmt->execute();
        $billing_info_id = $billing_info ? $billing_info['id'] : $conn->insert_id;
        $stmt->close();
        
        // Create order
        $order_number = 'ORD-' . strtoupper(uniqid());
        $order_type = $_POST['order_type'];
        $amount = floatval($_POST['amount']);
        $payment_gateway = $_POST['payment_gateway'];
        $metadata = json_encode($_POST['metadata'] ?? []);
        
        $stmt = $conn->prepare("INSERT INTO orders (user_id, order_number, order_type, amount, payment_gateway, billing_info_id, metadata) VALUES (?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("isssdis", $user_id, $order_number, $order_type, $amount, $payment_gateway, $billing_info_id, $metadata);
        $stmt->execute();
        $stmt->close();
        
        // Redirect to receipt page
        header("Location: receipt.php?order=" . $order_number);
        exit();
    }
}


if (isset($_GET['status']) && isset($_GET['reference'])) {
    $status = $_GET['status'];
    $reference = $_GET['reference'];
    
    if ($status === 'success') {
        // Verify payment with Paystack
        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL => "https://api.paystack.co/transaction/verify/{$reference}",
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_SSL_VERIFYHOST => 2,
            CURLOPT_HTTPHEADER => array(
                "Authorization: Bearer " . PAYSTACK_SECRET_KEY
            ),
        ));
        
        $response = curl_exec($curl);
        $curl_errno = curl_errno($curl);
        $curl_error = curl_error($curl);
        $http_code = curl_getinfo($curl, CURLINFO_HTTP_CODE);
        curl_close($curl);
        
        // Check for curl errors first
        if ($curl_errno !== 0) {
            $error_message = "Payment verification failed: Connection error. Please contact support with reference: " . $reference;
            error_log("Paystack verification curl error: " . $curl_error . " for reference: " . $reference);
        } elseif (empty($response)) {
            $error_message = "Payment verification failed: Empty response from payment gateway. Please contact support with reference: " . $reference;
            error_log("Paystack verification empty response for reference: " . $reference);
        } elseif ($http_code !== 200) {
            $error_message = "Payment verification failed: Invalid response (HTTP " . $http_code . "). Please contact support with reference: " . $reference;
            error_log("Paystack verification HTTP error " . $http_code . " for reference: " . $reference);
        } else {
            $result = json_decode($response, true);
            
            // Validate JSON decode was successful
            if (json_last_error() !== JSON_ERROR_NONE) {
                $error_message = "Payment verification failed: Invalid response format. Please contact support with reference: " . $reference;
                error_log("Paystack verification JSON decode error: " . json_last_error_msg() . " for reference: " . $reference);
            } elseif (!is_array($result)) {
                $error_message = "Payment verification failed: Invalid response structure. Please contact support with reference: " . $reference;
                error_log("Paystack verification result is not an array for reference: " . $reference);
            } elseif (!isset($result['status'])) {
                $error_message = "Payment verification failed: Missing status in response. Please contact support with reference: " . $reference;
                error_log("Paystack verification missing status field for reference: " . $reference);
            } elseif ($result['status'] !== true) {
                $error_message = "Payment verification failed: " . (isset($result['message']) ? $result['message'] : 'Unknown error') . ". Please contact support with reference: " . $reference;
                error_log("Paystack verification status false: " . print_r($result, true));
            } elseif (!isset($result['data']) || !is_array($result['data'])) {
                $error_message = "Payment verification failed: Missing transaction data. Please contact support with reference: " . $reference;
                error_log("Paystack verification missing data field for reference: " . $reference);
            } elseif (!isset($result['data']['status']) || $result['data']['status'] !== 'success') {
                $error_message = "Payment verification failed: Transaction not successful. Please contact support with reference: " . $reference;
                error_log("Paystack verification transaction status not success for reference: " . $reference . " - " . print_r($result['data'], true));
            } else {
                // All validations passed, proceed with payment processing
                $amount = $result['data']['amount'] / 100; // Paystack returns amount in kobo
                $payment_type = isset($result['data']['metadata']['payment_type']) ? $result['data']['metadata']['payment_type'] : null;
                
                if (!$payment_type) {
                    $error_message = "Payment verification failed: Invalid payment metadata. Please contact support with reference: " . $reference;
                    error_log("Paystack verification missing payment_type in metadata for reference: " . $reference);
                } else {
                    // Start transaction
                    $conn->begin_transaction();
                    
                    try {
                        if ($payment_type === 'premium_upgrade') {
                            // Process premium upgrade (old 1500/year plan)
                            $upgrade_amount = $amount; // This should reflect the actual amount paid
                            $referrer_commission = 500; // Fixed commission for premium upgrade
                            $company_amount = $upgrade_amount - $referrer_commission; // The amount for the company
                            
                            // Update user membership, ensuring membership_start_date is set if it's the first purchase
                            $stmt = $conn->prepare("UPDATE users SET membership_type = 'premium', membership_expires_at = DATE_ADD(NOW(), INTERVAL 1 YEAR), membership_start_date = COALESCE(membership_start_date, NOW()) WHERE id = ?");
                            $stmt->bind_param("i", $user_id);
                            $stmt->execute();
                            $stmt->close();
                            
                            $stmt = $conn->prepare("INSERT INTO premium_payments (user_id, amount, payment_method, payment_reference, status, referrer_commission, company_amount) VALUES (?, ?, 'paystack', ?, 'completed', ?, ?)");
                            $stmt->bind_param("idsdd", $user_id, $upgrade_amount, $reference, $referrer_commission, $company_amount);
                            $stmt->execute();
                            $stmt->close();
                            
                            // If user has a referrer, give commission
                            if ($user['referred_by']) {
                                $referrer_id = $user['referred_by'];
                                
                                // Check referrer's membership type
                                $stmt = $conn->prepare("SELECT membership_type FROM users WHERE id = ?");
                                $stmt->bind_param("i", $referrer_id);
                                $stmt->execute();
                                $referrer_result = $stmt->get_result();
                                $referrer = $referrer_result->fetch_assoc();
                                $stmt->close();
                                
                                // Commission based on referrer's membership
                                $commission = ($referrer['membership_type'] === 'premium') ? 500 : 250;
                                
                                // Update referrer's balance
                                $stmt = $conn->prepare("UPDATE balances SET referral_earnings = referral_earnings + ?, total_balance = total_balance + ? WHERE user_id = ?");
                                $stmt->bind_param("ddi", $commission, $commission, $referrer_id);
                                $stmt->execute();
                                $stmt->close();
                                
                                // Record commission
                                $stmt = $conn->prepare("INSERT INTO referral_commissions (referrer_id, referred_user_id, commission_type, commission_amount) VALUES (?, ?, 'premium_upgrade', ?)");
                                $stmt->bind_param("iid", $referrer_id, $user_id, $commission);
                                $stmt->execute();
                                $stmt->close();
                                
                                // Record transaction for referrer
                                $stmt = $conn->prepare("INSERT INTO transactions (user_id, transaction_type, amount, balance_type, description, reference_id) VALUES (?, 'referral_commission', ?, 'referral', 'Premium upgrade commission', ?)");
                                $stmt->bind_param("ids", $referrer_id, $commission, $reference);
                                $stmt->execute();
                                $stmt->close();
                            }
                            
                            // Record transaction
                            $stmt = $conn->prepare("INSERT INTO transactions (user_id, transaction_type, amount, balance_type, description, reference_id) VALUES (?, 'premium_upgrade', ?, 'total', 'Premium membership upgrade', ?)");
                            $stmt->bind_param("ids", $user_id, $upgrade_amount, $reference);
                            $stmt->execute();
                            $stmt->close();
                            
                            $success_message = "Membership upgrade is successful!";
                            
                        } elseif ($payment_type === 'senior_advertiser_upgrade') {
                            $plan_duration = isset($result['data']['metadata']['plan_duration']) ? $result['data']['metadata']['plan_duration'] : 'yearly';
                            $upgrade_amount = $amount;
                            
                            // Calculate expiry date based on plan duration
                            $expires_at = ($plan_duration === 'monthly') 
                                ? date('Y-m-d H:i:s', strtotime('+1 month'))
                                : date('Y-m-d H:i:s', strtotime('+1 year'));
                            
                            // Update user advertiser plan (NOT membership_type). Set advertiser_plan_start_date if it's the first time.
                            $stmt = $conn->prepare("UPDATE users SET advertiser_plan = 'senior', advertiser_plan_start_date = COALESCE(advertiser_plan_start_date, NOW()) WHERE id = ?");
                            $stmt->bind_param("i", $user_id);
                            $stmt->execute();
                            $stmt->close();
                            
                            $is_renewal = !empty($user['advertiser_plan_start_date']) ? 1 : 0; // Check if it's a renewal
                            $stmt = $conn->prepare("INSERT INTO advertiser_payments (user_id, amount, plan_duration, payment_method, payment_reference, status, is_renewal) VALUES (?, ?, ?, 'paystack', ?, 'completed', ?)");
                            $stmt->bind_param("idssi", $user_id, $upgrade_amount, $plan_duration, $reference, $is_renewal);
                            $stmt->execute();
                            $stmt->close();
                            
                            // Record transaction
                            $description = "Senior Advertiser plan upgrade (" . $plan_duration . ")";
                            $stmt = $conn->prepare("INSERT INTO transactions (user_id, transaction_type, amount, balance_type, description, reference_id) VALUES (?, 'premium_upgrade', ?, 'total', ?, ?)");
                            $stmt->bind_param("idss", $user_id, $upgrade_amount, $description, $reference);
                            $stmt->execute();
                            $stmt->close();
                            
                            $success_message = "Advertiser plan activated successfully";
                            
                        } elseif ($payment_type === 'deposit') {
                            // Process deposit
                            $deposit_purpose = isset($result['data']['metadata']['purpose']) 
                                ? $result['data']['metadata']['purpose'] 
                                : 'general';
                            
                            // Update user's total balance
                            $stmt = $conn->prepare("UPDATE balances SET total_balance = total_balance + ? WHERE user_id = ?");
                            $stmt->bind_param("di", $amount, $user_id);
                            $stmt->execute();
                            $stmt->close();
                            
                            // Record transaction
                            $description = "Deposit for " . $deposit_purpose;
                            $stmt = $conn->prepare("INSERT INTO transactions (user_id, transaction_type, amount, balance_type, description, reference_id) VALUES (?, 'deposit', ?, 'total', ?, ?)");
                            $stmt->bind_param("idss", $user_id, $amount, $description, $reference);
                            $stmt->execute();
                            $stmt->close();
                            
                            $success_message = "Deposit of ₦" . number_format($amount, 2) . " successful!";
                        }
                        
                        $conn->commit();
                        
                        // Refresh user data
                        $stmt = $conn->prepare("
                            SELECT u.*, b.total_balance, b.task_earnings, b.referral_earnings 
                            FROM users u 
                            LEFT JOIN balances b ON u.id = b.user_id 
                            WHERE u.id = ?
                        ");
                        $stmt->bind_param("i", $user_id);
                        $stmt->execute();
                        $result = $stmt->get_result();
                        $user = $result->fetch_assoc();
                        $stmt->close();
                        
                        // Recalculate prices after refresh
                        $premium_price = getRenewalPrice($user['membership_start_date'], 1500, 3500);
                        $senior_yearly_price = getRenewalPrice($user['advertiser_plan_start_date'], 2500, 5500);
                        
                    } catch (Exception $e) {
                        $conn->rollback();
                        $error_message = "Payment processing failed. Please contact support with reference: " . $reference;
                        error_log("Payment processing exception: " . $e->getMessage() . " for reference: " . $reference);
                    }
                }
            }
        }
    } else {
        $error_message = "Payment was not successful";
    }
}

$is_premium = ($user['membership_type'] === 'premium');
$is_advertiser = ($user['advertiser_plan'] === 'senior'); // Changed to check advertiser_plan
$membership_display = $is_premium ? 'Premium Member' : 'Basic Member';
if ($is_advertiser) {
    $membership_display .= ' + Senior Advertiser';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>FlowEarner Membership</title>
  <!-- Paystack inline script instead of Flutterwave -->
  <script src="https://js.paystack.co/v1/inline.js"></script>
  <script src="https://checkout.flutterwave.com/v3.js"></script>
  <style>
     :root {
      --page-blue-900: #030922;
      --page-blue-700: #0a164a;
      --page-blue-500: #142a7e;
      --page-blue-300: #2c5bf5;
      --page-mint: #4de1c1;
      --page-white: #f5f9ff;
      --panel-glass: rgba(13, 24, 62, 0.78);
      --panel-border: rgba(86, 139, 241, 0.28);
      --shadow-heavy: 0 40px 120px rgba(4, 10, 36, 0.65);
      --transition-long: 0.85s cubic-bezier(0.19, 1, 0.22, 1);
      --transition-short: 0.4s ease;
    }

    * { box-sizing: border-box; }

    body {
      margin: 0;
      font-family: "Titillium Web", "Segoe UI", sans-serif;
      background: radial-gradient(circle at 0% 0%, rgba(61, 116, 255, 0.28), transparent 55%),
                  radial-gradient(circle at 100% 0%, rgba(77, 225, 193, 0.18), transparent 40%),
                  linear-gradient(180deg, var(--page-blue-900), var(--page-blue-700));
      color: var(--page-white);
      overflow-x: hidden;
    }

    /* Fixed sidebar layout structure */
    .page-shell {
      min-height: 100vh;
      display: flex;
    }
 aside {
      position: fixed;
      left: 0;
      top: 0;
      bottom: 0;
      width: 320px;
      background: rgba(13, 24, 62, 0.78);
      backdrop-filter: blur(18px);
      padding: clamp(1.25rem, 3vw, 2.25rem) clamp(1rem, 2.5vw, 2rem);
      display: flex;
      flex-direction: column;
      gap: clamp(1.25rem, 2.5vw, 2rem);
      border-right: 1px solid var(--panel-border);
      overflow-y: auto;
      z-index: 100;
      transition: transform var(--transition-short);
    }

    aside::before {
      content: "";
      position: absolute;
      inset: 0;
      background: 
        radial-gradient(circle at 20% 30%, rgba(251, 191, 36, 0.15), transparent 50%),
        radial-gradient(circle at 80% 70%, rgba(245, 158, 11, 0.12), transparent 45%);
      pointer-events: none;
    }

    main {
      margin-left: 320px;
      flex: 1;
      padding: clamp(2rem, 4vw, 2.625rem) clamp(1.5rem, 3vw, 3rem);
      display: grid;
      gap: clamp(2rem, 3.5vw, 2.625rem);
    }

    @media (max-width: 960px) {
      .page-shell {
        display: block;
      }

      aside {
        position: relative;
        top: 0;
        width: 100%;
        height: auto;
        border-right: none;
        border-bottom: 1px solid var(--panel-border);
        padding: clamp(1rem, 2.5vw, 1.75rem) clamp(0.875rem, 2vw, 1.25rem);
        gap: clamp(0.875rem, 2vw, 1.25rem);
      }

      aside.scrolled .page-title,
      aside.scrolled .side-description,
      aside.scrolled .vector-cluster {
        display: none;
      }

      aside.scrolled {
        padding: clamp(0.75rem, 1.5vw, 1rem) clamp(0.875rem, 2vw, 1.25rem);
      }

      aside.scrolled .aside-welcome {
        grid-template-columns: auto 1fr;
      }

      main {
        margin-left: 0;
        padding: clamp(1.5rem, 3vw, 2rem) clamp(0.625rem, 1.5vw, 1.25rem) 10rem;
      }

      .vector-cluster {
        display: none;
      }
    }

    .back-link {
      display: inline-flex;
      align-items: center;
      gap: 10px;
      font-weight: 600;
      font-size: clamp(0.75rem, 1.5vw, 0.875rem);
      letter-spacing: 0.1em;
      text-transform: uppercase;
      color: rgba(210, 226, 255, 0.78);
      transition: color var(--transition-short), transform var(--transition-short);
      text-decoration: none;
    }

    .back-link:hover { color: var(--page-white); transform: translateX(-4px); }

    .page-title {
      font-size: clamp(1rem, 3vw, 1.5rem);
      letter-spacing: 0.1em;
      text-transform: uppercase;
      margin: 0 0 clamp(0.5rem, 1vw, 0.75rem);
      font-weight: 700;
    }

    .vector-cluster {
      position: relative;
      width: 100%;
      border-radius: 20px;
      padding: 20px;
      background: linear-gradient(135deg, rgba(251, 191, 36, 0.25), rgba(12, 29, 82, 0.85));
      box-shadow: 0 20px 60px rgba(251, 191, 36, 0.3);
      overflow: hidden;
    }

    .vector-cluster::after {
      content: "";
      position: absolute;
      width: 280px;
      height: 280px;
      top: -120px;
      right: -100px;
      border-radius: 50%;
      background: radial-gradient(circle, rgba(251, 191, 36, 0.4), transparent 65%);
    }

    .vector-cluster img {
      width: 100%;
      border-radius: 16px;
      display: block;
      filter: drop-shadow(0 20px 60px rgba(251, 191, 36, 0.4));
    }

     .aside-welcome {
      display: grid;
      grid-template-columns: auto 1fr;
      align-items: center;
      gap: clamp(0.75rem, 1.5vw, 1rem);
     
      background: linear-gradient(135deg, rgba(44, 91, 245, 0.3), rgba(26, 58, 171, 0.2));
      border: 1px solid rgba(44, 91, 245, 0.5);
      box-shadow: 0 0 10px rgba(44, 91, 245, 0.6);
      border-radius: 20px;
      padding: clamp(0.875rem, 1.75vw, 1.125rem);
      
      position: relative;
      z-index: 2;
    }

    .aside-avatar {
      width: clamp(48px, 10vw, 64px);
      height: clamp(48px, 10vw, 64px);
      border-radius: 50%;
      overflow: hidden;
      border: 4px solid rgba(251, 191, 36, 0.35);
      box-shadow: 0 14px 34px rgba(3, 9, 30, 0.55);
    }

    .aside-avatar img {
      width: 100%;
      display: block;
    }

    .welcome-tag {
      margin: 0;
      font-size: clamp(0.6875rem, 1.25vw, 0.75rem);
      letter-spacing: 0.12em;
      text-transform: uppercase;
      color: rgba(205, 219, 255, 0.62);
    }

    .aside-welcome h3 {
      margin: clamp(0.25rem, 0.5vw, 0.375rem) 0 clamp(0.125rem, 0.25vw, 0.25rem);
      font-size: clamp(1rem, 2vw, 1.12rem);
      letter-spacing: 0.04em;
      color: var(--page-white);
      font-weight: 700;
    }

    .welcome-meta {
      font-size: clamp(0.75rem, 1.5vw, 0.8rem);
      letter-spacing: 0.08em;
      color: rgba(149, 183, 255, 0.7);
    }

    /* Main content membership cards */
    .membership-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
      gap: 24px;
    }

    .membership-card {
      padding: clamp(24px, 4vw, 36px);
      border-radius: 24px;
      background: var(--panel-glass);
      border: 1px solid var(--panel-border);
      box-shadow: var(--shadow-heavy);
      position: relative;
      overflow: hidden;
      transition: transform var(--transition-long);
    }

    .membership-card:hover {
      transform: translateY(-8px);
    }

    .membership-card.current {
      border-color: rgba(77, 225, 193, 0.4);
    }

    .membership-card.premium {
      border-color: rgba(251, 191, 36, 0.4);
      background: linear-gradient(135deg, rgba(251, 191, 36, 0.08), rgba(13, 24, 62, 0.78));
    }

    .membership-card::before {
      content: "";
      position: absolute;
      inset: 0;
      background: url("front/assets/images/header-right-img.png") center/cover no-repeat;
      opacity: 0.05;
      pointer-events: none;
    }

    .card-badge {
      display: inline-block;
      padding: 8px 16px;
      background: rgba(77, 225, 193, 0.2);
      border: 1px solid rgba(77, 225, 193, 0.3);
      border-radius: 20px;
      font-size: clamp(0.7rem, 1.5vw, 0.75rem);
      letter-spacing: 0.1em;
      text-transform: uppercase;
      color: var(--page-mint);
      margin-bottom: 16px;
      font-weight: 600;
    }

    .card-badge.premium {
      background: rgba(251, 191, 36, 0.2);
      border-color: rgba(251, 191, 36, 0.3);
      color: #fbbf24;
    }

    .card-title {
      font-size: clamp(1.5rem, 3vw, 1.8rem);
      margin: 0 0 12px;
      letter-spacing: 0.05em;
      position: relative;
      z-index: 2;
    }

    .card-price {
      font-size: clamp(2rem, 5vw, 2.8rem);
      font-weight: 700;
      margin-bottom: 8px;
      position: relative;
      z-index: 2;
    }

    .card-price span {
      font-size: clamp(1rem, 2vw, 1.2rem);
      color: rgba(216, 230, 255, 0.7);
      font-weight: 400;
    }

    .card-description {
      color: rgba(216, 230, 255, 0.78);
      line-height: 1.7;
      font-size: clamp(0.9rem, 2vw, 1rem);
      margin-bottom: 24px;
      position: relative;
      z-index: 2;
    }

    .card-features {
      list-style: none;
      padding: 0;
      margin: 0 0 24px;
      display: grid;
      gap: 12px;
      position: relative;
      z-index: 2;
    }

    .card-features li {
      display: flex;
      align-items: center;
      gap: 12px;
      font-size: clamp(0.85rem, 1.5vw, 0.95rem);
      color: rgba(210, 224, 253, 0.85);
    }

    .feature-icon {
      width: 24px;
      height: 24px;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 12px;
      flex-shrink: 0;
    }

    .feature-check {
      background: rgba(77, 225, 193, 0.3);
      color: var(--page-mint);
    }

    .feature-lock {
      background: rgba(239, 68, 68, 0.3);
      color: #ef4444;
    }

    .upgrade-btn {
      width: 100%;
      padding: clamp(12px, 2.5vw, 16px);
      border: none;
      border-radius: 14px;
      font-size: clamp(0.9rem, 2vw, 1rem);
      font-weight: 600;
      cursor: pointer;
      transition: transform var(--transition-short);
      position: relative;
      z-index: 2;
      letter-spacing: 0.02em;
    }

    .upgrade-btn.current {
      background: rgba(100, 152, 255, 0.3);
      color: rgba(210, 224, 253, 0.7);
      cursor: not-allowed;
    }

    .upgrade-btn.premium {
      background: linear-gradient(135deg, #fbbf24, #f59e0b);
      color: var(--page-blue-900);
      box-shadow: 0 12px 28px rgba(251, 191, 36, 0.4);
    }

    .upgrade-btn.premium:hover {
      transform: translateY(-3px);
      box-shadow: 0 16px 36px rgba(251, 191, 36, 0.5);
    }

    /* Benefits section */
    .section-white {
      background: rgba(245, 249, 255, 0.96);
      border: 1px solid rgba(60, 102, 212, 0.14);
      border-radius: 22px;
      box-shadow: var(--shadow-heavy);
      padding: clamp(24px, 4vw, 36px);
      color: var(--page-blue-700);
    }

    .section-white h2 {
      color: var(--page-blue-500);
      margin-top: 0;
      font-size: clamp(1.3rem, 3vw, 1.6rem);
      margin-bottom: 24px;
    }

    .benefits-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
      gap: 20px;
    }

    .benefit-item {
      display: flex;
      gap: 16px;
      padding: clamp(16px, 3vw, 20px);
      border-radius: 14px;
      background: rgba(44, 92, 240, 0.08);
      border: 1px solid rgba(44, 92, 240, 0.16);
      transition: transform var(--transition-short);
    }

    .benefit-item:hover {
      transform: translateX(4px);
    }

    .benefit-icon {
      width: 48px;
      height: 48px;
      border-radius: 12px;
      background: linear-gradient(135deg, #fbbf24, #f59e0b);
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 24px;
      flex-shrink: 0;
    }

    .benefit-content h3 {
      margin: 0 0 6px;
      font-size: clamp(0.95rem, 2vw, 1.05rem);
      color: var(--page-blue-500);
    }

    .benefit-content p {
      margin: 0;
      font-size: clamp(0.85rem, 1.5vw, 0.9rem);
      color: rgba(20, 42, 126, 0.7);
      line-height: 1.6;
    }

    footer {
      padding: 40px 0 32px;
      background: linear-gradient(180deg, rgba(1, 5, 16, 0.95), rgba(1, 4, 12, 0.98));
      border-top: 1px solid rgba(86, 136, 230, 0.2);
    }

    .footer-grid {
      max-width: 1020px;
      margin: 0 auto;
      padding: 0 clamp(16px, 4vw, 32px);
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(140px, 1fr));
      gap: 20px;
    }

    .footer-list h4 {
      text-transform: uppercase;
      letter-spacing: 0.1em;
      font-size: clamp(0.75rem, 1.5vw, 0.82rem);
      margin-bottom: 14px;
      color: rgba(181, 201, 240, 0.76);
    }

    .footer-list ul {
      list-style: none;
      padding: 0;
      margin: 0;
      display: grid;
      gap: 10px;
    }

    .footer-list a {
      color: rgba(210, 224, 253, 0.7);
      font-size: clamp(0.8rem, 1.5vw, 0.9rem);
      transition: color var(--transition-short);
    }

    .footer-list a:hover { color: var(--page-mint); }

    .footer-brand {
      text-align: center;
      text-transform: uppercase;
      letter-spacing: 0.12em;
      color: rgba(160, 180, 226, 0.68);
      margin-top: 28px;
      font-size: clamp(0.7rem, 1.5vw, 0.76rem);
    }

    /* Updated mobile footer with 5 icons */
    .mobile-fintech-footer {
      display: none;
      position: fixed;
      left: 12px;
      right: 12px;
      bottom: 16px;
      padding: 10px;
      background: transparent;
      border: 1px solid rgba(86, 139, 241, 0.35);
      border-radius: 32px;
      backdrop-filter: blur(50px);
      box-shadow: 0 20px 60px rgba(4, 10, 36, 0.7);
      justify-content: space-around;
      align-items: center;
      z-index: 90;
    }

    .mobile-fintech-footer a {
      flex: 1;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      gap: 4px;
      text-decoration: none;
      color: rgba(205, 219, 255, 0.75);
      font-size: 0.45rem;
      letter-spacing: 0.06em;
      text-transform: uppercase;
      transition: all var(--transition-short);
      padding: 8px 4px;
      border-radius: 16px;
    }

    /* Special styling for middle icon (3rd icon - Withdraw) */
    /* .mobile-fintech-footer a:nth-child(3) {
      position: relative;
      transform: translateY(-12px);
    } */

    .mobile-fintech-footer a:nth-child(3) .icon-wrapper {
      width: 56px;
      height: 56px;
      border-radius: 50%;
      background: linear-gradient(135deg, rgba(77, 225, 193, 0.25), rgba(47, 91, 234, 0.25));
      backdrop-filter: blur(12px);
      border: 2px solid rgba(77, 225, 193, 0.4);
      display: flex;
      align-items: center;
      justify-content: center;
      box-shadow: 0 8px 24px rgba(77, 225, 193, 0.3);
    }

    .mobile-fintech-footer a:nth-child(3) svg {
      width: 28px;
      height: 28px;
    }

    .mobile-fintech-footer a.active {
      color: var(--page-mint);
    }

    .mobile-fintech-footer svg {
      width: 22px;
      height: 22px;
      fill: currentColor;
      filter: drop-shadow(0 4px 12px rgba(4, 10, 36, 0.4));
    }

    .mobile-fintech-footer a:hover {
      color: var(--page-mint);
      transform: translateY(-2px);
    }

    .mobile-fintech-footer a:nth-child(3):hover {
      transform: translateY(-14px);
    }

    @media (max-width: 680px) {
      body {
        padding-bottom: 100px;
      }

      .mobile-fintech-footer {
        display: flex;
      }
    }

    /* Common toast styles */
.toast-message {
  position: fixed;
  top: 20px;
  right: -400px; /* start hidden off-screen */
  padding: 16px 24px;
  border-radius: 12px;
  color: white;
  font-family: 'Segoe UI', sans-serif;
  font-size: 15px;
  z-index: 1000;
  opacity: 0;
  box-shadow: 0 10px 40px rgba(0, 0, 0, 0.2);
  transition: right 0.6s ease, opacity 0.6s ease;
}

/* Success styling */
.toast-message.success {
  background: rgba(77, 225, 193, 0.95);
  color: #030922;
  box-shadow: 0 10px 40px rgba(77, 225, 193, 0.4);
}

/* Error styling */
.toast-message.error {
  background: rgba(255, 77, 77, 0.95);
  color: #fff;
  box-shadow: 0 10px 40px rgba(255, 77, 77, 0.4);
}

/* When visible */
.toast-message.show {
  right: 20px;
  opacity: 1;
}

    /* Add checkout cart modal styles */
    .checkout-modal {
      display: none;
      position: fixed;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      background: rgba(3, 9, 34, 0.95);
      backdrop-filter: blur(10px);
      z-index: 1000;
      overflow-y: auto;
      padding: 20px;
    }

    .checkout-modal.active {
      display: flex;
      align-items: center;
      justify-content: center;
    }

    .checkout-container {
      max-width: 900px;
      width: 100%;
      background: var(--panel-glass);
      border: 1px solid var(--panel-border);
      border-radius: 24px;
      padding: clamp(24px, 4vw, 40px);
      box-shadow: var(--shadow-heavy);
    }

    .checkout-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 32px;
      padding-bottom: 20px;
      border-bottom: 1px solid var(--panel-border);
    }

    .checkout-header h2 {
      font-size: clamp(1.5rem, 3vw, 2rem);
      margin: 0;
      color: var(--page-white);
    }

    .close-checkout {
      background: none;
      border: none;
      color: rgba(216, 230, 255, 0.7);
      font-size: 32px;
      cursor: pointer;
      transition: color var(--transition-short);
    }

    .close-checkout:hover {
      color: var(--page-white);
    }

    .checkout-grid {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 32px;
    }

    @media (max-width: 768px) {
      .checkout-grid {
        grid-template-columns: 1fr;
      }
    }

    .order-summary {
      background: rgba(44, 91, 245, 0.08);
      border: 1px solid rgba(44, 91, 245, 0.2);
      border-radius: 16px;
      padding: 24px;
    }

    .order-summary h3 {
      margin: 0 0 20px;
      font-size: 1.2rem;
      color: var(--page-white);
    }

    .order-item {
      display: flex;
      justify-content: space-between;
      padding: 12px 0;
      border-bottom: 1px solid rgba(86, 139, 241, 0.2);
    }

    .order-item:last-child {
      border-bottom: none;
      font-weight: 700;
      font-size: 1.2rem;
      color: var(--page-mint);
      padding-top: 16px;
      margin-top: 8px;
      border-top: 2px solid rgba(77, 225, 193, 0.3);
    }

    .billing-form {
      display: grid;
      gap: 20px;
    }

    .form-group {
      display: grid;
      gap: 8px;
    }

    .form-group label {
      color: rgba(216, 230, 255, 0.9);
      font-size: 0.9rem;
      font-weight: 600;
    }

    .form-group input,
    .form-group select,
    .form-group textarea {
      width: 100%;
      padding: 12px;
      border-radius: 10px;
      border: 1px solid rgba(86, 139, 241, 0.3);
      background: rgba(13, 24, 62, 0.5);
      color: var(--page-white);
      font-size: 1rem;
      transition: border-color var(--transition-short);
    }

    .form-group input:focus,
    .form-group select:focus,
    .form-group textarea:focus {
      outline: none;
      border-color: var(--page-mint);
    }

    .payment-gateway-selector {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 16px;
      margin: 24px 0;
    }

    .gateway-option {
      padding: 20px;
      border: 2px solid rgba(86, 139, 241, 0.3);
      border-radius: 12px;
      background: rgba(13, 24, 62, 0.5);
      cursor: pointer;
      transition: all var(--transition-short);
      text-align: center;
    }

    .gateway-option:hover {
      border-color: var(--page-mint);
      transform: translateY(-2px);
    }

    .gateway-option.selected {
      border-color: var(--page-mint);
      background: rgba(77, 225, 193, 0.1);
    }

    .gateway-option input[type="radio"] {
      display: none;
    }

    .gateway-logo {
      font-size: 1.5rem;
      font-weight: 700;
      color: var(--page-white);
      margin-bottom: 8px;
    }

    .proceed-btn {
      width: 100%;
      padding: 16px;
      border: none;
      border-radius: 14px;
      font-size: 1.1rem;
      font-weight: 600;
      cursor: pointer;
      background: linear-gradient(135deg, #fbbf24, #f59e0b);
      color: var(--page-blue-900);
      box-shadow: 0 12px 28px rgba(251, 191, 36, 0.4);
      transition: transform var(--transition-short);
    }

    .proceed-btn:hover {
      transform: translateY(-3px);
      box-shadow: 0 16px 36px rgba(251, 191, 36, 0.5);
    }

    .proceed-btn:disabled {
      opacity: 0.5;
      cursor: not-allowed;
      transform: none;
    }

  </style>
</head>
<body>


 <?php if (isset($success_message)): ?>
  <div id="toast-success" class="toast-message success">
    <?php echo htmlspecialchars($success_message); ?>
  </div>
<?php endif; ?>

<?php if (isset($error_message)): ?>
  <div id="toast-error" class="toast-message error">
    <?php echo htmlspecialchars($error_message); ?>
  </div>
<?php endif; ?>

  <div class="page-shell">
    <?php include "embed.php"; ?>
    <aside id="sidebar">
      <a class="back-link" href="dashboard.php">← Prev</a>
      <div class="aside-welcome">
        <div class="aside-avatar">
           <img src="<?php echo !empty($user_data['profile_picture']) 
      ? htmlspecialchars($user_data['profile_picture']) 
      : 'front/assets/images/default-avatar.png'; ?>" 
      alt="User avatar">
        </div>
        <div>
          <p class="welcome-tag">Current Status</p>
          <h3><?php echo htmlspecialchars($user['username']); ?></h3>
          <p class="welcome-meta"><?php echo $membership_display; ?></p>
        </div>
      </div>
      <div>
        <h2 class="page-title">Membership</h2>
        <p class="side-description">Upgrade to Senior membership and unlock premium features. Deposit funds for ads, games, and more.</p>
      </div>
      <!-- <div class="vector-cluster">
        <img src="front/assets/images/who-we-are-img.png" alt="Vector module" />
      </div> -->
    </aside>
    <main>
      <!-- <?php //if (isset($success_message)): ?>
        <div style="padding: 16px; background: rgba(77, 225, 193, 0.2); border: 1px solid rgba(77, 225, 193, 0.4); border-radius: 12px; color: var(--page-mint); margin-bottom: 24px;">
          ✓ <?php //echo htmlspecialchars($success_message); ?>
        </div>
      <?php //endif; ?>
      
      <?php //if (isset($error_message)): ?>
        <div style="padding: 16px; background: rgba(239, 68, 68, 0.2); border: 1px solid rgba(239, 68, 68, 0.4); border-radius: 12px; color: #ef4444; margin-bottom: 24px;">
          ✗ <?php //echo htmlspecialchars($error_message); ?>
        </div>
      <?php //endif; ?> -->

     

      <!-- Added deposit section for users to add funds -->
      <section>
        <h2 style="font-size: clamp(1.3rem, 3vw, 1.6rem); margin-bottom: 20px; color: var(--page-white); display:flex; align-items:center; gap:8px;">
  <svg viewBox="0 0 24 24" width="22" height="22" fill="currentColor">
    <path d="M12 2c1.1 0 2 .9 2 2v1.2c1.7.5 3 2 3 3.8 0 2.2-1.8 4-4 4h-2c-2.2 0-4-1.8-4-4 0-1.8 1.3-3.3 3-3.8V4c0-1.1.9-2 2-2Zm-2 11h4v2h-4v-2Zm-2 4h8v2H8v-2Zm-2 4h12v2H6v-2Z"/>
  </svg>
  Deposit Funds
</h2>

        <div class="membership-grid">
          <article class="membership-card">
            <span class="card-badge">Quick Deposit</span>
            <h3 class="card-title">Add Balance</h3>
            <p class="card-description">Deposit money to your account for publishing ads, playing games, or upgrading to premium.</p>
            
            <div style="margin: 24px 0;">
              <label style="display: block; margin-bottom: 8px; color: rgba(216, 230, 255, 0.9); font-size: 0.9rem;">Amount (₦)</label>
              <input type="number" id="deposit-amount" min="1000" step="1000" placeholder="Enter amount" style="width: 100%; padding: 12px; border-radius: 10px; border: 1px solid rgba(86, 139, 241, 0.3); background: rgba(13, 24, 62, 0.5); color: var(--page-white); font-size: 1rem;" />
              <p style="color: #e53935;      /* red */
              font-size: 12px;
              margin-top: 5px;
              font-weight: 500;">Minimum deposit amount is ₦1,000</p>

            </div>
            
            <div style="margin: 24px 0;">
              <label style="display: block; margin-bottom: 8px; color: rgba(216, 230, 255, 0.9); font-size: 0.9rem;">Purpose</label>
              <select id="deposit-purpose" style="width: 100%; padding: 12px; border-radius: 10px; border: 1px solid rgba(86, 139, 241, 0.3); background: rgba(13, 24, 62, 0.5); color: var(--page-white); font-size: 1rem;">
                <option value="ads">Publish Advertisements</option>
                <option value="games">Games & Entertainment</option>
                <option value="general">General Balance</option>
              </select>
            </div>
            
            <button class="upgrade-btn premium" onclick="initiateDeposit()">Deposit Now</button>
          </article>
          
          <article class="membership-card" style="background: linear-gradient(135deg, rgba(77, 225, 193, 0.08), rgba(13, 24, 62, 0.78));">
            <span class="card-badge">Current Balance</span>
            <h3 class="card-title">Your Wallet</h3>
            <div style="margin: 20px 0;">
              <div style="margin-bottom: 16px;">
                <p style="margin: 0; font-size: 0.85rem; color: rgba(216, 230, 255, 0.7);">Total Balance</p>
                <p style="margin: 4px 0 0; font-size: 1.8rem; font-weight: 700; color: var(--page-mint);">₦<?php echo number_format($user['total_balance'], 2); ?></p>
              </div>
              <div style="margin-bottom: 16px;">
                <p style="margin: 0; font-size: 0.85rem; color: rgba(216, 230, 255, 0.7);">Task Earnings</p>
                <p style="margin: 4px 0 0; font-size: 1.3rem; font-weight: 600; color: rgba(210, 224, 253, 0.9);">₦<?php echo number_format($user['task_earnings'], 2); ?></p>
              </div>
              <div>
                <p style="margin: 0; font-size: 0.85rem; color: rgba(216, 230, 255, 0.7);">Referral Earnings</p>
                <p style="margin: 4px 0 0; font-size: 1.3rem; font-weight: 600; color: rgba(210, 224, 253, 0.9);">₦<?php echo number_format($user['referral_earnings'], 2); ?></p>
              </div>
            </div>
          </article>
        </div>
      </section>

      <!-- Membership Cards -->
      <section style="margin-top: 32px;">
        <h2 style="font-size: clamp(1.3rem, 3vw, 1.6rem); margin-bottom: 20px; color: var(--page-white);">🎯 Membership Plans</h2>
        <div class="membership-grid">
          <!-- Current Plan -->
          <article class="membership-card <?php echo !$is_premium ? 'current' : ''; ?>">
            <?php if (!$is_premium): ?>
              <span class="card-badge">Current Plan</span>
            <?php endif; ?>
            <h3 class="card-title">Basic</h3>
            <div class="card-price">₦0<span>/month</span></div>
            <p class="card-description">Perfect for getting started with essential features</p>
            <ul class="card-features">
              <li>
                <span class="feature-icon feature-check">✓</span>
                Basic Dashboard Access
              </li>
              <li>
                <span class="feature-icon feature-check">✓</span>
                Standard Tasks
              </li>
              <li>
                <span class="feature-icon feature-check">✓</span>
                Basic Withdrawals
              </li>
              <li>
                <span class="feature-icon feature-lock">  <svg viewBox="0 0 24 24" width="20" height="20" fill="currentColor">
    <path d="M12 2a5 5 0 0 1 5 5v3h1a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V12a2 2 0 0 1 2-2h1V7a5 5 0 0 1 5-5Zm0 2a3 3 0 0 0-3 3v3h6V7a3 3 0 0 0-3-3Zm-6 9v8h12v-8H6Zm6 2a2 2 0 1 1 0 4 2 2 0 0 1 0-4Z"/>
  </svg></span>
                Advanced Analytics
              </li>
              <li>
                <span class="feature-icon feature-lock">  <svg viewBox="0 0 24 24" width="20" height="20" fill="currentColor">
    <path d="M12 2a5 5 0 0 1 5 5v3h1a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V12a2 2 0 0 1 2-2h1V7a5 5 0 0 1 5-5Zm0 2a3 3 0 0 0-3 3v3h6V7a3 3 0 0 0-3-3Zm-6 9v8h12v-8H6Zm6 2a2 2 0 1 1 0 4 2 2 0 0 1 0-4Z"/>
  </svg></span>
                Priority Support
              </li>
            </ul>
            <?php if (!$is_premium): ?>
              <button class="upgrade-btn current">Current Plan</button>
            <?php else: ?>
              <button class="upgrade-btn" style="background: rgba(100, 152, 255, 0.2); color: rgba(210, 224, 253, 0.7); cursor: default;">Previous Plan</button>
            <?php endif; ?>
          </article>

          <!-- Premium Plan -->
          <article class="membership-card premium <?php echo $is_premium ? 'current' : ''; ?>">
            <?php if ($is_premium): ?>
              <span class="card-badge premium">✓ Active</span>
            <?php else: ?>
              <span class="card-badge premium"> Recommended</span>
              <?php if ($premium_price == 1500): ?>
                <div style="position: absolute; top: 16px; right: 16px; background: linear-gradient(135deg, #ef4444, #dc2626); color: white; padding: 6px 12px; border-radius: 8px; font-size: 0.75rem; font-weight: 700; letter-spacing: 0.05em; box-shadow: 0 4px 12px rgba(239, 68, 68, 0.4); z-index: 10;">
                  57% OFF
                </div>
              <?php endif; ?>
            <?php endif; ?>
            <h3 class="card-title">Premium</h3>
            <?php if ($premium_price == 1500): ?>
              <div class="card-price">
                <span style="font-size: 1.2rem; color: rgba(216, 230, 255, 0.5); text-decoration: line-through; margin-right: 8px;">₦3,500</span>
                ₦1,500<span>/year</span>
              </div>
              <p style="font-size: 0.85rem; color: var(--page-mint); margin-top: 4px; margin-bottom: 12px;"> First year special discount!</p>
            <?php else: ?>
              <div class="card-price">₦<?php echo number_format($premium_price, 0); ?><span>/year</span></div>
            <?php endif; ?>
            <p class="card-description">Unlock all premium features and maximize your potential</p>
            <ul class="card-features">
              <li>
                <span class="feature-icon feature-check">✓</span>
                Everything in Basic
              </li>
              <li>
                <span class="feature-icon feature-check">✓</span>
                Advanced Analytics Dashboard
              </li>
              <li>
                <span class="feature-icon feature-check">✓</span>
                Priority 24/7 Support
              </li>
              <li>
                <span class="feature-icon feature-check">✓</span>
                Higher Withdrawal Limits
              </li>
              <li>
                <span class="feature-icon feature-check">✓</span>
                Exclusive Premium Tasks
              </li>
              <li>
                <span class="feature-icon feature-check">✓</span>
                Special Referral Bonuses (₦500 per upgrade)
              </li>
              <li>
                <span class="feature-icon feature-check">✓</span>
                Early Access to New Features
              </li>
            </ul>
            <?php if ($is_premium): ?>
              <button class="upgrade-btn current">Current Plan</button>
              <?php if ($user['membership_expires_at']): ?>
                <p style="margin-top: 12px; font-size: 0.85rem; color: rgba(216, 230, 255, 0.7); text-align: center;">
                  Expires: <?php echo date('M d, Y', strtotime($user['membership_expires_at'])); ?>
                </p>
              <?php endif; ?>
            <?php else: ?>
              <button class="upgrade-btn premium" onclick="openCheckout('premium_upgrade', <?php echo $premium_price; ?>, 'Premium Membership')">Upgrade to Premium</button>
            <?php endif; ?>
          </article>
        </div>
      </section>

      <!-- New separate section for Advertiser Plans -->
      <section style="margin-top: 20px;">
        <h2 style="font-size: clamp(1.3rem, 3vw, 1.6rem); margin-bottom: 12px; color: var(--page-white); display: flex; align-items: center; gap: 8px;">
          📢 Advertiser Plans
        </h2>
        <p style="color: rgba(216, 230, 255, 0.8); margin-bottom: 24px; font-size: 0.95rem;">
          Advertiser plans are separate from membership. You can be a Premium Member AND a Senior Advertiser at the same time!
        </p>
        <div class="membership-grid">
          <article class="membership-card premium" style="background: linear-gradient(135deg, rgba(251, 146, 60, 0.12), rgba(13, 24, 62, 0.78)); border-color: rgba(251, 146, 60, 0.45);">
            <?php if ($is_advertiser): ?>
              <span class="card-badge premium" style="background: rgba(77, 225, 193, 0.25); border-color: rgba(77, 225, 193, 0.4); color: var(--page-mint);">✓ Active Advertiser</span>
            <?php else: ?>
              <span class="card-badge premium" style="background: rgba(251, 146, 60, 0.25); border-color: rgba(251, 146, 60, 0.4); color: #fb923c;">🏆 Best for Advertising</span>
              <?php if ($senior_yearly_price == 2500): ?>
                <div style="position: absolute; top: 16px; right: 16px; background: linear-gradient(135deg, #ef4444, #dc2626); color: white; padding: 6px 12px; border-radius: 8px; font-size: 0.75rem; font-weight: 700; letter-spacing: 0.05em; box-shadow: 0 4px 12px rgba(239, 68, 68, 0.4); z-index: 10;">
                  55% OFF
                </div>
              <?php endif; ?>
            <?php endif; ?>
            <h3 class="card-title">Senior Advertiser</h3>
            <div class="card-price">
              <?php if ($senior_yearly_price == 2500): ?>
                <span style="font-size: 1.2rem; color: rgba(216, 230, 255, 0.5); text-decoration: line-through; margin-left: 8px; margin-right: 8px;">₦5,500</span>
                ₦2,500<span>/year</span>
              <?php else: ?>
                ₦<?php echo number_format($senior_yearly_price, 0); ?><span>/year</span>
              <?php endif; ?>
            </div>
            <?php if ($senior_yearly_price == 2500): ?>
              <p style="font-size: 0.85rem; color: var(--page-mint); margin-top: 4px; margin-bottom: 12px;"> First year special discount!</p>
            <?php endif; ?>
            <p class="card-description"> Advertiser plans are separate from membership. You can be a Premium Member AND a Senior Advertiser at the same time!</p>
            <ul class="card-features">
              <li>
                <span class="feature-icon feature-check" style="background: rgba(251, 146, 60, 0.3); color: #fb923c;">✓</span>
                Post Task Access - Create advertising tasks
              </li>
              <li>
                <span class="feature-icon feature-check" style="background: rgba(251, 146, 60, 0.3); color: #fb923c;">✓</span>
                Earn 5% Advertisement Invite Commission
              </li>
              <li>
                <span class="feature-icon feature-check" style="background: rgba(251, 146, 60, 0.3); color: #fb923c;">✓</span>
                Unlimited earning potential
              </li>
              <li>
                <span class="feature-icon feature-check" style="background: rgba(251, 146, 60, 0.3); color: #fb923c;">✓</span>
                Priority ad placement
              </li>
            </ul>
            <div style="margin: 16px 0; padding: 14px; background: rgba(251, 146, 60, 0.15); border: 1px solid rgba(251, 146, 60, 0.3); border-radius: 12px;">
              <p style="margin: 0; font-size: 0.85rem; line-height: 1.6; color: rgba(216, 230, 255, 0.85);">
                <strong style="color: #fb923c;"></strong>Invite 100 users to buy 2000 likes or followers worth ₦10,000, you will earn ₦500 per user and a total whopping amount of <strong style="color: var(--page-mint);">₦50,000</strong> instantly & unlimited earnings.
              </p>
            </div>
            <?php if ($is_advertiser): ?>
              <button class="upgrade-btn current">Active Advertiser Plan</button>
            <?php else: ?>
              <button class="upgrade-btn premium" style="background: linear-gradient(135deg, #fb923c, #f97316); margin-top: 12px;" onclick="openCheckout('senior_advertiser_upgrade', <?php echo $senior_yearly_price; ?>, 'Senior Advertiser Plan')">Continue to Senior</button>
            <?php endif; ?>
          </article>
        </div>
      </section>

<nav class="mobile-fintech-footer">
    
  <a href="dashboard.php">
    <svg viewBox="0 0 24 24"><path d="M12 3a9 9 0 1 1 0 18 9 9 0 0 1 0-18Zm1 4h-2v6h6v-2h-4V7Z"/></svg>
    <span>Dashboard</span>
  </a>

  <!-- Premium (crown icon) -->
  <a href="membership.php" class="active">
    <svg viewBox="0 0 24 24"><path d="M5 7l2.5 5 4.5-4 4.5 4L19 7l2 13H3l2-13Z"/></svg>
    <span>Premium</span>
  </a>

  <a href="daily-rewards.php">
    <svg viewBox="0 0 24 24"><path d="M20 3H4a1 1 0 0 0-1 1v16l5-3 5 3 5-3 5 3V4a1 1 0 0 0-1-1Zm-2 5-6.7 6.7L7 10.4l1.4-1.4 2.9 2.9L17.6 6 18 8Z"/></svg>
    <span>Rewards</span>
  </a>

  <!-- Referrals (users/people icon) -->
  <!-- <a href="refferrals.php">
    <svg viewBox="0 0 24 24"><path d="M12 12a4 4 0 1 0-4-4 4 4 0 0 0 4 4Zm0 2c-4 0-8 2-8 5v1h16v-1c0-3-4-5-8-5Zm7-6a3 3 0 1 0-3 3 3 3 0 0 0 3-3Zm-1 6a5 5 0 0 1 4 2.5v1.5h-4v-1.3a6.8 6.8 0 0 0-1.2-2.2A7.9 7.9 0 0 1 18 14Z"/></svg>
    <span>Referrals</span>
  </a> -->

  <a href="history.php">
  <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
    <path d="M13 3a9 9 0 1 0 9 9h-2a7 7 0 1 1-7-7V3l4 4-4 4V7a5 5 0 1 0 5 5h2a7 7 0 1 1-7-7z"/>
  </svg>
  <span>History</span>
</a>


  <a href="profile.php">
    <svg viewBox="0 0 24 24"><path d="M12 2a6 6 0 0 1 6 6c0 3.31-2.69 6-6 6s-6-2.69-6-6a6 6 0 0 1 6-6Zm0 14c4.42 0 8 1.79 8 4v2H4v-2c0-2.21 3.58-4 8-4Z"/></svg>
    <span>Profile</span>
  </a>
</nav>


    </main>
  </div>


  <!-- Checkout Cart Modal -->
  <div id="checkout-modal" class="checkout-modal">
    <div class="checkout-container">
      <div class="checkout-header">
        <h2>🛒 Checkout</h2>
        <button class="close-checkout" onclick="closeCheckout()">&times;</button>
      </div>
      
      <div class="checkout-grid">
        <!-- Order Summary -->
        <div class="order-summary">
          <h3>Order Summary</h3>
          <div class="order-item">
            <span>Item:</span>
            <span id="order-item-name">-</span>
          </div>
          <div class="order-item">
            <span>Price:</span>
            <span id="order-item-price">₦0.00</span>
          </div>
          <div class="order-item">
            <span>Total:</span>
            <span id="order-total">₦0.00</span>
          </div>
        </div>

        <!-- Billing Form -->
        <form id="billing-form" class="billing-form">
          <h3 style="margin: 0 0 16px; color: var(--page-white);">Billing Information</h3>
          
          <div class="form-group">
            <label>Full Name *</label>
            <input type="text" name="full_name" value="<?php echo $billing_info ? htmlspecialchars($billing_info['full_name']) : htmlspecialchars($user_data['full_name']); ?>" required>
          </div>

          <div class="form-group">
            <label>Email Address *</label>
            <input type="email" name="email" value="<?php echo $billing_info ? htmlspecialchars($billing_info['email']) : htmlspecialchars($user_data['email']); ?>" required>
          </div>

          <div class="form-group">
            <label>Phone Number *</label>
            <input type="tel" name="phone" value="<?php echo $billing_info ? htmlspecialchars($billing_info['phone']) : ''; ?>" required>
          </div>

          <div class="form-group">
            <label>Address *</label>
            <textarea name="address" rows="2" required><?php echo $billing_info ? htmlspecialchars($billing_info['address']) : ''; ?></textarea>
          </div>

          <div class="form-group">
            <label>City *</label>
            <input type="text" name="city" value="<?php echo $billing_info ? htmlspecialchars($billing_info['city']) : ''; ?>" required>
          </div>

          <div class="form-group">
            <label>State *</label>
            <input type="text" name="state" value="<?php echo $billing_info ? htmlspecialchars($billing_info['state']) : ''; ?>" required>
          </div>

          <h3 style="margin: 24px 0 16px; color: var(--page-white);">Select Payment Gateway</h3>
          <div class="payment-gateway-selector">
            <label class="gateway-option selected" onclick="selectGateway('paystack')">
              <input type="radio" name="payment_gateway" value="paystack" checked>
              <div class="gateway-logo">💳 Paystack</div>
              <small style="color: rgba(216, 230, 255, 0.7);">Card, Bank Transfer</small>
            </label>
            <label class="gateway-option" onclick="selectGateway('flutterwave')">
              <input type="radio" name="payment_gateway" value="flutterwave">
              <div class="gateway-logo">🌊 Flutterwave</div>
              <small style="color: rgba(216, 230, 255, 0.7);">Card, USSD, Bank</small>
            </label>
          </div>

          <button type="button" class="proceed-btn" onclick="proceedToPayment()">Proceed to Payment</button>
        </form>
      </div>
    </div>
  </div>

  <script>
    let lastScrollTop = 0;
    const sidebar = document.getElementById('sidebar');
    
    window.addEventListener('scroll', function() {
      if (window.innerWidth <= 960) {
        let scrollTop = window.pageYOffset || document.documentElement.scrollTop;
        
        if (scrollTop > lastScrollTop && scrollTop > 50) {
          sidebar.classList.add('scrolled');
        } else if (scrollTop < lastScrollTop) {
          sidebar.classList.remove('scrolled');
        }
        
        lastScrollTop = scrollTop <= 0 ? 0 : scrollTop;
      }
    }, false);

    let currentOrderType = '';
    let currentAmount = 0;
    let currentItemName = '';

    function openCheckout(orderType, amount, itemName) {
      currentOrderType = orderType;
      currentAmount = amount;
      currentItemName = itemName;
      
      document.getElementById('order-item-name').textContent = itemName;
      document.getElementById('order-item-price').textContent = '₦' + amount.toLocaleString();
      document.getElementById('order-total').textContent = '₦' + amount.toLocaleString();
      document.getElementById('checkout-modal').classList.add('active');
    }

    function closeCheckout() {
      document.getElementById('checkout-modal').classList.remove('active');
    }

    function selectGateway(gateway) {
      document.querySelectorAll('.gateway-option').forEach(opt => opt.classList.remove('selected'));
      event.currentTarget.classList.add('selected');
      document.querySelector(`input[value="${gateway}"]`).checked = true;
    }

    function proceedToPayment() {
      const form = document.getElementById('billing-form');
      if (!form.checkValidity()) {
        form.reportValidity();
        return;
      }

      const formData = new FormData(form);
      const gateway = formData.get('payment_gateway');
      
      // Save billing info and create order
      const billingData = {
        action: 'save_billing',
        full_name: formData.get('full_name'),
        email: formData.get('email'),
        phone: formData.get('phone'),
        address: formData.get('address'),
        city: formData.get('city'),
        state: formData.get('state'),
        order_type: currentOrderType,
        amount: currentAmount,
        payment_gateway: gateway,
        metadata: {
          item_name: currentItemName
        }
      };

      // Close checkout modal
      closeCheckout();

      // Initiate payment based on selected gateway
      if (gateway === 'paystack') {
        initiatePaystackPayment(billingData);
      } else {
        initiateFlutterwavePayment(billingData);
      }
    }

    function initiatePaystackPayment(billingData) {
      var handler = PaystackPop.setup({
        key: "<?php echo PAYSTACK_PUBLIC_KEY; ?>",
        email: billingData.email,
        amount: billingData.amount * 100,
        currency: "NGN",
        ref: currentOrderType.toUpperCase() + "-" + Date.now(),
        metadata: {
          payment_type: currentOrderType,
          user_id: <?php echo $user_id; ?>,
          custom_fields: [
            {
              display_name: "Customer Name",
              variable_name: "customer_name",
              value: billingData.full_name
            }
          ]
        },
        callback: function(response) {
          window.location.href = "membership.php?status=success&reference=" + response.reference;
        },
        onClose: function() {
          console.log("Payment cancelled");
        }
      });
      handler.openIframe();
    }

    function initiateFlutterwavePayment(billingData) {
      FlutterwaveCheckout({
        public_key: "<?php echo FLUTTERWAVE_PUBLIC_KEY; ?>",
        tx_ref: currentOrderType.toUpperCase() + "-" + Date.now(),
        amount: billingData.amount,
        currency: "NGN",
        payment_options: "card, banktransfer, ussd",
        customer: {
          email: billingData.email,
          phone_number: billingData.phone,
          name: billingData.full_name,
        },
        customizations: {
          title: "FlowEarner",
          description: billingData.metadata.item_name,
          logo: "front/assets/images/logo.png",
        },
        callback: function(data) {
          if (data.status === "successful") {
            window.location.href = "membership.php?status=success&reference=" + data.tx_ref;
          }
        },
        onclose: function() {
          console.log("Payment cancelled");
        },
      });
    }

    function initiateDeposit() {
      const amount = document.getElementById('deposit-amount').value;
      const purpose = document.getElementById('deposit-purpose').value;

      function showError(message) {
        let errorToast = document.getElementById("toast-error");
        if (!errorToast) {
          errorToast = document.createElement("div");
          errorToast.id = "toast-error";
          errorToast.className = "toast-message error";
          document.body.appendChild(errorToast);
        }
        errorToast.textContent = message;
        errorToast.classList.remove("show");
        setTimeout(() => errorToast.classList.add("show"), 50);
        setTimeout(() => errorToast.classList.remove("show"), 4000);
      }

      if (!amount || amount < 1000) {
        showError("Minimum Deposit is ₦1,000");
        return;
      }

      // Open checkout for deposit
      openCheckout('deposit', parseFloat(amount), 'Account Deposit - ' + purpose);
    }

    // function initiateUpgrade() {
    //   var handler = PaystackPop.setup({
    //     key: "<?php echo PAYSTACK_PUBLIC_KEY; ?>",
    //     email: "<?php echo $user['email']; ?>",
    //     amount: <?php echo $premium_price * 100; ?>, // Paystack expects amount in kobo
    //     currency: "NGN",
    //     ref: "PREM-UPG-" + Date.now(),
    //     metadata: {
    //       payment_type: "premium_upgrade",
    //       user_id: <?php echo $user_id; ?>,
    //       custom_fields: [
    //         {
    //           display_name: "Customer Name",
    //           variable_name: "customer_name",
    //           value: "<?php echo $user['full_name']; ?>"
    //         }
    //       ]
    //     },
    //     callback: function(response) {
    //       window.location.href = "membership.php?status=success&reference=" + response.reference;
    //     },
    //     onClose: function() {
    //       console.log("Payment cancelled");
    //     }
    //   });
    //   handler.openIframe();
    // }

    // function initiateSeniorUpgrade(plan) {
    //   const amount = plan === 'monthly' ? 2500 : <?php echo $senior_yearly_price; ?>;
    //   const duration = plan === 'monthly' ? '1 month' : '1 year';
      
    //   var handler = PaystackPop.setup({
    //     key: "<?php echo PAYSTACK_PUBLIC_KEY; ?>",
    //     email: "<?php echo $user['email']; ?>",
    //     amount: amount * 100, // Paystack expects amount in kobo
    //     currency: "NGN",
    //     ref: "SENIOR-ADV-" + Date.now(),
    //     metadata: {
    //       payment_type: "senior_advertiser_upgrade",
    //       plan_duration: plan,
    //       user_id: <?php echo $user_id; ?>,
    //       custom_fields: [
    //         {
    //           display_name: "Customer Name",
    //           variable_name: "customer_name",
    //           value: "<?php echo $user['full_name']; ?>"
    //         }
    //       ]
    //     },
    //     callback: function(response) {
    //       window.location.href = "membership.php?status=success&reference=" + response.reference;
    //     },
    //     onClose: function() {
    //       console.log("Payment cancelled");
    //     }
    //   });
    //   handler.openIframe();
    // }

  </script>

  <script>
document.addEventListener("DOMContentLoaded", () => {
  const successToast = document.getElementById("toast-success");
  const errorToast = document.getElementById("toast-error");

  // Function to show and hide a toast
  function showToast(toast) {
    if (!toast) return;
    setTimeout(() => toast.classList.add("show"), 100); // slide in
    setTimeout(() => toast.classList.remove("show"), 4000); // hide after 4s
  }

  showToast(successToast);
  showToast(errorToast);
});
</script>
</body>
</html>
