<?php
require_once 'includes/session.php';
require_once 'config/database.php';

// Set user as inactive before destroying session
if (isset($_SESSION['user_id'])) {
    $user_id = $_SESSION['user_id'];
    try {
        $pdo = getDBConnection();
        $stmt = $pdo->prepare("UPDATE users SET is_active = 0 WHERE id = ?");
        $stmt->execute([$user_id]);
    } catch (Exception $e) {
        error_log("Error updating user active status: " . $e->getMessage());
    }
}

// Destroy session and redirect to login
destroyUserSession();
header('Location: login.php');
exit();
?>
