// Device fingerprinting library
// Generates a unique fingerprint for the device

;(() => {
  window.DeviceFingerprint = {
    // Generate device fingerprint
    generate: async function () {
      const components = await this.getComponents()
      const fingerprint = await this.hashComponents(components)
      return fingerprint
    },

    // Get all device components
    getComponents: async function () {
      const components = {
        userAgent: navigator.userAgent,
        language: navigator.language,
        colorDepth: screen.colorDepth,
        deviceMemory: navigator.deviceMemory || "unknown",
        hardwareConcurrency: navigator.hardwareConcurrency || "unknown",
        screenResolution: `${screen.width}x${screen.height}`,
        availableScreenResolution: `${screen.availWidth}x${screen.availHeight}`,
        timezoneOffset: new Date().getTimezoneOffset(),
        timezone: Intl.DateTimeFormat().resolvedOptions().timeZone,
        sessionStorage: !!window.sessionStorage,
        localStorage: !!window.localStorage,
        indexedDb: !!window.indexedDB,
        platform: navigator.platform,
        plugins: this.getPlugins(),
        canvas: await this.getCanvasFingerprint(),
        webgl: this.getWebGLFingerprint(),
        fonts: await this.getFonts(),
        audio: await this.getAudioFingerprint(),
      }
      return components
    },

    // Get installed plugins
    getPlugins: () => {
      const plugins = []
      for (let i = 0; i < navigator.plugins.length; i++) {
        plugins.push(navigator.plugins[i].name)
      }
      return plugins.join(",")
    },

    // Get canvas fingerprint
    getCanvasFingerprint: () =>
      new Promise((resolve) => {
        try {
          const canvas = document.createElement("canvas")
          const ctx = canvas.getContext("2d")
          const text = "FlowEarner Device Fingerprint 🔒"

          ctx.textBaseline = "top"
          ctx.font = '14px "Arial"'
          ctx.textBaseline = "alphabetic"
          ctx.fillStyle = "#f60"
          ctx.fillRect(125, 1, 62, 20)
          ctx.fillStyle = "#069"
          ctx.fillText(text, 2, 15)
          ctx.fillStyle = "rgba(102, 204, 0, 0.7)"
          ctx.fillText(text, 4, 17)

          resolve(canvas.toDataURL())
        } catch (e) {
          resolve("unsupported")
        }
      }),

    // Get WebGL fingerprint
    getWebGLFingerprint: () => {
      try {
        const canvas = document.createElement("canvas")
        const gl = canvas.getContext("webgl") || canvas.getContext("experimental-webgl")
        if (!gl) return "unsupported"

        const debugInfo = gl.getExtension("WEBGL_debug_renderer_info")
        return debugInfo
          ? gl.getParameter(debugInfo.UNMASKED_VENDOR_WEBGL) + "~" + gl.getParameter(debugInfo.UNMASKED_RENDERER_WEBGL)
          : "unavailable"
      } catch (e) {
        return "unsupported"
      }
    },

    // Get available fonts
    getFonts: () =>
      new Promise((resolve) => {
        const baseFonts = ["monospace", "sans-serif", "serif"]
        const testFonts = [
          "Arial",
          "Verdana",
          "Times New Roman",
          "Courier New",
          "Georgia",
          "Palatino",
          "Garamond",
          "Bookman",
          "Comic Sans MS",
          "Trebuchet MS",
          "Impact",
        ]

        const testString = "mmmmmmmmmmlli"
        const testSize = "72px"
        const canvas = document.createElement("canvas")
        const ctx = canvas.getContext("2d")

        const baseFontWidths = {}
        baseFonts.forEach((baseFont) => {
          ctx.font = testSize + " " + baseFont
          baseFontWidths[baseFont] = ctx.measureText(testString).width
        })

        const detectedFonts = []
        testFonts.forEach((font) => {
          let detected = false
          baseFonts.forEach((baseFont) => {
            ctx.font = testSize + " " + font + ", " + baseFont
            const width = ctx.measureText(testString).width
            if (width !== baseFontWidths[baseFont]) {
              detected = true
            }
          })
          if (detected) detectedFonts.push(font)
        })

        resolve(detectedFonts.join(","))
      }),

    // Get audio fingerprint
    getAudioFingerprint: () =>
      new Promise((resolve) => {
        try {
          const AudioContext = window.AudioContext || window.webkitAudioContext
          if (!AudioContext) {
            resolve("unsupported")
            return
          }

          const context = new AudioContext()
          const oscillator = context.createOscillator()
          const analyser = context.createAnalyser()
          const gainNode = context.createGain()
          const scriptProcessor = context.createScriptProcessor(4096, 1, 1)

          gainNode.gain.value = 0
          oscillator.type = "triangle"
          oscillator.connect(analyser)
          analyser.connect(scriptProcessor)
          scriptProcessor.connect(gainNode)
          gainNode.connect(context.destination)

          scriptProcessor.onaudioprocess = (event) => {
            const output = event.outputBuffer.getChannelData(0)
            const fingerprint = output.slice(0, 30).join("")
            oscillator.disconnect()
            scriptProcessor.disconnect()
            gainNode.disconnect()
            context.close()
            resolve(fingerprint)
          }

          oscillator.start(0)
        } catch (e) {
          resolve("unsupported")
        }
      }),

    // Hash components to create fingerprint
    hashComponents: async (components) => {
      const str = JSON.stringify(components)
      const encoder = new TextEncoder()
      const data = encoder.encode(str)
      const hashBuffer = await crypto.subtle.digest("SHA-256", data)
      const hashArray = Array.from(new Uint8Array(hashBuffer))
      const hashHex = hashArray.map((b) => b.toString(16).padStart(2, "0")).join("")
      return hashHex
    },

    // Get device info for display
    getDeviceInfo: () => {
      const parser = new UAParser()
      const result = parser.getResult()

      return {
        browser: `${result.browser.name || "Unknown"} ${result.browser.version || ""}`.trim(),
        os: `${result.os.name || "Unknown"} ${result.os.version || ""}`.trim(),
        device: result.device.type || "Desktop",
        screenResolution: `${screen.width}x${screen.height}`,
        timezone: Intl.DateTimeFormat().resolvedOptions().timeZone,
      }
    },
  }

  // Simple UA Parser (lightweight version)
  function UAParser() {
    this.getResult = function () {
      const ua = navigator.userAgent
      return {
        browser: this.getBrowser(ua),
        os: this.getOS(ua),
        device: this.getDevice(ua),
      }
    }

    this.getBrowser = (ua) => {
      if (ua.includes("Firefox/")) return { name: "Firefox", version: ua.match(/Firefox\/(\d+)/)?.[1] }
      if (ua.includes("Chrome/")) return { name: "Chrome", version: ua.match(/Chrome\/(\d+)/)?.[1] }
      if (ua.includes("Safari/") && !ua.includes("Chrome"))
        return { name: "Safari", version: ua.match(/Version\/(\d+)/)?.[1] }
      if (ua.includes("Edge/")) return { name: "Edge", version: ua.match(/Edge\/(\d+)/)?.[1] }
      return { name: "Unknown", version: "" }
    }

    this.getOS = (ua) => {
      if (ua.includes("Windows NT 10")) return { name: "Windows", version: "10" }
      if (ua.includes("Windows NT 6.3")) return { name: "Windows", version: "8.1" }
      if (ua.includes("Windows NT 6.2")) return { name: "Windows", version: "8" }
      if (ua.includes("Windows NT 6.1")) return { name: "Windows", version: "7" }
      if (ua.includes("Mac OS X"))
        return { name: "macOS", version: ua.match(/Mac OS X (\d+[._]\d+)/)?.[1].replace("_", ".") }
      if (ua.includes("Android")) return { name: "Android", version: ua.match(/Android (\d+)/)?.[1] }
      if (ua.includes("iPhone") || ua.includes("iPad")) return { name: "iOS", version: ua.match(/OS (\d+)/)?.[1] }
      if (ua.includes("Linux")) return { name: "Linux", version: "" }
      return { name: "Unknown", version: "" }
    }

    this.getDevice = (ua) => {
      if (ua.includes("Mobile") || ua.includes("Android")) return { type: "Mobile" }
      if (ua.includes("Tablet") || ua.includes("iPad")) return { type: "Tablet" }
      return { type: "Desktop" }
    }
  }
})()
