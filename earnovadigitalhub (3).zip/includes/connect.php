<?php
require_once 'config/database.php';
require_once 'includes/session.php';

// Require authentication
requireLogin();
checkSessionTimeout();

// Get current user
$user = getCurrentUser();
$user_id = $user['id'];

try {
    $pdo = getDBConnection();

    // Fetch user details + balances
    $stmt = $pdo->prepare("
        SELECT u.*, b.total_balance, b.task_earnings, b.referral_earnings
        FROM users u
        LEFT JOIN balances b ON u.id = b.user_id
        WHERE u.id = ?
    ");
    $stmt->execute([$user_id]);
    $user_data = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$user_data) {
        header('Location: login.php');
        exit;
    }

    // Fetch referral stats
    $stmt = $pdo->prepare("
        SELECT 
            COUNT(*) as total_referrals,
            SUM(CASE WHEN membership_type = 'premium' THEN 1 ELSE 0 END) as premium_referrals
        FROM users
        WHERE referred_by = ?
    ");
    $stmt->execute([$user_id]);
    $referral_stats = $stmt->fetch(PDO::FETCH_ASSOC);

    // Store important values in session
    $_SESSION['user_id']          = $user_data['id'];
    $_SESSION['username']         = $user_data['username'];
    $_SESSION['email']            = $user_data['email'];
    $_SESSION['full_name']        = $user_data['full_name'] ?? 'User';
    $_SESSION['phone']            = $user_data['phone'];
    $_SESSION['profile_picture']  = $user_data['profile_picture'] ?: 'front/assets/images/default-avatar.png';
    $_SESSION['membership_type']  = $user_data['membership_type'] ?? 'free';
    $_SESSION['membership_status']= ($_SESSION['membership_type'] === 'premium') ? 'Premium Member' : 'Free Member';

    $_SESSION['total_balance']    = $user_data['total_balance'] ?? 0;
    $_SESSION['task_earnings']    = $user_data['task_earnings'] ?? 0;
    $_SESSION['referral_earnings']= $user_data['referral_earnings'] ?? 0;

    $_SESSION['total_referrals']  = $referral_stats['total_referrals'] ?? 0;
    $_SESSION['premium_referrals']= $referral_stats['premium_referrals'] ?? 0;

} catch (PDOException $e) {
    error_log("Connect Error: " . $e->getMessage());
    die("Unable to load user data.");
}
