<?php
require_once __DIR__ . '/../config/config.php';

class Auth {
    private $pdo;
    
    public function __construct() {
        $this->pdo = getDBConnection();
    }
    
    // Register new user
    public function register($username, $email, $password, $fullName, $referralCode = null) {
        try {
            // Validate inputs
            $errors = [];
            
            if (strlen($username) < 3) {
                $errors[] = "Username must be at least 3 characters";
            }
            
            if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                $errors[] = "Invalid email format";
            }
            
            if (strlen($password) < PASSWORD_MIN_LENGTH) {
                $errors[] = "Password must be at least " . PASSWORD_MIN_LENGTH . " characters";
            }
            
            if (!empty($errors)) {
                return ['success' => false, 'message' => implode(', ', $errors)];
            }
            
            // Check if username or email already exists
            $stmt = $this->pdo->prepare("SELECT id FROM users WHERE username = ? OR email = ?");
            $stmt->execute([$username, $email]);
            if ($stmt->fetch()) {
                return ['success' => false, 'message' => 'Username or email already exists'];
            }
            
            // Validate referral code if provided
            $referrerId = null;
            if ($referralCode) {
                $stmt = $this->pdo->prepare("SELECT id FROM users WHERE referral_code = ?");
                $stmt->execute([$referralCode]);
                $referrer = $stmt->fetch();
                if ($referrer) {
                    $referrerId = $referrer['id'];
                }
            }
            
            // Generate unique referral code
            do {
                $newReferralCode = generateReferralCode();
                $stmt = $this->pdo->prepare("SELECT id FROM users WHERE referral_code = ?");
                $stmt->execute([$newReferralCode]);
            } while ($stmt->fetch());
            
            // Hash password
            $passwordHash = password_hash($password, PASSWORD_ARGON2ID);
            
            // Begin transaction
            $this->pdo->beginTransaction();
            
            // Insert user
            $stmt = $this->pdo->prepare("
                INSERT INTO users (username, email, password_hash, full_name, referral_code, referred_by)
                VALUES (?, ?, ?, ?, ?, ?)
            ");
            $stmt->execute([$username, $email, $passwordHash, $fullName, $newReferralCode, $referrerId]);
            $userId = $this->pdo->lastInsertId();
            
            // Create balance record with welcome bonus
            $stmt = $this->pdo->prepare("
                INSERT INTO balances (user_id, task_earnings, total_balance)
                VALUES (?, ?, ?)
            ");
            $stmt->execute([$userId, WELCOME_BONUS, WELCOME_BONUS]);
            
            // Record welcome bonus transaction
            $stmt = $this->pdo->prepare("
                INSERT INTO transactions (user_id, transaction_type, amount, balance_type, description)
                VALUES (?, 'task_reward', ?, 'task', 'Welcome bonus')
            ");
            $stmt->execute([$userId, WELCOME_BONUS]);
            
            $this->pdo->commit();
            
            return [
                'success' => true,
                'message' => 'Registration successful! Welcome bonus of ₦' . number_format(WELCOME_BONUS, 2) . ' added to your account.',
                'user_id' => $userId
            ];
            
        } catch (Exception $e) {
            $this->pdo->rollBack();
            error_log("Registration Error: " . $e->getMessage());
            return ['success' => false, 'message' => 'Registration failed. Please try again.'];
        }
    }
    
    // Login user
    public function login($email, $password) {
        try {
            $stmt = $this->pdo->prepare("
                SELECT id, username, email, password_hash, full_name, membership_type, is_active
                FROM users
                WHERE email = ?
            ");
            $stmt->execute([$email]);
            $user = $stmt->fetch();
            
            if (!$user) {
                return ['success' => false, 'message' => 'Invalid email or password'];
            }
            
            if (!$user['is_active']) {
                return ['success' => false, 'message' => 'Account is deactivated. Please contact support.'];
            }
            
            if (!password_verify($password, $user['password_hash'])) {
                return ['success' => false, 'message' => 'Invalid email or password'];
            }
            
            // Set session
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['username'] = $user['username'];
            $_SESSION['email'] = $user['email'];
            $_SESSION['full_name'] = $user['full_name'];
            $_SESSION['membership_type'] = $user['membership_type'];
            $_SESSION['last_activity'] = time();
            
            return [
                'success' => true,
                'message' => 'Login successful',
                'user' => [
                    'id' => $user['id'],
                    'username' => $user['username'],
                    'email' => $user['email'],
                    'membership_type' => $user['membership_type']
                ]
            ];
            
        } catch (Exception $e) {
            error_log("Login Error: " . $e->getMessage());
            return ['success' => false, 'message' => 'Login failed. Please try again.'];
        }
    }
    
    // Logout user
    public function logout() {
        session_unset();
        session_destroy();
        return ['success' => true, 'message' => 'Logged out successfully'];
    }
    
    // Check session timeout
    public function checkSessionTimeout() {
        if (isset($_SESSION['last_activity']) && (time() - $_SESSION['last_activity'] > SESSION_TIMEOUT)) {
            $this->logout();
            return false;
        }
        $_SESSION['last_activity'] = time();
        return true;
    }
}
?>
