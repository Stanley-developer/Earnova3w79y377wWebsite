<?php
/**
 * Centralized Email Helper using PHPMailer
 * This file provides a reusable function for sending emails across the entire application
 */

require_once __DIR__ . '/../PHPMailer/src/PHPMailer.php';
require_once __DIR__ . '/../PHPMailer/src/SMTP.php';
require_once __DIR__ . '/../PHPMailer/src/Exception.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

/**
 * Get standardized email header with logo and branding (Compact style)
 * 
 * @return string HTML header with Earnova branding
 */
function getEmailHeader() {
    return "
        <div style='background: rgba(3, 9, 34, 0.85); padding: 16px 20px; text-align: center; border-bottom: 1px solid rgba(255, 255, 255, 0.1);'>
            <div style='display: inline-flex; align-items: center; justify-content: center; width: 60px; height: 60px; border-radius: 50%;'>
                <img src='https://earnova-digital-hub.com/logo.png' alt='Earnova' style='width: 65px; height: 50px;' />
            </div>
            <h3 style='margin: 8px 0 0 0; font-family: -apple-system, BlinkMacSystemFont, \"Segoe UI\", \"Helvetica Neue\", sans-serif; font-size: 16px; font-weight: 600; color: #fff; letter-spacing: 1px;'>EARNOVA DIGITAL HUB</h3>
        </div>
    ";
}

/**
 * Send email using PHPMailer with configured SMTP settings
 * 
 * @param string $to_email Recipient email address
 * @param string $to_name Recipient name
 * @param string $subject Email subject
 * @param string $html_body HTML email body
 * @param string $alt_body Plain text alternative body (optional)
 * @return array ['success' => bool, 'message' => string]
 */
function sendEmail($to_email, $to_name, $subject, $html_body, $alt_body = '') {
    $mail = new PHPMailer(true);
    
    try {
        error_log("[EMAIL] Initializing PHPMailer for: $to_email");
        
        // SMTP configuration
        $mail->SMTPDebug = 0;
        $mail->isSMTP();
        $mail->Host = 'mail.earnova.org';
        $mail->SMTPAuth = true;
        $mail->Username = 'info@earnova.org';
        $mail->Password = '1TQ]KZOIdho?(]Y?';
        $mail->SMTPSecure = 'ssl';
        $mail->Port = 465;
        
        error_log("[EMAIL] SMTP configured - Host: mail.earnova.org, Port: 465");
        
        // Sender and recipient
        $mail->setFrom('info@earnova.org', 'Earnova Digital Hub');
        $mail->addAddress($to_email, $to_name);
        
        error_log("[EMAIL] From: info@earnova.org, To: $to_email");
        
        // Email content
        $mail->isHTML(true);
        $mail->Subject = $subject;
        $mail->Body = $html_body;
        
        if (!empty($alt_body)) {
            $mail->AltBody = $alt_body;
        }
        
        error_log("[EMAIL] Subject: $subject");
        error_log("[EMAIL] Attempting to send email...");
        
        $mail->send();
        
        error_log("[EMAIL] SUCCESS - Email sent to $to_email");
        
        return [
            'success' => true,
            'message' => 'Email sent successfully'
        ];
        
    } catch (Exception $e) {
        error_log("[EMAIL] FAILED - PHPMailer Exception: " . $e->getMessage());
        error_log("[EMAIL] PHPMailer ErrorInfo: " . $mail->ErrorInfo);
        error_log("[EMAIL] SMTP Error: " . $mail->ErrorInfo);
        
        return [
            'success' => false,
            'message' => 'Failed to send email: ' . $mail->ErrorInfo
        ];
    }
}

/**
 * Send device verification email
 */
function sendDeviceVerificationEmail($user_email, $user_name, $verification_code, $device_info, $ip_address, $location) {
    $subject = 'Earnova Digital Hub - Device Verification Code';
    $email_header = getEmailHeader();
    
    $html_body = "
        <html>
        <head>
            <style>
                * { margin: 0; padding: 0; box-sizing: border-box; }
                body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Helvetica Neue', sans-serif; background: #f5f5f5; color: #333; }
                .wrapper { width: 100%; background: #f5f5f5; }
                .container { max-width: 500px; margin: 0 auto; background: white; }
                .content { padding: 20px; }
                .header { margin-bottom: 16px; }
                .greeting { font-size: 14px; font-weight: 500; color: #333; margin-bottom: 8px; }
                .message { font-size: 13px; color: #666; line-height: 1.5; margin-bottom: 12px; }
                .code-box { background: #f9f9f9; border-left: 3px solid #2c5bf5; padding: 12px 14px; margin: 12px 0; }
                .code-label { font-size: 11px; color: #999; text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 4px; }
                .code-display { font-size: 28px; font-weight: 700; color: #2c5bf5; letter-spacing: 4px; font-family: 'Courier New', monospace; }
                .info-item { font-size: 12px; color: #666; padding: 6px 0; border-bottom: 1px solid #f0f0f0; }
                .info-item strong { color: #333; }
                .footer-text { font-size: 12px; color: #999; margin-top: 12px; line-height: 1.4; }
                .expiry { background: #fff3cd; border-left: 3px solid #ffc107; padding: 8px 12px; margin: 12px 0; font-size: 12px; color: #856404; }
            </style>
        </head>
        <body>
            <div class='wrapper'>
                <div class='container'>
                    $email_header
                    
                    <div class='content'>
                        <div class='header'>
                            <div class='greeting'>Hello " . htmlspecialchars(explode(' ', $user_name)[0]) . ",</div>
                            <div class='message'>New device login detected. Use the code below to verify:</div>
                        </div>
                        
                        <div class='code-box'>
                            <div class='code-label'>Verification Code</div>
                            <div class='code-display'>$verification_code</div>
                        </div>
                        
                        <div style='background: #f9f9f9; padding: 10px 12px; border-radius: 4px; margin: 12px 0; font-size: 12px;'>
                            <div class='info-item'><strong>Browser:</strong> " . htmlspecialchars($device_info['browser'] ?? 'Unknown') . "</div>
                            <div class='info-item'><strong>OS:</strong> " . htmlspecialchars($device_info['os'] ?? 'Unknown') . "</div>
                            <div class='info-item'><strong>IP:</strong> " . htmlspecialchars($ip_address) . "</div>
                            <div class='info-item'><strong>Location:</strong> " . htmlspecialchars($location) . "</div>
                            <div class='info-item' style='border: none;'><strong>Time:</strong> " . date('M d, Y • g:i a') . "</div>
                        </div>
                        
                        <div class='expiry'>Code expires in 15 minutes</div>
                        
                        <div class='footer-text'>
                            If you didn't attempt this login, secure your account immediately by changing your password.
                        </div>
                        <div class='footer-text' style='margin-top: 16px; padding-top: 12px; border-top: 1px solid #f0f0f0; color: #ccc; font-size: 11px;'>
                            Earnova Digital Hub • Automated Message
                        </div>
                    </div>
                </div>
            </div>
        </body>
        </html>
    ";
    
    $alt_body = "Device Verification Code for Earnova Digital Hub\n\n" .
                "Verification Code: $verification_code\n\n" .
                "Device: " . ($device_info['browser'] ?? 'Unknown') . " on " . ($device_info['os'] ?? 'Unknown') . "\n" .
                "IP: $ip_address | Location: $location\n" .
                "Time: " . date('M d, Y • g:i a') . "\n\n" .
                "Code expires in 15 minutes.\n\n" .
                "If you didn't attempt this login, change your password immediately.";
    
    return sendEmail($user_email, $user_name, $subject, $html_body, $alt_body);
}

/**
 * Send password reset email
 */
function sendPasswordResetEmail($user_email, $user_name, $reset_code) {
    $subject = 'Earnova Digital Hub - Password Reset Code';
    $email_header = getEmailHeader();
    
    $html_body = "
        <html>
        <head>
            <style>
                * { margin: 0; padding: 0; box-sizing: border-box; }
                body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Helvetica Neue', sans-serif; background: #f5f5f5; color: #333; }
                .wrapper { width: 100%; background: #f5f5f5; }
                .container { max-width: 500px; margin: 0 auto; background: white; }
                .content { padding: 20px; }
                .header { margin-bottom: 16px; }
                .greeting { font-size: 14px; font-weight: 500; color: #333; margin-bottom: 8px; }
                .message { font-size: 13px; color: #666; line-height: 1.5; margin-bottom: 12px; }
                .code-box { background: #f9f9f9; border-left: 3px solid #2c5bf5; padding: 12px 14px; margin: 12px 0; }
                .code-label { font-size: 11px; color: #999; text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 4px; }
                .code-display { font-size: 28px; font-weight: 700; color: #2c5bf5; letter-spacing: 4px; font-family: 'Courier New', monospace; }
                .expiry { background: #fff3cd; border-left: 3px solid #ffc107; padding: 8px 12px; margin: 12px 0; font-size: 12px; color: #856404; }
                .footer-text { font-size: 12px; color: #999; margin-top: 12px; line-height: 1.4; }
            </style>
        </head>
        <body>
            <div class='wrapper'>
                <div class='container'>
                    $email_header
                    
                    <div class='content'>
                        <div class='header'>
                            <div class='greeting'>Hello " . htmlspecialchars(explode(' ', $user_name)[0]) . ",</div>
                            <div class='message'>Password reset requested. Use the code below:</div>
                        </div>
                        
                        <div class='code-box'>
                            <div class='code-label'>Reset Code</div>
                            <div class='code-display'>$reset_code</div>
                        </div>
                        
                        <div class='expiry'>Code expires in 30 minutes</div>
                        
                        <div class='footer-text'>
                            If you didn't request a password reset, ignore this email or contact support.
                        </div>
                        <div class='footer-text' style='margin-top: 16px; padding-top: 12px; border-top: 1px solid #f0f0f0; color: #ccc; font-size: 11px;'>
                            Earnova Digital Hub • Automated Message
                        </div>
                    </div>
                </div>
            </div>
        </body>
        </html>
    ";
    
    $alt_body = "Password Reset Code\n\n" .
                "Reset Code: $reset_code\n\n" .
                "Code expires in 30 minutes.\n\n" .
                "If you didn't request this, ignore this email.";
    
    return sendEmail($user_email, $user_name, $subject, $html_body, $alt_body);
}

/**
 * Send Welcome Email to new users (Compact style)
 */
function sendWelcomeEmail($user_email, $user_name) {
    $subject = 'Welcome to Earnova Digital Hub!';
    $email_header = getEmailHeader();
    
    $html_body = "
        <html>
        <head>
            <style>
                * { margin: 0; padding: 0; box-sizing: border-box; }
                body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Helvetica Neue', sans-serif; background: #f5f5f5; color: #333; }
                .wrapper { width: 100%; background: #f5f5f5; }
                .container { max-width: 500px; margin: 0 auto; background: white; }
                .content { padding: 20px; }
                .greeting { font-size: 14px; font-weight: 500; color: #333; margin-bottom: 12px; }
                .intro { font-size: 13px; color: #666; line-height: 1.5; margin-bottom: 12px; }
                .feature { background: #f9f9f9; padding: 10px 12px; margin: 8px 0; border-left: 3px solid #4de1c1; font-size: 12px; }
                .feature-title { font-weight: 600; color: #2c5bf5; margin-bottom: 3px; }
                .feature-text { color: #666; font-size: 12px; }
                .tips { background: #f0f8ff; border-left: 3px solid #2c5bf5; padding: 10px 12px; margin: 12px 0; }
                .tips-title { font-weight: 600; color: #2c5bf5; font-size: 12px; margin-bottom: 6px; }
                .tips ul { margin: 0; padding-left: 16px; }
                .tips li { font-size: 12px; color: #666; margin: 3px 0; }
                .cta-button { display: inline-block; background: linear-gradient(135deg, #2c5bf5, #4de1c1); color: white !important; text-decoration: none; padding: 10px 20px; border-radius: 6px; font-weight: 600; font-size: 13px; margin: 12px 0; }
                .footer-text { font-size: 11px; color: #999; margin-top: 12px; line-height: 1.4; }
            </style>
        </head>
        <body>
            <div class='wrapper'>
                <div class='container'>
                    $email_header
                    
                    <div class='content'>
                        <div class='greeting'>Welcome " . htmlspecialchars(explode(' ', $user_name)[0]) . "! </div>
                        <div class='intro'>You're now part of Earnova Digital Hub. Start earning by completing tasks, watching videos, and more.</div>
                        
                      <div class='feature'>
                        <div class='feature-title'>Explore Real Opportunities</div>
                        <div class='feature-text'>Discover activities and unlock meaningful benefits across the platform</div>
                    </div>
                    
                    <div class='feature'>
                        <div class='feature-title'>Invitation Program</div>
                        <div class='feature-text'>Share your invitation link and grow your community effortlessly</div>
                    </div>
                    
                    <div class='feature'>
                        <div class='feature-title'>Quick Payouts</div>
                        <div class='feature-text'>Enjoy fast and secure withdrawals anytime you need them</div>
                    </div>
                    
                    <div class='tips'>
                        <div class='tips-title'>Quick Start Tips:</div>
                        <ul>
                            <li>Complete your profile to unlock full platform features</li>
                            <li>Check your dashboard daily for new activities</li>
                            <li>Share your invitation link with friends</li>
                        </ul>
                    </div>

                        
                        <div style='text-align: center;'>
                            <a href='https://earnova-digital-hub.com/dashboard.php' class='cta-button'>Go to Dashboard</a>
                        </div>
                        
                        <div class='footer-text'>
                            Questions? Our support team is here to help. Reply to this email or visit our support page.
                        </div>
                        <div class='footer-text' style='margin-top: 16px; padding-top: 12px; border-top: 1px solid #f0f0f0; color: #ccc; font-size: 11px;'>
                            Earnova Digital Hub • " . date('Y') . "
                        </div>
                    </div>
                </div>
            </div>
        </body>
        </html>
    ";
    
    $alt_body = "Welcome to Earnova Digital Hub!\n\n" .
                "Start earning by completing tasks, watching videos, and referring friends.\n\n" .
                "Quick Start:\n" .
                "- Complete your profile\n" .
                "- Check the task board daily\n" .
                "- Share your referral code\n\n" .
                "Start earning: https://earnova.org/dashboard.php\n\n" .
                "Earnova Digital Hub";
    
    return sendEmail($user_email, $user_name, $subject, $html_body, $alt_body);
}

/**
 * Send Newsletter Email (Compact style)
 */
function sendNewsletterEmail($to_email, $to_name, $subject, $content_html, $content_text = '') {
    $email_header = getEmailHeader();
    
    $html_body = "
        <html>
        <head>
            <style>
                * { margin: 0; padding: 0; box-sizing: border-box; }
                body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Helvetica Neue', sans-serif; background: #f5f5f5; color: #333; }
                .wrapper { width: 100%; background: #f5f5f5; }
                .container { max-width: 500px; margin: 0 auto; background: white; }
                .content { padding: 20px; }
                .greeting { font-size: 14px; font-weight: 500; color: #333; margin-bottom: 12px; }
                .message { font-size: 13px; color: #666; line-height: 1.6; }
                .footer-text { font-size: 11px; color: #999; margin-top: 16px; padding-top: 12px; border-top: 1px solid #f0f0f0; }
            </style>
        </head>
        <body>
            <div class='wrapper'>
                <div class='container'>
                    $email_header
                    
                    <div class='content'>
                        <div class='greeting'>Hello " . htmlspecialchars(explode(' ', $to_name)[0]) . ",</div>
                        <div class='message'>
                            $content_html
                        </div>
                        <div class='footer-text'>
                            You're receiving this because you subscribed to Earnova Digital Hub updates.
                        </div>
                    </div>
                </div>
            </div>
        </body>
        </html>
    ";

    if (empty($content_text)) {
        $content_text = strip_tags($content_html);
    }

    return sendEmail($to_email, $to_name, $subject, $html_body, $content_text);
}

?>
