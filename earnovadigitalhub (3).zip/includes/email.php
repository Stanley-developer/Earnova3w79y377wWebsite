<?php
// Email helper functions for FlowEarner

function sendEmail($to, $subject, $body, $from_name = 'FlowEarner') {
    $headers = "MIME-Version: 1.0" . "\r\n";
    $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
    $headers .= "From: $from_name <noreply@flowearner.com>" . "\r\n";
    
    return mail($to, $subject, $body, $headers);
}

function getEmailTemplate($title, $content, $cta_text = '', $cta_link = '') {
    $cta_button = '';
    if ($cta_text && $cta_link) {
        $cta_button = '<div style="text-align: center; margin: 30px 0;">
            <a href="' . $cta_link . '" style="display: inline-block; padding: 15px 40px; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; text-decoration: none; border-radius: 10px; font-weight: 600;">' . $cta_text . '</a>
        </div>';
    }
    
    return '
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
    </head>
    <body style="margin: 0; padding: 0; font-family: Arial, sans-serif; background-color: #f5f9ff;">
        <table width="100%" cellpadding="0" cellspacing="0" style="background-color: #f5f9ff; padding: 20px;">
            <tr>
                <td align="center">
                    <table width="600" cellpadding="0" cellspacing="0" style="background-color: white; border-radius: 20px; overflow: hidden; box-shadow: 0 8px 32px rgba(0,0,0,0.1);">
                        <tr>
                            <td style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); padding: 30px; text-align: center;">
                                <h1 style="color: white; margin: 0; font-size: 28px;">⚡ FlowEarner</h1>
                            </td>
                        </tr>
                        <tr>
                            <td style="padding: 40px 30px;">
                                <h2 style="color: #2d3748; margin-top: 0;">' . $title . '</h2>
                                <div style="color: #4a5568; line-height: 1.6; font-size: 16px;">
                                    ' . $content . '
                                </div>
                                ' . $cta_button . '
                            </td>
                        </tr>
                        <tr>
                            <td style="background-color: #f7fafc; padding: 20px; text-align: center; color: #718096; font-size: 14px;">
                                <p style="margin: 0;">© ' . date('Y') . ' FlowEarner. All rights reserved.</p>
                                <p style="margin: 10px 0 0;">Earn money online with FlowEarner</p>
                            </td>
                        </tr>
                    </table>
                </td>
            </tr>
        </table>
    </body>
    </html>
    ';
}

function sendJobPostedEmail($user_email, $job_title) {
    $subject = '[FlowEarner Job Update] Your Job Has Been Posted';
    $content = '<p>Your job posting "<strong>' . htmlspecialchars($job_title) . '</strong>" has been successfully submitted and is pending admin approval.</p>
                <p>You will receive another email once your job is approved and visible to members.</p>
                <p>Thank you for using FlowEarner!</p>';
    
    $body = getEmailTemplate('Job Posted Successfully', $content);
    return sendEmail($user_email, $subject, $body);
}

function sendJobApprovedEmail($user_email, $job_title, $job_id) {
    $subject = '[FlowEarner Job Update] Your Job Has Been Approved';
    $content = '<p>Great news! Your job posting "<strong>' . htmlspecialchars($job_title) . '</strong>" has been approved by our admin team.</p>
                <p>Your job is now live and visible to all qualified members. You can start receiving bids from interested candidates.</p>';
    
    $cta_link = 'https://flowearner.com/view-bids.php?job_id=' . $job_id;
    $body = getEmailTemplate('Job Approved!', $content, 'View Bids', $cta_link);
    return sendEmail($user_email, $subject, $body);
}

function sendNewJobNotification($user_email, $job_title, $job_category, $payment_amount) {
    $subject = '[FlowEarner Job Update] New Job Available in Your Category';
    $content = '<p>A new job matching your career category has been posted!</p>
                <p><strong>Job Title:</strong> ' . htmlspecialchars($job_title) . '</p>
                <p><strong>Category:</strong> ' . htmlspecialchars($job_category) . '</p>
                <p><strong>Payment:</strong> ₦' . number_format($payment_amount, 2) . '</p>
                <p>Login to FlowEarner to view details and place your bid.</p>';
    
    $body = getEmailTemplate('New Job Available', $content, 'View Job', 'https://flowearner.com/find-jobs.php');
    return sendEmail($user_email, $subject, $body);
}

function sendBidAcceptedEmail($user_email, $job_title, $advertiser_name) {
    $subject = '[FlowEarner Job Update] Your Bid Has Been Accepted';
    $content = '<p>Congratulations! Your bid has been accepted by <strong>' . htmlspecialchars($advertiser_name) . '</strong>.</p>
                <p><strong>Job:</strong> ' . htmlspecialchars($job_title) . '</p>
                <p>The advertiser will contact you soon with further details. Please check your dashboard for contact information.</p>';
    
    $body = getEmailTemplate('Bid Accepted!', $content, 'View Dashboard', 'https://flowearner.com/dashboard.php');
    return sendEmail($user_email, $subject, $body);
}

function sendJobCompletedEmail($user_email, $job_title, $payment_amount) {
    $subject = '[FlowEarner Job Update] Job Marked as Complete';
    $content = '<p>The job "<strong>' . htmlspecialchars($job_title) . '</strong>" has been marked as complete by the advertiser.</p>
                <p><strong>Payment Amount:</strong> ₦' . number_format($payment_amount, 2) . '</p>
                <p>Thank you for your excellent work! Keep earning with FlowEarner.</p>';
    
    $body = getEmailTemplate('Job Completed', $content);
    return sendEmail($user_email, $subject, $body);
}
?>
