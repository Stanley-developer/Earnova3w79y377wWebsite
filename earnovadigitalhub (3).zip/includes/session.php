<?php
// Start secure session
if (session_status() === PHP_SESSION_NONE) {
    ini_set('session.cookie_httponly', 1);
    ini_set('session.use_only_cookies', 1);
    ini_set('session.cookie_secure', 0); // change to 1 on HTTPS
    session_start();
}

// Set application timezone to Nigeria (Lagos)
date_default_timezone_set('Africa/Lagos');

// Restore user from remember-me token if session expired
restoreUserFromToken();

/* ---------------------------------------
   CHECK IF USER IS LOGGED IN
---------------------------------------- */
function isLoggedIn() {
    return isset($_SESSION['user_id']) && !empty($_SESSION['user_id']);
}

/* ---------------------------------------
   RESTORE USER FROM REMEMBER-ME TOKEN
---------------------------------------- */
function restoreUserFromToken() {
    // Only restore if not already logged in
    if (isLoggedIn()) {
        return;
    }

    // Check for remember-me token
    if (!isset($_COOKIE['remember_me_token'])) {
        return;
    }

    try {
        require_once __DIR__ . '/../config/database.php';
        $pdo = getDBConnection();
        
        $token = $_COOKIE['remember_me_token'];
        
        // Get user from remember-me token
        $stmt = $pdo->prepare("SELECT * FROM users WHERE remember_me_token = ? AND remember_me_expires > NOW()");
        $stmt->execute([$token]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($user) {
            // User token is valid, restore session and mark active
            setUserSession($user['id'], $user);
            regenerateSession();
        } else {
            // Token expired or invalid - try to find which user had this token so we can mark them inactive and clear the token
            try {
                $stmt2 = $pdo->prepare("SELECT id FROM users WHERE remember_me_token = ?");
                $stmt2->execute([$token]);
                $tokenOwner = $stmt2->fetch(PDO::FETCH_ASSOC);
                if ($tokenOwner && isset($tokenOwner['id'])) {
                    $stmt3 = $pdo->prepare("UPDATE users SET is_active = 0, remember_me_token = NULL, remember_me_expires = NULL WHERE id = ?");
                    $stmt3->execute([$tokenOwner['id']]);
                }
            } catch (Exception $e) {
                error_log("Error cleaning expired remember-me token: " . $e->getMessage());
            }

            // Delete client cookie regardless
            setcookie('remember_me_token', '', time() - 3600, '/');
        }
    } catch (Exception $e) {
        error_log("Error restoring user from token: " . $e->getMessage());
    }
}

/* ---------------------------------------
   LOGOUT USER
---------------------------------------- */
function destroyUserSession() {
    // Set user as inactive and clear remember-me token before destroying session
    if (isset($_SESSION['user_id'])) {
        try {
            require_once __DIR__ . '/../config/database.php';
            $pdo = getDBConnection();
            $stmt = $pdo->prepare("UPDATE users SET is_active = 0, remember_me_token = NULL, remember_me_expires = NULL WHERE id = ?");
            $stmt->execute([$_SESSION['user_id']]);
        } catch (Exception $e) {
            error_log("Error updating user active status on logout: " . $e->getMessage());
        }
    }

    // Clear remember-me cookie
    setcookie('remember_me_token', '', time() - 3600, '/');

    $_SESSION = [];

    if (isset($_COOKIE[session_name()])) {
        setcookie(session_name(), '', time() - 3600, '/');
    }

    session_destroy();
}

/* ---------------------------------------
   REQUIRE LOGIN FOR PROTECTED PAGES
---------------------------------------- */
function requireLogin() {
    if (!isLoggedIn()) {
        header("Location: login.php");
        exit();
    }

    // Check banned status inside this function
    $user = getCurrentUser();
    
    if ($user && isset($user['status']) && strtolower($user['status']) === 'banned') {
        destroyUserSession();
        header("Location: login.php?banned=1");
        exit();
    }
}

/* ---------------------------------------
   GET CURRENT USER FROM DATABASE
---------------------------------------- */
function getCurrentUser() {
    if (!isLoggedIn()) {
        return null;
    }

    require_once __DIR__ . '/../config/database.php';
    $pdo = getDBConnection();

    $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    return $stmt->fetch(PDO::FETCH_ASSOC);
}

/* ---------------------------------------
   SET USER SESSION DATA + UPDATE LAST ACTIVITY
---------------------------------------- */
function setUserSession($userId, $userData = [], $rememberMe = false) {
    $_SESSION['user_id'] = $userId;
    $_SESSION['username'] = $userData['username'] ?? '';
    $_SESSION['email'] = $userData['email'] ?? '';
    $_SESSION['login_time'] = time();
    $_SESSION['last_activity'] = time(); // Track last user activity

    // If remember me is enabled, create a persistent token
    if ($rememberMe) {
        createRememberMeToken($userId);
    }

    // Ensure database marks this user as active and updates last_activity
    try {
        updateUserActivity($userId);
    } catch (Exception $e) {
        // updateUserActivity already logs errors; swallow here to avoid breaking login flow
    }
}

/* ---------------------------------------
   CREATE REMEMBER-ME TOKEN (30 MINUTES)
---------------------------------------- */
function createRememberMeToken($userId) {
    try {
        require_once __DIR__ . '/../config/database.php';
        $pdo = getDBConnection();
        
        // Generate secure token
        $token = bin2hex(random_bytes(32));
        
        // Token expires in 30 minutes
        $expiryDate = date('Y-m-d H:i:s', strtotime('+30 minutes'));
        
        // Store token in database
        $stmt = $pdo->prepare("UPDATE users SET remember_me_token = ?, remember_me_expires = ? WHERE id = ?");
        $stmt->execute([$token, $expiryDate, $userId]);
        
        // Set cookie (expires in 30 minutes)
        setcookie('remember_me_token', $token, time() + (30 * 60), '/', '', false, true);
    } catch (Exception $e) {
        error_log("Error creating remember-me token: " . $e->getMessage());
    }
}

/* ---------------------------------------
   TRACK USER ACTIVITY (UPDATE LAST_ACTIVITY)
---------------------------------------- */
function updateUserActivity($userId) {
    try {
        require_once __DIR__ . '/../config/database.php';
        $pdo = getDBConnection();
        
        $stmt = $pdo->prepare("UPDATE users SET last_activity = NOW(), is_active = 1 WHERE id = ?");
        $stmt->execute([$userId]);
        
        // Also update session
        if (isset($_SESSION['user_id']) && $_SESSION['user_id'] == $userId) {
            $_SESSION['last_activity'] = time();
        }
    } catch (Exception $e) {
        error_log("Error updating user activity: " . $e->getMessage());
    }
}

/* ---------------------------------------
   REGENERATE SESSION ID
---------------------------------------- */
function regenerateSession() {
    session_regenerate_id(true);
}

/* ---------------------------------------
   SESSION TIMEOUT - 30 DAYS
---------------------------------------- */
function checkSessionTimeout() {
    // Session timeout set to 30 minutes (1800 seconds)
    $timeout = 30 * 60; // 30 minutes in seconds

    if (isset($_SESSION['login_time']) && (time() - $_SESSION['login_time']) > $timeout) {
        destroyUserSession();
        header("Location: login.php?timeout=1");
        exit();
    }

    // refresh last activity time
    $_SESSION['login_time'] = time();
}

/* ---------------------------------------
   AUTO CHECK BAN + TIMEOUT ON EVERY PAGE + UPDATE ACTIVITY
---------------------------------------- */
if (isLoggedIn()) {
    // Update user activity on every page load/action
    updateUserActivity($_SESSION['user_id']);
    
    // Timeout check
    checkSessionTimeout();

    // Ban check
    $user = getCurrentUser();

    if ($user && isset($user['status']) && strtolower($user['status']) === 'banned') {
        destroyUserSession();
        header("Location: login.php?banned=1");
        exit();
    }
}
?>
