<?php
// Theme Handler - Manages dark/light mode across all pages
function getUserTheme($user_id) {
    try {
        $pdo = getDBConnection();
        $stmt = $pdo->prepare("SELECT theme_preference FROM users WHERE id = ?");
        $stmt->execute([$user_id]);
        $result = $stmt->fetch();
        return $result['theme_preference'] ?? 'dark';
    } catch (PDOException $e) {
        error_log("Theme fetch error: " . $e->getMessage());
        return 'dark';
    }
}

function getThemeStyles($theme = 'dark') {
    if ($theme === 'light') {
        return "
        <style>
            :root {
                --page-bg-primary: #ffffff;
                --page-bg-secondary: #f8f9fa;
                --page-bg-tertiary: #e9ecef;
                --page-text-primary: #1a1a2e;
                --page-text-secondary: #4a5568;
                --page-text-muted: #718096;
                --panel-glass: rgba(255, 255, 255, 0.95);
                --panel-border: rgba(44, 92, 245, 0.2);
                --shadow-heavy: 0 20px 60px rgba(0, 0, 0, 0.1);
                --page-blue-900: #1a1a2e;
                --page-blue-700: #2d3748;
                --page-blue-500: #4a5568;
                --page-blue-300: #2c5bf5;
                --page-mint: #4de1c1;
                --page-white: #1a1a2e;
            }
            
            body {
                background: linear-gradient(180deg, #ffffff, #f8f9fa) !important;
                color: #1a1a2e !important;
            }
            
            aside {
                background: rgba(255, 255, 255, 0.98) !important;
                border-right: 1px solid rgba(44, 92, 245, 0.15) !important;
            }
            
            aside::before {
                background: radial-gradient(circle at 20% 30%, rgba(44, 92, 245, 0.08), transparent 50%),
                            radial-gradient(circle at 80% 70%, rgba(77, 225, 193, 0.06), transparent 45%) !important;
            }
            
            .aside-welcome {
                background: rgba(44, 92, 245, 0.08) !important;
                border: 1px solid rgba(44, 92, 245, 0.2) !important;
            }
            
            .balance-card {
                background: linear-gradient(135deg, rgba(44, 92, 245, 0.12), rgba(255, 255, 255, 0.95)) !important;
                border: 1px solid rgba(44, 92, 245, 0.25) !important;
                color: #1a1a2e !important;
            }
            
            .balance-label {
                color: rgba(74, 85, 104, 0.8) !important;
            }
            
            .balance-meta {
                color: rgba(74, 85, 104, 0.7) !important;
            }
            
            .quick-grid-wrapper {
                background: rgba(44, 92, 245, 0.08) !important;
                border: 1px solid rgba(44, 92, 245, 0.2) !important;
            }
            
            .quick-card {
                background: rgba(255, 255, 255, 0.9) !important;
                border: 1px solid rgba(44, 92, 245, 0.15) !important;
            }
            
            .quick-label {
                color: #1a1a2e !important;
            }
            
            .ticker {
                background: rgba(255, 255, 255, 0.95) !important;
                border: 1px solid rgba(44, 92, 245, 0.2) !important;
            }
            
            .ticker-track {
                color: rgba(74, 85, 104, 0.9) !important;
            }
            
            .section-white {
                background: rgba(255, 255, 255, 0.98) !important;
                border: 1px solid rgba(44, 92, 245, 0.15) !important;
            }
            
            .mobile-fintech-footer {
                background: rgba(255, 255, 255, 0.98) !important;
                border: 1px solid rgba(44, 92, 245, 0.25) !important;
            }
            
            .mobile-fintech-footer a {
                color: rgba(74, 85, 104, 0.8) !important;
            }
            
            .mobile-fintech-footer a.active {
                color: #2c5bf5 !important;
            }
            
            .page-title, .welcome-tag, .welcome-meta, .side-description {
                color: #1a1a2e !important;
            }
            
            .back-link {
                color: #2c5bf5 !important;
            }
            
            .vector-cluster {
                background: linear-gradient(135deg, rgba(44, 92, 245, 0.15), rgba(255, 255, 255, 0.9)) !important;
            }
        </style>
        ";
    }
    
    // Default dark theme
    return "
    <style>
        :root {
            --page-blue-900: #030922;
            --page-blue-700: #0a164a;
            --page-blue-500: #142a7e;
            --page-blue-300: #2c5bf5;
            --page-mint: #4de1c1;
            --page-white: #f5f9ff;
            --panel-glass: rgba(13, 24, 62, 0.78);
            --panel-border: rgba(86, 139, 241, 0.28);
            --shadow-heavy: 0 40px 120px rgba(4, 10, 36, 0.65);
        }
        
        body {
            background: radial-gradient(circle at 0% 0%, rgba(61, 116, 255, 0.28), transparent 55%),
                        radial-gradient(circle at 100% 0%, rgba(77, 225, 193, 0.18), transparent 40%),
                        linear-gradient(180deg, var(--page-blue-900), var(--page-blue-700)) !important;
            color: var(--page-white) !important;
        }
    </style>
    ";
}

function includeGamifiedAssets() {
    echo '<link rel="stylesheet" href="assets/css/gamified-fintech-theme.css">';
    echo '<script src="assets/js/theme-switcher.js" defer></script>';
}

function renderThemeToggle() {
    return '
    <button id="theme-toggle-btn" class="theme-toggle-button" aria-label="Toggle theme" style="
        position: fixed;
        bottom: 24px;
        right: 24px;
        width: 56px;
        height: 56px;
        border-radius: 50%;
        background: linear-gradient(135deg, #4de1c1, #2c5bf5);
        border: none;
        cursor: pointer;
        display: flex;
        align-items: center;
        justify-content: center;
        box-shadow: 0 8px 24px rgba(77, 225, 193, 0.4);
        transition: transform 0.3s ease, box-shadow 0.3s ease;
        z-index: 1000;
    ">
        <svg viewBox="0 0 24 24" width="24" height="24" fill="white">
            <path d="M12 18a6 6 0 1 1 0-12 6 6 0 0 1 0 12zm0-2a4 4 0 1 0 0-8 4 4 0 0 0 0 8zM11 1h2v3h-2V1zm0 19h2v3h-2v-3zM3.515 4.929l1.414-1.414L7.05 5.636 5.636 7.05 3.515 4.93zM16.95 18.364l1.414-1.414 2.121 2.121-1.414 1.414-2.121-2.121zm2.121-14.85l1.414 1.415-2.121 2.121-1.414-1.414 2.121-2.121zM5.636 16.95l1.414 1.414-2.121 2.121-1.414-1.414 2.121-2.121zM23 11v2h-3v-2h3zM4 11v2H1v-2h3z"/>
        </svg>
    </button>
    ';
}
?>
