<?php
session_start();
require_once 'config/database.php';
require_once 'includes/session.php';
require_once 'includes/connect.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$user_id = $_SESSION['user_id'];

// Get order number from URL
if (!isset($_GET['order'])) {
    header('Location: membership.php');
    exit();
}

$order_number = $_GET['order'];

// Fetch order details
$stmt = $conn->prepare("
    SELECT o.*, b.full_name, b.email, b.phone, b.address, b.city, b.state, u.username
    FROM orders o
    LEFT JOIN billing_information b ON o.billing_info_id = b.id
    LEFT JOIN users u ON o.user_id = u.id
    WHERE o.order_number = ? AND o.user_id = ?
");
$stmt->bind_param("si", $order_number, $user_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    header('Location: membership.php');
    exit();
}

$order = $result->fetch_assoc();
$stmt->close();

// Format order type for display
$order_type_display = str_replace('_', ' ', ucwords($order['order_type']));
$status_color = $order['status'] === 'paid' ? '#4de1c1' : '#fbbf24';
$status_text = $order['status'] === 'paid' ? 'PAID' : 'UNPAID';
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Receipt - <?php echo htmlspecialchars($order_number); ?></title>
  <style>
    :root {
      --page-blue-900: #030922;
      --page-blue-700: #0a164a;
      --page-mint: #4de1c1;
      --page-white: #f5f9ff;
      --panel-glass: rgba(13, 24, 62, 0.78);
      --panel-border: rgba(86, 139, 241, 0.28);
    }

    * { box-sizing: border-box; }

    body {
      margin: 0;
      font-family: "Titillium Web", "Segoe UI", sans-serif;
      background: linear-gradient(180deg, var(--page-blue-900), var(--page-blue-700));
      color: var(--page-white);
      min-height: 100vh;
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 20px;
    }

    .receipt-container {
      max-width: 700px;
      width: 100%;
      background: var(--panel-glass);
      border: 1px solid var(--panel-border);
      border-radius: 24px;
      padding: 40px;
      box-shadow: 0 40px 120px rgba(4, 10, 36, 0.65);
    }

    .receipt-header {
      text-align: center;
      margin-bottom: 32px;
      padding-bottom: 24px;
      border-bottom: 2px solid var(--panel-border);
    }

    .receipt-logo {
      font-size: 2.5rem;
      font-weight: 700;
      color: var(--page-mint);
      margin-bottom: 8px;
    }

    .receipt-title {
      font-size: 1.8rem;
      margin: 0 0 8px;
      color: var(--page-white);
    }

    .receipt-number {
      font-size: 0.9rem;
      color: rgba(216, 230, 255, 0.7);
      letter-spacing: 0.1em;
    }

    .status-badge {
      display: inline-block;
      padding: 12px 24px;
      border-radius: 20px;
      font-size: 1.1rem;
      font-weight: 700;
      letter-spacing: 0.1em;
      margin: 20px 0;
      border: 2px solid;
    }

    .status-paid {
      background: rgba(77, 225, 193, 0.2);
      border-color: var(--page-mint);
      color: var(--page-mint);
    }

    .status-unpaid {
      background: rgba(251, 191, 36, 0.2);
      border-color: #fbbf24;
      color: #fbbf24;
    }

    .receipt-section {
      margin: 24px 0;
    }

    .receipt-section h3 {
      font-size: 1.1rem;
      margin: 0 0 16px;
      color: rgba(216, 230, 255, 0.9);
      text-transform: uppercase;
      letter-spacing: 0.1em;
      font-size: 0.9rem;
    }

    .info-grid {
      display: grid;
      gap: 12px;
    }

    .info-row {
      display: flex;
      justify-content: space-between;
      padding: 12px 0;
      border-bottom: 1px solid rgba(86, 139, 241, 0.2);
    }

    .info-label {
      color: rgba(216, 230, 255, 0.7);
      font-size: 0.95rem;
    }

    .info-value {
      color: var(--page-white);
      font-weight: 600;
      text-align: right;
    }

    .total-row {
      border-top: 2px solid var(--panel-border);
      border-bottom: none;
      padding-top: 16px;
      margin-top: 8px;
    }

    .total-row .info-label {
      font-size: 1.1rem;
      color: var(--page-white);
      font-weight: 700;
    }

    .total-row .info-value {
      font-size: 1.5rem;
      color: var(--page-mint);
    }

    .action-buttons {
      display: grid;
      gap: 16px;
      margin-top: 32px;
    }

    .btn {
      padding: 16px;
      border: none;
      border-radius: 14px;
      font-size: 1rem;
      font-weight: 600;
      cursor: pointer;
      transition: transform 0.3s ease;
      text-decoration: none;
      text-align: center;
      display: block;
    }

    .btn:hover {
      transform: translateY(-2px);
    }

    .btn-primary {
      background: linear-gradient(135deg, #fbbf24, #f59e0b);
      color: var(--page-blue-900);
      box-shadow: 0 12px 28px rgba(251, 191, 36, 0.4);
    }

    .btn-secondary {
      background: rgba(86, 139, 241, 0.2);
      color: var(--page-white);
      border: 1px solid rgba(86, 139, 241, 0.4);
    }

    .receipt-footer {
      text-align: center;
      margin-top: 32px;
      padding-top: 24px;
      border-top: 1px solid var(--panel-border);
      color: rgba(216, 230, 255, 0.6);
      font-size: 0.85rem;
    }

    @media print {
      body {
        background: white;
        color: black;
      }
      .action-buttons {
        display: none;
      }
    }
  </style>
</head>
<body>
  <div class="receipt-container">
    <div class="receipt-header">
      <div class="receipt-logo">FlowEarner</div>
      <h1 class="receipt-title">Payment Receipt</h1>
      <p class="receipt-number">Order #<?php echo htmlspecialchars($order_number); ?></p>
      <div class="status-badge status-<?php echo $order['status']; ?>">
        <?php echo $status_text; ?>
      </div>
    </div>

    <div class="receipt-section">
      <h3>Order Details</h3>
      <div class="info-grid">
        <div class="info-row">
          <span class="info-label">Order Type:</span>
          <span class="info-value"><?php echo htmlspecialchars($order_type_display); ?></span>
        </div>
        <div class="info-row">
          <span class="info-label">Order Date:</span>
          <span class="info-value"><?php echo date('M d, Y - h:i A', strtotime($order['created_at'])); ?></span>
        </div>
        <div class="info-row">
          <span class="info-label">Payment Gateway:</span>
          <span class="info-value"><?php echo ucfirst($order['payment_gateway']); ?></span>
        </div>
        <?php if ($order['payment_reference']): ?>
        <div class="info-row">
          <span class="info-label">Reference:</span>
          <span class="info-value"><?php echo htmlspecialchars($order['payment_reference']); ?></span>
        </div>
        <?php endif; ?>
      </div>
    </div>

    <div class="receipt-section">
      <h3>Billing Information</h3>
      <div class="info-grid">
        <div class="info-row">
          <span class="info-label">Name:</span>
          <span class="info-value"><?php echo htmlspecialchars($order['full_name']); ?></span>
        </div>
        <div class="info-row">
          <span class="info-label">Email:</span>
          <span class="info-value"><?php echo htmlspecialchars($order['email']); ?></span>
        </div>
        <div class="info-row">
          <span class="info-label">Phone:</span>
          <span class="info-value"><?php echo htmlspecialchars($order['phone']); ?></span>
        </div>
        <div class="info-row">
          <span class="info-label">Address:</span>
          <span class="info-value"><?php echo htmlspecialchars($order['address']); ?></span>
        </div>
        <div class="info-row">
          <span class="info-label">City, State:</span>
          <span class="info-value"><?php echo htmlspecialchars($order['city'] . ', ' . $order['state']); ?></span>
        </div>
      </div>
    </div>

    <div class="receipt-section">
      <h3>Payment Summary</h3>
      <div class="info-grid">
        <div class="info-row">
          <span class="info-label">Subtotal:</span>
          <span class="info-value">₦<?php echo number_format($order['amount'], 2); ?></span>
        </div>
        <div class="info-row total-row">
          <span class="info-label">Total Amount:</span>
          <span class="info-value">₦<?php echo number_format($order['amount'], 2); ?></span>
        </div>
      </div>
    </div>

    <div class="action-buttons">
      <?php if ($order['status'] === 'paid'): ?>
        <a href="dashboard.php" class="btn btn-primary">Go to Dashboard</a>
        <button onclick="window.print()" class="btn btn-secondary">Print Receipt</button>
      <?php else: ?>
        <p style="text-align: center; color: #fbbf24; margin: 16px 0;">
          ⏳ Awaiting payment confirmation. Please complete your payment to activate your order.
        </p>
        <a href="membership.php" class="btn btn-primary">Return to Membership</a>
      <?php endif; ?>
    </div>

    <div class="receipt-footer">
      <p>Thank you for choosing FlowEarner!</p>
      <p>For support, contact: admin@flowearner.com</p>
    </div>
  </div>
</body>
</html>
