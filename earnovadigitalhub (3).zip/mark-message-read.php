<?php
require_once 'config/database.php';
require_once 'includes/session.php';
require_once 'includes/connect.php';

// Require authentication
requireLogin();

// Get current user data
$user = getCurrentUser();
$user_id = $user['id'];

// Get message_id from POST
$message_id = $_POST['message_id'] ?? null;

if (!$message_id) {
    echo json_encode(['success' => false, 'message' => 'Invalid message ID']);
    exit;
}

try {
    $pdo = getDBConnection();
    
    // Insert read record
    $stmt = $pdo->prepare("
        INSERT INTO user_message_reads (user_id, message_id, read_at)
        VALUES (?, ?, NOW())
        ON DUPLICATE KEY UPDATE read_at = NOW()
    ");
    $stmt->execute([$user_id, $message_id]);
    
    echo json_encode(['success' => true]);
} catch (PDOException $e) {
    error_log("Mark message read error: " . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'Database error']);
}
?>
