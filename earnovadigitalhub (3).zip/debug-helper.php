<?php
/**
 * Ultimate Debug Helper
 * Add this to the top of any PHP file that's showing a blank page
 * 
 * Usage: require_once 'includes/debug-helper.php';
 */

// Enable output buffering
if (!ob_get_level()) {
    ob_start();
}

// Force display all errors
error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
ini_set('log_errors', 1);
ini_set('error_log', __DIR__ . '/../error_log.txt');

// Custom error handler with visual output
set_error_handler(function($errno, $errstr, $errfile, $errline) {
    $error_types = [
        E_ERROR => 'ERROR',
        E_WARNING => 'WARNING',
        E_PARSE => 'PARSE ERROR',
        E_NOTICE => 'NOTICE',
        E_CORE_ERROR => 'CORE ERROR',
        E_CORE_WARNING => 'CORE WARNING',
        E_COMPILE_ERROR => 'COMPILE ERROR',
        E_COMPILE_WARNING => 'COMPILE WARNING',
        E_USER_ERROR => 'USER ERROR',
        E_USER_WARNING => 'USER WARNING',
        E_USER_NOTICE => 'USER NOTICE',
        E_STRICT => 'STRICT',
        E_RECOVERABLE_ERROR => 'RECOVERABLE ERROR',
        E_DEPRECATED => 'DEPRECATED',
        E_USER_DEPRECATED => 'USER DEPRECATED'
    ];
    
    $error_type = $error_types[$errno] ?? 'UNKNOWN ERROR';
    $error_message = "⚠️ {$error_type} [{$errno}]: {$errstr}\nFile: {$errfile}\nLine: {$errline}\n\n";
    
    // Log to file
    error_log($error_message);
    
    // Display visually
    echo "<div style='background: #f8d7da; color: #721c24; padding: 15px; border-left: 5px solid #f5c6cb; margin: 10px; font-family: monospace;'>";
    echo "<strong>⚠️ {$error_type}</strong><br>";
    echo "<strong>Message:</strong> " . htmlspecialchars($errstr) . "<br>";
    echo "<strong>File:</strong> " . htmlspecialchars($errfile) . "<br>";
    echo "<strong>Line:</strong> {$errline}<br>";
    echo "</div>";
    
    return false; // Let PHP's default error handler run as well
});

// Custom exception handler
set_exception_handler(function($exception) {
    $error_message = "💀 UNCAUGHT EXCEPTION: " . $exception->getMessage() . "\n";
    $error_message .= "File: " . $exception->getFile() . "\n";
    $error_message .= "Line: " . $exception->getLine() . "\n";
    $error_message .= "Stack trace:\n" . $exception->getTraceAsString() . "\n";
    
    // Log to file
    error_log($error_message);
    
    // Display visually
    echo "<div style='background: #f8d7da; color: #721c24; padding: 20px; border-left: 5px solid #dc3545; margin: 10px; font-family: monospace;'>";
    echo "<h2 style='margin: 0 0 10px 0; color: #dc3545;'>💀 UNCAUGHT EXCEPTION</h2>";
    echo "<strong>Message:</strong> " . htmlspecialchars($exception->getMessage()) . "<br>";
    echo "<strong>File:</strong> " . htmlspecialchars($exception->getFile()) . "<br>";
    echo "<strong>Line:</strong> " . $exception->getLine() . "<br>";
    echo "<details style='margin-top: 10px;'>";
    echo "<summary style='cursor: pointer; font-weight: bold;'>Stack Trace</summary>";
    echo "<pre style='background: #fff; padding: 10px; margin-top: 5px; overflow: auto;'>" . htmlspecialchars($exception->getTraceAsString()) . "</pre>";
    echo "</details>";
    echo "</div>";
});

// Register shutdown function to catch fatal errors
register_shutdown_function(function() {
    $error = error_get_last();
    if ($error !== null && in_array($error['type'], [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR, E_RECOVERABLE_ERROR])) {
        $error_types = [
            E_ERROR => 'FATAL ERROR',
            E_PARSE => 'PARSE ERROR',
            E_CORE_ERROR => 'CORE ERROR',
            E_COMPILE_ERROR => 'COMPILE ERROR',
            E_RECOVERABLE_ERROR => 'RECOVERABLE ERROR'
        ];
        
        $error_type = $error_types[$error['type']] ?? 'FATAL ERROR';
        $error_message = "💀 {$error_type}: {$error['message']}\nFile: {$error['file']}\nLine: {$error['line']}\n";
        
        // Log to file
        error_log($error_message);
        
        // Display visually
        echo "<div style='background: #f8d7da; color: #721c24; padding: 20px; border-left: 5px solid #dc3545; margin: 10px; font-family: monospace;'>";
        echo "<h2 style='margin: 0 0 10px 0; color: #dc3545;'>💀 {$error_type}</h2>";
        echo "<strong>Message:</strong> " . htmlspecialchars($error['message']) . "<br>";
        echo "<strong>File:</strong> " . htmlspecialchars($error['file']) . "<br>";
        echo "<strong>Line:</strong> {$error['line']}<br>";
        echo "</div>";
    }
    
    // Flush output buffer
    if (ob_get_level()) {
        ob_end_flush();
    }
});

// Function to check for BOM
function checkForBOM($file) {
    if (file_exists($file)) {
        $contents = file_get_contents($file);
        if (substr($contents, 0, 3) === "\xEF\xBB\xBF") {
            echo "<div style='background: #fff3cd; color: #856404; padding: 15px; border-left: 5px solid #ffc107; margin: 10px; font-family: monospace;'>";
            echo "⚠️ <strong>BOM DETECTED</strong> in file: " . htmlspecialchars($file) . "<br>";
            echo "This can cause 'headers already sent' errors. Remove the BOM from this file.";
            echo "</div>";
            return true;
        }
    }
    return false;
}

// Function to debug session issues
function debugSession() {
    echo "<div style='background: #d1ecf1; color: #0c5460; padding: 15px; border-left: 5px solid #17a2b8; margin: 10px; font-family: monospace;'>";
    echo "<strong>🔍 SESSION DEBUG INFO</strong><br>";
    echo "<strong>Session Status:</strong> " . (session_status() === PHP_SESSION_ACTIVE ? 'Active' : 'Inactive') . "<br>";
    echo "<strong>Session ID:</strong> " . (session_id() ?: 'None') . "<br>";
    echo "<strong>Session Data:</strong><br>";
    echo "<pre style='background: #fff; padding: 10px; margin-top: 5px;'>" . print_r($_SESSION ?? [], true) . "</pre>";
    echo "</div>";
}

// Echo a success message to confirm the debug helper is loaded
echo "<div style='background: #d4edda; color: #155724; padding: 10px; border-left: 5px solid #28a745; margin: 10px; font-family: monospace;'>";
echo "✅ <strong>Debug Helper Loaded Successfully</strong> - All errors will be displayed";
echo "</div>";
?>
