<?php
require_once 'config/database.php';
require_once 'includes/session.php';
require_once 'includes/email-helper.php';

// Redirect if already logged in
if (isLoggedIn()) {
    header('Location: dashboard.php');
    exit();
}

$error = '';
$success = '';
$step = 'email'; // email, code, reset

if (isset($_SESSION['reset_email']) && !isset($_POST['send_code'])) {
    if (isset($_SESSION['reset_user_id']) && isset($_SESSION['reset_code_id'])) {
        $step = 'reset';
    } else {
        $step = 'code';
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['send_code'])) {
        $email = trim($_POST['email'] ?? '');
        
        if (empty($email)) {
            $error = 'Please enter your email address';
        } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $error = 'Invalid email format';
        } else {
            try {
                $pdo = getDBConnection();
                
                // Check if email exists
                $stmt = $pdo->prepare("SELECT id, full_name, email FROM users WHERE email = ?");
                $stmt->execute([$email]);
                $user = $stmt->fetch();
                
                if (!$user) {
                    $error = 'No account found with this email address';
                } else {
                    // Check if a reset code was recently sent (30-second cooldown)
                    $check_stmt = $pdo->prepare("SELECT created_at FROM password_reset_codes WHERE email = ? AND created_at > DATE_SUB(NOW(), INTERVAL 30 SECOND) ORDER BY created_at DESC LIMIT 1");
                    $check_stmt->execute([$email]);
                    $recent_code = $check_stmt->fetch();
                    
                    if ($recent_code) {
                        $error = "Please wait 30 seconds before requesting a new code.";
                    } else {
                    // Generate 6-digit code
                        $reset_code = str_pad(rand(0, 999999), 6, '0', STR_PAD_LEFT);
                        
                        // Store reset code
                        $stmt = $pdo->prepare("INSERT INTO password_reset_codes (user_id, email, reset_code, expires_at) VALUES (?, ?, ?, DATE_ADD(NOW(), INTERVAL 15 MINUTE))");
                        $stmt->execute([$user['id'], $email, $reset_code]);
                        
                        $email_result = sendPasswordResetEmail($user['email'], $user['full_name'], $reset_code);
                        
                        if ($email_result['success']) {
                            $success = "Reset code sent to your email. Please check your inbox.";
                            $_SESSION['reset_email'] = $email;
                            $_SESSION['reset_resend_count'] = 0;
                            $_SESSION['reset_last_resend'] = time();
                            $step = 'code';
                        } else {
                            $error = 'Failed to send reset code. Please try again.';
                            error_log("Email sending failed: " . $email_result['message']);
                        }
                    }
                }
            } catch (Exception $e) {
                $error = 'Failed to send reset code. Please try again.';
                error_log("Password reset error: " . $e->getMessage());
            }
        }
    } elseif (isset($_POST['verify_code'])) {
        $email = $_SESSION['reset_email'] ?? '';
        $code = trim($_POST['reset_code'] ?? '');
        
        if (empty($code)) {
            $error = 'Please enter the reset code';
            $step = 'code'; // Stay on code step
        } else {
            try {
                $pdo = getDBConnection();
                
                $stmt = $pdo->prepare("SELECT * FROM password_reset_codes WHERE email = ? AND reset_code = ? AND is_used = FALSE AND expires_at > NOW() ORDER BY created_at DESC LIMIT 1");
                $stmt->execute([$email, $code]);
                $reset = $stmt->fetch();
                
                if (!$reset) {
                    $error = 'Invalid or expired reset code';
                    $step = 'code'; // Stay on code step
                } else {
                    $_SESSION['reset_code_id'] = $reset['id'];
                    $_SESSION['reset_user_id'] = $reset['user_id'];
                    $step = 'reset';
                }
            } catch (Exception $e) {
                $error = 'Verification failed. Please try again.';
                error_log("Code verification error: " . $e->getMessage());
                $step = 'code'; // Stay on code step
            }
        }
    } elseif (isset($_POST['reset_password'])) {
        $password = $_POST['new_password'] ?? '';
        $confirm_password = $_POST['confirm_password'] ?? '';
        $reset_code_id = $_SESSION['reset_code_id'] ?? 0;
        $user_id = $_SESSION['reset_user_id'] ?? 0;
        
        $step = 'reset';
        
        if (empty($password) || empty($confirm_password)) {
            $error = 'Please fill in all fields';
        } elseif (strlen($password) < 6) {
            $error = 'Password must be at least 6 characters';
        } elseif ($password !== $confirm_password) {
            $error = 'Passwords do not match';
        } else {
            try {
                $pdo = getDBConnection();
                
                // Update password
                $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
                $stmt = $pdo->prepare("UPDATE users SET password_hash = ? WHERE id = ?");
                $stmt->execute([$hashedPassword, $user_id]);
                
                // Mark code as used
                $stmt = $pdo->prepare("UPDATE password_reset_codes SET is_used = TRUE WHERE id = ?");
                $stmt->execute([$reset_code_id]);
                
                // Clear session
                unset($_SESSION['reset_email']);
                unset($_SESSION['reset_code_id']);
                unset($_SESSION['reset_user_id']);
                unset($_SESSION['reset_resend_count']);
                unset($_SESSION['reset_last_resend']);
                
                $success = 'Password reset successful! You can now login with your new password.';
                $step = 'success';
            } catch (Exception $e) {
                $error = 'Failed to reset password. Please try again.';
                error_log("Password reset error: " . $e->getMessage());
            }
        }
    }
}
?>
<?php // <!-- Added GSAP libraries and Google Fonts for Tech Giant design --> ?>
<?php include "doctype.php"; ?>
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet" />
    <link rel="stylesheet" href="styles.css" />
    
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; }
        
        html, body {
            max-width: 100%;
            overflow-x: hidden;
            scroll-behavior: smooth;
        }
        
        body {
            font-family: 'Poppins', -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
            background: radial-gradient(circle at 0% 0%, rgba(61, 116, 255, 0.28), transparent 55%),
                        radial-gradient(circle at 100% 0%, rgba(77, 225, 193, 0.18), transparent 45%),
                        linear-gradient(180deg, #030922, #0a164a);
            color: #f5f9ff;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
            padding-top: 80px;
        }

        <?php // <!-- Header / Navigation from index.php --> ?>
        header {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            z-index: 1000;
            backdrop-filter: blur(12px);
            background: rgba(3, 9, 34, 0.85);
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
            transition: all 0.3s ease;
        }
        
        .nav-container {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 16px 24px;
            max-width: 1280px;
            margin: 0 auto;
        }
        
        .logo-link {
            display: flex;
            align-items: center;
            gap: 12px;
            text-decoration: none;
            color: inherit;
            transition: opacity 0.3s ease;
        }
        
        .logo-link:hover {
            opacity: 0.8;
        }
        
        .logo-img {
            height: 40px;
            width: auto;
        }
        
        nav ul {
            display: none;
            list-style: none;
            gap: 32px;
        }
        
        @media (min-width: 768px) {
            nav ul {
                display: flex;
            }
        }
        
        nav a {
            text-decoration: none;
            color: inherit;
            opacity: 0.8;
            transition: opacity 0.3s ease;
            font-weight: 500;
            font-size: 15px;
        }
        
        nav a:hover {
            opacity: 1;
        }
        
        nav a.active {
            opacity: 1;
            color: #4de1c1;
            font-weight: 600;
        }
        
        .nav-cta {
            display: flex;
            gap: 12px;
            align-items: center;
        }
        
        @media (max-width: 767px) {
            .nav-cta .btn-ghost {
                display: none;
            }
        }
        
        .hamburger-menu {
            display: flex;
            flex-direction: column;
            gap: 5px;
            cursor: pointer;
            padding: 8px;
            background: transparent;
            border: none;
            z-index: 1001;
        }
        
        .hamburger-menu span {
            width: 25px;
            height: 3px;
            background: #f5f9ff;
            border-radius: 2px;
            transition: all 0.3s ease;
        }
        
        .hamburger-menu.active span:nth-child(1) {
            transform: rotate(45deg) translate(8px, 8px);
        }
        
        .hamburger-menu.active span:nth-child(2) {
            opacity: 0;
        }
        
        .hamburger-menu.active span:nth-child(3) {
            transform: rotate(-45deg) translate(7px, -7px);
        }
        
        @media (min-width: 768px) {
            .hamburger-menu {
                display: none;
            }
        }
        
        .mobile-menu {
            position: fixed;
            top: 72px;
            left: 0;
            right: 0;
            background: rgba(3, 9, 34, 0.98);
            backdrop-filter: blur(12px);
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
            max-height: 0;
            overflow: hidden;
            transition: max-height 0.5s ease;
            z-index: 999;
        }
        
        .mobile-menu.active {
            max-height: 400px;
        }
        
        .mobile-menu ul {
            list-style: none;
            padding: 20px 24px;
        }
        
        .mobile-menu li {
            opacity: 0;
            transform: translateX(-20px);
            transition: all 0.3s ease;
        }
        
        .mobile-menu.active li:nth-child(1) { opacity: 1; transform: translateX(0); transition-delay: 0.1s; }
        .mobile-menu.active li:nth-child(2) { opacity: 1; transform: translateX(0); transition-delay: 0.2s; }
        .mobile-menu.active li:nth-child(3) { opacity: 1; transform: translateX(0); transition-delay: 0.3s; }
        .mobile-menu.active li:nth-child(4) { opacity: 1; transform: translateX(0); transition-delay: 0.4s; }
        .mobile-menu.active li:nth-child(5) { opacity: 1; transform: translateX(0); transition-delay: 0.5s; }
        
        .mobile-menu a {
            display: block;
            padding: 12px 0;
            color: #f5f9ff;
            text-decoration: none;
            font-size: 16px;
            font-weight: 500;
            border-bottom: 1px solid rgba(255, 255, 255, 0.05);
            transition: color 0.3s ease;
        }
        
        .mobile-menu a:hover {
            color: #4de1c1;
        }
        
        @media (min-width: 768px) {
            .mobile-menu {
                display: none;
            }
        }

        <?php // <!-- Button Styles matching register.php and login.php --> ?>
        .btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            padding: 12px 24px;
            border-radius: 12px;
            font-weight: 600;
            font-size: 15px;
            text-decoration: none;
            transition: all 0.3s ease;
            border: none;
            cursor: pointer;
            font-family: inherit;
        }
        
        .btn-primary {
            background: linear-gradient(135deg, #2c5bf5, #4de1c1);
            color: #030922;
            box-shadow: 0 4px 16px rgba(44, 91, 245, 0.3);
        }
        
        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 24px rgba(44, 91, 245, 0.4);
        }
        
        .btn-ghost {
            background: transparent;
            color: inherit;
            border: 2px solid rgba(255, 255, 255, 0.2);
        }
        
        .btn-ghost:hover {
            border-color: rgba(255, 255, 255, 0.4);
            background: rgba(255, 255, 255, 0.05);
        }

        <?php // <!-- Main content area for centering the form --> ?>
        main {
            flex: 1;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px 0;
        }
        
        .forgot-password-wrapper {
            width: 100%;
            display: flex;
            justify-content: center;
            padding: 0 20px;
        }
        
        <?php // <!-- Container with full-width on mobile, rounded top corners --> ?>
        .container {
            max-width: 550px;
            width: 100%;
            background: rgba(13, 24, 62, 0.84);
            border: 1px solid rgba(86, 139, 241, 0.3);
            border-radius: 26px;
            padding: 40px;
            box-shadow: 0 40px 120px rgba(4, 10, 36, 0.65);
            backdrop-filter: blur(10px);
            transition: all 0.3s ease;
        }

        <?php // <!-- Mobile full-width with top corners rounded --> ?>
        @media (max-width: 640px) {
            .forgot-password-wrapper {
                padding: 0;
            }
            
            .container {
                border-radius: 26px 26px 0 0;
                border-left: none;
                border-right: none;
                border-bottom: none;
                padding: 30px 25px;
            }
        }
        
        .logo {
            text-align: center;
            margin-bottom: 32px;
        }
        
        .logo-container img {
            width: 130px;
            height: 30px;
            margin: 0 auto 16px;
        }
        
        .logo h1 {
            font-size: 1.5rem;
            font-weight: 700;
            letter-spacing: -0.02em;
            background: linear-gradient(135deg, #2c5bf5, #4de1c1);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            margin-bottom: 8px;
        }
        
        .logo p {
            color: rgba(205, 219, 255, 0.7);
            font-size: 0.875rem;
            line-height: 1.5;
            font-family: 'Inter', sans-serif;
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        label {
            display: block;
            margin-bottom: 8px;
            font-size: 0.875rem;
            font-weight: 500;
            color: rgba(205, 219, 255, 0.9);
        }
        
        .input-wrapper {
            position: relative;
        }

        .input-wrapper svg {
            position: absolute;
            left: 16px;
            top: 50%;
            transform: translateY(-50%);
            width: 20px;
            height: 20px;
            fill: rgba(205, 219, 255, 0.5);
            pointer-events: none;
        }

        .input-wrapper input {
            padding-left: 48px;
        }
        
        input {
            width: 100%;
            padding: 14px 16px;
            border: 1px solid rgba(99, 149, 255, 0.26);
            border-radius: 12px;
            background: rgba(5, 12, 36, 0.82);
            color: #f5f9ff;
            font-size: 1rem;
            transition: border-color 0.3s, box-shadow 0.3s;
            font-family: 'Poppins', sans-serif;
        }
        
        input:focus {
            outline: none;
            border-color: #4de1c1;
            box-shadow: 0 0 0 3px rgba(77, 225, 193, 0.2);
        }
        
        .btn-primary.submit-btn {
            width: 100%;
            padding: 16px;
            border-radius: 12px;
            background: linear-gradient(135deg, rgba(47, 91, 234, 0.95), rgba(77, 225, 193, 0.85));
            color: #030922;
            font-size: 1rem;
            font-weight: 600;
            letter-spacing: 0.02em;
            text-transform: uppercase;
            cursor: pointer;
            transition: transform 0.3s, box-shadow 0.3s;
            box-shadow: 0 24px 55px rgba(40, 90, 230, 0.45);
            margin-top: 8px;
        }
        
        .btn-primary.submit-btn:hover {
            transform: translateY(-4px);
            box-shadow: 0 28px 65px rgba(40, 90, 230, 0.55);
        }
        
        .links {
            text-align: center;
            margin-top: 24px;
        }
        
        .links p {
            margin: 8px 0;
            font-size: 0.9rem;
        }
        
        .links a {
            color: #4de1c1;
            text-decoration: none;
            transition: color 0.3s;
            font-weight: 500;
        }
        
        .links a:hover {
            color: #2c5bf5;
            text-decoration: underline;
        }

        <?php // <!-- Toast message styles --> ?>
        .toast-message {
            position: fixed;
            top: 20px;
            right: -400px;
            padding: 16px 24px;
            border-radius: 12px;
            color: white;
            font-family: 'Segoe UI', sans-serif;
            font-size: 15px;
            z-index: 999999;
            opacity: 0;
            box-shadow: 0 10px 40px rgba(0, 0, 0, 0.2);
            transition: right 0.6s ease, opacity 0.6s ease;
        }

        .toast-message.success {
            background: rgba(77, 225, 193, 0.95);
            color: #030922;
            box-shadow: 0 10px 40px rgba(77, 225, 193, 0.4);
        }

        .toast-message.error {
            background: rgba(255, 77, 77, 0.95);
            color: #fff;
            box-shadow: 0 10px 40px rgba(255, 77, 77, 0.4);
        }

        .toast-message.show {
            right: 20px;
            opacity: 1;
        }

        .success-icon {
            text-align: center;
            margin-bottom: 20px;
        }

        .success-icon svg {
            width: 80px;
            height: 80px;
        }
        
        .btn-secondary {
            background: transparent;
            border: 1px solid rgba(99, 149, 255, 0.4);
            color: #4de1c1;
            padding: 12px 24px;
            border-radius: 12px;
            cursor: pointer;
            font-size: 0.9rem;
            transition: opacity 0.3s, cursor 0.3s;
            width: 100%;
            font-family: 'Poppins', sans-serif;
            font-weight: 500;
        }
        
        .btn-secondary:hover {
            opacity: 0.8;
        }

        <?php // <!-- Footer from index.php --> ?>
        footer {
            padding: 60px 0 30px;
            border-top: 1px solid rgba(255, 255, 255, 0.1);
            background: rgba(3, 9, 34, 0.95);
            margin-top: auto;
        }
        
        .footer-content {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 32px;
            margin-bottom: 32px;
            max-width: 1280px;
            margin: 0 auto 32px;
            padding: 0 24px;
        }
        
        .footer-brand h3 {
            font-size: 1.5rem;
            margin-bottom: 12px;
            background: linear-gradient(135deg, #2c5bf5, #4de1c1);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }
        
        .footer-brand p {
            font-size: 0.875rem;
            opacity: 0.7;
            line-height: 1.6;
            font-family: 'Inter', sans-serif;
        }
        
        .footer-links h4 {
            font-size: 1rem;
            margin-bottom: 16px;
            font-weight: 600;
        }
        
        .footer-links ul {
            list-style: none;
            display: flex;
            flex-direction: column;
            gap: 10px;
        }
        
        .footer-links a {
            color: inherit;
            text-decoration: none;
            opacity: 0.7;
            transition: opacity 0.3s ease;
            font-size: 0.875rem;
            font-family: 'Inter', sans-serif;
        }
        
        .footer-links a:hover {
            opacity: 1;
            color: #4de1c1;
        }
        
        .footer-social {
            display: flex;
            gap: 12px;
            margin-top: 16px;
        }
        
        .social-link {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            border: 1px solid rgba(255, 255, 255, 0.2);
            display: flex;
            align-items: center;
            justify-content: center;
            text-decoration: none;
            color: inherit;
            transition: all 0.3s ease;
        }
        
        .social-link:hover {
            border-color: #4de1c1;
            background: rgba(77, 225, 193, 0.1);
            transform: translateY(-2px);
        }
        
        .social-link svg {
            width: 18px;
            height: 18px;
        }
        
        .footer-bottom {
            text-align: center;
            /*padding-top: 24px;*/
            /*border-top: 1px solid rgba(255, 255, 255, 0.1);*/
            font-size: 0.875rem;
            opacity: 0.6;
            font-family: 'Inter', sans-serif;
            max-width: 1280px;
            margin: 0 auto;
            padding-left: 24px;
            padding-right: 24px;
        }
        
        .footer-developer {
            margin-top: 12px;
            font-size: 0.8125rem;
            opacity: 0.7;
        }
        
        .footer-developer a {
            color: #4de1c1;
            text-decoration: none;
            font-weight: 600;
            transition: opacity 0.3s ease;
        }
        
        .footer-developer a:hover {
            opacity: 0.8;
            text-decoration: underline;
        }
    </style>

<body>
     <?php if ($error): ?>
                    <div id="toast-error" class="toast-message error"><?php echo htmlspecialchars($error); ?></div>
                <?php endif; ?>
                
                <?php if ($success): ?>
                    <div id="toast-success" class="toast-message success"><?php echo htmlspecialchars($success); ?></div>
                <?php endif; ?>
                
    <?php // <!-- Added header navigation from index.php --> ?>
    <header role="banner">
        <div class="nav-container">
            <a href="index.php" class="logo-link" aria-label="Earnova Home">
                <img src="logo.png" alt="Earnova Logo" class="logo-img" />
            </a>
            
            <nav role="navigation" aria-label="Main navigation">
                <ul>
                    <li><a href="index.php">Home</a></li>
                    <li><a href="index.php#features">Features</a></li>
                    <li><a href="index.php#games">Games</a></li>
                    <li><a href="index.php#pricing">Pricing</a></li>
                    <li><a href="terms.php">Privacy Policy</a></li>
                </ul>
            </nav>
            
            <div class="nav-cta">
                <a href="register.php" class="btn btn-ghost">Get Started</a>
                <a href="login.php" class="btn btn-primary">Sign In</a>
                <button class="hamburger-menu" aria-label="Toggle mobile menu" aria-expanded="false">
                    <span></span>
                    <span></span>
                    <span></span>
                </button>
            </div>
        </div>
        
        <div class="mobile-menu">
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="index.php#features">Features</a></li>
                <li><a href="index.php#games">Games</a></li>
                <li><a href="index.php#pricing">Pricing</a></li>
                <li><a href="terms.php">Privacy Policy</a></li>
            </ul>
        </div>
    </header>

    <?php // <!-- Wrapped form in main and wrapper for better centering --> ?>
    <main>
        <div class="forgot-password-wrapper">
            <div class="container">
                <div class="logo">
                    <?php // <!-- removed logo container image as it's already in header --> ?>
                    <h1>Reset Password</h1>
                    <p>
                        <?php 
                        if ($step === 'email') echo 'Enter your email to receive a reset code';
                        elseif ($step === 'code') echo 'Enter the 6-digit code sent to your email';
                        elseif ($step === 'reset') echo 'Create your new password';
                        elseif ($step === 'success') echo 'Password reset successful!';
                        ?>
                    </p>
                </div>
                
               
                
                <?php if ($step === 'email'): ?>
                    <form method="POST" action="">
                        <div class="form-group">
                            <label for="email">Email Address</label>
                            <div class="input-wrapper">
                                <svg viewBox="0 0 24 24">
                                    <path d="M20 4H4c-1.1 0-1.99.9-1.99 2L2 18c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 4l-8 5-8-5V6l8 5 8-5v2z"/>
                                </svg>
                                <input type="email" id="email" name="email" required placeholder="Enter your email">
                            </div>
                        </div>
                        
                        <button type="submit" name="send_code" class="btn-primary submit-btn">Send Reset Code</button>
                    </form>
                <?php elseif ($step === 'code'): ?>
                    <form method="POST" action="">
                        <div class="form-group">
                            <label for="reset_code">Reset Code</label>
                            <div class="input-wrapper">
                                <svg viewBox="0 0 24 24">
                                    <path d="M18 8h-1V6c0-2.76-2.24-5-5-5S7 3.24 7 6v2H6c-1.1 0-2 .9-2 2v10c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V10c0-1.1-.9-2-2-2zm0 9c-1.1 0-2-.9-2-2s1.34-2 3-2 3 1.34 3 3-.9 2-2 2zm3.1-9H8.9V6c0-1.71 1.39-3.1 3.1-3.1 1.71 0 3.1 1.39 3.1 3.1v2z"/>
                                </svg>
                                <input type="text" id="reset_code" name="reset_code" required maxlength="6" placeholder="Enter 6-digit code" style="text-align: center; letter-spacing: 8px; font-size: 1.2rem;">
                            </div>
                        </div>
                        
                        <button type="submit" name="verify_code" class="btn-primary submit-btn">Verify Code</button>
                        
                        <div style="text-align: center; margin-top: 16px;">
                            <button type="button" id="resendResetCodeBtn" class="btn-secondary">
                                Resend Code
                            </button>
                        </div>
                    </form>
                <?php elseif ($step === 'reset'): ?>
                    <form method="POST" action="">
                        <div class="form-group">
                            <label for="new_password">New Password</label>
                            <div class="input-wrapper">
                                <svg viewBox="0 0 24 24">
                                    <path d="M18 8h-1V6c0-2.76-2.24-5-5-5S7 3.24 7 6v2H6c-1.1 0-2 .9-2 2v10c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V10c0-1.1-.9-2-2-2zm0 9c-1.1 0-2-.9-2-2s1.34-2 3-2 3 1.34 3 3-.9 2-2 2zm3.1-9H8.9V6c0-1.71 1.39-3.1 3.1-3.1 1.71 0 3.1 1.39 3.1 3.1v2z"/>
                                </svg>
                                <input type="password" id="new_password" name="new_password" required minlength="6" placeholder="Enter new password">
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <label for="confirm_password">Confirm Password</label>
                            <div class="input-wrapper">
                                <svg viewBox="0 0 24 24">
                                    <path d="M18 8h-1V6c0-2.76-2.24-5-5-5S7 3.24 7 6v2H6c-1.1 0-2 .9-2 2v10c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V10c0-1.1-.9-2-2-2zm0 9c-1.1 0-2-.9-2-2s1.34-2 3-2 3 1.34 3 3-.9 2-2 2zm3.1-9H8.9V6c0-1.71 1.39-3.1 3.1-3.1 1.71 0 3.1 1.39 3.1 3.1v2z"/>
                                </svg>
                                <input type="password" id="confirm_password" name="confirm_password" required placeholder="Confirm new password">
                            </div>
                        </div>
                        
                        <button type="submit" name="reset_password" class="btn-primary submit-btn">Reset Password</button>
                    </form>
                <?php elseif ($step === 'success'): ?>
                    <div class="success-icon">
                        <svg viewBox="0 0 24 24" fill="none">
                            <circle cx="12" cy="12" r="10" fill="url(#grad1)"/>
                            <path d="M9 12l2 2 4-4" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                            <defs>
                                <linearGradient id="grad1" x1="0%" y1="0%" x2="100%" y2="100%">
                                    <stop offset="0%" style="stop-color:#2c5bf5;stop-opacity:1" />
                                    <stop offset="100%" style="stop-color:#4de1c1;stop-opacity:1" />
                                </linearGradient>
                            </defs>
                        </svg>
                    </div>
                    <p style="text-align: center; margin-bottom: 24px; color: rgba(205, 219, 255, 0.8);">
                        Your password has been reset successfully. You can now login with your new password.
                    </p>
                    <a href="login.php" class="btn-primary submit-btn" style="display: block; text-align: center; text-decoration: none;">Go to Login</a>
                <?php endif; ?>
                
                <div class="links">
                    <p><a href="login.php">← Back to Login</a></p>
                </div>
            </div>
        </div>
    </main>

    <?php // <!-- Added footer from index.php --> ?>
     <!-- Added footer from index.php -->
    <footer role="contentinfo">
        
        <div class="footer-bottom">
            <p>&copy; 2025 Earnova. All rights reserved. Built with care for earners and advertisers worldwide.</p>
            <!--<p class="footer-developer">-->
            <!--    Developed by <a href="https://wa.me/2348012345678" target="_blank" rel="noopener noreferrer">OBODO DEV</a>-->
            <!--</p>-->
        </div>
    </footer>
   

    <?php // <!-- Added GSAP for smooth animations --> ?>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.5/gsap.min.js" defer></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.5/ScrollTrigger.min.js" defer></script>
    
  <script>
        // Initialize sessionStorage with PHP session values for timer
        <?php if ($step === 'code'): ?>
            const phpLastResendTime = <?php echo isset($_SESSION['reset_last_resend']) ? $_SESSION['reset_last_resend'] : 0; ?>;
            if (phpLastResendTime > 0) {
                sessionStorage.setItem('reset_last_resend', phpLastResendTime.toString());
            }
        <?php endif; ?>

        document.addEventListener("DOMContentLoaded", () => {
            const successToast = document.getElementById("toast-success");
            const errorToast = document.getElementById("toast-error");

            function showToast(toast) {
                if (!toast) return;
                setTimeout(() => toast.classList.add("show"), 100);
                setTimeout(() => toast.classList.remove("show"), 5000);
            }

            showToast(successToast);
            showToast(errorToast);

            <?php // <!-- Added hamburger menu functionality --> ?>
            const hamburger = document.querySelector('.hamburger-menu');
            const mobileMenu = document.querySelector('.mobile-menu');
            
            if (hamburger && mobileMenu) {
                hamburger.addEventListener('click', function() {
                    this.classList.toggle('active');
                    mobileMenu.classList.toggle('active');
                    const isExpanded = this.classList.contains('active');
                    this.setAttribute('aria-expanded', isExpanded);
                });
                
                const mobileLinks = document.querySelectorAll('.mobile-menu a');
                mobileLinks.forEach(link => {
                    link.addEventListener('click', function() {
                        hamburger.classList.remove('active');
                        mobileMenu.classList.remove('active');
                        hamburger.setAttribute('aria-expanded', 'false');
                    });
                });
            }

            <?php // <!-- Added GSAP animation on page load --> ?>
            window.addEventListener('load', function() {
                if (typeof gsap !== 'undefined') {
                    gsap.registerPlugin(ScrollTrigger);
                    
                    const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
                    
                    if (!prefersReducedMotion) {
                        gsap.from('.container', {
                            duration: 0.8,
                            y: 50,
                            opacity: 0,
                            ease: 'power3.out'
                        });
                    }
                }
            });

            const resendBtn = document.getElementById('resendResetCodeBtn');
            if (resendBtn) {
                const waitTime = 30;
                
                function updateResendButton() {
                    const now = Math.floor(Date.now() / 1000);
                    const lastResendTime = parseInt(sessionStorage.getItem('reset_last_resend') || '0');
                    const elapsed = now - lastResendTime;
                    const remaining = Math.max(0, waitTime - elapsed);
                    
                    if (remaining > 0 && lastResendTime > 0) {
                        resendBtn.disabled = true;
                        resendBtn.style.opacity = '0.5';
                        resendBtn.style.cursor = 'not-allowed';
                        resendBtn.textContent = `Resend Code in ${remaining}s`;
                        setTimeout(updateResendButton, 1000);
                    } else {
                        resendBtn.disabled = false;
                        resendBtn.style.opacity = '1';
                        resendBtn.style.cursor = 'pointer';
                        resendBtn.textContent = 'Resend Code';
                    }
                }
                
                updateResendButton();
                
                resendBtn.addEventListener('click', async function() {
                    if (this.disabled) return;
                    this.disabled = true;
                    this.textContent = 'Sending...';
                    
                    try {
                        const response = await fetch('api/resend-password-reset.php', {
                            method: 'POST',
                            headers: { 'Content-Type': 'application/json' }
                        });
                        const data = await response.json();
                        
                        if (data.success) {
                            const now = Math.floor(Date.now() / 1000);
                            sessionStorage.setItem('reset_last_resend', now.toString());
                            
                            const successToast = document.getElementById('toast-success');
                            if (successToast) {
                                successToast.textContent = 'Reset code resent successfully!';
                                showToast(successToast);
                            }
                            updateResendButton();
                        } else {
                            if (data.remaining_seconds) {
                                const errorToast = document.getElementById('toast-error');
                                if (errorToast) {
                                    errorToast.textContent = `Please wait ${data.remaining_seconds} seconds before requesting another code`;
                                    showToast(errorToast);
                                }
                            } else {
                                const errorToast = document.getElementById('toast-error');
                                if (errorToast) {
                                    errorToast.textContent = data.message || 'Failed to resend code';
                                    showToast(errorToast);
                                }
                            }
                            this.disabled = false;
                            this.textContent = 'Resend Code';
                        }
                    } catch (error) {
                        console.error('Resend error:', error);
                        const errorToast = document.getElementById('toast-error');
                        if (errorToast) {
                            errorToast.textContent = 'Network error. Please try again.';
                            showToast(errorToast);
                        }
                        this.disabled = false;
                        this.textContent = 'Resend Code';
                    }
                });
            }
        });
    </script>
</body>
</html>
