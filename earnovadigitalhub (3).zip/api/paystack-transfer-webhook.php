<?php
/**
 * Paystack Webhook Handler for Prime Earnings Withdrawal Transfers
 * Receives transfer status updates from Paystack
 */

// IMPORTANT: Only include database.php - NOT connect.php
// connect.php calls requireLogin() which fails for webhook calls from Paystack
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/email.php';

header('Content-Type: application/json');

$log_file = __DIR__ . '/../paystack_error_logs';

function logWebhook($message, $log_file) {
    $timestamp = date('Y-m-d H:i:s');
    file_put_contents($log_file, "[$timestamp] WEBHOOK: $message\n", FILE_APPEND);
}

$payload = file_get_contents('php://input');
$signature = $_SERVER['HTTP_X_PAYSTACK_SIGNATURE'] ?? '';

logWebhook("Received webhook - Signature present: " . (!empty($signature) ? 'YES' : 'NO'), $log_file);

$computed_signature = hash_hmac('sha512', $payload, 'sk_live_7ceb76976f99b57f94ff8ba1e7d1940254b052ba');

if ($signature !== $computed_signature) {
    logWebhook("INVALID SIGNATURE - Rejecting webhook", $log_file);
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Invalid signature']);
    exit;
}

$event = json_decode($payload, true);
$event_type = $event['event'] ?? 'unknown';

logWebhook("Event type: $event_type - Payload: " . substr($payload, 0, 500), $log_file);

if ($event['event'] === 'transfer.success') {
    $transfer_data = $event['data'];
    $reference = $transfer_data['reference'];
    
    logWebhook("TRANSFER SUCCESS - Reference: $reference", $log_file);
    
    // Extract withdrawal_id from reference (format: WD-{id}-{timestamp})
    preg_match('/WD-(\d+)-/', $reference, $matches);
    $withdrawal_id = $matches[1] ?? null;

    if ($withdrawal_id) {
        logWebhook("Processing success for withdrawal ID: $withdrawal_id", $log_file);
        
        $stmt = $conn->prepare("
            UPDATE withdrawals 
            SET status = 'completed',
                paystack_status = 'success',
                paystack_completed_at = NOW(),
                processed_at = NOW()
            WHERE id = ? AND withdrawal_type = 'prime_earnings'
        ");
        $stmt->bind_param("i", $withdrawal_id);
        $stmt->execute();
        $affected_rows = $stmt->affected_rows;
        $stmt->close();
        
        logWebhook("Updated withdrawal - Affected rows: $affected_rows", $log_file);

        // Get withdrawal details for email
        $stmt = $conn->prepare("
            SELECT u.email, u.full_name, w.amount FROM withdrawals w
            JOIN users u ON w.user_id = u.id WHERE w.id = ?
        ");
        $stmt->bind_param("i", $withdrawal_id);
        $stmt->execute();
        $result = $stmt->get_result()->fetch_assoc();
        $stmt->close();

        if ($result) {
            // Send success email
            $subject = 'Prime Earnings Withdrawal Completed';
            $message = "Hi " . $result['full_name'] . ",<br><br>";
            $message .= "Your Prime Earnings withdrawal of ₦" . number_format($result['amount'], 2) . " has been successfully completed!<br>";
            $message .= "The funds are now in your bank account.<br><br>";
            $message .= "Thank you for using Earnova Digital Hub!";
            
            if (function_exists('sendEmail')) {
                sendEmail($result['email'], $subject, $message);
                logWebhook("Success email sent to: " . $result['email'], $log_file);
            }
        }

        echo json_encode(['success' => true, 'message' => 'Transfer completed successfully']);
    } else {
        logWebhook("Could not extract withdrawal ID from reference: $reference", $log_file);
    }
} elseif ($event['event'] === 'transfer.failed') {
    $transfer_data = $event['data'];
    $reference = $transfer_data['reference'];
    $reason = $transfer_data['reason'] ?? 'Transfer failed';
    
    logWebhook("TRANSFER FAILED - Reference: $reference, Reason: $reason", $log_file);
    
    preg_match('/WD-(\d+)-/', $reference, $matches);
    $withdrawal_id = $matches[1] ?? null;

    if ($withdrawal_id) {
        logWebhook("Processing failure for withdrawal ID: $withdrawal_id", $log_file);
        
        // Get withdrawal for refund
        $stmt = $conn->prepare("SELECT user_id, amount, withdrawal_type FROM withdrawals WHERE id = ?");
        $stmt->bind_param("i", $withdrawal_id);
        $stmt->execute();
        $withdrawal = $stmt->get_result()->fetch_assoc();
        $stmt->close();

        if ($withdrawal) {
            // Refund to user balance
            $balance_field = ($withdrawal['withdrawal_type'] === 'prime_earnings') ? 'referral_earnings' : 'task_earnings';
            
            $stmt = $conn->prepare("
                UPDATE balances 
                SET $balance_field = $balance_field + ?, total_balance = total_balance + ?
                WHERE user_id = ?
            ");
            $stmt->bind_param("ddi", $withdrawal['amount'], $withdrawal['amount'], $withdrawal['user_id']);
            $stmt->execute();
            $stmt->close();
            
            logWebhook("Refunded {$withdrawal['amount']} to user {$withdrawal['user_id']}", $log_file);

            // Update withdrawal record
            $stmt = $conn->prepare("
                UPDATE withdrawals 
                SET status = 'rejected',
                    paystack_status = 'failed',
                    paystack_error_message = ?
                WHERE id = ?
            ");
            $stmt->bind_param("si", $reason, $withdrawal_id);
            $stmt->execute();
            $stmt->close();
            
            logWebhook("Marked withdrawal as rejected", $log_file);
            
            // Send failure notification email
            $stmt = $conn->prepare("SELECT email, full_name FROM users WHERE id = ?");
            $stmt->bind_param("i", $withdrawal['user_id']);
            $stmt->execute();
            $user = $stmt->get_result()->fetch_assoc();
            $stmt->close();
            
            if ($user && function_exists('sendEmail')) {
                $subject = 'Prime Earnings Withdrawal Failed';
                $email_message = "Hi " . $user['full_name'] . ",<br><br>";
                $email_message .= "Unfortunately, your Prime Earnings withdrawal of ₦" . number_format($withdrawal['amount'], 2) . " could not be completed.<br>";
                $email_message .= "Reason: $reason<br><br>";
                $email_message .= "The funds have been returned to your account. Please verify your bank details and try again.<br><br>";
                $email_message .= "If you continue to experience issues, please contact support.<br><br>";
                $email_message .= "Thank you for using Earnova Digital Hub!";
                
                sendEmail($user['email'], $subject, $email_message);
                logWebhook("Failure email sent to: " . $user['email'], $log_file);
            }
        }

        echo json_encode(['success' => true, 'message' => 'Transfer failure logged']);
    } else {
        logWebhook("Could not extract withdrawal ID from reference: $reference", $log_file);
    }
} elseif ($event['event'] === 'transfer.reversed') {
    $transfer_data = $event['data'];
    $reference = $transfer_data['reference'];
    
    logWebhook("TRANSFER REVERSED - Reference: $reference", $log_file);
    
    preg_match('/WD-(\d+)-/', $reference, $matches);
    $withdrawal_id = $matches[1] ?? null;
    
    if ($withdrawal_id) {
        // Handle reversal similar to failure
        $stmt = $conn->prepare("SELECT user_id, amount, withdrawal_type FROM withdrawals WHERE id = ?");
        $stmt->bind_param("i", $withdrawal_id);
        $stmt->execute();
        $withdrawal = $stmt->get_result()->fetch_assoc();
        $stmt->close();

        if ($withdrawal) {
            $balance_field = ($withdrawal['withdrawal_type'] === 'prime_earnings') ? 'referral_earnings' : 'task_earnings';
            
            $stmt = $conn->prepare("
                UPDATE balances 
                SET $balance_field = $balance_field + ?, total_balance = total_balance + ?
                WHERE user_id = ?
            ");
            $stmt->bind_param("ddi", $withdrawal['amount'], $withdrawal['amount'], $withdrawal['user_id']);
            $stmt->execute();
            $stmt->close();

            $stmt = $conn->prepare("
                UPDATE withdrawals 
                SET status = 'rejected',
                    paystack_status = 'reversed',
                    paystack_error_message = 'Transfer was reversed'
                WHERE id = ?
            ");
            $stmt->bind_param("i", $withdrawal_id);
            $stmt->execute();
            $stmt->close();
            
            logWebhook("Handled reversal for withdrawal $withdrawal_id", $log_file);
        }
    }
    
    echo json_encode(['success' => true, 'message' => 'Transfer reversal handled']);
} else {
    logWebhook("Unknown event type: $event_type", $log_file);
    echo json_encode(['success' => true, 'message' => 'Event received']);
}
?>
