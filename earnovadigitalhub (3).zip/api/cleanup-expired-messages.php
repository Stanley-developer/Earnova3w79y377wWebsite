<?php
require_once '../includes/connect.php';

// Delete messages older than 24 hours
$stmt = $pdo->prepare("
    DELETE FROM chat_earn_messages 
    WHERE sent_at < DATE_SUB(NOW(), INTERVAL 24 HOUR)
");
$stmt->execute();

$deleted_count = $stmt->rowCount();

echo json_encode([
    'success' => true,
    'deleted_count' => $deleted_count,
    'message' => "Cleaned up $deleted_count expired messages"
]);
?>
