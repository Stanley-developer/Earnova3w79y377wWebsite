<?php
session_start();
require_once '../includes/connect.php';

header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'Not authenticated']);
    exit;
}

$user_id = $_SESSION['user_id'];
$paired_user_id = intval($_GET['paired_user_id'] ?? 0);

if ($paired_user_id === 0) {
    echo json_encode(['success' => false, 'message' => 'Invalid paired user']);
    exit;
}

// Get messages that haven't expired (within 24 hours)
$stmt = $pdo->prepare("
    SELECT 
        m.message_text,
        m.is_from_user,
        m.sent_at,
        DATE_FORMAT(m.sent_at, '%h:%i %p') as formatted_time
    FROM chat_earn_messages m
    INNER JOIN chat_earn_history h ON (
        (m.user_id = h.user_id AND m.paired_user_id = h.paired_user_id) OR
        (m.user_id = h.paired_user_id AND m.paired_user_id = h.user_id)
    )
    WHERE (m.user_id = ? AND m.paired_user_id = ?)
       OR (m.user_id = ? AND m.paired_user_id = ?)
    AND h.expires_at > NOW()
    AND m.sent_at > DATE_SUB(NOW(), INTERVAL 24 HOUR)
    ORDER BY m.sent_at ASC
");
$stmt->execute([$user_id, $paired_user_id, $paired_user_id, $user_id]);
$messages = $stmt->fetchAll(PDO::FETCH_ASSOC);

echo json_encode([
    'success' => true,
    'messages' => $messages
]);
?>
