<?php
require_once '../config/database.php';
require_once '../includes/session.php';

header('Content-Type: application/json');

// Require authentication
requireLogin();

$user = getCurrentUser();
$user_id = $user['id'];

try {
    $pdo = getDBConnection();
    $pdo->beginTransaction();
    
    // Get request data
    $input = json_decode(file_get_contents('php://input'), true);
    $bet_amount = floatval($input['bet_amount'] ?? 0);
    $is_free_play = boolval($input['is_free_play'] ?? false);
    
    // Fetch user data
    $stmt = $pdo->prepare("SELECT u.*, b.task_earnings, b.game_earnings FROM users u LEFT JOIN balances b ON u.id = b.user_id WHERE u.id = ? FOR UPDATE");
    $stmt->execute([$user_id]);
    $user_data = $stmt->fetch();
    
    if (!$user_data) {
        throw new Exception('User not found');
    }
    
    // Check premium membership
    if ($user_data['membership_type'] !== 'premium') {
        throw new Exception('This game is only available for premium members');
    }
    
    if ($is_free_play) {
        // Check if user has free spins
        if ($user_data['spin_win_free_plays'] <= 0) {
            throw new Exception('No free spins remaining');
        }
        
        // Deduct free spin
        $stmt = $pdo->prepare("UPDATE users SET spin_win_free_plays = spin_win_free_plays - 1 WHERE id = ?");
        $stmt->execute([$user_id]);
        
        $bet_amount = 0; // Free play has no bet
        $free_spins_remaining = $user_data['spin_win_free_plays'] - 1;
    } else {
        if ($bet_amount < 1000) {
            throw new Exception('Minimum bet amount is ₦1,000');
        }
        
        // Check if user has sufficient balance
        if ($user_data['game_earnings'] < $bet_amount) {
            throw new Exception('Insufficient play balance');
        }
        
        // Deduct bet amount from game earnings
        $stmt = $pdo->prepare("UPDATE balances SET game_earnings = game_earnings - ?, total_balance = total_balance - ? WHERE user_id = ?");
        $stmt->execute([$bet_amount, $bet_amount, $user_id]);
        
        $free_spins_remaining = $user_data['spin_win_free_plays'];
    }
    
    $rand = mt_rand(1, 100);
    if ($rand <= 25) {
        $multiplier = 0.5;
    } elseif ($rand <= 45) {
        $multiplier = 1.0;
    } elseif ($rand <= 65) {
        $multiplier = 1.5;
    } elseif ($rand <= 80) {
        $multiplier = 2.0;
    } elseif ($rand <= 90) {
        $multiplier = 3.0;
    } elseif ($rand <= 97) {
        $multiplier = 5.0;
    } else {
        $multiplier = 10.0;
    }
    
    // Calculate win amount
    $base_amount = $is_free_play ? 100 : $bet_amount;
    $win_amount = $base_amount * $multiplier;
    
    // Credit win amount to game earnings
    $stmt = $pdo->prepare("UPDATE balances SET game_earnings = game_earnings + ?, total_balance = total_balance + ? WHERE user_id = ?");
    $stmt->execute([$win_amount, $win_amount, $user_id]);

    // Log transaction
    $stmt = $pdo->prepare("INSERT INTO transactions (user_id, type, amount, description, status) VALUES (?, 'spin_win', ?, ?, 'completed')");
    $description = $is_free_play ? "Spin & Win (Free Play) - {$multiplier}x" : "Spin & Win - Bet: ₦{$bet_amount}, Multiplier: {$multiplier}x";
    $stmt->execute([$user_id, $win_amount, $description]);
    
    // Record game
    $stmt = $pdo->prepare("INSERT INTO spin_win_games (user_id, bet_amount, multiplier, win_amount, is_free_play) VALUES (?, ?, ?, ?, ?)");
    $stmt->execute([$user_id, $bet_amount, $multiplier, $win_amount, $is_free_play]);
    
    // Update stats
    $profit = $win_amount - $bet_amount;
    $stmt = $pdo->prepare("
        INSERT INTO spin_win_stats (user_id, total_spins, total_wins, total_bet, total_won, total_profit, biggest_win)
        VALUES (?, 1, ?, ?, ?, ?, ?)
        ON DUPLICATE KEY UPDATE
            total_spins = total_spins + 1,
            total_wins = total_wins + ?,
            total_bet = total_bet + ?,
            total_won = total_won + ?,
            total_profit = total_profit + ?,
            biggest_win = GREATEST(biggest_win, ?)
    ");
    $is_win = $multiplier >= 1 ? 1 : 0;
    $stmt->execute([
        $user_id, $is_win, $bet_amount, $win_amount, $profit, $win_amount,
        $is_win, $bet_amount, $win_amount, $profit, $win_amount
    ]);
    
    // Get new balance
    $stmt = $pdo->prepare("SELECT game_earnings FROM balances WHERE user_id = ?");
    $stmt->execute([$user_id]);
    $new_balance = $stmt->fetchColumn();
    
    $pdo->commit();
    
    echo json_encode([
        'success' => true,
        'multiplier' => $multiplier,
        'win_amount' => $win_amount,
        'new_balance' => $new_balance,
        'free_spins_remaining' => $free_spins_remaining
    ]);
    
} catch (Exception $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
}
