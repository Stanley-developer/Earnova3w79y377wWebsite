<?php
/**
 * Newsletter Unsubscribe Handler
 * Allows users to unsubscribe from newsletter
 */

session_start();
require_once '../config/database.php';

error_log("[NEWSLETTER] Unsubscribe endpoint called");

$method = $_SERVER['REQUEST_METHOD'];
header('Content-Type: application/json');

if ($method === 'GET') {
    // GET request from email unsubscribe link
    $token = trim($_GET['token'] ?? '');
    $email = trim($_GET['email'] ?? '');
    
    if (empty($token) || empty($email)) {
        http_response_code(400);
        die('Invalid unsubscribe link');
    }
    
    try {
        // Verify token
        $stmt = $conn->prepare("SELECT id FROM newsletters_subscribers WHERE email = ? AND confirmation_token = ?");
        $stmt->bind_param("ss", $email, $token);
        $stmt->execute();
        
        if ($stmt->get_result()->num_rows === 0) {
            http_response_code(404);
            die('Invalid unsubscribe link');
        }
        
        // Update subscription status
        $unsubscribed_at = date('Y-m-d H:i:s');
        $stmt = $conn->prepare("UPDATE newsletters_subscribers SET subscription_status = 'unsubscribed', unsubscribed_at = ? WHERE email = ?");
        $stmt->bind_param("ss", $unsubscribed_at, $email);
        $stmt->execute();
        
        error_log("[NEWSLETTER] Unsubscribed: $email");
        
        http_response_code(200);
        ?>
        <!DOCTYPE html>
        <html>
        <head>
            <title>Unsubscribed - Earnova Digital Hub</title>
            <style>
                body { font-family: Arial, sans-serif; background: linear-gradient(135deg, #2c5bf5, #4de1c1); margin: 0; padding: 20px; min-height: 100vh; display: flex; align-items: center; justify-content: center; }
                .container { max-width: 600px; background: white; padding: 40px; border-radius: 10px; box-shadow: 0 10px 30px rgba(0,0,0,0.2); text-align: center; }
                .logo { max-width: 150px; margin-bottom: 20px; }
                h1 { color: #2c5bf5; margin: 0 0 10px 0; font-size: 28px; }
                p { color: #666; line-height: 1.6; }
            </style>
        </head>
        <body>
            <div class="container">
                <!-- Updated unsubscribe page with Earnova branding and logo -->
                <img src="https://earnova.org/logo.png" alt="Earnova Digital Hub" class="logo" style="height: 50px; width: auto;">
                <h1>Unsubscribed</h1>
                <p>You have been unsubscribed from the <strong>Earnova Digital Hub</strong> newsletter.</p>
                <p>You will no longer receive emails from us.</p>
            </div>
        </body>
        </html>
        <?php
        
    } catch (Exception $e) {
        error_log("[NEWSLETTER] Unsubscribe error: " . $e->getMessage());
        http_response_code(500);
        die('An error occurred. Please try again later.');
    }
} elseif ($method === 'POST') {
    // POST request from authenticated users
    $user_id = $_SESSION['user_id'] ?? null;
    
    if (empty($user_id)) {
        http_response_code(401);
        echo json_encode(['success' => false, 'message' => 'Unauthorized']);
        exit();
    }
    
    try {
        $unsubscribed_at = date('Y-m-d H:i:s');
        $stmt = $conn->prepare("UPDATE newsletters_subscribers SET subscription_status = 'unsubscribed', unsubscribed_at = ? WHERE user_id = ?");
        $stmt->bind_param("si", $unsubscribed_at, $user_id);
        $stmt->execute();
        
        echo json_encode(['success' => true, 'message' => 'Unsubscribed successfully']);
    } catch (Exception $e) {
        error_log("[NEWSLETTER] Unsubscribe error: " . $e->getMessage());
        http_response_code(500);
        echo json_encode(['success' => false, 'message' => 'An error occurred']);
    }
}
?>
