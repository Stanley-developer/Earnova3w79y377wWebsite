<?php

require_once '../config/database.php';
require_once '../includes/email-helper.php';

session_start();

header('Content-Type: application/json');

error_reporting(E_ALL);
ini_set('display_errors', 0); // Don't display errors to user
ini_set('log_errors', 1);

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    error_log("[DEVICE_VERIFICATION] ERROR: Method not allowed - received: " . $_SERVER['REQUEST_METHOD']);
    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    exit();
}

$user_id = $_POST['user_id'] ?? '';
$device_fingerprint = $_POST['device_fingerprint'] ?? '';
$device_info = json_decode($_POST['device_info'] ?? '{}', true);

error_log("[DEVICE_VERIFICATION] ============================================");
error_log("[DEVICE_VERIFICATION] New verification request received");
error_log("[DEVICE_VERIFICATION] User ID: $user_id");
error_log("[DEVICE_VERIFICATION] Device FP (first 20 chars): " . substr($device_fingerprint, 0, 20) . "...");
error_log("[DEVICE_VERIFICATION] Session ID: " . session_id());
error_log("[DEVICE_VERIFICATION] IP Address: " . $_SERVER['REMOTE_ADDR']);
error_log("[DEVICE_VERIFICATION] ============================================");

if (empty($user_id) || empty($device_fingerprint)) {
    error_log("[DEVICE_VERIFICATION] ERROR: Missing required fields");
    error_log("[DEVICE_VERIFICATION] - User ID present: " . (empty($user_id) ? 'NO' : 'YES'));
    error_log("[DEVICE_VERIFICATION] - Device FP present: " . (empty($device_fingerprint) ? 'NO' : 'YES'));
    echo json_encode([
        'success' => false, 
        'message' => 'Missing required fields', 
        'debug' => [
            'user_id' => empty($user_id) ? 'missing' : 'present',
            'device_fingerprint' => empty($device_fingerprint) ? 'missing' : 'present'
        ]
    ]);
    exit();
}

$session_key = "resend_verification_{$user_id}_{$device_fingerprint}";
$resend_count_key = "{$session_key}_count";
$last_resend_key = "{$session_key}_last_time";

// Initialize resend tracking if not exists
if (!isset($_SESSION[$resend_count_key])) {
    $_SESSION[$resend_count_key] = 0;
    $_SESSION[$last_resend_key] = 0;
    error_log("[DEVICE_VERIFICATION] Initialized resend tracking for session");
}

$resend_count = $_SESSION[$resend_count_key];
$last_resend_time = $_SESSION[$last_resend_key];
$current_time = time();
$time_since_last = $current_time - $last_resend_time;

$wait_time = 30; // Always 30 seconds

error_log("[DEVICE_VERIFICATION] Rate limiting check:");
error_log("[DEVICE_VERIFICATION] - Resend count: $resend_count");
error_log("[DEVICE_VERIFICATION] - Last resend: " . ($last_resend_time > 0 ? date('Y-m-d H:i:s', $last_resend_time) : 'never'));
error_log("[DEVICE_VERIFICATION] - Time since last: {$time_since_last}s");
error_log("[DEVICE_VERIFICATION] - Required wait: {$wait_time}s");

// Check if user needs to wait
if ($last_resend_time > 0 && $time_since_last < $wait_time) {
    $remaining_time = $wait_time - $time_since_last;
    error_log("[DEVICE_VERIFICATION] RATE LIMIT: User must wait {$remaining_time}s before next resend");
    echo json_encode([
        'success' => false,
        'message' => "Please wait {$remaining_time} seconds before requesting another code",
        'wait_required' => true,
        'remaining_seconds' => $remaining_time,
        'resend_count' => $resend_count
    ]);
    exit();
}

try {
    error_log("[DEVICE_VERIFICATION] Attempting database connection...");
    $pdo = getDBConnection();
    error_log("[DEVICE_VERIFICATION] ✓ Database connected successfully");
    
    // Get user email
    error_log("[DEVICE_VERIFICATION] Querying user data for ID: $user_id");
    $stmt = $pdo->prepare("SELECT email, full_name FROM users WHERE id = ?");
    $stmt->execute([$user_id]);
    $user = $stmt->fetch();
    
    if (!$user) {
        error_log("[DEVICE_VERIFICATION] ✗ ERROR: User not found in database");
        echo json_encode([
            'success' => false, 
            'message' => 'User not found', 
            'debug' => "No user record with ID: $user_id"
        ]);
        exit();
    }
    
    error_log("[DEVICE_VERIFICATION] ✓ User found:");
    error_log("[DEVICE_VERIFICATION] - Email: {$user['email']}");
    error_log("[DEVICE_VERIFICATION] - Name: {$user['full_name']}");
    
    // Generate 6-digit verification code
    $verification_code = str_pad(rand(0, 999999), 6, '0', STR_PAD_LEFT);
    error_log("[DEVICE_VERIFICATION] ✓ Generated 6-digit code: $verification_code");
    
    // Get IP and location
    $ip_address = $_SERVER['REMOTE_ADDR'];
    $location = 'Unknown';
    
    error_log("[DEVICE_VERIFICATION] Inserting verification record into database...");
    error_log("[DEVICE_VERIFICATION] - Code: $verification_code");
    error_log("[DEVICE_VERIFICATION] - Expires: 15 minutes from now");
    
    try {
        // Store verification code
        $stmt = $pdo->prepare("
            INSERT INTO device_login_verifications 
            (user_id, device_fingerprint, verification_code, ip_address, location, browser, os, expires_at) 
            VALUES (?, ?, ?, ?, ?, ?, ?, DATE_ADD(NOW(), INTERVAL 15 MINUTE))
        ");
        $stmt->execute([
            $user_id,
            $device_fingerprint,
            $verification_code,
            $ip_address,
            $location,
            $device_info['browser'] ?? 'Unknown',
            $device_info['os'] ?? 'Unknown'
        ]);
        error_log("[DEVICE_VERIFICATION] ✓ Verification record inserted successfully (ID: " . $pdo->lastInsertId() . ")");
    } catch (PDOException $db_error) {
        error_log("[DEVICE_VERIFICATION] ✗ DATABASE ERROR:");
        error_log("[DEVICE_VERIFICATION] - Message: " . $db_error->getMessage());
        error_log("[DEVICE_VERIFICATION] - Code: " . $db_error->getCode());
        error_log("[DEVICE_VERIFICATION] - File: " . $db_error->getFile());
        error_log("[DEVICE_VERIFICATION] - Line: " . $db_error->getLine());
        echo json_encode([
            'success' => false, 
            'message' => 'Database error occurred',
            'debug' => [
                'error' => 'Failed to insert verification record',
                'message' => $db_error->getMessage(),
                'code' => $db_error->getCode()
            ]
        ]);
        exit();
    }
    
    error_log("[DEVICE_VERIFICATION] Preparing to send email...");
    error_log("[DEVICE_VERIFICATION] - To: {$user['email']}");
    error_log("[DEVICE_VERIFICATION] - Name: {$user['full_name']}");
    error_log("[DEVICE_VERIFICATION] - Browser: " . ($device_info['browser'] ?? 'Unknown'));
    error_log("[DEVICE_VERIFICATION] - OS: " . ($device_info['os'] ?? 'Unknown'));
    
    $email_result = sendDeviceVerificationEmail(
        $user['email'],
        $user['full_name'],
        $verification_code,
        $device_info,
        $ip_address,
        $location
    );
    
    error_log("[DEVICE_VERIFICATION] Email send result:");
    error_log("[DEVICE_VERIFICATION] - Success: " . ($email_result['success'] ? 'YES' : 'NO'));
    error_log("[DEVICE_VERIFICATION] - Message: {$email_result['message']}");
    
    if ($email_result['success']) {
        $_SESSION[$resend_count_key] = $resend_count + 1;
        $_SESSION[$last_resend_key] = $current_time;
        
        error_log("[DEVICE_VERIFICATION] ============================================");
        error_log("[DEVICE_VERIFICATION] ✓ SUCCESS - Verification email sent");
        error_log("[DEVICE_VERIFICATION] - New resend count: " . ($resend_count + 1));
        error_log("[DEVICE_VERIFICATION] - Next wait time: {$wait_time}s");
        error_log("[DEVICE_VERIFICATION] ============================================");
        
        echo json_encode([
            'success' => true,
            'message' => 'Verification code sent to your email',
            'expires_in' => 900, // 15 minutes in seconds
            'resend_count' => $resend_count + 1,
            'next_wait_time' => $wait_time,
            'debug_mode' => true
        ]);
    } else {
        error_log("[DEVICE_VERIFICATION] ✗ EMAIL FAILED:");
        error_log("[DEVICE_VERIFICATION] - Reason: {$email_result['message']}");
        echo json_encode([
            'success' => false,
            'message' => 'Failed to send verification email',
            'debug' => [
                'email_error' => $email_result['message']
            ]
        ]);
    }
    
} catch (Exception $e) {
    error_log("[DEVICE_VERIFICATION] ============================================");
    error_log("[DEVICE_VERIFICATION] ✗ EXCEPTION CAUGHT:");
    error_log("[DEVICE_VERIFICATION] - Message: " . $e->getMessage());
    error_log("[DEVICE_VERIFICATION] - File: " . $e->getFile());
    error_log("[DEVICE_VERIFICATION] - Line: " . $e->getLine());
    error_log("[DEVICE_VERIFICATION] - Trace: " . $e->getTraceAsString());
    error_log("[DEVICE_VERIFICATION] ============================================");
    
    echo json_encode([
        'success' => false, 
        'message' => 'Error sending verification code',
        'debug' => [
            'exception' => $e->getMessage(),
            'file' => basename($e->getFile()),
            'line' => $e->getLine()
        ]
    ]);
}
?>
