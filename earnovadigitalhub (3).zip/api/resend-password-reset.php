<?php
require_once '../config/database.php';
require_once '../includes/session.php';
require_once '../includes/email-helper.php';

header('Content-Type: application/json');

try {
    // Check if there's an active reset session
    if (!isset($_SESSION['reset_email'])) {
        echo json_encode([
            'success' => false,
            'message' => 'No active password reset session found'
        ]);
        exit;
    }
    
    $email = $_SESSION['reset_email'];
    
    // Initialize or get resend tracking
    if (!isset($_SESSION['reset_resend_count'])) {
        $_SESSION['reset_resend_count'] = 0;
    }
    if (!isset($_SESSION['reset_last_resend'])) {
        $_SESSION['reset_last_resend'] = 0;
    }
    
    $resendCount = $_SESSION['reset_resend_count'];
    $lastResendTime = $_SESSION['reset_last_resend'];
    
    $waitTime = 30; // Always 30 seconds
    
    // Determine required wait time based on resend count
    if ($resendCount > 0) {
        $timeSinceLastResend = time() - $lastResendTime;
        
        if ($timeSinceLastResend < $waitTime) {
            $remainingTime = $waitTime - $timeSinceLastResend;
            echo json_encode([
                'success' => false,
                'message' => 'Please wait before requesting another code',
                'remaining_seconds' => $remainingTime
            ]);
            exit;
        }
    }
    
    $pdo = getDBConnection();
    
    // Get user info
    $stmt = $pdo->prepare("SELECT id, full_name, email FROM users WHERE email = ?");
    $stmt->execute([$email]);
    $user = $stmt->fetch();
    
    if (!$user) {
        echo json_encode([
            'success' => false,
            'message' => 'User not found'
        ]);
        exit;
    }
    
    // Generate new 6-digit code
    $reset_code = str_pad(rand(0, 999999), 6, '0', STR_PAD_LEFT);
    
    // Store new reset code
    $stmt = $pdo->prepare("
        INSERT INTO password_reset_codes (user_id, email, reset_code, expires_at) 
        VALUES (?, ?, ?, DATE_ADD(NOW(), INTERVAL 15 MINUTE))
    ");
    $stmt->execute([$user['id'], $email, $reset_code]);
    
    // Send email
    $email_result = sendPasswordResetEmail($user['email'], $user['full_name'], $reset_code);
    
    if ($email_result['success']) {
        // Update resend tracking
        $_SESSION['reset_resend_count'] = $resendCount + 1;
        $_SESSION['reset_last_resend'] = time();
        
        echo json_encode([
            'success' => true,
            'message' => 'Reset code resent successfully',
            'resend_count' => $_SESSION['reset_resend_count'],
            'next_wait_time' => $waitTime
        ]);
    } else {
        error_log("Failed to send password reset email: " . $email_result['message']);
        echo json_encode([
            'success' => false,
            'message' => 'Failed to send reset code. Please try again.'
        ]);
    }
    
} catch (Exception $e) {
    error_log("Resend password reset error: " . $e->getMessage());
    echo json_encode([
        'success' => false,
        'message' => 'An error occurred. Please try again.',
        'debug' => $e->getMessage()
    ]);
}
?>
