<?php
require_once '../config/database.php';
require_once '../includes/session.php';

header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit;
}

$user_id = $_SESSION['user_id'];

try {
    $pdo = getDBConnection();
    
    $data = json_decode(file_get_contents('php://input'), true);
    $action = $data['action'] ?? 'verify';
    $track_id = $data['track_id'] ?? '';
    $track_title = $data['track_title'] ?? '';
    $proof_email = trim($data['proof_email'] ?? '');
    $stream_duration = intval($data['stream_duration'] ?? 0);
    $track_duration = intval($data['track_duration'] ?? 0);
    
    $ip_address = $_SERVER['REMOTE_ADDR'] ?? '';
    $user_agent = $_SERVER['HTTP_USER_AGENT'] ?? '';
    
    if ($action === 'log_visit') {
        if (empty($track_id)) {
            echo json_encode(['success' => false, 'message' => 'Invalid track']);
            exit;
        }
        
        $stmt = $pdo->prepare("
            INSERT INTO stream_ads_logs (user_id, track_id, event_type, stream_duration, ip_address, user_agent)
            VALUES (?, ?, 'visit_link', 0, ?, ?)
        ");
        $stmt->execute([$user_id, $track_id, $ip_address, $user_agent]);
        
        echo json_encode(['success' => true, 'message' => 'Visit logged', 'visit_time' => time()]);
        exit;
    }
    
    if (empty($track_id) || empty($proof_email) || $stream_duration <= 0 || $track_duration <= 0) {
        echo json_encode(['success' => false, 'message' => 'Invalid stream data']);
        exit;
    }
    
    if (!filter_var($proof_email, FILTER_VALIDATE_EMAIL)) {
        echo json_encode(['success' => false, 'message' => 'Please provide a valid email address']);
        exit;
    }
    
    $stmt = $pdo->prepare("
        SELECT created_at 
        FROM stream_ads_logs 
        WHERE user_id = ? AND track_id = ? AND event_type = 'visit_link'
        ORDER BY created_at DESC
        LIMIT 1
    ");
    $stmt->execute([$user_id, $track_id]);
    $visit_log = $stmt->fetch();
    
    if (!$visit_log) {
        echo json_encode(['success' => false, 'message' => 'You must visit the streaming platform first']);
        exit;
    }
    
    $visit_time = strtotime($visit_log['created_at']);
    $current_time = time();
    $elapsed_seconds = $current_time - $visit_time;
    $required_seconds = 120;
    
    if ($elapsed_seconds < $required_seconds) {
        $remaining = $required_seconds - $elapsed_seconds;
        echo json_encode([
            'success' => false, 
            'message' => "Please spend at least 2 minutes on the streaming platform. {$remaining} seconds remaining."
        ]);
        exit;
    }
    
    $stmt = $pdo->prepare("SELECT membership_type FROM users WHERE id = ?");
    $stmt->execute([$user_id]);
    $user = $stmt->fetch();
    
    if (!$user) {
        echo json_encode(['success' => false, 'message' => 'User not found']);
        exit;
    }
    
    $is_premium = ($user['membership_type'] === 'premium');
    
    $stmt = $pdo->prepare("SELECT free_reward, premium_reward FROM stream_tracks WHERE track_id = ? AND is_ad_track = 1");
    $stmt->execute([$track_id]);
    $track_info = $stmt->fetch();
    
    if (!$track_info) {
        echo json_encode(['success' => false, 'message' => 'Ad track not found']);
        exit;
    }
    
    $free_reward = floatval($track_info['free_reward'] ?? 100);
    $premium_reward = floatval($track_info['premium_reward'] ?? 200);
    
    $completion_percentage = ($stream_duration / $track_duration) * 100;
    
    $is_eligible = ($completion_percentage >= 100 && $is_premium);
    $payout_amount = $is_eligible ? $premium_reward : 0.00;
    
    $stmt = $pdo->prepare("
        SELECT id, payout_status 
        FROM stream_ads_earnings 
        WHERE user_id = ? AND track_id = ?
    ");
    $stmt->execute([$user_id, $track_id]);
    $existing_stream = $stmt->fetch();
    
    if ($existing_stream) {
        echo json_encode([
            'success' => true,
            'payout_awarded' => false,
            'message' => 'You have already completed this ad track',
            'already_claimed' => true
        ]);
        exit;
    }
    
    $stmt = $pdo->prepare("
        SELECT COUNT(*) as email_count 
        FROM stream_ads_earnings 
        WHERE track_id = ? AND proof_email = ?
    ");
    $stmt->execute([$track_id, $proof_email]);
    $email_check = $stmt->fetch();
    
    if ($email_check['email_count'] > 0) {
        echo json_encode([
            'success' => false,
            'message' => 'This email has already been used for this ad. Please use a different email.'
        ]);
        exit;
    }
    
    $one_hour_ago = date('Y-m-d H:i:s', strtotime('-1 hour'));
    $stmt = $pdo->prepare("
        SELECT COUNT(*) as stream_count 
        FROM stream_ads_logs 
        WHERE ip_address = ? AND created_at >= ?
    ");
    $stmt->execute([$ip_address, $one_hour_ago]);
    $rate_check = $stmt->fetch();
    
    if ($rate_check['stream_count'] > 100) {
        echo json_encode([
            'success' => false,
            'message' => 'Rate limit exceeded. Please try again later.'
        ]);
        exit;
    }
    
    $pdo->beginTransaction();
    
    try {
        $stmt = $pdo->prepare("
            INSERT INTO stream_ads_logs (user_id, track_id, event_type, stream_duration, ip_address, user_agent)
            VALUES (?, ?, 'verify', ?, ?, ?)
        ");
        $stmt->execute([$user_id, $track_id, $stream_duration, $ip_address, $user_agent]);
        
        $stmt = $pdo->prepare("
            INSERT INTO stream_ads_earnings 
            (user_id, track_id, track_title, proof_email, stream_duration, completion_percentage, payout_amount, is_eligible, payout_status, ip_address, user_agent, verified_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())
        ");
        $stmt->execute([
            $user_id,
            $track_id,
            $track_title,
            $proof_email,
            $stream_duration,
            $completion_percentage,
            $payout_amount,
            $is_eligible ? 1 : 0,
            $is_eligible ? 'paid' : 'pending',
            $ip_address,
            $user_agent
        ]);
        
        $payout_awarded = false;
        
        if ($is_eligible && $payout_amount > 0) {
            $stmt = $pdo->prepare("
                UPDATE balances 
                SET task_earnings = task_earnings + ?,
                    total_balance = total_balance + ?
                WHERE user_id = ?
            ");
            $stmt->execute([$payout_amount, $payout_amount, $user_id]);
            
            $stmt = $pdo->prepare("
                INSERT INTO transactions 
                (user_id, transaction_type, amount, balance_type, description)
                VALUES (?, 'stream_ad_earning', ?, 'task', ?)
            ");
            $description = "Ad Stream: " . $track_title;
            $stmt->execute([$user_id, $payout_amount, $description]);
            
            $stmt = $pdo->prepare("UPDATE stream_tracks SET play_count = play_count + 1 WHERE track_id = ?");
            $stmt->execute([$track_id]);
            
            $payout_awarded = true;
        }
        
        $pdo->commit();
        
        echo json_encode([
            'success' => true,
            'payout_awarded' => $payout_awarded,
            'payout_amount' => $payout_amount,
            'completion_percentage' => round($completion_percentage, 2),
            'is_eligible' => $is_eligible,
            'message' => $payout_awarded 
                ? 'Congratulations! ₦' . number_format($payout_amount, 0) . ' has been added to your wallet.' 
                : ($is_premium 
                    ? 'Verification recorded but not eligible for payout' 
                    : 'Verification recorded. Upgrade to Premium to earn from ads!')
        ]);
        
    } catch (Exception $e) {
        $pdo->rollBack();
        throw $e;
    }
    
} catch (PDOException $e) {
    error_log("Stream Ads Record Error: " . $e->getMessage());
    echo json_encode([
        'success' => false,
        'message' => 'An error occurred while processing your verification'
    ]);
}
?>
