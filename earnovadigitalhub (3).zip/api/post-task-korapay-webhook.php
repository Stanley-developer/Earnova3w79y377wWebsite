<?php
/**
 * post-task-korapay-webhook.php
 * Korapay Webhook handler for Post Task payments
 * This endpoint receives webhook notifications from Korapay
 * Webhook endpoint: /api/post-task-korapay-webhook.php
 */

// Enable debug via environment
$ENV_DEBUG = getenv('KORAPAY_DEBUG');
$DEBUG = ($ENV_DEBUG === '1');

if ($DEBUG) {
    ini_set('display_errors', 1);
    ini_set('display_startup_errors', 1);
    error_reporting(E_ALL);
} else {
    ini_set('display_errors', 0);
    error_reporting(E_ALL & ~E_NOTICE);
}

header('Content-Type: application/json; charset=utf-8');

// Required includes
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/korapay.php';

// Helper: return JSON and exit
function json_exit($code, $payload) {
    http_response_code($code);
    echo json_encode($payload);
    exit;
}

// Log webhook for debugging
$webhook_log_file = __DIR__ . '/../logs/korapay_webhook.log';
$timestamp = date('Y-m-d H:i:s');

// Get raw POST body
$raw_body = file_get_contents('php://input');
error_log("KORAPAY_WEBHOOK_RECEIVED: " . $raw_body);
@file_put_contents($webhook_log_file, "[$timestamp] Raw Body: $raw_body\n", FILE_APPEND | LOCK_EX);

// Decode JSON payload
$payload = json_decode($raw_body, true);
if (!is_array($payload)) {
    error_log("KORAPAY_WEBHOOK_ERROR: Invalid JSON");
    @file_put_contents($webhook_log_file, "[$timestamp] Error: Invalid JSON\n", FILE_APPEND | LOCK_EX);
    json_exit(400, ['status' => false, 'message' => 'Invalid JSON']);
}

error_log("KORAPAY_WEBHOOK_DECODED: " . json_encode($payload));
@file_put_contents($webhook_log_file, "[$timestamp] Decoded: " . json_encode($payload) . "\n", FILE_APPEND | LOCK_EX);

// Extract webhook data
$reference = $payload['reference'] ?? null;
$status = $payload['status'] ?? null;
$amount = $payload['amount'] ?? null;
$metadata = $payload['metadata'] ?? [];
$customer = $payload['customer'] ?? [];

// Ensure database connection (needed before fetching stored payload)
try {
    $pdo = getDBConnection();
} catch (Exception $e) {
    error_log("KORAPAY_WEBHOOK_DB_ERROR: " . $e->getMessage());
    @file_put_contents($webhook_log_file, "[$timestamp] DB Error: " . $e->getMessage() . "\n", FILE_APPEND | LOCK_EX);
    json_exit(500, ['status' => false, 'message' => 'Database error']);
}

// Try to obtain the detailed task payload. We store it server-side (by reference)
// because Korapay limits metadata keys/size. First, check if payload was included
// inside metadata (older flows). If not, try to fetch from server table by reference.
$decoded_payload = [];
if (!empty($metadata['payload'])) {
    $decoded_payload = json_decode($metadata['payload'], true);
    if (!is_array($decoded_payload)) {
        $decoded_payload = [];
    }
}

// If no decoded payload found in metadata, attempt to fetch server-side stored payload
if (empty($decoded_payload)) {
    try {
        $stmt = $pdo->prepare("SELECT payload FROM korapay_post_task_payloads WHERE reference = ? LIMIT 1");
        $stmt->execute([$reference]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($row && !empty($row['payload'])) {
            $fetched = json_decode($row['payload'], true);
            if (is_array($fetched)) {
                $decoded_payload = $fetched;
            }
        }
    } catch (Exception $e) {
        error_log('KORAPAY_PAYLOAD_FETCH_ERROR: ' . $e->getMessage());
        @file_put_contents($webhook_log_file, "[$timestamp] Payload fetch error: " . $e->getMessage() . "\n", FILE_APPEND | LOCK_EX);
    }
}

// Merge so downstream code can use keys directly (decoded payload overrides generic keys)
$metadata = array_merge($metadata, $decoded_payload);

if (!$reference || !$status) {
    error_log("KORAPAY_WEBHOOK_ERROR: Missing reference or status");
    @file_put_contents($webhook_log_file, "[$timestamp] Error: Missing reference or status\n", FILE_APPEND | LOCK_EX);
    json_exit(400, ['status' => false, 'message' => 'Missing required fields']);
}

// Verify webhook signature (optional but recommended)
$korapay_signature = $_SERVER['HTTP_X_KORAPAY_SIGNATURE'] ?? null;
if ($korapay_signature) {
    $expected_signature = hash_hmac('sha256', $raw_body, KORAPAY_SECRET_KEY);
    if ($korapay_signature !== $expected_signature) {
        error_log("KORAPAY_WEBHOOK_ERROR: Invalid signature");
        @file_put_contents($webhook_log_file, "[$timestamp] Error: Invalid signature\n", FILE_APPEND | LOCK_EX);
        json_exit(401, ['status' => false, 'message' => 'Invalid signature']);
    }
}

// Handle webhook based on status
if ($status === 'success') {
    $payment_type = $metadata['payment_type'] ?? null;
    $user_id = intval($metadata['user_id'] ?? 0);
    
    error_log("KORAPAY_WEBHOOK_SUCCESS: ref=$reference, user=$user_id, type=$payment_type");
    @file_put_contents($webhook_log_file, "[$timestamp] Success - ref=$reference, user_id=$user_id, type=$payment_type\n", FILE_APPEND | LOCK_EX);
    
    // Validate payment type
    if ($payment_type !== 'post_task_deposit' || !$user_id) {
        error_log("KORAPAY_WEBHOOK_ERROR: Invalid payment_type or user_id");
        @file_put_contents($webhook_log_file, "[$timestamp] Error: Invalid payment_type or user_id\n", FILE_APPEND | LOCK_EX);
        json_exit(400, ['status' => false, 'message' => 'Invalid payment type or user']);
    }
    
    // Start transaction
    try {
        $pdo->beginTransaction();
        
        // Verify user exists
        $stmt = $pdo->prepare("SELECT id FROM users WHERE id = ? LIMIT 1");
        $stmt->execute([$user_id]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$user) {
            $pdo->rollBack();
            error_log("KORAPAY_WEBHOOK_ERROR: User not found - id=$user_id");
            @file_put_contents($webhook_log_file, "[$timestamp] Error: User not found (id=$user_id)\n", FILE_APPEND | LOCK_EX);
            json_exit(404, ['status' => false, 'message' => 'User not found']);
        }
        
        // Check if this payment has already been processed (prevent duplicate processing)
        $stmt = $pdo->prepare("SELECT id FROM korapay_post_task_payments WHERE reference = ? LIMIT 1");
        $stmt->execute([$reference]);
        $existing = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($existing) {
            $pdo->rollBack();
            error_log("KORAPAY_WEBHOOK_WARNING: Duplicate webhook - ref=$reference");
            @file_put_contents($webhook_log_file, "[$timestamp] Warning: Duplicate webhook (ref=$reference)\n", FILE_APPEND | LOCK_EX);
            json_exit(200, ['status' => true, 'message' => 'Already processed']);
        }
        
        // Record the payment in korapay_post_task_payments
        $stmt = $pdo->prepare("
            INSERT INTO korapay_post_task_payments 
            (user_id, reference, amount, status, metadata, created_at) 
            VALUES (?, ?, ?, ?, ?, NOW())
        ");
        $metadata_json = json_encode($metadata);
        $stmt->execute([$user_id, $reference, $amount, $status, $metadata_json]);
        $payment_id = $pdo->lastInsertId();
        
        error_log("KORAPAY_WEBHOOK_RECORDED: payment_id=$payment_id");
        @file_put_contents($webhook_log_file, "[$timestamp] Payment recorded - payment_id=$payment_id\n", FILE_APPEND | LOCK_EX);
        
        // Add the deposit amount to user's total balance only (do not credit referral earnings)
        $stmt = $pdo->prepare("
            UPDATE balances 
            SET total_balance = total_balance + ?
            WHERE user_id = ?
        ");
        $stmt->execute([$amount, $user_id]);

        error_log("KORAPAY_WEBHOOK_BALANCE_UPDATED: user=$user_id, total_added=$amount");
        @file_put_contents($webhook_log_file, "[$timestamp] Total balance updated - user_id=$user_id, amount=$amount\n", FILE_APPEND | LOCK_EX);
        
        // Record the transaction
        $stmt = $pdo->prepare("
            INSERT INTO transactions 
            (user_id, transaction_type, amount, balance_type, description, reference_id, created_at) 
            VALUES (?, ?, ?, ?, ?, ?, NOW())
        ");
        $desc = "Korapay Deposit for Post Task - Ref: " . $reference;
        $stmt->execute([$user_id, 'korapay_deposit_post_task', $amount, 'total_balance', $desc, $reference]);
        
        error_log("KORAPAY_WEBHOOK_TRANSACTION_RECORDED: user=$user_id");
        @file_put_contents($webhook_log_file, "[$timestamp] Transaction recorded\n", FILE_APPEND | LOCK_EX);
        
        // Attempt to auto-create the task if metadata contains task details (idempotent)
        try {
            if (!empty($metadata['title']) && !empty($metadata['task_url'])) {
                // Fetch poster username/fullname
                $stmt = $pdo->prepare("SELECT username, fullname FROM users WHERE id = ? LIMIT 1");
                $stmt->execute([$user_id]);
                $poster = $stmt->fetch(PDO::FETCH_ASSOC);

                $task_title = trim($metadata['title']);
                $task_desc = trim($metadata['description'] ?? '');
                $task_platform = trim($metadata['task_platform'] ?? ($metadata['platform'] ?? ''));
                $task_url = trim($metadata['task_url']);
                $participants = max(10, intval($metadata['participants'] ?? 10));
                $total_cost_val = floatval($metadata['total_cost'] ?? $amount);

                // Check for existing similar task posted recently to avoid duplicates
                $chk = $pdo->prepare("SELECT id FROM tasks WHERE task_url = ? AND user_id = ? AND created_at >= DATE_SUB(NOW(), INTERVAL 10 MINUTE) LIMIT 1");
                $chk->execute([$task_url, $user_id]);
                $exists_task = $chk->fetch(PDO::FETCH_ASSOC);

                if (!$exists_task) {
                    $reward_total = $total_cost_val * 0.06;
                    $reward_per_user = ($participants > 0) ? ($reward_total / $participants) : 0;

                    $stmt = $pdo->prepare("INSERT INTO tasks (title, description, task_type, platform, reward_amount, task_url, participants_count, is_active, is_premium_only, created_at, user_id, posted_by_username, posted_by_fullname) VALUES (?, ?, 'social_media', ?, ?, ?, ?, 1, 0, NOW(), ?, ?, ?)");
                    $stmt->execute([$task_title, $task_desc, $task_platform, $reward_per_user, $task_url, $participants, $user_id, $poster['username'] ?? '', $poster['fullname'] ?? '']);
                    $task_id = $pdo->lastInsertId();

                    // Create advertisement record
                    $stmt = $pdo->prepare("INSERT INTO advertisements (user_id, title, description, ad_type, target_url, budget, cost_per_action, total_actions, remaining_budget, is_active, created_at) VALUES (?, ?, ?, 'social_media', ?, ?, ?, 0, ?, 1, NOW())");
                    $stmt->execute([$user_id, $task_title, $task_desc, $task_url, $total_cost_val, $reward_per_user, $total_cost_val]);

                    // Handle upline commission (5% to senior referrer)
                    $stmt = $pdo->prepare("SELECT referred_by FROM users WHERE id = ?");
                    $stmt->execute([$user_id]);
                    $upline_result = $stmt->fetch(PDO::FETCH_ASSOC);
                    if ($upline_result && !empty($upline_result['referred_by'])) {
                        $upline_id = $upline_result['referred_by'];
                        $stmt = $pdo->prepare("SELECT u.advertiser_plan, b.referral_earnings FROM users u LEFT JOIN balances b ON u.id = b.user_id WHERE u.id = ?");
                        $stmt->execute([$upline_id]);
                        $upline_data = $stmt->fetch(PDO::FETCH_ASSOC);
                        if ($upline_data && $upline_data['advertiser_plan'] === 'senior') {
                            $upline_reward = ($total_cost_val * 0.05);
                            $stmt = $pdo->prepare("UPDATE balances SET referral_earnings = referral_earnings + ?, total_balance = total_balance + ? WHERE user_id = ?");
                            $stmt->execute([$upline_reward, $upline_reward, $upline_id]);

                            $stmt = $pdo->prepare("INSERT INTO transactions (user_id, transaction_type, amount, balance_type, description, reference_id, created_at) VALUES (?, ?, ?, ?, ?, ?, NOW())");
                            $reward_description = "5% Advertisement Commission - Downline task posting (₦{$total_cost_val}) on {$task_platform}";
                            $stmt->execute([$upline_id, 'advertise_commission', $upline_reward, 'referral_earnings', $reward_description, "UPLINE-AD-COMM-{$task_id}"]);

                            $commission_percentage = 5.00;
                            $stmt2 = $pdo->prepare("INSERT INTO ad_invite_commissions (referrer_id, referred_user_id, ad_purchase_amount, commission_amount, commission_percentage, created_at) VALUES (?, ?, ?, ?, ?, NOW())");
                            $stmt2->execute([$upline_id, $user_id, $total_cost_val, $upline_reward, $commission_percentage]);
                        }
                    }
                }
            }
        } catch (Exception $e) {
            error_log('Auto-create task during Korapay webhook failed: ' . $e->getMessage());
            @file_put_contents($webhook_log_file, "[$timestamp] Auto-create task error: " . $e->getMessage() . "\n", FILE_APPEND | LOCK_EX);
        }
        
        // Commit transaction
        $pdo->commit();
        
        error_log("KORAPAY_WEBHOOK_COMPLETED: ref=$reference");
        @file_put_contents($webhook_log_file, "[$timestamp] Webhook completed successfully\n\n", FILE_APPEND | LOCK_EX);
        
        json_exit(200, [
            'status' => true,
            'message' => 'Payment processed successfully',
            'payment_id' => $payment_id,
            'reference' => $reference
        ]);
        
    } catch (Exception $e) {
        $pdo->rollBack();
        error_log("KORAPAY_WEBHOOK_EXCEPTION: " . $e->getMessage());
        @file_put_contents($webhook_log_file, "[$timestamp] Exception: " . $e->getMessage() . "\n", FILE_APPEND | LOCK_EX);
        json_exit(500, ['status' => false, 'message' => 'Processing error']);
    }
    
} else if ($status === 'pending') {
    // Payment is still pending
    error_log("KORAPAY_WEBHOOK_PENDING: ref=$reference");
    @file_put_contents($webhook_log_file, "[$timestamp] Pending - ref=$reference\n", FILE_APPEND | LOCK_EX);
    json_exit(200, ['status' => true, 'message' => 'Payment pending']);
    
} else {
    // Payment failed
    error_log("KORAPAY_WEBHOOK_FAILED: ref=$reference, status=$status");
    @file_put_contents($webhook_log_file, "[$timestamp] Failed - ref=$reference, status=$status\n", FILE_APPEND | LOCK_EX);
    
    $user_id = intval($metadata['user_id'] ?? 0);
    if ($user_id) {
        try {
            // Record failed payment attempt
            $stmt = $pdo->prepare("
                INSERT INTO korapay_post_task_payments 
                (user_id, reference, amount, status, metadata, created_at) 
                VALUES (?, ?, ?, ?, ?, NOW())
            ");
            $metadata_json = json_encode($metadata);
            $stmt->execute([$user_id, $reference, $amount, $status, $metadata_json]);
        } catch (Exception $e) {
            error_log("KORAPAY_WEBHOOK_FAILED_RECORD_ERROR: " . $e->getMessage());
        }
    }
    
    json_exit(200, ['status' => false, 'message' => 'Payment failed']);
}
?>
