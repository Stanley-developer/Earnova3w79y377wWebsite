<?php
require_once '../config/database.php';
require_once '../includes/session.php';

header('Content-Type: application/json');

try {
    $pdo = getDBConnection();
    
    // Get top streamers (top 10)
    $stmt = $pdo->prepare("
        SELECT 
            u.id,
            u.username,
            u.full_name,
            u.profile_picture,
            COUNT(se.id) as total_streams,
            SUM(se.payout_amount) as total_earned
        FROM users u
        INNER JOIN stream_earnings se ON u.id = se.user_id
        WHERE se.is_eligible = 1 AND se.payout_status = 'paid'
        GROUP BY u.id
        ORDER BY total_earned DESC, total_streams DESC
        LIMIT 10
    ");
    $stmt->execute();
    $leaderboard = $stmt->fetchAll();
    
    echo json_encode([
        'success' => true,
        'leaderboard' => $leaderboard
    ]);
    
} catch (PDOException $e) {
    error_log("Stream Leaderboard Error: " . $e->getMessage());
    echo json_encode([
        'success' => false,
        'message' => 'Unable to load leaderboard',
        'leaderboard' => []
    ]);
}
?>
