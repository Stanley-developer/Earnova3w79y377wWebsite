<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('log_errors', 1);

require_once '../config/database.php';
require_once '../includes/session.php';

header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit;
}

$user_id = $_SESSION['user_id'];

try {
    $pdo = getDBConnection();
    
    // Get POST data
    $data = json_decode(file_get_contents('php://input'), true);
    $distance = intval($data['distance'] ?? 0);
    $earnings = floatval($data['earnings'] ?? 0);
    
    error_log("[TEMPLE-RUN] User: $user_id, Distance: $distance, Earnings: $earnings");
    
    // Validate inputs
    if ($distance < 0 || $earnings < 0) {
        echo json_encode(['success' => false, 'message' => 'Invalid parameters']);
        exit;
    }
    
    // Get user data
    $stmt = $pdo->prepare("SELECT u.*, b.game_earnings, b.total_balance FROM users u LEFT JOIN balances b ON u.id = b.user_id WHERE u.id = ?");
    $stmt->execute([$user_id]);
    $user = $stmt->fetch();
    
    if (!$user) {
        echo json_encode(['success' => false, 'message' => 'User not found']);
        exit;
    }
    
    // Check premium membership
    if ($user['membership_type'] !== 'premium') {
        echo json_encode(['success' => false, 'message' => 'Premium membership required']);
        exit;
    }
    
    // Calculate rewards (1 Naira per 10 meters, plus coin bonuses)
    $distance_reward = ($distance / 10) * 10; // Round to nearest 10
    $total_reward = $distance_reward + $earnings; // Earnings from coins
    
    // Cap rewards to prevent abuse
    $max_reward = 50000; // Max 50,000 Naira per run
    if ($total_reward > $max_reward) {
        $total_reward = $max_reward;
    }
    
    if ($total_reward > 0) {
        // Update balance
        $stmt = $pdo->prepare("UPDATE balances SET game_earnings = game_earnings + ?, total_balance = total_balance + ? WHERE user_id = ?");
        $stmt->execute([$total_reward, $total_reward, $user_id]);
        
        error_log("[TEMPLE-RUN] Reward added: $total_reward");
    }
    
    // Record in transaction history
    $stmt = $pdo->prepare("INSERT INTO transactions (user_id, transaction_type, amount, balance_type, description, reference_id) VALUES (?, 'game_play', ?, 'game', ?, ?)");
    $description = "Temple Run - Distance: " . $distance . "m | Coins: ₦" . number_format($earnings, 2) . " | Total Reward: ₦" . number_format($total_reward, 2);
    $reference_id = 'TEMPLERUN_' . time() . '_' . $user_id;
    $stmt->execute([$user_id, $total_reward, $description, $reference_id]);
    
    // Get updated balance
    $stmt = $pdo->prepare("SELECT game_earnings, total_balance FROM balances WHERE user_id = ?");
    $stmt->execute([$user_id]);
    $balance = $stmt->fetch();
    
    error_log("[TEMPLE-RUN] Success: Distance=$distance, Earnings=$earnings, Reward=$total_reward, GameBalance=" . $balance['game_earnings']);
    
    echo json_encode([
        'success' => true,
        'distance' => $distance,
        'earnings' => floatval($earnings),
        'reward' => floatval($total_reward),
        'game_earnings' => floatval($balance['game_earnings']),
        'total_balance' => floatval($balance['total_balance'])
    ]);
    
} catch (PDOException $e) {
    error_log("[TEMPLE-RUN] DB Error: " . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'Database Error']);
} catch (Exception $e) {
    error_log("[TEMPLE-RUN] Exception: " . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'Error: ' . $e->getMessage()]);
}
?>
