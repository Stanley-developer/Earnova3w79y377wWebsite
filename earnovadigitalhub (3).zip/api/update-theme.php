<?php
session_start();
require_once '../config/database.php';
require_once '../includes/connect.php';

header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'Not authenticated']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
    exit;
}

$user_id = $_SESSION['user_id'];
$theme = $_POST['theme'] ?? 'dark';

// Validate theme
if (!in_array($theme, ['dark', 'light'])) {
    echo json_encode(['success' => false, 'message' => 'Invalid theme']);
    exit;
}

// Update user's theme preference
$stmt = $conn->prepare("UPDATE users SET theme_preference = ? WHERE id = ?");
$stmt->bind_param("si", $theme, $user_id);

if ($stmt->execute()) {
    $_SESSION['theme'] = $theme;
    echo json_encode(['success' => true, 'message' => 'Theme updated successfully']);
} else {
    echo json_encode(['success' => false, 'message' => 'Failed to update theme']);
}

$stmt->close();
?>
