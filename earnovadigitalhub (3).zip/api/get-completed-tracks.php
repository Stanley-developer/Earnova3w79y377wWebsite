<?php
require_once '../config/database.php';
require_once '../includes/session.php';

header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'tracks' => []]);
    exit;
}

$user_id = $_SESSION['user_id'];

try {
    $pdo = getDBConnection();
    
    $stmt = $pdo->prepare("
        SELECT DISTINCT track_id 
        FROM stream_earnings 
        WHERE user_id = ? AND is_eligible = 1
    ");
    $stmt->execute([$user_id]);
    $completed = $stmt->fetchAll(PDO::FETCH_COLUMN);
    
    echo json_encode(['success' => true, 'completed_tracks' => $completed]);
    
} catch (PDOException $e) {
    echo json_encode(['success' => false, 'completed_tracks' => []]);
}
?>
