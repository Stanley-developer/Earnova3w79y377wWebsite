<?php
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../includes/auth.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonResponse(false, 'Invalid request method');
}

// Get POST data
$data = json_decode(file_get_contents('php://input'), true);

// Validate required fields
$requiredFields = ['fullname', 'email', 'username', 'password', 'confirmPassword'];
foreach ($requiredFields as $field) {
    if (empty($data[$field])) {
        jsonResponse(false, 'All fields are required');
    }
}

// Sanitize inputs
$fullname = sanitizeInput($data['fullname']);
$email = sanitizeInput($data['email']);
$username = sanitizeInput($data['username']);
$password = $data['password'];
$confirmPassword = $data['confirmPassword'];
$referralCode = isset($data['referralCode']) ? sanitizeInput($data['referralCode']) : null;

// Validate password match
if ($password !== $confirmPassword) {
    jsonResponse(false, 'Passwords do not match');
}

// Register user
$auth = new Auth();
$result = $auth->register($username, $email, $password, $fullname, $referralCode);

jsonResponse($result['success'], $result['message'], $result);
?>
