<?php
require_once '../config/database.php';
require_once '../includes/session.php';

header('Content-Type: application/json');

try {
    $pdo = getDBConnection();
    
    // Fetch top 10 players by total profit
    $stmt = $pdo->prepare("
        SELECT 
            u.id,
            u.username,
            u.full_name,
            u.profile_picture,
            s.total_games,
            s.total_wins,
            s.total_profit,
            s.biggest_win
        FROM mystery_box_stats s
        JOIN users u ON s.user_id = u.id
        ORDER BY s.total_profit DESC
        LIMIT 10
    ");
    $stmt->execute();
    $leaderboard = $stmt->fetchAll();
    
    echo json_encode([
        'success' => true,
        'leaderboard' => $leaderboard
    ]);
    
} catch (PDOException $e) {
    error_log("Mystery Box Leaderboard Error: " . $e->getMessage());
    echo json_encode([
        'success' => false,
        'message' => 'Unable to load leaderboard'
    ]);
}
?>
