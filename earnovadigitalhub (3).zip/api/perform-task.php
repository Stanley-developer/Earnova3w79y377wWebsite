<?php
// Separate API endpoint for perform-task AJAX requests
// This prevents HTML from being mixed with JSON responses
header('Content-Type: application/json; charset=utf-8');
ob_start();

require_once '../config/database.php';
require_once '../includes/session.php';
require_once '../includes/connect.php';
require_once '../vendor/autoload.php';

use libphonenumber\PhoneNumberUtil;
use libphonenumber\PhoneNumberFormat;

// Require authentication
requireLogin();
checkSessionTimeout();

// Get current user data
$user = getCurrentUser();
$user_id = $user['id'];

// Clear output buffer and ensure JSON header
ob_end_clean();

try {
    $pdo = getDBConnection();
    
    // Fetch user details with balances
    $stmt = $pdo->prepare("
        SELECT u.*, b.total_balance, b.task_earnings, b.referral_earnings
        FROM users u
        LEFT JOIN balances b ON u.id = b.user_id
        WHERE u.id = ?
    ");
    $stmt->execute([$user_id]);
    $user_data = $stmt->fetch();
    
    if (!$user_data) {
        http_response_code(401);
        echo json_encode(['success' => false, 'message' => 'User not found']);
        exit;
    }
    
    $action = $_POST['action'] ?? '';

    if ($action === 'agree_terms') {
        $_SESSION['ts_agreed_' . $user_id] = true;
        echo json_encode(['success' => true, 'message' => 'Task Instructions agreed']);
        exit;
    }
    
    if ($action === 'start_task') {
        if ($user_data['membership_type'] === 'free') {
            echo json_encode(['success' => false, 'message' => 'Please upgrade to Premium to perform tasks', 'show_premium_popup' => true]);
            exit;
        }
        
        $task_id = intval($_POST['task_id'] ?? 0);
        
        // Get task details
        $stmt = $pdo->prepare("SELECT * FROM tasks WHERE id = ? AND is_active = 1");
        $stmt->execute([$task_id]);
        $task = $stmt->fetch();
        
        if (!$task) {
            echo json_encode(['success' => false, 'message' => 'Task not found']);
            exit;
        }
        
        // Check if user already has this task in progress
        $stmt = $pdo->prepare("SELECT * FROM user_tasks WHERE user_id = ? AND task_id = ? AND status IN ('pending', 'in_progress')");
        $stmt->execute([$user_id, $task_id]);
        $existing = $stmt->fetch();
        
        if ($existing) {
            $_SESSION['active_task_' . $user_id] = $task_id;
            $_SESSION['active_user_task_id_' . $user_id] = $existing['id'];
            $_SESSION['active_task_platform_' . $user_id] = $task['platform'] ?? null;
            
            echo json_encode([
                'success' => true,
                'user_task_id' => $existing['id'],
                'task_url' => $task['task_url'],
                'start_time' => time(),
                'is_resumed' => true
            ]);
            exit;
        }
        
        $stmt = $pdo->prepare("SELECT * FROM user_tasks WHERE user_id = ? AND task_id = ? AND status = 'completed'");
        $stmt->execute([$user_id, $task_id]);
        $completed = $stmt->fetch();
        
        if ($completed) {
            echo json_encode(['success' => false, 'message' => 'You have already completed this task']);
            exit;
        }
        
        // Create task record with start time
        $stmt = $pdo->prepare("INSERT INTO user_tasks (user_id, task_id, status, created_at) VALUES (?, ?, 'in_progress', NOW())");
        
        if (!$stmt->execute([$user_id, $task_id])) {
            $errorInfo = $stmt->errorInfo();
            error_log("Database error starting task: " . print_r($errorInfo, true));
            echo json_encode(['success' => false, 'message' => 'Error starting task']);
            exit;
        }
        
        $user_task_id = $pdo->lastInsertId();
        
        $_SESSION['active_task_' . $user_id] = $task_id;
        $_SESSION['active_user_task_id_' . $user_id] = $user_task_id;
        $_SESSION['active_task_platform_' . $user_id] = $task['platform'] ?? null;
        
        echo json_encode([
            'success' => true,
            'user_task_id' => $user_task_id,
            'task_url' => $task['task_url'],
            'start_time' => time(),
            'is_resumed' => false
        ]);
        exit;
        
    } elseif ($action === 'submit_verification') {
        $user_task_id = intval($_POST['user_task_id'] ?? 0);
        $start_time = intval($_POST['start_time'] ?? 0);
        $profile_link = $_POST['profile_link'] ?? '';
        $platform = $_POST['platform'] ?? '';
        
        if (!$user_task_id) {
            error_log("ERROR: Missing user_task_id in submit_verification for user: $user_id");
            echo json_encode(['success' => false, 'message' => 'Session expired. Please start the task again.']);
            exit;
        }
        
        // Get user task
        $stmt = $pdo->prepare("
            SELECT ut.*, t.task_type, t.platform, t.title, t.posted_by_admin, t.member_reward, t.non_member_reward, t.reward_amount
            FROM user_tasks ut
            JOIN tasks t ON ut.task_id = t.id
            WHERE ut.id = ? AND ut.user_id = ?
        ");
        $stmt->execute([$user_task_id, $user_id]);
        $user_task = $stmt->fetch();
        
        if (!$user_task) {
            error_log("ERROR: Task not found for user_task_id: $user_task_id, user_id: $user_id");
            echo json_encode(['success' => false, 'message' => 'Task not found. Please try starting the task again.']);
            exit;
        }
        
        if (empty($profile_link)) {
            error_log("ERROR: Empty profile link provided");
            echo json_encode(['success' => false, 'message' => 'Please provide a profile link or phone number']);
            exit;
        }
        
        $platform = strtolower($platform ?: ($user_task['platform'] ?? $user_task['task_type']));
        error_log("Detected platform: $platform");
        
        if ($platform === 'whatsapp' || $platform === 'telegram') {
            $isPhoneNumber = preg_match('/^\+?[0-9\s\-()]+$/', $profile_link);
            
            if ($isPhoneNumber) {
                // Validate as Nigerian phone number
                $validation = validateNigerianPhoneNumber($profile_link);
                
                if (!$validation['valid']) {
                    error_log("ERROR: Invalid Nigerian phone number: $profile_link");
                    echo json_encode([
                        'success' => false,
                        'message' => 'Invalid Nigerian phone number. Please enter a valid ' . ucfirst($platform) . ' number (e.g., +234 or 0).'
                    ]);
                    exit;
                }
                
                $cleanPhone = $validation['number'];
                error_log("Valid Nigerian phone number: $cleanPhone");
                $profile_link = $cleanPhone;
            } else {
                // It's a URL, validate it
                if (!filter_var($profile_link, FILTER_VALIDATE_URL)) {
                    error_log("ERROR: Invalid " . ucfirst($platform) . " URL: $profile_link");
                    echo json_encode(['success' => false, 'message' => 'Please provide a valid ' . ucfirst($platform) . ' link or phone number']);
                    exit;
                }
            }
        } else {
            if (!filter_var($profile_link, FILTER_VALIDATE_URL)) {
                error_log("ERROR: Invalid URL for platform $platform: $profile_link");
                echo json_encode(['success' => false, 'message' => 'Please provide a valid profile link (must start with http:// or https://)']);
                exit;
            }
        }
        
        $platformDomains = [
            'tiktok' => ['tiktok.com', 'vm.tiktok.com'],
            'instagram' => ['instagram.com', 'instagr.am'],
            'twitter' => ['twitter.com', 'x.com', 't.co'],
            'facebook' => ['facebook.com', 'fb.com', 'fb.me', 'm.facebook.com'],
            'linkedin' => ['linkedin.com', 'lnkd.in'],
            'snapchat' => ['snapchat.com', 'snap.com'],
            'youtube' => ['youtube.com', 'youtu.be', 'm.youtube.com'],
            'pinterest' => ['pinterest.com', 'pin.it'],
            'reddit' => ['reddit.com', 'redd.it'],
            'discord' => ['discord.com', 'discord.gg', 'discordapp.com'],
            'twitch' => ['twitch.tv', 'twitch.com'],
            'telegram' => ['telegram.org', 't.me', 'telegram.me'],
            'whatsapp' => ['whatsapp.com', 'wa.me', 'chat.whatsapp.com', 'api.whatsapp.com'],
            'playstore' => ['play.google.com'],
            'appstore' => ['apps.apple.com', 'itunes.apple.com'],
            'audiomack' => ['audiomack.com'],
            'boomplay' => ['boomplay.com'],
            'spotify' => ['spotify.com', 'open.spotify.com', 'spoti.fi'],
            'applemusic' => ['music.apple.com', 'itunes.apple.com'],
            'soundcloud' => ['soundcloud.com', 'on.soundcloud.com']
        ];
        
        if (!($platform === 'whatsapp' && preg_match('/^\+?[0-9\s\-()]+$/', $profile_link)) && !($platform === 'telegram' && preg_match('/^\+?[0-9\s\-()]+$/', $profile_link))) {
            $parsedUrl = parse_url($profile_link);
            $host = strtolower($parsedUrl['host'] ?? '');
            $path = $parsedUrl['path'] ?? '/';
            $host = str_replace('www.', '', $host);
            
            $baseSocialUrls = [
                'tiktok.com', 'instagram.com', 'twitter.com', 'x.com', 'facebook.com',
                'linkedin.com', 'snapchat.com', 'youtube.com', 'pinterest.com',
                'reddit.com', 'discord.com', 'twitch.tv', 'telegram.org', 'whatsapp.com',
                'audiomack.com', 'boomplay.com', 'spotify.com', 'music.apple.com', 'soundcloud.com'
            ];
            
            foreach ($baseSocialUrls as $baseUrl) {
                if (stripos($host, $baseUrl) !== false && ($path === '/' || $path === '')) {
                    error_log("ERROR: Base URL detected (no profile): $profile_link");
                    echo json_encode(['success' => false, 'message' => 'Please provide a link to your profile.']);
                    exit;
                }
            }
            
            $link_valid = false;
            
            if (isset($platformDomains[$platform])) {
                foreach ($platformDomains[$platform] as $domain) {
                    if (stripos($host, $domain) !== false) {
                        $link_valid = true;
                        break;
                    }
                }
            }
            
            if (!$link_valid) {
                $platformName = ucfirst($platform);
                if ($platform === 'applemusic') $platformName = 'Apple Music';
                if ($platform === 'playstore') $platformName = 'Google Play Store';
                if ($platform === 'appstore') $platformName = 'Apple App Store';
                echo json_encode(['success' => false, 'message' => "Profile Link must be from $platformName."]);
                exit;
            }
        }
        
        $earning = getTaskReward($user_task, $user_data);
        error_log("Calculated earning: ₦$earning");
        
        $final_status = 'completed';
        
        $stmt = $pdo->prepare("
            UPDATE user_tasks 
            SET proof_url = ?, status = ?, completed_at = NOW() 
            WHERE id = ?
        ");
        $updateResult = $stmt->execute([$profile_link, $final_status, $user_task_id]);
        
        if (!$updateResult) {
            $errorInfo = $stmt->errorInfo();
            error_log("ERROR: Failed to update user_tasks: " . print_r($errorInfo, true));
            echo json_encode(['success' => false, 'message' => 'Database error updating task']);
            exit;
        }
        
        $pdo->beginTransaction();
        error_log("Transaction started");
        
        try {
            // Update balance
            $stmt = $pdo->prepare("
                UPDATE balances 
                SET task_earnings = task_earnings + ?, total_balance = total_balance + ? 
                WHERE user_id = ?
            ");
            $balanceResult = $stmt->execute([$earning, $earning, $user_id]);
            
            if (!$balanceResult) {
                $errorInfo = $stmt->errorInfo();
                error_log("ERROR: Failed to update balances: " . print_r($errorInfo, true));
                throw new Exception('Failed to update balance');
            }
            
            // Record transaction
            $stmt = $pdo->prepare("
                INSERT INTO transactions 
                (user_id, transaction_type, amount, balance_type, description, reference_id, created_at) 
                VALUES (?, 'task_reward', ?, 'activity_earnings', ?, ?, NOW())
            ");
            $description = "Completed task: {$user_task['title']}";
            $transactionResult = $stmt->execute([$user_id, $earning, $description, "TASK-{$user_task_id}"]);
            
            if (!$transactionResult) {
                $errorInfo = $stmt->errorInfo();
                error_log("ERROR: Failed to insert transaction: " . print_r($errorInfo, true));
                throw new Exception('Failed to record transaction');
            }
            
            // Mark task as completed
            $stmt = $pdo->prepare("INSERT IGNORE INTO user_completed_tasks (user_id, task_id) VALUES (?, ?)");
            $completedResult = $stmt->execute([$user_id, $user_task['task_id']]);
            
            if (!$completedResult) {
                $errorInfo = $stmt->errorInfo();
                error_log("WARNING: Failed to mark task as completed: " . print_r($errorInfo, true));
            }
            
            // Update fake task count
            $stmt = $pdo->prepare("SELECT setting_value FROM task_display_settings WHERE setting_key = 'fake_total_tasks'");
            $stmt->execute();
            $current_fake = $stmt->fetch();
            $fake_before = $current_fake ? intval($current_fake['setting_value']) : 50;
            $fake_after = max(0, $fake_before - 1);
            
            $stmt = $pdo->prepare("SELECT COUNT(*) FROM tasks WHERE is_active = 1");
            $stmt->execute();
            $real_before = $stmt->fetchColumn();
            $real_after = $real_before;
            
            $stmt = $pdo->prepare("UPDATE task_display_settings SET setting_value = ? WHERE setting_key = 'fake_total_tasks'");
            $stmt->execute([$fake_after]);
            
            $stmt = $pdo->prepare("
                INSERT INTO task_count_sync_log 
                (action_type, task_id, user_id, fake_count_before, fake_count_after, real_count_before, real_count_after) 
                VALUES ('task_completed', ?, ?, ?, ?, ?, ?)
            ");
            $stmt->execute([$user_task['task_id'], $user_id, $fake_before, $fake_after, $real_before, $real_after]);
            
            $pdo->commit();
            
            // Clear active task session
            unset($_SESSION['active_task_' . $user_id]);
            unset($_SESSION['active_user_task_id_' . $user_id]);
            unset($_SESSION['active_task_platform_' . $user_id]);
            
            echo json_encode([
                'success' => true,
                'approved' => true,
                'reward' => $earning,
                'message' => 'Task completed! ₦' . number_format($earning, 2) . ' has been credited to your account.'
            ]);
            exit;
            
        } catch (Exception $e) {
            $pdo->rollBack();
            error_log("ERROR: Transaction rolled back - " . $e->getMessage());
            echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
            exit;
        }
        
    } elseif ($action === 'clear_task_session') {
        unset($_SESSION['active_task_' . $user_id]);
        unset($_SESSION['active_user_task_id_' . $user_id]);
        unset($_SESSION['active_task_platform_' . $user_id]);
        echo json_encode(['success' => true, 'message' => 'Task session cleared.']);
        exit;
    }
    
    echo json_encode(['success' => false, 'message' => 'Invalid action']);
    exit;
    
} catch (Exception $e) {
    error_log("API Error: " . $e->getMessage());
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Server error']);
    exit;
}

// Helper functions
function validateNigerianPhoneNumber($phoneNumber) {
    try {
        $phoneUtil = PhoneNumberUtil::getInstance();
        $parsed = $phoneUtil->parse($phoneNumber, 'NG');
        $isValid = $phoneUtil->isValidNumber($parsed);
        
        if ($isValid) {
            $formatted = $phoneUtil->format($parsed, PhoneNumberFormat::INTERNATIONAL);
            return [
                'valid' => true,
                'formatted' => $formatted,
                'number' => $phoneUtil->format($parsed, PhoneNumberFormat::E164)
            ];
        }
        return ['valid' => false];
    } catch (Exception $e) {
        error_log("Phone validation error: " . $e->getMessage());
        return ['valid' => false];
    }
}

function getTaskReward($task, $user_data) {
    $is_member = in_array($user_data['membership_type'], ['premium', 'senior']);
    
    if ($task['posted_by_admin'] == 1) {
        $reward = $is_member ? floatval($task['member_reward']) : floatval($task['non_member_reward']);
        if ($reward <= 0) {
            $reward = 50;
        }
        return max($reward, 50);
    } else {
        $base_reward = floatval($task['reward_amount'] ?? 50);
        if ($base_reward <= 0) {
            $base_reward = 50;
        }
        $final_reward = $is_member ? ($base_reward * 1.20) : $base_reward;
        return max($final_reward, 50);
    }
}
?>
