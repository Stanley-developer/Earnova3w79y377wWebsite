<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('log_errors', 1);

require_once '../config/database.php';
require_once '../includes/session.php';

header('Content-Type: application/json');

// Require authentication
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit;
}

$user_id = $_SESSION['user_id'];

try {
    $pdo = getDBConnection();
    
    // Get POST data
    $data = json_decode(file_get_contents('php://input'), true);
    $bet_amount = floatval($data['bet_amount'] ?? 0);
    $selected_numbers = $data['selected_numbers'] ?? [];
    
    // Validate bet amount
    if ($bet_amount < 1000) {
        echo json_encode(['success' => false, 'message' => 'Minimum bet amount is ₦1,000']);
        exit;
    }
    
    // Validate selected numbers
    if (count($selected_numbers) !== 10) {
        echo json_encode(['success' => false, 'message' => 'You must select exactly 10 numbers']);
        exit;
    }
    
    // Get user data
    $stmt = $pdo->prepare("
        SELECT u.*, b.referral_earnings, b.game_earnings, b.total_balance, b.task_earnings
        FROM users u
        LEFT JOIN balances b ON u.id = b.user_id
        WHERE u.id = ?
    ");
    $stmt->execute([$user_id]);
    $user = $stmt->fetch();
    
    if (!$user) {
        echo json_encode(['success' => false, 'message' => 'User not found']);
        exit;
    }
    
    if ($user['membership_type'] !== 'premium') {
        echo json_encode(['success' => false, 'message' => 'Premium membership required', 'upgrade_required' => true]);
        exit;
    }
    
    if ($user['game_earnings'] < $bet_amount) {
        echo json_encode(['success' => false, 'message' => 'Insufficient balance. Please deposit to play.', 'insufficient_balance' => true]);
        exit;
    }
    
    $stmt = $pdo->prepare("
        UPDATE balances 
        SET game_earnings = game_earnings - ?, 
            total_balance = total_balance - ? 
        WHERE user_id = ?
    ");
    $stmt->execute([$bet_amount, $bet_amount, $user_id]);
    
    $all_numbers = range(1, 80);
    shuffle($all_numbers);
    $drawn_numbers = array_slice($all_numbers, 0, 10);
    
    // Calculate matches
    $matched_numbers = array_intersect($selected_numbers, $drawn_numbers);
    $matches = count($matched_numbers);
    
    $rand = mt_rand(1, 100);
    $multiplier = 0;
    
    $multiplier_table = [
        9 => 5.0,
        8 => 4.5,
        7 => 4.0,
        6 => 3.0,
        5 => 2.0,
        4 => 1.5,
        3 => 1.0
    ];
    
    if ($rand <= 60) {
        // 60% chance to win - ensure at least 3 matches
        if ($matches < 3) {
            // Force a win by adjusting matches
            $matches = array_rand(array_flip([3, 4, 5, 6, 7]));
            
            // Recalculate matched numbers for display
            $matched_numbers = array_slice($selected_numbers, 0, $matches);
        }
        
        $multiplier = $multiplier_table[$matches] ?? 1.0;
    } else {
        // 40% chance to lose - ensure less than 3 matches
        if ($matches >= 3) {
            $matches = mt_rand(0, 2);
            $matched_numbers = array_slice($selected_numbers, 0, $matches);
        }
        $multiplier = 0;
    }
    
    $win_amount = $bet_amount * $multiplier;
    
    if ($win_amount > 0) {
        $stmt = $pdo->prepare("
            UPDATE balances 
            SET game_earnings = game_earnings + ?, 
                total_balance = total_balance + ? 
            WHERE user_id = ?
        ");
        $stmt->execute([$win_amount, $win_amount, $user_id]);
    }
    
    $stmt = $pdo->prepare("
        INSERT INTO transactions (user_id, transaction_type, amount, balance_type, description, reference_id)
        VALUES (?, 'game_play', ?, 'game', ?, ?)
    ");
    $description = "Keno Game - Bet: ₦" . number_format($bet_amount, 2) . " | Matches: " . $matches . " | Win: ₦" . number_format($win_amount, 2);
    $reference_id = 'KENO_' . time() . '_' . $user_id;
    $stmt->execute([$user_id, $win_amount, $description, $reference_id]);
    
    // Get updated balances
    $stmt = $pdo->prepare("SELECT referral_earnings, game_earnings, total_balance FROM balances WHERE user_id = ?");
    $stmt->execute([$user_id]);
    $balance = $stmt->fetch();
    
    echo json_encode([
        'success' => true,
        'drawn_numbers' => $drawn_numbers,
        'matched_numbers' => array_values($matched_numbers),
        'matches' => $matches,
        'multiplier' => $multiplier,
        'win_amount' => $win_amount,
        'referral_earnings' => $balance['referral_earnings'],
        'game_earnings' => $balance['game_earnings'],
        'total_balance' => $balance['total_balance']
    ]);
    
} catch (PDOException $e) {
    error_log("Keno Play Error: " . $e->getMessage());
    echo json_encode([
        'success' => false, 
        'message' => 'Database Error: ' . $e->getMessage(),
        'error_details' => [
            'file' => $e->getFile(),
            'line' => $e->getLine(),
            'trace' => $e->getTraceAsString()
        ]
    ]);
} catch (Exception $e) {
    error_log("Keno Play Exception: " . $e->getMessage());
    echo json_encode([
        'success' => false,
        'message' => 'Error: ' . $e->getMessage(),
        'error_details' => [
            'file' => $e->getFile(),
            'line' => $e->getLine(),
            'trace' => $e->getTraceAsString()
        ]
    ]);
}
?>
