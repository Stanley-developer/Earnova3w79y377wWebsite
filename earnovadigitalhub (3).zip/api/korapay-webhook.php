<?php
/**
 * Kora Pay Webhook Handler
 * Receives and processes payment notifications from Kora Pay
 * Endpoint: /api/korapay-webhook.php
 */

session_start();
require_once '../config/database.php';
require_once '../config/korapay.php';
require_once '../includes/connect.php';

// Verify webhook authenticity (Kora Pay sends X-Kora-Signature header)
function verifyKorapayWebhook() {
    $signature = $_SERVER['HTTP_X_KORA_SIGNATURE'] ?? $_SERVER['HTTP_X_KORAPAY_SIGNATURE'] ?? null;
    $payload = file_get_contents('php://input');
    
    if (!$signature || !$payload) {
        http_response_code(401);
        return false;
    }
    
    // Verify signature: HMAC-SHA256 of payload with secret key
    $expected_signature = hash_hmac('sha256', $payload, KORAPAY_SECRET_KEY);
    
    return hash_equals($expected_signature, $signature);
}

// Handler: incorporate post-task Korapay webhook logic (migrated from post-task-korapay-webhook.php)
function handle_post_task_korapay_webhook($raw_body, $payload_arr) {
    header('Content-Type: application/json; charset=utf-8');

    // Helper: return JSON and exit
    $json_exit = function($code, $payload) {
        http_response_code($code);
        echo json_encode($payload);
        exit;
    };

    // Log webhook for debugging
    $webhook_log_file = __DIR__ . '/../logs/korapay_webhook.log';
    $timestamp = date('Y-m-d H:i:s');
    @file_put_contents($webhook_log_file, "[$timestamp] Raw Body: $raw_body\n", FILE_APPEND | LOCK_EX);

    $payload = $payload_arr;
    if (!is_array($payload)) {
        @file_put_contents($webhook_log_file, "[$timestamp] Error: Invalid JSON\n", FILE_APPEND | LOCK_EX);
        $json_exit(400, ['status' => false, 'message' => 'Invalid JSON']);
    }

    $reference = $payload['reference'] ?? null;
    $status = $payload['status'] ?? null;
    $amount = $payload['amount'] ?? null;
    $metadata = $payload['metadata'] ?? [];

    if (!$reference || !$status) {
        @file_put_contents($webhook_log_file, "[$timestamp] Error: Missing reference or status\n", FILE_APPEND | LOCK_EX);
        $json_exit(400, ['status' => false, 'message' => 'Missing required fields']);
    }

    // Try to obtain server DB connection via PDO helper
    try {
        $pdo = getDBConnection();
    } catch (Exception $e) {
        @file_put_contents($webhook_log_file, "[$timestamp] DB Error: " . $e->getMessage() . "\n", FILE_APPEND | LOCK_EX);
        $json_exit(500, ['status' => false, 'message' => 'Database error']);
    }

    // Attempt to merge any stored payload (backwards compatibility)
    $decoded_payload = [];
    if (!empty($metadata['payload'])) {
        $decoded_payload = json_decode($metadata['payload'], true);
        if (!is_array($decoded_payload)) {
            $decoded_payload = [];
        }
    }

    if (empty($decoded_payload)) {
        try {
            $stmt = $pdo->prepare("SELECT payload FROM korapay_post_task_payloads WHERE reference = ? LIMIT 1");
            $stmt->execute([$reference]);
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            if ($row && !empty($row['payload'])) {
                $fetched = json_decode($row['payload'], true);
                if (is_array($fetched)) {
                    $decoded_payload = $fetched;
                }
            }
        } catch (Exception $e) {
            @file_put_contents($webhook_log_file, "[$timestamp] Payload fetch error: " . $e->getMessage() . "\n", FILE_APPEND | LOCK_EX);
        }
    }

    $metadata = array_merge($metadata, $decoded_payload);

    // Optional signature check if Korapay signature header exists
    $korapay_signature = $_SERVER['HTTP_X_KORAPAY_SIGNATURE'] ?? $_SERVER['HTTP_X_KORA_SIGNATURE'] ?? null;
    if ($korapay_signature) {
        $expected_signature = hash_hmac('sha256', $raw_body, KORAPAY_SECRET_KEY);
        if ($korapay_signature !== $expected_signature) {
            @file_put_contents($webhook_log_file, "[$timestamp] Error: Invalid signature\n", FILE_APPEND | LOCK_EX);
            $json_exit(401, ['status' => false, 'message' => 'Invalid signature']);
        }
    }

    if ($status === 'success') {
        $payment_type = $metadata['payment_type'] ?? null;
        $user_id = intval($metadata['user_id'] ?? 0);

        if ($payment_type !== 'post_task_deposit' || !$user_id) {
            @file_put_contents($webhook_log_file, "[$timestamp] Error: Invalid payment_type or user_id\n", FILE_APPEND | LOCK_EX);
            $json_exit(400, ['status' => false, 'message' => 'Invalid payment type or user']);
        }

        try {
            $pdo->beginTransaction();

            $stmt = $pdo->prepare("SELECT id FROM users WHERE id = ? LIMIT 1");
            $stmt->execute([$user_id]);
            $user = $stmt->fetch(PDO::FETCH_ASSOC);

            if (!$user) {
                $pdo->rollBack();
                @file_put_contents($webhook_log_file, "[$timestamp] Error: User not found (id=$user_id)\n", FILE_APPEND | LOCK_EX);
                $json_exit(404, ['status' => false, 'message' => 'User not found']);
            }

            $stmt = $pdo->prepare("SELECT id FROM korapay_post_task_payments WHERE reference = ? LIMIT 1");
            $stmt->execute([$reference]);
            $existing = $stmt->fetch(PDO::FETCH_ASSOC);
            if ($existing) {
                $pdo->rollBack();
                @file_put_contents($webhook_log_file, "[$timestamp] Warning: Duplicate webhook (ref=$reference)\n", FILE_APPEND | LOCK_EX);
                $json_exit(200, ['status' => true, 'message' => 'Already processed']);
            }

            $stmt = $pdo->prepare("INSERT INTO korapay_post_task_payments (user_id, reference, amount, status, metadata, created_at) VALUES (?, ?, ?, ?, ?, NOW())");
            $metadata_json = json_encode($metadata);
            $stmt->execute([$user_id, $reference, $amount, $status, $metadata_json]);
            $payment_id = $pdo->lastInsertId();

            $stmt = $pdo->prepare("UPDATE balances SET total_balance = total_balance + ? WHERE user_id = ?");
            $stmt->execute([$amount, $user_id]);

            $stmt = $pdo->prepare("INSERT INTO transactions (user_id, transaction_type, amount, balance_type, description, reference_id, created_at) VALUES (?, ?, ?, ?, ?, ?, NOW())");
            $desc = "Korapay Deposit for Post Task - Ref: " . $reference;
            $stmt->execute([$user_id, 'korapay_deposit_post_task', $amount, 'total_balance', $desc, $reference]);

            // Attempt to auto-create the task if metadata contains task details (idempotent)
            try {
                if (!empty($metadata['title']) && !empty($metadata['task_url'])) {
                    $stmt = $pdo->prepare("SELECT username, fullname FROM users WHERE id = ? LIMIT 1");
                    $stmt->execute([$user_id]);
                    $poster = $stmt->fetch(PDO::FETCH_ASSOC);

                    $task_title = trim($metadata['title']);
                    $task_desc = trim($metadata['description'] ?? '');
                    $task_platform = trim($metadata['task_platform'] ?? ($metadata['platform'] ?? ''));
                    $task_url = trim($metadata['task_url']);
                    $participants = max(10, intval($metadata['participants'] ?? 10));
                    $total_cost_val = floatval($metadata['total_cost'] ?? $amount);

                    $chk = $pdo->prepare("SELECT id FROM tasks WHERE task_url = ? AND user_id = ? AND created_at >= DATE_SUB(NOW(), INTERVAL 10 MINUTE) LIMIT 1");
                    $chk->execute([$task_url, $user_id]);
                    $exists_task = $chk->fetch(PDO::FETCH_ASSOC);

                    if (!$exists_task) {
                        $reward_total = $total_cost_val * 0.06;
                        $reward_per_user = ($participants > 0) ? ($reward_total / $participants) : 0;

                        $stmt = $pdo->prepare("INSERT INTO tasks (title, description, task_type, platform, reward_amount, task_url, participants_count, is_active, is_premium_only, created_at, user_id, posted_by_username, posted_by_fullname) VALUES (?, ?, 'social_media', ?, ?, ?, ?, 1, 0, NOW(), ?, ?, ?)");
                        $stmt->execute([$task_title, $task_desc, $task_platform, $reward_per_user, $task_url, $participants, $user_id, $poster['username'] ?? '', $poster['fullname'] ?? '']);
                        $task_id = $pdo->lastInsertId();

                        $stmt = $pdo->prepare("INSERT INTO advertisements (user_id, title, description, ad_type, target_url, budget, cost_per_action, total_actions, remaining_budget, is_active, created_at) VALUES (?, ?, ?, 'social_media', ?, ?, ?, 0, ?, 1, NOW())");
                        $stmt->execute([$user_id, $task_title, $task_desc, $task_url, $total_cost_val, $reward_per_user, $total_cost_val]);

                        // Handle upline commission (5% to senior referrer)
                        $stmt = $pdo->prepare("SELECT referred_by FROM users WHERE id = ?");
                        $stmt->execute([$user_id]);
                        $upline_result = $stmt->fetch(PDO::FETCH_ASSOC);
                        if ($upline_result && !empty($upline_result['referred_by'])) {
                            $upline_id = $upline_result['referred_by'];
                            $stmt = $pdo->prepare("SELECT u.advertiser_plan, b.referral_earnings FROM users u LEFT JOIN balances b ON u.id = b.user_id WHERE u.id = ?");
                            $stmt->execute([$upline_id]);
                            $upline_data = $stmt->fetch(PDO::FETCH_ASSOC);
                            if ($upline_data && $upline_data['advertiser_plan'] === 'senior') {
                                $upline_reward = ($total_cost_val * 0.05);
                                $stmt = $pdo->prepare("UPDATE balances SET referral_earnings = referral_earnings + ?, total_balance = total_balance + ? WHERE user_id = ?");
                                $stmt->execute([$upline_reward, $upline_reward, $upline_id]);

                                $stmt = $pdo->prepare("INSERT INTO transactions (user_id, transaction_type, amount, balance_type, description, reference_id, created_at) VALUES (?, ?, ?, ?, ?, ?, NOW())");
                                $reward_description = "5% Advertisement Commission - Downline task posting (₦{$total_cost_val}) on {$task_platform}";
                                $stmt->execute([$upline_id, 'advertise_commission', $upline_reward, 'referral_earnings', $reward_description, "UPLINE-AD-COMM-{$task_id}"]);

                                $commission_percentage = 5.00;
                                $stmt2 = $pdo->prepare("INSERT INTO ad_invite_commissions (referrer_id, referred_user_id, ad_purchase_amount, commission_amount, commission_percentage, created_at) VALUES (?, ?, ?, ?, ?, NOW())");
                                $stmt2->execute([$upline_id, $user_id, $total_cost_val, $upline_reward, $commission_percentage]);
                            }
                        }
                    }
                }
            } catch (Exception $e) {
                @file_put_contents($webhook_log_file, "[$timestamp] Auto-create task error: " . $e->getMessage() . "\n", FILE_APPEND | LOCK_EX);
            }

            $pdo->commit();

            @file_put_contents($webhook_log_file, "[$timestamp] Webhook completed successfully\n\n", FILE_APPEND | LOCK_EX);

            $json_exit(200, [
                'status' => true,
                'message' => 'Payment processed successfully',
                'payment_id' => $payment_id,
                'reference' => $reference
            ]);

        } catch (Exception $e) {
            $pdo->rollBack();
            @file_put_contents($webhook_log_file, "[$timestamp] Exception: " . $e->getMessage() . "\n", FILE_APPEND | LOCK_EX);
            $json_exit(500, ['status' => false, 'message' => 'Processing error']);
        }

    } else if ($status === 'pending') {
        @file_put_contents($webhook_log_file, "[$timestamp] Pending - ref=$reference\n", FILE_APPEND | LOCK_EX);
        $json_exit(200, ['status' => true, 'message' => 'Payment pending']);
    } else {
        @file_put_contents($webhook_log_file, "[$timestamp] Failed - ref=$reference, status=$status\n", FILE_APPEND | LOCK_EX);
        $user_id = intval($metadata['user_id'] ?? 0);
        if ($user_id) {
            try {
                $stmt = $pdo->prepare("INSERT INTO korapay_post_task_payments (user_id, reference, amount, status, metadata, created_at) VALUES (?, ?, ?, ?, ?, NOW())");
                $metadata_json = json_encode($metadata);
                $stmt->execute([$user_id, $reference, $amount, $status, $metadata_json]);
            } catch (Exception $e) {
                @file_put_contents($webhook_log_file, "[$timestamp] Failed record error: " . $e->getMessage() . "\n", FILE_APPEND | LOCK_EX);
            }
        }
        $json_exit(200, ['status' => false, 'message' => 'Payment failed']);
    }
}

// Handle the webhook
header('Content-Type: application/json');

// Log incoming webhook
$payload = file_get_contents('php://input');
error_log('Kora Pay Webhook Received: ' . $payload);

// Verify webhook
if (!verifyKorapayWebhook()) {
    http_response_code(401);
    echo json_encode(['status' => false, 'message' => 'Unauthorized']);
    exit;
}

$data = json_decode($payload, true);

if (!$data) {
    http_response_code(400);
    echo json_encode(['status' => false, 'message' => 'Invalid JSON payload']);
    exit;
}

// If payload matches legacy post-task webhook format (reference + status), delegate to post-task handler
if (isset($data['reference']) && isset($data['status'])) {
    handle_post_task_korapay_webhook($payload, $data);
    // handler will exit after responding
}

if (!isset($data['event']) || !isset($data['data'])) {
    http_response_code(400);
    echo json_encode(['status' => false, 'message' => 'Invalid payload']);
    exit;
}

$event = $data['event'];
$event_data = $data['data'];

error_log("Processing Kora Pay Event: $event");

// Start transaction
$conn->begin_transaction();

try {
    // Handle charge.success event (Virtual Bank Account deposit)
    if ($event === 'charge.success' && isset($event_data['virtual_bank_account_details'])) {
        $reference = $event_data['reference'];
        $amount = $event_data['amount'];
        $currency = $event_data['currency'];
        $vba_details = $event_data['virtual_bank_account_details'];
        $account_reference = $vba_details['virtual_bank_account']['account_reference'] ?? null;
        $payer = $vba_details['payer_bank_account'] ?? [];
        
        error_log("Processing VBA deposit - Reference: $reference, Amount: $amount, Account Ref: $account_reference");
        
        // Find user by account reference
        if (!$account_reference) {
            throw new Exception('No account reference in VBA details');
        }
        
        $stmt = $conn->prepare("SELECT id, full_name, email FROM users WHERE korapay_account_reference = ?");
        $stmt->bind_param("s", $account_reference);
        $stmt->execute();
        $user_result = $stmt->get_result();
        $user = $user_result->fetch_assoc();
        $stmt->close();
        
        if (!$user) {
            throw new Exception('User not found for account reference: ' . $account_reference);
        }
        
        $user_id = $user['id'];
        error_log("Found user: $user_id");
        
        // Check if transaction already processed
        $stmt = $conn->prepare("SELECT id FROM korapay_transactions WHERE korapay_reference = ?");
        $stmt->bind_param("s", $reference);
        $stmt->execute();
        if ($stmt->get_result()->num_rows > 0) {
            $stmt->close();
            error_log("Transaction already processed: $reference");
            http_response_code(200);
            echo json_encode(['status' => true, 'message' => 'Already processed']);
            $conn->commit();
            exit;
        }
        $stmt->close();
        
        // Record webhook
        $stmt = $conn->prepare("INSERT INTO korapay_webhooks (event_type, webhook_reference, payload) VALUES (?, ?, ?)");
        $payload_json = json_encode($event_data);
        $stmt->bind_param("sss", $event, $reference, $payload_json);
        $stmt->execute();
        $stmt->close();
        
        // Record transaction
        $payer_account = $payer['account_number'] ?? '';
        $payer_name = $payer['account_name'] ?? '';
        $payer_bank = $payer['bank_name'] ?? '';
        $narration = $event_data['transaction_date'] ?? date('Y-m-d H:i:s');
        $received_at = $event_data['transaction_date'] ?? date('Y-m-d H:i:s');
        
        $stmt = $conn->prepare("
            INSERT INTO korapay_transactions 
            (user_id, korapay_reference, amount, currency, payer_account_number, payer_account_name, payer_bank_name, transaction_narration, status, received_at, description)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'success', ?, ?)
        ");
        $description = "VBA Deposit from $payer_bank - $payer_name";
        $stmt->bind_param("isddsssss", $user_id, $reference, $amount, $currency, $payer_account, $payer_name, $payer_bank, $narration, $received_at, $description);
        if (!$stmt->execute()) {
            throw new Exception("Failed to record transaction: " . $stmt->error);
        }
        $stmt->close();
        
        error_log("Transaction recorded successfully for user $user_id, amount: $amount");
        
        // Credit user's balance
        // For VBA deposits, credit to prime balance (referral_earnings)
        $stmt = $conn->prepare("
            UPDATE balances 
            SET total_balance = total_balance + ?, 
                referral_earnings = referral_earnings + ?
            WHERE user_id = ?
        ");
        $stmt->bind_param("ddi", $amount, $amount, $user_id);
        if (!$stmt->execute()) {
            throw new Exception("Failed to update balance: " . $stmt->error);
        }
        $stmt->close();
        
        error_log("User balance updated for user $user_id");
        
        // Record transaction in transactions table
        $transaction_type = 'deposit';
        $description_transaction = "Kora Pay VBA Deposit - ₦" . number_format($amount, 2);
        $stmt = $conn->prepare("
            INSERT INTO transactions 
            (user_id, transaction_type, amount, description, reference_id, status, balance_type)
            VALUES (?, ?, ?, ?, ?, 'completed', 'prime_earnings')
        ");
        $stmt->bind_param("isdss", $user_id, $transaction_type, $amount, $description_transaction, $reference);
        $stmt->execute();
        $stmt->close();
        
        error_log("Transaction history recorded for user $user_id");
        
        // Mark webhook as processed
        $stmt = $conn->prepare("UPDATE korapay_webhooks SET processed = 1, processed_at = NOW() WHERE webhook_reference = ?");
        $stmt->bind_param("s", $reference);
        $stmt->execute();
        $stmt->close();
        
        $conn->commit();
        
        error_log("VBA deposit processing completed successfully for user $user_id");
        
        http_response_code(200);
        echo json_encode(['status' => true, 'message' => 'Deposit processed successfully']);
        exit;
    }
    
    // Handle charge.success event (Regular charge/payment for upgrade)
    elseif ($event === 'charge.success') {
        $reference = $event_data['reference'];
        $amount = $event_data['amount'];
        $customer_email = $event_data['customer']['email'] ?? null;
        $metadata = $event_data['metadata'] ?? [];
        
        error_log("Processing regular charge - Reference: $reference, Email: $customer_email, Amount: $amount");
        
        // Find user by email
        if (!$customer_email) {
            throw new Exception('No customer email in charge data');
        }
        
        $stmt = $conn->prepare("SELECT id FROM users WHERE email = ?");
        $stmt->bind_param("s", $customer_email);
        $stmt->execute();
        $user_result = $stmt->get_result();
        $user = $user_result->fetch_assoc();
        $stmt->close();
        
        if (!$user) {
            throw new Exception('User not found for email: ' . $customer_email);
        }
        
        $user_id = $user['id'];
        $payment_type = $metadata['payment_type'] ?? 'general';
        $plan_duration = $metadata['plan_duration'] ?? 'yearly';
        
        error_log("Found user: $user_id, Payment type: $payment_type");
        
        // Check if transaction already processed
        $stmt = $conn->prepare("SELECT id FROM korapay_transactions WHERE korapay_reference = ?");
        $stmt->bind_param("s", $reference);
        $stmt->execute();
        if ($stmt->get_result()->num_rows > 0) {
            $stmt->close();
            error_log("Transaction already processed: $reference");
            http_response_code(200);
            echo json_encode(['status' => true, 'message' => 'Already processed']);
            $conn->commit();
            exit;
        }
        $stmt->close();
        
        // Record webhook
        $stmt = $conn->prepare("INSERT INTO korapay_webhooks (event_type, webhook_reference, payload) VALUES (?, ?, ?)");
        $payload_json = json_encode($event_data);
        $stmt->bind_param("sss", $event, $reference, $payload_json);
        $stmt->execute();
        $stmt->close();
        
        // Process based on payment type
        if ($payment_type === 'premium_upgrade') {
            error_log("Processing premium upgrade for user $user_id");
            
            // Update user membership
            $stmt = $conn->prepare("
                UPDATE users 
                SET membership_type = 'premium',
                    membership_expires_at = DATE_ADD(NOW(), INTERVAL 1 YEAR),
                    membership_start_date = COALESCE(membership_start_date, NOW())
                WHERE id = ?
            ");
            $stmt->bind_param("i", $user_id);
            if (!$stmt->execute()) {
                throw new Exception("Failed to update membership: " . $stmt->error);
            }
            $stmt->close();
            
            // Record payment
            $referrer_commission = 500;
            $company_amount = $amount - $referrer_commission;
            $stmt = $conn->prepare("
                INSERT INTO premium_payments 
                (user_id, amount, payment_method, payment_reference, status, referrer_commission, company_amount)
                VALUES (?, ?, 'korapay', ?, 'completed', ?, ?)
            ");
            $stmt->bind_param("idsdd", $user_id, $amount, $reference, $referrer_commission, $company_amount);
            if (!$stmt->execute()) {
                throw new Exception("Failed to record premium payment: " . $stmt->error);
            }
            $stmt->close();
            
            error_log("Premium upgrade recorded successfully");
        }
        elseif ($payment_type === 'premium_plus_upgrade') {
            error_log("Processing premium plus upgrade for user $user_id");
            
            // Get user current membership
            $stmt = $conn->prepare("SELECT membership_type, advertiser_plan FROM users WHERE id = ?");
            $stmt->bind_param("i", $user_id);
            $stmt->execute();
            $current_user = $stmt->get_result()->fetch_assoc();
            $stmt->close();
            
            // Auto-upgrade to Premium if not already
            if ($current_user['membership_type'] !== 'premium') {
                $stmt = $conn->prepare("
                    UPDATE users 
                    SET membership_type = 'premium',
                        membership_expires_at = DATE_ADD(NOW(), INTERVAL 1 YEAR),
                        membership_start_date = COALESCE(membership_start_date, NOW())
                    WHERE id = ?
                ");
                $stmt->bind_param("i", $user_id);
                $stmt->execute();
                $stmt->close();
                error_log("User auto-upgraded to Premium");
            }
            
            // Set advertiser plan
            $stmt = $conn->prepare("
                UPDATE users 
                SET advertiser_plan = 'senior',
                    advertiser_plan_start_date = COALESCE(advertiser_plan_start_date, NOW())
                WHERE id = ?
            ");
            $stmt->bind_param("i", $user_id);
            if (!$stmt->execute()) {
                throw new Exception("Failed to update advertiser plan: " . $stmt->error);
            }
            $stmt->close();
            
            // Check if renewal
            $is_renewal = !empty($current_user['advertiser_plan_start_date']) ? 1 : 0;
            
            // Record advertiser payment
            $stmt = $conn->prepare("
                INSERT INTO advertiser_payments 
                (user_id, amount, plan_duration, payment_method, payment_reference, status, is_renewal)
                VALUES (?, ?, ?, 'korapay', ?, 'completed', ?)
            ");
            $stmt->bind_param("idssi", $user_id, $amount, $plan_duration, $reference, $is_renewal);
            if (!$stmt->execute()) {
                throw new Exception("Failed to record advertiser payment: " . $stmt->error);
            }
            $stmt->close();
            
            error_log("Premium Plus upgrade recorded successfully");
        }
        
        // Record transaction in korapay_transactions
        $stmt = $conn->prepare("
            INSERT INTO korapay_transactions 
            (user_id, korapay_reference, amount, currency, status, payment_type, received_at, description)
            VALUES (?, ?, ?, 'NGN', 'success', ?, NOW(), ?)
        ");
        $description = "Payment for " . ($payment_type === 'premium_plus_upgrade' ? 'Premium Plus' : 'Premium') . " upgrade via Kora Pay";
        $stmt->bind_param("isdss", $user_id, $reference, $amount, $payment_type, $description);
        $stmt->execute();
        $stmt->close();
        
        // Record in transactions table
        $transaction_type = 'premium_upgrade';
        $description_transaction = ucfirst(str_replace('_', ' ', $payment_type)) . " - ₦" . number_format($amount, 2);
        $stmt = $conn->prepare("
            INSERT INTO transactions 
            (user_id, transaction_type, amount, description, reference_id, status)
            VALUES (?, ?, ?, ?, ?, 'completed')
        ");
        $stmt->bind_param("isdss", $user_id, $transaction_type, $amount, $description_transaction, $reference);
        $stmt->execute();
        $stmt->close();
        
        // Mark webhook as processed
        $stmt = $conn->prepare("UPDATE korapay_webhooks SET processed = 1, processed_at = NOW() WHERE webhook_reference = ?");
        $stmt->bind_param("s", $reference);
        $stmt->execute();
        $stmt->close();
        
        $conn->commit();
        error_log("Payment processing completed successfully for user $user_id");
        
        http_response_code(200);
        echo json_encode(['status' => true, 'message' => 'Payment processed successfully']);
        exit;
    }
    
    // Handle other events
    else {
        error_log("Unhandled Kora Pay event: $event");
        http_response_code(200);
        echo json_encode(['status' => true, 'message' => 'Event received but not processed']);
        exit;
    }
    
} catch (Exception $e) {
    $conn->rollback();
    error_log("Kora Pay Webhook Error: " . $e->getMessage());
    http_response_code(500);
    echo json_encode(['status' => false, 'message' => 'Processing error: ' . $e->getMessage()]);
    exit;
}
?>
