<?php
// Allow requests from your frontend domain
header("Access-Control-Allow-Origin: https://earnova-cosmic-growth-platform.vercel.app");
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");

// Handle preflight requests (OPTIONS)
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}
/**
 * Newsletter Subscription API
 * Handles email validation, subscription, and confirmation
 */

session_start();
require_once '../config/database.php';
require_once '../includes/email-helper.php';

// Enable error reporting for debugging
error_log("[NEWSLETTER] Subscribe endpoint called");

// Set JSON header
header('Content-Type: application/json');

// Get request method
$method = $_SERVER['REQUEST_METHOD'];

if ($method !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    exit();
}

// Get input data
$data = json_decode(file_get_contents('php://input'), true) ?? [];
$email = trim($data['email'] ?? '');
$full_name = trim($data['full_name'] ?? '');

$email_pattern = '/^[a-zA-Z0-9.!#$%&\'*+\/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/';

// Validate email
if (empty($email) || !preg_match($email_pattern, $email)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Please provide a valid email address']);
    exit();
}

// Validate full name if provided
if (!empty($full_name) && strlen($full_name) > 255) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Name is too long']);
    exit();
}

try {
    // Check if already subscribed
    $stmt = $conn->prepare("SELECT id, subscription_status, is_confirmed FROM newsletters_subscribers WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        $subscriber = $result->fetch_assoc();
        
        if ($subscriber['subscription_status'] === 'active') {
            if ($subscriber['is_confirmed']) {
                echo json_encode(['success' => false, 'message' => 'This email is already subscribed']);
                exit();
            } else {
                // Resend confirmation email
                $confirmation_token = bin2hex(random_bytes(32));
                $stmt = $conn->prepare("UPDATE newsletters_subscribers SET confirmation_token = ? WHERE email = ?");
                $stmt->bind_param("ss", $confirmation_token, $email);
                $stmt->execute();
            }
        } else {
            // Reactivate subscription
            $confirmation_token = bin2hex(random_bytes(32));
            $stmt = $conn->prepare("UPDATE newsletters_subscribers SET subscription_status = 'active', confirmation_token = ?, unsubscribed_at = NULL WHERE email = ?");
            $stmt->bind_param("ss", $confirmation_token, $email);
            $stmt->execute();
        }
    } else {
        // Create new subscription
        $confirmation_token = bin2hex(random_bytes(32));
        $user_id = isset($_SESSION['user_id']) ? $_SESSION['user_id'] : 0;
        
        $stmt = $conn->prepare("INSERT INTO newsletters_subscribers (email, full_name, user_id, confirmation_token) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("ssis", $email, $full_name, $user_id, $confirmation_token);
        
        if (!$stmt->execute()) {
            throw new Exception("Database insert error: " . $stmt->error);
        }
    }
    
    // Get confirmation token for new subscriptions
    $stmt = $conn->prepare("SELECT confirmation_token FROM newsletters_subscribers WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $subscriber = $stmt->get_result()->fetch_assoc();
    $confirmation_token = $subscriber['confirmation_token'];
    
    $confirmation_url = "https://earnova-digital-hub.com/api/confirm-newsletter.php?token=" . urlencode($confirmation_token) . "&email=" . urlencode($email);
    
    $subject = 'Confirm Your Earnova Digital Hub Newsletter Subscription';
    $subscriber_name = !empty($full_name) ? $full_name : 'Subscriber';
    
    $html_body = "
        <html>
        <head>
            <style>
                body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; margin: 0; padding: 0; }
                .container { max-width: 600px; margin: 0 auto; padding: 0; }
                .header { background: linear-gradient(135deg, #2c5bf5, #4de1c1); padding: 30px 20px; text-align: center; color: white; }
                .logo { max-width: 150px; margin-bottom: 15px; }
                .header h1 { margin: 10px 0; font-size: 24px; }
                .content { background: #f9f9f9; padding: 30px 20px; }
                .button { display: inline-block; background: #2c5bf5; color: white; padding: 12px 30px; text-decoration: none; border-radius: 5px; margin: 20px 0; font-weight: bold; }
                .footer { text-align: center; margin-top: 20px; color: #666; font-size: 12px; padding: 20px; border-top: 1px solid #ddd; }
                a { color: #2c5bf5; }
            </style>
        </head>
        <body>
            <div class='container'>
                <div class='header'>
                    <img src='https://earnova.org/logo.png' alt='Earnova Digital Hub' class='logo' style='height: 50px; width: auto;'>
                    <h1>Confirm Your Newsletter Subscription</h1>
                </div>
                <div class='content'>
                    <p>Hello " . htmlspecialchars($subscriber_name) . ",</p>
                    <p>Thank you for subscribing to <strong>Earnova Digital Hub</strong>! We're excited to have you on board.</p>
                    <p>Please confirm your email address by clicking the button below:</p>
                    
                    <center>
                        <a href='" . htmlspecialchars($confirmation_url) . "' class='button'>Confirm Email</a>
                    </center>
                    
                    <p>Or copy and paste this link in your browser:</p>
                    <p style='word-break: break-all; color: #666; font-size: 12px;'>" . htmlspecialchars($confirmation_url) . "</p>
                    
                    <p>This confirmation link will expire in 24 hours.</p>
                    <p>If you did not subscribe to our newsletter, please ignore this email.</p>
                </div>
                <div class='footer'>
                    <p><strong>Earnova Digital Hub</strong></p>
                    <p>This is an automated message from Earnova. Please do not reply to this email.</p>
                </div>
            </div>
        </body>
        </html>
    ";
    
    $alt_body = "Hello " . $subscriber_name . ",\n\n" .
                "Thank you for subscribing to Earnova Digital Hub newsletter!\n\n" .
                "Please confirm your email by visiting this link:\n" .
                $confirmation_url . "\n\n" .
                "This link will expire in 24 hours.\n\n" .
                "If you did not subscribe, please ignore this email.\n\n" .
                "Best regards,\nEarnova Digital Hub";
    
    $email_result = sendEmail($email, $subscriber_name, $subject, $html_body, $alt_body);

    
    if (!$email_result['success']) {
        error_log("[EMAIL] Failed to send confirmation email to $email: " . $email_result['message']);
    }
    
    echo json_encode([
        'success' => true,
        'message' => 'Subscription successful! Please check your email to confirm your subscription.'
    ]);
    
} catch (Exception $e) {
    error_log("[NEWSLETTER] Subscription error: " . $e->getMessage());
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'An error occurred. Please try again later.']);
}
?>
