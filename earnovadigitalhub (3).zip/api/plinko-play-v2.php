<?php
require_once '../config/database.php';
require_once '../includes/session.php';

header('Content-Type: application/json');

// Require authentication
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit;
}

$user_id = $_SESSION['user_id'];

try {
    $pdo = getDBConnection();
    
    // Get POST data
    $data = json_decode(file_get_contents('php://input'), true);
    $bet_amount = floatval($data['bet_amount'] ?? 0);
    $multiplier = floatval($data['multiplier'] ?? 0);
    
    // Validate bet amount
    if ($bet_amount < 1000) {
        echo json_encode(['success' => false, 'message' => 'Minimum bet amount is ₦1,000']);
        exit;
    }
    
    // Validate multiplier - only allow expected values
    $valid_multipliers = [4, 3, 2.5, 1.5, 0.5, 0.25];
    if (!in_array($multiplier, $valid_multipliers)) {
        echo json_encode(['success' => false, 'message' => 'Invalid multiplier']);
        exit;
    }
    
    // Get user data
    $stmt = $pdo->prepare("
        SELECT u.*, b.referral_earnings, b.game_earnings, b.total_balance
        FROM users u
        LEFT JOIN balances b ON u.id = b.user_id
        WHERE u.id = ?
    ");
    $stmt->execute([$user_id]);
    $user = $stmt->fetch();
    
    if (!$user) {
        echo json_encode(['success' => false, 'message' => 'User not found']);
        exit;
    }
    
    if ($user['membership_type'] !== 'premium') {
        echo json_encode(['success' => false, 'message' => 'Premium membership required', 'upgrade_required' => true]);
        exit;
    }
    
    if ($user['game_earnings'] < $bet_amount) {
        echo json_encode(['success' => false, 'message' => 'Insufficient balance. Please deposit to play.', 'insufficient_balance' => true]);
        exit;
    }
    
    $stmt = $pdo->prepare("
        UPDATE balances 
        SET game_earnings = game_earnings - ?, 
            total_balance = total_balance - ? 
        WHERE user_id = ?
    ");
    $stmt->execute([$bet_amount, $bet_amount, $user_id]);
    
    // Use the multiplier from frontend - this is the actual result
    $win_amount = $bet_amount * $multiplier;
    
    // Add winnings to game_earnings
    if ($win_amount > 0) {
        $stmt = $pdo->prepare("
            UPDATE balances 
            SET game_earnings = game_earnings + ?, 
                total_balance = total_balance + ? 
            WHERE user_id = ?
        ");
        $stmt->execute([$win_amount, $win_amount, $user_id]);
    }
    
    $stmt = $pdo->prepare("
        INSERT INTO transactions (user_id, transaction_type, amount, balance_type, description, reference_id)
        VALUES (?, 'game_play', ?, 'game', ?, ?)
    ");
    $description = "Plinko Game - Bet: ₦" . number_format($bet_amount, 2) . " | Multiplier: " . $multiplier . "x | Win: ₦" . number_format($win_amount, 2);
    $reference_id = 'PLINKO_' . time() . '_' . $user_id;
    $stmt->execute([$user_id, $win_amount, $description, $reference_id]);
    
    // Get updated balances
    $stmt = $pdo->prepare("SELECT referral_earnings, game_earnings, total_balance FROM balances WHERE user_id = ?");
    $stmt->execute([$user_id]);
    $balance = $stmt->fetch();
    
    echo json_encode([
        'success' => true,
        'multiplier' => $multiplier,
        'win_amount' => $win_amount,
        'referral_earnings' => $balance['referral_earnings'],
        'game_earnings' => $balance['game_earnings'],
        'total_balance' => $balance['total_balance']
    ]);
    
} catch (PDOException $e) {
    error_log("Plinko Play Error: " . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'An error occurred']);
}
?>
