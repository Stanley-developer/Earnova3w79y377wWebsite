<?php
require_once '../config/database.php';
require_once '../includes/session.php';

header('Content-Type: application/json');

// Require authentication
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit;
}

$user_id = $_SESSION['user_id'];

try {
    $pdo = getDBConnection();
    
    // Get POST data
    $data = json_decode(file_get_contents('php://input'), true);
    $track_id = $data['track_id'] ?? '';
    $track_title = $data['track_title'] ?? '';
    $stream_duration = intval($data['stream_duration'] ?? 0);
    $track_duration = intval($data['track_duration'] ?? 0);
        // Get any verified email for this user+track (if the user has verified an email via audio ad)
        $email = null;
    
    // Validate input
    if (empty($track_id) || $stream_duration <= 0 || $track_duration <= 0) {
        echo json_encode(['success' => false, 'message' => 'Invalid stream data']);
        exit;
    }
    
    // Get user data
    $stmt = $pdo->prepare("SELECT membership_type FROM users WHERE id = ?");
    $stmt->execute([$user_id]);
    $user = $stmt->fetch();
    
    if (!$user) {
        echo json_encode(['success' => false, 'message' => 'User not found']);
        exit;
    }
    
    $is_premium = ($user['membership_type'] === 'premium');
    
    $stmt = $pdo->prepare("SELECT free_reward, premium_reward FROM stream_tracks WHERE track_id = ?");
    $stmt->execute([$track_id]);
    $track_info = $stmt->fetch();
    
    if (!$track_info) {
        echo json_encode(['success' => false, 'message' => 'Track not found']);
        exit;
    }
    
    $free_reward = floatval($track_info['free_reward'] ?? 100);
    $premium_reward = floatval($track_info['premium_reward'] ?? 200);
    
    // Calculate completion percentage
    $completion_percentage = ($stream_duration / $track_duration) * 100;
    
    $is_eligible = ($completion_percentage >= 70 && $is_premium);
    $payout_amount = $is_eligible ? $premium_reward : 0.00;
    
    // Get client info for fraud detection
    $ip_address = $_SERVER['REMOTE_ADDR'] ?? '';
    $user_agent = $_SERVER['HTTP_USER_AGENT'] ?? '';
    
    // Check if user already earned from this track
    $stmt = $pdo->prepare("
        SELECT id, payout_status 
        FROM stream_earnings 
        WHERE user_id = ? AND track_id = ?
    ");
    $stmt->execute([$user_id, $track_id]);
    $existing_stream = $stmt->fetch();
    
    if ($existing_stream) {
        echo json_encode([
            'success' => true,
            'payout_awarded' => false,
            'message' => 'You have already streamed this track',
            'already_claimed' => true
        ]);
        exit;
    }
    
    // Anti-fraud: Check rate limiting (max 200 streams per hour from same IP)
    $one_hour_ago = date('Y-m-d H:i:s', strtotime('-1 hour'));
    $stmt = $pdo->prepare("
        SELECT COUNT(*) as stream_count 
        FROM stream_logs 
        WHERE ip_address = ? AND created_at >= ?
    ");
    $stmt->execute([$ip_address, $one_hour_ago]);
    $rate_check = $stmt->fetch();
    
    if ($rate_check['stream_count'] > 200) {
        echo json_encode([
            'success' => false,
            'message' => 'Rate limit exceeded. Please try again later.'
        ]);
        exit;
    }
    
    // Begin transaction
    $pdo->beginTransaction();
    
    try {
        // Log the stream event
        $stmt = $pdo->prepare("
            INSERT INTO stream_logs (user_id, track_id, event_type, stream_duration, ip_address, user_agent)
            VALUES (?, ?, 'complete', ?, ?, ?)
        ");
        $stmt->execute([$user_id, $track_id, $stream_duration, $ip_address, $user_agent]);
        
        // Record stream earning
        // Try to fetch a verified email for this user & track (non-blocking)
        try {
            // Prefer verified emails that are tied to this user & track
            $stmt2 = $pdo->prepare("SELECT email, id, user_id FROM stream_ad_verified_emails WHERE track_id = ? AND user_id = ? ORDER BY id DESC LIMIT 1");
            $stmt2->execute([$track_id, $user_id]);
            $row = $stmt2->fetch();
            if ($row && !empty($row['email'])) {
                $email = $row['email'];
            } else {
                // Fallback: if a verified email was recently registered for this track in session, use it
                $sessKey = 'stream_ad_verified_email_' . $track_id;
                if (!empty($_SESSION[$sessKey])) {
                    $email = $_SESSION[$sessKey];
                }

                // Last fallback: if the user's account email matches a verified email for this track,
                // use it (do NOT update any rows)
                if (empty($email) && !empty($user['email'])) {
                    try {
                        $stmt4 = $pdo->prepare("SELECT email FROM stream_ad_verified_emails WHERE track_id = ? AND email = ? LIMIT 1");
                        $stmt4->execute([$track_id, $user['email']]);
                        $row4 = $stmt4->fetch();
                        if ($row4 && !empty($row4['email'])) {
                            $email = $row4['email'];
                        }
                    } catch (Exception $e3) {
                        // ignore failures here
                        error_log("Failed to fetch verified email by user email fallback: " . $e3->getMessage());
                    }
                }
            }
        } catch (Exception $e) {
            // If the table/column doesn't exist or query fails, continue with null email (do not block the process)
            error_log("Failed to fetch verified email for stream_earnings: " . $e->getMessage());
        }

        $stmt = $pdo->prepare("
                INSERT INTO stream_earnings 
            (user_id, track_id, track_title, stream_duration, completion_percentage, payout_amount, is_eligible, payout_status, ip_address, user_agent, email)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ");
            $stmt->execute([
                $user_id,
                $track_id,
                $track_title,
                $stream_duration,
                $completion_percentage,
                $payout_amount,
                $is_eligible ? 1 : 0,
                $is_eligible ? 'paid' : 'pending',
                $ip_address,
                $user_agent,
                $email
            ]);
        
        $payout_awarded = false;
        
        // If eligible, credit payout
        if ($is_eligible && $payout_amount > 0) {
            // Update balances atomically
            $stmt = $pdo->prepare("
                UPDATE balances 
                SET task_earnings = task_earnings + ?,
                    total_balance = total_balance + ?
                WHERE user_id = ?
            ");
            $stmt->execute([$payout_amount, $payout_amount, $user_id]);
            
            $stmt = $pdo->prepare("
                INSERT INTO transactions 
                (user_id, transaction_type, amount, balance_type, description)
                VALUES (?, 'stream_earning', ?, 'Activity_earnings', ?)
            ");
            $description = "Streamed: " . $track_title;
            $stmt->execute([$user_id, $payout_amount, $description]);
            
            // Update daily stats
            $today = date('Y-m-d');
            $stmt = $pdo->prepare("
                INSERT INTO stream_daily_stats (user_id, stream_date, total_streams, total_payouts, eligible_streams)
                VALUES (?, ?, 1, ?, 1)
                ON DUPLICATE KEY UPDATE
                    total_streams = total_streams + 1,
                    total_payouts = total_payouts + ?,
                    eligible_streams = eligible_streams + 1
            ");
            $stmt->execute([$user_id, $today, $payout_amount, $payout_amount]);
            
            // Update track play count
            $stmt = $pdo->prepare("UPDATE stream_tracks SET play_count = play_count + 1 WHERE track_id = ?");
            $stmt->execute([$track_id]);
            
            $payout_awarded = true;
        }
        
        $pdo->commit();
        
        echo json_encode([
            'success' => true,
            'payout_awarded' => $payout_awarded,
            'payout_amount' => $payout_amount,
            'completion_percentage' => round($completion_percentage, 2),
            'is_eligible' => $is_eligible,
            'message' => $payout_awarded 
                ? 'Congratulations! ₦' . number_format($payout_amount, 0) . ' has been added to your Activity Earnings.' 
                : ($is_premium 
                    ? 'Stream recorded but not eligible for payout (need 70% completion)' 
                    : 'Stream recorded. Upgrade to Premium to earn from streaming!')
        ]);
        
    } catch (Exception $e) {
        $pdo->rollBack();
        throw $e;
    }
    
} catch (PDOException $e) {
    error_log("Stream Record Error: " . $e->getMessage());
    echo json_encode([
        'success' => false,
        'message' => 'An error occurred while recording your stream'
    ]);
}
?>
