<?php
/**
 * Paystack Automatic Transfer Processing for Prime Earnings
 * This endpoint processes Prime Earnings withdrawals automatically via Paystack API
 * Called when a Prime Earnings withdrawal status changes to 'processing'
 */

session_start();

// IMPORTANT: Only include database.php - NOT connect.php
// connect.php calls requireLogin() which fails for API/cron calls
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/email.php';

header('Content-Type: application/json');

define('PAYSTACK_SECRET_KEY', 'sk_live_7ceb76976f99b57f94ff8ba1e7d1940254b052ba');
define('PAYSTACK_PUBLIC_KEY', 'pk_live_c63f1c7c23ee7e26d0e0964f6795c937d43c05ef');
define('PAYSTACK_BASE_URL', 'https://api.paystack.co');

$log_file = __DIR__ . '/../paystack_error_logs';

function logPaystackError($message, $log_file) {
    $timestamp = date('Y-m-d H:i:s');
    $log_entry = "[$timestamp] $message\n";
    file_put_contents($log_file, $log_entry, FILE_APPEND);
}

// Authorization required - either admin or system process
if (!isset($_SESSION['user_id'])) {
    // Allow system cron jobs via secret token
    $auth_token = $_GET['token'] ?? '';
    if ($auth_token !== 'sys_' . substr(md5('earnova_paystack_cron'), 0, 16)) {
        logPaystackError("UNAUTHORIZED ACCESS ATTEMPT - Invalid token: $auth_token", $log_file);
        http_response_code(401);
        echo json_encode(['success' => false, 'message' => 'Unauthorized']);
        exit;
    }
}

logPaystackError("=== PAYSTACK TRANSFER PROCESSING STARTED ===", $log_file);

try {
    // Get all Prime Earnings withdrawals pending Paystack transfer
    // Now selecting account_details from withdrawals table (where bank info is stored)
    $stmt = $conn->prepare("
        SELECT w.*, w.account_details, u.id as user_id, u.email, u.full_name, 
               u.withdrawal_account_number, u.withdrawal_bank_code, 
               u.withdrawal_account_name, u.paystack_recipient_code
        FROM withdrawals w
        JOIN users u ON w.user_id = u.id
        WHERE w.withdrawal_type = 'prime_earnings' 
        AND w.status = 'processing' 
        AND w.paystack_status IN ('not_initiated', 'failed')
        AND w.requested_at > DATE_SUB(NOW(), INTERVAL 7 DAY)
        LIMIT 50
    ");
    $stmt->execute();
    $pending_withdrawals = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $stmt->close();

    $count = count($pending_withdrawals);
    logPaystackError("Found $count pending withdrawals to process", $log_file);

    $processed_count = 0;
    $failed_count = 0;
    $results = [];

    foreach ($pending_withdrawals as $withdrawal) {
        logPaystackError("Processing withdrawal ID: " . $withdrawal['id'] . " for user: " . $withdrawal['user_id'], $log_file);
        
        $transfer_result = processPaystackTransfer($withdrawal, $conn, $log_file);
        
        if ($transfer_result['success']) {
            $processed_count++;
            logPaystackError("SUCCESS - Withdrawal ID: " . $withdrawal['id'] . " - Transfer ID: " . $transfer_result['transfer_id'], $log_file);
            $results[] = [
                'withdrawal_id' => $withdrawal['id'],
                'status' => 'success',
                'paystack_transfer_id' => $transfer_result['transfer_id'],
                'message' => 'Transfer initiated successfully'
            ];
        } else {
            $failed_count++;
            logPaystackError("FAILED - Withdrawal ID: " . $withdrawal['id'] . " - Error: " . $transfer_result['message'], $log_file);
            $results[] = [
                'withdrawal_id' => $withdrawal['id'],
                'status' => 'failed',
                'message' => $transfer_result['message'],
                'error' => $transfer_result['error'] ?? null
            ];
        }
    }

    logPaystackError("=== PROCESSING COMPLETE: $processed_count success, $failed_count failed ===", $log_file);

    echo json_encode([
        'success' => true,
        'message' => "Processed $processed_count transfers, $failed_count failed",
        'processed' => $processed_count,
        'failed' => $failed_count,
        'results' => $results
    ]);

} catch (Exception $e) {
    logPaystackError("CRITICAL ERROR: " . $e->getMessage(), $log_file);
    error_log("Paystack Transfer Error: " . $e->getMessage());
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => 'An error occurred processing transfers',
        'error' => $e->getMessage()
    ]);
}

/**
 * Process a single withdrawal through Paystack API
 */
function processPaystackTransfer($withdrawal, $conn, $log_file) {
    global $result;

    $withdrawal_id = $withdrawal['id'];
    $user_id = $withdrawal['user_id'];
    $amount_naira = $withdrawal['amount'];
    
    $amount_kobo = $amount_naira * 100;

    logPaystackError("Withdrawal ID $withdrawal_id - account_details JSON: " . ($withdrawal['account_details'] ?? 'NULL'), $log_file);
    
    // Parse account_details JSON from withdrawals table (PRIMARY SOURCE)
    // CRITICAL: Use ONLY the account_details stored with this withdrawal record
    // Do NOT fallback to users table as it gets updated with each withdrawal and may contain
    // different bank details than what was originally submitted for this withdrawal
    // This prevents the PalmPay→OPay account mismatch issue
    $account_data = null;
    if (!empty($withdrawal['account_details'])) {
        $account_data = json_decode($withdrawal['account_details'], true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            logPaystackError("JSON decode error: " . json_last_error_msg(), $log_file);
            $account_data = null;
        }
    }
    
    // Ensure account_data is an array
    if (!is_array($account_data)) {
        $account_data = [];
    }
    
    // Get bank details ONLY from account_details JSON (withdrawal-specific data)
    // NEVER fallback to users table - it contains current info, not the info used for this withdrawal
    $account_number = null;
    $account_name = null;
    $bank_code = null;
    $bank_name = '';
    
    // Extract from account_details JSON only
    if (!empty($account_data['account_number'])) {
        $account_number = $account_data['account_number'];
    }
    if (!empty($account_data['account_name'])) {
        $account_name = $account_data['account_name'];
    }
    if (!empty($account_data['bank_code'])) {
        $bank_code = $account_data['bank_code'];
    }
    if (!empty($account_data['bank_name'])) {
        $bank_name = $account_data['bank_name'];
    }
    
    logPaystackError("Resolved bank details - Account: $account_number, Name: $account_name, Bank Code: $bank_code, Bank: $bank_name", $log_file);

    // Validate required fields
    if (empty($account_number) || empty($bank_code) || empty($account_name)) {
        $missing = [];
        if (empty($account_number)) $missing[] = 'account_number';
        if (empty($bank_code)) $missing[] = 'bank_code';
        if (empty($account_name)) $missing[] = 'account_name';
        
        $error_msg = 'Missing bank account details: ' . implode(', ', $missing);
        logPaystackError("VALIDATION FAILED - $error_msg", $log_file);
        
        logPaystackTransfer($withdrawal_id, $user_id, $amount_naira, null, null, null, 400, $error_msg, $conn);
        return ['success' => false, 'message' => $error_msg];
    }
    
    // Update the withdrawal's account_details if it was missing bank_code (legacy fix)
    $needs_update = false;
    if (empty($account_data['bank_code']) && !empty($bank_code)) {
        $account_data['bank_code'] = $bank_code;
        $needs_update = true;
    }
    if (empty($account_data['account_number']) && !empty($account_number)) {
        $account_data['account_number'] = $account_number;
        $needs_update = true;
    }
    if (empty($account_data['account_name']) && !empty($account_name)) {
        $account_data['account_name'] = $account_name;
        $needs_update = true;
    }
    if (empty($account_data['bank_name']) && !empty($bank_name)) {
        $account_data['bank_name'] = $bank_name;
        $needs_update = true;
    }
    
    if ($needs_update) {
        $updated_account_details = json_encode($account_data);
        $stmt = $conn->prepare("UPDATE withdrawals SET account_details = ? WHERE id = ?");
        $stmt->bind_param("si", $updated_account_details, $withdrawal_id);
        $stmt->execute();
        $stmt->close();
        logPaystackError("Updated withdrawal account_details with missing fields", $log_file);
    }

    // Step 1: Create or get Paystack recipient code if not already created
    $recipient_code = $withdrawal['paystack_recipient_code'];
    
    if (!$recipient_code) {
        logPaystackError("Creating new Paystack recipient for user $user_id", $log_file);
        
        // Pass the parsed bank details to createPaystackRecipient
        $recipient_result = createPaystackRecipient($account_number, $account_name, $bank_code, $log_file);
        
        if (!$recipient_result['success']) {
            logPaystackTransfer($withdrawal_id, $user_id, $amount_naira, null, null, null, 500, 
                              "Failed to create recipient: " . $recipient_result['message'], $conn);
            return ['success' => false, 'message' => 'Failed to create Paystack recipient', 'error' => $recipient_result['message']];
        }
        $recipient_code = $recipient_result['recipient_code'];
        
        logPaystackError("Created recipient code: $recipient_code", $log_file);
        
        // Save recipient code and bank details to users table for future use
        $stmt = $conn->prepare("
            UPDATE users 
            SET paystack_recipient_code = ?,
                withdrawal_account_number = ?,
                withdrawal_account_name = ?,
                withdrawal_bank_code = ?,
                withdrawal_bank_name = ?
            WHERE id = ?
        ");
        $stmt->bind_param("sssssi", $recipient_code, $account_number, $account_name, $bank_code, $bank_name, $user_id);
        $stmt->execute();
        $stmt->close();
        
        logPaystackError("Saved recipient code and bank details to users table for user $user_id", $log_file);
    }

    // Step 2: Initiate transfer via Paystack
    $transfer_data = [
        'source' => 'balance',
        'reason' => 'Prime Earnings Withdrawal - WD-' . $withdrawal_id,
        'amount' => $amount_kobo,
        'recipient' => $recipient_code,
        'reference' => 'WD-' . $withdrawal_id . '-' . time()
    ];

    logPaystackError("Initiating transfer - Amount: " . ($amount_kobo/100) . " NGN, Recipient: $recipient_code", $log_file);

    $ch = curl_init();
    curl_setopt_array($ch, [
        CURLOPT_URL => PAYSTACK_BASE_URL . '/transfer',
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_CUSTOMREQUEST => 'POST',
        CURLOPT_HTTPHEADER => [
            'Authorization: Bearer ' . PAYSTACK_SECRET_KEY,
            'Content-Type: application/json'
        ],
        CURLOPT_POSTFIELDS => json_encode($transfer_data),
        CURLOPT_TIMEOUT => 30,
        CURLOPT_SSL_VERIFYPEER => true
    ]);

    $response = curl_exec($ch);
    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $curl_error = curl_error($ch);
    curl_close($ch);

    if ($curl_error) {
        logPaystackError("CURL ERROR: $curl_error", $log_file);
    }

    $response_data = json_decode($response, true);
    
    logPaystackError("Paystack API Response (HTTP $http_code): " . substr($response, 0, 500), $log_file);

    logPaystackTransfer($withdrawal_id, $user_id, $amount_naira, null, $recipient_code,
                       json_encode($transfer_data), $http_code, json_encode($response_data), $conn);

    if ($http_code === 200 && isset($response_data['status']) && $response_data['status'] === true) {
        $transfer_id = $response_data['data']['transfer_code'] ?? $response_data['data']['id'];
        $paystack_status = $response_data['data']['status'] ?? 'pending';

        $stmt = $conn->prepare("
            UPDATE withdrawals 
            SET paystack_status = 'pending',
                paystack_transfer_id = ?,
                paystack_initiated_at = NOW()
            WHERE id = ?
        ");
        $stmt->bind_param("si", $transfer_id, $withdrawal_id);
        $stmt->execute();
        $stmt->close();

        // Send notification email to user
        sendWithdrawalTransferEmail($withdrawal['email'], $withdrawal['full_name'], 
                                    $amount_naira, $transfer_id, 'initiated');

        return [
            'success' => true,
            'transfer_id' => $transfer_id,
            'message' => 'Transfer initiated successfully'
        ];
    } else {
        $error_message = $response_data['message'] ?? 'Unknown error occurred';
        
        logPaystackError("TRANSFER FAILED - Error: $error_message", $log_file);
        
        $stmt = $conn->prepare("
            UPDATE withdrawals 
            SET paystack_status = 'failed',
                paystack_error_message = ?
            WHERE id = ?
        ");
        $stmt->bind_param("si", $error_message, $withdrawal_id);
        $stmt->execute();
        $stmt->close();

        return [
            'success' => false,
            'message' => 'Failed to initiate Paystack transfer',
            'error' => $error_message
        ];
    }
}

/**
 * Create a Paystack recipient for the user's bank account
 * Now accepts bank details as parameters instead of reading from withdrawal array
 */
function createPaystackRecipient($account_number, $account_name, $bank_code, $log_file) {
    
    if (!$account_number || !$bank_code) {
        logPaystackError("createPaystackRecipient FAILED - Missing: account=$account_number, bank_code=$bank_code", $log_file);
        return ['success' => false, 'message' => 'Missing bank account details'];
    }

    $recipient_data = [
        'type' => 'nuban',
        'name' => $account_name,
        'account_number' => $account_number,
        'bank_code' => $bank_code,
        'currency' => 'NGN'
    ];

    logPaystackError("Creating recipient with data: " . json_encode($recipient_data), $log_file);

    $ch = curl_init();
    curl_setopt_array($ch, [
        CURLOPT_URL => PAYSTACK_BASE_URL . '/transferrecipient',
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_CUSTOMREQUEST => 'POST',
        CURLOPT_HTTPHEADER => [
            'Authorization: Bearer ' . PAYSTACK_SECRET_KEY,
            'Content-Type: application/json'
        ],
        CURLOPT_POSTFIELDS => json_encode($recipient_data),
        CURLOPT_TIMEOUT => 30,
        CURLOPT_SSL_VERIFYPEER => true
    ]);

    $response = curl_exec($ch);
    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $curl_error = curl_error($ch);
    curl_close($ch);

    if ($curl_error) {
        logPaystackError("CURL ERROR in createPaystackRecipient: $curl_error", $log_file);
    }

    $response_data = json_decode($response, true);
    
    logPaystackError("Create Recipient Response (HTTP $http_code): " . substr($response, 0, 500), $log_file);

    if ($http_code === 201 && isset($response_data['status']) && $response_data['status'] === true) {
        return [
            'success' => true,
            'recipient_code' => $response_data['data']['recipient_code']
        ];
    } else {
        $error = $response_data['message'] ?? 'Failed to create recipient';
        logPaystackError("createPaystackRecipient FAILED - $error", $log_file);
        return ['success' => false, 'message' => $error];
    }
}

/**
 * Log all Paystack API interactions to database
 */
function logPaystackTransfer($withdrawal_id, $user_id, $amount, $transfer_id, $recipient_code, 
                             $request_data, $status_code, $response_data, $conn) {
    $stmt = $conn->prepare("
        INSERT INTO paystack_transfer_logs 
        (withdrawal_id, user_id, transfer_amount, paystack_transfer_id, recipient_code, 
         api_request, api_response, api_status_code, error_message)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    ");
    
    $error_msg = null;
    if (is_array($response_data) && isset($response_data['message'])) {
        $error_msg = $response_data['message'];
    } elseif (!is_array($response_data)) {
        $error_msg = $response_data;
    }

    $stmt->bind_param("iidssssis", $withdrawal_id, $user_id, $amount, $transfer_id, 
                      $recipient_code, $request_data, $response_data, $status_code, $error_msg);
    $stmt->execute();
    $stmt->close();
}

/**
 * Send email notification about transfer status
 */
function sendWithdrawalTransferEmail($email, $name, $amount, $transfer_id, $status) {
    $subject = 'Prime Earnings Withdrawal - ' . ucfirst($status);
    
    if ($status === 'initiated') {
        $message = "Hi $name,<br><br>";
        $message .= "Your Prime Earnings withdrawal of ₦" . number_format($amount, 2) . " has been initiated.<br>";
        $message .= "Transfer ID: $transfer_id<br>";
        $message .= "This will be processed to your account within 24-48 hours.<br><br>";
        $message .= "Thank you for using Earnova Digital Hub!";
    } elseif ($status === 'completed') {
        $message = "Hi $name,<br><br>";
        $message .= "Great news! Your Prime Earnings withdrawal of ₦" . number_format($amount, 2) . " has been successfully completed.<br>";
        $message .= "The funds should now be in your bank account.<br><br>";
        $message .= "Thank you for using Earnova!";
    } else {
        $message = "Hi $name,<br><br>";
        $message .= "Your Prime Earnings withdrawal could not be processed at this time.<br>";
        $message .= "Please contact support for assistance.<br><br>";
        $message .= "Thank you for using Earnova Digital Hub!";
    }

    // Use existing email function from includes/email.php if available
    if (function_exists('sendEmail')) {
        sendEmail($email, $subject, $message);
    }
}
?>
