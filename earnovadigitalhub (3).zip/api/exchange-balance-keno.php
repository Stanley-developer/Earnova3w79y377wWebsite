<?php
require_once '../config/database.php';
require_once '../includes/session.php';

header('Content-Type: application/json');

// Require authentication
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit;
}

$user_id = $_SESSION['user_id'];

try {
    $pdo = getDBConnection();
    
    // Get POST data
    $data = json_decode(file_get_contents('php://input'), true);
    $amount = floatval($data['amount'] ?? 0);
    
    // Validate amount
    if ($amount <= 0) {
        echo json_encode(['success' => false, 'message' => 'Invalid amount']);
        exit;
    }
    
    // Get user balance
    $stmt = $pdo->prepare("SELECT game_earnings, task_earnings, total_balance FROM balances WHERE user_id = ?");
    $stmt->execute([$user_id]);
    $balance = $stmt->fetch();
    
    if (!$balance) {
        echo json_encode(['success' => false, 'message' => 'Balance not found']);
        exit;
    }
    
    // Check if user has enough game_earnings
    if ($balance['game_earnings'] < $amount) {
        echo json_encode(['success' => false, 'message' => 'Insufficient game earnings']);
        exit;
    }
    
    $stmt = $pdo->prepare("
        UPDATE balances 
        SET game_earnings = game_earnings - ?, 
            task_earnings = task_earnings + ?,
            total_balance = total_balance + ?
        WHERE user_id = ?
    ");
    $stmt->execute([$amount, $amount, $amount, $user_id]);
    
    $stmt = $pdo->prepare("
        INSERT INTO transactions (user_id, transaction_type, amount, balance_type, description, reference_id)
        VALUES (?, 'balance_exchange', ?, 'task', 'Exchanged Game Earnings to Task Balance', ?)
    ");
    $reference_id = 'EXCHANGE_' . time() . '_' . $user_id;
    $stmt->execute([$user_id, $amount, $reference_id]);
    
    // Get updated balances
    $stmt = $pdo->prepare("SELECT game_earnings, task_earnings, total_balance FROM balances WHERE user_id = ?");
    $stmt->execute([$user_id]);
    $updated_balance = $stmt->fetch();
    
    echo json_encode([
        'success' => true,
        'game_earnings' => $updated_balance['game_earnings'],
        'task_earnings' => $updated_balance['task_earnings'],
        'total_balance' => $updated_balance['total_balance']
    ]);
    
} catch (PDOException $e) {
    error_log("Exchange Balance Keno Error: " . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'An error occurred']);
}
?>
