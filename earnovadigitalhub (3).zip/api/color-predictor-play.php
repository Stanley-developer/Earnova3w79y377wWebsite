<?php
require_once '../config/database.php';
require_once '../includes/session.php';

header('Content-Type: application/json');

// Require authentication
requireLogin();

// Get current user
$user = getCurrentUser();
$user_id = $user['id'];

try {
    $pdo = getDBConnection();
    
    // Get request data
    $input = json_decode(file_get_contents('php://input'), true);
    $selected_color = $input['selected_color'] ?? '';
    $bet_amount = floatval($input['bet_amount'] ?? 0);
    $is_free_play = boolval($input['is_free_play'] ?? false);
    
    // Validate input
    if (!in_array($selected_color, ['red', 'green', 'blue'])) {
        echo json_encode(['success' => false, 'message' => 'Invalid color selected']);
        exit;
    }
    
    // Get user data
    $stmt = $pdo->prepare("
        SELECT u.*, b.task_earnings 
        FROM users u 
        LEFT JOIN balances b ON u.id = b.user_id 
        WHERE u.id = ?
    ");
    $stmt->execute([$user_id]);
    $user_data = $stmt->fetch();
    
    if (!$user_data) {
        echo json_encode(['success' => false, 'message' => 'User not found']);
        exit;
    }
    
    // Check if premium member
    if ($user_data['membership_type'] !== 'premium') {
        echo json_encode(['success' => false, 'message' => 'Premium membership required']);
        exit;
    }
    
    if ($is_free_play) {
        if ($user_data['color_predictor_free_plays'] <= 0) {
            echo json_encode(['success' => false, 'message' => 'No free plays remaining']);
            exit;
        }
        $bet_amount = 0;
    } else {
        if ($bet_amount < 1000) {
            echo json_encode(['success' => false, 'message' => 'Minimum bet amount is ₦1,000']);
            exit;
        }
        
        // Check if user has sufficient balance
        if ($user_data['task_earnings'] < $bet_amount) {
            echo json_encode(['success' => false, 'message' => 'Insufficient task balance']);
            exit;
        }
    }
    
    // x0 (lose) - 50%, x1.5 - 30%, x2 - 15%, x3 - 5%
    $rand = mt_rand(1, 100);
    if ($rand <= 50) {
        $multiplier = 0; // Lose
    } elseif ($rand <= 80) {
        $multiplier = 1.5;
    } elseif ($rand <= 95) {
        $multiplier = 2;
    } else {
        $multiplier = 3; // Very rare
    }
    
    // Generate random result color
    $colors = ['red', 'green', 'blue'];
    $result_color = $colors[array_rand($colors)];
    
    // Calculate win amount
    $win_amount = $bet_amount * $multiplier;
    
    if ($multiplier > 0 && $win_amount < 50 && !$is_free_play) {
        $win_amount = 50;
    }
    
    // Begin transaction
    $pdo->beginTransaction();
    
    try {
        // Deduct bet amount if not free play
        if (!$is_free_play && $bet_amount > 0) {
            $stmt = $pdo->prepare("
                UPDATE balances 
                SET task_earnings = task_earnings - ?, 
                    total_balance = total_balance - ? 
                WHERE user_id = ?
            ");
            $stmt->execute([$bet_amount, $bet_amount, $user_id]);
        }
        
        // Add winnings if won
        $net_profit = $win_amount - $bet_amount;
        if ($win_amount > 0) {
            $stmt = $pdo->prepare("
                UPDATE balances 
                SET task_earnings = task_earnings + ?, 
                    total_balance = total_balance + ? 
                WHERE user_id = ?
            ");
            $stmt->execute([$win_amount, $win_amount, $user_id]);
        }
        
        // Update free plays if free play
        if ($is_free_play) {
            $stmt = $pdo->prepare("
                UPDATE users 
                SET color_predictor_free_plays = color_predictor_free_plays - 1 
                WHERE id = ?
            ");
            $stmt->execute([$user_id]);
        }
        
        // Record game
        $stmt = $pdo->prepare("
            INSERT INTO color_predictor_games 
            (user_id, bet_amount, selected_color, result_color, multiplier, win_amount, is_free_play) 
            VALUES (?, ?, ?, ?, ?, ?, ?)
        ");
        $stmt->execute([
            $user_id, 
            $bet_amount, 
            $selected_color, 
            $result_color, 
            $multiplier, 
            $win_amount, 
            $is_free_play
        ]);
        
        // Update or create stats
        $stmt = $pdo->prepare("
            INSERT INTO color_predictor_stats 
            (user_id, total_games, total_wins, total_losses, total_wagered, total_won, total_profit, biggest_win, win_streak, best_win_streak) 
            VALUES (?, 1, ?, ?, ?, ?, ?, ?, ?, ?)
            ON DUPLICATE KEY UPDATE
                total_games = total_games + 1,
                total_wins = total_wins + ?,
                total_losses = total_losses + ?,
                total_wagered = total_wagered + ?,
                total_won = total_won + ?,
                total_profit = total_profit + ?,
                biggest_win = GREATEST(biggest_win, ?),
                win_streak = IF(? > 0, win_streak + 1, 0),
                best_win_streak = GREATEST(best_win_streak, IF(? > 0, win_streak + 1, 0))
        ");
        
        $is_win = $multiplier > 0 ? 1 : 0;
        $is_loss = $multiplier > 0 ? 0 : 1;
        
        $stmt->execute([
            $user_id,
            $is_win, $is_loss,
            $bet_amount, $win_amount, $net_profit,
            $win_amount,
            $is_win, $is_win,
            // ON DUPLICATE KEY UPDATE values
            $is_win, $is_loss,
            $bet_amount, $win_amount, $net_profit,
            $win_amount,
            $multiplier, $multiplier
        ]);
        
        // Log transaction if not free play
        if (!$is_free_play) {
            $description = $multiplier > 0 
                ? "Color Predictor Win: x{$multiplier} on {$result_color}" 
                : "Color Predictor Loss on {$result_color}";
            
            $stmt = $pdo->prepare("
                INSERT INTO transactions 
                (user_id, transaction_type, amount, balance_type, description, created_at) 
                VALUES (?, ?, ?, 'task', ?, NOW())
            ");
            $stmt->execute([
                $user_id,
                $multiplier > 0 ? 'game_win' : 'game_loss',
                $multiplier > 0 ? $win_amount : $bet_amount,
                $description
            ]);
        }
        
        $pdo->commit();
        
        // Get updated balance and free plays
        $stmt = $pdo->prepare("
            SELECT b.task_earnings, u.color_predictor_free_plays 
            FROM users u 
            LEFT JOIN balances b ON u.id = b.user_id 
            WHERE u.id = ?
        ");
        $stmt->execute([$user_id]);
        $updated_data = $stmt->fetch();
        
        echo json_encode([
            'success' => true,
            'result_color' => $result_color,
            'multiplier' => $multiplier,
            'win_amount' => $win_amount,
            'new_balance' => $updated_data['task_earnings'],
            'free_plays_remaining' => $updated_data['color_predictor_free_plays']
        ]);
        
    } catch (Exception $e) {
        $pdo->rollBack();
        error_log("Color Predictor Play Error: " . $e->getMessage());
        echo json_encode(['success' => false, 'message' => 'Failed to process game']);
    }
    
} catch (PDOException $e) {
    error_log("Color Predictor API Error: " . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'Database error']);
}
