<?php
require_once '../config/database.php';
require_once '../includes/session.php';

header('Content-Type: application/json');

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'Not authenticated']);
    exit;
}

$user_id = $_SESSION['user_id'];

// Get JSON input
$input = json_decode(file_get_contents('php://input'), true);
$skill_id = intval($input['skill_id'] ?? 0);

if ($skill_id <= 0) {
    echo json_encode(['success' => false, 'message' => 'Invalid skill ID']);
    exit;
}

try {
    $pdo = getDBConnection();
    
    $stmt = $pdo->prepare("INSERT INTO skill_clicks (skill_id, user_id, clicked_at) VALUES (?, ?, NOW())");
    $stmt->execute([$skill_id, $user_id]);
    
    $stmt = $pdo->prepare("UPDATE skills SET clicks = clicks + 1 WHERE id = ?");
    $stmt->execute([$skill_id]);
    
    echo json_encode(['success' => true, 'message' => 'Click tracked']);
} catch (PDOException $e) {
    error_log("Skill click tracking error: " . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'Failed to track click']);
}
?>
