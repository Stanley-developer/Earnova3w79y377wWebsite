<?php
/**
 * Newsletter Confirmation Handler
 * Confirms email subscription when user clicks confirmation link
 */

session_start();
require_once '../config/database.php';

error_log("[NEWSLETTER] Confirm endpoint called");

$token = trim($_GET['token'] ?? '');
$email = trim($_GET['email'] ?? '');

if (empty($token) || empty($email)) {
    showErrorPage("Invalid confirmation link.");
    exit();
}

try {
    // Look for matching token + email
    $stmt = $conn->prepare("SELECT id, is_confirmed FROM newsletters_subscribers 
                            WHERE email = ? AND confirmation_token = ?");
    $stmt->bind_param("ss", $email, $token);
    $stmt->execute();
    $result = $stmt->get_result();

    // ========== CASE 1 — Token does NOT match but email exists (Already verified) ==========
    if ($result->num_rows === 0) {

        $checkEmail = $conn->prepare("SELECT is_confirmed FROM newsletters_subscribers WHERE email = ?");
        $checkEmail->bind_param("s", $email);
        $checkEmail->execute();
        $emailResult = $checkEmail->get_result();

        if ($emailResult->num_rows > 0) {
            $sub = $emailResult->fetch_assoc();

            if ($sub['is_confirmed']) {
                showAlreadyConfirmedPage($email);
                exit();
            }
        }

        // Token is invalid and email isn't confirmed
        showErrorPage("Invalid or expired confirmation link.");
        exit();
    }

    // ========== CASE 2 — Token matches ==========
    $subscriber = $result->fetch_assoc();

    // If already confirmed but token still existed (rare case)
    if ($subscriber['is_confirmed']) {
        showAlreadyConfirmedPage($email);
        exit();
    }

    // ========== CASE 3 — First time confirmation ==========
    $confirmed_at = date('Y-m-d H:i:s');

    $update = $conn->prepare("UPDATE newsletters_subscribers
                              SET is_confirmed = 1, confirmed_at = ?, confirmation_token = NULL
                              WHERE email = ? AND confirmation_token = ?");
    $update->bind_param("sss", $confirmed_at, $email, $token);
    $update->execute();

    showSuccessPage($email);
    exit();

} catch (Exception $e) {
    error_log("[NEWSLETTER] Confirmation error: " . $e->getMessage());
    showErrorPage("An error occurred. Please try again.");
    exit();
}


/* ================================================================
   COMPONENTS: SUCCESS / ALREADY CONFIRMED / ERROR (Same UI Style)
   ================================================================ */

function showSuccessPage($email) {
    renderPage(
        "Email Confirmed!",
        "Your email <b>$email</b> has been successfully verified. You are now subscribed to Earnova Digital Hub newsletter.",
        "success"
    );
}

function showAlreadyConfirmedPage($email) {
    renderPage(
        "Email Already Verified",
        "Your email <b>$email</b> is already confirmed. You're fully subscribed and good to go!",
        "verified"
    );
}

function showErrorPage($message) {
    renderPage(
        "Invalid Link",
        $message,
        "error"
    );
}

function renderPage($title, $message, $type = "success") {
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    

    <!-- Page Title -->
    <title>EARNOVA - Earning, Gaming & Social Reward Platform</title>

    <!-- Favicon -->
    <link rel="icon" type="image/png" href="logo.png">

    <!-- SEO Meta Tags -->
    <meta name="description" content="EARNOVA is a gaming and social reward platform where users earn daily through tasks, games, and engagement. Join today and start earning instantly!">
    <meta name="keywords" content="EARNOVA, earn money online, gaming rewards, social tasks, daily rewards, earn coins, Nigeria, CBI MONIE, online income, game platform, reward system">
    <meta name="author" content="EARNOVA Team">

    <!-- Open Graph (for social media sharing) -->
    <meta property="og:title" content="EARNOVA - Earning, Gaming & Social Reward Platform">
    <meta property="og:description" content="Earn daily by completing gaming and social tasks on EARNOVA. Join now and start growing your income online!">
    <meta property="og:image" content="logo.png">
    <meta property="og:type" content="website">
    <meta property="og:url" content="https://earnova.com"> <!-- replace with your actual domain -->

    <!-- Optional: Twitter Card -->
    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:title" content="EARNOVA - Earning, Gaming & Social Reward Platform">
    <meta name="twitter:description" content="Earn daily through gaming, social tasks, and rewards on EARNOVA.">
    <meta name="twitter:image" content="logo.png">
</head>
    <title><?php echo $title; ?> - Earnova Digital Hub</title>
    <style>
        body {
            font-family: "Titillium Web", "Segoe UI", sans-serif;
            background: radial-gradient(circle at 0% 0%, rgba(61,116,255,0.30), transparent 55%),
                        radial-gradient(circle at 100% 0%, rgba(77,225,193,0.22), transparent 45%),
                        linear-gradient(180deg, #030922, #0a164a);
            color: #f5f9ff;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            text-align: center;
            padding: 20px;
        }

        .box {
            max-width: 520px;
            width: 100%;
            padding: 50px 40px;
            background: rgba(13, 24, 62, 0.84);
            border: 1px solid rgba(86,139,241,0.3);
            border-radius: 26px;
            box-shadow: 0 40px 120px rgba(4,10,36,0.65);
            animation: fadeIn 0.7s ease;
        }

        @keyframes fadeIn {
            from { opacity:0; transform: translateY(20px); }
            to   { opacity:1; transform: translateY(0); }
        }

        .checkmark-box {
            width: 90px;
            height: 90px;
            border-radius: 50%;
            border: 3px solid rgba(77,225,193,0.3);
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 25px;
            animation: pulseGlow 1.6s infinite;
        }

        @keyframes pulseGlow {
            0% { box-shadow: 0 0 0 0 rgba(77,225,193,0.3); }
            70% { box-shadow: 0 0 0 22px rgba(77,225,193,0); }
            100% { box-shadow: 0 0 0 0 rgba(77,225,193,0); }
        }

        h1 {
            font-size: 2rem;
            margin-bottom: 12px;
            background: linear-gradient(135deg, #4de1c1, #2c5bf5);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        p {
            color: rgba(205,219,255,0.8);
            line-height: 1.7;
            margin-bottom: 25px;
        }

        a {
            color: #4de1c1;
            text-decoration: none;
            font-size: 1rem;
            font-weight: 600;
        }

    </style>
</head>
<body>

    <div class="box">
        <img src="https://earnova-digital-hub.com/logo.png" style="height: 45px; margin-bottom: 25px;">

        <div class="checkmark-box">
            <svg width="60" height="60" viewBox="0 0 52 52">
                <path d="M14 27l7 7 17-17" fill="none" stroke="#4de1c1" stroke-width="5" stroke-linecap="round" stroke-linejoin="round"/>
            </svg>
        </div>

        <h1><?php echo $title; ?></h1>
        <p><?php echo $message; ?></p>

        <a href="https://earnova-digital-hub.com">← Return to Earnova Digital Hub</a>
    </div>

</body>
</html>
<?php
}
