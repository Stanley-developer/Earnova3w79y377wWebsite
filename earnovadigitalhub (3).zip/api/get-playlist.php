<?php
require_once '../config/database.php';
require_once '../includes/session.php';

header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit;
}

$user_id = $_SESSION['user_id'];

try {
    $pdo = getDBConnection();
    
    $stmt = $pdo->prepare("
        SELECT * FROM user_playlists 
        WHERE user_id = ? 
        ORDER BY added_at DESC
    ");
    $stmt->execute([$user_id]);
    $playlist = $stmt->fetchAll();
    
    echo json_encode(['success' => true, 'playlist' => $playlist]);
    
} catch (PDOException $e) {
    error_log("Get Playlist Error: " . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'Error fetching playlist']);
}
?>
