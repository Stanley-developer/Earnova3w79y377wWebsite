<?php
require_once '../config/database.php';
require_once '../includes/session.php';

requireLogin();
checkSessionTimeout();

header('Content-Type: application/json');

$user = getCurrentUser();
$userId = $user['id'];

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);
$email = trim($input['email'] ?? '');
$trackId = trim($input['track_id'] ?? '');

if (empty($email)) {
    echo json_encode(['success' => false, 'message' => 'Email is required']);
    exit;
}

if (empty($trackId)) {
    echo json_encode(['success' => false, 'message' => 'Track ID is required']);
    exit;
}

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    echo json_encode(['success' => false, 'message' => 'Invalid email address']);
    exit;
}

try {
    $pdo = getDBConnection();
    
    $stmt = $pdo->prepare("
        SELECT id FROM stream_ad_verified_emails 
        WHERE email = ? AND track_id = ?
        LIMIT 1
    ");
    $stmt->execute([$email, $trackId]);
    $existingEmail = $stmt->fetch();
    
    if ($existingEmail) {
        echo json_encode([
            'success' => false, 
            'message' => 'This email has already been used to verify this track. Each email can only verify each track once.',
            'duplicate' => true
        ]);
        exit;
    }
    
        // Capture current user id and username (extended metadata)
        $user_id = $userId;
        $username = $user['username'] ?? null;

        // Check if there's an existing row for the same email (regardless of track). If so, update that row
        // to include user metadata and track_id, otherwise insert a new row.
        $stmt2 = $pdo->prepare("SELECT id, track_id, user_id FROM stream_ad_verified_emails WHERE email = ? LIMIT 1");
        $stmt2->execute([$email]);
        $existingByEmail = $stmt2->fetch();
    
        $stmt = $pdo->prepare("SELECT id, user_id, username FROM stream_ad_verified_emails WHERE email = ? AND track_id = ? LIMIT 1");
        $stmt->execute([$email, $trackId]);
        $existingRow = $stmt->fetch();

        $user_id = $userId;
        $username = $user['username'] ?? null;

        if ($existingRow) {
            // Only update user_id/username if missing
            if (empty($existingRow['user_id']) || empty($existingRow['username'])) {
                $updateStmt = $pdo->prepare("UPDATE stream_ad_verified_emails SET user_id = ?, username = ?, verified_at = CURRENT_TIMESTAMP WHERE id = ?");
                $updateStmt->execute([$user_id, $username, $existingRow['id']]);
            }
        } else {
            // Always insert a new row for each (email, track_id) combination
            $insertStmt = $pdo->prepare("INSERT INTO stream_ad_verified_emails (email, track_id, user_id, username) VALUES (?, ?, ?, ?)");
            $insertStmt->execute([$email, $trackId, $user_id, $username]);
        }

        // Persist the verified email in the session to use as a fallback in stream-record API
        if (!empty($email)) {
            $_SESSION['stream_ad_verified_email_' . $trackId] = $email;
        }

        // Persist the verified email in the session to use as a fallback in stream-record API
        if (!empty($email)) {
            $_SESSION['stream_ad_verified_email_' . $trackId] = $email;
        }
    
    echo json_encode([
        'success' => true,
        'message' => 'Email verified successfully for audio ad completion'
    ]);
    
} catch (PDOException $e) {
    error_log("Ad Email Verification Error: " . $e->getMessage());
    echo json_encode([
        'success' => false,
        'message' => 'An error occurred during verification'
    ]);
}
?>
