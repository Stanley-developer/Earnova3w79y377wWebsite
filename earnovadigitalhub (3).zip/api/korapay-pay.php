<?php
/**
 * korapay-pay.php (Rewritten)
 * KoraPay Payment Initialization endpoint
 * Endpoint: /api/korapay-pay.php
 *
 * Notes:
 * - Requires config/korapay.php (contains initializeKorapayCharge function)
 * - Requires config/database.php and includes/session.php
 * - Put KORAPAY keys in env variables and set KORAPAY_SANDBOX_MODE as needed
 * - Use ?debug=1 to enable verbose error output temporarily
 */

// Enable debug via environment or ?debug=1
$ENV_DEBUG = getenv('KORAPAY_DEBUG');
$REQ_DEBUG = isset($_GET['debug']) && $_GET['debug'] === '1';
$DEBUG = ($ENV_DEBUG === '1' || $REQ_DEBUG === true);

if ($DEBUG) {
    ini_set('display_errors', 1);
    ini_set('display_startup_errors', 1);
    error_reporting(E_ALL);
} else {
    ini_set('display_errors', 0);
    error_reporting(E_ALL & ~E_NOTICE);
}

header('Content-Type: application/json; charset=utf-8');

// Required includes
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/korapay.php';
require_once __DIR__ . '/../includes/session.php';

// Ensure session started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Helper: return JSON and exit
function json_exit($code, $payload) {
    http_response_code($code);
    echo json_encode($payload);
    exit;
}

// Basic error handler to convert warnings/notices to exceptions in debug mode
set_error_handler(function($errno, $errstr, $errfile, $errline) use ($DEBUG) {
    error_log("PHP Error [$errno]: $errstr in $errfile:$errline");
    if ($DEBUG) {
        throw new ErrorException($errstr, 0, $errno, $errfile, $errline);
    }
});

// Verify authentication
if (!function_exists('isLoggedIn') || !isLoggedIn()) {
    json_exit(401, ['status' => false, 'message' => 'Not authenticated']);
}

$user_id = $_SESSION['user_id'] ?? null;
if (!$user_id) {
    json_exit(401, ['status' => false, 'message' => 'Invalid session']);
}

// Fetch user details
try {
    $pdo = getDBConnection();
    $stmt = $pdo->prepare('SELECT id, full_name, email FROM users WHERE id = ? LIMIT 1');
    $stmt->execute([$user_id]);
    $user_data = $stmt->fetch(PDO::FETCH_ASSOC);
} catch (Exception $e) {
    error_log('DB error: ' . $e->getMessage());
    json_exit(500, ['status' => false, 'message' => 'Database error']);
}

if (!$user_data) {
    json_exit(404, ['status' => false, 'message' => 'User not found']);
}

// Read JSON input (also allow form fallback)
$raw = file_get_contents('php://input');
$input = json_decode($raw, true);
if (!is_array($input)) {
    // fallback to POST form data
    $input = $_POST;
}

$payment_type = isset($input['payment_type']) ? trim($input['payment_type']) : null;
$amount_raw = $input['amount'] ?? null;
$plan_duration = $input['plan_duration'] ?? 'yearly';

// Normalize amount: korapay expects integer (in Naira), avoid floats
$amount = null;
if (is_numeric($amount_raw)) {
    // if amount provided as float e.g. 1000.00, convert to int
    $amount = intval(round(floatval($input['amount']))); // convert to kobo

}

// Basic validation
if (!$payment_type || !$amount || $amount <= 0) {
    json_exit(400, ['status' => false, 'message' => 'Invalid payment parameters']);
}

// Build unique reference
$reference = sprintf('EARNOVA-%s-%d-%d-%04d', preg_replace('/[^A-Z0-9_\-]/i', '', $payment_type), $user_id, time(), random_int(0, 9999));

// Prepare payload according to Korapay requirements
$host = $_SERVER['HTTP_HOST'] ?? 'earnova-digital-hub.com';
$notification_url = 'https://' . $host . '/api/korapay-webhook.php';
$return_url = 'https://' . $host . '/membership.php';


$payload = [
    'amount' => $amount,      // in Naira
    'currency' => 'NGN',
    'reference' => $reference,
    'customer' => [
        'name' => $user_data['full_name'],
        'email' => $user_data['email']
    ],
    'metadata' => [
        'user_id' => strval($user_id),
        'payment_type' => strval($payment_type),
        'plan_duration' => strval($plan_duration),
        'platform' => 'Earnova Digital Hub'
    ],
    'notification_url' => $notification_url,
    // Note: Korapay only accepts redirect_url (not return_url or success_url)
    'redirect_url' => $return_url
];




// Log minimal debug info
error_log('KORAPAY_INIT: user=' . $user_id . ' ref=' . $reference . ' amount=' . $amount);
if ($DEBUG) {
    error_log('KORAPAY_PAYLOAD: ' . json_encode($payload));
}

// Call Korapay
try {
    if (!function_exists('initializeKorapayCharge')) {
        throw new Exception('Korapay integration not loaded (initializeKorapayCharge missing)');
    }

error_log("Korapay Payload: " . json_encode($payload, JSON_PRETTY_PRINT));

    $response = initializeKorapayCharge($payload);

    // Defensive handling: many Korapay responses set top-level status or data structure
    if (!is_array($response)) {
        throw new Exception('Invalid response from Korapay');
    }

    $http_code = $response['http_code'] ?? null;
    $status_field = $response['status'] ?? null; // some responses use boolean
    $data = $response['data'] ?? null;
    $raw_response = $response['raw_response'] ?? null;

    error_log('KORAPAY_RESPONSE_HTTP: ' . var_export($http_code, true));
    if ($DEBUG) {
        error_log('KORAPAY_RAW: ' . substr($raw_response ?? json_encode($response), 0, 4000));
    }

    // Success criteria: status === true and checkout_url exists
    if ($status_field === true && is_array($data) && !empty($data['checkout_url'])) {
        json_exit(200, [
            'status' => true,
            'message' => 'Checkout initialized',
            'checkout_url' => $data['checkout_url'],
            'reference' => $data['reference'] ?? $reference
        ]);
    }

    // Sometimes Korapay returns success boolean inside data
    if (is_array($data) && !empty($data['checkout_url'])) {
        json_exit(200, [
            'status' => true,
            'message' => 'Checkout initialized',
            'checkout_url' => $data['checkout_url'],
            'reference' => $data['reference'] ?? $reference
        ]);
    }

    // Otherwise, extract message
    $message = $response['message'] ?? ($data['message'] ?? 'Payment initialization failed');
    throw new Exception($message);

} catch (Exception $e) {
    error_log('KORAPAY_INIT_ERROR: ' . $e->getMessage());
    if ($DEBUG) {
        json_exit(500, [
            'status' => false,
            'message' => $e->getMessage(),
            'file' => $e->getFile(),
            'line' => $e->getLine(),
            'trace' => $e->getTraceAsString()
        ]);
    }
    json_exit(500, [
        'status' => false,
        'message' => $e->getMessage()
    ]);
}

?>
