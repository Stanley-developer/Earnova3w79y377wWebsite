<?php
session_start();
require_once '../config/database.php';

header('Content-Type: application/json');

define('PAYSTACK_SECRET_KEY', 'sk_live_7ceb76976f99b57f94ff8ba1e7d1940254b052ba'); // Replace with actual key

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
    exit;
}

$account_number = $_POST['account_number'] ?? '';
$bank_code = $_POST['bank_code'] ?? '';
$resolve_only = $_POST['resolve_only'] ?? false;

if (empty($account_number)) {
    echo json_encode(['success' => false, 'message' => 'Account number is required']);
    exit;
}

if ($resolve_only && empty($bank_code)) {
    // Try to resolve account across all banks
    $curl = curl_init();
    curl_setopt_array($curl, array(
        CURLOPT_URL => "https://api.paystack.co/bank/resolve?account_number={$account_number}",
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HTTPHEADER => array(
            "Authorization: Bearer " . PAYSTACK_SECRET_KEY
        ),
    ));

    $response = curl_exec($curl);
    $err = curl_error($curl);
    curl_close($curl);

    if (!$err) {
        $result = json_decode($response, true);
        
        if ($result['status'] === true && isset($result['data'])) {
            // Successfully resolved with one bank
            echo json_encode([
                'success' => true,
                'account_name' => $result['data']['account_name'],
                'account_number' => $result['data']['account_number'],
                'bank_code' => $result['data']['bank_id'] ?? '',
                'bank_name' => $result['data']['bank_name'] ?? ''
            ]);
            exit;
        }
    }
    
    // If resolution failed, return failure so frontend shows bank select
    echo json_encode(['success' => false, 'message' => 'Please select your bank to verify account']);
    exit;
}

if (empty($bank_code)) {
    echo json_encode(['success' => false, 'message' => 'Bank code is required']);
    exit;
}

$curl = curl_init();
curl_setopt_array($curl, array(
    CURLOPT_URL => "https://api.paystack.co/bank/resolve?account_number={$account_number}&bank_code={$bank_code}",
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_HTTPHEADER => array(
        "Authorization: Bearer " . PAYSTACK_SECRET_KEY
    ),
));

$response = curl_exec($curl);
$err = curl_error($curl);
curl_close($curl);

if ($err) {
    echo json_encode(['success' => false, 'message' => 'Error verifying account']);
    exit;
}

$result = json_decode($response, true);

if ($result['status'] === true) {
    echo json_encode([
        'success' => true,
        'account_name' => $result['data']['account_name'],
        'account_number' => $result['data']['account_number'],
        'bank_code' => $bank_code
    ]);
} else {
    echo json_encode(['success' => false, 'message' => $result['message'] ?? 'Could not verify account']);
}
?>
