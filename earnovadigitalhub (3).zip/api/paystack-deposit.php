<?php
require_once '../config/database.php';
require_once '../includes/session.php';

header('Content-Type: application/json');

// Require authentication
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit;
}

$user_id = $_SESSION['user_id'];

// Paystack keys
define('PAYSTACK_SECRET_KEY', 'sk_test_6c1c62ff73bf54c90de32dcd3f8d0dc8941c8e17');
define('PAYSTACK_PUBLIC_KEY', 'pk_test_2889acc30e717c743676ced0e02e0e1ad4d274fe');

try {
    $pdo = getDBConnection();
    
    // Get POST data
    $data = json_decode(file_get_contents('php://input'), true);
    $action = $data['action'] ?? '';
    
    if ($action === 'initialize') {
        $amount = floatval($data['amount'] ?? 0);
        $email = $data['email'] ?? '';
        
        // Validate amount (minimum ₦1000)
        if ($amount < 1000) {
            echo json_encode(['success' => false, 'message' => 'Minimum deposit is ₦1,000']);
            exit;
        }
        
        // Initialize Paystack transaction
        $url = "https://api.paystack.co/transaction/initialize";
        $fields = [
            'email' => $email,
            'amount' => $amount * 100, // Convert to kobo
            'metadata' => json_encode([
                'user_id' => $user_id,
                'purpose' => 'game_deposit'
            ])
        ];
        
        $fields_string = http_build_query($fields);
        
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $fields_string);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            "Authorization: Bearer " . PAYSTACK_SECRET_KEY,
            "Cache-Control: no-cache",
        ]);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        
        $result = curl_exec($ch);
        
        if (curl_errno($ch)) {
            $error_msg = curl_error($ch);
            curl_close($ch);
            echo json_encode(['success' => false, 'message' => 'Connection error: ' . $error_msg]);
            exit;
        }
        
        curl_close($ch);
        
        $response = json_decode($result, true);
        
        if ($response && isset($response['status']) && $response['status']) {
            echo json_encode([
                'success' => true,
                'authorization_url' => $response['data']['authorization_url'],
                'reference' => $response['data']['reference']
            ]);
        } else {
            $error_message = isset($response['message']) ? $response['message'] : 'Failed to initialize payment';
            echo json_encode(['success' => false, 'message' => $error_message]);
        }
        
    } elseif ($action === 'verify') {
        $reference = $data['reference'] ?? '';
        
        if (empty($reference)) {
            echo json_encode(['success' => false, 'message' => 'Reference is required']);
            exit;
        }
        
        // Verify Paystack transaction
        $url = "https://api.paystack.co/transaction/verify/" . $reference;
        
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            "Authorization: Bearer " . PAYSTACK_SECRET_KEY,
            "Cache-Control: no-cache",
        ]);
        
        $result = curl_exec($ch);
        
        if (curl_errno($ch)) {
            $error_msg = curl_error($ch);
            curl_close($ch);
            echo json_encode(['success' => false, 'message' => 'Connection error: ' . $error_msg]);
            exit;
        }
        
        curl_close($ch);
        
        $response = json_decode($result, true);
        
        if ($response && isset($response['status']) && $response['status'] && $response['data']['status'] === 'success') {
            $amount = $response['data']['amount'] / 100; // Convert from kobo
            
            $stmt = $pdo->prepare("
                UPDATE balances 
                SET referral_earnings = referral_earnings + ?, 
                    total_balance = total_balance + ? 
                WHERE user_id = ?
            ");
            $stmt->execute([$amount, $amount, $user_id]);
            
            $stmt = $pdo->prepare("
                INSERT INTO transactions (user_id, transaction_type, amount, balance_type, description, reference_id)
                VALUES (?, 'deposit', ?, 'referral', 'Deposit to play games', ?)
            ");
            $stmt->execute([$user_id, $amount, $reference]);
            
            $stmt = $pdo->prepare("SELECT referred_by FROM users WHERE id = ?");
            $stmt->execute([$user_id]);
            $user_data = $stmt->fetch();
            
            if ($user_data && $user_data['referred_by']) {
                $upline_id = $user_data['referred_by'];
                
                // Check if upline is premium
                $stmt = $pdo->prepare("SELECT membership_type FROM users WHERE id = ?");
                $stmt->execute([$upline_id]);
                $upline = $stmt->fetch();
                
                if ($upline && $upline['membership_type'] === 'premium') {
                    $commission = $amount * 0.20; // 20% commission
                    
                    // Credit upline's referral_earnings
                    $stmt = $pdo->prepare("
                        UPDATE balances 
                        SET referral_earnings = referral_earnings + ?, 
                            total_balance = total_balance + ? 
                        WHERE user_id = ?
                    ");
                    $stmt->execute([$commission, $commission, $upline_id]);
                    
                    $stmt = $pdo->prepare("
                        INSERT INTO referral_commissions (referrer_id, referred_user_id, commission_type, commission_amount)
                        VALUES (?, ?, 'game_deposit', ?)
                    ");
                    $stmt->execute([$upline_id, $user_id, $commission]);
                    
                    $stmt = $pdo->prepare("
                        INSERT INTO transactions (user_id, transaction_type, amount, balance_type, description, reference_id)
                        VALUES (?, 'referral_commission', ?, 'referral', 'Deposit bonus from downline', ?)
                    ");
                    $stmt->execute([$upline_id, $commission, $reference]);
                }
            }
            
            echo json_encode([
                'success' => true,
                'message' => 'Deposit successful',
                'amount' => $amount
            ]);
        } else {
            $error_message = isset($response['message']) ? $response['message'] : 'Payment verification failed';
            echo json_encode(['success' => false, 'message' => $error_message]);
        }
    } else {
        echo json_encode(['success' => false, 'message' => 'Invalid action']);
    }
    
} catch (Exception $e) {
    error_log("Paystack Deposit Error: " . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'An error occurred: ' . $e->getMessage()]);
}
?>
