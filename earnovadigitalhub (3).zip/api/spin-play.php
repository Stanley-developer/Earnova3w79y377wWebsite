<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('log_errors', 1);

require_once '../config/database.php';
require_once '../includes/session.php';

header('Content-Type: application/json');

// Require authentication
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit;
}

$user_id = $_SESSION['user_id'];

try {
    $pdo = getDBConnection();
    
    // Get POST data
    $data = json_decode(file_get_contents('php://input'), true);
    $bet_amount = floatval($data['bet_amount'] ?? 0);
    
    error_log("[v0] Spin Play Debug - User ID: $user_id, Bet Amount: $bet_amount");
    
    // Validate bet amount
    if ($bet_amount < 1000) {
        error_log("[v0] Spin Play Error: Bet amount too low ($bet_amount)");
        echo json_encode(['success' => false, 'message' => 'Minimum bet amount is ₦1,000']);
        exit;
    }
    
    // Get user data
    $stmt = $pdo->prepare("SELECT u.*, b.referral_earnings, b.game_earnings, b.total_balance, b.task_earnings FROM users u LEFT JOIN balances b ON u.id = b.user_id WHERE u.id = ?");
    $stmt->execute([$user_id]);
    $user = $stmt->fetch();
    
    if (!$user) {
        error_log("[v0] Spin Play Error: User not found (ID: $user_id)");
        echo json_encode(['success' => false, 'message' => 'User not found']);
        exit;
    }
    
    error_log("[v0] Spin Play Balance Check:");
    error_log("  User ID: $user_id");
    error_log("  Game Earnings: " . $user['game_earnings']);
    error_log("  Referral Earnings: " . $user['referral_earnings']);
    error_log("  Task Earnings: " . $user['task_earnings']);
    error_log("  Total Balance: " . $user['total_balance']);
    error_log("  Bet Amount: $bet_amount");
    error_log("  Has Sufficient Balance: " . ($user['game_earnings'] >= $bet_amount ? 'YES' : 'NO'));
    
    // Check premium membership
    if ($user['membership_type'] !== 'premium') {
        error_log("[v0] Spin Play Error: User is not premium (Type: " . $user['membership_type'] . ")");
        echo json_encode(['success' => false, 'message' => 'Premium membership required', 'upgrade_required' => true]);
        exit;
    }
    
    if ($user['game_earnings'] < $bet_amount) {
        error_log("[v0] Spin Play Error: Insufficient balance - Game Earnings: " . $user['game_earnings'] . ", Bet: $bet_amount");
        echo json_encode([
            'success' => false, 
            'message' => 'Insufficient balance. You have ₦' . number_format($user['game_earnings'], 2) . ' but need ₦' . number_format($bet_amount, 2) . ' to play.',
            'insufficient_balance' => true,
            'debug_info' => [
                'game_earnings' => $user['game_earnings'],
                'bet_amount' => $bet_amount,
                'difference' => $bet_amount - $user['game_earnings']
            ]
        ]);
        exit;
    }
    
    error_log("[v0] Spin Play: Balance check passed, deducting bet amount");
    
    $stmt = $pdo->prepare("UPDATE balances SET game_earnings = game_earnings - ?, total_balance = total_balance - ? WHERE user_id = ?");
    $stmt->execute([$bet_amount, $bet_amount, $user_id]);
    
    error_log("[v0] Spin Play: Bet deducted successfully");
    
    // Define wheel segments (50% win, 50% loss)
    $segments = [
        ['label' => 'x3.0', 'multiplier' => 3.0, 'isWin' => true],
        ['label' => 'Empty', 'multiplier' => 0, 'isWin' => false],
        ['label' => 'x2.0', 'multiplier' => 2.0, 'isWin' => true],
        ['label' => '0.5x', 'multiplier' => 0.5, 'isWin' => false],
        ['label' => 'x1.5', 'multiplier' => 1.5, 'isWin' => true],
        ['label' => '0.8x', 'multiplier' => 0.8, 'isWin' => false],
        ['label' => 'x1.2', 'multiplier' => 1.2, 'isWin' => true],
        ['label' => 'Empty', 'multiplier' => 0, 'isWin' => false]
    ];
    
    // Determine win or loss (50/50)
    $rand = mt_rand(1, 100);
    $shouldWin = $rand <= 50;
    
    // Filter segments based on win/loss
    $availableSegments = array_filter($segments, function($seg) use ($shouldWin) {
        return $seg['isWin'] === $shouldWin;
    });
    
    // Pick random segment from available ones
    $availableSegments = array_values($availableSegments);
    $selectedSegment = $availableSegments[array_rand($availableSegments)];
    
    // Find the index in original segments array
    $segmentIndex = array_search($selectedSegment, $segments);
    
    $multiplier = $selectedSegment['multiplier'];
    $win_amount = $bet_amount * $multiplier;
    
    error_log("[v0] Spin Play Result: Segment=" . $selectedSegment['label'] . ", Multiplier=$multiplier, Win Amount=$win_amount");
    
    // Add winnings to game_earnings
    if ($win_amount > 0) {
        $stmt = $pdo->prepare("UPDATE balances SET game_earnings = game_earnings + ?, total_balance = total_balance + ? WHERE user_id = ?");
        $stmt->execute([$win_amount, $win_amount, $user_id]);
        error_log("[v0] Spin Play: Winnings added to game_earnings");
    }
    
    // Record in history
    $stmt = $pdo->prepare("INSERT INTO transactions (user_id, transaction_type, amount, balance_type, description, reference_id) VALUES (?, 'game_play', ?, 'game', ?, ?)");
    $description = "Spin & Win - Bet: ₦" . number_format($bet_amount, 2) . " | Result: " . $selectedSegment['label'] . " | Win: ₦" . number_format($win_amount, 2);
    $reference_id = 'SPIN_' . time() . '_' . $user_id;
    $stmt->execute([$user_id, $win_amount, $description, $reference_id]);
    
    // Get updated balances
    $stmt = $pdo->prepare("SELECT referral_earnings, game_earnings, total_balance FROM balances WHERE user_id = ?");
    $stmt->execute([$user_id]);
    $balance = $stmt->fetch();
    
    error_log("[v0] Spin Play Success: New game_earnings=" . $balance['game_earnings']);
    
    echo json_encode([
        'success' => true,
        'segment_index' => $segmentIndex,
        'segment_label' => $selectedSegment['label'],
        'multiplier' => $multiplier,
        'win_amount' => $win_amount,
        'referral_earnings' => $balance['referral_earnings'],
        'game_earnings' => $balance['game_earnings'],
        'total_balance' => $balance['total_balance']
    ]);
    
} catch (PDOException $e) {
    error_log("[v0] Spin Play Database Error: " . $e->getMessage() . " in " . $e->getFile() . " on line " . $e->getLine());
    echo json_encode([
        'success' => false, 
        'message' => 'Database Error: ' . $e->getMessage(),
        'error_details' => [
            'file' => $e->getFile(),
            'line' => $e->getLine(),
            'trace' => $e->getTraceAsString()
        ]
    ]);
} catch (Exception $e) {
    error_log("[v0] Spin Play Exception: " . $e->getMessage() . " in " . $e->getFile() . " on line " . $e->getLine());
    echo json_encode([
        'success' => false,
        'message' => 'Error: ' . $e->getMessage(),
        'error_details' => [
            'file' => $e->getFile(),
            'line' => $e->getLine(),
            'trace' => $e->getTraceAsString()
        ]
    ]);
}
?>
