<?php
/**
 * Cron Job Endpoint: Mark Inactive Users
 * 
 * This endpoint is called by a server cron job every minute to:
 * 1. Find users who haven't been active for 30 minutes
 * 2. Mark them as is_active = 0 in the database
 * 
 * Usage: GET /api/mark-inactive-users.php
 * Optionally with secret key: GET /api/mark-inactive-users.php?key=YOUR_SECRET_KEY
 * 
 * Setup cron:
 * * * * * curl -s http://localhost/Earnova-digital-hub/api/mark-inactive-users.php?key=your_secret_key > /dev/null 2>&1
 */

require_once '../config/database.php';

// Optional: Protect endpoint with a secret key
// Change this to a strong random key and use it in your cron job
$CRON_SECRET_KEY = 'your_super_secret_cron_key_change_this';

// Verify the request is from cron (optional security layer)
$provided_key = isset($_GET['key']) ? trim($_GET['key']) : '';
if ($provided_key !== $CRON_SECRET_KEY) {
    http_response_code(403);
    echo json_encode(['success' => false, 'error' => 'Unauthorized. Invalid or missing secret key.']);
    exit;
}

try {
    $pdo = getDBConnection();
    
    // 30 minutes in seconds
    $inactivity_threshold = 30 * 60;

    // Calculate timestamp for 30 minutes ago
    $inactive_before = date('Y-m-d H:i:s', time() - $inactivity_threshold);

    // 1) Mark users inactive if they are currently active but have no recent activity
    //    OR their remember-me token has expired
    $stmt = $pdo->prepare(
        "UPDATE users
         SET is_active = 0
         WHERE is_active = 1
           AND (
               last_activity IS NULL
               OR last_activity < ?
               OR (remember_me_expires IS NOT NULL AND remember_me_expires < NOW())
           )"
    );
    $stmt->execute([$inactive_before]);
    $rows_inactivated = $stmt->rowCount();

    // 2) Ensure users who have recent activity or valid remember-me tokens are marked active
    $stmt2 = $pdo->prepare(
        "UPDATE users
         SET is_active = 1
         WHERE (
               (last_activity IS NOT NULL AND last_activity >= ?)
            OR (remember_me_expires IS NOT NULL AND remember_me_expires > NOW())
         )"
    );
    $stmt2->execute([$inactive_before]);
    $rows_activated = $stmt2->rowCount();

    // Log the action
    error_log(sprintf(
        "[CRON] Mark Inactive Users: inactivated=%d activated=%d at %s",
        $rows_inactivated,
        $rows_activated,
        date('Y-m-d H:i:s')
    ));

    http_response_code(200);
    echo json_encode([
        'success' => true,
        'inactivated' => $rows_inactivated,
        'activated' => $rows_activated,
        'timestamp' => date('Y-m-d H:i:s'),
        'threshold_minutes' => 30,
        'message' => "Sync completed"
    ]);
    
} catch (Exception $e) {
    error_log("[CRON ERROR] Mark Inactive Users: " . $e->getMessage());
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => 'Database error: ' . $e->getMessage()
    ]);
}
?>
