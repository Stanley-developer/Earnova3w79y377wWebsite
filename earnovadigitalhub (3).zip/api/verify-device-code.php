<?php
require_once '../config/database.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    exit();
}

$user_id = $_POST['user_id'] ?? '';
$device_fingerprint = $_POST['device_fingerprint'] ?? '';
$verification_code = $_POST['verification_code'] ?? '';

if (empty($user_id) || empty($device_fingerprint) || empty($verification_code)) {
    echo json_encode(['success' => false, 'message' => 'Missing required fields']);
    exit();
}

try {
    $pdo = getDBConnection();
    
    // Check if code is valid and not expired
    $stmt = $pdo->prepare("
        SELECT * FROM device_login_verifications 
        WHERE user_id = ? 
        AND device_fingerprint = ? 
        AND verification_code = ? 
        AND is_used = FALSE 
        AND expires_at > NOW()
        ORDER BY created_at DESC 
        LIMIT 1
    ");
    $stmt->execute([$user_id, $device_fingerprint, $verification_code]);
    $verification = $stmt->fetch();
    
    if (!$verification) {
        echo json_encode(['success' => false, 'message' => 'Invalid or expired verification code']);
        exit();
    }
    
    // Mark code as used
    $stmt = $pdo->prepare("UPDATE device_login_verifications SET is_used = TRUE WHERE id = ?");
    $stmt->execute([$verification['id']]);
    
    // Add device to user_devices
    $device_info = [
        'browser' => $verification['browser'],
        'os' => $verification['os'],
        'ip_address' => $verification['ip_address']
    ];
    
    $stmt = $pdo->prepare("
        INSERT INTO user_devices 
        (user_id, device_fingerprint, device_name, browser, os, ip_address, is_verified, first_login, last_login) 
        VALUES (?, ?, ?, ?, ?, ?, TRUE, NOW(), NOW())
        ON DUPLICATE KEY UPDATE 
        last_login = NOW(), 
        is_verified = TRUE
    ");
    $stmt->execute([
        $user_id,
        $device_fingerprint,
        $device_info['browser'] . ' on ' . $device_info['os'],
        $device_info['browser'],
        $device_info['os'],
        $device_info['ip_address']
    ]);
    
    echo json_encode([
        'success' => true,
        'message' => 'Device verified successfully'
    ]);
    
} catch (Exception $e) {
    error_log("Device verification error: " . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'Error verifying device']);
}
?>
