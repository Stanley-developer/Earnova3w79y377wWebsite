<?php
/**
 * Simple DB health check for Kora Pay integration
 * Returns JSON listing required tables and critical columns
 */

require_once __DIR__ . '/../config/database.php';
header('Content-Type: application/json');

$required = [
    'users' => ['id','email','full_name','membership_type','advertiser_plan','referred_by','membership_start_date','advertiser_plan_start_date','username'],
    'balances' => ['user_id','total_balance','task_earnings','referral_earnings','game_earnings'],
    'premium_payments' => ['id','user_id','amount','payment_method','payment_reference','status'],
    'advertiser_payments' => ['id','user_id','amount','plan_duration','payment_method','payment_reference','status'],
    'transactions' => ['id','user_id','transaction_type','amount','balance_type','reference_id'],
    'referral_commissions' => ['id','referrer_id','referred_user_id','commission_amount','description'],
    'korapay_transactions' => ['id','user_id','korapay_reference','amount','status'],
    'korapay_webhooks' => ['id','event_type','webhook_reference','processed']
];

$report = [
    'status' => true,
    'checked_at' => date('c'),
    'results' => []
];

try {
    $pdo = getDBConnection();

    foreach ($required as $table => $cols) {
        $tableOk = false;
        $colResults = [];

        // Check table exists (use direct query, no placeholders for SHOW)
        $res = $pdo->query("SHOW TABLES LIKE '$table'")->fetchAll(PDO::FETCH_ASSOC);
        if (count($res) > 0) {
            $tableOk = true;
            // Check columns (use direct query)
            foreach ($cols as $col) {
                $c = $pdo->query("SHOW COLUMNS FROM `$table` LIKE '$col'")->fetchAll(PDO::FETCH_ASSOC);
                $colResults[$col] = (count($c) > 0);
            }
        }

        $report['results'][$table] = [
            'table_exists' => $tableOk,
            'columns' => $colResults
        ];

        if (!$tableOk) $report['status'] = false;
        else {
            // if any required column missing -> overall failure
            foreach ($colResults as $present) {
                if (!$present) $report['status'] = false;
            }
        }
    }

    echo json_encode($report, JSON_PRETTY_PRINT);
} catch (Exception $e) {
    http_response_code(500);
    error_log('Korapay health check error: ' . $e->getMessage());
    echo json_encode(['status' => false, 'message' => 'Health check failed', 'error' => $e->getMessage()]);
}
