<?php
require_once '../config/database.php';
require_once '../includes/session.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    exit();
}

$user_id = $_POST['user_id'] ?? '';

if (empty($user_id)) {
    echo json_encode(['success' => false, 'message' => 'Missing user ID']);
    exit();
}

// Verify this matches the pending login session
if (!isset($_SESSION['pending_login_user_id']) || $_SESSION['pending_login_user_id'] != $user_id) {
    echo json_encode(['success' => false, 'message' => 'Invalid session']);
    exit();
}

try {
    $pdo = getDBConnection();
    
    // Get user data
    $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
    $stmt->execute([$user_id]);
    $user = $stmt->fetch();
    
    if (!$user) {
        echo json_encode(['success' => false, 'message' => 'User not found']);
        exit();
    }
    
    // Clear pending login data
    unset($_SESSION['pending_login_user_id']);
    unset($_SESSION['pending_login_device']);
    unset($_SESSION['pending_login_device_info']);
    unset($_SESSION['pending_login_email']);
    unset($_SESSION['pending_login_time']);
    unset($_SESSION['pending_login_password']);
    setcookie('pending_device_verification', '', time() - 3600, '/', '', true, true);
    
    // Set user session
    setUserSession($user['id'], $user);
    regenerateSession();
    
    echo json_encode([
        'success' => true,
        'message' => 'Login successful'
    ]);
    
} catch (Exception $e) {
    error_log("Complete device login error: " . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'Error completing login']);
}
?>
