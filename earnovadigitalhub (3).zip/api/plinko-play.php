<?php
require_once '../config/database.php';
require_once '../includes/session.php';

header('Content-Type: application/json');

// Require authentication
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit;
}

$user_id = $_SESSION['user_id'];

try {
    $pdo = getDBConnection();
    
    // Get POST data
    $data = json_decode(file_get_contents('php://input'), true);
    $bet_amount = floatval($data['bet_amount'] ?? 0);
    $is_free_play = boolval($data['is_free_play'] ?? false);
    
    // Validate bet amount
    if ($bet_amount < 0) {
        echo json_encode(['success' => false, 'message' => 'Invalid bet amount']);
        exit;
    }
    
    // Get user data
    $stmt = $pdo->prepare("
        SELECT u.*, b.task_earnings, b.referral_earnings, b.total_balance
        FROM users u
        LEFT JOIN balances b ON u.id = b.user_id
        WHERE u.id = ?
    ");
    $stmt->execute([$user_id]);
    $user = $stmt->fetch();
    
    if (!$user) {
        echo json_encode(['success' => false, 'message' => 'User not found']);
        exit;
    }
    
    // Check if free play
    if ($is_free_play) {
        // Reset free plays if it's a new day
        $today = date('Y-m-d');
        if ($user['plinko_last_reset'] !== $today) {
            $stmt = $pdo->prepare("UPDATE users SET plinko_free_plays = 2, plinko_last_reset = ? WHERE id = ?");
            $stmt->execute([$today, $user_id]);
            $user['plinko_free_plays'] = 2;
        }
        
        // Check if user has free plays left
        if ($user['plinko_free_plays'] <= 0) {
            echo json_encode(['success' => false, 'message' => 'No free plays remaining']);
            exit;
        }
        
        // Deduct free play
        $stmt = $pdo->prepare("UPDATE users SET plinko_free_plays = plinko_free_plays - 1 WHERE id = ?");
        $stmt->execute([$user_id]);
        
    } else {
        // Check if user has enough balance
        if ($user['task_earnings'] < $bet_amount) {
            echo json_encode(['success' => false, 'message' => 'Insufficient balance']);
            exit;
        }
        
        // Deduct bet amount from task earnings
        $stmt = $pdo->prepare("
            UPDATE balances 
            SET task_earnings = task_earnings - ?, 
                total_balance = total_balance - ? 
            WHERE user_id = ?
        ");
        $stmt->execute([$bet_amount, $bet_amount, $user_id]);
    }
    
    // Calculate win (random multiplier with weighted probabilities)
    $multipliers = [
        0.5 => 30,    // 30% chance - lose half
        1.0 => 25,    // 25% chance - break even
        1.5 => 20,    // 20% chance - 1.5x
        2.0 => 15,    // 15% chance - 2x
        3.0 => 7,     // 7% chance - 3x
        5.0 => 2,     // 2% chance - 5x
        10.0 => 1     // 1% chance - 10x jackpot
    ];
    
    $rand = mt_rand(1, 100);
    $cumulative = 0;
    $selected_multiplier = 1.0;
    
    foreach ($multipliers as $multiplier => $probability) {
        $cumulative += $probability;
        if ($rand <= $cumulative) {
            $selected_multiplier = $multiplier;
            break;
        }
    }
    
    $win_amount = $bet_amount * $selected_multiplier;
    
    // Add winnings to referral earnings
    if ($win_amount > 0) {
        $stmt = $pdo->prepare("
            UPDATE balances 
            SET referral_earnings = referral_earnings + ?, 
                total_balance = total_balance + ? 
            WHERE user_id = ?
        ");
        $stmt->execute([$win_amount, $win_amount, $user_id]);
    }
    
    // Record game in history
    $stmt = $pdo->prepare("
        INSERT INTO plinko_games (user_id, bet_amount, win_amount, multiplier, is_free_play)
        VALUES (?, ?, ?, ?, ?)
    ");
    $stmt->execute([$user_id, $bet_amount, $win_amount, $selected_multiplier, $is_free_play]);
    
    // Get updated balance
    $stmt = $pdo->prepare("SELECT task_earnings, referral_earnings, total_balance FROM balances WHERE user_id = ?");
    $stmt->execute([$user_id]);
    $balance = $stmt->fetch();
    
    // Get updated free plays
    $stmt = $pdo->prepare("SELECT plinko_free_plays FROM users WHERE id = ?");
    $stmt->execute([$user_id]);
    $user_data = $stmt->fetch();
    
    echo json_encode([
        'success' => true,
        'multiplier' => $selected_multiplier,
        'win_amount' => $win_amount,
        'new_balance' => $balance['task_earnings'],
        'new_referral_balance' => $balance['referral_earnings'],
        'free_plays_remaining' => $user_data['plinko_free_plays']
    ]);
    
} catch (PDOException $e) {
    error_log("Plinko Play Error: " . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'An error occurred']);
}
?>
