<?php
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../includes/auth.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonResponse(false, 'Invalid request method');
}

// Get POST data
$data = json_decode(file_get_contents('php://input'), true);

// Validate required fields
if (empty($data['email']) || empty($data['password'])) {
    jsonResponse(false, 'Email and password are required');
}

// Sanitize inputs
$email = sanitizeInput($data['email']);
$password = $data['password'];

// Login user
$auth = new Auth();
$result = $auth->login($email, $password);

jsonResponse($result['success'], $result['message'], $result);
?>
