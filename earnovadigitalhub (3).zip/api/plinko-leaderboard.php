<?php
require_once '../config/database.php';
require_once '../includes/session.php';

header('Content-Type: application/json');

try {
    $pdo = getDBConnection();
    
    // Get top 10 players from leaderboard
    $stmt = $pdo->query("
        SELECT 
            u.id,
            u.username,
            u.full_name,
            u.profile_picture,
            COUNT(CASE WHEN pg.win_amount > pg.bet_amount THEN 1 END) as total_wins,
            COALESCE(SUM(pg.win_amount - pg.bet_amount), 0) as total_profit,
            COALESCE(MAX(pg.win_amount), 0) as biggest_win
        FROM users u
        LEFT JOIN plinko_games pg ON u.id = pg.user_id
        GROUP BY u.id, u.username, u.full_name, u.profile_picture
        HAVING total_profit > 0
        ORDER BY total_profit DESC
        LIMIT 10
    ");
    
    $leaderboard = $stmt->fetchAll();
    
    echo json_encode([
        'success' => true,
        'leaderboard' => $leaderboard
    ]);
    
} catch (PDOException $e) {
    error_log("Plinko Leaderboard Error: " . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'An error occurred']);
}
?>
