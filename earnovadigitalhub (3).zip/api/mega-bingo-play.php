<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('log_errors', 1);

require_once '../config/database.php';
require_once '../includes/session.php';

header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit;
}

$user_id = $_SESSION['user_id'];

try {
    $pdo = getDBConnection();
    
    // Get POST data
    $data = json_decode(file_get_contents('php://input'), true);
    $bet_amount = floatval($data['bet_amount'] ?? 0);
    $pattern = strtolower($data['pattern'] ?? '');
    $reward = floatval($data['reward'] ?? 0);
    
    error_log("[MEGA-BINGO] User: $user_id, Bet: $bet_amount, Pattern: $pattern, Reward: $reward");
    
    // Validate inputs
    if ($bet_amount < 1000) {
        echo json_encode(['success' => false, 'message' => 'Minimum bet amount is ₦1,000']);
        exit;
    }
    
    if ($reward <= 0) {
        echo json_encode(['success' => false, 'message' => 'Invalid reward amount']);
        exit;
    }
    
    // Get user data
    $stmt = $pdo->prepare("SELECT u.*, b.game_earnings, b.total_balance FROM users u LEFT JOIN balances b ON u.id = b.user_id WHERE u.id = ?");
    $stmt->execute([$user_id]);
    $user = $stmt->fetch();
    
    if (!$user) {
        echo json_encode(['success' => false, 'message' => 'User not found']);
        exit;
    }
    
    error_log("[MEGA-BINGO] Balance: Game=" . $user['game_earnings']);
    
    // Check premium membership
    if ($user['membership_type'] !== 'premium') {
        echo json_encode(['success' => false, 'message' => 'Premium membership required']);
        exit;
    }
    
    // Update balance with reward
    $stmt = $pdo->prepare("UPDATE balances SET game_earnings = game_earnings + ?, total_balance = total_balance + ? WHERE user_id = ?");
    $stmt->execute([$reward, $reward, $user_id]);
    
    error_log("[MEGA-BINGO] Reward added: $reward");
    
    // Record in transaction history
    $stmt = $pdo->prepare("INSERT INTO transactions (user_id, transaction_type, amount, balance_type, description, reference_id) VALUES (?, 'game_play', ?, 'game', ?, ?)");
    $description = "Mega Bingo - Bet: ₦" . number_format($bet_amount, 2) . " | Pattern: " . ucfirst($pattern) . " | Win: ₦" . number_format($reward, 2);
    $reference_id = 'BINGO_' . time() . '_' . $user_id;
    $stmt->execute([$user_id, $reward, $description, $reference_id]);
    
    // Get updated balance
    $stmt = $pdo->prepare("SELECT game_earnings, total_balance FROM balances WHERE user_id = ?");
    $stmt->execute([$user_id]);
    $balance = $stmt->fetch();
    
    error_log("[MEGA-BINGO] Success: GameEarnings=" . $balance['game_earnings']);
    
    echo json_encode([
        'success' => true,
        'pattern' => $pattern,
        'reward' => floatval($reward),
        'bet_amount' => floatval($bet_amount),
        'game_earnings' => floatval($balance['game_earnings']),
        'total_balance' => floatval($balance['total_balance'])
    ]);
    
} catch (PDOException $e) {
    error_log("[MEGA-BINGO] DB Error: " . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'Database Error']);
} catch (Exception $e) {
    error_log("[MEGA-BINGO] Exception: " . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'Error: ' . $e->getMessage()]);
}
?>
