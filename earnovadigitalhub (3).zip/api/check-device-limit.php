<?php
require_once '../config/database.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    exit();
}

$device_fingerprint = $_POST['device_fingerprint'] ?? '';

if (empty($device_fingerprint)) {
    echo json_encode(['success' => false, 'message' => 'Device fingerprint required']);
    exit();
}

try {
    $pdo = getDBConnection();
    
    // Count how many accounts are registered from this device
    $stmt = $pdo->prepare("SELECT COUNT(*) as account_count FROM device_registration_log WHERE device_fingerprint = ?");
    $stmt->execute([$device_fingerprint]);
    $result = $stmt->fetch();
    
    $account_count = $result['account_count'];
    $can_register = $account_count < 2;
    
    echo json_encode([
        'success' => true,
        'can_register' => $can_register,
        'account_count' => $account_count,
        'limit' => 2
    ]);
    
} catch (Exception $e) {
    error_log("Device limit check error: " . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'Error checking device limit']);
}
?>
