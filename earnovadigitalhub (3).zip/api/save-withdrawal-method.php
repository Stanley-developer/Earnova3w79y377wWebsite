<?php
session_start();
require_once '../config/database.php';
require_once '../includes/connect.php';

header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'Not authenticated']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
    exit;
}

$user_id = $_SESSION['user_id'];
$account_number = $_POST['account_number'] ?? '';
$account_name = $_POST['account_name'] ?? '';
$bank_name = $_POST['bank_name'] ?? '';
$bank_code = $_POST['bank_code'] ?? '';

if (empty($account_number) || empty($account_name) || empty($bank_name) || empty($bank_code)) {
    echo json_encode(['success' => false, 'message' => 'All fields are required']);
    exit;
}

// Update user's withdrawal method
$stmt = $conn->prepare("UPDATE users SET withdrawal_account_number = ?, withdrawal_account_name = ?, withdrawal_bank_name = ?, withdrawal_bank_code = ? WHERE id = ?");
$stmt->bind_param("ssssi", $account_number, $account_name, $bank_name, $bank_code, $user_id);

if ($stmt->execute()) {
    echo json_encode(['success' => true, 'message' => 'Withdrawal method saved successfully']);
} else {
    echo json_encode(['success' => false, 'message' => 'Failed to save withdrawal method']);
}

$stmt->close();
?>
