<?php
require_once '../config/database.php';
require_once '../includes/session.php';

header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit;
}

$user_id = $_SESSION['user_id'];

try {
    $pdo = getDBConnection();
    $data = json_decode(file_get_contents('php://input'), true);
    
    $track_id = $data['track_id'] ?? '';
    $track_title = $data['track_title'] ?? '';
    $artist = $data['artist'] ?? '';
    $cover_image = $data['cover_image'] ?? '';
    $audio_file = $data['audio_file'] ?? '';
    $duration = intval($data['duration'] ?? 0);
    
    if (empty($track_id)) {
        echo json_encode(['success' => false, 'message' => 'Invalid track data']);
        exit;
    }
    
    // Insert or ignore if already exists
    $stmt = $pdo->prepare("
        INSERT IGNORE INTO user_playlists 
        (user_id, track_id, track_title, artist, cover_image, audio_file, duration)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    ");
    $stmt->execute([$user_id, $track_id, $track_title, $artist, $cover_image, $audio_file, $duration]);
    
    echo json_encode(['success' => true, 'message' => 'Added to playlist']);
    
} catch (PDOException $e) {
    error_log("Add to Playlist Error: " . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'Error adding to playlist']);
}
?>
