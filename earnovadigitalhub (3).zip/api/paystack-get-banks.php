<?php
session_start();
require_once '../config/database.php';

header('Content-Type: application/json');

// Paystack API credentials
define('PAYSTACK_SECRET_KEY', 'sk_live_7ceb76976f99b57f94ff8ba1e7d1940254b052ba');

// Fetch list of banks from Paystack
$curl = curl_init();
curl_setopt_array($curl, array(
    CURLOPT_URL => "https://api.paystack.co/bank",
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_HTTPHEADER => array(
        "Authorization: Bearer " . PAYSTACK_SECRET_KEY
    ),
));

$response = curl_exec($curl);
$err = curl_error($curl);
curl_close($curl);

if ($err) {
    echo json_encode(['success' => false, 'message' => 'Error fetching banks']);
    exit;
}

$result = json_decode($response, true);

if ($result['status'] === true) {
    echo json_encode(['success' => true, 'banks' => $result['data']]);
} else {
    echo json_encode(['success' => false, 'message' => 'Failed to fetch banks']);
}
?>
