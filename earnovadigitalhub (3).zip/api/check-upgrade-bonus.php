<?php
session_start();
require_once('../config/db.php');

header('Content-Type: application/json');

// Only process POST requests
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    exit;
}

// Get user ID
$user_id = $_SESSION['user_id'] ?? null;

if (!$user_id) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit;
}

try {
    // Check if this user was referred by someone
    $stmt = $conn->prepare("SELECT referred_by FROM users WHERE id = ?");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();
    $stmt->close();
    
    if (!$user || !$user['referred_by']) {
        echo json_encode(['success' => true, 'bonus' => 0]);
        exit;
    }
    
    $referrer_id = $user['referred_by'];
    
    // Check if this user was previously Premium (has referral commission record from premium upgrade)
    $stmt = $conn->prepare("
        SELECT COUNT(*) as premium_count 
        FROM referral_commissions 
        WHERE referred_user_id = ? AND commission_type = 'premium_upgrade'
    ");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $prev_result = $stmt->get_result();
    $prev_premium = $prev_result->fetch_assoc();
    $stmt->close();
    
    if ($prev_premium['premium_count'] == 0) {
        // User was never Premium, no upgrade bonus
        echo json_encode(['success' => true, 'bonus' => 0]);
        exit;
    }
    
    // Get referrer's tier
    $stmt = $conn->prepare("SELECT membership_type, advertiser_plan FROM users WHERE id = ?");
    $stmt->bind_param("i", $referrer_id);
    $stmt->execute();
    $referrer_result = $stmt->get_result();
    $referrer = $referrer_result->fetch_assoc();
    $stmt->close();
    
    $upgrade_bonus = 0;
    
    // Premium user: N500 upgrade bonus when downline upgrades from Premium to Premium Plus
    if ($referrer['membership_type'] === 'premium' && $referrer['advertiser_plan'] !== 'senior') {
        $upgrade_bonus = 500;
    }
    // Premium Plus user: N1000 upgrade bonus when downline upgrades from Premium to Premium Plus
    elseif ($referrer['advertiser_plan'] === 'senior') {
        $upgrade_bonus = 1000;
    }
    
    echo json_encode(['success' => true, 'bonus' => $upgrade_bonus]);
    
} catch (Exception $e) {
    error_log("Error in check-upgrade-bonus.php: " . $e->getMessage());
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Internal server error']);
}
?>
