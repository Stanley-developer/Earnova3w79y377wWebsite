<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once '../config/database.php';
require_once '../includes/session.php';

header('Content-Type: application/json');

// Require authentication
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit;
}

$user_id = $_SESSION['user_id'];

try {
    $pdo = getDBConnection();
    
    // Get POST data
    $data = json_decode(file_get_contents('php://input'), true);
    $bet_amount = floatval($data['bet_amount'] ?? 0);
    
    if ($bet_amount < 1000) {
        echo json_encode(['success' => false, 'message' => 'Minimum bet amount is ₦1,000']);
        exit;
    }
    
    $stmt = $pdo->prepare("SELECT u.*, b.referral_earnings, b.game_earnings, b.total_balance FROM users u LEFT JOIN balances b ON u.id = b.user_id WHERE u.id = ?");
    $stmt->execute([$user_id]);
    $user = $stmt->fetch();
    
    if (!$user) {
        echo json_encode(['success' => false, 'message' => 'User not found']);
        exit;
    }
    
    if ($user['membership_type'] !== 'premium') {
        echo json_encode(['success' => false, 'message' => 'Premium membership required', 'upgrade_required' => true]);
        exit;
    }
    
    if ($user['game_earnings'] < $bet_amount) {
        echo json_encode(['success' => false, 'message' => 'Insufficient balance. Please deposit to play.', 'insufficient_balance' => true]);
        exit;
    }
    
    $stmt = $pdo->prepare("UPDATE balances SET game_earnings = game_earnings - ?, total_balance = total_balance - ? WHERE user_id = ?");
    $stmt->execute([$bet_amount, $bet_amount, $user_id]);
    
    $rand = mt_rand(1, 100);
    
    if ($rand <= 60) {
        // 60% chance to win
        $multipliers = [
            1.2 => 30,    // 30% chance - small win
            1.5 => 18,    // 18% chance - medium win
            2.0 => 8,     // 8% chance - good win
            3.0 => 3,     // 3% chance - great win
            5.0 => 1      // 1% chance - jackpot
        ];
    } else {
        // 40% chance to lose
        $multipliers = [
            0.5 => 25,    // 25% chance - lose half
            0.3 => 10,    // 10% chance - lose more
            0.0 => 5      // 5% chance - lose all
        ];
    }
    
    $cumulative = 0;
    $selected_multiplier = 1.0;
    $total_probability = array_sum($multipliers);
    $rand_multiplier = mt_rand(1, $total_probability);
    
    foreach ($multipliers as $multiplier => $probability) {
        $cumulative += $probability;
        if ($rand_multiplier <= $cumulative) {
            $selected_multiplier = $multiplier;
            break;
        }
    }
    
    $win_amount = $bet_amount * $selected_multiplier;
    
    if ($win_amount > 0) {
        $stmt = $pdo->prepare("UPDATE balances SET game_earnings = game_earnings + ?, total_balance = total_balance + ? WHERE user_id = ?");
        $stmt->execute([$win_amount, $win_amount, $user_id]);
    }
    
    $stmt = $pdo->prepare("INSERT INTO transactions (user_id, transaction_type, amount, balance_type, description, reference_id) VALUES (?, 'game_play', ?, 'game', ?, ?)");
    $description = "Mystery Box Game - Bet: ₦" . number_format($bet_amount, 2) . " | Multiplier: " . $selected_multiplier . "x | Win: ₦" . number_format($win_amount, 2);
    $reference_id = 'MYSTERYBOX_' . time() . '_' . $user_id;
    $stmt->execute([$user_id, $win_amount, $description, $reference_id]);
    
    // Get updated balances
    $stmt = $pdo->prepare("SELECT referral_earnings, game_earnings, total_balance FROM balances WHERE user_id = ?");
    $stmt->execute([$user_id]);
    $balance = $stmt->fetch();
    
    echo json_encode([
        'success' => true,
        'multiplier' => $selected_multiplier,
        'win_amount' => $win_amount,
        'referral_earnings' => $balance['referral_earnings'],
        'game_earnings' => $balance['game_earnings'],
        'total_balance' => $balance['total_balance']
    ]);
    
} catch (PDOException $e) {
    error_log("Mystery Box Play Error: " . $e->getMessage());
    echo json_encode([
        'success' => false, 
        'message' => 'Database error: ' . $e->getMessage(),
        'error_details' => $e->getTraceAsString()
    ]);
} catch (Exception $e) {
    error_log("Mystery Box Play Error: " . $e->getMessage());
    echo json_encode([
        'success' => false, 
        'message' => $e->getMessage()
    ]);
}
?>
