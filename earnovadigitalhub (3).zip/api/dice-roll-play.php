<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('log_errors', 1);

require_once '../config/database.php';
require_once '../includes/session.php';

header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit;
}

$user_id = $_SESSION['user_id'];

try {
    $pdo = getDBConnection();
    
    // Get POST data
    $data = json_decode(file_get_contents('php://input'), true);
    $bet_amount = floatval($data['bet_amount'] ?? 0);
    $choice = strtolower($data['choice'] ?? '');
    
    error_log("[DICE-ROLL] User: $user_id, Bet: $bet_amount, Choice: $choice");
    
    // Validate inputs
    if ($bet_amount < 1000) {
        echo json_encode(['success' => false, 'message' => 'Minimum bet amount is ₦1,000']);
        exit;
    }
    
    if (!in_array($choice, ['high', 'low'])) {
        echo json_encode(['success' => false, 'message' => 'Invalid choice']);
        exit;
    }
    
    // Get user data
    $stmt = $pdo->prepare("SELECT u.*, b.referral_earnings, b.game_earnings, b.total_balance FROM users u LEFT JOIN balances b ON u.id = b.user_id WHERE u.id = ?");
    $stmt->execute([$user_id]);
    $user = $stmt->fetch();
    
    if (!$user) {
        echo json_encode(['success' => false, 'message' => 'User not found']);
        exit;
    }
    
    error_log("[DICE-ROLL] Balance: Game=" . $user['game_earnings']);
    
    // Check premium membership
    if ($user['membership_type'] !== 'premium') {
        echo json_encode(['success' => false, 'message' => 'Premium membership required', 'upgrade_required' => true]);
        exit;
    }
    
    // Check balance
    if ($user['game_earnings'] < $bet_amount) {
        echo json_encode(['success' => false, 'message' => 'Insufficient balance', 'insufficient_balance' => true]);
        exit;
    }
    
    // Deduct bet amount
    $stmt = $pdo->prepare("UPDATE balances SET game_earnings = game_earnings - ?, total_balance = total_balance - ? WHERE user_id = ?");
    $stmt->execute([$bet_amount, $bet_amount, $user_id]);
    
    // Roll two dice
    $dice1 = mt_rand(1, 6);
    $dice2 = mt_rand(1, 6);
    $total = $dice1 + $dice2;
    
    // Determine result based on choice (High: 7-12, Low: 2-6)
    $isHigh = $total >= 7;
    $won = ($choice === 'high' && $isHigh) || ($choice === 'low' && !$isHigh);
    
    error_log("[DICE-ROLL] Dice: $dice1, $dice2, Total: $total, Choice: $choice, Won: $won");
    
    // Calculate winnings (double on win, lose bet on loss)
    $win_amount = $won ? ($bet_amount * 2) : 0;
    
    // Add winnings if won
    if ($win_amount > 0) {
        $stmt = $pdo->prepare("UPDATE balances SET game_earnings = game_earnings + ?, total_balance = total_balance + ? WHERE user_id = ?");
        $stmt->execute([$win_amount, $win_amount, $user_id]);
        error_log("[DICE-ROLL] Winnings added: $win_amount");
    }
    
    // Record in transaction history
    $stmt = $pdo->prepare("INSERT INTO transactions (user_id, transaction_type, amount, balance_type, description, reference_id) VALUES (?, 'game_play', ?, 'game', ?, ?)");
    $description = "Dice Roll - Bet: ₦" . number_format($bet_amount, 2) . " | Choice: " . ucfirst($choice) . " | Result: $dice1 + $dice2 = $total | Win: ₦" . number_format($win_amount, 2);
    $reference_id = 'DICEROLL_' . time() . '_' . $user_id;
    $stmt->execute([$user_id, $win_amount, $description, $reference_id]);
    
    // Get updated balances
    $stmt = $pdo->prepare("SELECT referral_earnings, game_earnings, total_balance FROM balances WHERE user_id = ?");
    $stmt->execute([$user_id]);
    $balance = $stmt->fetch();
    
    error_log("[DICE-ROLL] Success: GameEarnings=" . $balance['game_earnings'] . ", Won=$won");
    
    echo json_encode([
        'success' => true,
        'result' => "$dice1 + $dice2 = $total",
        'won' => $won,
        'win_amount' => floatval($win_amount),
        'bet_amount' => floatval($bet_amount),
        'choice' => $choice,
        'dice1' => $dice1,
        'dice2' => $dice2,
        'total' => $total,
        'referral_earnings' => floatval($balance['referral_earnings']),
        'game_earnings' => floatval($balance['game_earnings']),
        'total_balance' => floatval($balance['total_balance'])
    ]);
    
} catch (PDOException $e) {
    error_log("[DICE-ROLL] DB Error: " . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'Database Error']);
} catch (Exception $e) {
    error_log("[DICE-ROLL] Exception: " . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'Error: ' . $e->getMessage()]);
}
?>
