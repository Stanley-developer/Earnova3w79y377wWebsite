<?php
require_once '../config/database.php';
require_once '../includes/session.php';

header('Content-Type: application/json');

try {
    $pdo = getDBConnection();
    
    // Get top 10 players by profit
    $stmt = $pdo->prepare("
        SELECT 
            u.id,
            u.username,
            u.full_name,
            u.profile_picture,
            s.total_spins,
            s.total_wins,
            s.total_profit,
            s.biggest_win
        FROM spin_win_stats s
        JOIN users u ON s.user_id = u.id
        ORDER BY s.total_profit DESC
        LIMIT 10
    ");
    $stmt->execute();
    $leaderboard = $stmt->fetchAll();
    
    echo json_encode([
        'success' => true,
        'leaderboard' => $leaderboard
    ]);
    
} catch (PDOException $e) {
    echo json_encode([
        'success' => false,
        'message' => 'Failed to load leaderboard'
    ]);
}
