<?php
ob_start();

require_once 'config/database.php';
require_once 'includes/session.php';
require_once 'includes/connect.php';

// Require authentication
requireLogin();
checkSessionTimeout();

// Get current user data
$user = getCurrentUser();
$user_id = $user['id'];

try {
    $pdo = getDBConnection();
    
    // Fetch user details with balances
    $stmt = $pdo->prepare("SELECT u.*, b.total_balance, b.task_earnings, b.referral_earnings FROM users u LEFT JOIN balances b ON u.id = b.user_id WHERE u.id = ?");
    $stmt->execute([$user_id]);
    $user_data = $stmt->fetch();
    
    if (!$user_data) {
        header('Location: login.php');
        exit;
    }
    
    // Check if user agreed to post-video terms
    $video_post_agreed = isset($_SESSION['post_video_agreed_' . $user_id]) ? $_SESSION['post_video_agreed_' . $user_id] : false;
    
    // Handle AJAX request to agree video terms
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['ajax']) && $_POST['ajax'] && isset($_POST['action']) && $_POST['action'] === 'agree_video_terms') {
      ob_end_clean();
      header('Content-Type: application/json; charset=utf-8');
      $_SESSION['post_video_agreed_' . $user_id] = true;
      echo json_encode(['success' => true, 'message' => 'Post Video Terms agreed']);
      exit;
    }
    
    // Platform prices per 10 participants (in Naira)
    $platform_prices = [
        'youtube' => ['name' => 'YouTube', 'price' => 400],
        'tiktok' => ['name' => 'TikTok', 'price' => 320],
        'instagram' => ['name' => 'Instagram', 'price' => 350],
        'facebook' => ['name' => 'Facebook', 'price' => 350],
        'twitter' => ['name' => 'Twitter/X', 'price' => 380],
        'linkedin' => ['name' => 'LinkedIn', 'price' => 350]
    ];

    // Platform URL patterns used to validate that provided video links match the selected platform
    $platform_url_patterns = [
      'tiktok' => ['tiktok.com', 'vm.tiktok.com'],
      'instagram' => ['instagram.com', 'instagr.am'],
      'twitter' => ['twitter.com', 'x.com'],
      'facebook' => ['facebook.com', 'fb.com', 'fb.me'],
      'linkedin' => ['linkedin.com'],
      'youtube' => ['youtube.com', 'youtu.be']
    ];

    function validatePlatformUrl($url, $platform, $patterns) {
      $url_lower = strtolower($url);
      if (!isset($patterns[$platform])) {
        return false;
      }
      foreach ($patterns[$platform] as $pattern) {
        if (strpos($url_lower, $pattern) !== false) {
          return true;
        }
      }
      return false;
    }
    
    // Handle form submission
    $message = '';
    $messageType = '';
    
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'upload_video') {
        $title = trim($_POST['title'] ?? '');
        $description = trim($_POST['description'] ?? '');
        $video_url = trim($_POST['video_url'] ?? '');
        $platform = $_POST['platform'] ?? '';
        $video_duration = floatval($_POST['video_duration'] ?? 0);
        $video_mp4 = null;
        $thumbnail = null;
        $participants = intval($_POST['participants'] ?? 10);
        
        // Validation
        if (empty($title) || empty($video_url) || empty($platform)) {
            $message = 'Please fill in all required fields (Title, Video URL, Platform)';
            $messageType = 'error';
        } elseif (!filter_var($video_url, FILTER_VALIDATE_URL)) {
            $message = 'Please provide a valid Video URL';
            $messageType = 'error';
        } elseif (!isset($platform_prices[$platform])) {
            $message = 'Invalid platform selected';
            $messageType = 'error';
        } elseif (!validatePlatformUrl($video_url, $platform, $platform_url_patterns)) {
          $message = 'Video URL does not match selected platform.';
          $messageType = 'error';
          } elseif ($participants < 10 || $participants > 1000) {
              $message = 'Participants must be between 10 and 1000';
              $messageType = 'error';
        } else {
            try {
                $video_length = $video_duration;
                
                // Handle video MP4 upload (optional)
                if (isset($_FILES['video_mp4']) && $_FILES['video_mp4']['error'] === UPLOAD_ERR_OK) {
                    $video_tmp = $_FILES['video_mp4']['tmp_name'];
                    $video_name = basename($_FILES['video_mp4']['name']);
                    $video_ext = strtolower(pathinfo($video_name, PATHINFO_EXTENSION));
                    
                    // Validate video file type
                    $allowed_video = ['mp4', 'mov', 'avi', 'mkv', 'webm'];
                    if (!in_array($video_ext, $allowed_video)) {
                        throw new Exception('Invalid video file type. Allowed: mp4, mov, avi, mkv, webm');
                    }
                    
                    $video_filename = 'video_' . time() . '_' . uniqid() . '.' . $video_ext;
                    $video_path = 'uploads/user_videos/' . $video_filename;
                    
                    if (!is_dir('uploads/user_videos')) {
                        mkdir('uploads/user_videos', 0755, true);
                    }
                    
                    if (move_uploaded_file($video_tmp, $video_path)) {
                        $video_mp4 = $video_path;
                    }
                    
                    // Check if video exceeds 15 seconds (from JS detection)
                    if ($video_length > 15) {
                        $message .= ' Note: Your video is longer than 15 seconds. Please ensure it meets platform requirements. ';
                    }
                }
                
                // Handle thumbnail upload (optional)
                if (isset($_FILES['thumbnail']) && $_FILES['thumbnail']['error'] === UPLOAD_ERR_OK) {
                    $thumb_tmp = $_FILES['thumbnail']['tmp_name'];
                    $thumb_name = basename($_FILES['thumbnail']['name']);
                    $thumb_ext = strtolower(pathinfo($thumb_name, PATHINFO_EXTENSION));
                    
                    // Validate image file type
                    $allowed_images = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
                    if (in_array($thumb_ext, $allowed_images)) {
                        $thumb_filename = 'thumb_' . time() . '_' . uniqid() . '.' . $thumb_ext;
                        $thumb_path = 'uploads/video_thumbnails/' . $thumb_filename;
                        
                        if (!is_dir('uploads/video_thumbnails')) {
                            mkdir('uploads/video_thumbnails', 0755, true);
                        }
                        
                        if (move_uploaded_file($thumb_tmp, $thumb_path)) {
                            $thumbnail = $thumb_path;
                        }
                    }
                }
                
                // Calculate cost based on platform (fixed at 10 participants for user uploads)
                // Calculate cost based on platform and participants
                $base_price = $platform_prices[$platform]['price'];
                $total_cost = ($participants / 10) * $base_price;
                
                // Check if user has sufficient balance
                $available_balance = $user_data['referral_earnings'];
                
                if ($available_balance < $total_cost) {
                    $message = 'Insufficient balance. You need ₦' . number_format($total_cost, 2) . ' to post this video. Please deposit funds.';
                    $messageType = 'error';
                } else {
                    // Begin transaction
                    $pdo->beginTransaction();
                    
                    try {
                        // Generate unique video ID
                        $video_id = 'video_' . time() . '_' . uniqid();
                        $created_at = date('Y-m-d H:i:s');
                        
                        // Set rewards for free and premium users (6% of total cost distributed)
                        $reward_total = $total_cost * 0.06;
                        $free_reward = $reward_total / $participants;
                        $premium_reward = $free_reward * 1.5; // Premium users get 50% more
                        
                        // Insert video into available_videos table (store participants target)
                        $stmt = $pdo->prepare("\n                            INSERT INTO available_videos\n                            (video_id, title, description, video_url, platform, thumbnail_url, duration, free_reward, premium_reward, is_active, created_at, is_compulsory, uploaded_by_user_id, participants_target, video_file_path)\n                            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?, 0, ?, ?, ?)\n                        ");

                        $stmt->execute([
                          $video_id,
                          $title,
                          $description,
                          $video_url,
                          $platform,
                          $thumbnail,
                          $video_length,
                          $free_reward,
                          $premium_reward,
                          $created_at,
                          $user_id,
                          $participants,
                          $video_mp4
                        ]);
                        
                        // Deduct from user's balance
                        $stmt = $pdo->prepare("UPDATE balances SET referral_earnings = referral_earnings - ? WHERE user_id = ?");
                        $stmt->execute([$total_cost, $user_id]);
                        
                        // Record transaction
                        $stmt = $pdo->prepare("INSERT INTO transactions (user_id, transaction_type, amount, balance_type, description, reference_id, created_at) VALUES (?, ?, ?, ?, ?, ?, NOW())");
                        $description_text = "Posted video: {$title} on {$platform_prices[$platform]['name']}";
                        $stmt->execute([$user_id, 'video_post', $total_cost, 'prime_earnings', $description_text, "VIDEO-{$video_id}"]);
                        
                        $pdo->commit();
                        
                        $message = ($message ? $message : '') . 'Video posted successfully! Your video is now available for users to watch and earn.';
                        $messageType = 'success';
                        
                        // Refresh user data
                        $stmt = $pdo->prepare("SELECT u.*, b.total_balance, b.task_earnings, b.referral_earnings FROM users u LEFT JOIN balances b ON u.id = b.user_id WHERE u.id = ?");
                        $stmt->execute([$user_id]);
                        $user_data = $stmt->fetch();
                        
                    } catch (Exception $e) {
                        $pdo->rollBack();
                        throw $e;
                    }
                }
            } catch (Exception $e) {
                $message = 'Upload failed: ' . htmlspecialchars($e->getMessage());
                $messageType = 'error';
                error_log('Video upload error: ' . $e->getMessage());
            }
        }
    }
    
} catch (PDOException $e) {
    error_log("Upload Video Error: " . $e->getMessage());
    $error_message = "Unable to load page data.";
}

$username = htmlspecialchars($user_data['username'] ?? 'User');
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Upload Video - Earnova</title>
  <!-- Using internal CSS instead of post-task.css -->
  <style>
    :root {
      --bg-primary: linear-gradient(180deg, rgba(3, 9, 34, 1), rgba(4, 10, 36, 1));
      --bg-secondary: rgba(13, 24, 62, 0.82);
      --page-white: #f5f9ff;
      --page-mint: #4de1c1;
      --page-soft-blue: rgba(100, 154, 255, 0.2);
      --text-secondary: rgba(205, 219, 255, 0.8);
    }

    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }

    body {
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      background: var(--bg-primary);
      color: var(--page-white);
      min-height: 100vh;
    }

    .page-shell {
      display: flex;
      min-height: 100vh;
      padding-bottom: 80px;
    }

    /* Hide the aside on the user upload page and make the form full width */
    aside#sidebar {
      display: none;
    }

    .back-link {
      display: inline-flex;
      align-items: center;
      gap: 8px;
      color: var(--page-mint);
      text-decoration: none;
      font-weight: 600;
      font-size: 0.9rem;
      margin-bottom: 24px;
      transition: transform 0.2s ease;
    }

    .back-link:hover {
      transform: translateX(-4px);
    }

    .aside-welcome {
      display: flex;
      gap: 12px;
      margin-bottom: 32px;
      padding: 16px;
      background: rgba(77, 225, 193, 0.08);
      border: 1px solid rgba(77, 225, 193, 0.2);
      border-radius: 12px;
    }

    .aside-avatar {
      width: 48px;
      height: 48px;
      border-radius: 50%;
      overflow: hidden;
      border: 2px solid var(--page-mint);
    }

    .aside-avatar img {
      width: 100%;
      height: 100%;
      object-fit: cover;
    }

    .welcome-tag {
      font-size: 0.75rem;
      color: var(--text-secondary);
      margin-bottom: 4px;
    }

    .aside-welcome h3 {
      font-size: 1.1rem;
      margin-bottom: 4px;
    }

    .welcome-meta {
      font-size: 0.85rem;
      color: var(--page-mint);
      font-weight: 600;
    }

    .page-title {
      font-size: 1.8rem;
      margin-bottom: 12px;
      color: var(--page-white);
    }

    .side-description {
      color: var(--text-secondary);
      line-height: 1.6;
      font-size: 0.95rem;
    }

    main {
      flex: 1;
      max-width: none;
      width: 100%;
      margin: 0;
      padding: 40px 24px;
    }

    .hero-section {
      background: linear-gradient(135deg, rgba(77, 225, 193, 0.08), rgba(13, 24, 62, 0.78));
      border: 1px solid rgba(100, 154, 255, 0.3);
      border-radius: 20px;
      padding: 32px;
      margin-bottom: 32px;
    }

    .hero-content h1 {
      font-size: 2rem;
      margin-bottom: 12px;
      color: var(--page-white);
    }

    .hero-content p {
      color: var(--text-secondary);
      font-size: 1rem;
      line-height: 1.6;
    }

    .form-section {
      background: rgba(13, 24, 62, 0.6);
      border: 1px solid rgba(100, 154, 255, 0.25);
      border-radius: 20px;
      padding: 32px;
    }

    .task-form {
      display: flex;
      flex-direction: column;
      gap: 24px;
    }

    .form-group {
      display: flex;
      flex-direction: column;
      gap: 8px;
    }

    .form-group label {
      font-weight: 600;
      color: var(--page-white);
      font-size: 0.95rem;
    }

    .form-group input[type="text"],
    .form-group input[type="url"],
    .form-group input[type="file"],
    .form-group input[type="number"],
    .form-group textarea,
    .form-group select {
      padding: 14px 16px;
      background: rgba(6, 16, 48, 0.6);
      border: 1px solid rgba(100, 154, 255, 0.3);
      border-radius: 12px;
      color: var(--page-white);
      font-size: 0.95rem;
      transition: all 0.3s ease;
    }

    .form-group input:focus,
    .form-group textarea:focus,
    .form-group select:focus {
      outline: none;
      border-color: var(--page-mint);
      box-shadow: 0 0 0 3px rgba(77, 225, 193, 0.1);
    }

    .form-group small {
      color: var(--text-secondary);
      font-size: 0.85rem;
    }

    /* Word counter styling (copied from post-task.php) */
    .word-count-container {
      margin-top: 8px;
      display: flex;
      justify-content: space-between;
      align-items: center;
    }

    .word-counter {
      font-size: 0.9rem;
      color: rgba(245, 249, 255, 0.7);
      font-weight: 600;
    }

    .word-counter.warning {
      color: #FFB84D;
    }

    .word-counter.error {
      color: #FF6B6B;
    }

    .pricing-summary {
      background: rgba(77, 225, 193, 0.08);
      border: 1px solid rgba(77, 225, 193, 0.3);
      border-radius: 12px;
      padding: 20px;
      margin-top: 8px;
    }

    .pricing-summary h3 {
      font-size: 1.1rem;
      margin-bottom: 16px;
      color: var(--page-white);
    }

    .summary-row {
      display: flex;
      justify-content: space-between;
      padding: 10px 0;
      border-bottom: 1px solid rgba(77, 225, 193, 0.15);
      color: var(--text-secondary);
    }

    .summary-row:last-child {
      border-bottom: none;
    }

    .summary-row.total {
      font-weight: 700;
      font-size: 1.1rem;
      color: var(--page-white);
      margin-top: 8px;
      padding-top: 16px;
      border-top: 2px solid rgba(77, 225, 193, 0.3);
    }

    .submit-btn {
      padding: 16px 32px;
      background: linear-gradient(135deg, var(--page-mint), #2ec4b6);
      border: none;
      border-radius: 12px;
      color: #030922;
      font-weight: 700;
      font-size: 1rem;
      cursor: pointer;
      transition: all 0.3s ease;
      margin-top: 16px;
    }

    .submit-btn:hover {
      transform: translateY(-2px);
      box-shadow: 0 8px 20px rgba(77, 225, 193, 0.4);
    }

    .alert-message {
      position: fixed;
      top: 20px;
      right: -400px;
      padding: 16px 24px;
      border-radius: 12px;
      font-family: 'Segoe UI', sans-serif;
      font-size: 15px;
      z-index: 10000;
      opacity: 0;
      box-shadow: 0 10px 40px rgba(0, 0, 0, 0.2);
      transition: right 0.6s ease, opacity 0.6s ease;
      color: #fff;
      max-width: 400px;
    }

    .alert-success {
      background: rgba(77, 225, 193, 0.95);
      color: #030922;
      box-shadow: 0 10px 40px rgba(77, 225, 193, 0.4);
    }

    .alert-error {
      background: rgba(255, 77, 77, 0.95);
      color: #fff;
      box-shadow: 0 10px 40px rgba(255, 77, 77, 0.4);
    }

    .alert-message.show {
      right: 20px;
      opacity: 1;
    }

    .video-length-notice {
      display: flex;
      align-items: flex-start;
      gap: 12px;
      padding: 16px;
      border-radius: 12px;
      background: rgba(255, 193, 7, 0.15);
      border: 1px solid rgba(255, 193, 7, 0.3);
      margin-bottom: 24px;
    }

    .video-length-notice svg {
      width: 24px;
      height: 24px;
      color: #FFC107;
      flex-shrink: 0;
      margin-top: 2px;
    }

    .video-length-notice-content {
      flex: 1;
    }

    .video-length-notice-content h4 {
      color: #fff;
      font-size: 1rem;
      font-weight: 600;
      margin-bottom: 4px;
    }

    .video-length-notice-content p {
      color: rgba(255, 255, 255, 0.85);
      font-size: 0.9rem;
      line-height: 1.5;
    }

   .mobile-fintech-footer {
      display: none;
      position: fixed;
      left: 12px;
      right: 12px;
      bottom: 16px;
      padding: 10px;
      background: transparent;
      border: 1px solid rgba(86, 139, 241, 0.35);
      border-radius: 32px;
      backdrop-filter: blur(50px);
      box-shadow: 0 20px 60px rgba(4, 10, 36, 0.7);
      justify-content: space-around;
      align-items: center;
      z-index: 90;
    }

    .mobile-fintech-footer a {
      flex: 1;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      gap: 4px;
      text-decoration: none;
      color: rgba(205, 219, 255, 0.75);
      font-size: 0.45rem;
      letter-spacing: 0.06em;
      text-transform: uppercase;
      transition: all var(--transition-short);
      padding: 8px 4px;
      border-radius: 16px;
    }

    .mobile-fintech-footer a:nth-child(3) .icon-wrapper {
      width: 56px;
      height: 56px;
      border-radius: 50%;
      background: linear-gradient(135deg, rgba(77, 225, 193, 0.25), rgba(47, 91, 234, 0.25));
      backdrop-filter: blur(12px);
      border: 2px solid rgba(77, 225, 193, 0.4);
      display: flex;
      align-items: center;
      justify-content: center;
      box-shadow: 0 8px 24px rgba(77, 225, 193, 0.3);
    }

    .mobile-fintech-footer a:nth-child(3) svg {
      width: 28px;
      height: 28px;
    }

    .mobile-fintech-footer a.active {
      color: var(--page-mint);
    }

    .mobile-fintech-footer svg {
      width: 22px;
      height: 22px;
      fill: currentColor;
      filter: drop-shadow(0 4px 12px rgba(4, 10, 36, 0.4));
    }

    .mobile-fintech-footer a:hover {
      color: var(--page-mint);
      transform: translateY(-2px);
    }

    .mobile-fintech-footer a:nth-child(3):hover {
      transform: translateY(-14px);
    }
    
      @media (max-width: 680px) {

      .mobile-fintech-footer {
        display: flex;
      }
    }



    @media (max-width: 768px) {
      aside#sidebar {
        display: none;
      }

      .page-shell {
        flex-direction: column;
      }

      main {
        padding: 20px 16px 100px;
      }

      .mobile-fintech-footer {
        display: flex;
      }

      .hero-content h1 {
        font-size: 1.5rem;
      }

      .form-section {
        padding: 20px;
      }
    }
    /* Post-Video Terms Modal (matching post-task.php) */
    .ts-modal {
      display: none;
      position: fixed;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      background: rgba(3, 9, 34, 0.9);
      backdrop-filter: blur(8px);
      z-index: 99999;
      align-items: center;
      justify-content: center;
      padding: 20px;
    }

    .ts-modal.active {
      display: flex;
    }

    .ts-modal-content {
      background: rgba(6, 16, 48, 0.98);
      border: 1px solid rgba(100, 154, 255, 0.3);
      border-radius: 24px;
      padding: 32px;
      max-width: 600px;
      width: 100%;
      max-height: 80vh;
      overflow-y: auto;
      display: flex;
      flex-direction: column;
    }

    .ts-modal-header { margin-bottom: 24px; border-bottom: 1px solid rgba(100, 154, 255, 0.2); padding-bottom: 16px; }
    .ts-modal-header h2 { margin: 0; font-size: 1.5rem; color: var(--page-white); }

    .ts-modal-body { flex: 1; overflow-y: auto; margin-right: 8px; padding-right: 8px; }
    .ts-modal-body::-webkit-scrollbar { width: 6px; }
    .ts-modal-body::-webkit-scrollbar-track { background: rgba(100, 154, 255, 0.1); border-radius: 3px; }
    .ts-modal-body::-webkit-scrollbar-thumb { background: rgba(77, 225, 193, 0.3); border-radius: 3px; }
    .ts-modal-body::-webkit-scrollbar-thumb:hover { background: rgba(77, 225, 193, 0.5); }

    .ts-modal-body h3 { color: var(--page-white); margin-top: 20px; margin-bottom: 12px; font-size: 1.1rem; }
    .ts-modal-body p, .ts-modal-body ul { color: rgba(205, 219, 255, 0.8); line-height: 1.6; margin-bottom: 12px; font-size: 0.95rem; }

    .ts-modal-footer { display: flex; gap: 12px; justify-content: flex-end; align-items: center; border-top: 1px solid rgba(100, 154, 255, 0.2); padding-top: 20px; }

    .ts-checkbox-wrapper { background: rgba(77, 225, 193, 0.08); border: 1px solid rgba(77, 225, 193, 0.3); border-radius: 12px; padding: 16px; margin-bottom: 0; display: flex; align-items: center; gap: 12px; }
    .ts-checkbox { width: 20px; height: 20px; cursor: pointer; accent-color: var(--page-mint); }
    .ts-checkbox-label { color: rgba(205, 219, 255, 0.8); font-size: 0.9rem; cursor: pointer; }

    .ts-modal-actions { display: flex; gap: 12px; justify-content: flex-end; }

    .ts-btn { padding: 10px 16px; border-radius: 10px; border: 1px solid rgba(100, 154, 255, 0.08); background: transparent; color: var(--page-white); cursor: pointer; }
    .ts-btn.primary, .btn-primary { background: linear-gradient(135deg, var(--page-mint), #2ec4b6); color: #030922; border: none; font-weight: 700; }
    .btn-secondary { background: transparent; border: 1px solid rgba(100,154,255,0.12); color: var(--page-white); padding: 10px 14px; border-radius: 8px; }
    /* When modal is open hide page content behind it (match post-task behaviour) */
    body.ts-modal-open .page-shell,
    body.ts-modal-open header,
    body.ts-modal-open nav.mobile-fintech-footer {
      visibility: hidden !important;
      opacity: 0 !important;
      pointer-events: none !important;
    }
  </style>
</head>
<body>


<?php include 'header2.php'; ?>
<?php include 'doctype.php'; ?>
<?php include 'embed.php'; ?>

<?php if ($message): ?>
  <div id="alert-toast" class="alert-message alert-<?php echo $messageType; ?>">
    <?php echo htmlspecialchars($message); ?>
  </div>
<?php endif; ?>

<!-- Added JavaScript for client-side video duration detection (no FFmpeg needed) -->
<script>
document.addEventListener("DOMContentLoaded", () => {
  const alertToast = document.getElementById("alert-toast");
  if (alertToast) {
    setTimeout(() => alertToast.classList.add("show"), 100);
    setTimeout(() => alertToast.classList.remove("show"), 6000);
  }

  // Client-side video duration detection (works on shared hosting)
  const videoInput = document.getElementById('video_mp4');
  const durationField = document.getElementById('video_duration');
  
  if (videoInput) {
    videoInput.addEventListener('change', function(e) {
      const file = e.target.files[0];
      if (file && file.type.startsWith('video/')) {
        const video = document.createElement('video');
        video.preload = 'metadata';
        
        video.onloadedmetadata = function() {
          window.URL.revokeObjectURL(video.src);
          const duration = Math.floor(video.duration);
          durationField.value = duration;
          
          console.log('Video duration detected:', duration, 'seconds');
          
          if (duration > 15) {
            // Use toast instead of alert
            showToast('Warning: Your video is ' + duration + ' seconds long. The recommended maximum is 15 seconds. Please consider trimming your video before uploading.', 'error');
          }
        };
        
        video.src = URL.createObjectURL(file);
      }
    });
  }
});

// Generic toast helper for this page (uses the existing alert-toast element)
function showToast(message, type = 'success', duration = 6000) {
  let toast = document.getElementById('alert-toast');
  if (!toast) {
    toast = document.createElement('div');
    toast.id = 'alert-toast';
    toast.className = 'alert-message';
    document.body.appendChild(toast);
  }
  toast.className = 'alert-message alert-' + (type === 'error' ? 'error' : 'success');
  toast.textContent = message;
  // show
  toast.classList.add('show');
  clearTimeout(toast._hideTimer);
  toast._hideTimer = setTimeout(() => toast.classList.remove('show'), duration);
}

function updatePricing() {
  const platform = document.getElementById('platform').value;
  const platformPrices = <?php echo json_encode($platform_prices); ?>;
  
  if (platform && platformPrices[platform]) {
    const platformName = platformPrices[platform].name;
    const basePrice = platformPrices[platform].price;
    const participantsEl = document.getElementById('participants');
    const participants = participantsEl ? (parseInt(participantsEl.value) || 10) : 10;
    const totalCost = (participants / 10) * basePrice;
    
    document.getElementById('selected-platform').textContent = platformName;
    document.getElementById('selected-participants').textContent = participants;
    document.getElementById('base-price').textContent = '₦' + basePrice.toLocaleString('en-NG', {minimumFractionDigits: 2});
    document.getElementById('total-cost').textContent = '₦' + totalCost.toLocaleString('en-NG', {minimumFractionDigits: 2});
  } else {
    document.getElementById('selected-platform').textContent = '--';
    document.getElementById('selected-participants').textContent = '10';
    document.getElementById('base-price').textContent = '₦0.00';
    document.getElementById('total-cost').textContent = '₦0.00';
  }
}

// Patterns for client-side platform URL validation
const platformUrlPatterns = <?php echo json_encode($platform_url_patterns); ?>;

function validateVideoUrl() {
  const platformEl = document.getElementById('platform');
  const videoUrlEl = document.getElementById('video_url');
  if (!platformEl || !videoUrlEl) return true;

  const platform = platformEl.value;
  const url = (videoUrlEl.value || '').toLowerCase();
  if (!platform || !url) {
    videoUrlEl.setCustomValidity('');
    return true;
  }

  const patterns = platformUrlPatterns[platform];
  if (!patterns) {
    videoUrlEl.setCustomValidity('');
    return true;
  }

  let isValid = false;
  for (let pattern of patterns) {
    if (url.includes(pattern.toLowerCase())) {
      isValid = true;
      break;
    }
  }

  if (!isValid) {
    videoUrlEl.setCustomValidity('Video URL must match the selected platform');
  } else {
    videoUrlEl.setCustomValidity('');
  }

  return isValid;
}

function updateTitleCounter() {
  const titleInput = document.getElementById('title');
  const counter = document.getElementById('titleCounter');
  if (!titleInput || !counter) return;
  const text = titleInput.value;
  const charCount = text.length;
  counter.textContent = charCount + ' / 45';
  if (charCount >= 45) {
    counter.classList.add('error');
    counter.classList.remove('warning');
  } else if (charCount >= 38) {
    counter.classList.add('warning');
    counter.classList.remove('error');
  } else {
    counter.classList.remove('warning', 'error');
  }
}

function updateWordCounter() {
  const textarea = document.getElementById('description');
  const counter = document.getElementById('wordCounter');
  if (!textarea || !counter) return;
  const text = textarea.value;
  const charCount = text.length;
  counter.textContent = charCount + ' / 100';
  if (charCount >= 100) {
    counter.classList.add('error');
    counter.classList.remove('warning');
  } else if (charCount >= 85) {
    counter.classList.add('warning');
    counter.classList.remove('error');
  } else {
    counter.classList.remove('warning', 'error');
  }
  if (charCount > 100) {
    textarea.value = text.slice(0, 100);
    counter.textContent = '100 / 100';
    counter.classList.add('error');
  }
}

// Initialize pricing display and attach validation listeners
document.addEventListener('DOMContentLoaded', function() {
  updatePricing();
  const platformEl = document.getElementById('platform');
  const participantsEl = document.getElementById('participants');
  const videoUrlEl = document.getElementById('video_url');
  const titleEl = document.getElementById('title');
  const descEl = document.getElementById('description');
  if (platformEl) platformEl.addEventListener('change', function(){ updatePricing(); validateVideoUrl(); });
  if (participantsEl) participantsEl.addEventListener('input', updatePricing);
  if (participantsEl) participantsEl.addEventListener('change', updatePricing);
  if (videoUrlEl) {
    videoUrlEl.addEventListener('input', validateVideoUrl);
    videoUrlEl.addEventListener('blur', validateVideoUrl);
  }
  if (titleEl) {
    titleEl.addEventListener('input', updateTitleCounter);
    titleEl.addEventListener('change', updateTitleCounter);
    updateTitleCounter();
  }
  if (descEl) {
    descEl.addEventListener('input', updateWordCounter);
    descEl.addEventListener('change', updateWordCounter);
    updateWordCounter();
  }
});
</script>

  <div class="page-shell">
    <aside id="sidebar">
      <a class="back-link" href="dashboard.php">← Dashboard</a>
      <div class="aside-welcome">
        <div class="aside-avatar">
          <img src="<?php echo !empty($user_data['profile_picture']) ? htmlspecialchars($user_data['profile_picture']) : 'front/assets/images/default-avatar.png'; ?>" alt="User avatar">
        </div>
        <div>
          <p class="welcome-tag">Welcome back</p>
          <h3><?php echo $username; ?></h3>
          <p class="welcome-meta">Prime Balance: ₦<?php echo number_format($user_data['referral_earnings'], 2); ?></p>
        </div>
      </div>
      <div>
        <h2 class="page-title">Upload Video</h2>
        <p class="side-description">Post your video and reach thousands of users. Users will watch your video and earn rewards while promoting your content.</p>
      </div>
    </aside>
    
    <main>
      <section class="hero-section">
        <div class="hero-content">
          <h1>Upload Your Video</h1>
            <p>Share your content with our community. Users watch, engage, and earn while promoting your video across social platforms.</p>
            <!--<div style="margin-top:12px;">-->
            <!--  <button type="button" class="ts-btn" onclick="openVideoTermsModal()">View Post Video Instructions</button>-->
            <!--</div>-->
            
                
               <!-- Added clickable checkbox to view post task instructions -->
        <div style="background: rgba(77, 225, 193, 0.08); border: 1px solid rgba(77, 225, 193, 0.3); border-radius: 12px; padding: 16px; margin-top: 16px; display: flex; align-items: center; gap: 12px; cursor: pointer;" onclick="openVideoTermsModal()">
          <input type="checkbox" id="postHeroCheckbox" style="width: 20px; height: 20px; cursor: pointer; accent-color: var(--page-mint, #4de1c1);" onclick="event.stopPropagation();">
          <label for="postHeroCheckbox" style="color: rgba(205, 219, 255, 0.8); font-size: 0.9rem; cursor: pointer; margin: 0;">View Post Video Instructions</label>
        </div>
        
        </div>
      </section>

      <section class="form-section">
        <div class="video-length-notice">
          <svg viewBox="0 0 24 24" fill="currentColor">
            <path d="M12 2a10 10 0 1 0 10 10A10 10 0 0 0 12 2zm1 15h-2v-2h2zm0-4h-2V7h2z"/>
          </svg>
          <div class="video-length-notice-content">
            <h4>Video Length Requirement</h4>
            <p>Maximum video length: 15 seconds.
Videos longer than 15 seconds will be automatically trimmed to the first 15 seconds when uploaded.</p>
          </div>
        </div>

        <form method="POST" enctype="multipart/form-data" class="task-form">
          <input type="hidden" name="action" value="upload_video">
          <!-- Hidden field to store JavaScript-detected video duration -->
          <input type="hidden" id="video_duration" name="video_duration" value="0">
          
          <div class="form-group">
            <label for="title">Video Title *</label>
            <input type="text" id="title" name="title" required placeholder="Enter a catchy title for your video">
            <div class="word-count-container">
              <span class="word-counter" id="titleCounter">0 / 45</span>
            </div>
          </div>

          <div class="form-group">
            <label for="description">Description</label>
            <textarea id="description" name="description" rows="4" placeholder="Describe what your video is about (optional)"></textarea>
            <div class="word-count-container">
              <span class="word-counter" id="wordCounter">0 / 100</span>
            </div>
          </div>

          <div class="form-group">
            <label for="video_mp4">Upload Video Mp4 (Optional)</label>
            <input type="file" id="video_mp4" name="video_mp4" accept="video/mp4,video/mov,video/avi,video/mkv,video/webm">
            <small>Optional: Upload your video file directly (Recommended max 15 seconds)</small>
          </div>

          <div class="form-group">
            <label for="video_url">Video URL *</label>
            <input type="url" id="video_url" name="video_url" required placeholder="https://platform.com/your-video">
            <small>Paste the link to your video on the platform (YouTube, TikTok, Instagram, etc.)</small>
          </div>

          <div class="form-group">
            <label for="platform">Platform *</label>
            <select id="platform" name="platform" required onchange="updatePricing()">
              <option value="">-- Select Platform --</option>
              <?php foreach ($platform_prices as $key => $platform): ?>
                <option value="<?php echo $key; ?>"><?php echo $platform['name']; ?> - ₦<?php echo number_format($platform['price'], 2); ?>/10 participants</option>
              <?php endforeach; ?>
            </select>
            <small>Choose the social media platform where your video is hosted</small>
          </div>

          <div class="form-group">
            <label for="participants">Participants *</label>
            <input type="number" id="participants" name="participants" required min="10" max="1000" value="10" oninput="updatePricing()" />
            <small>Set how many participants you want to reach (min 10, max 1000)</small>
          </div>
         

          <div class="form-group">
            <label for="thumbnail">Thumbnail Image (Optional)</label>
            <input type="file" id="thumbnail" name="thumbnail" accept="image/jpeg,image/jpg,image/png,image/gif,image/webp">
            <small>Upload a custom thumbnail image for your video (optional)</small>
          </div>

          <div class="pricing-summary">
            <h3>Cost Summary</h3>
            <div class="summary-row">
              <span>Platform:</span>
              <span id="selected-platform">--</span>
            </div>
            <div class="summary-row">
              <span>Participants:</span>
              <span id="selected-participants">10</span>
            </div>
            <div class="summary-row">
              <span>Base Price (per 10):</span>
              <span id="base-price">₦0.00</span>
            </div>
            <div class="summary-row total">
              <span>Total Cost:</span>
              <span id="total-cost">₦0.00</span>
            </div>
            <div class="summary-row">
              <span>Your Prime Balance:</span>
              <span style="color: #4de1c1;">₦<?php echo number_format($user_data['referral_earnings'], 2); ?></span>
            </div>
          </div>

          <button type="submit" class="submit-btn">Upload Video</button>
        </form>
      </section>
    </main>
  </div>

  <nav class="mobile-fintech-footer">
    
  <a href="dashboard.php">
    <svg viewBox="0 0 24 24"><path d="M12 3a9 9 0 1 1 0 18 9 9 0 0 1 0-18Zm1 4h-2v6h6v-2h-4V7Z"/></svg>
    <span>Dashboard</span>
  </a>

  <!-- Premium (crown icon) -->
  <a href="membership.php">
    <svg viewBox="0 0 24 24"><path d="M5 7l2.5 5 4.5-4 4.5 4L19 7l2 13H3l2-13Z"/></svg>
    <span>Premium</span>
  </a>

  <a href="post-task.php">
<svg viewBox="0 0 24 24" aria-hidden="true">
  <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8l-6-6Zm1 14h-3v3h-2v-3H7v-2h3v-3h2v3h3v2Zm-3-9V3.5L18.5 8H12Z"/>
</svg>
    
    <span>Post Advert</span>
  </a>
  
  

  <a href="history.php">
  <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
    <path d="M13 3a9 9 0 1 0 9 9h-2a7 7 0 1 1-7-7V3l4 4-4 4V7a5 5 0 1 0 5 5h2a7 7 0 1 1-7-7z"/>
  </svg>
  <span>History</span>
</a>


  <a href="profile.php">
    <svg viewBox="0 0 24 24"><path d="M12 2a6 6 0 0 1 6 6c0 3.31-2.69 6-6 6s-6-2.69-6-6a6 6 0 0 1 6-6Zm0 14c4.42 0 8 1.79 8 4v2H4v-2c0-2.21 3.58-4 8-4Z"/></svg>
    <span>Profile</span>
  </a>
</nav>

  <!-- Post-Video Terms Modal Markup (structure matching post-task.php) -->
  <div id="video-terms-modal" class="ts-modal" aria-hidden="true" role="dialog">
    <div class="ts-modal-content" role="document">
      <div class="ts-modal-header">
        <h2>Post Video Instructions</h2>
      </div>
      <div class="ts-modal-body">
        <p><strong>Earnova Digital – Post Video Guidelines</strong></p>

        <h3>1. Introduction</h3>
        <p>Please read these Post Video Terms carefully. By agreeing you confirm that the content you post complies with platform rules and does not infringe on copyrights, trademarks, or third-party rights. You also confirm you have the right to upload or share the video link and any thumbnail you provide.</p>

        <h3>2. Content Rules</h3>
        <p>Do not post content that is illegal, sexually explicit, hateful, violent, or otherwise violates our community standards. Earnova reserves the right to remove content and suspend accounts that breach these terms.</p>

        <h3>3. Rewards & Liability</h3>
        <p>By agreeing, you acknowledge that users may view, share, and interact with your video, and that rewards are distributed according to our published reward structure. Earnova is not responsible for third-party platform enforcement or takedowns.</p>

        <h3>4. Promotions & Disclosures</h3>
        <p>If you have promotional or sponsored material, ensure you follow disclosure requirements for the target platform. Do not impersonate other individuals or brands.</p>
      </div>
      <div class="ts-modal-footer">
        <div class="ts-checkbox-wrapper">
          <input type="checkbox" id="videoTsCheckbox" class="ts-checkbox" <?php echo $video_post_agreed ? 'checked disabled' : ''; ?> />
          <label for="videoTsCheckbox" class="ts-checkbox-label">I agree</label>
        </div>
        <div class="ts-modal-actions">
          <button class="btn-secondary" id="videoTsCloseBtn" onclick="closeVideoTermsModal()" style="<?php echo $video_post_agreed ? 'display: block;' : 'display: none;'; ?>">Close</button>
          <button class="btn-primary" id="videoTsAgreeBtn" onclick="agreeVideoTermsAndClose(this)" style="<?php echo $video_post_agreed ? 'display: none;' : 'display: block;'; ?>">Agree &amp; Continue</button>
        </div>
      </div>
    </div>
  </div>

  <script>
    // Video Terms modal functions
    function openVideoTermsModal() {
      const el = document.getElementById('video-terms-modal');
      if (el) el.classList.add('active');
      document.body.classList.add('ts-modal-open');
    }

    function closeVideoTermsModal() {
      const el = document.getElementById('video-terms-modal');
      if (el) el.classList.remove('active');
      document.body.classList.remove('ts-modal-open');
    }

    function agreeVideoTermsAndClose(btn) {
      if (!btn) return;
      btn.disabled = true;
      const oldText = btn.textContent;
      btn.textContent = 'Agreeing...';

      fetch(window.location.href, {
        method: 'POST',
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        body: 'ajax=1&action=agree_video_terms'
      }).then(r => r.json()).then(data => {
        if (data && data.success) {
          showToast(data.message || 'Agreed to terms', 'success');
          closeVideoTermsModal();
          setTimeout(() => { location.reload(); }, 700);
        } else {
          showToast((data && data.message) ? data.message : 'Unable to record agreement', 'error');
          btn.disabled = false;
          btn.textContent = oldText;
        }
      }).catch(err => {
        console.error(err);
        showToast('Network error while saving agreement', 'error');
        btn.disabled = false;
        btn.textContent = oldText;
      });
    }

    // Open modal automatically if user hasn't agreed yet
    document.addEventListener('DOMContentLoaded', function() {
      const hasAgreed = <?php echo ($video_post_agreed ? 'true' : 'false'); ?>;
      if (!hasAgreed) {
        // Defer slightly so page paints first
        setTimeout(openVideoTermsModal, 220);
      }
    });
  </script>
</body>
</html>
