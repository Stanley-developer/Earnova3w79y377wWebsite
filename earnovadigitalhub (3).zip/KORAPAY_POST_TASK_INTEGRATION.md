# Korapay Integration for Post-Task.php

## Overview
This documentation covers the integration of Korapay as a payment option for the Post-Task feature in Earnova Digital Hub. Users can now deposit funds via Korapay to pay for posting tasks.

## Files Modified/Created

### 1. **post-task.php** (Modified)
- Added Korapay configuration import
- Added Korapay option to payment source dropdown
- Added Korapay modal and JavaScript functions
- Added Korapay callback handler
- Updated form submission to handle Korapay payments

**Key Changes:**
- New payment source option: "Deposit via Korapay"
- Two modals now: Paystack and Korapay confirmation dialogs
- JavaScript functions: `showKorapayModal()`, `closeKorapayModal()`, `proceedWithKorapay()`
- Callback handler for Korapay redirect after payment

### 2. **api/post-task-korapay-pay.php** (New)
This is the payment initialization endpoint that creates a Korapay checkout.

**Endpoint:** `POST /api/post-task-korapay-pay.php`

**Request Body (JSON):**
```json
{
  "payment_type": "post_task_deposit",
  "amount": 5000
}
```

**Response (Success):**
```json
{
  "status": true,
  "message": "Checkout initialized",
  "checkout_url": "https://checkout.korapay.com/...",
  "reference": "EARNOVA-TASK-12345-1234567890-1234"
}
```

**Response (Error):**
```json
{
  "status": false,
  "message": "Payment initialization failed"
}
```

**Features:**
- Validates user authentication
- Generates unique payment reference
- Builds Korapay payload with metadata
- Returns checkout URL for redirect
- Debug mode available via `?debug=1`

### 3. **api/korapay-webhook.php** (New)
This is the webhook endpoint that receives payment notifications from Korapay.

**Webhook Endpoint:** `POST /api/korapay-webhook.php`

**Webhook Payload (from Korapay):**
```json
{
  "reference": "EARNOVA-TASK-12345-1234567890-1234",
  "status": "success",
  "amount": 5000,
  "metadata": {
    "user_id": "12345",
    "payment_type": "post_task_deposit",
    "platform": "Earnova Digital Hub - Post Task"
  },
  "customer": {
    "email": "user@example.com"
  }
}
```

**Processing Flow:**
1. Validates webhook signature (optional but recommended)
2. Verifies payment hasn't been processed before
3. Updates user balance with deposit amount
4. Records transaction in database
5. Logs all activity for debugging

**Features:**
- Duplicate payment prevention
- Comprehensive error logging
- Support for success, pending, and failed statuses
- Automatic balance update on successful payment

### 4. **database/setup-korapay-post-task.php** (New)
Database schema setup script for Korapay post-task payments.

**New Table: `korapay_post_task_payments`**
```sql
CREATE TABLE korapay_post_task_payments (
  id INT PRIMARY KEY AUTO_INCREMENT,
  user_id INT NOT NULL,
  reference VARCHAR(100) NOT NULL UNIQUE,
  amount DECIMAL(10, 2) NOT NULL,
  status VARCHAR(50) NOT NULL,
  metadata JSON,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id),
  INDEX idx_user_id (user_id),
  INDEX idx_reference (reference),
  INDEX idx_status (status),
  INDEX idx_created_at (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
```

## Setup Instructions

### 1. Run Database Setup
Execute the setup script to create the necessary database table:
```bash
php /database/setup-korapay-post-task.php
```

### 2. Configure Korapay API Keys
Ensure your Korapay API keys are properly configured in `config/korapay.php`:
```php
define('KORAPAY_PUBLIC_KEY', getenv('KORAPAY_PUBLIC_KEY') ?: 'pk_test_...');
define('KORAPAY_SECRET_KEY', getenv('KORAPAY_SECRET_KEY') ?: 'sk_test_...');
```

### 3. Configure Webhook URL
Set up your webhook URL in Korapay dashboard:
- Webhook URL: `https://your-domain.com/api/korapay-webhook.php`
- Enable webhook signature verification for security

### 4. Update Return URL
The return URL after payment is automatically set to:
- `https://your-domain.com/post-task.php`

## Payment Flow

### User Flow
1. User fills in task posting form
2. Selects "Deposit via Korapay" as payment source
3. Enters amount and clicks "Post Task Now"
4. Korapay confirmation modal appears
5. User clicks "Continue to Deposit"
6. JavaScript initializes Korapay payment via `/api/post-task-korapay-pay.php`
7. User is redirected to Korapay checkout page
8. User completes payment on Korapay
9. Korapay redirects back to `post-task.php` with reference and status
10. Payment is verified and balance is updated
11. Success/error message is displayed

### Backend Flow
1. **post-task-korapay-pay.php:**
   - Receives payment initialization request
   - Creates unique reference
   - Calls `initializeKorapayCharge()` from korapay config
   - Returns checkout URL to frontend

2. **api/korapay-webhook.php:**
  - Receives webhook from Korapay
   - Verifies signature (optional)
   - Checks for duplicate payments
   - Updates user balance
   - Records transaction

3. **post-task.php (Callback):**
   - Handles redirect from Korapay
   - Verifies payment status
   - Updates balance if not already processed by webhook
   - Displays confirmation message

## Reference Format
Korapay post-task payment references follow this format:
```
EARNOVA-TASK-{user_id}-{timestamp}-{random_4_digits}
Example: EARNOVA-TASK-12345-1734000000-4567
```

This ensures:
- Easy identification of post-task payments vs other payment types
- Uniqueness across all users
- Easy filtering in logs and analytics

## Transaction Recording
Each successful Korapay deposit creates:
1. **Entry in `korapay_post_task_payments` table** - Tracks Korapay-specific data
2. **Entry in `transactions` table** - General transaction ledger with type `korapay_deposit_post_task`
3. **Balance update** - Adds amount to user's `referral_earnings` (Prime Wallet)

## Error Handling

### Frontend Errors
- Invalid JSON response from payment API
- Network errors during checkout initialization
- Missing required form fields

### Backend Errors
- Database connection failures
- Invalid Korapay API response
- Missing or invalid user data
- Duplicate payment attempts

All errors are logged to:
- PHP error log (default location)
- `logs/korapay_webhook.log` - Detailed webhook processing log
- `logs/korapay_debug.log` - API request/response debugging

## Debugging

### Enable Debug Mode
Pass `?debug=1` to the API endpoints:
```
/api/post-task-korapay-pay.php?debug=1
```

Or set environment variable:
```bash
export KORAPAY_DEBUG=1
```

### View Logs
```bash
tail -f /logs/korapay_webhook.log
tail -f /logs/korapay_debug.log
```

## Testing

### Test Payment Flow (Sandbox)
1. Use test Korapay API keys
2. Use test card details provided by Korapay
3. Monitor logs for successful webhook delivery
4. Verify balance updates in database

### Webhook Testing (ngrok)
For local testing, use ngrok to expose your local server:
```bash
ngrok http 80
# Update webhook URL in Korapay dashboard to: https://your-ngrok-url.ngrok.io/api/korapay-webhook.php
```

## Security Considerations

1. **API Key Protection:**
   - Store keys in environment variables
   - Never commit keys to version control
   - Rotate keys regularly

2. **Webhook Signature Verification:**
   - Always verify Korapay webhook signature
   - Use `KORAPAY_SECRET_KEY` for validation
   - Reject webhooks with invalid signatures

3. **Payment Reference:**
   - Check for duplicate references before processing
   - Use unique references for each payment
   - Reference format includes user ID for validation

4. **HTTPS Only:**
   - Ensure all endpoints use HTTPS in production
   - Webhook should be received over HTTPS only
   - Redirect URL should use HTTPS

## Troubleshooting

### Payment Initialization Fails
**Problem:** "Payment initialization failed"
**Solution:**
- Check Korapay API keys
- Verify network connectivity
- Enable debug mode: `?debug=1`
- Check `logs/korapay_debug.log`

### Webhook Not Processing
**Problem:** Balance not updated after payment
**Solution:**
- Verify webhook URL in Korapay dashboard
- Check firewall rules allow Korapay IPs
- Enable webhook logging
- Check `logs/korapay_webhook.log`

### Duplicate Payments
**Problem:** Same payment processed multiple times
**Solution:**
- System checks reference uniqueness
- If webhook fires multiple times, only first is processed
- Check database: `SELECT * FROM korapay_post_task_payments WHERE reference = '...'`

### Balance Not Updating
**Problem:** User balance shows no change after payment
**Solution:**
- Verify webhook was received and processed successfully
- Check `logs/korapay_webhook.log` for errors
- Verify `balances` table record exists for user
- Check database transactions

## Integration with Existing Code

### Payment Source Handling
The post-task.php form now supports three payment sources:
1. **prime_earnings** - Wallet payment (no API call)
2. **paystack** - Paystack integration (existing)
3. **korapay** - Korapay integration (new)

### Balance Updates
Both Paystack and Korapay deposits credit to `referral_earnings` column, which serves as the "Prime Wallet" for task posting.

### Transaction Types
New transaction type added:
- `korapay_deposit_post_task` - Tracks Korapay deposits for post-task feature

## Support and Maintenance

### Regular Maintenance
- Monitor `logs/korapay_webhook.log` for errors
- Check failed payment attempts
- Update Korapay integration if API changes
- Test payment flow monthly

### Updates
If Korapay API changes:
- Update `config/korapay.php` functions if needed
- Test all payment flows
- Update webhook signature verification if format changes
- Document changes in this file

## Contact & Support
For issues or questions:
- Check logs for detailed error information
- Review this documentation
- Contact Korapay support: https://support.korapay.com
- Contact Earnova support team

---
**Last Updated:** 2025-12-11
**Korapay API Version:** v1
**Integration Status:** Production Ready
