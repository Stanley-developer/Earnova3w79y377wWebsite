<?php
session_start();
require_once 'config/database.php';
require_once 'includes/session.php';
require_once 'includes/connect.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$user_id = $_SESSION['user_id'];

// Fetch user data
$stmt = $conn->prepare("SELECT u.*, b.total_balance, b.task_earnings, b.referral_earnings FROM users u LEFT JOIN balances b ON u.id = b.user_id WHERE u.id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();
$stmt->close();

$is_premium = ($user['membership_type'] === 'premium');
if (!$is_premium) {
    $_SESSION['error_message'] = "Premium membership required to access profile verification.";
    header('Location: membership.php');
    exit();
}

// Check existing verification
$stmt = $conn->prepare("SELECT * FROM user_verification WHERE user_id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$verification = $stmt->get_result()->fetch_assoc();
$stmt->close();

$career_categories = [
    'Web Development',
    'Graphic Design',
    'Content Writing',
    'Digital Marketing',
    'Video Editing',
    'Data Entry',
    'Virtual Assistant',
    'Social Media Management',
    'SEO Specialist',
    'Mobile App Development',
    'UI/UX Design',
    'Photography',
    'Voice Over',
    'Translation',
    'Customer Support'
];

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nin = trim($_POST['nin']);
    $full_name = trim($_POST['full_name']);
    $dob = $_POST['date_of_birth'];
    $location = trim($_POST['location']);
    $phone = trim($_POST['phone_number']);
    $email = trim($_POST['email']);
    $recent_jobs = trim($_POST['recent_jobs']);
    
    $career1 = isset($_POST['career1']) ? trim($_POST['career1']) : null;
    $career2 = isset($_POST['career2']) ? trim($_POST['career2']) : null;
    
    // Handle file uploads
    $profile_picture = null;
    $portfolio_cv = null;
    
    if (isset($_FILES['profile_picture']) && $_FILES['profile_picture']['error'] === 0) {
        $upload_dir = 'uploads/verification/';
        if (!file_exists($upload_dir)) {
            mkdir($upload_dir, 0777, true);
        }
        $file_ext = pathinfo($_FILES['profile_picture']['name'], PATHINFO_EXTENSION);
        $profile_picture = $upload_dir . 'profile_' . $user_id . '_' . time() . '.' . $file_ext;
        move_uploaded_file($_FILES['profile_picture']['tmp_name'], $profile_picture);
    }
    
    if (isset($_FILES['portfolio_cv']) && $_FILES['portfolio_cv']['error'] === 0) {
        $upload_dir = 'uploads/verification/';
        if (!file_exists($upload_dir)) {
            mkdir($upload_dir, 0777, true);
        }
        $file_ext = pathinfo($_FILES['portfolio_cv']['name'], PATHINFO_EXTENSION);
        $portfolio_cv = $upload_dir . 'portfolio_' . $user_id . '_' . time() . '.' . $file_ext;
        move_uploaded_file($_FILES['portfolio_cv']['tmp_name'], $portfolio_cv);
    }
    
    $stmt = $conn->prepare("UPDATE users SET career1 = ?, career2 = ? WHERE id = ?");
    $stmt->bind_param("ssi", $career1, $career2, $user_id);
    $stmt->execute();
    $stmt->close();
    
    // Insert or update verification
    if ($verification) {
        $stmt = $conn->prepare("UPDATE user_verification SET nin = ?, full_name = ?, date_of_birth = ?, location = ?, phone_number = ?, email = ?, profile_picture = COALESCE(?, profile_picture), portfolio_cv = COALESCE(?, portfolio_cv), recent_jobs = ?, verification_status = 'pending', submitted_at = NOW() WHERE user_id = ?");
        $stmt->bind_param("sssssssssi", $nin, $full_name, $dob, $location, $phone, $email, $profile_picture, $portfolio_cv, $recent_jobs, $user_id);
    } else {
        $stmt = $conn->prepare("INSERT INTO user_verification (user_id, nin, full_name, date_of_birth, location, phone_number, email, profile_picture, portfolio_cv, recent_jobs) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("isssssssss", $user_id, $nin, $full_name, $dob, $location, $phone, $email, $profile_picture, $portfolio_cv, $recent_jobs);
    }
    
    if ($stmt->execute()) {
        $success_message = "Verification submitted successfully! Awaiting admin approval.";
        // Refresh verification data
        $stmt = $conn->prepare("SELECT * FROM user_verification WHERE user_id = ?");
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        $verification = $stmt->get_result()->fetch_assoc();
        
        // Refresh user data to get updated careers
        $stmt = $conn->prepare("SELECT u.*, b.total_balance, b.task_earnings, b.referral_earnings FROM users u LEFT JOIN balances b ON u.id = b.user_id WHERE u.id = ?");
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        $result = $stmt->get_result();
        $user = $result->fetch_assoc();
    } else {
        $error_message = "Failed to submit verification. Please try again.";
    }
    $stmt->close();
}

$status_badge = '';
$status_color = '';
if ($verification) {
    switch ($verification['verification_status']) {
        case 'approved':
            $status_badge = '✓ Verified';
            $status_color = 'var(--page-mint)';
            break;
        case 'pending':
            $status_badge = '⏳ Pending Review';
            $status_color = '#fbbf24';
            break;
        case 'rejected':
            $status_badge = '✗ Rejected';
            $status_color = '#ef4444';
            break;
    }
} else {
    $status_badge = '⚠ Not Verified';
    $status_color = '#94a3b8';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Profile Verification - FlowEarner</title>
  <style>
    <?php include 'front/assets/css/shared-styles.css'; ?>
    
    /* Additional styles for career selection and improved UI */
    .career-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
      gap: 16px;
      margin-top: 12px;
    }
    
    .career-option {
      position: relative;
    }
    
    .career-option input[type="radio"] {
      position: absolute;
      opacity: 0;
      cursor: pointer;
    }
    
    .career-label {
      display: block;
      padding: 14px 18px;
      border-radius: 12px;
      border: 2px solid rgba(86, 139, 241, 0.3);
      background: rgba(13, 24, 62, 0.5);
      color: rgba(216, 230, 255, 0.9);
      font-size: 0.9rem;
      font-weight: 600;
      text-align: center;
      cursor: pointer;
      transition: all 0.3s ease;
    }
    
    .career-option input[type="radio"]:checked + .career-label {
      border-color: var(--page-mint);
      background: rgba(77, 225, 193, 0.15);
      color: var(--page-mint);
      box-shadow: 0 0 20px rgba(77, 225, 193, 0.3);
    }
    
    .career-label:hover {
      border-color: rgba(77, 225, 193, 0.5);
      transform: translateY(-2px);
    }
    
    .status-banner {
      padding: 20px;
      border-radius: 16px;
      margin-bottom: 24px;
      display: flex;
      align-items: center;
      gap: 16px;
      font-weight: 600;
      font-size: 1rem;
    }
    
    .status-banner.approved {
      background: rgba(77, 225, 193, 0.15);
      border: 2px solid rgba(77, 225, 193, 0.4);
      color: var(--page-mint);
    }
    
    .status-banner.pending {
      background: rgba(251, 191, 36, 0.15);
      border: 2px solid rgba(251, 191, 36, 0.4);
      color: #fbbf24;
    }
    
    .status-banner.rejected {
      background: rgba(239, 68, 68, 0.15);
      border: 2px solid rgba(239, 68, 68, 0.4);
      color: #ef4444;
    }
    
    .status-banner.not-verified {
      background: rgba(148, 163, 184, 0.15);
      border: 2px solid rgba(148, 163, 184, 0.4);
      color: #94a3b8;
    }
    
    .status-icon {
      font-size: 2rem;
    }
    
    .form-section {
      margin-bottom: 32px;
    }
    
    .form-section-title {
      font-size: 1.1rem;
      font-weight: 700;
      color: var(--page-white);
      margin-bottom: 16px;
      padding-bottom: 12px;
      border-bottom: 2px solid rgba(86, 139, 241, 0.3);
    }
  </style>
</head>
<body>
  <div class="page-shell">
    <aside id="sidebar">
      <a class="back-link" href="find-jobs.php">← Back to Jobs</a>
      <div class="aside-welcome">
        <div class="aside-avatar">
          <img src="<?php echo !empty($user['profile_picture']) ? htmlspecialchars($user['profile_picture']) : 'front/assets/images/default-avatar.png'; ?>" alt="User avatar">
        </div>
        <div>
          <p class="welcome-tag">Verification Status</p>
          <h3><?php echo htmlspecialchars($user['username']); ?></h3>
          <p class="welcome-meta" style="color: <?php echo $status_color; ?>;">
            <?php echo $status_badge; ?>
          </p>
        </div>
      </div>
      <div>
        <h2 class="page-title">Profile Verification</h2>
        <p class="side-description">Complete your profile verification to start bidding on jobs in the marketplace. All information must be accurate and match your NIN.</p>
      </div>
      
       Added verification benefits section 
      <div class="vector-cluster">
        <h3 style="font-size: 1rem; margin-bottom: 12px; color: var(--page-white);">Verification Benefits</h3>
        <ul style="list-style: none; padding: 0; margin: 0; font-size: 0.85rem; color: rgba(216, 230, 255, 0.8); line-height: 1.8;">
          <li>✓ Bid on premium jobs</li>
          <li>✓ Higher trust from employers</li>
          <li>✓ Access to exclusive opportunities</li>
          <li>✓ Faster payment processing</li>
        </ul>
      </div>
    </aside>
    
    <main>
       Toast notification system 
      <?php if (isset($success_message)): ?>
        <div id="success-toast" class="status-banner approved">
          <span class="status-icon">✓</span>
          <div>
            <strong>Success!</strong><br>
            <?php echo htmlspecialchars($success_message); ?>
          </div>
        </div>
      <?php endif; ?>
      
      <?php if (isset($error_message)): ?>
        <div id="error-toast" class="status-banner rejected">
          <span class="status-icon">✗</span>
          <div>
            <strong>Error!</strong><br>
            <?php echo htmlspecialchars($error_message); ?>
          </div>
        </div>
      <?php endif; ?>
      
      <?php if ($verification && $verification['verification_status'] === 'rejected'): ?>
        <div class="status-banner rejected">
          <span class="status-icon">✗</span>
          <div>
            <strong>Verification Rejected</strong><br>
            Admin Notes: <?php echo htmlspecialchars($verification['admin_notes'] ?? 'No notes provided'); ?>
          </div>
        </div>
      <?php endif; ?>
      
      <?php if ($verification && $verification['verification_status'] === 'approved'): ?>
        <div class="status-banner approved">
          <span class="status-icon">✓</span>
          <div>
            <strong>Profile Verified!</strong><br>
            You can now bid on jobs in the marketplace. Your profile is trusted by employers.
          </div>
        </div>
      <?php endif; ?>
      
      <?php if ($verification && $verification['verification_status'] === 'pending'): ?>
        <div class="status-banner pending">
          <span class="status-icon">⏳</span>
          <div>
            <strong>Verification Pending</strong><br>
            Your verification is under review. This usually takes 24-48 hours.
          </div>
        </div>
      <?php endif; ?>
      
      <section>
        <h2 style="font-size: clamp(1.3rem, 3vw, 1.6rem); margin-bottom: 20px; color: var(--page-white);">📋 Verification Form</h2>
        
        <form method="POST" enctype="multipart/form-data" style="background: var(--panel-glass); border: 1px solid var(--panel-border); border-radius: 24px; padding: clamp(24px, 4vw, 36px); box-shadow: var(--shadow-heavy);">
          
           Career Selection Section 
          <div class="form-section">
            <h3 class="form-section-title">🎯 Career Categories</h3>
            <p style="color: rgba(216, 230, 255, 0.8); font-size: 0.9rem; margin-bottom: 16px;">
              Select up to 2 career categories to match you with relevant jobs in the marketplace.
            </p>
            
            <div style="margin-bottom: 20px;">
              <label style="display: block; margin-bottom: 12px; color: rgba(216, 230, 255, 0.9); font-size: 0.9rem; font-weight: 600;">Primary Career *</label>
              <div class="career-grid">
                <?php foreach ($career_categories as $career): ?>
                  <div class="career-option">
                    <input type="radio" name="career1" id="career1_<?php echo str_replace(' ', '_', $career); ?>" value="<?php echo htmlspecialchars($career); ?>" <?php echo ($user['career1'] === $career) ? 'checked' : ''; ?> required>
                    <label class="career-label" for="career1_<?php echo str_replace(' ', '_', $career); ?>">
                      <?php echo htmlspecialchars($career); ?>
                    </label>
                  </div>
                <?php endforeach; ?>
              </div>
            </div>
            
            <div>
              <label style="display: block; margin-bottom: 12px; color: rgba(216, 230, 255, 0.9); font-size: 0.9rem; font-weight: 600;">Secondary Career (Optional)</label>
              <div class="career-grid">
                <div class="career-option">
                  <input type="radio" name="career2" id="career2_none" value="" <?php echo empty($user['career2']) ? 'checked' : ''; ?>>
                  <label class="career-label" for="career2_none">None</label>
                </div>
                <?php foreach ($career_categories as $career): ?>
                  <div class="career-option">
                    <input type="radio" name="career2" id="career2_<?php echo str_replace(' ', '_', $career); ?>" value="<?php echo htmlspecialchars($career); ?>" <?php echo ($user['career2'] === $career) ? 'checked' : ''; ?>>
                    <label class="career-label" for="career2_<?php echo str_replace(' ', '_', $career); ?>">
                      <?php echo htmlspecialchars($career); ?>
                    </label>
                  </div>
                <?php endforeach; ?>
              </div>
            </div>
          </div>
          
           Personal Information Section 
          <div class="form-section">
            <h3 class="form-section-title">👤 Personal Information</h3>
            
            <div style="display: grid; gap: 24px;">
              <div>
                <label style="display: block; margin-bottom: 8px; color: rgba(216, 230, 255, 0.9); font-size: 0.9rem; font-weight: 600;">NIN (National Identification Number) *</label>
                <input type="text" name="nin" required maxlength="20" value="<?php echo htmlspecialchars($verification['nin'] ?? ''); ?>" style="width: 100%; padding: 12px; border-radius: 10px; border: 1px solid rgba(86, 139, 241, 0.3); background: rgba(13, 24, 62, 0.5); color: var(--page-white); font-size: 1rem;" />
              </div>
              
              <div>
                <label style="display: block; margin-bottom: 8px; color: rgba(216, 230, 255, 0.9); font-size: 0.9rem; font-weight: 600;">Full Name (Must match NIN) *</label>
                <input type="text" name="full_name" required value="<?php echo htmlspecialchars($verification['full_name'] ?? ''); ?>" style="width: 100%; padding: 12px; border-radius: 10px; border: 1px solid rgba(86, 139, 241, 0.3); background: rgba(13, 24, 62, 0.5); color: var(--page-white); font-size: 1rem;" />
              </div>
              
              <div>
                <label style="display: block; margin-bottom: 8px; color: rgba(216, 230, 255, 0.9); font-size: 0.9rem; font-weight: 600;">Date of Birth (Must match NIN) *</label>
                <input type="date" name="date_of_birth" required value="<?php echo htmlspecialchars($verification['date_of_birth'] ?? ''); ?>" style="width: 100%; padding: 12px; border-radius: 10px; border: 1px solid rgba(86, 139, 241, 0.3); background: rgba(13, 24, 62, 0.5); color: var(--page-white); font-size: 1rem;" />
              </div>
              
              <div>
                <label style="display: block; margin-bottom: 8px; color: rgba(216, 230, 255, 0.9); font-size: 0.9rem; font-weight: 600;">Location *</label>
                <input type="text" name="location" required value="<?php echo htmlspecialchars($verification['location'] ?? ''); ?>" placeholder="City, State" style="width: 100%; padding: 12px; border-radius: 10px; border: 1px solid rgba(86, 139, 241, 0.3); background: rgba(13, 24, 62, 0.5); color: var(--page-white); font-size: 1rem;" />
              </div>
              
              <div>
                <label style="display: block; margin-bottom: 8px; color: rgba(216, 230, 255, 0.9); font-size: 0.9rem; font-weight: 600;">Phone Number *</label>
                <input type="tel" name="phone_number" required value="<?php echo htmlspecialchars($verification['phone_number'] ?? ''); ?>" style="width: 100%; padding: 12px; border-radius: 10px; border: 1px solid rgba(86, 139, 241, 0.3); background: rgba(13, 24, 62, 0.5); color: var(--page-white); font-size: 1rem;" />
              </div>
              
              <div>
                <label style="display: block; margin-bottom: 8px; color: rgba(216, 230, 255, 0.9); font-size: 0.9rem; font-weight: 600;">Email *</label>
                <input type="email" name="email" required value="<?php echo htmlspecialchars($verification['email'] ?? $user['email']); ?>" style="width: 100%; padding: 12px; border-radius: 10px; border: 1px solid rgba(86, 139, 241, 0.3); background: rgba(13, 24, 62, 0.5); color: var(--page-white); font-size: 1rem;" />
              </div>
            </div>
          </div>
          
           Documents Section 
          <div class="form-section">
            <h3 class="form-section-title">📄 Documents</h3>
            
            <div style="display: grid; gap: 24px;">
              <div>
                <label style="display: block; margin-bottom: 8px; color: rgba(216, 230, 255, 0.9); font-size: 0.9rem; font-weight: 600;">Upload Clear Picture *</label>
                <input type="file" name="profile_picture" accept="image/*" <?php echo !$verification ? 'required' : ''; ?> style="width: 100%; padding: 12px; border-radius: 10px; border: 1px solid rgba(86, 139, 241, 0.3); background: rgba(13, 24, 62, 0.5); color: var(--page-white); font-size: 1rem;" />
                <?php if ($verification && $verification['profile_picture']): ?>
                  <p style="margin-top: 8px; font-size: 0.85rem; color: rgba(216, 230, 255, 0.7);">Current: <?php echo basename($verification['profile_picture']); ?></p>
                <?php endif; ?>
              </div>
              
              <div>
                <label style="display: block; margin-bottom: 8px; color: rgba(216, 230, 255, 0.9); font-size: 0.9rem; font-weight: 600;">Portfolio or CV *</label>
                <input type="file" name="portfolio_cv" accept=".pdf,.doc,.docx" <?php echo !$verification ? 'required' : ''; ?> style="width: 100%; padding: 12px; border-radius: 10px; border: 1px solid rgba(86, 139, 241, 0.3); background: rgba(13, 24, 62, 0.5); color: var(--page-white); font-size: 1rem;" />
                <?php if ($verification && $verification['portfolio_cv']): ?>
                  <p style="margin-top: 8px; font-size: 0.85rem; color: rgba(216, 230, 255, 0.7);">Current: <?php echo basename($verification['portfolio_cv']); ?></p>
                <?php endif; ?>
              </div>
              
              <div>
                <label style="display: block; margin-bottom: 8px; color: rgba(216, 230, 255, 0.9); font-size: 0.9rem; font-weight: 600;">Recent Jobs Delivered *</label>
                <textarea name="recent_jobs" required rows="5" placeholder="Describe recent jobs you've completed, including client names, project details, and outcomes..." style="width: 100%; padding: 12px; border-radius: 10px; border: 1px solid rgba(86, 139, 241, 0.3); background: rgba(13, 24, 62, 0.5); color: var(--page-white); font-size: 1rem; resize: vertical;"><?php echo htmlspecialchars($verification['recent_jobs'] ?? ''); ?></textarea>
              </div>
            </div>
          </div>
          
          <button type="submit" style="width: 100%; padding: 16px; border: none; border-radius: 14px; background: linear-gradient(135deg, var(--page-mint), var(--page-blue-300)); color: var(--page-blue-900); font-size: 1rem; font-weight: 600; cursor: pointer; transition: transform 0.3s;">
            <?php echo $verification ? 'Update Verification' : 'Submit for Verification'; ?>
          </button>
        </form>
      </section>
      
      <nav class="mobile-fintech-footer">
        <a href="dashboard.php">
          <svg viewBox="0 0 24 24"><path d="M12 3a9 9 0 1 1 0 18 9 9 0 0 1 0-18Zm1 4h-2v6h6v-2h-4V7Z"/></svg>
          <span>Dashboard</span>
        </a>
        <a href="find-jobs.php">
          <svg viewBox="0 0 24 24"><path d="M20 6h-4V4c0-1.1-.9-2-2-2h-4c-1.1 0-2 .9-2 2v2H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V8c0-1.1-.9-2-2-2zM10 4h4v2h-4V4zm10 16H4V8h16v12z"/></svg>
          <span>Jobs</span>
        </a>
        <a href="my-bids.php">
          <svg viewBox="0 0 24 24"><path d="M9 11H7v2h2v-2zm4 0h-2v2h2v-2zm4 0h-2v2h2v-2zm2-7h-1V2h-2v2H8V2H6v2H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 16H5V9h14v11z"/></svg>
          <span>My Bids</span>
        </a>
        <a href="profile.php" class="active">
          <svg viewBox="0 0 24 24"><path d="M12 2a6 6 0 0 1 6 6c0 3.31-2.69 6-6 6s-6-2.69-6-6a6 6 0 0 1 6-6Zm0 14c4.42 0 8 1.79 8 4v2H4v-2c0-2.21 3.58-4 8-4Z"/></svg>
          <span>Profile</span>
        </a>
      </nav>
    </main>
  </div>
  
  <script>
    document.addEventListener("DOMContentLoaded", () => {
      const successToast = document.getElementById("success-toast");
      const errorToast = document.getElementById("error-toast");
      
      if (successToast) {
        setTimeout(() => {
          successToast.style.opacity = '0';
          successToast.style.transform = 'translateY(-20px)';
          setTimeout(() => successToast.remove(), 300);
        }, 5000);
      }
      
      if (errorToast) {
        setTimeout(() => {
          errorToast.style.opacity = '0';
          errorToast.style.transform = 'translateY(-20px)';
          setTimeout(() => errorToast.remove(), 300);
        }, 5000);
      }
    });
    
    let lastScrollTop = 0;
    const sidebar = document.getElementById('sidebar');
    
    window.addEventListener('scroll', function() {
      if (window.innerWidth <= 960) {
        let scrollTop = window.pageYOffset || document.documentElement.scrollTop;
        
        if (scrollTop > lastScrollTop && scrollTop > 50) {
          sidebar.classList.add('scrolled');
        } else if (scrollTop < lastScrollTop - 10) {
          sidebar.classList.remove('scrolled');
        }
        
        lastScrollTop = scrollTop <= 0 ? 0 : scrollTop;
      }
    }, false);
  </script>
</body>
</html>
