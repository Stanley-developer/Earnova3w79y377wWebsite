<?php
require_once 'config/database.php';
require_once 'includes/session.php';

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Redirect if already logged in
if (isLoggedIn()) {
    header('Location: dashboard.php');
    exit();
}

$error = '';
$success = '';

$referral_code_from_url = isset($_GET['ref']) ? trim($_GET['ref']) : '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $full_name = trim($_POST['full_name'] ?? '');
    $username = trim($_POST['username'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';
    $referral_code = trim($_POST['referral_code'] ?? '');
    $device_fingerprint = trim($_POST['device_fingerprint'] ?? '');
    $device_info = json_decode($_POST['device_info'] ?? '{}', true);
    $ip_address = $_SERVER['REMOTE_ADDR'];
    $turnstile_response = $_POST['cf-turnstile-response'] ?? '';
    
    // NOTE: Replace with your own Cloudflare Turnstile secret key
    // Get your keys at: https://dash.cloudflare.com/
    // Current key is a test key that always passes
    $turnstile_secret = '0x4AAAAAACCP_LiqE2HCf2w7bNybDQPOMqU'; // REPLACE THIS with your secret key
    
    if (!empty($turnstile_response)) {
        $verify_url = 'https://challenges.cloudflare.com/turnstile/v0/siteverify';
        $verify_data = [
            'secret' => $turnstile_secret,
            'response' => $turnstile_response,
            'remoteip' => $_SERVER['REMOTE_ADDR']
        ];
        
        $ch = curl_init($verify_url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($verify_data));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $verify_response = curl_exec($ch);
        curl_close($ch);
        
        $verify_result = json_decode($verify_response, true);
        
        if (!$verify_result['success']) {
            $error = 'Captcha verification failed. Please try again.';
        }
    }
    
    // Validation
    if (empty($error) && (empty($full_name) || empty($username) || empty($email) || empty($password) || empty($confirm_password))) {
        $error = 'Please fill in all required fields';
    } elseif (empty($error) && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Invalid email format';
    } elseif (empty($error) && strlen($password) < 6) {
        $error = 'Password must be at least 6 characters';
    } elseif (empty($error) && $password !== $confirm_password) {
        $error = 'Passwords do not match';
    } elseif (empty($error) && !empty($device_fingerprint)) {
        try {
            $pdo = getDBConnection();
            
            $stmt = $pdo->prepare("
                SELECT COUNT(DISTINCT user_id) as account_count 
                FROM user_devices 
                WHERE device_fingerprint = ? AND is_verified = TRUE
            ");
            $stmt->execute([$device_fingerprint]);
            $result = $stmt->fetch();
            
            if ($result['account_count'] >= 2) {
                $error = 'Maximum account limit reached for this device. Only 2 accounts per device.';
            }
        } catch (Exception $e) {
            error_log("Device check error: " . $e->getMessage());
        }
    }
    
    // Additional server-side validations:
    // 1) Username may only contain letters, numbers and the symbols @, - and _
    // 2) Full name may only contain letters, numbers, spaces and the symbols @, - and _
    // 3) Block reserved words in username or full name (case-insensitive)
    // 4) Prevent using your own username as the referral code
    if (empty($error)) {
        if (!preg_match('/^[A-Za-z0-9@_-]+$/', $username)) {
            $error = 'Username may only contain letters, numbers, @, - and _';
        } elseif (!preg_match('/^[A-Za-z0-9 @_-]+$/', $full_name)) {
            $error = 'Full name contains invalid characters. Only letters, numbers, spaces, @, - and _ are allowed';
        } elseif (preg_match('/^\d/', $username)) {
            $error = 'Username cannot start with a number';
        } elseif (preg_match('/^\d/', $full_name)) {
            $error = 'Full name cannot start with a number';
        } else {
            $reserved = ['admin', 'earnova', 'developer', 'website', 'my website'];
            foreach ($reserved as $r) {
                if ($r === '') continue;
                if (stripos($username, $r) !== false || stripos($full_name, $r) !== false) {
                    $error = 'Username or full name contains a reserved word. Please choose a different value.';
                    break;
                }
            }
        }

        if (empty($error) && !empty($referral_code) && strcasecmp($referral_code, $username) === 0) {
            $error = 'You cannot use your own username as an invite/referral code';
        }
    }
    
    if (empty($error)) {
        try {
            $pdo = getDBConnection();
            
            // Check if email already exists
            $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ?");
            $stmt->execute([$email]);
            if ($stmt->fetch()) {
                $error = 'Email already registered';
            } else {
                $user_referral_code = strtoupper($username);
                
                // Check if referral code already exists (username collision)
                $stmt = $pdo->prepare("SELECT id FROM users WHERE referral_code = ?");
                $stmt->execute([$user_referral_code]);
                if ($stmt->fetch()) {
                    $error = 'Username already taken. Please choose a different username.';
                } else {
                    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
                    
                    // Check if referral code is valid
                    $referred_by = null;
                    if (!empty($referral_code)) {
                        $stmt = $pdo->prepare("SELECT id FROM users WHERE referral_code = ?");
                        $stmt->execute([$referral_code]);
                        $referrer = $stmt->fetch();
                        if ($referrer) {
                            $referred_by = $referrer['id'];
                        }
                    }
                    
                    $stmt = $pdo->prepare("
                        INSERT INTO users 
                        (full_name, username, email, password_hash, referral_code, referred_by, created_at,
                         full_name_last_updated, phone_last_updated, username_last_updated) 
                        VALUES (?, ?, ?, ?, ?, ?, NOW(), NOW(), NOW(), NOW())
                    ");
                    $stmt->execute([$full_name, $username, $email, $hashedPassword, $user_referral_code, $referred_by]);
                    
                    $new_user_id = $pdo->lastInsertId();
                    
                    $stmt = $pdo->prepare("INSERT INTO balances (user_id, total_balance, task_earnings, referral_earnings) VALUES (?, 0.00, 0.00, 0.00)");
                    $stmt->execute([$new_user_id]);

                    if (!empty($device_fingerprint)) {
                        $stmt = $pdo->prepare("
                            INSERT INTO device_registration_log 
                            (device_fingerprint, user_id, ip_address, browser, os) 
                            VALUES (?, ?, ?, ?, ?)
                        ");
                        $stmt->execute([
                            $device_fingerprint,
                            $new_user_id,
                            $ip_address,
                            $device_info['browser'] ?? 'Unknown',
                            $device_info['os'] ?? 'Unknown'
                        ]);
                        
                        // Add to user_devices
                        $stmt = $pdo->prepare("
                            INSERT INTO user_devices 
                            (user_id, device_fingerprint, device_name, browser, os, ip_address, is_verified, first_login, last_login) 
                            VALUES (?, ?, ?, ?, ?, ?, TRUE, NOW(), NOW())
                        ");
                        $stmt->execute([
                            $new_user_id,
                            $device_fingerprint,
                            ($device_info['browser'] ?? 'Unknown') . ' on ' . ($device_info['os'] ?? 'Unknown'),
                            $device_info['browser'] ?? 'Unknown',
                            $device_info['os'] ?? 'Unknown',
                            $ip_address
                        ]);
                    }
                    
                    $_SESSION['new_user_id'] = $new_user_id;
                    header('Location: onboarding-survey.php');
                    exit();
                }
            }
        } catch (Exception $e) {
            $error = "Registration failed: " . $e->getMessage();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- SEO Meta Tags -->
    <title>Create Advertiser Account | Earnova Digital Hub</title>
    <meta name="description" content="Create your advertiser account on Earnova Digital Hub. Launch paid campaigns, engage audiences, and track results on a secure, transparent platform connecting people to paid tasks, games, and rewards.">
    <meta name="keywords" content="create advertiser account, earnova digital hub, paid campaigns, online marketing platform, track audience engagement, digital advertising, secure platform for advertisers, paid tasks marketing">

    <!-- Open Graph -->
    <meta property="og:title" content="Create Advertiser Account | Earnova Digital Hub">
    <meta property="og:description" content="Create your advertiser account on Earnova Digital Hub. Launch paid campaigns, engage audiences, and track results on a secure, transparent platform connecting people to paid tasks, games, and rewards.">
    <meta property="og:image" content="https://earnova-digital-hub.com/logo.png">
    <meta property="og:type" content="website">
    <meta property="og:url" content="https://earnova-digital-hub.com/register.php">

    <!-- Twitter Card -->
    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:title" content="Create Advertiser Account | Earnova Digital Hub">
    <meta name="twitter:description" content="Create your advertiser account on Earnova Digital Hub. Launch paid campaigns, engage audiences, and track results on a secure, transparent platform connecting people to paid tasks, games, and rewards.">
    <meta name="twitter:image" content="https://earnova-digital-hub.com/logo.png">

    <!-- Favicon -->
    <link rel="icon" href="logo.png" type="image/png">

    <!-- JSON-LD Structured Data -->
    <script type="application/ld+json">
    {
      "@context": "https://schema.org",
      "@type": "Organization",
      "name": "Earnova Digital Hub",
      "url": "https://earnova-digital-hub.com",
      "logo": "https://earnova-digital-hub.com/logo.png",
      "sameAs": [
        // "https://www.facebook.com/earnova",
        // "https://twitter.com/earnova",
        // "https://www.linkedin.com/company/earnova"
      ]
    }
    </script>
    <!-- Adding GSAP libraries and Google Fonts for modern design -->
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet" />
    <link rel="stylesheet" href="styles.css" />
    
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; }
        
        html, body {
            max-width: 100%;
            overflow-x: hidden;
            scroll-behavior: smooth;
            /*display: none;*/
        }
        
        body {
            font-family: 'Poppins', -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
            background: radial-gradient(circle at 0% 0%, rgba(61, 116, 255, 0.28), transparent 55%),
                        radial-gradient(circle at 100% 0%, rgba(77, 225, 193, 0.18), transparent 45%),
                        linear-gradient(180deg, #030922, #0a164a);
            color: #f5f9ff;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
            padding-top: 80px;
            display: none;
        }

        /* Header / Navigation from index.php */
        header {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            z-index: 1000;
            backdrop-filter: blur(12px);
            background: rgba(3, 9, 34, 0.85);
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
            transition: all 0.3s ease;
        }
        
        .nav-container {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 16px 24px;
            max-width: 1280px;
            margin: 0 auto;
        }
        
        .logo-link {
            display: flex;
            align-items: center;
            gap: 12px;
            text-decoration: none;
            color: inherit;
            transition: opacity 0.3s ease;
        }
        
        .logo-link:hover {
            opacity: 0.8;
        }
        
        .logo-img {
            height: 40px;
            width: auto;
        }
        
        nav ul {
            display: none;
            list-style: none;
            gap: 32px;
        }
        
        @media (min-width: 768px) {
            nav ul {
                display: flex;
            }
        }
        
        nav a {
            text-decoration: none;
            color: inherit;
            opacity: 0.8;
            transition: opacity 0.3s ease;
            font-weight: 500;
            font-size: 15px;
        }
        
        nav a:hover {
            opacity: 1;
        }
        
        nav a.active {
            opacity: 1;
            color: #4de1c1;
            font-weight: 600;
        }
        
        .nav-cta {
            display: flex;
            gap: 12px;
            align-items: center;
        }
        
        @media (max-width: 767px) {
            .nav-cta .btn-ghost {
                display: none;
            }
        }
        
        .hamburger-menu {
            display: flex;
            flex-direction: column;
            gap: 5px;
            cursor: pointer;
            padding: 8px;
            background: transparent;
            border: none;
            z-index: 1001;
        }
        
        .hamburger-menu span {
            width: 25px;
            height: 3px;
            background: #f5f9ff;
            border-radius: 2px;
            transition: all 0.3s ease;
        }
        
        .hamburger-menu.active span:nth-child(1) {
            transform: rotate(45deg) translate(8px, 8px);
        }
        
        .hamburger-menu.active span:nth-child(2) {
            opacity: 0;
        }
        
        .hamburger-menu.active span:nth-child(3) {
            transform: rotate(-45deg) translate(7px, -7px);
        }
        
        @media (min-width: 768px) {
            .hamburger-menu {
                display: none;
            }
        }
        
        .mobile-menu {
            position: fixed;
            top: 72px;
            left: 0;
            right: 0;
            background: rgba(3, 9, 34, 0.98);
            backdrop-filter: blur(12px);
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
            max-height: 0;
            overflow: hidden;
            transition: max-height 0.5s ease;
            z-index: 999;
        }
        
        .mobile-menu.active {
            max-height: 400px;
        }
        
        .mobile-menu ul {
            list-style: none;
            padding: 20px 24px;
        }
        
        .mobile-menu li {
            opacity: 0;
            transform: translateX(-20px);
            transition: all 0.3s ease;
        }
        
        .mobile-menu.active li:nth-child(1) { opacity: 1; transform: translateX(0); transition-delay: 0.1s; }
        .mobile-menu.active li:nth-child(2) { opacity: 1; transform: translateX(0); transition-delay: 0.2s; }
        .mobile-menu.active li:nth-child(3) { opacity: 1; transform: translateX(0); transition-delay: 0.3s; }
        .mobile-menu.active li:nth-child(4) { opacity: 1; transform: translateX(0); transition-delay: 0.4s; }
        .mobile-menu.active li:nth-child(5) { opacity: 1; transform: translateX(0); transition-delay: 0.5s; }
        
        .mobile-menu a {
            display: block;
            padding: 12px 0;
            color: #f5f9ff;
            text-decoration: none;
            font-size: 16px;
            font-weight: 500;
            border-bottom: 1px solid rgba(255, 255, 255, 0.05);
            transition: color 0.3s ease;
        }
        
        .mobile-menu a:hover {
            color: #4de1c1;
        }
        
        @media (min-width: 768px) {
            .mobile-menu {
                display: none;
            }
        }

        /* Button Styles */
        .btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            padding: 12px 24px;
            border-radius: 12px;
            font-weight: 600;
            font-size: 15px;
            text-decoration: none;
            transition: all 0.3s ease;
            border: none;
            cursor: pointer;
            font-family: inherit;
        }
        
        .btn-primary {
            background: linear-gradient(135deg, #2c5bf5, #4de1c1);
            color: #030922;
            box-shadow: 0 4px 16px rgba(44, 91, 245, 0.3);
        }
        
        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 24px rgba(44, 91, 245, 0.4);
        }
        
        .btn-ghost {
            background: transparent;
            color: inherit;
            border: 2px solid rgba(255, 255, 255, 0.2);
        }
        
        .btn-ghost:hover {
            border-color: rgba(255, 255, 255, 0.4);
            background: rgba(255, 255, 255, 0.05);
        }

        /* Main content area for centering the form */
        main {
            flex: 1;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px 0;
        }
        
        .register-wrapper {
            width: 100%;
            display: flex;
            justify-content: center;
            padding: 0 20px;
        }
        
        /* Register container with full-width on mobile, rounded top corners */
        .register-container {
            max-width: 550px;
            width: 100%;
            background: rgba(13, 24, 62, 0.84);
            border: 1px solid rgba(86, 139, 241, 0.3);
            border-radius: 26px;
            padding: 40px;
            box-shadow: 0 40px 120px rgba(4, 10, 36, 0.65);
            backdrop-filter: blur(10px);
            transition: all 0.3s ease;
        }

        /* Mobile full-width with top corners rounded */
        @media (max-width: 640px) {
            .register-wrapper {
                padding: 0;
            }
            
            .register-container {
                border-radius: 26px 26px 0 0;
                border-left: none;
                border-right: none;
                border-bottom: none;
                padding: 30px 25px;
            }
        }
        
        .logo {
            text-align: center;
            margin-bottom: 32px;
        }
        
        .logo-container img {
            width: 130px;
            height: 30px;
            margin: 0 auto 16px;
        }
        
        .logo h1 {
            font-size: 1.5rem;
            font-weight: 700;
            letter-spacing: -0.02em;
            background: linear-gradient(135deg, #2c5bf5, #4de1c1);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            margin-bottom: 8px;
        }
        
        .logo p {
            color: rgba(205, 219, 255, 0.7);
            font-size: 0.875rem;
            line-height: 1.5;
            font-family: 'Inter', sans-serif;
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        label {
            display: block;
            margin-bottom: 8px;
            font-size: 0.875rem;
            font-weight: 500;
            color: rgba(205, 219, 255, 0.9);
        }
        
        .input-wrapper {
            position: relative;
        }

        .input-wrapper svg {
            position: absolute;
            left: 16px;
            top: 50%;
            transform: translateY(-50%);
            width: 20px;
            height: 20px;
            fill: rgba(205, 219, 255, 0.5);
           
        }

        .input-wrapper input {
            padding-left: 48px;
        }
        
        input {
            width: 100%;
            padding: 14px 16px;
            border: 1px solid rgba(99, 149, 255, 0.26);
            border-radius: 12px;
            background: rgba(5, 12, 36, 0.82);
            color: #f5f9ff;
            font-size: 1rem;
            transition: border-color 0.3s, box-shadow 0.3s;
            font-family: 'Poppins', sans-serif;
        }
        
        input:focus {
            outline: none;
            border-color: #4de1c1;
            box-shadow: 0 0 0 3px rgba(77, 225, 193, 0.2);
        }

        /* Working password toggle button */
        .password-toggle {
            position: absolute;
            right: 46px;
            top: 50%;
            transform: translateY(-50%);
            background: none;
            border: none;
            cursor: pointer;
            padding: 4px;
            display: flex;
            align-items: center;
            justify-content: center;
             pointer-events: auto; 
            z-index: 10;
        }

        .password-toggle svg {
            width: 20px;
            height: 20px;
            fill: rgba(205, 219, 255, 0.5);
            transition: fill 0.3s;
             pointer-events: auto; 
        }

        .password-toggle:hover svg {
            fill: #4de1c1;
        }

        .password-toggle:focus {
            /*outline: 2px solid #4de1c1;*/
            /*outline-offset: 2px;*/
            border-radius: 4px;
        }
        
        
        .btn-primary.submit-btn {
            width: 100%;
            padding: 16px;
            border-radius: 12px;
            background: linear-gradient(135deg, rgba(47, 91, 234, 0.95), rgba(77, 225, 193, 0.85));
            color: #030922;
            font-size: 1rem;
            font-weight: 600;
            letter-spacing: 0.02em;
            text-transform: uppercase;
            cursor: pointer;
            transition: transform 0.3s, box-shadow 0.3s;
            box-shadow: 0 24px 55px rgba(40, 90, 230, 0.45);
            margin-top: 8px;
        }
        
        .btn-primary.submit-btn:hover {
            transform: translateY(-4px);
            box-shadow: 0 28px 65px rgba(40, 90, 230, 0.55);
        }
        
        .alert {
            padding: 14px 16px;
            border-radius: 12px;
            margin-bottom: 24px;
            font-size: 0.9rem;
        }
        
        .alert-error {
            background: rgba(239, 68, 68, 0.15);
            border: 1px solid rgba(239, 68, 68, 0.3);
            color: #fca5a5;
        }
        
        .alert-success {
            background: rgba(77, 225, 193, 0.15);
            border: 1px solid rgba(77, 225, 193, 0.3);
            color: #4de1c1;
        }
        
        .links {
            text-align: center;
            margin-top: 24px;
        }
        
        .links p {
            margin: 8px 0;
            font-size: 0.9rem;
        }
        
        .links a {
            color: #4de1c1;
            text-decoration: none;
            transition: color 0.3s;
            font-weight: 500;
        }
        
        .links a:hover {
            color: #2c5bf5;
            text-decoration: underline;
        }

        /* Toast message styles */
        .toast-message {
            position: fixed;
            top: 20px;
            right: -400px;
            padding: 16px 24px;
            border-radius: 12px;
            color: white;
            font-family: 'Segoe UI', sans-serif;
            font-size: 15px;
            z-index: 999999;
            opacity: 0;
            box-shadow: 0 10px 40px rgba(0, 0, 0, 0.2);
            transition: right 0.6s ease, opacity 0.6s ease;
        }

        .toast-message.success {
            background: rgba(77, 225, 193, 0.95);
            color: #030922;
            box-shadow: 0 10px 40px rgba(77, 225, 193, 0.4);
        }

        .toast-message.error {
            background: rgba(255, 77, 77, 0.95);
            color: #fff;
            box-shadow: 0 10px 40px rgba(255, 77, 77, 0.4);
        }

        .toast-message.show {
            right: 20px;
            opacity: 1;
        }

        /* Footer from index.php */
        footer {
            padding: 60px 0 30px;
            border-top: 1px solid rgba(255, 255, 255, 0.1);
            background: rgba(3, 9, 34, 0.95);
            margin-top: auto;
        }
        
        .footer-content {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 32px;
            margin-bottom: 32px;
            max-width: 1280px;
            margin: 0 auto 32px;
            padding: 0 24px;
        }
        
        .footer-brand h3 {
            font-size: 1.5rem;
            margin-bottom: 12px;
            background: linear-gradient(135deg, #2c5bf5, #4de1c1);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }
        
        .footer-brand p {
            font-size: 0.875rem;
            opacity: 0.7;
            line-height: 1.6;
            font-family: 'Inter', sans-serif;
        }
        
        .footer-links h4 {
            font-size: 1rem;
            margin-bottom: 16px;
            font-weight: 600;
        }
        
        .footer-links ul {
            list-style: none;
            display: flex;
            flex-direction: column;
            gap: 10px;
        }
        
        .footer-links a {
            color: inherit;
            text-decoration: none;
            opacity: 0.7;
            transition: opacity 0.3s ease;
            font-size: 0.875rem;
            font-family: 'Inter', sans-serif;
        }
        
        .footer-links a:hover {
            opacity: 1;
            color: #4de1c1;
        }
        
        .footer-social {
            display: flex;
            gap: 12px;
            margin-top: 16px;
        }
        
        .social-link {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            border: 1px solid rgba(255, 255, 255, 0.2);
            display: flex;
            align-items: center;
            justify-content: center;
            text-decoration: none;
            color: inherit;
            transition: all 0.3s ease;
        }
        
        .social-link:hover {
            border-color: #4de1c1;
            background: rgba(77, 225, 193, 0.1);
            transform: translateY(-2px);
        }
        
        .social-link svg {
            width: 18px;
            height: 18px;
        }
        
        .footer-bottom {
            text-align: center;
            /*padding-top: 14px;*/
            /*border-top: 1px solid rgba(255, 255, 255, 0.1);*/
            font-size: 0.875rem;
            opacity: 0.6;
            font-family: 'Inter', sans-serif;
            max-width: 1280px;
            margin: 0 auto;
            padding-left: 24px;
            padding-right: 24px;
        }
        
        .footer-developer {
            margin-top: 12px;
            font-size: 0.8125rem;
            opacity: 0.7;
        }
        
        .footer-developer a {
            color: #4de1c1;
            text-decoration: none;
            font-weight: 600;
            transition: opacity 0.3s ease;
        }
        
        .footer-developer a:hover {
            opacity: 0.8;
            text-decoration: underline;
        }

        /* Cloudflare Turnstile container */
        .cf-turnstile {
            display: flex;
            justify-content: center;
            margin: 8px 0;
        }
    </style>

<body>
     <?php if ($error): ?>
                    <div id="toast-error" class="toast-message error"><?php echo htmlspecialchars($error); ?></div>
                <?php endif; ?>
                
                <?php if ($success): ?>
                    <div id="toast-success" class="toast-message success"><?php echo htmlspecialchars($success); ?></div>
                <?php endif; ?>
                
                
    <!-- Added header navigation from index.php -->
    <header role="banner">
        <div class="nav-container">
            <a href="index.php" class="logo-link" aria-label="Earnova Home">
                <img src="logo.png" alt="Earnova Logo" class="logo-img" />
            </a>
            
            <nav role="navigation" aria-label="Main navigation">
               <ul>
                    <li><a href="index.php">Home</a></li>
                <li><a href="about-us.php">About Us</a></li>
                <li><a href="terms.php">Privacy Policy</a></li>
                <li><a href="login.php">Login</a></li>
                </ul>
            </nav>
            
            <div class="nav-cta">
                <a href="register.php" class="btn btn-ghost">Get Started</a>
                <a href="login.php" class="btn btn-primary">Sign In</a>
                <button class="hamburger-menu" aria-label="Toggle mobile menu" aria-expanded="false">
                    <span></span>
                    <span></span>
                    <span></span>
                </button>
            </div>
        </div>
        
        <div class="mobile-menu">
            <ul>
                    <li><a href="index.php">Home</a></li>
                <li><a href="about-us.php">About Us</a></li>
                <li><a href="terms.php">Privacy Policy</a></li>
                <li><a href="login.php">Login</a></li>
                </ul>
        </div>
    </header>

    <!-- Wrapped register form in main and wrapper for better centering -->
    <main>
        <div class="register-wrapper">
            <div class="register-container">
                <div class="logo">
                    <!--<div class="logo-container">-->
                    <!--    <img src="logo.png" alt="Earnova Logo">-->
                    <!--</div>-->
                    <h1>Create An Account</h1>
                    <p>Create your account to start earning rewards and join the community.</p>
                </div>
                
               
                
                <form method="POST" action="" id="registerForm">
                    <div class="form-group">
                        <label for="full_name">Full Name</label>
                        <div class="input-wrapper">
                            <svg viewBox="0 0 24 24">
                                <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 3c1.66 0 3 1.34 3 3s-1.34 3-3 3-3-1.34-3-3 1.34-3 3-3zm0 14.2c-2.5 0-4.71-1.28-6-3.22.03-1.99 4-3.08 6-3.08 1.99 0 5.97 1.09 6 3.08-1.29 1.94-3.5 3.22-6 3.22z"/>
                            </svg>
                            <input type="text" id="full_name" name="full_name" placeholder="Enter Your FullName" value="<?php echo htmlspecialchars($_POST['full_name'] ?? ''); ?>" required>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label for="username">Username</label>
                        <div class="input-wrapper">
                            <svg viewBox="0 0 24 24">
                                <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 3c1.66 0 3 1.34 3 3s-1.34 3-3 3-3-1.34-3-3 1.34-3 3-3zm0 14.2c-2.5 0-4.71-1.28-6-3.22.03-1.99 4-3.08 6-3.08 1.99 0 5.97 1.09 6 3.08-1.29 1.94-3.5 3.22-6 3.22z"/>
                            </svg>
                            <input type="text" 
                               id="username" 
                               name="username" 
                               placeholder="Enter Username" 
                               value="<?php echo htmlspecialchars($_POST['username'] ?? ''); ?>" 
                               required
                               oninput="this.value = this.value.replace(/\s/g, '')">

                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label for="email">Email</label>
                        <div class="input-wrapper">
                            <svg viewBox="0 0 24 24">
                                <path d="M20 4H4c-1.1 0-1.99.9-1.99 2L2 18c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 4l-8 5-8-5V6l8 5 8-5v2z"/>
                            </svg>
                            <input type="email" id="email" name="email" placeholder="Enter Email Address" value="<?php echo htmlspecialchars($_POST['email'] ?? ''); ?>" required>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label for="password">Password</label>
                        <div class="input-wrapper">
                            <svg viewBox="0 0 24 24">
                                <path d="M18 8h-1V6c0-2.76-2.24-5-5-5S7 3.24 7 6v2H6c-1.1 0-2 .9-2 2v10c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V10c0-1.1-.9-2-2-2zm0 9c-1.1 0-2-.9-2-2s1.34-2 3-2 3 1.34 3 3-.9 2-2 2zm3.1-9H8.9V6c0-1.71 1.39-3.1 3.1-3.1 1.71 0 3.1 1.39 3.1 3.1v2z"/>
                            </svg>
                            <input type="password" id="password" name="password" placeholder="Enter Your Password" required minlength="6">
                            <!-- Fixed password toggle button to be functional -->
                            <button type="button" class="password-toggle" onclick="togglePassword('password')" aria-label="Toggle password visibility">
                                <svg id="password-eye" viewBox="0 0 24 24">
                                    <path d="M12 4.5C7 4.5 2.73 7.61 1 12c1.73 4.39 6 7.5 11 7.5s9.27-3.11 11-7.5c-1.73-4.39-6-7.5-11-7.5zM12 17c-2.76 0-5-2.24-5-5s2.24-5 5-5 5 2.24 5 5-2.24 5-5 5zm0-8c-1.66 0-3 1.34-3 3s1.34 3 3 3 3-1.34 3-3-1.34-3-3-3z"/>
                                </svg>
                            </button>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label for="confirm_password">Confirm Password</label>
                        <div class="input-wrapper">
                            <svg viewBox="0 0 24 24">
                                <path d="M18 8h-1V6c0-2.76-2.24-5-5-5S7 3.24 7 6v2H6c-1.1 0-2 .9-2 2v10c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V10c0-1.1-.9-2-2-2zm0 9c-1.1 0-2-.9-2-2s1.34-2 3-2 3 1.34 3 3-.9 2-2 2zm3.1-9H8.9V6c0-1.71 1.39-3.1 3.1-3.1 1.71 0 3.1 1.39 3.1 3.1v2z"/>
                            </svg>
                            <input type="password" id="confirm_password" name="confirm_password" placeholder="Retype Your Password" required>
                            <!-- Fixed confirm password toggle button to be functional -->
                            <button type="button" class="password-toggle" onclick="togglePassword('confirm_password')" aria-label="Toggle confirm password visibility">
                                <svg id="confirm_password-eye" viewBox="0 0 24 24">
                                    <path d="M12 4.5C7 4.5 2.73 7.61 1 12c1.73 4.39 6 7.5 11 7.5s9.27-3.11 11-7.5c-1.73-4.39-6-7.5-11-7.5zM12 17c-2.76 0-5-2.24-5-5s2.24-5 5-5 5 2.24 5 5-2.24 5-5 5zm0-8c-1.66 0-3 1.34-3 3s1.34 3 3 3 3-1.34 3-3-1.34-3-3-3z"/>
                                </svg>
                            </button>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="referral_code">Invite Code (Optional)</label>
                        <div class="input-wrapper">
                            <svg viewBox="0 0 24 24">
                                <path d="M18 16.08c-.76 0-1.44.3-1.96.77L8.91 12.7c.05-.23.09-.46.09-.7s-.04-.47-.09-.7l7.05-4.11c.54.5 1.25.81 2.04.81 1.66 0 3-1.34 3-3s-1.34-3-3-3c-.79 0-1.5-.31-2.04-.81l7.12 4.16c-.05.21-.08.43-.08.65 0 1.61 1.31 2.92 2.92 2.92 1.61 0 2.92-1.31 2.92-2.92s-1.31-2.92-2.92-2.92z"/>
                            </svg>
                            <input type="text" id="referral_code" name="referral_code" 
                                   value="<?php echo htmlspecialchars($referral_code_from_url ?: ($_POST['referral_code'] ?? '')); ?>"
                                   <?php echo $referral_code_from_url ? 'readonly' : ''; ?>
                                   placeholder="Enter invite code"  oninput="this.value = this.value.replace(/\s/g, '')">
                        </div>
                    </div>
                    <div style="margin-top: 15px; display: flex; align-items: flex-start; gap: 8px;">
    <input 
        type="checkbox" 
        id="agreeTerms" 
        required 
        style="width: 18px; height: 18px; cursor: pointer;"
    >

    <label for="agreeTerms" style="font-size: 14px; color: #fff; cursor: pointer; line-height: 1.3;">
        By signing up, you agree to the 
        <a href="terms.php" target="_blank" style="color: #4de1c1; text-decoration: underline;">
            Terms & Services
        </a>.
    </label>
</div>

                    <input type="hidden" name="device_fingerprint" id="device_fingerprint">
                    <input type="hidden" name="device_info" id="device_info">
                    
                    <div class="form-group">
                        <div class="input-wrapper">
                            <div id="cf-turnstile" class="cf-turnstile" data-sitekey="0x4AAAAAACCP_P5Ix_ronEc_" data-theme="dark"></div>
                        </div>
                    </div>
                    
                    <button type="submit" class="btn-primary submit-btn">Register</button>
                </form>
                
                <div class="links">
                    <p>Already have an account? <a href="login.php">Login here</a></p>
                    <p><a href="index.php">← Back to Home</a></p>
                </div>
            </div>
        </div>
    </main>

    <!-- Added footer from index.php -->
    <footer role="contentinfo">
        
        <div class="footer-bottom">
            <p>&copy; 2025 Earnova. All rights reserved. Built with care for earners and advertisers worldwide.</p>
            <!--<p class="footer-developer">-->
            <!--    Developed by <a href="https://wa.me/2348012345678" target="_blank" rel="noopener noreferrer">OBODO DEV</a>-->
            <!--</p>-->
        </div>
    </footer>

    <script src="includes/device-fingerprint.js"></script>
    <script src="https://challenges.cloudflare.com/turnstile/v0/api.js" async defer></script>
    <!-- Added GSAP for smooth animations -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.5/gsap.min.js" defer></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.5/ScrollTrigger.min.js" defer></script>
    
    <script>
        function togglePassword(fieldId) {
            const field = document.getElementById(fieldId);
            const eyeIcon = document.getElementById(fieldId + '-eye');
            
            if (field.type === 'password') {
                field.type = 'text';
                // Eye with slash icon (hidden password)
                eyeIcon.innerHTML = '<path d="M12 7c2.76 0 5 2.24 5 5 0 .65-.13 1.26-.36 1.83l2.92 2.92c1.51-1.26 2.7-2.89 3.43-4.75-1.73-4.39-6-7.5-11-7.5-1.4 0-2.74.25-3.98.7l2.16 2.16C10.74 7.13 11.35 7 12 7zM2 4.27l2.28 2.28.46.46C3.08 8.3 1.78 10.02 1 12c1.73 4.39 6 7.5 11 7.5 1.55 0 3.03-.3 4.38-.84l.42.42L19.73 22 21 20.73 3.27 3 2 4.27zM7.53 9.8l1.55 1.55c-.05.21-.08.43-.08.65 0 1.66 1.34 3 3 3 .22 0 .44-.03.65-.08l1.55 1.55c-.67.33-1.41.53-2.2.53-2.76 0-5-2.24-5-5 0-.79.2-1.53.53-2.2zm4.31-.78l3.15 3.15.02-.16c0-1.66-1.34-3-3-3l-.17.01z"/>';
            } else {
                field.type = 'password';
                // Eye open icon (visible password)
                eyeIcon.innerHTML = '<path d="M12 4.5C7 4.5 2.73 7.61 1 12c1.73 4.39 6 7.5 11 7.5s9.27-3.11 11-7.5c-1.73-4.39-6-7.5-11-7.5zM12 17c-2.76 0-5-2.24-5-5s2.24-5 5-5 5 2.24 5 5-2.24 5-5 5zm0-8c-1.66 0-3 1.34-3 3s1.34 3 3 3 3-1.34 3-3-1.34-3-3-3z"/>';
            }
        }

        // Toast message functionality
        document.addEventListener("DOMContentLoaded", () => {
            const successToast = document.getElementById("toast-success");
            const errorToast = document.getElementById("toast-error");

            function showToast(toast) {
                if (!toast) return;
                setTimeout(() => toast.classList.add("show"), 100);
                setTimeout(() => toast.classList.remove("show"), 5000);
            }

            showToast(successToast);
            showToast(errorToast);

            const hamburger = document.querySelector('.hamburger-menu');
            const mobileMenu = document.querySelector('.mobile-menu');
            
            if (hamburger && mobileMenu) {
                hamburger.addEventListener('click', function() {
                    this.classList.toggle('active');
                    mobileMenu.classList.toggle('active');
                    const isExpanded = this.classList.contains('active');
                    this.setAttribute('aria-expanded', isExpanded);
                });
                
                const mobileLinks = document.querySelectorAll('.mobile-menu a');
                mobileLinks.forEach(link => {
                    link.addEventListener('click', function() {
                        hamburger.classList.remove('active');
                        mobileMenu.classList.remove('active');
                        hamburger.setAttribute('aria-expanded', 'false');
                    });
                });
            }

            window.addEventListener('load', function() {
                if (typeof gsap !== 'undefined') {
                    gsap.registerPlugin(ScrollTrigger);
                    
                    const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
                    
                    if (!prefersReducedMotion) {
                        gsap.from('.register-container', {
                            duration: 0.8,
                            y: 50,
                            opacity: 0,
                            ease: 'power3.out'
                        });
                    }
                }
            });
        });

        // Generate device fingerprint on page load
        document.addEventListener('DOMContentLoaded', async function() {
            try {
                const fingerprint = await DeviceFingerprint.generate();
                const deviceInfo = DeviceFingerprint.getDeviceInfo();
                
                document.getElementById('device_fingerprint').value = fingerprint;
                document.getElementById('device_info').value = JSON.stringify(deviceInfo);
            } catch (error) {
                console.error('Error generating device fingerprint:', error);
            }
        });
    </script>

</body>
</html>
