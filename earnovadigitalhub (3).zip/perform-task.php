<?php 
ob_start();

require_once 'config/database.php';
require_once 'includes/session.php';
require_once 'includes/connect.php';
require_once 'vendor/autoload.php';
use libphonenumber\PhoneNumberUtil;
use libphonenumber\PhoneNumberFormat;

// Require authentication
requireLogin();
checkSessionTimeout();

// Get current user data
$user = getCurrentUser();
$user_id = $user['id'];

// Detect AJAX request
$isAjax =
    (!empty($_POST['ajax']) && $_POST['ajax']) ||
    (isset($_SERVER['HTTP_X_REQUESTED_WITH']) &&
     strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest');

// DELETE task ONLY on normal page load (refresh/navigation), not AJAX
if ($_SERVER['REQUEST_METHOD'] === 'GET' && !$isAjax) {

    if (isset($_SESSION['user_id'])) {
        
        // Delete the task for this user
        $stmt = $pdo->prepare("
            DELETE FROM user_tasks
            WHERE user_id = ? AND status = 'in_progress'
        ");
        $stmt->execute([$_SESSION['user_id']]);
    }

    // DO NOT clear session as you requested
    // No unset($_SESSION['active_task']);
}


// Initialize variables to prevent undefined errors
$sessionMessage = isset($_SESSION['task_message']) ? $_SESSION['task_message'] : null;
$sessionMessageType = isset($_SESSION['task_message_type']) ? $_SESSION['task_message_type'] : 'info';
$total_active_tasks = 0; // Initialize variable before try-catch
$available_tasks = [];
$pinned_tasks = [];
$completed_tasks = [];
$user_data = null;

$ts_agreed = isset($_SESSION['ts_agreed_' . $user_id]) ? $_SESSION['ts_agreed_' . $user_id] : false;

unset($_SESSION['task_message']);
unset($_SESSION['task_message_type']);

try {
    $pdo = getDBConnection();
    
    // Fetch user details with balances
    $stmt = $pdo->prepare("
        SELECT u.*, b.total_balance, b.task_earnings, b.referral_earnings
        FROM users u
        LEFT JOIN balances b ON u.id = b.user_id
        WHERE u.id = ?
    ");
    $stmt->execute([$user_id]);
    $user_data = $stmt->fetch();
    
    if (!$user_data) {
        header('Location: login.php');
        exit;
    }
    
    $stmt = $pdo->prepare("SELECT setting_value FROM task_display_settings WHERE setting_key = 'fake_total_tasks'");
    $stmt->execute();
    $fake_task_setting = $stmt->fetch();
    $fake_total_tasks = $fake_task_setting ? intval($fake_task_setting['setting_value']) : 50;
    
    $task_earnings = [
        'tiktok' => 20,
        'instagram' => 24,
        'whatsapp' => 22,
        'playstore' => 50,
        'appstore' => 60,
        'telegram' => 22,
        'twitter' => 25,
        'facebook' => 25,
        'linkedin' => 25,
        'snapchat' => 22,
        'youtube' => 28,
        'pinterest' => 23,
        'reddit' => 24,
        'discord' => 50,
        'twitch' => 28,
        'audiomack' => 20,
        'boomplay' => 30,
        'spotify' => 28,
        'applemusic' => 28,
        'soundcloud' => 30,
        'website' => 37
    ];
    
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['ajax'])) {
        ob_end_clean();
        
        header('Content-Type: application/json; charset=utf-8');
        
        $action = $_POST['action'] ?? '';

        if ($action === 'agree_terms') {
            $_SESSION['ts_agreed_' . $user_id] = true;
            echo json_encode(['success' => true, 'message' => 'Task Instructions agreed']);
            exit;
        }
        
        if ($action === 'start_task') {
            if ($user_data['membership_type'] === 'free') {
                echo json_encode(['success' => false, 'message' => 'Please upgrade to Premium to perform tasks', 'show_premium_popup' => true]);
                exit;
            }
            
            $task_id = intval($_POST['task_id'] ?? 0);
            
            // Get task details
            $stmt = $pdo->prepare("SELECT * FROM tasks WHERE id = ? AND is_active = 1");
            $stmt->execute([$task_id]);
            $task = $stmt->fetch();
            
            if (!$task) {
                echo json_encode(['success' => false, 'message' => 'Task not found']);
                exit;
            }
            
            // Check if user already has this task in progress
            $stmt = $pdo->prepare("SELECT * FROM user_tasks WHERE user_id = ? AND task_id = ? AND status IN ('pending', 'in_progress')");
            $stmt->execute([$user_id, $task_id]);
            $existing = $stmt->fetch();
            
            if ($existing) {
                echo json_encode(['success' => false, 'message' => 'You already have this task in progress']);
                exit;
            }
            
            $stmt = $pdo->prepare("SELECT * FROM user_tasks WHERE user_id = ? AND task_id = ? AND status = 'completed'");
            $stmt->execute([$user_id, $task_id]);
            $completed = $stmt->fetch();
            
            if ($completed) {
                echo json_encode(['success' => false, 'message' => 'You have already completed this task']);
                exit;
            }
            
            // Create task record with start time
            $stmt = $pdo->prepare("INSERT INTO user_tasks (user_id, task_id, status, created_at) VALUES (?, ?, 'in_progress', NOW())");
            
            if (!$stmt->execute([$user_id, $task_id])) {
                $errorInfo = $stmt->errorInfo();
                error_log("Database error starting task: " . print_r($errorInfo, true));
                echo json_encode(['success' => false, 'message' => 'Database error: ' . $errorInfo[2]]);
                exit;
            }
            
            $user_task_id = $pdo->lastInsertId();
            
            echo json_encode([
                'success' => true,
                'user_task_id' => $user_task_id,
                'task_url' => $task['task_url'],
                'start_time' => time() // time in seconds
            ]);
            exit;
            
        } elseif ($action === 'submit_verification') {
            $user_task_id = intval($_POST['user_task_id'] ?? 0);
            $start_time = intval($_POST['start_time'] ?? 0);
            $profile_link = $_POST['profile_link'] ?? '';
            
            if (!$user_task_id) {
                error_log("ERROR: Missing user_task_id in submit_verification");
                echo json_encode(['success' => false, 'message' => 'Session expired. Please start the task again.']);
                exit;
            }

            // Get user task
            $stmt = $pdo->prepare("
                SELECT ut.*, t.task_type, t.platform, t.title, t.posted_by_admin, t.member_reward, t.non_member_reward, t.reward_amount
                FROM user_tasks ut
                JOIN tasks t ON ut.task_id = t.id
                WHERE ut.id = ? AND ut.user_id = ?
            ");
            $stmt->execute([$user_task_id, $user_id]);
            $user_task = $stmt->fetch();
            
            if (!$user_task) {
                error_log("ERROR: Task not found for user_task_id: $user_task_id, user_id: $user_id");
                echo json_encode(['success' => false, 'message' => 'Task not found. Please try starting the task again.']);
                exit;
            }
            
            error_log("Task found: " . $user_task['title']);
            error_log("Task platform: " . ($user_task['platform'] ?? $user_task['task_type']));
            
            if (empty($profile_link)) {
                error_log("ERROR: Empty profile link provided");
                echo json_encode(['success' => false, 'message' => 'Please provide a profile link or phone number']);
                exit;
            }
            
            error_log("Profile link validation passed");
            
            $platform = strtolower($user_task['platform'] ?? $user_task['task_type']);
            error_log("Detected platform: $platform");
            
            // CHANGE: Added Telegram phone verification like WhatsApp
            // CHANGE: Add function to detect email-based tasks
            $emailBasedTasks = ['playstore', 'appstore', 'audiomack', 'boomplay', 'spotify', 'soundcloud', 'pinterest', 'website'];
            $isEmailTask = in_array($platform, $emailBasedTasks);
            
            // Validate proof format based on task type
            if ($isEmailTask) {
                // Email-based tasks require email format
                if (!filter_var($profile_link, FILTER_VALIDATE_EMAIL)) {
                    error_log("ERROR: Invalid email format for email-based task $platform: $profile_link");
                    echo json_encode(['success' => false, 'message' => 'Please provide a valid email address for ' . ucfirst($platform)]);
                    exit;
                }
                error_log("Email validation passed for " . ucfirst($platform));
                
                // skip all further link/phone validation
                  goto finishValidation;
            } else {
                // Existing validation for other task types (links, phone numbers)
                if ($platform === 'whatsapp' || $platform === 'telegram') {
                    $isPhoneNumber = preg_match('/^\+?[0-9\s\-()]+$/', $profile_link);
                    error_log("" . ucfirst($platform) . " - Is phone number: " . ($isPhoneNumber ? 'YES' : 'NO'));
                    
                    if ($isPhoneNumber) {
                        // Validate as Nigerian phone number
                        $validation = validateNigerianPhoneNumber($profile_link);
                        
                        if (!$validation['valid']) {
                            error_log("ERROR: Invalid Nigerian phone number: $profile_link");
                            echo json_encode([
                                'success' => false,
                                'message' => 'Invalid Nigerian phone number. Please enter a valid ' . ucfirst($platform) . ' number (e.g., +234 or 0).'
                            ]);
                            exit;
                        }
                        
                        $cleanPhone = $validation['number'];
                        error_log("Valid Nigerian phone number: $cleanPhone");
                        
                        // Store the formatted phone number instead of raw input
                        $profile_link = $cleanPhone;
                    } else {
                        // It's a URL, validate it
                        if (!filter_var($profile_link, FILTER_VALIDATE_URL)) {
                            error_log("ERROR: Invalid " . ucfirst($platform) . " URL: $profile_link");
                            echo json_encode(['success' => false, 'message' => 'Please provide a valid ' . ucfirst($platform) . ' link or phone number']);
                            exit;
                        }
                        error_log("" . ucfirst($platform) . " URL validation passed");
                    }
                } else {
                    if (!filter_var($profile_link, FILTER_VALIDATE_URL)) {
                        error_log("ERROR: Invalid URL for platform $platform: $profile_link");
                        echo json_encode(['success' => false, 'message' => 'Please provide a valid profile link (must start with http:// or https://)']);
                        exit;
                    }
                    error_log("URL validation passed");
                }
            }
            
           // Check if this proof has already been used for this task
            $stmt = $pdo->prepare("
                SELECT COUNT(*) as duplicate_count 
                FROM user_tasks 
                WHERE task_id = ? AND proof_url = ?
            ");
            $stmt->execute([$user_task['task_id'], $profile_link]);
            $duplicate_check = $stmt->fetch();
            
            if ($duplicate_check && $duplicate_check['duplicate_count'] > 0) {
                error_log("ERROR: Duplicate proof detected - Link/Email/Phone already used on this task");
                echo json_encode([
                    'success' => false,
                    'message' => 'This link, email, or phone number has already been used for this task. Please use a different profile or contact support.'
                ]);
                exit;
            }

        
            error_log("Duplicate proof check passed");
            
            $platformDomains = [
                'tiktok' => ['tiktok.com', 'vm.tiktok.com'],
                'instagram' => ['instagram.com', 'instagr.am'],
                'twitter' => ['twitter.com', 'x.com', 't.co'],
                'facebook' => ['facebook.com', 'fb.com', 'fb.me', 'm.facebook.com'],
                'linkedin' => ['linkedin.com', 'lnkd.in'],
                'snapchat' => ['snapchat.com', 'snap.com'],
                'youtube' => ['youtube.com', 'youtu.be', 'm.youtube.com'],
                'pinterest' => ['pinterest.com', 'pin.it'],
                'reddit' => ['reddit.com', 'redd.it'],
                'discord' => ['discord.com', 'discord.gg', 'discordapp.com'],
                'twitch' => ['twitch.tv', 'twitch.com'],
                'telegram' => ['telegram.org', 't.me', 'telegram.me'],
                'whatsapp' => ['whatsapp.com', 'wa.me', 'chat.whatsapp.com', 'api.whatsapp.com'],
                'playstore' => ['play.google.com'],
                'appstore' => ['apps.apple.com', 'itunes.apple.com'],
                'audiomack' => ['audiomack.com'],
                'boomplay' => ['boomplay.com'],
                'spotify' => ['spotify.com', 'open.spotify.com', 'spoti.fi'],
                'applemusic' => ['music.apple.com', 'itunes.apple.com'],
                'soundcloud' => ['soundcloud.com', 'on.soundcloud.com']
            ];
            
            if (!($platform === 'whatsapp' && preg_match('/^\+?[0-9\s\-()]+$/', $profile_link))) {
                $parsedUrl = parse_url($profile_link);
                $host = strtolower($parsedUrl['host'] ?? '');
                $path = $parsedUrl['path'] ?? '/';
                
                // Remove www. prefix for comparison
                $host = str_replace('www.', '', $host);
                
                error_log("Parsed URL - Host: $host, Path: $path");
                
                $baseSocialUrls = [
                    'tiktok.com', 'instagram.com', 'twitter.com', 'x.com', 'facebook.com',
                    'linkedin.com', 'snapchat.com', 'youtube.com', 'pinterest.com',
                    'reddit.com', 'discord.com', 'twitch.tv', 'telegram.org', 'whatsapp.com',
                    'audiomack.com', 'boomplay.com', 'spotify.com', 'music.apple.com', 'soundcloud.com'
                ];
                
                foreach ($baseSocialUrls as $baseUrl) {
                    if (stripos($host, $baseUrl) !== false && ($path === '/' || $path === '')) {
                        error_log("ERROR: Base URL detected (no profile): $profile_link");
                        echo json_encode(['success' => false, 'message' => 'Please provide a link to your profile.']);
                        exit;
                    }
                }
                
                error_log("Base URL check passed");
                
                $link_valid = false;
                
                if (isset($platformDomains[$platform])) {
                    foreach ($platformDomains[$platform] as $domain) {
                        if (stripos($host, $domain) !== false) {
                            $link_valid = true;
                            error_log("Platform match found - Platform: $platform, Domain: $domain, Host: $host");
                            break;
                        }
                    }
                }
                
                if (!preg_match('/^\\+?[0-9\\s\\-()]+$/', $profile_link) && $platform === 'telegram') {
                    // If it's not a phone number for Telegram, check domain
                    if (!$link_valid) {
                        error_log("ERROR: Invalid platform match - Platform: $platform, Host: $host");
                        $platformName = ucfirst($platform);
                        if ($platform === 'applemusic') $platformName = 'Apple Music';
                        if ($platform === 'playstore') $platformName = 'Google Play Store';
                        if ($platform === 'appstore') $platformName = 'Apple App Store';
                        echo json_encode(['success' => false, 'message' => "Profile Link must be from $platformName."]);
                        exit;
                    }
                } elseif (!$link_valid && $platform !== 'telegram') {
                    // For non-Telegram platforms, require valid domain
                    error_log("ERROR: Invalid platform match - Platform: $platform, Host: $host");
                    $platformName = ucfirst($platform);
                    if ($platform === 'applemusic') $platformName = 'Apple Music';
                    if ($platform === 'playstore') $platformName = 'Google Play Store';
                    if ($platform === 'appstore') $platformName = 'Apple App Store';
                    echo json_encode(['success' => false, 'message' => "Profile Link must be from $platformName."]);
                    exit;
                }
                
                error_log("Platform validation passed");
            }
            
            finishValidation:
            error_log("All validations passed, proceeding to credit user");
            
            $earning = getTaskReward($user_task, $user_data);
            error_log("Calculated earning: â‚¦$earning");
            
            $final_status = 'completed';
            
            $stmt = $pdo->prepare("
                UPDATE user_tasks 
                SET proof_url = ?, status = ?, completed_at = NOW() 
                WHERE id = ?
            ");
            $updateResult = $stmt->execute([$profile_link, $final_status, $user_task_id]);
            
            if (!$updateResult) {
                $errorInfo = $stmt->errorInfo();
                error_log("ERROR: Failed to update user_tasks: " . print_r($errorInfo, true));
                echo json_encode(['success' => false, 'message' => 'Database error updating task: ' . $errorInfo[2]]);
                exit;
            }
            
            error_log("User task updated successfully");
            
            $pdo->beginTransaction();
            error_log("Transaction started");
            
            try {
                // Update balance
                $stmt = $pdo->prepare("
                    UPDATE balances 
                    SET task_earnings = task_earnings + ?, total_balance = total_balance + ? 
                    WHERE user_id = ?
                ");
                $balanceResult = $stmt->execute([$earning, $earning, $user_id]);
                
                if (!$balanceResult) {
                    $errorInfo = $stmt->errorInfo();
                    error_log("ERROR: Failed to update balances: " . print_r($errorInfo, true));
                    throw new Exception('Failed to update balance: ' . $errorInfo[2]);
                }
                
                error_log("Balance updated successfully");
                
                // Record transaction
                $stmt = $pdo->prepare("
                    INSERT INTO transactions 
                    (user_id, transaction_type, amount, balance_type, description, reference_id, created_at) 
                    VALUES (?, 'task_reward', ?, 'activity_earnings', ?, ?, NOW())
                ");
                $description = "Completed task: {$user_task['title']}";
                $transactionResult = $stmt->execute([$user_id, $earning, $description, "TASK-{$user_task_id}"]);
                
                if (!$transactionResult) {
                    $errorInfo = $stmt->errorInfo();
                    error_log("ERROR: Failed to insert transaction: " . print_r($errorInfo, true));
                    throw new Exception('Failed to record transaction: ' . $errorInfo[2]);
                }
                
                error_log("Transaction recorded successfully");
                
                // Mark task as completed and store the reward amount
                $stmt = $pdo->prepare("INSERT IGNORE INTO user_completed_tasks (user_id, task_id, reward_amount) VALUES (?, ?, ?)");
                $completedResult = $stmt->execute([$user_id, $user_task['task_id'], $earning]);
                
                if (!$completedResult) {
                    $errorInfo = $stmt->errorInfo();
                    error_log("WARNING: Failed to mark task as completed: " . print_r($errorInfo, true));
                    // Don't throw exception here, just log warning
                } else {
                    error_log("Task marked as completed");
                }
                
                
                // Log the sync action
                $stmt = $pdo->prepare("
                    INSERT INTO task_count_sync_log 
                    (action_type, task_id, user_id, fake_count_before, fake_count_after, real_count_before, real_count_after) 
                    VALUES ('task_completed', ?, ?, ?, ?, ?, ?)
                ");
                $stmt->execute([$user_task['task_id'], $user_id, $fake_before, $fake_after, $real_before, $real_after]);
                
                // ---------------------------------------------------------
// UPDATE TASK COMPLETION COUNT
// ---------------------------------------------------------
$stmt = $pdo->prepare("
    UPDATE tasks 
    SET completed_count = completed_count + 1
    WHERE id = ?
");
$stmt->execute([$user_task['task_id']]);

// Get updated counts
$stmt = $pdo->prepare("
    SELECT completed_count, participants_count 
    FROM tasks 
    WHERE id = ?
");
$stmt->execute([$user_task['task_id']]);
$taskCounts = $stmt->fetch();

if ($taskCounts) {
    $completedCount = intval($taskCounts['completed_count']);
    $participantsCount = intval($taskCounts['participants_count']);

    // If task limit reached â†’ mark as completed
 if ($completedCount >= $participantsCount) {

    // Mark task completed
    $stmt = $pdo->prepare("
        UPDATE tasks 
        SET is_completed = 1,
            is_active = 0
        WHERE id = ?
    ");
    $stmt->execute([$user_task['task_id']]);

    // ðŸŽ¯ Only reduce fake_total_tasks NOW
    $stmt = $pdo->prepare("
        SELECT setting_value FROM task_display_settings 
        WHERE setting_key = 'fake_total_tasks'
    ");
    $stmt->execute();
    $current_fake = $stmt->fetchColumn();

    if ($current_fake !== false) {
        $new_fake = max(0, $current_fake - 1);

        $stmt = $pdo->prepare("
            UPDATE task_display_settings 
            SET setting_value = ?
            WHERE setting_key = 'fake_total_tasks'
        ");
        $stmt->execute([$new_fake]);
    }
}

}
// ---------------------------------------------------------

                
                $pdo->commit();
                error_log("Transaction committed successfully");
                error_log("===== VERIFICATION SUCCESS - User credited â‚¦$earning =====");
                
                echo json_encode([
                    'success' => true,
                    'approved' => true,
                    'reward' => $earning,
                    'message' => 'Task completed! â‚¦' . number_format($earning, 2) . ' has been credited to your account.'
                ]);
                exit;
                
            } catch (Exception $e) {
                $pdo->rollBack();
                error_log("ERROR: Transaction rolled back - " . $e->getMessage());
                error_log("ERROR: Stack trace - " . $e->getTraceAsString());
                echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
                exit;
            }
            
        }
        
        echo json_encode(['success' => false, 'message' => 'Invalid action']);
        exit;
    }
    
    // Get completed tasks
    $stmt = $pdo->prepare("
        SELECT DISTINCT task_id FROM user_completed_tasks
        WHERE user_id = ?
    ");
    $stmt->execute([$user_id]);
    $completed_tasks = $stmt->fetchAll(PDO::FETCH_COLUMN);
    
    // Get task history
    $stmt = $pdo->prepare("
        SELECT ut.*, t.title, t.description, t.platform, t.task_url, t.reward_amount, t.member_reward, t.non_member_reward, t.posted_by_admin
        FROM user_tasks ut
        JOIN tasks t ON ut.task_id = t.id
        WHERE ut.user_id = ? AND ut.created_at >= DATE_SUB(NOW(), INTERVAL 1 DAY)
        ORDER BY ut.created_at DESC
    ");
    $stmt->execute([$user_id]);
    $task_history = $stmt->fetchAll();
    
    // Calculate total active tasks
    if ($user_data['membership_type'] === 'free') {
        $total_active_tasks = $fake_total_tasks;
    } else {
        $stmt = $pdo->prepare("
            SELECT COUNT(*) as total_active_tasks
            FROM tasks t
            WHERE t.is_active = 1 
            AND t.id NOT IN (SELECT task_id FROM user_completed_tasks WHERE user_id = ?)
        ");
        $stmt->execute([$user_id]);
        $result = $stmt->fetch();
        $total_active_tasks = $result ? intval($result['total_active_tasks']) : 0; // Ensure integer value
    }
    
 // Get available tasks
$stmt = $pdo->prepare("
    SELECT t.*,
        (SELECT COUNT(*) FROM user_tasks WHERE user_id = ? AND task_id = t.id AND status IN ('pending', 'in_progress')) as in_progress,
        (SELECT COUNT(*) FROM user_tasks WHERE user_id = ? AND task_id = t.id AND status = 'completed') as user_completed_count
    FROM tasks t
    WHERE 
        t.is_active = 1
        AND t.is_completed = 0
        AND t.id NOT IN (SELECT task_id FROM user_completed_tasks WHERE user_id = ?)
    ORDER BY t.is_pinned DESC, t.created_at DESC
");

    $stmt->execute([$user_id, $user_id, $user_id]);
    $available_tasks = $stmt->fetchAll();
    
    // Fetch pinned tasks separately for the "compulsory" section
    $stmt = $pdo->prepare("
        SELECT t.*,
        (SELECT COUNT(*) FROM user_tasks WHERE user_id = ? AND task_id = t.id AND status IN ('pending', 'in_progress')) as in_progress,
        (SELECT COUNT(*) FROM user_tasks WHERE user_id = ? AND task_id = t.id AND status = 'completed') as completed_count
        FROM tasks t
        WHERE t.is_active = 1 AND t.is_pinned = 1 AND t.id NOT IN (SELECT task_id FROM user_completed_tasks WHERE user_id = ?)
        ORDER BY t.created_at DESC
    ");
    $stmt->execute([$user_id, $user_id, $user_id]);
    $pinned_tasks = $stmt->fetchAll();

} catch (PDOException $e) {
    error_log("Perform Tasks Error: " . $e->getMessage());
    $sessionMessage = "Error loading tasks. Please try again.";
    $sessionMessageType = "error";
}

// Helper function to detect platform from task data
function detectTaskPlatform($title, $description, $task_type, $platform = null) {
    if (!empty($platform)) {
        return strtolower($platform);
    }
    
    $platforms = [
        'tiktok' => 'TikTok',
        'instagram' => 'Instagram',
        'whatsapp' => 'WhatsApp',
        'playstore' => 'PlayStore',
        'appstore' => 'AppStore',
        'telegram' => 'Telegram',
        'twitter' => 'Twitter',
        'facebook' => 'Facebook',
        'linkedin' => 'LinkedIn',
        'snapchat' => 'Snapchat',
        'youtube' => 'YouTube',
        'pinterest' => 'Pinterest',
        'reddit' => 'Reddit',
        'discord' => 'Discord',
        'twitch' => 'Twitch',
        'audiomack' => 'Audiomack',
        'boomplay' => 'Boomplay',
        'spotify' => 'Spotify',
        'applemusic' => 'Apple Music',
        'soundcloud' => 'SoundCloud'
    ];
    
    $search_text = strtolower($title . ' ' . $description . ' ' . $task_type);
    
    foreach ($platforms as $key => $name) {
        if (stripos($search_text, $key) !== false || stripos($search_text, $name) !== false) {
            return $key;
        }
    }
    return 'tiktok'; // default
}


function validateNigerianPhoneNumber($phoneNumber) {
    try {
        $phoneUtil = PhoneNumberUtil::getInstance();
        // Parse the phone number for Nigeria
        $parsed = $phoneUtil->parse($phoneNumber, 'NG');
        // Validate the parsed number
        $isValid = $phoneUtil->isValidNumber($parsed);
        
        if ($isValid) {
            // Format to international format
            $formatted = $phoneUtil->format($parsed, PhoneNumberFormat::INTERNATIONAL);
            return [
                'valid' => true,
                'formatted' => $formatted,
                'number' => $phoneUtil->format($parsed, PhoneNumberFormat::E164)
            ];
        }
        return ['valid' => false];
    } catch (Exception $e) {
        error_log("Phone validation error: " . $e->getMessage());
        return ['valid' => false];
    }
}

function getTaskReward($task, $user_data)
{
    global $task_earnings;

    // Admin posted tasks use admin reward
    if (!empty($task['posted_by_admin']) && $task['posted_by_admin'] == 1) {
        $reward = floatval($task['member_reward']);
        return $reward > 0 ? $reward : 50;
    }

    // Platform is detected earlier using detectTaskPlatform()
    $platform = strtolower($task['platform'] ?? 'tiktok'); // fallback

    if (isset($task_earnings[$platform])) {
        return $task_earnings[$platform];
    }

    // fallback if unknown platform
    return 50;
}



function getPlatformColor($platform) {
    $colors = [
        'tiktok' => '#000000',
        'instagram' => '#E4405F',
        'whatsapp' => '#25D366',
        'playstore' => '#34A853',
        'appstore' => '#0D7EFF',
        'telegram' => '#0088cc',
        'twitter' => '#1DA1F2',
        'facebook' => '#1877F2',
        'linkedin' => '#0A66C2',
        'snapchat' => '#FFFC00',
        'youtube' => '#FF0000',
        'pinterest' => '#E60023',
        'reddit' => '#FF4500',
        'discord' => '#5865F2',
        'twitch' => '#9146FF',
        'audiomack' => '#FF8800',
        'boomplay' => '#E91E63',
        'spotify' => '#1DB954',
        'applemusic' => '#FA243C',
        'soundcloud' => '#FF5500',
        'website' => '#000000'
    ];
    
    return $colors[$platform] ?? '#000000'; // default to mint

}

function getPlatformSVG($platform) {
    $svgs = [
        'tiktok' => '<svg viewBox="0 0 24 24" fill="#ffffff" aria-hidden="true"><path d="M19.59 6.69a4.83 4.83 0 0 1-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 0 1-5.2 1.74 2.89 2.89 0 0 1 2.31-4.64 2.93 2.93 0 0 1 .88.13V9.4a6.84 6.84 0 0 0-1-.05A6.33 6.33 0 0 0 5 20.1a6.34 6.34 0 0 0 10.86-4.43v-7a8.16 8.16 0 0 0 4.77 1.52v-3.4a4.85 4.85 0 0 1-1-.1z"/></svg>',

        'instagram' => '<svg viewBox="0 0 24 24" aria-hidden="true"><defs><linearGradient id="igGrad" x1="0" x2="1" y1="0" y2="1"><stop offset="0" stop-color="#f58529"/><stop offset="0.3" stop-color="#dd2a7b"/><stop offset="0.6" stop-color="#8134af"/><stop offset="1" stop-color="#515bd4"/></linearGradient></defs><path fill="url(#igGrad)" d="M7.8 2h8.4C19.4 2 22 4.6 22 7.8v8.4a5.8 5.8 0 0 1-5.8 5.8H7.8C4.6 22 2 19.4 2 16.2V7.8A5.8 5.8 0 0 1 7.8 2m-.2 2A3.6 3.6 0 0 0 4 7.6v8.8C4 18.39 5.61 20 7.6 20h8.8a3.6 3.6 0 0 0 3.6-3.6V7.6C20 5.61 18.39 4 16.4 4H7.6m9.65 1.5a1.25 1.25 0 0 1 1.25 1.25A1.25 1.25 0 0 1 17.25 8 1.25 1.25 0 0 1 16 6.75a1.25 1.25 0 0 1 1.25-1.25M12 7a5 5 0 0 1 5 5 5 5 0 0 1-5 5 5 5 0 0 1-5-5 5 5 0 0 1 5-5m0 2a3 3 0 0 0-3 3 3 3 0 0 0 3 3 3 3 0 0 0 3-3 3 3 0 0 0-3-3z"/></svg>',

        'whatsapp' => '<svg viewBox="0 0 24 24" fill="#25D366" aria-hidden="true"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/></svg>',
        
        'playstore' => '<svg width="24" height="24" viewBox="0 0 256 256" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M29.24 20.6199C27.13 22.7299 26 25.6399 26 28.2599V227.66C26 230.28 27.13 233.19 29.24 235.3L29.87 235.93L134.87 130.93V130.3L29.24 20.6199Z" fill="#EA4335"/><path d="M178.51 174.77L134.87 131.12V130.93L178.51 87.2899L179.24 87.9199L232.19 118.72C247.65 127.95 247.65 144.1 232.19 153.33L179.24 184.13L178.51 184.76V174.77Z" fill="#FBBC04"/><path d="M178.51 87.2899L134.87 130.93L29.24 20.6199C31.35 18.5099 34.26 17.3799 36.88 17.3799C39.5 17.3799 42.41 18.5099 44.52 20.6199L178.51 87.2899Z" fill="#4285F4"/><path d="M178.51 174.77L44.52 241.44C42.41 243.55 39.5 244.68 36.88 244.68C34.26 244.68 31.35 243.55 29.24 241.44L134.87 131.12L178.51 174.77Z" fill="#34A853"/></svg>',


        'youtube' => '<svg viewBox="0 0 24 24" fill="#FF0000" aria-hidden="true"><path d="M10 15l5.19-3L10 9v6m11.56-7.83c.13.47.22 1.1.28 1.9.07.8.1 1.49.1 2.09L22 12c0 2.19-.16 3.8-.44 4.83-.25.9-.83 1.48-1.73 1.73-.47.13-1.33.22-2.65.28-1.3.07-2.49.1-3.59.1L12 19c-4.19 0-6.8-.16-7.83-.44-.9-.25-1.48-.83-1.73-1.73-.13-.47-.22-1.1-.28-1.9-.07-.8-.1-1.49-.1-2.09L2 12c0-2.19.16-3.8.44-4.83.25-.9.83-1.48 1.73-1.73.47-.13 1.33-.22 2.65-.28 1.3-.07 2.49-.1 3.59-.1L12 5c4.19 0 6.8.16 7.83.44.9.25 1.48.83 1.73 1.73z"/></svg>',

        'facebook' => '<svg viewBox="0 0 24 24" fill="#1877F2" aria-hidden="true"><path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/></svg>',

        'linkedin' => '<svg viewBox="0 0 24 24" fill="#0077B5" aria-hidden="true"><path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433c-1.144 0-2.063-.926-2.063-2.065 0-1.138.92-2.063 2.063-2.063 1.14 0 2.064.925 2.064 2.063 0 1.139-.925 2.065-2.064 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z"/></svg>',

        'telegram' => '<svg viewBox="0 0 24 24" fill="#0088CC" aria-hidden="true"><path d="M11.944 0A12 12 0 0 0 0 12a12 12 0 0 0 12 12 12 12 0 0 0 12-12A12 12 0 0 0 12 0a12 12 0 0 0-.056 0zm4.962 7.224c.1-.002.321.023.465.14a.506.506 0 0 1 .171.325c.016.093.036.306.02.472-.18 1.898-.962 6.502-1.36 8.627-.168.9-.499 1.201-.82 1.23-.696.065-1.225-.46-1.9-.902-1.056-.693-1.653-1.124-2.678-1.8-1.185-.78-.417-1.21.258-1.91.177-.184 3.247-2.977 3.307-3.23.007-.032.014-.15-.056-.212s-.174-.041-.249-.024c-.106.024-1.793 1.14-5.061 3.345-.48.33-.913.49-1.302.48-.428-.008-1.252-.241-1.865-.44-.752-.245-1.349-.374-1.297-.789.027-.216.325-.437.893-.663 3.498-1.524 5.83-2.529 6.998-3.014 3.332-1.386 4.025-1.627 4.476-1.635z"/></svg>',

        'twitter' => '<svg viewBox="0 0 24 24" aria-hidden="true"><g stroke="#ffffff" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 3l18 18"/><path d="M21 3L3 21"/></g></svg>',

        'snapchat' => '<svg viewBox="0 0 24 24" fill="#FFFC00" aria-hidden="true"><path d="M12.206.793c.99 0 4.347.276 5.93 3.821.529 1.193.403 3.219.299 4.847l-.003.06c-.012.18-.022.345-.03.51.075.045.203.09.401.09.3-.016.659-.12 1.033-.301.165-.088.344-.104.464-.104.182 0 .359.029.509.09.45.149.734.479.734.838.015.449-.39.839-1.213 1.168-.089.029-.209.075-.344.119-.45.135-1.139.36-1.333.81-.09.224-.061.524.12.868l.015.015c.06.136 1.526 3.475 4.791 4.014.255.044.435.27.42.509 0 .075-.015.149-.045.225-.24.569-1.273.988-3.146 1.271-.059.091-.12.375-.164.57-.029.179-.074.36-.134.553-.076.271-.27.405-.555.405h-.03c-.135 0-.313-.031-.538-.074-.36-.075-.765-.135-1.273-.135-.3 0-.599.015-.913.074-.6.104-1.123.464-1.723.884-.853.599-1.826 1.288-3.294 1.288-.06 0-.119-.015-.18-.015h-.149c-1.468 0-2.427-.675-3.279-1.288-.599-.42-1.107-.779-1.707-.884-.314-.045-.629-.074-.928-.074-.54 0-.958.089-1.272.149-.211.043-.391.074-.54.074-.374 0-.523-.224-.583-.42-.061-.192-.09-.389-.135-.567-.046-.181-.105-.494-.166-.57-1.918-.222-2.95-.642-3.189-1.226-.031-.063-.052-.15-.055-.225-.015-.243.165-.465.42-.509 3.264-.54 4.73-3.879 4.791-4.01l.016-.029c.18-.345.224-.645.119-.869-.195-.434-.884-.658-1.332-.809-.121-.029-.24-.074-.346-.119-1.107-.435-1.257-.93-1.197-1.273.09-.479.674-.793 1.168-.793.146 0 .27.029.383.074.42.194.789.3 1.104.3.234 0 .384-.06.465-.105l-.046-.569c-.098-1.626-.225-3.651.307-4.837C7.392 1.077 10.739.807 11.727.807l.419-.015h.06z"/></svg>',

        'youtube' => '<svg viewBox="0 0 24 24" fill="#FF0000" aria-hidden="true"><path d="M10 15l5.19-3L10 9v6m11.56-7.83c.13.47.22 1.1.28 1.9.07.8.1 1.49.1 2.09L22 12c0 2.19-.16 3.8-.44 4.83-.25.9-.83 1.48-1.73 1.73-.47.13-1.33.22-2.65.28-1.3.07-2.49.1-3.59.1L12 19c-4.19 0-6.8-.16-7.83-.44-.9-.25-1.48-.83-1.73-1.73-.13-.47-.22-1.1-.28-1.9-.07-.8-.1-1.49-.1-2.09L2 12c0-2.19.16-3.8.44-4.83.25-.9.83-1.48 1.73-1.73.47-.13 1.33-.22 2.65-.28 1.3-.07 2.49-.1 3.59-.1L12 5c4.19 0 6.8.16 7.83.44.9.25 1.48.83 1.73 1.73z"/></svg>',

       
        
    
        'pinterest' => '<svg viewBox="0 0 24 24" fill="#E60023"><path d="M12.017 0C5.396 0 .029 5.367.029 11.987c0 5.079 3.158 9.417 7.618 11.162-.105-.949-.199-2.403.041-3.439.219-.937 1.406-5.957 1.406-5.957s-.359-.72-.359-1.781c0-1.663.967-2.911 2.168-2.911 1.024 0 1.518.769 1.518 1.688 0 1.029-.653 2.567-.992 3.992-.285 1.193.6 2.165 1.775 2.165 2.128 0 3.768-2.245 3.768-5.487 0-2.861-2.063-4.869-5.008-4.869-3.41 0-5.409 2.562-5.409 5.199 0 1.033.394 2.143.889 2.741.099.12.112.225.085.345-.09.375-.293 1.199-.334 1.363-.053.225-.172.271-.401.165-1.495-.69-2.433-2.878-2.433-4.646 0-3.776 2.748-7.252 7.92-7.252 4.158 0 7.392 2.967 7.392 6.923 0 4.135-2.607 7.462-6.233 7.462-1.214 0-2.354-.629-2.758-1.379l-.749 2.848c-.269 1.045-1.004 2.352-1.498 3.146 1.123.345 2.306.535 3.55.535 6.607 0 11.985-5.365 11.985-11.987C23.97 5.39 18.592.026 11.985.026L12.017 0z"/></svg>',

        'reddit' => '<svg viewBox="0 0 24 24" fill="#FF4500" aria-hidden="true"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-3 13.5a1.5 1.5 0 1 1 0-3 1.5 1.5 0 0 1 0 3zm6 0a1.5 1.5 0 1 1 0-3 1.5 1.5 0 0 1 0 3zM10.5 14a3 3 0 0 1 3-3h-2.5a3 3 0 1 1 0 6h2.5a3 3 0 1 1-3-3z"/></svg>',

        'discord' => '<svg viewBox="0 0 24 24" fill="#5865F2" aria-hidden="true"><path d="M20.317 4.492c-1.53-.69-3.17-1.2-4.885-1.49a.075.075 0 00-.079.036c-.211.375-.445.864-.607 1.25a17.97 17.97 0 00-5.406 0c-.162-.386-.405-.875-.616-1.25a.077.077 0 00-.079-.036c-1.716.29-3.354.8-4.885 1.49a.07.07 0 00-.032.027C1.9 8.55.27 12.45 1.635 16.25a.075.075 0 00.029.052c1.582.973 3.112 1.565 4.615 1.96.03.008.061 0 .076-.021.415-.566.784-1.156 1.095-1.776a.075.075 0 00-.041-.104c-.606-.229-1.184-.499-1.738-.8a.075.075 0 01-.008-.125c.116-.088.233-.18.346-.273a.074.074 0 01.076-.01c3.64 1.663 7.581 1.663 11.183 0a.074.074 0 01.077.009c.113.094.23.185.346.274a.075.075 0 01-.006.125c-.554.3-1.131.571-1.738.8a.075.075 0 00-.041.105c.311.62.68 1.21 1.095 1.776a.075.075 0 00.076.021c1.503-.395 3.033-.987 4.615-1.96a.075.075 0 00.031-.03z"/></svg>',

        'twitch' => '<svg viewBox="0 0 24 24" fill="#9146FF" aria-hidden="true"><path d="M21.484 5.612a6.722 6.722 0 00-1.66-2.205 7.008 7.008 0 00-2.395-1.718 7.178 7.178 0 00-3.016-.445H7.362a7.177 7.177 0 00-3.016.445 6.721 6.721 0 00-1.66 2.205 6.999 6.999 0 00-1.177 2.649 7.326 7.326 0 00-.438 3.367v4.402c0 1.075.13 2.115.438 3.367a6.72 6.72 0 001.66 2.205 7.008 7.008 0 002.395 1.718 7.178 7.178 0 003.016.445h6.762a7.178 7.178 0 003.016-.445 6.721 6.721 0 001.66-2.205 7.008 7.008 0 001.177-2.649 7.325 7.325 0 00.438-3.367v-4.402c0-1.075-.13-2.115-.438-3.367zm-2.845 9.682a3.516 3.516 0 01-.739 1.335 3.425 3.425 0 01-1.195 1.041 3.506 3.506 0 01-1.584.445H7.362a3.506 3.506 0 01-1.584-.445 3.425 3.425 0 01-1.195-1.041 3.515 3.515 0 01-.739-1.335 3.645 3.645 0 01-.261-1.771v-4.402a3.645 3.645 0 01.261-1.771 3.516 3.516 0 01.739-1.335 3.425 3.425 0 011.195-1.041 3.506 3.506 0 011.584-.445h6.762a3.506 3.506 0 011.584.445 3.425 3.425 0 011.195 1.041 3.516 3.516 0 01.739 1.335 3.645 3.645 0 01-.261 1.771v4.402a3.645 3.645 0 01-.261 1.771z"/></svg>',

        'audiomack' => '<svg viewBox="0 0 24 24" fill="#FF8800" aria-hidden="true"><path d="M12 2L2 7v10l10 5 10-5V7l-10-5zm0 2.18L19.82 8 12 11.82 4.18 8 12 4.18zM4 9.48l7 3.5v7.84l-7-3.5V9.48zm16 0v7.84l-7 3.5v-7.84l7-3.5z"/></svg>',

        'boomplay' => '<svg viewBox="0 0 24 24" fill="#E91E63" aria-hidden="true"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 14.5v-9l6 4.5-6 4.5z"/></svg>',

        'spotify' => '<svg viewBox="0 0 24 24" fill="#1DB954" aria-hidden="true"><path d="M12 0C5.4 0 0 5.4 0 12s5.4 12 12 12 12-5.4 12-12S18.66 0 12 0zm5.521 17.34c-.24.359-.66.48-1.021.24-2.82-1.74-6.36-2.101-10.561-1.141-.418.122-.779-.179-.899-.539-.12-.421.18-.78.54-.9 4.56-1.021 8.52-.6 11.64 1.32.42.18.479.659.301 1.02zm1.44-3.3c-.301.42-.841.6-1.262.3-3.239-1.98-8.159-2.58-11.939-1.38-.479.12-1.02-.12-1.14-.6-.12-.48.12-.1.6-1.141C9.6 9.9 15 10.561 18.72 12.84c.361.181.54.78.241 1.2zm.12-3.36C15.24 8.4 8.82 8.16 5.16 9.301c-.6.179-1.2-.181-1.38-.721-.18-.601.18-.72.72-1.381 4.26-1.26 11.28-1.02 15.721 1.621.539.3.719 1.02.419 1.56-.299.421-1.02.599-1.559.3z"/></svg>',

        'applemusic' => '<svg viewBox="0 0 24 24" fill="#FA243C" aria-hidden="true"><path d="M23.994 6.124a9.23 9.23 0 0 0-.24-2.19c-.317-1.31-1.062-2.31-2.18-3.043a5.022 5.022 0 0 0-1.877-.726 10.496 10.496 0 0 0-1.564-.15c-.04-.003-.083-.01-.124-.013H5.986c-.152.01-.303.017-.455.026-.747.043-1.49.123-2.193.4-1.336.53-2.3 1.452-2.865 2.78-.192.448-.292.925-.363 1.408a10.61 10.61 0 0 0-.1 1.18c0 .032-.007.062-.01.093v12.223c.01.14.017.283.027.424.05.815.154 1.624.497 2.373.65 1.42 1.738 2.353 3.234 2.801.42.127.856.187 1.293.228.555.053 1.11.06 1.667.06h11.03a12.5 12.5 0 0 0 1.57-.1c.822-.106 1.596-.35 2.296-.81a5.046 5.046 0 0 0 1.88-2.207c.186-.42.293-.87.344-1.333.065-.586.092-1.178.092-1.77V6.124z"/></svg>',

        'soundcloud' => '<svg viewBox="0 0 24 24" fill="#FF5500" aria-hidden="true"><path d="M1.175 12.225c-.051 0-.094.046-.101.1l-.233 2.154.233 2.105c.007.058.05.098.101.098.05 0 .09-.04.099-.098l.255-2.105-.27-2.154c0-.057-.045-.1-.09-.1m-.899.828c-.06 0-.091.037-.104.094L0 14.479l.165 1.308c0 .055.045.094.09.094s.089-.045.104-.104l.21-1.319-.21-1.334c0-.061-.044-.09-.09-.09m1.83-1.229c-.061 0-.12.045-.12.104l-.21 2.563.225 2.458c0 .06.045.12.119.12.061 0 .105-.061.121-.12l.254-2.474-.254-2.458c0-.06-.045-.12.09-.09m.945-.089c-.075 0-.135.06-.15.135l-.193 2.64.21 2.458c0 .06.045.12.119.12.061 0 .105-.061.121-.12l.254-2.474-.254-2.458c0-.06-.045-.12.09-.09m.959-.166c-.09 0-.15.074-.165.148l-.195 2.883.209 2.714c.016.09.075.165.166.165.074 0 .149-.074.164-.165l.226-2.714-.226-2.883c-.015-.091-.075-.165-.165-.165m.971-.15c-.09 0-.166.074-.18.165l-.18 3.046.18 2.883c.015.09.075.165.18.165.09 0 .164-.074.18-.165l.209-2.883-.209-3.046c-.016-.09-.09-.165-.18-.165m.986-.104c-.104 0-.18.09-.194.179l-.18 3.165.18 2.883c.015.104.09.18.194.18.09 0 .18-.09.195-.18l.209-2.883-.209-3.165c-.015-.104-.09-.18-.195-.18m.987-.045c-.105 0-.195.09-.21.195l-.164 3.195.164 2.883c.016.119.105.225.225.225.119 0 .21-.105.225-.225l.179-2.82-.179-3.27c-.016-.135-.12-.254-.255-.254m1.003-.09c-.135 0-.314.149-.33.329l-.089 3.629.089 2.82c.016.18.15.33.33.33.179 0 .313-.15.329-.33l.119-2.82-.119-3.629c-.016-.18-.15-.329-.329-.329m1.018-.09c-.18 0-.314.149-.33.329l-.089 3.629.089 2.82c.016.18.15.33.33.33.179 0 .313-.15.329-.33l.119-2.82-.119-3.629c-.016-.18-.15-.329-.329-.329m6.628 1.763c-.195 0-.375.045-.539.104v7.008c0 .06.045.104.104.104h8.254c.81 0 1.469-.659 1.469-1.469 0-2.025-1.643-3.668-3.668-3.668-.405 0-.795.074-1.155.195-.24-1.38-1.425-2.429-2.865-2.429-.405 0-.795.09-1.155.24-.195-.09-.405-.135-.63-.135z"/></svg>',
        
        'website' => '<svg viewBox="0 0 24 24" fill="#ffffff" aria-hidden="true"><path d="M12 2a10 10 0 1 0 10 10A10.011 10.011 0 0 0 12 2Zm6.93 6h-3.27a15.27 15.27 0 0 0-1.2-3.51A8.025 8.025 0 0 1 18.93 8Zm-6.93-4.95c.69.89 1.39 2.19 1.8 3.95h-3.6c.41-1.76 1.11-3.06 1.8-3.95ZM8.54 10a18.5 18.5 0 0 1 .63-3h5.66a18.5 18.5 0 0 1 .63 3Zm0 2h6.92a18.5 18.5 0 0 1-.63 3H9.17a18.5 18.5 0 0 1-.63-3Zm.17 5h5.66c-.41 1.76-1.11 3.06-1.8 3.95-.69-.89-1.39-2.19-1.8-3.95Zm6.66 3.51c.5-1.1.89-2.33 1.2-3.51h3.27a8.025 8.025 0 0 1-4.47 3.51ZM5.2 16h3.27c.31 1.18.7 2.41 1.2 3.51A8.025 8.025 0 0 1 5.2 16Zm4.47-11.51c-.5 1.1-.89 2.33-1.2 3.51H5.2a8.025 8.025 0 0 1 4.47-3.51ZM4.07 14a8.025 8.025 0 0 1 0-4h3.27a20.9 20.9 0 0 0 0 4Z"/></svg>',

    ];

    return $svgs[$platform] ?? $svgs['tiktok']; // Default to TikTok SVG
}

?>
<?php include "doctype.php"; ?>
  <link rel="stylesheet" href="perform-task-page.css" />
  <style>
  
  body {
      background: #030922;
  }
    /* Additional styles for perform-tasks specific features */
    .view-toggle {
      display: flex;
      gap: 8px;
      background: rgba(8, 21, 64, 0.6);
      border-radius: 16px;
      padding: 6px;
      border: 1px solid rgba(100, 154, 255, 0.25);
    }
    
    .view-toggle button {
      padding: 10px 20px;
      border: none;
      background: transparent;
      color: rgba(205, 219, 255, 0.7);
      border-radius: 12px;
      cursor: pointer;
      transition: all 0.3s ease;
      font-weight: 600;
      font-size: 0.85rem;
      text-transform: uppercase;
      letter-spacing: 0.04em;
    }
    
    .view-toggle button.active {
      background: linear-gradient(135deg, rgba(77, 225, 193, 0.3), rgba(44, 92, 245, 0.3));
      color: var(--page-white);
      border: 1px solid rgba(77, 225, 193, 0.4);
    }
    
    .tasks-list-view {
      display: none;
      flex-direction: column;
      gap: 16px;
    }
    
    .tasks-list-view.active {
      display: flex;
    }
    
    .task-list-item {
      display: grid;
      grid-template-columns: auto 1fr auto;
      gap: 20px;
      align-items: center;
      background: rgba(6, 16, 48, 0.9);
      border: 1px solid rgba(100, 154, 255, 0.24);
      border-radius: 20px;
      padding: 20px;
      transition: all 0.3s ease;
    }
    
    .task-list-item:hover {
      border-color: rgba(77, 225, 193, 0.45);
      transform: translateX(4px);
    }
    
    .task-list-icon {
      width: 56px;
      height: 56px;
      border-radius: 14px;
      background: linear-gradient(135deg, rgba(77, 225, 193, 0.2), rgba(44, 92, 245, 0.2));
      display: flex;
      align-items: center;
      justify-content: center;
      border: 1px solid rgba(77, 225, 193, 0.3);
    }
    
    .task-list-icon svg {
      width: 32px;
      height: 32px;
      color: var(--page-mint);
    }
    
    .task-list-info h3 {
      margin: 0 0 8px;
      font-size: 1.1rem;
      color: var(--page-white);
    }
    
    .task-list-info p {
      margin: 0;
      color: rgba(205, 219, 255, 0.7);
      font-size: 0.9rem;
    }
    
    .task-list-action {
      display: flex;
      flex-direction: column;
      align-items: flex-end;
      gap: 8px;
    }
    
    .task-list-action button {
      width: 170px; /* Fixed width for action buttons */
      padding: 10px 16px;
      border-radius: 10px;
      font-weight: 600;
      font-size: 0.85rem;
      text-transform: uppercase;
      letter-spacing: 0.04em;
      cursor: pointer;
      transition: all 0.3s ease;
      border: none;
    }

    .task-list-action .btn-action {
      background: var(--page-mint);
      color: #030922;
    }

    .task-list-action .btn-action:hover {
      opacity: 0.85;
      transform: translateY(-1px);
    }

    .task-list-action .btn-pause {
      background: rgba(255, 193, 7, 0.2);
      border: 1px solid rgba(255, 193, 7, 0.4);
      color: #ffc107;
      cursor: not-allowed;
    }
    
    .task-list-action .btn-action[data-platform="tiktok"] { background-color: #00000 !important; color: white; }
    .task-list-action .btn-action[data-platform="instagram"] { background-color: #E4405F !important; }
    .task-list-action .btn-action[data-platform="whatsapp"] { background-color: #25D366 !important; }
    .task-list-action .btn-action[data-platform="playstore"] { background-color: #34A853 !important; }
    .task-list-action .btn-action[data-platform="appstore"] { background-color: #0D7EFF !important; }
    .task-list-action .btn-action[data-platform="telegram"] { background-color: #0088cc !important; }
    .task-list-action .btn-action[data-platform="twitter"] { background-color: #1DA1F2 !important; }
    .task-list-action .btn-action[data-platform="facebook"] { background-color: #1877F2 !important; }
    .task-list-action .btn-action[data-platform="linkedin"] { background-color: #0A66C2 !important; }
    .task-list-action .btn-action[data-platform="snapchat"] { background-color: #FFFC00 !important; color: #000 !important; }
    .task-list-action .btn-action[data-platform="youtube"] { background-color: #FF0000 !important; }
    .task-list-action .btn-action[data-platform="pinterest"] { background-color: #E60023 !important; }
    .task-list-action .btn-action[data-platform="reddit"] { background-color: #FF4500 !important; }
    .task-list-action .btn-action[data-platform="discord"] { background-color: #5865F2 !important; }
    .task-list-action .btn-action[data-platform="twitch"] { background-color: #9146FF !important; }
    .task-list-action .btn-action[data-platform="audiomack"] { background-color: #FF8800 !important; }
    .task-list-action .btn-action[data-platform="boomplay"] { background-color: #E91E63 !important; }
    .task-list-action .btn-action[data-platform="spotify"] { background-color: #1DB954 !important; }
    .task-list-action .btn-action[data-platform="applemusic"] { background-color: #FA243C !important; }
    .task-list-action .btn-action[data-platform="soundcloud"] { background-color: #FF5500 !important; }
     .task-list-action .btn-action[data-platform="website"] { background-color: #0000 !important; color: white; }

    .task-reward {
      font-size: 1.3rem;
      font-weight: 700;
      color: var(--page-mint);
    }
    
    .verification-modal {
      display: none;
      position: fixed;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      background: rgba(3, 9, 34, 0.9);
      backdrop-filter: blur(8px);
      z-index: 9999;
      align-items: center;
      justify-content: center;
      padding: 20px;
    }
    
    .verification-modal.active {
      display: flex;
    }
    
    .verification-content {
      background: rgba(6, 16, 48, 0.98);
      border: 1px solid rgba(100, 154, 255, 0.3);
      border-radius: 24px;
      padding: 32px;
      max-width: 600px;
      width: 100%;
      max-height: 90vh;
      overflow-y: auto;
    }
    
    .verification-step {
      display: none;
    }
    
    .verification-step.active {
      display: block;
    }
    
    .verification-step h2 {
      margin: 0 0 24px;
      font-size: 1.5rem;
      color: var(--page-white);
    }
    
    .verification-step p {
      color: rgba(205, 219, 255, 0.7);
      line-height: 1.7;
      margin-bottom: 24px;
    }
    
    .upload-area {
      border: 2px dashed rgba(100, 154, 255, 0.3);
      border-radius: 16px;
      padding: 40px;
      text-align: center;
      cursor: pointer;
      transition: all 0.3s ease;
      margin-bottom: 24px;
    }
    
    .upload-area:hover {
      border-color: rgba(77, 225, 193, 0.5);
      background: rgba(77, 225, 193, 0.05);
    }
    
    .upload-area.has-file {
      border-color: rgba(77, 225, 193, 0.5);
      background: rgba(77, 225, 193, 0.1);
    }
    
    .preview-image {
      max-width: 100%;
      border-radius: 12px;
      margin-top: 16px;
    }
    
    .form-input {
      width: 100%;
      padding: 14px 16px;
      border-radius: 12px;
      border: 1px solid rgba(100, 154, 255, 0.3);
      background: rgba(8, 21, 64, 0.6);
      color: var(--page-white);
      font-size: 0.95rem;
      font-family: inherit;
      transition: border-color 0.3s ease;
      margin-bottom: 24px;
    }
    
    .form-input:focus {
      outline: none;
      border-color: rgba(77, 225, 193, 0.5);
    }
    
    .verification-actions {
      display: flex;
      gap: 12px;
      justify-content: flex-end;
    }
    
    .btn-secondary {
      padding: 12px 24px;
      border-radius: 12px;
      border: 1px solid rgba(100, 154, 255, 0.3);
      background: rgba(8, 21, 64, 0.6);
      color: var(--page-white);
      font-weight: 600;
      font-size: 0.9rem;
      cursor: pointer;
      transition: all 0.3s ease;
    }
    
    .btn-secondary:hover {
      border-color: rgba(77, 225, 193, 0.5);
    }
    
    .timer-warning {
      background: rgba(255, 193, 7, 0.2);
      border: 1px solid rgba(255, 193, 7, 0.4);
      color: #ffc107;
      padding: 12px 16px;
      border-radius: 12px;
      margin-bottom: 24px;
      font-size: 0.9rem;
    }
    
    /* Added compulsory tasks section */
    .compulsory-section {
      margin-bottom: 48px;
    }
    
    .compulsory-header {
      display: flex;
      align-items: center;
      gap: 12px;
      margin-bottom: 24px;
      padding: 16px 24px;
      background: linear-gradient(135deg, rgba(239, 68, 68, 0.2), rgba(220, 38, 38, 0.2));
      border: 1px solid rgba(239, 68, 68, 0.4);
      border-radius: 16px;
    }
    
    .compulsory-header svg {
      width: 32px;
      height: 32px;
      color: #ef4444;
    }
    
    .compulsory-header h2 {
      margin: 0;
      font-size: 1.5rem;
      color: var(--page-white);
    }
    
    .compulsory-header p {
      margin: 4px 0 0;
      color: rgba(205, 219, 255, 0.7);
      font-size: 0.9rem;
    }
    
    .task-card.compulsory {
      background: linear-gradient(135deg, rgba(239, 68, 68, 0.1), rgba(220, 38, 38, 0.05));
    }
    
    .task-card.compulsory::before {
      
      position: absolute;
      top: 12px;
      right: 12px;
      background: #ef4444;
      color: white;
      padding: 4px 12px;
      border-radius: 8px;
      font-size: 0.75rem;
      font-weight: 700;
      letter-spacing: 0.05em;
    }
    
    .task-list-item.compulsory {
      /*border: 2px solid rgba(239, 68, 68, 0.5);*/
      /*background: linear-gradient(135deg, rgba(239, 68, 68, 0.1), rgba(220, 38, 38, 0.05));*/
    }
    
    @media (max-width: 680px) {
      .verification-content {
        padding: 24px;
      }
      
      .task-list-item {
        grid-template-columns: auto 1fr;
        gap: 12px;
      }
      
      .task-list-action {
        grid-column: 1 / -1;
        flex-direction: row;
        justify-content: space-between;
        align-items: center;
      }
    }

    /* Added platform-specific styles to task cards and list items */
    .platform-icon {
      width: 56px;
      height: 56px;
      border-radius: 14px;
      display: flex;
      align-items: center;
      justify-content: center;
      border: 1px solid rgba(77, 225, 193, 0.3); /* Default border */
    }
    .platform-icon div { /* Inner container for SVG */
      display: flex;
      align-items: center;
      justify-content: center;
      width: 32px;
      height: 32px;
    }
    .platform-icon svg {
      width: 100%;
      height: 100%;
    }
    
    .task-card .task-header .platform-icon {
      background: rgba(77, 225, 193, 0.2); /* Default background */
      border-color: rgba(77, 225, 193, 0.4); /* Default border color */
    }
    .task-card.compulsory .task-header .platform-icon {
      background: rgba(239, 68, 68, 0.1);
      border-color: rgba(239, 68, 68, 0.4);
    }

    /* Added platform-specific button colors */
    /* These are applied via JS now to .btn-action[data-platform="..."] */
    
    .btn-action:disabled {
      opacity: 0.6;
      cursor: not-allowed;
    }
    
    /* Added toast notification styles */
    .alert-message {
      position: fixed;
      top: 20px;
      right: -400px; /* start hidden off-screen */
      padding: 16px 24px;
      border-radius: 12px;
      color: white;
      font-family: 'Segoe UI', sans-serif;
      font-size: 15px;
      z-index: 10000;
      opacity: 0;
      box-shadow: 0 10px 40px rgba(0, 0, 0, 0.2);
      transition: right 0.6s ease, opacity 0.6s ease;
    }

    .alert-message.show {
      right: 20px;
      opacity: 1;
    }

    .alert-info { background-color: rgba(77, 225, 193, 0.2); border: 1px solid rgba(77, 225, 193, 0.4); }
    .alert-success { 
      background: rgba(77, 225, 193, 0.95);
      color: #030922;
      box-shadow: 0 10px 40px rgba(77, 225, 193, 0.4); 
    }
    .alert-warning { background-color: rgba(255, 193, 7, 0.2); border: 1px solid rgba(255, 193, 7, 0.4); color: #ffc107; }
    .alert-error {  
      background: rgba(255, 77, 77, 0.95);
      color: #fff;
      box-shadow: 0 10px 40px rgba(255, 77, 77, 0.4); 
    }
    
    /* CHANGE: Updated task cooldown styles - moved to bottom right corner as a badge */
    .task-cooldown {
      position: absolute;
      bottom: 12px;
      right: 12px;
      background: rgba(255, 193, 7, 0.95);
      backdrop-filter: blur(4px);
      border-radius: 12px;
      display: flex;
      align-items: center;
      gap: 8px;
      padding: 8px 16px;
      z-index: 10;
      box-shadow: 0 4px 12px rgba(255, 193, 7, 0.3);
    }

    .task-cooldown svg {
      width: 20px;
      height: 20px;
      color: #000;
    }

    .task-cooldown-time {
      font-size: 0.95rem;
      font-weight: 700;
      color: #000;
    }

    .task-cooldown-text {
      display: none; /* Hide text in compact badge */
    }
    
    /* CHANGE: Add Terms and Services modal styles */
    .ts-modal {
      display: none;
      position: fixed;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      background: rgba(3, 9, 34, 0.9);
      backdrop-filter: blur(8px);
      z-index: 2500;
      align-items: center;
      justify-content: center;
      padding: 20px;
      z-index: 99999;
    }

    .ts-modal.active {
      display: flex;
    }

    .ts-modal-content {
      background: rgba(6, 16, 48, 0.98);
      border: 1px solid rgba(100, 154, 255, 0.3);
      border-radius: 24px;
      padding: 32px;
      max-width: 600px;
      width: 100%;
      max-height: 80vh;
      overflow-y: auto;
      display: flex;
      flex-direction: column;
    }

    .ts-modal-header {
      margin-bottom: 24px;
      border-bottom: 1px solid rgba(100, 154, 255, 0.2);
      padding-bottom: 16px;
    }

    .ts-modal-header h2 {
      margin: 0;
      font-size: 1.5rem;
      color: var(--page-white);
    }

    .ts-modal-body {
      flex: 1;
      overflow-y: auto;
      margin-right: 8px; /* Added for scrollbar spacing */
      padding-right: 8px; /* Ensure content doesn't touch scrollbar */
    }

    .ts-modal-body::-webkit-scrollbar {
      width: 6px;
    }

    .ts-modal-body::-webkit-scrollbar-track {
      background: rgba(100, 154, 255, 0.1);
      border-radius: 3px;
    }

    .ts-modal-body::-webkit-scrollbar-thumb {
      background: rgba(77, 225, 193, 0.3);
      border-radius: 3px;
    }

    .ts-modal-body::-webkit-scrollbar-thumb:hover {
      background: rgba(77, 225, 193, 0.5);
    }

    .ts-modal-body h3 {
      color: var(--page-white);
      margin-top: 20px;
      margin-bottom: 12px;
      font-size: 1.1rem;
    }

    .ts-modal-body p {
      color: rgba(205, 219, 255, 0.8);
      line-height: 1.6;
      margin-bottom: 12px;
      font-size: 0.95rem;
    }

    .ts-modal-body ul {
      color: rgba(205, 219, 255, 0.8);
      line-height: 1.6;
      margin-bottom: 12px;
      margin-left: 20px;
      font-size: 0.95rem;
    }

    .ts-modal-body li {
      margin-bottom: 8px;
    }

    .ts-modal-footer {
      display: flex;
      gap: 12px;
      justify-content: flex-end;
      align-items: center;
      border-top: 1px solid rgba(100, 154, 255, 0.2);
      padding-top: 20px;
    }

    .ts-checkbox-container {
      display: flex;
      align-items: center;
      gap: 8px;
    }

    .ts-checkbox {
      width: 20px;
      height: 20px;
      cursor: pointer;
      accent-color: var(--page-mint);
    }

    .ts-checkbox-label {
      color: rgba(205, 219, 255, 0.8);
      font-size: 0.9rem;
      cursor: pointer;
    }

    .ts-modal-actions {
      display: flex;
      gap: 12px;
      justify-content: flex-end;
    }

    .ts-checkbox-wrapper {
      background: rgba(77, 225, 193, 0.08);
      border: 1px solid rgba(77, 225, 193, 0.3);
      border-radius: 12px;
      padding: 16px;
      margin-bottom: 24px;
      display: flex;
      align-items: center;
      gap: 12px;
    }

    .ts-checkbox-wrapper input[type="checkbox"]:disabled {
      opacity: 0.5;
      cursor: not-allowed;
    }

    .ts-checkbox-wrapper input[type="checkbox"]:disabled + label {
      opacity: 0.5;
      cursor: not-allowed;
    }
  </style>
</head>
<body>
  <?php include "embed.php"; ?>
  <?php include "doctype.php"; ?>
  <?php include "header2.php"; ?>
  
  <!-- CHANGE: Removed notification bell HTML -->

  <!-- CHANGE: Added Terms and Services Modal -->
  <div class="ts-modal" id="tsModal">
    <div class="ts-modal-content">
      <div class="ts-modal-header">
        <h2>Task Instructions</h2>
      </div>
      <div class="ts-modal-body">
        <p><strong>Earnova Digital â€“ 2025 Perform Tasks</strong></p>


        <h3>1. Introduction</h3>
        <p>Welcome to our Task Platform. By using our services, you agree to comply with and be bound by these Terms and Services. If you do not agree with any part of these terms, please do not use our platform.</p>

        <h3>2. User Responsibilities</h3>
        <p>As a user, you are responsible for:</p>
        <ul>
          <li>Providing accurate and truthful information</li>
          <li>Completing tasks honestly and thoroughly</li>
          <li>Not using fake profiles or misleading information</li>
          <li>Not engaging in fraudulent or deceptive practices</li>
          <li>Maintaining the confidentiality of your account credentials</li>
        </ul>

        <h3>3. Task Completion Requirements</h3>
        <p>When completing tasks:</p>
        <ul>
          <li>You must follow all task instructions precisely</li>
          <li>You must use your genuine profile or account</li>
          <li>Profile links and information must be valid and not duplicated</li>
          <li>Any violation may result in rejection and account suspension</li>
        </ul>

        <h3>4. Verification and Approval</h3>
        <p>All submitted tasks are subject to verification. We reserve the right to:</p>
        <ul>
          <li>Review and verify all task submissions</li>
          <li>Reject submissions that don't meet requirements</li>
          <li>Flag suspicious activity for investigation</li>
          <li>Withhold or reverse earnings for fraudulent submissions</li>
        </ul>

        <h3>5. Prohibited Activities</h3>
        <p>You agree not to:</p>
        <ul>
          <li>Use duplicate or fake accounts</li>
          <li>Submit false profile links or information</li>
          <li>Use bots or automated tools to complete tasks</li>
          <li>Engage in collusion with other users</li>
          <li>Attempt to exploit platform vulnerabilities</li>
          <li>Use abusive, harassing, or offensive language</li>
        </ul>

        <h3>6. Earnings and Payments</h3>
        <p>Your earnings are calculated based on:</p>
        <ul>
          <li>Successfully completed and verified tasks</li>
          <li>Your membership tier</li>
          <li>Platform-specific reward rates</li>
        </ul>
        <p>We reserve the right to modify payment terms and rates at any time with notice.</p>

        <h3>7. Account Suspension and Termination</h3>
        <p>We may suspend or terminate your account if you:</p>
        <ul>
          <li>Violate these terms and conditions</li>
          <li>Engage in fraudulent activity</li>
          <li>Submit false or misleading information</li>
          <li>Violate platform policies</li>
        </ul>

        <h3>8. Liability Disclaimer</h3>
        <p>The platform is provided "as is" without warranties. We are not liable for:</p>
        <ul>
          <li>Lost earnings due to task rejection</li>
          <li>Technical issues or platform downtime</li>
          <li>Actions of third parties or external platforms</li>
        </ul>

        <h3>9. Changes to Terms</h3>
        <p>We reserve the right to modify these terms at any time. Your continued use of the platform constitutes acceptance of any changes.</p>

        <h3>10. Contact Information</h3>
        <p>For questions or concerns, please contact our support team through the help section of your account.</p>
      </div>
      <div class="ts-modal-footer">
        <!-- <button class="btn-secondary" id="tsCloseBtn" onclick="closeTSModal()">Close</button> -->
        <div class="ts-checkbox-wrapper" style="margin-bottom: 0;">
          <input type="checkbox" id="tsCheckbox" class="ts-checkbox" <?php echo $ts_agreed ? 'checked disabled' : ''; ?>>
          <label for="tsCheckbox" class="ts-checkbox-label"><span style="font-size: 13px;">I agree</label>
        </div>
        <div class="ts-modal-actions">
          <button class="btn-secondary" id="tsCloseBtn" onclick="closeTSModal()" style="<?php echo $ts_agreed ? 'display: block;' : 'display: none;'; ?>">Close</button>
          <button class="btn-primary" id="tsAgreeBtn" onclick="agreeTSAndClose()" style="<?php echo $ts_agreed ? 'display: none;' : 'display: block;'; ?>">Agree & Continue</button>
        </div>
      </div>
    </div>
  </div>

  <!-- Verification Modal -->
  <div class="verification-modal" id="verificationModal">
    <div class="verification-content">
      <!-- Step 1: Submit Profile Link/Email/Phone -->
      <div class="verification-step active" id="step1">
        <!-- Updated modal text and styling for WhatsApp phone verification -->
        <h2 id="verificationTitle" style="font-size: 1rem;">Submit Profile Link</h2>
        <p id="verificationDescription" style="font-size: 0.8rem;">Provide a link to your profile or username.</p>
        
        <!-- Countdown timer -->
        <div id="countdownTimer" style="text-align: center; padding: 40px 20px;">
          <div style="width: 80px; height: 80px; border: 4px solid rgba(77, 225, 193, 0.3); border-top-color: var(--page-mint); border-radius: 50%; animation: spin 1s linear infinite; margin: 0 auto 24px;"></div>
          <h3 style="color: var(--page-mint); margin-bottom: 12px; font-size: 0.9rem">Validating Task...</h3>
          <p style="color: rgba(255, 235, 59, 0.7); font-size: 0.8rem; font-weight: 600;">The system is currently verifying your task. Please ensure you have fully completed it while waiting to submit your proof of completion for approval.</p>
          <p style="color: rgba(205, 219, 255, 0.7); font-size: 0.7rem; font-weight: 600;" id="countdownText">30</p>
          <p style="color: rgba(205, 219, 255, 0.5); font-size: 0.7rem;">seconds remaining</p>
        </div>
        
        <div id="profileLinkForm" style="display: none;">
          <!-- Updated input field for WhatsApp phone numbers with +234 prefix display -->
          <div id="inputWrapper" style="position: relative; margin-bottom: 24px;">
            <div id="phonePrefix" style="display: none; position: absolute; left: 16px; top: 40%; transform: translateY(-40%); color: rgba(205, 219, 255, 0.7); font-weight: 600; font-size: 0.7rem; pointer-events: none;">+234</div>
            <input type="text" class="form-input" id="profileLink" placeholder="https://platform.com/your-profile" onkeyup="validateProfileLink()" style="padding-left: 16px;">
          </div>
          
          <!-- Updated warning text -->
          <small id="warningText" style="color: rgba(205, 219, 255, 0.6); display: block; margin-top: -16px; margin-bottom: 24px;">
            Invalid profile links/emails/numbers are counted as cheating.
          </small>
          
          <div class="verification-actions">
            <button class="btn-secondary" onclick="cancelVerification()">Cancel</button>
            <button class="btn-primary" id="step1Next" onclick="submitVerification()" disabled>Submit</button>
          </div>
        </div>
      </div>

      <!-- Step 2: Processing -->
      <div class="verification-step" id="step2">
        <h2>Processing...</h2>
        <div style="text-align: center; padding: 40px 20px;">
          <div style="width: 64px; height: 64px; border: 4px solid rgba(77, 225, 193, 0.3); border-top-color: var(--page-mint); border-radius: 50%; animation: spin 1s linear infinite; margin: 0 auto 24px;"></div>
          <p style="color: rgba(205, 219, 255, 0.7);">Verifying your submission...</p>
        </div>
      </div>

      <!-- Step 3: Success -->
      <div class="verification-step" id="step3">
        <h2 style="font-size: 1rem">Task Completed!</h2>
        <div style="text-align: center; padding: 40px 20px;">
          <svg viewBox="0 0 24 24" width="80" height="80" fill="var(--page-mint)" style="margin-bottom: 24px;">
            <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/>
          </svg>
          <h3 style="margin: 0 0 12px; color: var(--page-mint);">Congratulations!</h3>
          <p style="color: rgba(205, 219, 255, 0.7); margin-bottom: 24px;">Your task has been approved and ₦<span id="rewardAmount"></span> has been credited to your balance.</p>
        </div>
        <div class="verification-actions">
          <button class="btn-primary" onclick="closeVerification()" style="width: 100%;">Continue</button>
        </div>
      </div>
    </div>
  </div>

  <!-- CHANGE: Added cooldown modal HTML -->
  <!-- This modal is no longer used directly, cooldown is handled by overlays on tasks -->
  <!-- <div class="cooldown-modal" id="cooldownModal">
    <div class="cooldown-content">
      <svg viewBox="0 0 24 24" width="80" height="80" fill="#ffc107" style="margin-bottom: 24px;">
        <path d="M12 2C6.5 2 2 6.5 2 12s4.5 10 10 10 10-4.5 10-10S17.5 2 12 2zm0 18c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8zm.5-13H11v6l5.2 3.2.8-1.3-4.5-2.7V7z"/>
      </svg>
      <h2>Please Wait</h2>
      <p>You need to wait before starting another task</p>
      <div class="cooldown-timer" id="cooldownTimer">5:00</div>
      <button class="btn-primary" onclick="closeCooldown()" style="width: 100%;">OK</button>
    </div>
  </div> -->

  <div class="page-shell">
   
   
    
    <main>
      <section class="hero-section" style="background: linear-gradient(135deg, rgba(77, 225, 193, 0.08), rgba(13, 24, 62, 0.78));">
        <div class="hero-content">
          <h1 style="font-size: 17px; color: #fff;">Perform Tasks <?php if (in_array($user_data['membership_type'], ['premium', 'senior'])): ?>
        <div class="stat-item" style="background: transparent; padding: 12px; border-radius: 12px; margin-top: 12px;">
          <span style="color: var(--page-mint); font-weight: 600;"> Member Bonus</span>
          <strong style="color: var(--page-mint);">+20% Earnings</strong>
        </div>
        <?php endif; ?>
      <div class="stat-item">
          <span>Activity Balance</span>
          <strong>₦
 <?php echo number_format($user_data['task_earnings'], 2); ?></strong>
        </div>
        
        <!-- Total available tasks now shows fake count for free users -->
        <div class="stat-item" style="background: linear-gradient(135deg, rgba(77, 225, 193, 0.2), rgba(44, 92, 245, 0.2)); border: 1px solid rgba(77, 225, 193, 0.4); padding: 12px 20px; border-radius: 12px; margin-top: 12px; display: flex; align-items: center; justify-content: space-between; gap: 12px;">
          <div style="display: flex; align-items: center; gap: 8px;">
            <svg viewBox="0 0 24 24" width="20" height="20" fill="var(--page-mint)">
              <path d="M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm-5 14H7v-2h7v2zm3-4H7v-2h10v2zm0-4H7V7h10v2z"/>
            </svg>
            <span style="color: rgba(205, 219, 255, 0.9); font-weight: 600;">Total Available Tasks</span>
          </div>
          <strong style="color: var(--page-mint); font-size: 1.3rem; font-weight: 700;"><?php echo number_format($total_active_tasks); ?></strong>
        </div>

        <!-- Added visible checkbox in hero section to open verification modal -->
        <div style="background: rgba(77, 225, 193, 0.08); border: 1px solid rgba(77, 225, 193, 0.3); border-radius: 12px; padding: 16px; margin-top: 12px; display: flex; align-items: center; gap: 12px; cursor: pointer;" onclick="openHeroCheckboxModal()">
          <input type="checkbox" id="heroCheckbox" style="width: 20px; height: 20px; cursor: pointer; accent-color: var(--page-mint);" onclick="event.stopPropagation(); openHeroCheckboxModal();">
          <label for="heroCheckbox" style="color: rgba(205, 219, 255, 0.8); font-size: 0.9rem; cursor: pointer; margin: 0;">View Task Details & Instructions</label>
        </div>
        
        </h1>
          <p>Choose a task, complete it, and earn rewards instantly. All tasks are verified before payment.</p>
        </div>
        <div style="display: flex; gap: 12px; align-items: center; flex-wrap: wrap;">
          <!-- Disable platform filter for free users -->
          <select id="platformFilter" onchange="filterTasks()" <?php echo $user_data['membership_type'] === 'free' ? 'disabled' : ''; ?> style="padding: 10px 16px; border-radius: 12px; border: 1px solid rgba(100, 154, 255, 0.3); background: rgba(8, 21, 64, 0.6); color: var(--page-white); font-size: 0.85rem; font-weight: 600; cursor: <?php echo $user_data['membership_type'] === 'free' ? 'not-allowed' : 'pointer'; ?>; opacity: <?php echo $user_data['membership_type'] === 'free' ? '0.5' : '1'; ?>;">
            <option value="all"><?php echo $user_data['membership_type'] === 'free' ? 'Activate Account to Filter' : 'All Platforms'; ?></option>
            <?php if ($user_data['membership_type'] !== 'free'): ?>
            <option value="tiktok">TikTok</option>
            <option value="instagram">Instagram</option>
            <option value="twitter">Twitter</option>
            <option value="facebook">Facebook</option>
            <option value="youtube">YouTube</option>
            <option value="linkedin">LinkedIn</option>
            <option value="telegram">Telegram</option>
            <option value="whatsapp">WhatsApp</option>
            <option value="snapchat">Snapchat</option>
            <option value="pinterest">Pinterest</option>
            <option value="reddit">Reddit</option>
            <option value="discord">Discord</option>
            <option value="twitch">Twitch</option>
            <option value="playstore">PlayStore</option>
            <option value="appstore">AppStore</option>
            <option value="audiomack">Audiomack</option>
            <option value="boomplay">Boomplay</option>
            <option value="spotify">Spotify</option>
            <option value="applemusic">Apple Music</option>
            <option value="soundcloud">SoundCloud</option>
            <?php endif; ?>
          </select>
          
          <div class="view-toggle">
            <button class="active" onclick="switchView('box')">
              <svg viewBox="0 0 24 24" width="16" height="16" fill="currentColor" style="vertical-align: middle; margin-right: 4px;">
                <path d="M4 11h6V5H4v6zm0 8h6v-6H4v6zm8 0h6v-6h-6v6zm0-16v6h6V5h-6z"/>
              </svg>
              Box
            </button>
            <button onclick="switchView('list')">
              <svg viewBox="0 0 24 24" width="16" height="16" fill="currentColor" style="vertical-align: middle; margin-right: 4px;">
                <path d="M3 13h2v-2H3v2zm0 4h2v-2H3v2zm0-8h2V7H3v2zm4 4h14v-2H7v2zm0 4h14v-2H7v2zM7 7v2h14V7H7z"/>
              </svg>
              List
            </button>
          </div>
        </div>
      </section>

      <!-- Box View -->
      <section class="tasks-grid" id="boxView">
          

          
          
          
        <?php if (empty($available_tasks) && empty($pinned_tasks)): ?>
          <div style="grid-column: 1 / -1; text-align: center; padding: 48px 24px;">
            <svg viewBox="0 0 24 24" width="80" height="80" fill="rgba(77, 225, 193, 0.3)">
              <path d="M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm-5 14H7v-2h7v2zm3-4H7v-2h10v2zm0-4H7V7h10v2z"/>
            </svg>
            <h2>No Tasks Available</h2>
            <p>Check back soon for new tasks!</p>
          </div>
        <?php else: ?>
          <?php foreach ($available_tasks as $task): 
            $platform = detectTaskPlatform($task['title'], $task['description'], $task['task_type'], $task['platform'] ?? null);
            $earning = getTaskReward($task, $user_data);
            $platformColor = getPlatformColor($platform);
            $isCompulsory = in_array($task['id'], array_column($pinned_tasks, 'id'));
          ?>
            <article class="task-card <?php echo $isCompulsory ? 'compulsory' : ''; ?> <?php echo $task['in_progress'] > 0 ? 'in-progress' : ''; ?>" data-platform="<?php echo $platform; ?>" style="background: linear-gradient(135deg, rgba(77, 225, 193, 0.08), rgba(13, 24, 62, 0.78));">
              <div class="task-header">
                <div class="platform-icon" data-platform="<?php echo $platform; ?>" style="background: <?php echo $platformColor; ?>15; border-color: <?php echo $platformColor; ?>40;">
                  <div style="color: <?php echo $platformColor; ?>;">
                    <?php echo getPlatformSVG($platform); ?>
                  </div>
                </div>
                <div class="task-status">
                  <span class="status-badge active">₦<?php echo number_format($earning, 2); ?></span>
                </div>
              </div>
              
              <h3 class="task-title"><?php echo htmlspecialchars($task['title']); ?></h3>
              <p class="task-description"><?php echo htmlspecialchars(substr($task['description'], 0, 100)) . (strlen($task['description']) > 100 ? '...' : ''); ?></p>
              
              <div class="task-actions">
                <?php if ($task['in_progress'] > 0): ?>
                  <button class="btn-action btn-pause" disabled>In Progress</button>
                <?php else: ?>
                  <button class="btn-action btn-resume" data-platform="<?php echo $platform; ?>" style="background: <?php echo $platformColor; ?>; <?php echo $platform === 'snapchat' ? 'color: #000;' : ''; ?> width: 170px;" onclick="startTask(<?php echo $task['id']; ?>, '<?php echo htmlspecialchars($task['task_url']); ?>', '<?php echo $platform; ?>')">Start Task</button>
                <?php endif; ?>
              </div>
              
              <div class="task-meta">
                <span>Platform: <?php echo ucfirst($platform); ?></span>
              </div>
            </article>
          <?php endforeach; ?>
        <?php endif; ?>
      </section>

      <!-- List View -->
      <section class="tasks-list-view" id="listView">
    

        <?php if (!empty($available_tasks) || !empty($pinned_tasks)): ?>
          <h3 style="color: var(--page-white); margin-bottom: 16px;">Available Tasks</h3>
          
               <!-- Added compulsory tasks to list view -->
        <?php if (!empty($pinned_tasks)): ?>
          <div style="margin-bottom: 1px;">
           
            <?php foreach ($pinned_tasks as $task): 
              $platform = detectTaskPlatform($task['title'], $task['description'], $task['task_type'], $task['platform'] ?? null);
              $earning = getTaskReward($task, $user_data);
              $platformColor = getPlatformColor($platform);
            ?>
              <div class="task-list-item compulsory" data-platform="<?php echo $platform; ?>">
                <div class="task-list-icon" style="background: <?php echo $platformColor; ?>15; border-color: <?php echo $platformColor; ?>40;">
                  <div style="color: <?php echo $platformColor; ?>;">
                    <?php echo getPlatformSVG($platform); ?>
                  </div>
                </div>
                <div class="task-list-info">
                  <h3><?php echo htmlspecialchars($task['title']); ?></h3>
                  <p><?php echo htmlspecialchars(substr($task['description'], 0, 150)) . (strlen($task['description']) > 150 ? '...' : ''); ?></p>
                </div>
                <div class="task-list-action">
                  <div class="task-reward">₦<?php echo number_format($earning, 2); ?></div>
                  <?php if ($task['in_progress'] > 0): ?>
                    <button class="btn-action btn-pause" disabled>In Progress</button>
                  <?php else: ?>
                    <button class="btn-action btn-resume" data-platform="<?php echo $platform; ?>" style="background: <?php echo $platformColor; ?>; <?php echo $platform === 'snapchat' ? 'color: #000;' : ''; ?> width: 170px;" onclick="startTask(<?php echo $task['id']; ?>, '<?php echo htmlspecialchars($task['task_url']); ?>', '<?php echo $platform; ?>')">Start Task</button>
                  <?php endif; ?>
                </div>
              </div>
            <?php endforeach; ?>
          </div>
        <?php endif; ?>
        
          <?php foreach ($available_tasks as $task): 
            $platform = detectTaskPlatform($task['title'], $task['description'], $task['task_type'], $task['platform'] ?? null);
            $earning = getTaskReward($task, $user_data);
            $platformColor = getPlatformColor($platform);
            $isCompulsory = in_array($task['id'], array_column($pinned_tasks, 'id'));
          ?>
            <div class="task-list-item <?php echo $isCompulsory ? 'compulsory' : ''; ?>" data-platform="<?php echo $platform; ?>">
              <div class="task-list-icon" style="background: <?php echo $platformColor; ?>15; border-color: <?php echo $platformColor; ?>40;">
                <div style="color: <?php echo $platformColor; ?>;">
                  <?php echo getPlatformSVG($platform); ?>
                </div>
              </div>
              <div class="task-list-info">
                <h3><?php echo htmlspecialchars($task['title']); ?></h3>
                <p><?php echo htmlspecialchars(substr($task['description'], 0, 150)) . (strlen($task['description']) > 150 ? '...' : ''); ?></p>
              </div>
              <div class="task-list-action">
                <div class="task-reward">₦<?php echo number_format($earning, 2); ?></div>
                <?php if ($task['in_progress'] > 0): ?>
                  <button class="btn-action btn-pause" disabled>In Progress</button>
                <?php else: ?>
                  <button class="btn-action btn-resume" data-platform="<?php echo $platform; ?>" style="background: <?php echo $platformColor; ?>; <?php echo $platform === 'snapchat' ? 'color: #000;' : ''; ?> width: 170px;" onclick="startTask(<?php echo $task['id']; ?>, '<?php echo htmlspecialchars($task['task_url']); ?>', '<?php echo $platform; ?>')">Start Task</button>
                <?php endif; ?>
              </div>
            </div>
          <?php endforeach; ?>
        <?php else: ?>
          <div style="grid-column: 1 / -1; text-align: center; padding: 48px 24px;">
            <svg viewBox="0 0 24 24" width="80" height="80" fill="rgba(77, 225, 193, 0.3)">
              <path d="M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm-5 14H7v-2h7v2zm3-4H7v-2h10v2zm0-4H7V7h10v2z"/>
            </svg>
            <h2>No Tasks Available</h2>
            <p>Check back soon for new tasks!</p>
          </div>
        <?php endif; ?>
      </section>
    </main>
  </div>

  <nav class="mobile-fintech-footer">
    
  <a href="dashboard.php">
    <svg viewBox="0 0 24 24"><path d="M12 3a9 9 0 1 1 0 18 9 9 0 0 1 0-18Zm1 4h-2v6h6v-2h-4V7Z"/></svg>
    <span>Dashboard</span>
  </a>

  <!-- Premium (crown icon) -->
  <a href="membership.php">
    <svg viewBox="0 0 24 24"><path d="M5 7l2.5 5 4.5-4 4.5 4L19 7l2 13H3l2-13Z"/></svg>
    <span>Premium</span>
  </a>

  <a href="post-task.php">
<svg viewBox="0 0 24 24" aria-hidden="true">
  <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8l-6-6Zm1 14h-3v3h-2v-3H7v-2h3v-3h2v3h3v2Zm-3-9V3.5L18.5 8H12Z"/>
</svg>
    
    <span>Advert Post</span>
  </a>
  
  

  <a href="history.php">
  <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
    <path d="M13 3a9 9 0 1 0 9 9h-2a7 7 0 1 1-7-7V3l4 4-4 4V7a5 5 0 1 0 5 5h2a7 7 0 1 1-7-7z"/>
  </svg>
  <span>History</span>
</a>


  <a href="profile.php">
    <svg viewBox="0 0 24 24"><path d="M12 2a6 6 0 0 1 6 6c0 3.31-2.69 6-6 6s-6-2.69-6-6a6 6 0 0 1 6-6Zm0 14c4.42 0 8 1.79 8 4v2H4v-2c0-2.21 3.58-4 8-4Z"/></svg>
    <span>Profile</span>
  </a>
</nav>


  <script>
    let currentTaskId = null;
    let currentUserTaskId = null;
    let taskStartTime = null;
    let taskWindow = null;
    let preventRefresh = false;
    let countdownInterval = null;
    let cooldownUpdateInterval = null; // Added interval for updating all cooldowns
    let currentPlatform = null;
    
    // Terms and Services Modal Functions
    document.addEventListener('DOMContentLoaded', function() {
      const tsCheckbox = document.getElementById('tsCheckbox');
      if (tsCheckbox) {
        tsCheckbox.disabled = false;
      }
    });
    
    
    // CHANGE: New function to randomize task cards (except pinned/compulsory tasks)
        function randomizeTaskCards() {
            // Get all task cards from both grid view
            const boxViewCards = Array.from(document.querySelectorAll('#boxView > .task-card:not(.compulsory)'));
            
            // Get all task list items from list view
            const listViewItems = Array.from(document.querySelectorAll('#listView .task-list-item:not(.compulsory)'));
            
            // Shuffle function using Fisher-Yates algorithm
            function shuffleArray(array) {
                const shuffled = [...array];
                for (let i = shuffled.length - 1; i > 0; i--) {
                    const j = Math.floor(Math.random() * (i + 1));
                    [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
                }
                return shuffled;
            }
            
            // Randomize box view cards (grid layout)
            const randomizedBoxCards = shuffleArray(boxViewCards);
            randomizedBoxCards.forEach(card => {
                document.querySelector('#boxView').appendChild(card);
            });
            
            // Randomize list view items 
            const randomizedListItems = shuffleArray(listViewItems);
            randomizedListItems.forEach(item => {
                // Find the correct container (after pinned tasks if they exist)
                const listView = document.getElementById('listView');
                const pinnedSection = listView.querySelector('div[style*="margin-bottom: 1px"]');
                if (pinnedSection && pinnedSection.nextSibling) {
                    listView.insertBefore(item, pinnedSection.nextSibling);
                } else {
                    listView.appendChild(item);
                }
            });
            
            console.log("Tasks randomized on page load - pinned tasks remain in position");
        }

    function openTSModal() {
      const modal = document.getElementById('tsModal');
      if (modal) {
        modal.classList.add('active');
      }
    }

    function closeTSModal() {
      const modal = document.getElementById('tsModal');
      if (modal) {
        modal.classList.remove('active');
      }
      // Ensure checkbox is checked and buttons are reset if modal is closed without agreeing
      const tsCheckbox = document.getElementById('tsCheckbox');
      const tsAgreeBtn = document.getElementById('tsAgreeBtn');
      const tsCloseBtn = document.getElementById('tsCloseBtn');

      if (tsCheckbox && !tsCheckbox.disabled) { // Only reset if not permanently agreed
        tsCheckbox.checked = false;
        if(tsAgreeBtn) tsAgreeBtn.style.display = 'block';
        if(tsCloseBtn) tsCloseBtn.style.display = 'none';
      }
    }

    function agreeTSAndClose() {
      // Set checkbox as checked
      const tsCheckbox = document.getElementById('tsCheckbox');
      if(tsCheckbox) tsCheckbox.checked = true;
      
      // Disable checkbox and buttons after agreeing
      if(tsCheckbox) tsCheckbox.disabled = true;
      const tsAgreeBtn = document.getElementById('tsAgreeBtn');
      const tsCloseBtn = document.getElementById('tsCloseBtn');
      if(tsAgreeBtn) tsAgreeBtn.style.display = 'none';
      if(tsCloseBtn) tsCloseBtn.style.display = 'block';
      
      // Send AJAX request to store agreement in session
      fetch('perform-task.php', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: 'ajax=1&action=agree_terms'
      })
      .then(response => response.json())
      .then(data => {
        if (data.success) {
          // Close modal and show success
          closeTSModal();
          showToast('Task instructions accepted!', 'success');
        } else {
          // Re-enable buttons if AJAX fails
          if(tsCheckbox) tsCheckbox.disabled = false; // Re-enable checkbox
          if(tsCheckbox) tsCheckbox.checked = false; // Reset checkbox
          if(tsAgreeBtn) tsAgreeBtn.style.display = 'block';
          if(tsCloseBtn) tsCloseBtn.style.display = 'none';
          showToast('Failed to save agreement. Please try again.', 'error');
        }
      })
      .catch(error => {
        console.error('Error agreeing to T&S:', error);
        // Re-enable buttons if AJAX fails
        if(tsCheckbox) tsCheckbox.disabled = false; // Re-enable checkbox
        if(tsCheckbox) tsCheckbox.checked = false; // Reset checkbox
        if(tsAgreeBtn) tsAgreeBtn.style.display = 'block';
        if(tsCloseBtn) tsCloseBtn.style.display = 'none';
        showToast('Failed to save agreement. Please try again.', 'error');
      });
    }


    function showToast(message, type = 'info') {
      const toast = document.createElement('div');
      toast.className = `alert-message alert-${type}`;
      toast.textContent = message;
      document.body.appendChild(toast);

      setTimeout(() => {
        toast.classList.add('show');
      }, 50);

      setTimeout(() => {
        toast.classList.remove('show');
        setTimeout(() => toast.remove(), 600);
      }, 4000);
    }

    function checkTaskCooldown(taskId) {
      const cooldownEnd = localStorage.getItem(`taskCooldown_${taskId}`);
      if (cooldownEnd) {
        const now = Date.now();
        const endTime = parseInt(cooldownEnd);
        if (now < endTime) {
          return endTime - now; // Return remaining milliseconds
        } else {
          localStorage.removeItem(`taskCooldown_${taskId}`);
        }
      }
      return 0;
    }

    function startTaskCooldown(taskId) {
      const endTime = Date.now() + (5 * 60 * 1000); // 5 minutes from now
      localStorage.setItem(`taskCooldown_${taskId}`, endTime.toString());
    }

    function formatTimeRemaining(ms) {
      const minutes = Math.floor(ms / 60000);
      const seconds = Math.floor((ms % 60000) / 1000);
      return `${minutes}:${seconds.toString().padStart(2, '0')}`;
    }

    function updateAllCooldowns() {
      const allTaskCards = document.querySelectorAll('.task-card, .task-list-item');
      
      allTaskCards.forEach(card => {
        const startButton = card.querySelector('.btn-action');
        if (!startButton || startButton.disabled) return;
        
        const onclickAttr = startButton.getAttribute('onclick');
        if (!onclickAttr) return;
        
        const taskIdMatch = onclickAttr.match(/startTask\((\d+)/);
        if (!taskIdMatch) return;
        
        const taskId = taskIdMatch[1];
        const remainingMs = checkTaskCooldown(taskId);
        
        let cooldownOverlay = card.querySelector('.task-cooldown');
        
        if (remainingMs > 0) {
          // Show or update cooldown overlay
          if (!cooldownOverlay) {
            cooldownOverlay = document.createElement('div');
            cooldownOverlay.className = 'task-cooldown';
            cooldownOverlay.innerHTML = `
              <svg viewBox="0 0 24 24" fill="currentColor">
                <path d="M12 2C6.5 2 2 6.5 2 12s4.5 10 10 10 10-4.5 10-10S17.5 2 12 2zm0 18c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8zm.5-13H11v6l5.2 3.2.8-1.3-4.5-2.7V7z"/>
              </svg>
              <div class="task-cooldown-time"></div>
              <div class="task-cooldown-text">Try again later</div>
            `;
            card.style.position = 'relative'; // Ensure card has positioning context
            card.appendChild(cooldownOverlay);
          }
          
          const timeElement = cooldownOverlay.querySelector('.task-cooldown-time');
          if (timeElement) timeElement.textContent = formatTimeRemaining(remainingMs);
        } else if (cooldownOverlay) {
          // Remove cooldown overlay
          cooldownOverlay.remove();
        }
      });
    }

    document.addEventListener('DOMContentLoaded', () => {
      // Ensure TS modal is checked if user already agreed
      const tsCheckbox = document.getElementById('tsCheckbox');
      if (tsCheckbox) { // Check if the element exists
        <?php if ($ts_agreed): ?>
          tsCheckbox.checked = true;
          tsCheckbox.disabled = true;
          document.getElementById('tsAgreeBtn').style.display = 'none';
          document.getElementById('tsCloseBtn').style.display = 'block';
        <?php else: ?>
          // If not agreed, open the modal on first load for new users
          setTimeout(openTSModal, 500); // Delay slightly to ensure UI is ready
        <?php endif; ?>
      }
      
      // CHANGE: Randomize non-pinned tasks on page load - desktop and mobile
           randomizeTaskCards();

      updateAllCooldowns();
      cooldownUpdateInterval = setInterval(updateAllCooldowns, 1000);
      
      
    });
    
    

    // Filter tasks by platform
    function filterTasks() {
      const selectedPlatform = document.getElementById('platformFilter').value;
      const allTasks = document.querySelectorAll('.task-card, .task-list-item');
      
      allTasks.forEach(task => {
        if (selectedPlatform === '' || selectedPlatform === 'all') { // 'all' is for the default option value
          task.style.display = '';
        } else {
          const taskPlatform = task.getAttribute('data-platform');
          if (taskPlatform === selectedPlatform) {
            task.style.display = '';
          } else {
            task.style.display = 'none';
          }
        }
      });
    }

    // Switch between box and list view
    function switchView(view) {
      const boxView = document.getElementById('boxView');
      const listView = document.getElementById('listView');
      const buttons = document.querySelectorAll('.view-toggle button');
      
      buttons.forEach(btn => btn.classList.remove('active'));
      
      if (view === 'box') {
        boxView.style.display = 'grid';
        listView.classList.remove('active');
        buttons[0].classList.add('active');
      } else {
        boxView.style.display = 'none';
        listView.classList.add('active');
        buttons[1].classList.add('active');
      }
    }

    function startTask(taskId, taskUrl, platform) { 
      const tsCheckbox = document.getElementById('tsCheckbox');
      if (!tsCheckbox || !tsCheckbox.checked) {
        showToast('Please agree to the Task Instructions before starting a task.', 'warning');
        // Highlight the checkbox
        if(tsCheckbox) tsCheckbox.focus();
        // Highlight the parent container for better visibility
        const tsCheckboxWrapper = tsCheckbox ? tsCheckbox.closest('.ts-checkbox-wrapper') : null;
        if (tsCheckboxWrapper) {
          tsCheckboxWrapper.style.borderColor = 'rgba(255, 107, 107, 0.7)';
          setTimeout(() => {
            tsCheckboxWrapper.style.borderColor = 'rgba(77, 225, 193, 0.3)';
          }, 3000);
        }
        return;
      }

      <?php if ($user_data['membership_type'] === 'free'): ?>
        // Show premium popup for free users
        showPremiumPopup();
        return;
      <?php endif; ?>
      
      const remainingCooldown = checkTaskCooldown(taskId);
      if (remainingCooldown > 0) {
        const minutes = Math.floor(remainingCooldown / 60000);
        const seconds = Math.floor((remainingCooldown % 60000) / 1000);
        showToast(`Please wait ${minutes}:${seconds.toString().padStart(2, '0')} before starting this task again`, 'warning');
        return;
      }

      if (preventRefresh) {
        showToast('You already have a task in progress.', 'error');
        return;
      }

      currentTaskId = taskId;
      currentPlatform = platform; // This might be redundant if platform is passed from HTML
     

      // Make AJAX request to start task
      fetch('perform-task.php', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: `ajax=1&action=start_task&task_id=${taskId}`
      })
      .then(response => {
        const contentType = response.headers.get('content-type');
        if (!contentType || !contentType.includes('application/json')) {
          throw new Error('Server returned an error. Please try again.');
        }
        return response.json();
      })
      .then(data => {
        if (data.success) {
          currentUserTaskId = data.user_task_id;
          taskStartTime = data.start_time;
          
          taskWindow = window.open(taskUrl, '_blank');
          
        //   showToast('Task has started! Complete the task and wait for the form.', 'success');
          
          setTimeout(() => {
            document.getElementById('verificationModal').classList.add('active');
            updateVerificationModal(platform); // Use the platform passed to startTask
            startCountdown();
          }, 4000); // Show verification form after 4 seconds
        } else {
          showToast(data.message, 'error');
          preventRefresh = false;
          window.onbeforeunload = null;
          if (data.show_premium_popup) {
            showPremiumPopup();
          }
        }
      })
      .catch(error => {
        console.error('Error starting task:', error);
        showToast('An error occured', 'error');
        preventRefresh = false;
        window.onbeforeunload = null;
      });
    }

    // CHANGE: Update verification placeholder function to support email verification for specific platforms
    function updateVerificationModal(platform) {
      const title = document.getElementById('verificationTitle');
      const description = document.getElementById('verificationDescription');
      const warningText = document.getElementById('warningText');
      const phonePrefix = document.getElementById('phonePrefix');
      const profileLink = document.getElementById('profileLink');
      
      // Define platforms that require email verification
      const emailVerificationPlatforms = ['playstore', 'appstore', 'audiomack', 'boomplay', 'spotify', 'soundcloud', 'pinterest', 'website'];
      
      if (platform === 'whatsapp' || platform === 'telegram') {
        const platformName = platform.charAt(0).toUpperCase() + platform.slice(1);
        title.textContent = 'Submit your ' + platformName + ' Number';
        description.textContent = 'Please enter your valid ' + platformName + ' number.';
        warningText.textContent = 'Invalid numbers will be flagged as cheating.';
        phonePrefix.style.display = 'block';
        profileLink.placeholder = 'Enter 10-digit number';
        profileLink.style.paddingLeft = '60px';
        profileLink.type = 'text';
      } else if (emailVerificationPlatforms.includes(platform)) {
        // Email verification for specific platforms
        const platformName = platform.charAt(0).toUpperCase() + platform.slice(1);
        if (platform === 'playstore') {
          title.textContent = 'Submit your Google Email';
          description.textContent = 'Enter the email address linked to your Google Play Store account.';
        } else if (platform === 'appstore') {
          title.textContent = 'Submit your Apple Email';
          description.textContent = 'Enter the email address linked to your Apple ID/App Store account.';
        } else {
          title.textContent = 'Submit your Email Address';
          description.textContent = 'Enter the email address you use on ' + platformName + '.';
        }
        warningText.textContent = 'Invalid or unverified emails will be flagged as cheating.';
        phonePrefix.style.display = 'none';
        profileLink.placeholder = 'example@email.com';
        profileLink.style.paddingLeft = '16px';
        profileLink.type = 'email';
      } else {
        // Link verification for other platforms
        title.textContent = 'Submit Profile Link';
        description.textContent = 'Provide a link to your profile or username.';
        warningText.textContent = 'Invalid profile links are counted as cheating.';
        phonePrefix.style.display = 'none';
        profileLink.placeholder = 'https://platform.com/your-profile';
        profileLink.style.paddingLeft = '16px';
        profileLink.type = 'text';
      }
    }

     function startCountdown() {
      let seconds = 30;
      const countdownText = document.getElementById('countdownText');
      const countdownTimer = document.getElementById('countdownTimer');
      const profileLinkForm = document.getElementById('profileLinkForm');
      
      countdownInterval = setInterval(() => {
        seconds--;
        countdownText.textContent = seconds;
        
        if (seconds <= 0) {
          clearInterval(countdownInterval);
          countdownTimer.style.display = 'none';
          profileLinkForm.style.display = 'block';
        }
      }, 1000);
    }

    // CHANGE: Update validateProfileLink to support email validation
    function validateProfileLink() {
      const link = document.getElementById('profileLink').value;
      let isValid = false;
      
      // Define platforms that require email verification
      const emailVerificationPlatforms = ['playstore', 'appstore', 'audiomack', 'boomplay', 'spotify', 'soundcloud', 'pinterest', 'website'];
      
      if (currentPlatform === 'whatsapp' || currentPlatform === 'telegram') {
        // For WhatsApp/Telegram, accept 10+ digits for Nigerian numbers, optionally with country code
        isValid = /^\+?234\d{10,}$/.test(link.replace(/[\s\-()]/g, '')) || /^\d{10,}$/.test(link.replace(/[\s\-()]/g, ''));
      } else if (emailVerificationPlatforms.includes(currentPlatform)) {
        // For email verification platforms, validate email format
        const emailRegex = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
        isValid = emailRegex.test(link.trim());
      } else {
        // For other platforms, must be valid URL
        isValid = link.length > 0 && (link.startsWith('http://') || link.startsWith('https://'));
      }
      
      document.getElementById('step1Next').disabled = !isValid;
    }

    // CHANGE: Update submitVerification to handle email submissions
    function submitVerification() {
      let profileLink = document.getElementById('profileLink').value.trim();
      
      // Define platforms that require email verification
      const emailVerificationPlatforms = ['playstore', 'appstore', 'audiomack', 'boomplay', 'spotify', 'soundcloud', 'website'];
      
      if (!profileLink) {
        if (currentPlatform === 'whatsapp' || currentPlatform === 'telegram') {
          showToast('Please enter your phone number', 'error');
        } else if (emailVerificationPlatforms.includes(currentPlatform)) {
          showToast('Please enter your email address', 'error');
        } else {
          showToast('Please provide a profile link', 'error');
        }
        return;
      }

      // Ensure phone number starts with +234 if it's a Nigerian number
      if (currentPlatform === 'whatsapp' || currentPlatform === 'telegram') {
        const cleanNumber = profileLink.replace(/[\s\-()]/g, '');
        if (cleanNumber.startsWith('0')) {
          profileLink = '+234' + cleanNumber.substring(1);
        } else if (!cleanNumber.startsWith('+')) {
          profileLink = '+234' + cleanNumber;
        } else {
          profileLink = cleanNumber;
        }
      } else if (emailVerificationPlatforms.includes(currentPlatform)) {
        // Validate email format one more time before submission
        const emailRegex = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
        if (!emailRegex.test(profileLink)) {
          showToast('Please enter a valid email address', 'error');
          return;
        }
        profileLink = profileLink.toLowerCase();
      }

      // Show processing step
      nextStep(2);

      // Convert taskStartTime to seconds before sending
      const startTimeSeconds = Math.floor(taskStartTime);

      fetch('perform-task.php', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: `ajax=1&action=submit_verification&user_task_id=${currentUserTaskId}&start_time=${startTimeSeconds}&profile_link=${encodeURIComponent(profileLink)}`
      })
      .then(response => {
        const contentType = response.headers.get('content-type');
        if (!contentType || !contentType.includes('application/json')) {
          throw new Error('Server returned an error. Please try again.');
        }
        return response.json();
      })
      .then(data => {
        if (data.success) {
          if (data.approved) {
            // Show success step
            document.getElementById('rewardAmount').textContent = `${data.reward.toFixed(2)}`;
            nextStep(3);
          } else {
            startTaskCooldown(currentTaskId);
            updateAllCooldowns();
            showToast(data.message, 'info');
            closeVerification();
            location.reload(); // Reload page if verification fails but not a critical error
          }
        } else {
          startTaskCooldown(currentTaskId);
          updateAllCooldowns();
          showToast(data.message, 'error');
          nextStep(1);
          const countdownTimer = document.getElementById('countdownTimer');
          const profileLinkForm = document.getElementById('profileLinkForm');
          if (countdownTimer) countdownTimer.style.display = 'block';
          if (profileLinkForm) profileLinkForm.style.display = 'none';
          const countdownText = document.getElementById('countdownText');
          if (countdownText) countdownText.textContent = '30';
          if (countdownInterval) {
            clearInterval(countdownInterval);
            startCountdown();
          }
        }
      })
      .catch(error => {
        console.error('Error submitting verification:', error);
        startTaskCooldown(currentTaskId);
        updateAllCooldowns();
        showToast('Failed to submit verification. Please try again in 5 minutes.', 'error');
        nextStep(1);
        const countdownTimer = document.getElementById('countdownTimer');
        const profileLinkForm = document.getElementById('profileLinkForm');
        if (countdownTimer) countdownTimer.style.display = 'block';
        if (profileLinkForm) profileLinkForm.style.display = 'none';
        const countdownText = document.getElementById('countdownText');
        if (countdownText) countdownText.textContent = '30';
        if (countdownInterval) {
          clearInterval(countdownInterval);
          startCountdown();
        }
      });
    }

    function cancelVerification() {
      // Add a confirmation modal
      const confirmationModal = document.createElement('div');
      confirmationModal.className = 'verification-modal active'; // Reuse existing modal classes
      confirmationModal.innerHTML = `
        <div class="verification-content" style="max-width: 400px;">
          <h2 style="color: white;">Cancel Task?</h2>
          <p style="color:white">Are you sure you want to cancel? Your current task progress will be lost.</p>
          <div class="verification-actions">
            <button class="btn-secondary" onclick="this.closest('.verification-modal').remove()">No, Continue</button>
            <button class="btn-primary" onclick="confirmCancel()">Yes, Cancel</button>
          </div>
        </div>
      `;
      document.body.appendChild(confirmationModal);
    }
    
    function confirmCancel() {
      // Remove confirmation modal
      document.querySelectorAll('.verification-modal').forEach(m => {
        if (m.id !== 'verificationModal') { // Only remove the confirmation modal itself
          m.remove();
        }
      });
      
      // Close verification and reload
      closeVerification();
      preventRefresh = false;
      window.onbeforeunload = null;
      if (countdownInterval) {
        clearInterval(countdownInterval);
      }
      window.location.href = window.location.href; // Reload the page
    }

    // Close verification modal
    function closeVerification() {
      const step3Active = document.getElementById('step3').classList.contains('active');
      
      const verificationModal = document.getElementById('verificationModal');
      if (verificationModal) verificationModal.classList.remove('active');
      
      document.querySelectorAll('.verification-step').forEach(step => step.classList.remove('active'));
      const step1 = document.getElementById('step1');
      if (step1) step1.classList.add('active');
      
      const profileLink = document.getElementById('profileLink');
      if (profileLink) profileLink.value = '';
      document.getElementById('step1Next').disabled = true;
      
      const countdownTimer = document.getElementById('countdownTimer');
      const profileLinkForm = document.getElementById('profileLinkForm');
      if (countdownTimer) countdownTimer.style.display = 'block';
      if (profileLinkForm) profileLinkForm.style.display = 'none';

      const countdownText = document.getElementById('countdownText');
      if (countdownText) countdownText.textContent = '30';
      if (countdownInterval) {
        clearInterval(countdownInterval);
      }
      preventRefresh = false;
      window.onbeforeunload = null;
      
      // Reload page if coming from step3 (success)
      if (step3Active) {
        window.location.href = window.location.href;
      }
    }

    // Next step
    function nextStep(step) {
      document.querySelectorAll('.verification-step').forEach(s => s.classList.remove('active'));
      const nextStepElement = document.getElementById(`step${step}`);
      if (nextStepElement) nextStepElement.classList.add('active');
    }

    // Moved validateProfileLink here to ensure it's in scope for the modal

    function showPremiumPopup() {
      const overlay = document.getElementById('premiumPopupOverlay');
      if(overlay) overlay.classList.add('active');
    }

    function closePremiumPopup() {
      const overlay = document.getElementById('premiumPopupOverlay');
      if(overlay) overlay.classList.remove('active');
    }

    // Add spin animation
    const style = document.createElement('style');
    style.textContent = `
      @keyframes spin {
        to { transform: rotate(360deg); }
      }
    `;
    document.head.appendChild(style);

    <?php if ($user_data['membership_type'] === 'free'): ?>
    let hasShownScrollPopup = false;
    window.addEventListener('scroll', function() {
      if (hasShownScrollPopup) return;
      
      const scrollPosition = window.scrollY + window.innerHeight;
      const pageHeight = document.documentElement.scrollHeight;
      
      // Show popup when user scrolls to 80% of page
      if (scrollPosition >= pageHeight * 0.8) {
        hasShownScrollPopup = true;
        showPremiumPopup();
      }
    });
    <?php endif; ?>
  </script>
  
  <!-- Added Hero Checkbox Modal HTML -->
  <div class="ts-modal" id="heroCheckboxModal">
    <div class="ts-modal-content">
      <div class="ts-modal-header">
        <h2>Task Instructions</h2>
      </div>
      <div class="ts-modal-body">
        <h3>How to Complete Tasks Correctly</h3>
        <p>To ensure your tasks are approved and you receive your earnings, please follow these guidelines carefully:</p>
        
        <ul>
          <li><strong>Read Instructions:</strong> Always read the full task description and instructions before starting.</li>
          <li><strong>Use Correct Profile:</strong> Submit the profile link or username requested for the specific platform (e.g., your TikTok profile, not your friend's).</li>
          <li><strong>Valid Links Only:</strong> Ensure the link you provide is directly to your profile or the required action page. Do not use generic profile page links if a specific task link is given.</li>
          <li><strong>No Duplicates:</strong> Do not submit the same profile link for multiple tasks of the same type unless explicitly allowed.</li>
          <li><strong>Wait for Verification:</strong> After completing a task, you will be prompted to submit your verification details. Wait for the verification form to appear.</li>
          <li><strong>Accurate Information:</strong> Provide accurate and truthful information. Any attempt to cheat or provide false information will result in disqualification and potential account suspension.</li>
          <li><strong>Platform Rules:</strong> Adhere to the terms of service of the platform where you are performing the task.</li>
        </ul>
        
        <h3>Important Notes:</h3>
        <p><strong>Free Users:</strong> To access all available tasks and filtering options, please consider upgrading to a premium membership. Free users may have limited task availability.</p>
        <p><strong>Task Submission Time:</strong> You will have a limited time to submit your verification details after starting a task. Ensure you complete the task and submit promptly.</p>
        <p><strong>Verification Time:</strong> Some tasks may take a short while to verify. Please be patient as our system automatically checks your submission.</p>
      </div>
      <div class="ts-modal-footer">
        <div class="ts-checkbox-wrapper" style="margin-bottom: 0;">
          <input type="checkbox" id="heroCheckboxCheck" class="ts-checkbox">
          <label for="heroCheckboxCheck" class="ts-checkbox-label">Don't show this again</label>
        </div>
        <div class="ts-modal-actions">
          <button class="btn-secondary" onclick="closeHeroCheckboxModal()">Close</button>
        </div>
      </div>
    </div>
  </div>

  <script>
    function openHeroCheckboxModal() {
      const modal = document.getElementById('heroCheckboxModal');
      if (modal) modal.classList.add('active');
    }

    function closeHeroCheckboxModal() {
      const modal = document.getElementById('heroCheckboxModal');
      if (modal) modal.classList.remove('active');
      
      const checkbox = document.getElementById('heroCheckboxCheck');
      if (checkbox && checkbox.checked) {
        // Optionally, store this preference in local storage or session
        localStorage.setItem('hideHeroCheckboxModal', 'true');
      }
    }

    // Check local storage on page load to see if modal should be hidden
    document.addEventListener('DOMContentLoaded', () => {
      if (localStorage.getItem('hideHeroCheckboxModal') === 'true') {
        // Hide the checkbox in the hero section if the modal has been dismissed with "Don't show again"
        const heroCheckboxContainer = document.querySelector('.hero-content > div[style*="cursor: pointer"]');
        if (heroCheckboxContainer) heroCheckboxContainer.style.display = 'none';
      }
    });
  </script>


  <script>
    document.addEventListener("DOMContentLoaded", () => {
      // Select all alert messages
      const alerts = document.querySelectorAll(".alert-message");

      // Function to show and hide each alert
      function showAlert(alert) {
        if (!alert) return;
        setTimeout(() => alert.classList.add("show"), 100);
        setTimeout(() => alert.classList.remove("show"), 5000);
      }

      alerts.forEach(showAlert);
    });
  </script>
  
  <!-- Added Premium Popup HTML -->
  <div class="premium-popup-overlay" id="premiumPopupOverlay">
      <div class="free-user-content">
      <svg viewBox="0 0 24 24" fill="currentColor">
        <path d="M12 2L2 7l10 5 10-5-10-5zm0 18.5l-8-4v-7l8 4 8-4v7l-8 4z"/>
      </svg>
      <h2>Premium Access</h2>
      <p>To access more available Task & Earn is reserved for premium members. Activate your account to begin earning by completing daily tasks.</p>
      <div>
        <a href="membership.php" class="upgrade-btn">Activate Now</a>
        <button class="close-modal-btn" onclick="closePremiumPopup()">Maybe Later</button>
      </div>
    </div>
    <!--<div class="premium-popup-content">-->
    <!--  <button class="premium-popup-close" onclick="closePremiumPopup()">-->
    <!--    <svg viewBox="0 0 24 24" width="24" height="24" fill="currentColor">-->
    <!--      <path d="M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12 19 6.41z"/>-->
    <!--    </svg>-->
    <!--  </button>-->
      
      
      
      
      <!--<a href="membership.php" class="btn-primary" style="width: 100%; text-align: center; text-decoration: none; padding: 16px; font-size: 1.1rem;">-->
      <!--  Upgrade Now-->
      <!--</a>-->
    </div>
  </div>

  <!-- Added premium popup styles -->
  <style>
    .premium-popup-overlay {
      display: none;
      position: fixed;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      background: rgba(3, 9, 34, 0.9);
      backdrop-filter: blur(8px);
      z-index: 9999999;
      align-items: center;
      justify-content: center;
      padding: 20px;
    }
    
    .premium-popup-overlay.active {
      display: flex;
    }
    
    .premium-popup-content {
      background: rgba(6, 16, 48, 0.98);
      border: 1px solid rgba(77, 225, 193, 0.4);
      border-radius: 24px;
      padding: 32px;
      max-width: 500px;
      width: 100%;
      max-height: 90vh;
      overflow-y: auto;
      position: relative;
      box-shadow: 0 20px 60px rgba(0, 0, 0, 0.5);
    }
    
    .premium-popup-close {
      position: absolute;
      top: 16px;
      right: 16px;
      background: rgba(255, 77, 77, 0.2);
      border: 1px solid rgba(255, 77, 77, 0.4);
      color: #ff4d4d;
      width: 40px;
      height: 40px;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      cursor: pointer;
      transition: all 0.3s ease;
    }
    
    .premium-popup-close:hover {
      background: rgba(255, 77, 77, 0.3);
      transform: scale(1.1);
    }
    
    @media (max-width: 680px) {
      .premium-popup-content {
        padding: 24px;
      }
    }
    
     .free-user-content {
      background: rgba(6, 16, 48, 0.98);
      border: 1px solid rgba(100, 154, 255, 0.3);
      border-radius: 24px;
      padding: 32px;
      max-width: 500px;
      width: 100%;
      text-align: center;
    }
    
    .free-user-content svg {
      width: 80px;
      height: 80px;
      margin-bottom: 24px;
      color: #fbbf24;
    }
    
    .free-user-content h2 {
      margin: 0 0 16px;
      font-size: 1.5rem;
      color: var(--page-white);
    }
    
    .free-user-content p {
      color: rgba(205, 219, 255, 0.7);
      line-height: 1.7;
      margin-bottom: 24px;
    }
    
    .upgrade-btn {
      display: inline-block;
      padding: 14px 32px;
      background: linear-gradient(135deg, #fbbf24, #f59e0b);
      color: #000;
      border-radius: 12px;
      text-decoration: none;
      font-weight: 700;
      font-size: 1rem;
      text-transform: uppercase;
      letter-spacing: 0.05em;
      transition: all 0.3s ease;
      margin-right: 12px;
    }
    
    .upgrade-btn:hover {
      transform: translateY(-2px);
      box-shadow: 0 8px 24px rgba(251, 191, 36, 0.4);
    }
    
      .close-modal-btn {
      display: inline-block;
      padding: 14px 32px;
      background: rgba(100, 154, 255, 0.2);
      color: var(--page-white);
      border-radius: 12px;
      text-decoration: none;
      font-weight: 600;
      font-size: 1rem;
      cursor: pointer;
      transition: all 0.3s ease;
    }
    
    .close-modal-btn:hover {
      background: rgba(100, 154, 255, 0.3);
    }
  </style>
</body>
</html>
