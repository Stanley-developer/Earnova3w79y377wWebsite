<?php
require_once 'config/database.php';
require_once 'includes/session.php';
require_once 'includes/connect.php';

// Require authentication
requireLogin();
checkSessionTimeout();

// Get current user data
$user = getCurrentUser();
$user_id = $user['id'];

try {
    $pdo = getDBConnection();
    
    // Fetch user details with balance
    $stmt = $pdo->prepare("SELECT u.*, b.total_balance, b.referral_earnings, b.game_earnings, b.task_earnings FROM users u LEFT JOIN balances b ON u.id = b.user_id WHERE u.id = ?");
    $stmt->execute([$user_id]);
    $user_data = $stmt->fetch();
    
    if (!$user_data) {
        header('Location: login.php');
        exit;
    }
    
    $is_premium = ($user_data['membership_type'] === 'premium');
    
} catch (PDOException $e) {
    error_log("Spin Wheel Error: " . $e->getMessage());
    $error_message = "Unable to load game data.";
}

$referral_earnings = $user_data['referral_earnings'] ?? 0;
$game_earnings = $user_data['game_earnings'] ?? 0;
$task_earnings = $user_data['task_earnings'] ?? 0;
$membership_type = $user_data['membership_type'] ?? 'free';
$user_email = $user_data['email'] ?? '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Spin & Win - FlowEarner</title>
    <link rel="stylesheet" href="assets/css/gamified-fintech-theme.css">
    <style>
        :root {
            --page-blue-900: #030922;
            --page-blue-800: #0a1642;
            --page-blue-700: #0a164a;
            --page-blue-500: #142e7e;
            --page-mint: #4de1c1;
            --page-white: #f5f9ff;
            --page-orange: #fb923c;
            --page-gold: #fbbf24;
            --page-red: #ef4444;
        }

        * { box-sizing: border-box; margin: 0; padding: 0; }

        body {
            font-family: 'Inter', sans-serif;
            background: linear-gradient(135deg, #0a0e27 0%, #1a1f3a 100%);
            color: #fff;
            overflow-x: hidden;
        }
        
        .container {
            max-width: 1400px;
            margin: 0 auto;
            padding: 20px;
        }
        
        .page-header {
            text-align: center;
            padding: 30px 20px;
            background: linear-gradient(135deg, rgba(44, 91, 245, 0.2), rgba(77, 225, 193, 0.1));
            border-radius: 20px;
            margin-bottom: 20px;
        }
        
        .page-header h1 {
            font-size: 2.5rem;
            margin: 0 0 10px;
            background: linear-gradient(135deg, #2c5bf5, #4de1c1);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }
        
        .back-link {
            display: inline-block;
            margin-bottom: 20px;
            color: var(--page-mint);
            text-decoration: none;
            font-size: 1rem;
            transition: color 0.3s ease;
        }
        
        .back-link:hover {
            color: #fff;
        }
        
        .game-layout {
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 20px;
            margin-bottom: 30px;
        }
        
        .game-canvas-container {
            background: linear-gradient(135deg, #1a2a5e 0%, #0f1937 100%);
            border: 2px solid rgba(77, 225, 193, 0.2);
            border-radius: 30px;
            padding: 20px;
            position: relative;
            width: 100%;
            max-width: 600px;
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 20px;
            overflow: hidden;
            box-shadow: 0 10px 40px rgba(0, 0, 0, 0.5);
        }
        
        .top-balance-bar {
            display: flex;
            justify-content: flex-end;
            align-items: center;
            width: 100%;
            gap: 15px;
        }
        
        .balance-chip {
            background: rgba(10, 22, 66, 0.8);
            border: 2px solid rgba(77, 225, 193, 0.3);
            border-radius: 25px;
            padding: 8px 20px;
            display: flex;
            align-items: center;
            gap: 10px;
            cursor: pointer;
            transition: all 0.3s ease;
        }
        
        .balance-chip:hover {
            background: rgba(10, 22, 66, 1);
            border-color: var(--page-mint);
        }
        
        .balance-chip-icon {
            font-size: 1.2rem;
        }
        
        .balance-chip-value {
            color: #fff;
            font-weight: 600;
            font-size: 1rem;
        }
        
        .deposit-chip {
            background: linear-gradient(135deg, #ef4444, #dc2626);
            border: none;
            color: #fff;
            font-weight: 700;
            padding: 10px 25px;
        }
        
        .deposit-chip:hover {
            transform: scale(1.05);
        }
        
        .wheel-container {
            position: relative;
            width: 400px;
            height: 400px;
            margin: 30px 0;
        }
        
        .wheel-pointer {
            position: absolute;
            top: -20px;
            left: 50%;
            transform: translateX(-50%);
            width: 0;
            height: 0;
            border-left: 20px solid transparent;
            border-right: 20px solid transparent;
            border-top: 40px solid var(--page-gold);
            z-index: 10;
            filter: drop-shadow(0 4px 8px rgba(0, 0, 0, 0.3));
        }
        
        .wheel-pointer::before {
            content: '';
            position: absolute;
            top: -50px;
            left: 50%;
            transform: translateX(-50%);
            width: 30px;
            height: 30px;
            background: var(--page-gold);
            border-radius: 50% 50% 0 0;
        }
        
        .wheel {
            width: 100%;
            height: 100%;
            border-radius: 50%;
            border: 8px solid var(--page-gold);
            position: relative;
            transition: transform 10s cubic-bezier(0.17, 0.67, 0.12, 0.99);
            box-shadow: 0 0 0 12px rgba(10, 22, 66, 0.8), 0 0 40px rgba(251, 191, 36, 0.4);
            overflow: hidden; /* Added overflow hidden to ensure wheel stays perfectly circular */
        }
        
        .wheel-center {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            width: 100px;
            height: 100px;
            background: linear-gradient(135deg, var(--page-gold), #f59e0b);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 900;
            font-size: 0.9rem;
            text-align: center;
            z-index: 5;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.5);
            border: 4px solid rgba(10, 22, 66, 0.8);
        }
        
        .wheel-segment {
            position: absolute;
            width: 50%;
            height: 50%;
            transform-origin: 100% 100%;
            clip-path: polygon(0 0, 100% 0, 100% 100%);
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        .wheel-segment-text {
            position: absolute;
            font-weight: 900;
            font-size: 1.2rem;
            color: #000;
            text-shadow: 1px 1px 2px rgba(255, 255, 255, 0.5);
            transform: rotate(-22.5deg) translateX(60px);
        }
        
        .bottom-controls {
            width: 100%;
            background: rgba(10, 22, 66, 0.6);
            border-radius: 20px;
            padding: 20px;
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 15px;
        }
        
        .bet-controls {
            display: flex;
            align-items: center;
            gap: 10px;
            width: 100%;
            justify-content: center;
        }
        
        .bet-label {
            color: rgba(255, 255, 255, 0.7);
            font-size: 0.9rem;
            margin-right: 5px;
        }
        
        .bet-btn {
            width: 40px;
            height: 40px;
            border-radius: 10px;
            border: 2px solid rgba(251, 146, 60, 0.5);
            background: rgba(251, 146, 60, 0.1);
            color: var(--page-orange);
            font-size: 1.2rem;
            cursor: pointer;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        .bet-btn:hover {
            background: rgba(251, 146, 60, 0.3);
            border-color: var(--page-orange);
        }
        
        .bet-display {
            background: rgba(10, 22, 66, 0.8);
            border: 2px solid rgba(77, 225, 193, 0.3);
            border-radius: 12px;
            padding: 10px 30px;
            color: #fff;
            font-size: 1.2rem;
            font-weight: 600;
            min-width: 120px;
            text-align: center;
        }
        
        .action-buttons {
            display: flex;
            gap: 15px;
            width: 100%;
        }
        
        .spin-button {
            flex: 1;
            background: linear-gradient(135deg, #fbbf24, #f59e0b);
            border: none;
            border-radius: 15px;
            padding: 15px 40px;
            color: #000;
            font-size: 1.3rem;
            font-weight: 900;
            cursor: pointer;
            transition: all 0.3s ease;
            text-transform: uppercase;
            letter-spacing: 1px;
        }
        
        .spin-button:hover:not(:disabled) {
            transform: scale(1.05);
            box-shadow: 0 0 30px rgba(251, 191, 36, 0.8);
        }
        
        .spin-button:disabled {
            opacity: 0.5;
            cursor: not-allowed;
        }
        
        .info-btn {
            width: 50px;
            height: 50px;
            border-radius: 15px;
            border: none;
            background: linear-gradient(135deg, #fbbf24, #f59e0b);
            color: #000;
            font-size: 1.2rem;
            font-weight: 900;
            cursor: pointer;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        .info-btn:hover {
            transform: scale(1.05);
            box-shadow: 0 0 20px rgba(251, 191, 36, 0.6);
        }
        
        .particles {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            pointer-events: none;
            overflow: hidden;
        }
        
        .particle {
            position: absolute;
            width: 3px;
            height: 3px;
            background: var(--page-gold);
            border-radius: 50%;
            animation: float 10s infinite;
            opacity: 0.6;
        }
        
        @keyframes float {
            0%, 100% {
                transform: translateY(0) translateX(0);
                opacity: 0;
            }
            10% {
                opacity: 0.6;
            }
            90% {
                opacity: 0.6;
            }
            100% {
                transform: translateY(-100vh) translateX(50px);
                opacity: 0;
            }
        }
        
        .modal-overlay {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.9);
            z-index: 1000;
            align-items: center;
            justify-content: center;
            opacity: 0;
            transition: opacity 0.3s ease;
        }
        
        .modal-overlay.active {
            display: flex;
            opacity: 1;
        }
        
        .modal-content {
            background: linear-gradient(135deg, #0a0e27, #1a1f3a);
            border-radius: 30px;
            padding: 40px;
            max-width: 600px;
            width: 90%;
            border: 2px solid rgba(77, 225, 193, 0.3);
            text-align: center;
            position: relative;
            max-height: 90vh;
            overflow-y: auto;
        }
        
        .modal-close {
            position: absolute;
            top: 20px;
            right: 20px;
            background: rgba(255, 59, 48, 0.2);
            border: 2px solid rgba(255, 59, 48, 0.5);
            color: #ff3b30;
            padding: 8px 16px;
            border-radius: 10px;
            cursor: pointer;
            font-weight: 600;
        }
        
        .modal-icon {
            font-size: 5rem;
            margin-bottom: 20px;
        }
        
        .modal-title {
            font-size: 2rem;
            margin-bottom: 15px;
        }
        
        .modal-message {
            font-size: 1.1rem;
            color: rgba(255, 255, 255, 0.8);
            line-height: 1.6;
            margin-bottom: 30px;
        }
        
        .modal-btn {
            padding: 15px 40px;
            border-radius: 15px;
            border: none;
            background: linear-gradient(135deg, #2c5bf5, #4de1c1);
            color: #fff;
            font-size: 1.1rem;
            font-weight: 700;
            cursor: pointer;
            margin: 0 10px;
            transition: all 0.3s ease;
        }
        
        .tutorial-steps {
            text-align: left;
            margin: 20px 0;
            position: relative;
        }
        
        .tutorial-step {
            background: rgba(77, 225, 193, 0.1);
            padding: 20px;
            border-radius: 15px;
            margin-bottom: 15px;
            /* border-left: 4px solid var(--page-mint); */
            display: none;
        }
        
        .tutorial-step.active {
            display: block;
            animation: slideIn 0.3s ease;
        }
        
        @keyframes slideIn {
            from {
                opacity: 0;
                transform: translateX(-20px);
            }
            to {
                opacity: 1;
                transform: translateX(0);
            }
        }
        
        .tutorial-step h4 {
            color: var(--page-mint);
            margin-bottom: 12px;
            font-size: 1.3rem;
        }
        
        .tutorial-step p {
            line-height: 1.6;
            font-size: 1rem;
        }
        
        .tutorial-navigation {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-top: 30px;
            gap: 15px;
        }
        
        .tutorial-nav-btn {
            padding: 12px 30px;
            border-radius: 12px;
            border: none;
            background: linear-gradient(135deg, #2c5bf5, #4de1c1);
            color: #fff;
            font-size: 1rem;
            font-weight: 600;
            cursor: pointer;
            display: flex;
            align-items: center;
            gap: 8px;
            transition: all 0.3s ease;
        }
        
        .tutorial-nav-btn:hover {
            transform: scale(1.05);
        }
        
        .tutorial-nav-btn:disabled {
            opacity: 0.3;
            cursor: not-allowed;
            transform: scale(1);
        }
        
        .tutorial-progress {
            text-align: center;
            color: rgba(255, 255, 255, 0.7);
            font-size: 0.9rem;
        }
        
        .tutorial-dots {
            display: flex;
            justify-content: center;
            gap: 8px;
            margin-top: 10px;
        }
        
        .tutorial-dot {
            width: 10px;
            height: 10px;
            border-radius: 50%;
            background: rgba(255, 255, 255, 0.3);
            transition: all 0.3s ease;
        }
        
        .tutorial-dot.active {
            background: var(--page-mint);
            width: 30px;
            border-radius: 5px;
        }
        
        .exchange-input {
            width: 100%;
            padding: 15px;
            border-radius: 10px;
            border: 2px solid rgba(77, 225, 193, 0.3);
            background: rgba(255, 255, 255, 0.05);
            color: #fff;
            font-size: 1.2rem;
            margin: 20px 0;
            text-align: center;
        }
        
        .upgrade-modal .modal-content {
            border-color: rgba(251, 146, 60, 0.5);
        }
        
        .prize-table {
            background: rgba(77, 225, 193, 0.1);
            padding: 20px;
            border-radius: 15px;
            margin: 20px 0;
            text-align: left;
        }
        
        .prize-table h4 {
            color: var(--page-gold);
            margin-bottom: 15px;
            text-align: center;
        }
        
        .prize-row {
            display: flex;
            justify-content: space-between;
            padding: 8px 0;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }
        
        .prize-row:last-child {
            border-bottom: none;
        }
        
        @media (max-width: 768px) {
            .game-canvas-container {
                max-width: 100%;
                padding: 15px;
                margin: 0 10px;
            }
            
            .wheel-container {
                width: 300px;
                height: 300px;
            }
            
            .wheel-center {
                width: 80px;
                height: 80px;
                font-size: 0.75rem;
            }
            
            .wheel-segment-text {
                font-size: 1rem;
                transform: rotate(-22.5deg) translateX(45px);
            }
            
            .page-header h1 {
                font-size: 1.8rem;
            }

            .modal-content {
                padding: 25px;
                max-width: 95%;
            }
            
            .tutorial-navigation {
                flex-direction: column;
            }
            
            .tutorial-nav-btn {
                width: 100%;
                justify-content: center;
            }
            
            .action-buttons {
                flex-direction: row;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <a href="play-earn.php" class="back-link">← Back to Games</a>
        
        <div class="page-header">
            <h1>Spin & Win</h1>
            <p>Spin the lucky wheel and win amazing prizes!</p>
        </div>
        
        <div class="game-layout">
            <div class="game-canvas-container">
                <div class="particles" id="particles"></div>
                
                <div class="top-balance-bar">
                    <div class="balance-chip" onclick="openBalanceModal('game')">
                        <span class="balance-chip-icon">💰</span>
                        <span class="balance-chip-value" id="gameBalance">₦<?php echo number_format($game_earnings, 2); ?></span>
                    </div>
                    <button class="balance-chip" id="volumeBtn" onclick="toggleMute()" style="cursor: pointer; border: none; background: rgba(10, 22, 66, 0.8);">
                        <span id="volumeIcon">🔊</span>
                    </button>
                    <div class="balance-chip deposit-chip" onclick="window.location.href='membership.php'">
                        Deposit
                    </div>
                </div>
                
                <div class="wheel-container">
                    <div class="wheel-pointer"></div>
                    <div class="wheel" id="wheel">
                        <div class="wheel-center">LUCK<br>WHEEL</div>
                    </div>
                </div>
                
                <div class="bottom-controls">
                    <div class="bet-controls">
                        <span class="bet-label">Bet:</span>
                        <button class="bet-btn" onclick="decreaseBet()">↓</button>
                        <button class="bet-btn" onclick="decreaseBetSmall()">−</button>
                        <div class="bet-display" id="betDisplay">1</div>
                        <button class="bet-btn" onclick="increaseBetSmall()">+</button>
                        <button class="bet-btn" onclick="increaseBet()">↑</button>
                    </div>
                    <div class="action-buttons">
                        <button class="spin-button" id="spinBtn" onclick="spinWheel()">SPIN</button>
                        <button class="info-btn" onclick="showTutorial()">ⓘ</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Notification Modal -->
    <div class="modal-overlay" id="notificationModal">
        <div class="modal-content">
            <button class="modal-close" onclick="closeNotificationModal()">✕</button>
            <div class="modal-icon" id="notificationIcon">ℹ️</div>
            <h2 class="modal-title" id="notificationTitle">Notification</h2>
            <p class="modal-message" id="notificationMessage">This is a notification message.</p>
            <button class="modal-btn" onclick="closeNotificationModal()">OK</button>
        </div>
    </div>

    <!-- Tutorial Modal -->
    <div class="modal-overlay" id="tutorialModal">
        <div class="modal-content">
            <button class="modal-close" onclick="closeTutorial()">✕</button>
            <div class="modal-icon" id="tutorialIcon">🎓</div>
            <h2 class="modal-title">How to Play Spin & Win</h2>
            
            <div class="tutorial-steps">
                <div class="tutorial-step active" data-step="1">
                    <h4>Step 1: Set Your Bet</h4>
                    <p>Use the + and - buttons to adjust your bet amount. Minimum bet is ₦1,000. Your bet will be deducted from your Play Balance (referral earnings).</p>
                </div>
                <div class="tutorial-step" data-step="2">
                    <h4>Step 2: Spin the Wheel</h4>
                    <p>Click the golden "SPIN" button to start spinning the lucky wheel. Watch as it spins and lands on a prize!</p>
                </div>
                <div class="tutorial-step" data-step="3">
                    <h4>Step 3: Win Prizes</h4>
                    <p>The wheel has 8 segments with different multipliers. Where it lands determines your prize! 50% win rate, 50% loss rate.</p>
                    <div class="prize-table">
                        <h4>Prize Segments</h4>
                        <div class="prize-row"><span>x3.0</span><span>Triple your bet!</span></div>
                        <div class="prize-row"><span>x2.0</span><span>Double your bet!</span></div>
                        <div class="prize-row"><span>x1.5</span><span>1.5x your bet</span></div>
                        <div class="prize-row"><span>x1.2</span><span>1.2x your bet</span></div>
                        <div class="prize-row"><span>Empty</span><span>No prize</span></div>
                        <div class="prize-row"><span>0.8x</span><span>Lose 20%</span></div>
                        <div class="prize-row"><span>0.5x</span><span>Lose 50%</span></div>
                        <div class="prize-row"><span>Empty</span><span>No prize</span></div>
                    </div>
                </div>
                <div class="tutorial-step" data-step="4">
                    <h4>Step 4: Collect Winnings</h4>
                    <p>Your winnings are automatically added to Game Earnings. Exchange them to Task Balance anytime for withdrawals!</p>
                </div>
            </div>
            
            <div class="tutorial-progress">
                <span id="tutorialStepText">Step 1 of 4</span>
                <div class="tutorial-dots">
                    <div class="tutorial-dot active"></div>
                    <div class="tutorial-dot"></div>
                    <div class="tutorial-dot"></div>
                    <div class="tutorial-dot"></div>
                </div>
            </div>
            
            <div class="tutorial-navigation">
                <button class="tutorial-nav-btn" id="tutorialPrevBtn" onclick="previousTutorialStep()" disabled>
                    ← Back
                </button>
                <button class="tutorial-nav-btn" id="tutorialNextBtn" onclick="nextTutorialStep()">
                    Next →
                </button>
            </div>
            
            <p style="margin: 20px 0; color: rgba(255, 255, 255, 0.7);">
                Need more help? <a href="https://www.youtube.com/watch?v=spin-wheel-tutorial" target="_blank" style="color: var(--page-mint);">Watch Tutorial Video</a>
            </p>
        </div>
    </div>
    
    <!-- Balance Exchange Modal -->
    <div class="modal-overlay" id="exchangeModal">
        <div class="modal-content">
            <button class="modal-close" onclick="closeExchangeModal()">✕</button>
            <div class="modal-icon">💱</div>
            <h2 class="modal-title">Exchange Game Earnings</h2>
            <p class="modal-message">Convert your Game Earnings to Task Balance for withdrawals.</p>
            <div style="background: rgba(77, 225, 193, 0.1); padding: 15px; border-radius: 10px; margin: 20px 0;">
                <p style="margin-bottom: 10px;">Available Game Earnings:</p>
                <p style="font-size: 2rem; font-weight: 700; color: var(--page-mint);" id="availableGameEarnings">₦0.00</p>
            </div>
            <input type="number" class="exchange-input" id="exchangeAmount" placeholder="Enter amount to exchange" min="100" step="100">
            <button class="modal-btn" onclick="exchangeBalance()">Exchange Now</button>
        </div>
    </div>
    
    <!-- Upgrade Required Modal -->
    <div class="modal-overlay upgrade-modal" id="upgradeModal">
        <div class="modal-content">
            <button class="modal-close" onclick="closeUpgradeModal()">✕</button>
            <div class="modal-icon">🔒</div>
            <h2 class="modal-title">Premium Membership Required</h2>
            <p class="modal-message">
                This game is exclusively for Premium Members. Upgrade now to unlock all games and start winning real rewards!
            </p>
            <div style="background: rgba(251, 146, 60, 0.1); padding: 20px; border-radius: 10px; margin: 20px 0; text-align: left;">
                <h4 style="color: var(--page-orange); margin-bottom: 15px;">Premium Benefits:</h4>
                <p style="margin-bottom: 8px;">✓ Access to all games</p>
                <p style="margin-bottom: 8px;">✓ Higher winning rates</p>
                <p style="margin-bottom: 8px;">✓ Exclusive tournaments</p>
                <p>✓ Priority support</p>
            </div>
            <button class="modal-btn" onclick="window.location.href='membership.php'" style="background: linear-gradient(135deg, #fb923c, #f97316);">
                Upgrade to Premium
            </button>
        </div>
    </div>
    
    <!-- Deposit Modal -->
    <div class="modal-overlay" id="depositModal">
        <div class="modal-content">
            <button class="modal-close" onclick="closeDepositModal()">✕</button>
            <div class="modal-icon">💳</div>
            <h2 class="modal-title">Deposit to Play</h2>
            <p class="modal-message">Add funds to your Play Balance to continue playing games.</p>
            <input type="number" class="exchange-input" id="depositAmount" placeholder="Enter amount (Min: ₦1,000)" min="1000" step="100">
            <button class="modal-btn" onclick="initiateDeposit()">Deposit with Paystack</button>
        </div>
    </div>
    
    <!-- Result Modal -->
    <div class="modal-overlay" id="resultModal">
        <div class="modal-content">
            <div class="modal-icon" id="resultIcon">🎉</div>
            <h2 class="modal-title" id="resultTitle">You Won!</h2>
            <p style="font-size: 3rem; font-weight: 900; color: var(--page-mint); margin: 20px 0;" id="resultAmount">₦0.00</p>
            <p class="modal-message" id="resultMessage">Your winnings have been added to Game Earnings!</p>
            <button class="modal-btn" onclick="closeResultModal()">Claim Reward</button>
            <button class="modal-btn" onclick="spinAgain()" style="background: rgba(255, 255, 255, 0.1);">Spin Again</button>
        </div>
    </div>
    
    <script>
        const PAYSTACK_PUBLIC_KEY = 'pk_test_2889acc30e717c743676ced0e02e0e1ad4d274fe';
        const USER_EMAIL = '<?php echo $user_email; ?>';
        const IS_PREMIUM = <?php echo $is_premium ? 'true' : 'false'; ?>;
        
        const sounds = {
            background: new Audio('assets/sounds/spin-bg-music.mp3'),
            spin: new Audio('assets/sounds/spin-wheel.mp3'),
            tick: new Audio('assets/sounds/wheel-tick.mp3'),
            win: new Audio('assets/sounds/spin-win.mp3'),
            bigWin: new Audio('assets/sounds/spin-big-win.mp3'),
            lose: new Audio('assets/sounds/spin-lose.mp3')
        };
        
        // Configure sounds
        sounds.background.loop = true;
        sounds.background.volume = 0.3;
        sounds.spin.volume = 0.5;
        sounds.tick.volume = 0.3;
        sounds.win.volume = 0.6;
        sounds.bigWin.volume = 0.7;
        sounds.lose.volume = 0.5;
        
        // Sound manager with mute functionality
        let isMuted = localStorage.getItem('spin_sound_muted') === 'true';
        let isBackgroundMusicPlaying = false;
        
        // Apply mute state on load
        if (isMuted) {
            Object.values(sounds).forEach(sound => sound.muted = true);
            document.getElementById('volumeIcon').textContent = '🔇';
        }
        
        function toggleMute() {
            isMuted = !isMuted;
            localStorage.setItem('spin_sound_muted', isMuted);
            
            Object.values(sounds).forEach(sound => sound.muted = isMuted);
            document.getElementById('volumeIcon').textContent = isMuted ? '🔇' : '🔊';
            
            if (!isMuted) {
                playBackgroundMusic();
            } else {
                stopBackgroundMusic();
            }
        }
        
        function playBackgroundMusic() {
            if (!isBackgroundMusicPlaying && !isMuted) {
                sounds.background.play().catch(err => {
                    console.log('Background music autoplay prevented. User interaction required.');
                });
                isBackgroundMusicPlaying = true;
            }
        }
        
        function stopBackgroundMusic() {
            if (isBackgroundMusicPlaying) {
                sounds.background.pause();
                sounds.background.currentTime = 0;
                isBackgroundMusicPlaying = false;
            }
        }
        
        function playSpinSound() {
            sounds.spin.currentTime = 0;
            sounds.spin.play().catch(err => console.log('Spin sound error:', err));
        }
        
        function playResultSound(multiplier) {
            if (multiplier >= 2.0) {
                sounds.bigWin.play().catch(err => console.log('Big win sound error:', err));
            } else if (multiplier > 0) {
                sounds.win.play().catch(err => console.log('Win sound error:', err));
            } else {
                sounds.lose.play().catch(err => console.log('Lose sound error:', err));
            }
        }
        
        // Start background music on first user interaction
        document.addEventListener('click', function initAudio() {
            playBackgroundMusic();
            document.removeEventListener('click', initAudio);
        }, { once: true });
        
        let isSpinning = false;
        let hasSeenTutorial = localStorage.getItem('spin_tutorial_seen') === 'true';
        let currentTutorialStep = 1;
        const totalTutorialSteps = 4;
        let betAmount = 1; // This represents thousands (1 = ₦1,000)
        let spinCount = 0; // Added spin counter to increase rotation with each spin
        
        // Wheel segments: 50% win (x3.0, x2.0, x1.5, x1.2) and 50% loss (Empty, 0.8x, 0.5x, Empty)
        const segments = [
            { label: 'x3.0', multiplier: 3.0, color: '#3b82f6', isWin: true },
            { label: 'Empty', multiplier: 0, color: '#fb923c', isWin: false },
            { label: 'x2.0', multiplier: 2.0, color: '#3b82f6', isWin: true },
            { label: '0.5x', multiplier: 0.5, color: '#fb923c', isWin: false },
            { label: 'x1.5', multiplier: 1.5, color: '#3b82f6', isWin: true },
            { label: '0.8x', multiplier: 0.8, color: '#fb923c', isWin: false },
            { label: 'x1.2', multiplier: 1.2, color: '#3b82f6', isWin: true },
            { label: 'Empty', multiplier: 0, color: '#fb923c', isWin: false }
        ];
        
        function createParticles() {
            const particlesContainer = document.getElementById('particles');
            for (let i = 0; i < 20; i++) {
                const particle = document.createElement('div');
                particle.className = 'particle';
                particle.style.left = Math.random() * 100 + '%';
                particle.style.animationDelay = Math.random() * 10 + 's';
                particle.style.animationDuration = (Math.random() * 10 + 10) + 's';
                particlesContainer.appendChild(particle);
            }
        }
        
        createParticles();
        
        function initWheel() {
            const wheel = document.getElementById('wheel');
            const segmentAngle = 360 / segments.length;
            
            segments.forEach((segment, index) => {
                const segmentDiv = document.createElement('div');
                segmentDiv.className = 'wheel-segment';
                segmentDiv.style.background = segment.color;
                segmentDiv.style.transform = `rotate(${index * segmentAngle}deg)`;
                
                const textDiv = document.createElement('div');
                textDiv.className = 'wheel-segment-text';
                textDiv.textContent = segment.label;
                segmentDiv.appendChild(textDiv);
                
                wheel.appendChild(segmentDiv);
            });
        }
        
        initWheel();
        
        /* Show tutorial on first visit */
        if (!hasSeenTutorial) {
            setTimeout(() => {
                const modal = document.getElementById('tutorialModal');
                modal.style.display = 'flex';
                setTimeout(() => modal.classList.add('active'), 10);
            }, 500);
        }
        
        function showTutorial() {
            currentTutorialStep = 1;
            updateTutorialDisplay();
            const modal = document.getElementById('tutorialModal');
            modal.style.display = 'flex';
            setTimeout(() => modal.classList.add('active'), 10);
        }
        
        function nextTutorialStep() {
            if (currentTutorialStep < totalTutorialSteps) {
                currentTutorialStep++;
                updateTutorialDisplay();
            } else {
                closeTutorial();
            }
        }
        
        function previousTutorialStep() {
            if (currentTutorialStep > 1) {
                currentTutorialStep--;
                updateTutorialDisplay();
            }
        }
        
        function updateTutorialDisplay() {
            document.querySelectorAll('.tutorial-step').forEach((step, index) => {
                step.classList.toggle('active', index + 1 === currentTutorialStep);
            });
            
            document.querySelectorAll('.tutorial-dot').forEach((dot, index) => {
                dot.classList.toggle('active', index + 1 === currentTutorialStep);
            });
            
            document.getElementById('tutorialStepText').textContent = `Step ${currentTutorialStep} of ${totalTutorialSteps}`;
            
            document.getElementById('tutorialPrevBtn').disabled = currentTutorialStep === 1;
            document.getElementById('tutorialNextBtn').textContent = currentTutorialStep === totalTutorialSteps ? "Let's Play! 🎮" : "Next →";
            
            const icons = ['🎓', '🎡', '🏆', '💰'];
            document.getElementById('tutorialIcon').textContent = icons[currentTutorialStep - 1];
        }
        
        function closeTutorial() {
            localStorage.setItem('spin_tutorial_seen', 'true');
            const modal = document.getElementById('tutorialModal');
            modal.classList.remove('active');
            setTimeout(() => modal.style.display = 'none', 300);
        }
        
        function increaseBet() {
            betAmount = Math.min(betAmount + 5, 100);
            updateBetDisplay();
        }
        
        function decreaseBet() {
            betAmount = Math.max(betAmount - 5, 1);
            updateBetDisplay();
        }
        
        function increaseBetSmall() {
            betAmount = Math.min(betAmount + 1, 100);
            updateBetDisplay();
        }
        
        function decreaseBetSmall() {
            betAmount = Math.max(betAmount - 1, 1);
            updateBetDisplay();
        }
        
        function updateBetDisplay() {
            document.getElementById('betDisplay').textContent = '₦' + (betAmount * 1000).toLocaleString();
        }
        
        function showNotification(title, message, icon = 'ℹ️') {
            document.getElementById('notificationIcon').textContent = icon;
            document.getElementById('notificationTitle').textContent = title;
            document.getElementById('notificationMessage').textContent = message;
            
            const modal = document.getElementById('notificationModal');
            modal.style.display = 'flex';
            setTimeout(() => modal.classList.add('active'), 10);
        }
        
        function closeNotificationModal() {
            const modal = document.getElementById('notificationModal');
            modal.classList.remove('active');
            setTimeout(() => modal.style.display = 'none', 300);
        }
        
        async function spinWheel() {
            if (isSpinning) return;
            
            if (!IS_PREMIUM) {
                const modal = document.getElementById('upgradeModal');
                modal.style.display = 'flex';
                setTimeout(() => modal.classList.add('active'), 10);
                return;
            }
            
            const actualBetAmount = betAmount * 1000;
            
            const gameBalanceElement = document.getElementById('gameBalance');
            const gameBalanceText = gameBalanceElement.textContent;
            const gameBalanceValue = parseFloat(gameBalanceText.replace('₦', '').replace(/,/g, ''));
            
            console.log('[v0] Spin Debug - Balance Check:');
            console.log('  Display Balance Text:', gameBalanceText);
            console.log('  Parsed Balance Value:', gameBalanceValue);
            console.log('  Bet Amount:', actualBetAmount);
            console.log('  Has Sufficient Balance:', gameBalanceValue >= actualBetAmount);
            
            stopBackgroundMusic();
            playSpinSound();
            
            isSpinning = true;
            document.getElementById('spinBtn').disabled = true;
            
            try {
                console.log('[v0] Sending spin request to API...');
                const response = await fetch('api/spin-play.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ bet_amount: actualBetAmount })
                });
                
                const data = await response.json();
                console.log('[v0] API Response:', data);
                
                if (data.success) {
                    // Animate wheel spin
                    await animateWheelSpin(data.segment_index);
                    
                    // Update balances
                    document.getElementById('gameBalance').textContent = '₦' + parseFloat(data.game_earnings).toLocaleString('en-NG', {minimumFractionDigits: 2, maximumFractionDigits: 2});
                    
                    playResultSound(data.multiplier);
                    
                    // Show result
                    showResult(data.win_amount, data.segment_label, data.multiplier);
                    
                    setTimeout(() => {
                        playBackgroundMusic();
                    }, 3000);
                } else {
                    console.error('[v0] Spin Failed:', data);
                    if (data.upgrade_required) {
                        const modal = document.getElementById('upgradeModal');
                        modal.style.display = 'flex';
                        setTimeout(() => modal.classList.add('active'), 10);
                    } else if (data.insufficient_balance) {
                        console.error('[v0] Insufficient Balance Error');
                        showNotification(
                            'Insufficient Balance',
                            'You don\'t have enough balance to play. Please deposit funds in the Membership page to continue playing.',
                            '💰'
                        );
                        setTimeout(() => {
                            closeNotificationModal();
                            window.location.href = 'membership.php';
                        }, 3000);
                    } else {
                        console.error('[v0] Spin Error:', data);
                        let errorMsg = data.message || 'An error occurred';
                        if (data.error_details) {
                            errorMsg += '\n\nDetails:\n' + JSON.stringify(data.error_details, null, 2);
                        }
                        showNotification('Error', errorMsg, '❌');
                    }
                    playBackgroundMusic();
                }
            } catch (error) {
                console.error('[v0] Spin Connection Error:', error);
                showNotification(
                    'Connection Error',
                    'Connection error: ' + error.message + '\n\nPlease check your internet connection and try again.',
                    '⚠️'
                );
                playBackgroundMusic();
            }
            
            isSpinning = false;
            document.getElementById('spinBtn').disabled = false;
        }
        
        async function animateWheelSpin(targetIndex) {
            const wheel = document.getElementById('wheel');
            const segmentAngle = 360 / segments.length;
            
            spinCount++;
            const baseRotations = 3600; // 10 full rotations
            const additionalRotations = spinCount * 1800; // Add 5 more rotations per spin
            
            // Calculate target rotation (pointer at top, so we need to adjust)
            const targetRotation = baseRotations + additionalRotations + (360 - (targetIndex * segmentAngle + segmentAngle / 2));
            
            console.log('[v0] Spin #' + spinCount + ' - Total rotation: ' + targetRotation + ' degrees');
            
            wheel.style.transform = `rotate(${targetRotation}deg)`;
            
            await new Promise(resolve => setTimeout(resolve, 10000));
        }
        
        function showResult(amount, label, multiplier) {
            const resultModal = document.getElementById('resultModal');
            const resultIcon = document.getElementById('resultIcon');
            const resultTitle = document.getElementById('resultTitle');
            const resultAmount = document.getElementById('resultAmount');
            const resultMessage = document.getElementById('resultMessage');
            
            if (multiplier >= 2.0) {
                resultIcon.textContent = '🎰';
                resultTitle.textContent = 'JACKPOT!';
            } else if (multiplier >= 1.0) {
                resultIcon.textContent = '🎉';
                resultTitle.textContent = 'You Won!';
            } else {
                resultIcon.textContent = '😔';
                resultTitle.textContent = 'Try Again!';
            }
            
            resultAmount.textContent = '₦' + parseFloat(amount).toLocaleString('en-NG', {minimumFractionDigits: 2, maximumFractionDigits: 2});
            resultMessage.textContent = multiplier > 0 ? `You landed on ${label}!` : 'Better luck next time!';
            
            resultModal.style.display = 'flex';
            setTimeout(() => resultModal.classList.add('active'), 10);
        }
        
        function closeResultModal() {
            const modal = document.getElementById('resultModal');
            modal.classList.remove('active');
            setTimeout(() => modal.style.display = 'none', 300);
        }
        
        function spinAgain() {
            closeResultModal();
            const wheel = document.getElementById('wheel');
            wheel.style.transition = 'none';
            wheel.style.transform = 'rotate(0deg)';
            setTimeout(() => {
                wheel.style.transition = 'transform 10s cubic-bezier(0.17, 0.67, 0.12, 0.99)';
            }, 50);
        }
        
        function openBalanceModal(type) {
            if (type === 'game') {
                const gameBalance = document.getElementById('gameBalance').textContent.replace('₦', '').replace(/,/g, '');
                document.getElementById('availableGameEarnings').textContent = '₦' + parseFloat(gameBalance).toLocaleString('en-NG', {minimumFractionDigits: 2, maximumFractionDigits: 2});
                const modal = document.getElementById('exchangeModal');
                modal.style.display = 'flex';
                setTimeout(() => modal.classList.add('active'), 10);
            }
        }
        
        function closeExchangeModal() {
            const modal = document.getElementById('exchangeModal');
            modal.classList.remove('active');
            setTimeout(() => modal.style.display = 'none', 300);
        }
        
        async function exchangeBalance() {
            const amount = parseFloat(document.getElementById('exchangeAmount').value);
            
            if (isNaN(amount) || amount <= 0) {
                showNotification('Invalid Amount', 'Please enter a valid amount', '⚠️');
                return;
            }
            
            try {
                const response = await fetch('api/exchange-balance-keno.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ amount })
                });
                
                const data = await response.json();
                
                if (data.success) {
                    document.getElementById('gameBalance').textContent = '₦' + parseFloat(data.game_earnings).toLocaleString('en-NG', {minimumFractionDigits: 2, maximumFractionDigits: 2});
                    
                    showNotification('Success', 'Balance exchanged successfully to Task Balance!', '✅');
                    closeExchangeModal();
                    
                    setTimeout(() => location.reload(), 1000);
                } else {
                    showNotification('Exchange Failed', data.message || 'Exchange failed', '❌');
                }
            } catch (error) {
                console.error('Error:', error);
                showNotification('Connection Error', 'Connection error. Please check your internet and try again.', '⚠️');
            }
        }
        
        function closeUpgradeModal() {
            const modal = document.getElementById('upgradeModal');
            modal.classList.remove('active');
            setTimeout(() => modal.style.display = 'none', 300);
        }
        
        function openDepositModal() {
            const modal = document.getElementById('depositModal');
            modal.style.display = 'flex';
            setTimeout(() => modal.classList.add('active'), 10);
        }
        
        function closeDepositModal() {
            const modal = document.getElementById('depositModal');
            modal.classList.remove('active');
            setTimeout(() => modal.style.display = 'none', 300);
        }
        
        async function initiateDeposit() {
            const amount = parseFloat(document.getElementById('depositAmount').value);
            
            if (isNaN(amount) || amount < 1000) {
                alert('Minimum deposit is ₦1,000');
                return;
            }
            
            try {
                const response = await fetch('api/paystack-deposit.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        action: 'initialize',
                        amount: amount,
                        email: USER_EMAIL
                    })
                });
                
                const data = await response.json();
                
                if (data.success && data.authorization_url) {
                    window.location.href = data.authorization_url;
                } else {
                    alert(data.message || 'Failed to initialize payment. Please try again.');
                }
            } catch (error) {
                console.error('[v0] Deposit error:', error);
                alert('Connection error. Please check your internet and try again.');
            }
        }
        
        updateBetDisplay();
        
    </script>
</body>
</html>
