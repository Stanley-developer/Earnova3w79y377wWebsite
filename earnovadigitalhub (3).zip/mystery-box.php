<?php
require_once 'config/database.php';
require_once 'includes/session.php';
require_once 'includes/connect.php';

// Require authentication
requireLogin();
checkSessionTimeout();

// Get current user data
$user = getCurrentUser();
$user_id = $user['id'];

try {
    $pdo = getDBConnection();
    
    // Fetch user details with balance
    $stmt = $pdo->prepare("SELECT u.*, b.total_balance, b.referral_earnings, b.game_earnings, b.task_earnings FROM users u LEFT JOIN balances b ON u.id = b.user_id WHERE u.id = ?");
    $stmt->execute([$user_id]);
    $user_data = $stmt->fetch();
    
    if (!$user_data) {
        header('Location: login.php');
        exit;
    }
    
    $is_premium = ($user_data['membership_type'] === 'premium');
    
} catch (PDOException $e) {
    error_log("Mystery Box 3D Error: " . $e->getMessage());
    $error_message = "Unable to load game data.";
}

$referral_earnings = $user_data['referral_earnings'] ?? 0;
$game_earnings = $user_data['game_earnings'] ?? 0;
$task_earnings = $user_data['task_earnings'] ?? 0;
$membership_type = $user_data['membership_type'] ?? 'free';
$user_email = $user_data['email'] ?? '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mystery Box - FlowEarner</title>
    <link rel="stylesheet" href="assets/css/gamified-fintech-theme.css">
    <script src="https://cdn.jsdelivr.net/npm/three@0.160.0/build/three.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/three@0.160.0/examples/js/controls/OrbitControls.js"></script>
    <style>
        :root {
            --page-blue-900: #030922;
            --page-blue-800: #0a1642;
            --page-blue-700: #0a164a;
            --page-blue-500: #142e7e;
            --page-mint: #4de1c1;
            --page-white: #f5f9ff;
            --page-orange: #fb923c;
            --page-gold: #fbbf24;
        }

        * { box-sizing: border-box; margin: 0; padding: 0; }

        body {
            font-family: 'Inter', sans-serif;
            background: linear-gradient(135deg, #0a0e27 0%, #1a1f3a 100%);
            color: #fff;
            overflow-x: hidden;
        }
        
        .container {
            max-width: 1400px;
            margin: 0 auto;
            padding: 20px;
        }
        
        .page-header {
            text-align: center;
            padding: 30px 20px;
            background: linear-gradient(135deg, rgba(44, 91, 245, 0.2), rgba(77, 225, 193, 0.1));
            border-radius: 20px;
            margin-bottom: 20px;
        }
        
        .page-header h1 {
            font-size: 2.5rem;
            margin: 0 0 10px;
            background: linear-gradient(135deg, #2c5bf5, #4de1c1);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }
        
        .back-link {
            display: inline-block;
            margin-bottom: 20px;
            color: var(--page-mint);
            text-decoration: none;
            font-size: 1rem;
            transition: color 0.3s ease;
        }
        
        .back-link:hover {
            color: #fff;
        }
        
        .game-layout {
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 20px;
            margin-bottom: 30px;
        }
        
        .game-canvas-container {
            background: linear-gradient(135deg, #1a2a5e 0%, #0f1937 100%);
            border: 2px solid rgba(77, 225, 193, 0.2);
            border-radius: 30px;
            padding: 20px 0;
            position: relative;
            width: 100%;
            max-width: 800px;
            height: 700px;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: space-between;
            overflow: hidden;
            box-shadow: 0 10px 40px rgba(0, 0, 0, 0.5);
        }
        
        .top-balance-bar {
            display: flex;
            justify-content: flex-end;
            align-items: center;
            width: 100%;
            padding: 10px 20px;
            gap: 15px;
        }
        
        .balance-chip {
            background: rgba(10, 22, 66, 0.8);
            border: 2px solid rgba(77, 225, 193, 0.3);
            border-radius: 25px;
            padding: 8px 20px;
            display: flex;
            align-items: center;
            gap: 10px;
            cursor: pointer;
            transition: all 0.3s ease;
        }
        
        .balance-chip:hover {
            background: rgba(10, 22, 66, 1);
            border-color: var(--page-mint);
        }
        
        .balance-chip-icon {
            font-size: 1.2rem;
        }
        
        .balance-chip-value {
            color: #fff;
            font-weight: 600;
            font-size: 1rem;
        }
        
        .deposit-chip {
            background: linear-gradient(135deg, #fb923c, #f97316);
            border: none;
            color: #fff;
            font-weight: 700;
            padding: 10px 25px;
        }
        
        .deposit-chip:hover {
            transform: scale(1.05);
        }
        
        .canvas-wrapper {
            width: 100%;
            flex: 1;
            display: flex;
            align-items: center;
            justify-content: center;
            position: relative;
            padding: 0;
        }
        
        /* Replaced Three.js canvas with CSS gift boxes grid */
        .boxes-grid {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 20px;
            padding: 40px 20px;
            max-width: 700px;
            margin: 0 auto;
        }
        
        .mystery-box {
            aspect-ratio: 1;
            background: linear-gradient(135deg, #fb923c, #f97316);
            border-radius: 20px;
            border: 4px solid var(--page-gold);
            cursor: pointer;
            position: relative;
            transition: all 0.3s ease;
            animation: shake 2s ease-in-out infinite;
            box-shadow: 0 10px 30px rgba(251, 146, 60, 0.4);
        }
        
        .mystery-box:nth-child(2) { animation-delay: 0.2s; }
        .mystery-box:nth-child(3) { animation-delay: 0.4s; }
        .mystery-box:nth-child(4) { animation-delay: 0.6s; }
        .mystery-box:nth-child(5) { animation-delay: 0.8s; }
        .mystery-box:nth-child(6) { animation-delay: 1s; }
        
        .mystery-box:hover {
            transform: scale(1.05);
            box-shadow: 0 15px 40px rgba(251, 146, 60, 0.6);
        }
        
        .mystery-box.disabled {
            opacity: 0.5;
            cursor: not-allowed;
            animation: none;
        }
        
        .mystery-box.opening {
            animation: openBox 0.8s ease forwards;
        }
        
        .box-icon {
            font-size: 4rem;
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
        }
        
        .box-ribbon {
            position: absolute;
            top: 0;
            left: 50%;
            transform: translateX(-50%);
            width: 20px;
            height: 100%;
            background: var(--page-gold);
        }
        
        .box-ribbon-horizontal {
            position: absolute;
            top: 50%;
            left: 0;
            transform: translateY(-50%);
            width: 100%;
            height: 20px;
            background: var(--page-gold);
        }
        
        .box-bow {
            position: absolute;
            top: -10px;
            left: 50%;
            transform: translateX(-50%);
            font-size: 3rem;
        }
        
        @keyframes shake {
            0%, 100% { transform: rotate(0deg); }
            25% { transform: rotate(-2deg); }
            75% { transform: rotate(2deg); }
        }
        
        @keyframes openBox {
            0% { transform: scale(1) rotate(0deg); }
            50% { transform: scale(1.3) rotate(10deg); }
            100% { transform: scale(0) rotate(360deg); opacity: 0; }
        }
        
        @media (max-width: 768px) {
            .boxes-grid {
                grid-template-columns: repeat(2, 1fr);
                gap: 15px;
                padding: 20px 15px;
            }
            
            .box-icon {
                font-size: 3rem;
            }
            
            .box-bow {
                font-size: 2rem;
            }
        }
        
        #mysteryBox3DCanvas {
            width: 100%;
            height: 100%;
            border-radius: 0;
            cursor: pointer;
        }
        
        .bottom-controls {
            width: 100%;
            background: rgba(10, 22, 66, 0.6);
            border-radius: 20px;
            padding: 20px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 15px;
        }
        
        .bet-controls {
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .bet-label {
            color: rgba(255, 255, 255, 0.7);
            font-size: 0.9rem;
            margin-right: 5px;
        }
        
        .bet-btn {
            width: 40px;
            height: 40px;
            border-radius: 10px;
            border: 2px solid rgba(251, 146, 60, 0.5);
            background: rgba(251, 146, 60, 0.1);
            color: var(--page-orange);
            font-size: 1.2rem;
            cursor: pointer;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        .bet-btn:hover {
            background: rgba(251, 146, 60, 0.3);
            border-color: var(--page-orange);
        }
        
        .bet-display {
            background: rgba(10, 22, 66, 0.8);
            border: 2px solid rgba(77, 225, 193, 0.3);
            border-radius: 12px;
            padding: 10px 30px;
            color: #fff;
            font-size: 1.2rem;
            font-weight: 600;
            min-width: 120px;
            text-align: center;
        }
        
        .play-button {
            background: linear-gradient(135deg, #fb923c, #f97316);
            border: none;
            border-radius: 15px;
            padding: 12px 50px;
            color: #fff;
            font-size: 1.3rem;
            font-weight: 700;
            cursor: pointer;
            transition: all 0.3s ease;
            text-transform: uppercase;
            letter-spacing: 1px;
        }
        
        .play-button:hover:not(:disabled) {
            transform: scale(1.05);
            box-shadow: 0 0 30px rgba(251, 146, 60, 0.8);
        }
        
        .play-button:disabled {
            opacity: 0.5;
            cursor: not-allowed;
        }
        
        .info-btn {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            border: 2px solid rgba(77, 225, 193, 0.5);
            background: rgba(77, 225, 193, 0.1);
            color: var(--page-mint);
            font-size: 1.2rem;
            cursor: pointer;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        .info-btn:hover {
            background: rgba(77, 225, 193, 0.3);
        }
        
        .particles {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            pointer-events: none;
            overflow: hidden;
        }
        
        .particle {
            position: absolute;
            width: 3px;
            height: 3px;
            background: var(--page-gold);
            border-radius: 50%;
            animation: float 10s infinite;
            opacity: 0.6;
        }
        
        @keyframes float {
            0%, 100% {
                transform: translateY(0) translateX(0);
                opacity: 0;
            }
            10% {
                opacity: 0.6;
            }
            90% {
                opacity: 0.6;
            }
            100% {
                transform: translateY(-100vh) translateX(50px);
                opacity: 0;
            }
        }
        
        .modal-overlay {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.9);
            z-index: 1000;
            align-items: center;
            justify-content: center;
        }
        
        .modal-overlay.active {
            display: flex;
        }
        
        .modal-content {
            background: linear-gradient(135deg, #0a0e27, #1a1f3a);
            border-radius: 30px;
            padding: 40px;
            max-width: 600px;
            width: 90%;
            border: 2px solid rgba(77, 225, 193, 0.3);
            text-align: center;
            position: relative;
            max-height: 90vh;
            overflow-y: auto;
        }
        
        .modal-close {
            position: absolute;
            top: 20px;
            right: 20px;
            background: rgba(255, 59, 48, 0.2);
            border: 2px solid rgba(255, 59, 48, 0.5);
            color: #ff3b30;
            padding: 8px 16px;
            border-radius: 10px;
            cursor: pointer;
            font-weight: 600;
        }
        
        .modal-icon {
            font-size: 5rem;
            margin-bottom: 20px;
        }
        
        .modal-title {
            font-size: 2rem;
            margin-bottom: 15px;
        }
        
        .modal-message {
            font-size: 1.1rem;
            color: rgba(255, 255, 255, 0.8);
            line-height: 1.6;
            margin-bottom: 30px;
        }
        
        .modal-btn {
            padding: 15px 40px;
            border-radius: 15px;
            border: none;
            background: linear-gradient(135deg, #2c5bf5, #4de1c1);
            color: #fff;
            font-size: 1.1rem;
            font-weight: 700;
            cursor: pointer;
            margin: 0 10px;
        }
        
        .tutorial-steps {
            text-align: left;
            margin: 20px 0;
            position: relative;
        }
        
        .tutorial-step {
            background: rgba(77, 225, 193, 0.1);
            padding: 20px;
            border-radius: 15px;
            margin-bottom: 15px;
            /* border-left: 4px solid var(--page-mint); */
            display: none;
        }
        
        .tutorial-step.active {
            display: block;
            animation: slideIn 0.3s ease;
        }
        
        @keyframes slideIn {
            from {
                opacity: 0;
                transform: translateX(-20px);
            }
            to {
                opacity: 1;
                transform: translateX(0);
            }
        }
        
        .tutorial-step h4 {
            color: var(--page-mint);
            margin-bottom: 12px;
            font-size: 1.3rem;
        }
        
        .tutorial-step p {
            line-height: 1.6;
            font-size: 1rem;
        }
        
        .tutorial-navigation {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-top: 30px;
            gap: 15px;
        }
        
        .tutorial-nav-btn {
            padding: 12px 30px;
            border-radius: 12px;
            border: none;
            background: linear-gradient(135deg, #2c5bf5, #4de1c1);
            color: #fff;
            font-size: 1rem;
            font-weight: 600;
            cursor: pointer;
            display: flex;
            align-items: center;
            gap: 8px;
            transition: all 0.3s ease;
        }
        
        .tutorial-nav-btn:hover {
            transform: scale(1.05);
        }
        
        .tutorial-nav-btn:disabled {
            opacity: 0.3;
            cursor: not-allowed;
            transform: scale(1);
        }
        
        .tutorial-progress {
            text-align: center;
            color: rgba(255, 255, 255, 0.7);
            font-size: 0.9rem;
        }
        
        .tutorial-dots {
            display: flex;
            justify-content: center;
            gap: 8px;
            margin-top: 10px;
        }
        
        .tutorial-dot {
            width: 10px;
            height: 10px;
            border-radius: 50%;
            background: rgba(255, 255, 255, 0.3);
            transition: all 0.3s ease;
        }
        
        .tutorial-dot.active {
            background: var(--page-mint);
            width: 30px;
            border-radius: 5px;
        }
        
        .exchange-input {
            width: 100%;
            padding: 15px;
            border-radius: 10px;
            border: 2px solid rgba(77, 225, 193, 0.3);
            background: rgba(255, 255, 255, 0.05);
            color: #fff;
            font-size: 1.2rem;
            margin: 20px 0;
            text-align: center;
        }
        
        .upgrade-modal .modal-content {
            border-color: rgba(251, 146, 60, 0.5);
        }
        
        @media (max-width: 768px) {
            .game-canvas-container {
                height: 500px;
                max-width: 100%;
                padding: 15px 0;
                margin: 0 10px;
            }
            
            .page-header h1 {
                font-size: 1.8rem;
            }
            
            .modal-content {
                padding: 25px;
                max-width: 95%;
            }
            
            .tutorial-navigation {
                flex-direction: column;
            }
            
            .tutorial-nav-btn {
                width: 100%;
                justify-content: center;
            }
            
            .bottom-controls {
                flex-wrap: wrap;
                justify-content: center;
            }
            
            .bet-controls {
                order: 1;
                width: 100%;
                justify-content: center;
            }
            
            .play-button {
                order: 2;
                width: 100%;
            }
            
            .info-btn {
                order: 3;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <a href="play-earn.php" class="back-link">← Back to Games</a>
        
        <div class="page-header">
            <h1>Mystery Box 3D</h1>
            <p>Choose a box and reveal your prize!</p>
        </div>
        
        <div class="game-layout">
            <div class="game-canvas-container">
                <div class="particles" id="particles"></div>
                
                <div class="top-balance-bar">
                    <div class="balance-chip" onclick="openBalanceModal('game')">
                        <span class="balance-chip-icon">💰</span>
                        <span class="balance-chip-value" id="gameBalance">₦<?php echo number_format($game_earnings, 2); ?></span>
                    </div>
                    <div class="balance-chip deposit-chip" onclick="openDepositModal()">
                        Deposit
                    </div>
                </div>
                
                <div class="canvas-wrapper">
                    <!-- Replaced Three.js canvas with CSS gift boxes -->
                    <div class="boxes-grid" id="boxesGrid">
                        <div class="mystery-box" onclick="selectBox(this, 0)">
                            <div class="box-ribbon"></div>
                            <div class="box-ribbon-horizontal"></div>
                            <div class="box-bow">🎀</div>
                            <div class="box-icon">🎁</div>
                        </div>
                        <div class="mystery-box" onclick="selectBox(this, 1)">
                            <div class="box-ribbon"></div>
                            <div class="box-ribbon-horizontal"></div>
                            <div class="box-bow">🎀</div>
                            <div class="box-icon">🎁</div>
                        </div>
                        <div class="mystery-box" onclick="selectBox(this, 2)">
                            <div class="box-ribbon"></div>
                            <div class="box-ribbon-horizontal"></div>
                            <div class="box-bow">🎀</div>
                            <div class="box-icon">🎁</div>
                        </div>
                        <div class="mystery-box" onclick="selectBox(this, 3)">
                            <div class="box-ribbon"></div>
                            <div class="box-ribbon-horizontal"></div>
                            <div class="box-bow">🎀</div>
                            <div class="box-icon">🎁</div>
                        </div>
                        <div class="mystery-box" onclick="selectBox(this, 4)">
                            <div class="box-ribbon"></div>
                            <div class="box-ribbon-horizontal"></div>
                            <div class="box-bow">🎀</div>
                            <div class="box-icon">🎁</div>
                        </div>
                        <div class="mystery-box" onclick="selectBox(this, 5)">
                            <div class="box-ribbon"></div>
                            <div class="box-ribbon-horizontal"></div>
                            <div class="box-bow">🎀</div>
                            <div class="box-icon">🎁</div>
                        </div>
                    </div>
                </div>
                
                <div class="bottom-controls">
                    <div class="bet-controls">
                        <span class="bet-label">Bet:</span>
                        <button class="bet-btn" onclick="decreaseBet()">↓</button>
                        <button class="bet-btn" onclick="decreaseBetSmall()">−</button>
                        <div class="bet-display" id="betDisplay">1</div>
                        <button class="bet-btn" onclick="increaseBetSmall()">+</button>
                        <button class="bet-btn" onclick="increaseBet()">↑</button>
                    </div>
                    <button class="play-button" id="playBtn" onclick="playGame()">PLAY</button>
                    <button class="info-btn" onclick="showTutorial()">ⓘ</button>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Tutorial Modal -->
    <div class="modal-overlay" id="tutorialModal">
        <div class="modal-content">
            <button class="modal-close" onclick="closeTutorial()">✕</button>
            <div class="modal-icon" id="tutorialIcon">🎓</div>
            <h2 class="modal-title">How to Play Mystery Box</h2>
            
            <div class="tutorial-steps">
                <div class="tutorial-step active" data-step="1">
                    <h4>Step 1: Set Your Bet</h4>
                    <p>Use the + and - buttons to adjust your bet amount. Minimum bet is ₦1,000. Your bet will be deducted from your Play Balance (referral earnings).</p>
                </div>
                <div class="tutorial-step" data-step="2">
                    <h4>Step 2: Choose a Box</h4>
                    <p>Click the orange "PLAY" button to start. Six floating 3D mystery boxes will appear. Click on any box to reveal your prize!</p>
                </div>
                <div class="tutorial-step" data-step="3">
                    <h4>Step 3: Win Rewards</h4>
                    <p>Each box contains a different multiplier (0.5x to 5.0x). Your winnings are calculated based on your bet × multiplier and added to Game Earnings! 60% win rate, 40% loss rate.</p>
                </div>
                <div class="tutorial-step" data-step="4">
                    <h4>Step 4: Exchange Earnings</h4>
                    <p>Click on your Game Earnings balance (top left) to exchange it to Task Balance anytime. Task Balance can be withdrawn to your bank account!</p>
                </div>
            </div>
            
            <div class="tutorial-progress">
                <span id="tutorialStepText">Step 1 of 4</span>
                <div class="tutorial-dots">
                    <div class="tutorial-dot active"></div>
                    <div class="tutorial-dot"></div>
                    <div class="tutorial-dot"></div>
                    <div class="tutorial-dot"></div>
                </div>
            </div>
            
            <div class="tutorial-navigation">
                <button class="tutorial-nav-btn" id="tutorialPrevBtn" onclick="previousTutorialStep()" disabled>
                    ← Back
                </button>
                <button class="tutorial-nav-btn" id="tutorialNextBtn" onclick="nextTutorialStep()">
                    Next →
                </button>
            </div>
            
            <p style="margin: 20px 0; color: rgba(255, 255, 255, 0.7);">
                Need more help? <a href="https://www.youtube.com/watch?v=mystery-box-tutorial" target="_blank" style="color: var(--page-mint);">Watch Tutorial Video</a>
            </p>
        </div>
    </div>
    
    <!-- Balance Exchange Modal -->
    <div class="modal-overlay" id="exchangeModal">
        <div class="modal-content">
            <button class="modal-close" onclick="closeExchangeModal()">✕</button>
            <div class="modal-icon">💱</div>
            <h2 class="modal-title">Exchange Game Earnings</h2>
            <p class="modal-message">Convert your Game Earnings to Task Balance for withdrawals.</p>
            <div style="background: rgba(77, 225, 193, 0.1); padding: 15px; border-radius: 10px; margin: 20px 0;">
                <p style="margin-bottom: 10px;">Available Game Earnings:</p>
                <p style="font-size: 2rem; font-weight: 700; color: var(--page-mint);" id="availableGameEarnings">₦0.00</p>
            </div>
            <input type="number" class="exchange-input" id="exchangeAmount" placeholder="Enter amount to exchange" min="100" step="100">
            <button class="modal-btn" onclick="exchangeBalance()">Exchange Now</button>
        </div>
    </div>
    
    <!-- Upgrade Required Modal -->
    <div class="modal-overlay upgrade-modal" id="upgradeModal">
        <div class="modal-content">
            <button class="modal-close" onclick="closeUpgradeModal()">✕</button>
            <div class="modal-icon">🔒</div>
            <h2 class="modal-title">Premium Membership Required</h2>
            <p class="modal-message">
                This game is exclusively for Premium Members. Upgrade now to unlock all games and start winning real rewards!
            </p>
            <div style="background: rgba(251, 146, 60, 0.1); padding: 20px; border-radius: 10px; margin: 20px 0; text-align: left;">
                <h4 style="color: var(--page-orange); margin-bottom: 15px;">Premium Benefits:</h4>
                <p style="margin-bottom: 8px;">✓ Access to all games</p>
                <p style="margin-bottom: 8px;">✓ Higher winning rates</p>
                <p style="margin-bottom: 8px;">✓ Exclusive tournaments</p>
                <p>✓ Priority support</p>
            </div>
            <button class="modal-btn" onclick="window.location.href='membership.php'" style="background: linear-gradient(135deg, #fb923c, #f97316);">
                Upgrade to Premium
            </button>
        </div>
    </div>
    
    <!-- Deposit Modal -->
    <div class="modal-overlay" id="depositModal">
        <div class="modal-content">
            <button class="modal-close" onclick="closeDepositModal()">✕</button>
            <div class="modal-icon">💳</div>
            <h2 class="modal-title">Deposit to Play</h2>
            <p class="modal-message">Add funds to your Play Balance to continue playing games.</p>
            <input type="number" class="exchange-input" id="depositAmount" placeholder="Enter amount (Min: ₦1,000)" min="1000" step="100">
            <button class="modal-btn" onclick="initiateDeposit()">Deposit with Paystack</button>
        </div>
    </div>
    
    <!-- Result Modal -->
    <div class="modal-overlay" id="resultModal">
        <div class="modal-content">
            <div class="modal-icon" id="resultIcon">🎉</div>
            <h2 class="modal-title" id="resultTitle">You Won!</h2>
            <p style="font-size: 3rem; font-weight: 900; color: var(--page-mint); margin: 20px 0;" id="resultAmount">₦0.00</p>
            <p class="modal-message" id="resultMessage">Your winnings have been added to Game Earnings!</p>
            <button class="modal-btn" onclick="closeResultModal()">Claim Reward</button>
            <button class="modal-btn" onclick="playAgain()" style="background: rgba(255, 255, 255, 0.1);">Play Again</button>
        </div>
    </div>
    
    <script>
        const PAYSTACK_PUBLIC_KEY = 'pk_test_2889acc30e717c743676ced0e02e0e1ad4d274fe';
        const USER_EMAIL = '<?php echo $user_email; ?>';
        const IS_PREMIUM = <?php echo $is_premium ? 'true' : 'false'; ?>;
        
        /* Removed Three.js code and replaced with simple CSS box selection */
        let isPlaying = false;
        let selectedBoxIndex = null;
        const multipliers = [5.0, 3.0, 2.0, 1.5, 0.8, 0.5];
        
        let currentTutorialStep = 1;
        const totalTutorialSteps = 4;
        let betAmount = 1;
        
        function createParticles() {
            const particlesContainer = document.getElementById('particles');
            for (let i = 0; i < 20; i++) {
                const particle = document.createElement('div');
                particle.className = 'particle';
                particle.style.left = Math.random() * 100 + '%';
                particle.style.animationDelay = Math.random() * 10 + 's';
                particle.style.animationDuration = (Math.random() * 10 + 10) + 's';
                particlesContainer.appendChild(particle);
            }
        }
        
        createParticles();
        
        if (!localStorage.getItem('mysterybox_tutorial_seen') === 'true') {
            document.getElementById('tutorialModal').classList.add('active');
        }
        
        function showTutorial() {
            currentTutorialStep = 1;
            updateTutorialDisplay();
            document.getElementById('tutorialModal').classList.add('active');
        }
        
        function nextTutorialStep() {
            if (currentTutorialStep < totalTutorialSteps) {
                currentTutorialStep++;
                updateTutorialDisplay();
            } else {
                closeTutorial();
            }
        }
        
        function previousTutorialStep() {
            if (currentTutorialStep > 1) {
                currentTutorialStep--;
                updateTutorialDisplay();
            }
        }
        
        function updateTutorialDisplay() {
            document.querySelectorAll('.tutorial-step').forEach((step, index) => {
                step.classList.toggle('active', index + 1 === currentTutorialStep);
            });
            
            document.querySelectorAll('.tutorial-dot').forEach((dot, index) => {
                dot.classList.toggle('active', index + 1 === currentTutorialStep);
            });
            
            document.getElementById('tutorialStepText').textContent = `Step ${currentTutorialStep} of ${totalTutorialSteps}`;
            document.getElementById('tutorialPrevBtn').disabled = currentTutorialStep === 1;
            document.getElementById('tutorialNextBtn').textContent = currentTutorialStep === totalTutorialSteps ? "Let's Play! 🎮" : "Next →";
            
            const icons = ['🎓', '🎁', '🎰', '💱'];
            document.getElementById('tutorialIcon').textContent = icons[currentTutorialStep - 1];
        }
        
        function closeTutorial() {
            localStorage.setItem('mysterybox_tutorial_seen', 'true');
            document.getElementById('tutorialModal').classList.remove('active');
        }
        
        function increaseBet() {
            betAmount = Math.min(betAmount + 5, 100);
            updateBetDisplay();
        }
        
        function decreaseBet() {
            betAmount = Math.max(betAmount - 5, 1);
            updateBetDisplay();
        }
        
        function increaseBetSmall() {
            betAmount = Math.min(betAmount + 1, 100);
            updateBetDisplay();
        }
        
        function decreaseBetSmall() {
            betAmount = Math.max(betAmount - 1, 1);
            updateBetDisplay();
        }
        
        function updateBetDisplay() {
            document.getElementById('betDisplay').textContent = '₦' + (betAmount * 1000).toLocaleString();
        }
        
        async function playGame() {
            if (isPlaying) return;
            
            if (!IS_PREMIUM) {
                document.getElementById('upgradeModal').classList.add('active');
                return;
            }
            
            isPlaying = true;
            selectedBoxIndex = null;
            document.getElementById('playBtn').disabled = true;
            
            // Enable all boxes for selection
            document.querySelectorAll('.mystery-box').forEach(box => {
                box.classList.remove('disabled');
            });
        }
        
        async function selectBox(boxElement, index) {
            if (!isPlaying || selectedBoxIndex !== null) return;
            
            selectedBoxIndex = index;
            const actualBetAmount = betAmount * 1000;
            
            // Disable all other boxes
            document.querySelectorAll('.mystery-box').forEach((box, i) => {
                if (i !== index) {
                    box.classList.add('disabled');
                }
            });
            
            // Animate the selected box opening
            boxElement.classList.add('opening');
            
            // Wait for animation to complete
            setTimeout(async () => {
                try {
                    const response = await fetch('api/mystery-box-play.php', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ bet_amount: actualBetAmount })
                    });
                    
                    const data = await response.json();
                    
                    if (data.success) {
                        document.getElementById('gameBalance').textContent = '₦' + parseFloat(data.game_earnings).toLocaleString('en-NG', {minimumFractionDigits: 2, maximumFractionDigits: 2});
                        showResult(data.win_amount, data.multiplier);
                    } else {
                        if (data.upgrade_required) {
                            document.getElementById('upgradeModal').classList.add('active');
                        } else if (data.insufficient_balance) {
                            document.getElementById('depositModal').classList.add('active');
                        } else {
                            alert(data.message || 'An error occurred');
                        }
                    }
                } catch (error) {
                    console.error('Error:', error);
                    alert('Connection error. Please try again.');
                }
                
                isPlaying = false;
                document.getElementById('playBtn').disabled = false;
            }, 800);
        }
        
        function showResult(amount, multiplier) {
            const resultModal = document.getElementById('resultModal');
            const resultIcon = document.getElementById('resultIcon');
            const resultTitle = document.getElementById('resultTitle');
            const resultAmount = document.getElementById('resultAmount');
            const resultMessage = document.getElementById('resultMessage');
            
            if (multiplier >= 3) {
                resultIcon.textContent = '🎁';
                resultTitle.textContent = 'JACKPOT!';
            } else if (multiplier >= 1.5) {
                resultIcon.textContent = '🎉';
                resultTitle.textContent = 'Big Win!';
            } else if (multiplier > 1) {
                resultIcon.textContent = '✨';
                resultTitle.textContent = 'You Won!';
            } else {
                resultIcon.textContent = '😔';
                resultTitle.textContent = 'Try Again!';
            }
            
            resultAmount.textContent = '₦' + parseFloat(amount).toLocaleString('en-NG', {minimumFractionDigits: 2, maximumFractionDigits: 2});
            resultMessage.textContent = multiplier > 0 ? 'Your winnings have been added to Game Earnings!' : 'Better luck next time!';
            resultModal.classList.add('active');
        }
        
        function closeResultModal() {
            document.getElementById('resultModal').classList.remove('active');
            // Reset all boxes
            document.querySelectorAll('.mystery-box').forEach(box => {
                box.classList.remove('opening', 'disabled');
            });
        }
        
        function playAgain() {
            closeResultModal();
        }
        
        function openBalanceModal(type) {
            if (type === 'game') {
                const gameBalance = document.getElementById('gameBalance').textContent.replace('₦', '').replace(/,/g, '');
                document.getElementById('availableGameEarnings').textContent = '₦' + parseFloat(gameBalance).toLocaleString('en-NG', {minimumFractionDigits: 2, maximumFractionDigits: 2});
                document.getElementById('exchangeModal').classList.add('active');
            }
        }
        
        function closeExchangeModal() {
            document.getElementById('exchangeModal').classList.remove('active');
        }
        
        async function exchangeBalance() {
            const amount = parseFloat(document.getElementById('exchangeAmount').value);
            
            if (isNaN(amount) || amount <= 0) {
                alert('Please enter a valid amount');
                return;
            }
            
            try {
                const response = await fetch('api/exchange-balance.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ amount })
                });
                
                const data = await response.json();
                
                if (data.success) {
                    document.getElementById('gameBalance').textContent = '₦' + parseFloat(data.game_earnings).toLocaleString('en-NG', {minimumFractionDigits: 2, maximumFractionDigits: 2});
                    alert('Balance exchanged successfully to Task Balance!');
                    closeExchangeModal();
                    setTimeout(() => location.reload(), 1000);
                } else {
                    alert(data.message || 'Exchange failed');
                }
            } catch (error) {
                console.error('Error:', error);
                alert('Connection error. Please try again.');
            }
        }
        
        function closeUpgradeModal() {
            document.getElementById('upgradeModal').classList.remove('active');
        }
        
        function openDepositModal() {
            document.getElementById('depositModal').classList.add('active');
        }
        
        function closeDepositModal() {
            document.getElementById('depositModal').classList.remove('active');
        }
        
        async function initiateDeposit() {
            const amount = parseFloat(document.getElementById('depositAmount').value);
            
            if (isNaN(amount) || amount < 1000) {
                alert('Minimum deposit is ₦1,000');
                return;
            }
            
            try {
                const response = await fetch('api/paystack-deposit.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        action: 'initialize',
                        amount: amount,
                        email: USER_EMAIL
                    })
                });
                
                const data = await response.json();
                
                if (data.success) {
                    window.location.href = data.authorization_url;
                } else {
                    alert(data.message || 'Failed to initialize payment');
                }
            } catch (error) {
                console.error('Error:', error);
                alert('Connection error. Please try again.');
            }
        }
        
        const urlParams = new URLSearchParams(window.location.search);
        const reference = urlParams.get('reference');
        if (reference) {
            verifyPayment(reference);
        }
        
        async function verifyPayment(reference) {
            try {
                const response = await fetch('api/paystack-deposit.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        action: 'verify',
                        reference: reference
                    })
                });
                
                const data = await response.json();
                
                if (data.success) {
                    alert('Deposit successful! ₦' + data.amount.toLocaleString('en-NG') + ' has been added to your Play Balance.');
                    window.location.href = 'mystery-box-3d.php';
                } else {
                    alert('Payment verification failed');
                }
            } catch (error) {
                console.error('Error:', error);
            }
        }
    </script>
</body>
</html>
