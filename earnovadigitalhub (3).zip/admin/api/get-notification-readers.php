<?php
header('Content-Type: application/json');
session_start();
require_once '../../config/database.php';

// Check if user is admin
if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode(['error' => 'Unauthorized']);
    exit;
}

$user_id = $_SESSION['user_id'];
$stmt = $conn->prepare("SELECT is_admin FROM users WHERE id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result()->fetch_assoc();

if (!$result || $result['is_admin'] != 1) {
    http_response_code(403);
    echo json_encode(['error' => 'Forbidden']);
    exit;
}

if (!isset($_GET['message_id'])) {
    http_response_code(400);
    echo json_encode(['error' => 'message_id required']);
    exit;
}

$message_id = intval($_GET['message_id']);

// Fetch users who read this notification
$query = "
    SELECT u.id, u.username, u.email, umr.read_at
    FROM user_message_reads umr
    JOIN users u ON umr.user_id = u.id
    WHERE umr.message_id = ?
    ORDER BY umr.read_at DESC
";
$stmt = $conn->prepare($query);
if (!$stmt) {
    http_response_code(500);
    echo json_encode(['error' => $conn->error]);
    exit;
}

$stmt->bind_param("i", $message_id);
$stmt->execute();
$result = $stmt->get_result();
$readers = $result->fetch_all(MYSQLI_ASSOC);

echo json_encode(['readers' => $readers]);
?>
