<?php
session_start();
require_once '../config/database.php';

header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit;
}

$user_id = $_SESSION['user_id'];
$stmt = $conn->prepare("SELECT is_admin FROM users WHERE id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$result || $result['is_admin'] != 1) {
    echo json_encode(['success' => false, 'message' => 'Admin access required']);
    exit;
}

$target_user_id = intval($_POST['user_id'] ?? 0);
$field = $_POST['field'] ?? '';
$value = $_POST['value'] ?? '';

if (!$target_user_id) {
    echo json_encode(['success' => false, 'message' => 'Invalid user ID']);
    exit;
}

try {
    switch ($field) {
        case 'status':
            $stmt = $conn->prepare("UPDATE users SET status = ? WHERE id = ?");
            $stmt->bind_param("si", $value, $target_user_id);
            if ($stmt->execute()) {
                $status_text = ($value === 'banned') ? 'suspended' : 'unsuspended';
                echo json_encode(['success' => true, 'message' => 'User ' . $status_text . ' successfully']);
            } else {
                echo json_encode(['success' => false, 'message' => 'Failed to update status']);
            }
            $stmt->close();
            break;

        case 'membership_type':
            if ($value === 'premium_plus') {
                $stmt = $conn->prepare("UPDATE users SET membership_type = 'premium', advertiser_plan = 'senior', advertiser_plan_start_date = NOW() WHERE id = ?");
                $stmt->bind_param("i", $target_user_id);
                if ($stmt->execute()) {
                    echo json_encode(['success' => true, 'message' => 'Plan changed to Premium Plus']);
                } else {
                    echo json_encode(['success' => false, 'message' => 'Failed to update membership']);
                }
            } elseif ($value === 'premium') {
                $stmt = $conn->prepare("UPDATE users SET membership_type = 'premium', advertiser_plan = NULL WHERE id = ?");
                $stmt->bind_param("i", $target_user_id);
                if ($stmt->execute()) {
                    echo json_encode(['success' => true, 'message' => 'Plan changed to Premium']);
                } else {
                    echo json_encode(['success' => false, 'message' => 'Failed to update membership']);
                }
            } elseif ($value === 'free') {
                $stmt = $conn->prepare("UPDATE users SET membership_type = 'free', advertiser_plan = NULL WHERE id = ?");
                $stmt->bind_param("i", $target_user_id);
                if ($stmt->execute()) {
                    echo json_encode(['success' => true, 'message' => 'Plan changed to Free']);
                } else {
                    echo json_encode(['success' => false, 'message' => 'Failed to update membership']);
                }
            } else {
                echo json_encode(['success' => false, 'message' => 'Invalid membership type']);
            }
            $stmt->close();
            break;

        case 'add_earnings':
            // ADD to existing earnings
            $earnings = json_decode($value, true);
            if (!is_array($earnings)) {
                echo json_encode(['success' => false, 'message' => 'Invalid earnings data']);
                exit;
            }
            
            $task_add = floatval($earnings['task_earnings'] ?? 0);
            $referral_add = floatval($earnings['referral_earnings'] ?? 0);
            $game_add = floatval($earnings['game_earnings'] ?? 0);
            
            $check_stmt = $conn->prepare("SELECT task_earnings, referral_earnings, game_earnings, total_balance FROM balances WHERE user_id = ?");
            $check_stmt->bind_param("i", $target_user_id);
            $check_stmt->execute();
            $result = $check_stmt->get_result()->fetch_assoc();
            $check_stmt->close();
            
            if ($result) {
                // ADD to existing values
                $new_task = floatval($result['task_earnings'] ?? 0) + $task_add;
                $new_referral = floatval($result['referral_earnings'] ?? 0) + $referral_add;
                $new_game = floatval($result['game_earnings'] ?? 0) + $game_add;
                $new_total = $new_task + $new_referral + $new_game;
                
                $update_stmt = $conn->prepare("UPDATE balances SET task_earnings = ?, referral_earnings = ?, game_earnings = ?, total_balance = ? WHERE user_id = ?");
                $update_stmt->bind_param("ddddi", $new_task, $new_referral, $new_game, $new_total, $target_user_id);
                if ($update_stmt->execute()) {
                    $added_total = $task_add + $referral_add + $game_add;
                    echo json_encode(['success' => true, 'message' => '₦' . number_format($added_total, 2) . ' ADDED to earnings. New total: ₦' . number_format($new_total, 2)]);
                } else {
                    echo json_encode(['success' => false, 'message' => 'Failed to add to earnings']);
                }
                $update_stmt->close();
            } else {
                // Create new balance record
                $total = $task_add + $referral_add + $game_add;
                $insert_stmt = $conn->prepare("INSERT INTO balances (user_id, task_earnings, referral_earnings, game_earnings, total_balance, ad_commission_earnings) VALUES (?, ?, ?, ?, ?, 0)");
                $insert_stmt->bind_param("idddd", $target_user_id, $task_add, $referral_add, $game_add, $total);
                if ($insert_stmt->execute()) {
                    echo json_encode(['success' => true, 'message' => 'Earnings added successfully. Total: ₦' . number_format($total, 2)]);
                } else {
                    echo json_encode(['success' => false, 'message' => 'Failed to create earnings record']);
                }
                $insert_stmt->close();
            }
            break;

        case 'add_balance':
            // ADD to existing total_balance
            $amount = floatval($value);
            if ($amount <= 0) {
                echo json_encode(['success' => false, 'message' => 'Amount must be greater than 0']);
                exit;
            }
            
            $stmt = $conn->prepare("UPDATE balances SET total_balance = total_balance + ? WHERE user_id = ?");
            $stmt->bind_param("di", $amount, $target_user_id);
            
            if ($stmt->execute()) {
                if ($stmt->affected_rows === 0) {
                    $insert_stmt = $conn->prepare("INSERT INTO balances (user_id, total_balance, task_earnings, referral_earnings, game_earnings, ad_commission_earnings) VALUES (?, ?, 0, 0, 0, 0)");
                    $insert_stmt->bind_param("id", $target_user_id, $amount);
                    $insert_stmt->execute();
                    $insert_stmt->close();
                }
                echo json_encode(['success' => true, 'message' => '₦' . number_format($amount, 2) . ' ADDED to balance']);
            } else {
                echo json_encode(['success' => false, 'message' => 'Failed to add balance']);
            }
            $stmt->close();
            break;

        case 'subtract_balance':
            // SUBTRACT from specific earning type AND total_balance
            $data = json_decode($value, true);
            $amount = floatval($data['amount'] ?? 0);
            $source = $data['source'] ?? 'task';
            
            if ($amount <= 0) {
                echo json_encode(['success' => false, 'message' => 'Amount must be greater than 0']);
                exit;
            }
            
            // Validate source
            if (!in_array($source, ['task', 'referral', 'game'])) {
                echo json_encode(['success' => false, 'message' => 'Invalid source type']);
                exit;
            }
            
            // Check current balances
            $source_column = $source . '_earnings';
            $check_stmt = $conn->prepare("SELECT total_balance, " . $source_column . " FROM balances WHERE user_id = ?");
            $check_stmt->bind_param("i", $target_user_id);
            $check_stmt->execute();
            $balance_result = $check_stmt->get_result()->fetch_assoc();
            $check_stmt->close();
            
            if (!$balance_result) {
                echo json_encode(['success' => false, 'message' => 'User has no balance record']);
                exit;
            }
            
            $current_total = floatval($balance_result['total_balance'] ?? 0);
            $current_source = floatval($balance_result[$source_column] ?? 0);
            
            // Check if enough in both total and source
            if ($current_total < $amount) {
                echo json_encode(['success' => false, 'message' => 'Insufficient total balance. Current: ₦' . number_format($current_total, 2)]);
                exit;
            }
            
            if ($current_source < $amount) {
                echo json_encode(['success' => false, 'message' => 'Insufficient ' . ucfirst($source) . ' Earnings. Current: ₦' . number_format($current_source, 2)]);
                exit;
            }
            
            // Deduct from both the specific earning type and total_balance
            $update_sql = "UPDATE balances SET " . $source_column . " = " . $source_column . " - ?, total_balance = total_balance - ? WHERE user_id = ?";
            $stmt = $conn->prepare($update_sql);
            $stmt->bind_param("ddi", $amount, $amount, $target_user_id);
            
            if ($stmt->execute()) {
                $new_source = $current_source - $amount;
                $new_total = $current_total - $amount;
                echo json_encode(['success' => true, 'message' => '₦' . number_format($amount, 2) . ' DEDUCTED from ' . ucfirst($source) . ' Earnings and Total Balance. New ' . ucfirst($source) . ': ₦' . number_format($new_source, 2) . ', New Total: ₦' . number_format($new_total, 2)]);
            } else {
                echo json_encode(['success' => false, 'message' => 'Failed to subtract balance']);
            }
            $stmt->close();
            break;

        case 'delete':
            $stmt = $conn->prepare("DELETE FROM users WHERE id = ?");
            $stmt->bind_param("i", $target_user_id);
            if ($stmt->execute()) {
                echo json_encode(['success' => true, 'message' => 'User account deleted permanently']);
            } else {
                echo json_encode(['success' => false, 'message' => 'Failed to delete user']);
            }
            $stmt->close();
            break;

        default:
            echo json_encode(['success' => false, 'message' => 'Invalid operation']);
    }
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => 'Server error: ' . $e->getMessage()]);
}
?>
