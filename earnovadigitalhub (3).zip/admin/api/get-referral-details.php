<?php
session_start();
require_once '../../config/database.php';

header('Content-Type: application/json');

try {
    // Check if user is admin
    if (!isset($_SESSION['user_id'])) {
        http_response_code(401);
        echo json_encode(['error' => 'Unauthorized']);
        exit();
    }

    $user_id = $_SESSION['user_id'];
    $stmt = $conn->prepare("SELECT is_admin FROM users WHERE id = ?");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $admin_check = $stmt->get_result()->fetch_assoc();

    if (!$admin_check || $admin_check['is_admin'] != 1) {
        http_response_code(403);
        echo json_encode(['error' => 'Forbidden']);
        exit();
    }

    // Get referrer ID from request
    $referrer_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

    if ($referrer_id <= 0) {
        http_response_code(400);
        echo json_encode(['error' => 'Invalid referrer ID']);
        exit();
    }

    // Fetch referrer details
    $stmt = $conn->prepare("SELECT id, username, email, membership_type, advertiser_plan, profile_picture, referral_code, created_at FROM users WHERE id = ?");
    $stmt->bind_param("i", $referrer_id);
    $stmt->execute();
    $referrer = $stmt->get_result()->fetch_assoc();

    if (!$referrer) {
        http_response_code(404);
        echo json_encode(['error' => 'User not found']);
        exit();
    }

    // Determine account type
    $account_type = 'Free';
    if ($referrer['membership_type'] === 'premium') {
        $account_type = ($referrer['advertiser_plan'] === 'senior') ? 'Premium Plus' : 'Premium';
    }

    // Fetch downlines breakdown
    $stmt = $conn->prepare("
        SELECT 
            COUNT(*) as total_downline,
            SUM(CASE WHEN membership_type = 'free' THEN 1 ELSE 0 END) as free_count,
            SUM(CASE WHEN membership_type = 'premium' AND (advertiser_plan IS NULL OR advertiser_plan != 'senior') THEN 1 ELSE 0 END) as premium_count,
            SUM(CASE WHEN membership_type = 'premium' AND advertiser_plan = 'senior' THEN 1 ELSE 0 END) as premium_plus_count
        FROM users WHERE referred_by = ?
    ");
    $stmt->bind_param("i", $referrer_id);
    $stmt->execute();
    $downline_stats = $stmt->get_result()->fetch_assoc();

    // Fetch all downlines
    $stmt = $conn->prepare("
        SELECT 
            u.id,
            u.username,
            u.email,
            u.membership_type,
            u.advertiser_plan,
            u.created_at,
            COALESCE(b.total_balance, 0) as total_balance,
            COALESCE(b.task_earnings, 0) as task_earnings,
            COALESCE(b.referral_earnings, 0) as referral_earnings,
            COALESCE(b.game_earnings, 0) as game_earnings
        FROM users u
        LEFT JOIN balances b ON u.id = b.user_id
        WHERE u.referred_by = ?
        ORDER BY u.created_at DESC
    ");
    $stmt->bind_param("i", $referrer_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $downlines = $result->fetch_all(MYSQLI_ASSOC) ?: [];

    // Fetch referrer's balance
    $stmt = $conn->prepare("SELECT COALESCE(total_balance, 0) as total_balance, COALESCE(task_earnings, 0) as task_earnings, COALESCE(referral_earnings, 0) as referral_earnings, COALESCE(game_earnings, 0) as game_earnings, COALESCE(ad_commission_earnings, 0) as ad_commission_earnings FROM balances WHERE user_id = ?");
    $stmt->bind_param("i", $referrer_id);
    $stmt->execute();
    $balance = $stmt->get_result()->fetch_assoc();

    if (!$balance) {
        $balance = [
            'total_balance' => 0,
            'task_earnings' => 0,
            'referral_earnings' => 0,
            'game_earnings' => 0,
            'ad_commission_earnings' => 0
        ];
    }

    // Build response
    $response = [
        'referrer' => $referrer,
        'account_type' => $account_type,
        'balance' => $balance,
        'downline_stats' => [
            'total' => intval($downline_stats['total_downline'] ?? 0),
            'free' => intval($downline_stats['free_count'] ?? 0),
            'premium' => intval($downline_stats['premium_count'] ?? 0),
            'premium_plus' => intval($downline_stats['premium_plus_count'] ?? 0)
        ],
        'downlines' => $downlines
    ];

    http_response_code(200);
    echo json_encode($response);

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Server error: ' . $e->getMessage()]);
}
?>
