<?php
session_start();
require_once '../config/database2.php';

// Check if user is logged in and is admin
if (!isset($_SESSION['user_id'])) {
    header('Location: ../login.php');
    exit();
}

$user_id = $_SESSION['user_id'];

// Check if user is admin
$stmt = $pdo->prepare("SELECT is_admin FROM users WHERE id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch();

if (!$user || !$user['is_admin']) {
    header('Location: ../dashboard.php');
    exit();
}

// Get filter
$filter = $_GET['filter'] ?? 'all';
$search = $_GET['search'] ?? '';

// Build query
$query = "SELECT t.*, u.username, u.email 
          FROM transactions t 
          JOIN users u ON t.user_id = u.id 
          WHERE 1=1";

$params = [];

if ($filter !== 'all') {
    $query .= " AND t.transaction_type = :type";
    $params['type'] = $filter;
}

if ($search) {
    $query .= " AND (u.username LIKE :search OR u.email LIKE :search OR t.description LIKE :search)";
    $params['search'] = "%$search%";
}

$query .= " ORDER BY t.created_at DESC LIMIT 100";

$stmt = $pdo->prepare($query);
$stmt->execute($params);
$transactions = $stmt->fetchAll();

// Get stats
$stmt = $pdo->query("SELECT 
    COUNT(*) as total,
    SUM(CASE WHEN transaction_type = 'withdraw' THEN amount ELSE 0 END) as total_credits,
    SUM(CASE WHEN transaction_type = 'deposit' THEN amount ELSE 0 END) as total_debits,
    COUNT(CASE WHEN DATE(created_at) = CURDATE() THEN 1 END) as today_count
    FROM transactions");
$stats = $stmt->fetch();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Transactions - FlowEarner Admin</title>
    <link rel="stylesheet" href="../css/style.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px;
        }

       
        .admin-main {
            flex: 1;
        }

        .admin-header {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            padding: 30px;
            margin-bottom: 20px;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
        }

        .admin-header h1 {
            color: #2d3748;
            font-size: 32px;
            margin-bottom: 10px;
        }

        .admin-header p {
            color: #718096;
            font-size: 16px;
        }

        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 20px;
        }

        .stat-card {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 15px;
            padding: 25px;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
        }

        .stat-card h3 {
            color: #718096;
            font-size: 14px;
            margin-bottom: 10px;
            text-transform: uppercase;
        }

        .stat-card .value {
            color: #2d3748;
            font-size: 32px;
            font-weight: bold;
        }

        .filters-section {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 15px;
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
            display: flex;
            gap: 15px;
            flex-wrap: wrap;
            align-items: center;
        }

        .search-box {
            flex: 1;
            min-width: 250px;
        }

        .search-box input {
            width: 100%;
            padding: 12px 20px;
            border: 2px solid #e2e8f0;
            border-radius: 10px;
            font-size: 14px;
        }

        .filter-tabs {
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
        }

        .filter-tab {
            padding: 10px 20px;
            background: white;
            border: 2px solid #e2e8f0;
            border-radius: 10px;
            cursor: pointer;
            font-size: 14px;
            color: #4a5568;
            text-decoration: none;
            transition: all 0.3s;
        }

        .filter-tab:hover, .filter-tab.active {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border-color: transparent;
        }

        .transactions-table {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            padding: 30px;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
            overflow-x: auto;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th {
            text-align: left;
            padding: 15px;
            color: #4a5568;
            font-weight: 600;
            border-bottom: 2px solid #e2e8f0;
        }

        td {
            padding: 15px;
            color: #2d3748;
            border-bottom: 1px solid #e2e8f0;
        }

        .type-badge {
            display: inline-block;
            padding: 5px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
        }

        .type-credit {
            background: #d1fae5;
            color: #065f46;
        }

        .type-debit {
            background: #fee2e2;
            color: #991b1b;
        }

        .type-deposit {
            background: #fee2e2;
            color: #991b1b;
        }

        .type-withdraw {
            background: #d1fae5;
            color: #065f46;
        }

        @media (max-width: 768px) {
            body {
                padding: 12px;
            }

            .admin-main {
                padding: 0;
            }

            .admin-header {
                padding: 16px;
                margin-bottom: 12px;
                border-radius: 12px;
            }

            .admin-header h1 {
                font-size: 18px;
                margin-bottom: 4px;
            }

            .admin-header p {
                font-size: 12px;
            }

            .stats-grid {
                grid-template-columns: 1fr 1fr;
                gap: 10px;
                margin-bottom: 12px;
            }

            .stat-card {
                padding: 12px;
                border-radius: 10px;
            }

            .stat-card h3 {
                font-size: 11px;
                margin-bottom: 4px;
            }

            .stat-card .value {
                font-size: 18px;
            }

            .filters-section {
                padding: 12px;
                margin-bottom: 12px;
                flex-direction: column;
                gap: 10px;
                border-radius: 10px;
            }

            .search-box {
                width: 100%;
                min-width: 100%;
            }

            .search-box input {
                padding: 10px 12px;
                font-size: 14px;
            }

            .filter-tabs {
                gap: 6px;
                width: 100%;
                justify-content: flex-start;
            }

            .filter-tab {
                padding: 8px 12px;
                font-size: 11px;
                border-radius: 6px;
            }

            .transactions-table {
                padding: 12px;
                border-radius: 10px;
                overflow-x: auto;
                -webkit-overflow-scrolling: touch;
            }

            table {
                min-width: 700px;
                display: inline-block;
            }

            th {
                padding: 8px;
                font-size: 11px;
            }

            td {
                padding: 8px;
                font-size: 10px;
            }

            .type-badge {
                padding: 3px 8px;
                font-size: 9px;
            }
        }
    </style>
</head>
<body>
     <?php include 'side-bar.php'; ?>
<div class="admin-content">
        
        <main class="admin-main">
            <div class="admin-header">
                <h1>All Transactions</h1>
                <p>View and monitor all platform transactions</p>
            </div>

             Stats 
            <div class="stats-grid">
                <div class="stat-card">
                    <h3>Total Transactions</h3>
                    <div class="value"><?php echo number_format($stats['total']); ?></div>
                </div>
                <div class="stat-card">
                    <h3>Total Credits</h3>
                    <div class="value" style="color: #10b981;">₦<?php echo number_format($stats['total_credits'], 2); ?></div>
                </div>
                <div class="stat-card">
                    <h3>Total Debits</h3>
                    <div class="value" style="color: #ef4444;">₦<?php echo number_format($stats['total_debits'], 2); ?></div>
                </div>
                <div class="stat-card">
                    <h3>Today's Transactions</h3>
                    <div class="value"><?php echo number_format($stats['today_count']); ?></div>
                </div>
            </div>

             Filters 
            <div class="filters-section">
                <div class="search-box">
                    <form method="GET">
                        <input type="text" name="search" placeholder="Search by username, email, or description..." value="<?php echo htmlspecialchars($search); ?>">
                        <input type="hidden" name="filter" value="<?php echo $filter; ?>">
                    </form>
                </div>
                <div class="filter-tabs">
                    <a href="?filter=all&search=<?php echo urlencode($search); ?>" class="filter-tab <?php echo $filter === 'all' ? 'active' : ''; ?>">All</a>
                    <a href="?filter=withdrawal&search=<?php echo urlencode($search); ?>" class="filter-tab <?php echo $filter === 'withdrawal' ? 'active' : ''; ?>">Withdrawals</a>
                    <a href="?filter=deposit&search=<?php echo urlencode($search); ?>" class="filter-tab <?php echo $filter === 'deposit' ? 'active' : ''; ?>">Deposits</a>
                </div>
            </div>

             Transactions Table 
            <div class="transactions-table">
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>User</th>
                            <th>Type</th>
                            <th>Amount</th>
                            <th>Description</th>
                            <th>Date</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($transactions as $transaction): ?>
                            <tr>
                                <td>#<?php echo $transaction['id']; ?></td>
                                <td>
                                    <strong><?php echo htmlspecialchars($transaction['username']); ?></strong><br>
                                    <small><?php echo htmlspecialchars($transaction['email']); ?></small>
                                </td>
                                <td>
                                    <span class="type-badge type-<?php echo $transaction['transaction_type']; ?>">
                                        <?php echo ucfirst($transaction['transaction_type']); ?>
                                    </span>
                                </td>
                                <td>
                                    <strong style="color: <?php echo $transaction['transaction_type'] === 'credit' ? '#10b981' : '#ef4444'; ?>">
                                        <?php echo $transaction['transaction_type'] === 'credit' ? '+' : '-'; ?>₦<?php echo number_format($transaction['amount'], 2); ?>
                                    </strong>
                                </td>
                                <td><?php echo htmlspecialchars($transaction['description']); ?></td>
                                <td><?php echo date('M d, Y H:i', strtotime($transaction['created_at'])); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </main>
    </div>
</body>
</html>
