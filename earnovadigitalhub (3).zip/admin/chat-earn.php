<?php
session_start();
require_once '../config/database2.php';

// Check if user is logged in and is admin
if (!isset($_SESSION['user_id'])) {
    header('Location: ../login.php');
    exit();
}

$user_id = $_SESSION['user_id'];

// Check if user is admin
$stmt = $pdo->prepare("SELECT is_admin, advertiser_plan FROM users WHERE id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch();

if (!$user || !$user['is_admin']) {
    header('Location: ../dashboard.php');
    exit();
}

// Check if user is premium plus (advertiser_plan = 'senior')
if ($user['advertiser_plan'] !== 'senior') {
    header('Location: ../dashboard.php');
    exit();
}

// Get Chat & Earn stats - ONLY for premium plus users (advertiser_plan = 'senior')
$stmt = $pdo->query("SELECT 
    COUNT(*) as total_users,
    COUNT(CASE WHEN chat_earn_enabled = 1 THEN 1 END) as enabled_users,
    COUNT(CASE WHEN gender = 'male' AND chat_earn_enabled = 1 THEN 1 END) as male_users,
    COUNT(CASE WHEN gender = 'female' AND chat_earn_enabled = 1 THEN 1 END) as female_users
    FROM users 
    WHERE advertiser_plan = 'senior'");
$stats = $stmt->fetch();

// Get total pairings
$stmt = $pdo->query("SELECT COUNT(*) as total_pairings FROM chat_earn_history");
$pairing_stats = $stmt->fetch();

// Get today's pairings
$stmt = $pdo->query("SELECT COUNT(*) as today_pairings FROM chat_earn_history WHERE DATE(paired_at) = CURDATE()");
$today_stats = $stmt->fetch();

// Get recent pairings
$stmt = $pdo->query("SELECT ceh.*, 
    u1.username as user1_name, u1.whatsapp_number as user1_whatsapp,
    u2.username as user2_name, u2.whatsapp_number as user2_whatsapp
    FROM chat_earn_history ceh
    JOIN users u1 ON ceh.user_id = u1.id
    JOIN users u2 ON ceh.paired_user_id = u2.id
    ORDER BY ceh.paired_at DESC
    LIMIT 50");
$recent_pairings = $stmt->fetchAll();

// Get users with Chat & Earn enabled - ONLY premium plus users
$search_query = $_GET['search'] ?? '';
$search_param = '%' . $search_query . '%';

if ($search_query) {
    $stmt = $pdo->prepare("SELECT id, username, email, gender, whatsapp_number, chat_earn_last_paired, advertiser_plan
        FROM users 
        WHERE chat_earn_enabled = 1 AND advertiser_plan = 'senior' AND (username LIKE ? OR email LIKE ?)
        ORDER BY chat_earn_last_paired DESC");
    $stmt->execute([$search_param, $search_param]);
} else {
    $stmt = $pdo->query("SELECT id, username, email, gender, whatsapp_number, chat_earn_last_paired, advertiser_plan
        FROM users 
        WHERE chat_earn_enabled = 1 AND advertiser_plan = 'senior'
        ORDER BY chat_earn_last_paired DESC");
}
$active_users = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Chat & Earn - FlowEarner Admin</title>
    <link rel="stylesheet" href="../css/style.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px;
        }

       
        .admin-main {
            flex: 1;
        }

        .admin-header {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            padding: 30px;
            margin-bottom: 20px;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
        }

        .admin-header h1 {
            color: #2d3748;
            font-size: 32px;
            margin-bottom: 10px;
        }

        .admin-header p {
            color: #718096;
            font-size: 16px;
        }

        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 20px;
        }

        .stat-card {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 15px;
            padding: 25px;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
        }

        .stat-card h3 {
            color: #718096;
            font-size: 14px;
            margin-bottom: 10px;
            text-transform: uppercase;
        }

        .stat-card .value {
            color: #2d3748;
            font-size: 32px;
            font-weight: bold;
        }

        .content-section {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            padding: 30px;
            margin-bottom: 20px;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
        }

        .content-section h2 {
            color: #2d3748;
            font-size: 24px;
            margin-bottom: 20px;
        }

        .table-wrapper {
            overflow-x: auto;
            -webkit-overflow-scrolling: touch;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            min-width: 600px;
        }

        th {
            text-align: left;
            padding: 15px;
            color: #4a5568;
            font-weight: 600;
            border-bottom: 2px solid #e2e8f0;
        }

        td {
            padding: 15px;
            color: #2d3748;
            border-bottom: 1px solid #e2e8f0;
        }

        .gender-badge {
            display: inline-block;
            padding: 5px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
        }

        .gender-male {
            background: #dbeafe;
            color: #1e40af;
        }

        .gender-female {
            background: #fce7f3;
            color: #9f1239;
        }

        .search-container {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
        }

        .search-form {
            display: flex;
            gap: 12px;
            align-items: center;
        }

        .search-form input {
            flex: 1;
            padding: 12px 16px;
            border: 1px solid #e2e8f0;
            border-radius: 10px;
            font-size: 14px;
            color: #2d3748;
            transition: border-color 0.3s ease;
        }

        .search-form input:focus {
            outline: none;
            border-color: #667eea;
            box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
        }

        .search-form button {
            padding: 12px 24px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border: none;
            border-radius: 10px;
            cursor: pointer;
            font-weight: 600;
            transition: transform 0.2s ease;
        }

        .search-form button:hover {
            transform: translateY(-2px);
        }

        .search-form button:active {
            transform: translateY(0);
        }

        .search-results {
            color: #718096;
            font-size: 14px;
            padding: 0 16px;
            white-space: nowrap;
        }

        @media (max-width: 1024px) {
            .stats-grid {
                grid-template-columns: repeat(3, 1fr);
                gap: 12px;
            }

            .stat-card {
                padding: 16px;
            }

            .stat-card h3 {
                font-size: 0.75rem;
            }

            .stat-card .value {
                font-size: 1.8rem;
            }
        }

        @media (max-width: 768px) {
            body {
                padding: 10px;
            }

            .admin-header {
                padding: 12px;
                margin-bottom: 10px;
                border-radius: 12px;
            }

            .admin-header h1 {
                font-size: 1.3rem;
                margin-bottom: 4px;
            }

            .admin-header p {
                font-size: 0.85rem;
            }

            .stats-grid {
                grid-template-columns: repeat(2, 1fr);
                gap: 8px;
                margin-bottom: 10px;
            }

            .stat-card {
                padding: 10px 12px;
                border-radius: 10px;
            }

            .stat-card h3 {
                font-size: 0.65rem;
                margin-bottom: 4px;
                font-weight: 500;
            }

            .stat-card .value {
                font-size: 1.5rem;
            }

            .content-section {
                padding: 12px;
                margin-bottom: 10px;
                border-radius: 12px;
            }

            .content-section h2 {
                font-size: 1rem;
                margin-bottom: 10px;
            }

            .table-wrapper {
                overflow-x: auto;
                -webkit-overflow-scrolling: touch;
                margin: 0 -12px;
                padding: 0 12px;
            }

            th {
                padding: 8px 10px;
                font-size: 0.75rem;
                border-bottom: 1px solid #e2e8f0;
            }

            td {
                padding: 8px 10px;
                font-size: 0.8rem;
                border-bottom: 1px solid #e2e8f0;
            }

            .gender-badge {
                padding: 2px 6px;
                font-size: 0.65rem;
            }

            .search-container {
                padding: 12px;
                margin-bottom: 10px;
                border-radius: 12px;
            }

            .search-form {
                gap: 8px;
                flex-wrap: wrap;
            }

            .search-form input {
                flex: 1;
                min-width: 150px;
                padding: 10px 12px;
                font-size: 0.85rem;
            }

            .search-form button {
                padding: 10px 16px;
                font-size: 0.85rem;
            }

            .search-results {
                flex: 1 100%;
                font-size: 0.75rem;
                padding: 8px 0;
            }
        }

        @media (max-width: 480px) {
            body {
                padding: 6px;
            }

            .admin-header {
                padding: 10px;
                margin-bottom: 8px;
            }

            .admin-header h1 {
                font-size: 1.1rem;
                margin-bottom: 2px;
            }

            .admin-header p {
                font-size: 0.8rem;
            }

            .stats-grid {
                grid-template-columns: 1fr;
                gap: 6px;
                margin-bottom: 8px;
            }

            .stat-card {
                padding: 8px 10px;
                border-radius: 8px;
            }

            .stat-card h3 {
                font-size: 0.6rem;
                margin-bottom: 3px;
            }

            .stat-card .value {
                font-size: 1.2rem;
            }

            .content-section {
                padding: 10px;
                margin-bottom: 8px;
            }

            .content-section h2 {
                font-size: 0.95rem;
                margin-bottom: 8px;
            }

            th {
                padding: 6px 8px;
                font-size: 0.7rem;
            }

            td {
                padding: 6px 8px;
                font-size: 0.75rem;
            }

            .gender-badge {
                padding: 1px 4px;
                font-size: 0.6rem;
            }

            .search-container {
                padding: 10px;
                margin-bottom: 8px;
            }

            .search-form {
                flex-direction: column;
                gap: 6px;
            }

            .search-form input {
                min-width: auto;
                padding: 9px 10px;
                font-size: 0.8rem;
            }

            .search-form button {
                padding: 9px 12px;
                font-size: 0.8rem;
                width: 100%;
            }

            .search-results {
                font-size: 0.7rem;
                padding: 4px 0;
            }
        }
    </style>
</head>
<body>
    
   
  <?php include 'side-bar.php'; ?>
<div class="admin-content">
        <main class="admin-main">
            <div class="admin-header">
                <h1>Chat & Earn Monitor</h1>
                <p>Track and manage the Chat & Earn feature</p>
            </div>

             Stats 
            <div class="stats-grid">
                <div class="stat-card">
                    <h3>Total Premium Plus</h3>
                    <div class="value"><?php echo number_format($stats['total_users']); ?></div>
                </div>
                <div class="stat-card">
                    <h3>Chat & Earn Enabled</h3>
                    <div class="value" style="color: #10b981;"><?php echo number_format($stats['enabled_users']); ?></div>
                </div>
                <div class="stat-card">
                    <h3>Male Users</h3>
                    <div class="value" style="color: #3b82f6;"><?php echo number_format($stats['male_users']); ?></div>
                </div>
                <div class="stat-card">
                    <h3>Female Users</h3>
                    <div class="value" style="color: #ec4899;"><?php echo number_format($stats['female_users']); ?></div>
                </div>
                <div class="stat-card">
                    <h3>Total Pairings</h3>
                    <div class="value"><?php echo number_format($pairing_stats['total_pairings']); ?></div>
                </div>
                <div class="stat-card">
                    <h3>Today's Pairings</h3>
                    <div class="value"><?php echo number_format($today_stats['today_pairings']); ?></div>
                </div>
            </div>

            <!-- Search Users -->
            <div class="search-container">
                <form method="GET" class="search-form">
                    <input type="text" name="search" placeholder="Search by username or email..." value="<?php echo htmlspecialchars($search_query); ?>">
                    <button type="submit">Search</button>
                    <?php if ($search_query): ?>
                        <a href="?" style="padding: 12px 16px; background: #e2e8f0; color: #2d3748; border: none; border-radius: 10px; text-decoration: none; font-weight: 600; cursor: pointer;">Clear</a>
                        <div class="search-results">Found <?php echo count($active_users); ?> user(s)</div>
                    <?php endif; ?>
                </form>
            </div>

             Active Users 
            <div class="content-section">
                <h2>Active Chat & Earn Users</h2>
                <div class="table-wrapper">
                    <table>
                        <thead>
                            <tr>
                                <th>User</th>
                                <th>Gender</th>
                                <th>WhatsApp</th>
                                <th>Last Paired</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($active_users as $user): ?>
                                <tr>
                                    <td>
                                        <strong><?php echo htmlspecialchars($user['username']); ?></strong><br>
                                        <small><?php echo htmlspecialchars($user['email']); ?></small>
                                    </td>
                                    <td>
                                        <span class="gender-badge gender-<?php echo $user['gender']; ?>">
                                            <?php echo ucfirst($user['gender']); ?>
                                        </span>
                                    </td>
                                    <td><?php echo htmlspecialchars($user['whatsapp_number'] ?? 'Not set'); ?></td>
                                    <td><?php echo $user['chat_earn_last_paired'] ? date('M d, Y', strtotime($user['chat_earn_last_paired'])) : 'Never'; ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>

             Recent Pairings 
            <div class="content-section">
                <h2>Recent Pairings</h2>
                <div class="table-wrapper">
                    <table>
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>User 1</th>
                                <th>User 2</th>
                                <th>Paired At</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($recent_pairings as $pairing): ?>
                                <tr>
                                    <td>#<?php echo $pairing['id']; ?></td>
                                    <td>
                                        <strong><?php echo htmlspecialchars($pairing['user1_name']); ?></strong><br>
                                        <small><?php echo htmlspecialchars($pairing['user1_whatsapp']); ?></small>
                                    </td>
                                    <td>
                                        <strong><?php echo htmlspecialchars($pairing['user2_name']); ?></strong><br>
                                        <small><?php echo htmlspecialchars($pairing['user2_whatsapp']); ?></small>
                                    </td>
                                    <td><?php echo date('M d, Y H:i', strtotime($pairing['paired_at'])); ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </main>
    </div>
</body>
</html>
