<?php
session_start();
require_once '../config/database.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: ../login.php');
    exit();
}

$user_id = $_SESSION['user_id'];
$stmt = $conn->prepare("SELECT is_admin FROM users WHERE id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();

if (!$user || $user['is_admin'] != 1) {
    header('Location: ../dashboard.php');
    exit();
}

$search_user = isset($_GET['search_user']) ? trim($_GET['search_user']) : '';
$search_video = isset($_GET['search_video']) ? trim($_GET['search_video']) : '';
$filter_platform = isset($_GET['filter_platform']) ? trim($_GET['filter_platform']) : '';
$filter_type = isset($_GET['filter_type']) ? trim($_GET['filter_type']) : '';

$all_videos = [];
$stats = [
    'total_videos' => 0,
    'youtube' => 0,
    'tiktok' => 0,
    'instagram' => 0,
    'twitter' => 0,
    'facebook' => 0,
    'linkedin' => 0,
    'total_earned' => 0
];

try {
    // Get all video watches from video_earnings
    $query = "SELECT 
        ve.id,
        ve.user_id,
        ve.video_id,
        ve.video_title,
        ve.amount_earned,
        ve.profile_link,
        ve.watched_at,
        u.username,
        u.email as user_email,
        COALESCE(av.platform, 'youtube') as platform,
        COALESCE(av.description, '') as description,
        COALESCE(av.duration, 0) as duration,
        av.free_reward,
        av.premium_reward,
        av.is_compulsory,
        av.is_active,
        av.video_url
        FROM video_earnings ve
        JOIN users u ON ve.user_id = u.id
        LEFT JOIN available_videos av ON ve.video_id = av.video_id
        WHERE 1=1";

    $params = [];
    $types = "";

    if (!empty($search_user)) {
        $query .= " AND (u.username LIKE ? OR u.email LIKE ?)";
        $search_param = '%' . $search_user . '%';
        $params[] = $search_param;
        $params[] = $search_param;
        $types .= "ss";
    }

    if (!empty($search_video)) {
        $query .= " AND ve.video_title LIKE ?";
        $search_param = '%' . $search_video . '%';
        $params[] = $search_param;
        $types .= "s";
    }

    if (!empty($filter_platform)) {
        $query .= " AND LOWER(COALESCE(av.platform, 'youtube')) = LOWER(?)";
        $params[] = $filter_platform;
        $types .= "s";
    }

    if ($filter_type === 'compulsory') {
        $query .= " AND av.is_compulsory = 1";
    } elseif ($filter_type === 'optional') {
        $query .= " AND (av.is_compulsory = 0 OR av.is_compulsory IS NULL)";
    }

    $query .= " ORDER BY ve.watched_at DESC LIMIT 1000";

    $stmt = $conn->prepare($query);
    if (!empty($params)) {
        $stmt->bind_param($types, ...$params);
    }
    $stmt->execute();
    $all_videos = $stmt->get_result()->fetch_all(MYSQLI_ASSOC) ?: [];

    // Calculate stats from results
    $stats['total_videos'] = count($all_videos);
    
    foreach ($all_videos as $video) {
        $platform = strtolower($video['platform']);
        if ($platform === 'youtube') {
            $stats['youtube']++;
        } elseif ($platform === 'tiktok') {
            $stats['tiktok']++;
        } elseif ($platform === 'instagram') {
            $stats['instagram']++;
        } elseif ($platform === 'twitter') {
            $stats['twitter']++;
        } elseif ($platform === 'facebook') {
            $stats['facebook']++;
        } elseif ($platform === 'linkedin') {
            $stats['linkedin']++;
        }
        $stats['total_earned'] += (float)($video['amount_earned'] ?? 0);
    }

} catch (Exception $e) {
    error_log("Error in view-watched-videos.php: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Watched Videos - Admin Panel</title>
    <link rel="stylesheet" href="../css/style.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        html, body {
            width: 100%;
            overflow-x: hidden;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px;
        }

        .admin-content {
            display: flex;
            width: 100%;
            max-width: 100%;
        }

        .admin-main {
            flex: 1;
            width: 100%;
            max-width: 100%;
            overflow-x: hidden;
        }

        .admin-header {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            padding: 30px;
            margin-bottom: 20px;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
        }

        .admin-header h1 {
            color: #2d3748;
            font-size: 32px;
            margin-bottom: 10px;
        }

        .admin-header p {
            color: #718096;
            font-size: 16px;
        }

        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(140px, 1fr));
            gap: 15px;
            margin-bottom: 20px;
        }

        .stat-card {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 15px;
            padding: 20px;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
            text-align: center;
            border-top: 4px solid #667eea;
        }

        .stat-card h3 {
            color: #718096;
            font-size: 11px;
            text-transform: uppercase;
            letter-spacing: 0.05em;
            margin-bottom: 8px;
            font-weight: 700;
        }

        .stat-card .value {
            color: #2d3748;
            font-size: 28px;
            font-weight: 900;
        }

        .content-section {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            padding: 30px;
            margin-bottom: 20px;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 100%;
            overflow-x: hidden;
        }

        .content-section h2 {
            color: #2d3748;
            font-size: 20px;
            margin-bottom: 20px;
            font-weight: 700;
        }

        .filters-section {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
            gap: 15px;
            margin-bottom: 20px;
        }

        .filter-group {
            display: flex;
            flex-direction: column;
        }

        .filter-group label {
            font-size: 12px;
            color: #4a5568;
            text-transform: uppercase;
            letter-spacing: 0.05em;
            font-weight: 700;
            margin-bottom: 6px;
        }

        .filter-group input,
        .filter-group select {
            padding: 10px 12px;
            border: 1px solid #e2e8f0;
            border-radius: 8px;
            font-size: 13px;
            background: white;
            color: #2d3748;
        }

        .filter-group input:focus,
        .filter-group select:focus {
            outline: none;
            border-color: #667eea;
            box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
        }

        .filter-buttons {
            display: flex;
            gap: 10px;
            align-items: flex-end;
        }

        .btn-search {
            padding: 10px 24px;
            background: #667eea;
            color: white;
            border: none;
            border-radius: 8px;
            font-weight: 700;
            cursor: pointer;
            font-size: 13px;
            transition: all 0.3s;
        }

        .btn-search:hover {
            background: #5568d3;
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(102, 126, 234, 0.4);
        }

        .btn-clear {
            padding: 10px 24px;
            background: #e2e8f0;
            color: #4a5568;
            border: none;
            border-radius: 8px;
            font-weight: 700;
            cursor: pointer;
            font-size: 13px;
            text-decoration: none;
            display: inline-block;
            transition: all 0.3s;
        }

        .btn-clear:hover {
            background: #cbd5e0;
        }

        .table-container {
            background: white;
            border-radius: 12px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            overflow-x: auto;
            -webkit-overflow-scrolling: touch;
            width: 100%;
            max-width: 100%;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            font-size: 13px;
            min-width: 1000px;
        }

        th {
            text-align: left;
            padding: 12px;
            color: #4a5568;
            font-weight: 700;
            background: #f7fafc;
            border-bottom: 2px solid #e2e8f0;
            white-space: nowrap;
            font-size: 12px;
            text-transform: uppercase;
            letter-spacing: 0.05em;
        }

        td {
            padding: 10px 12px;
            color: #2d3748;
            border-bottom: 1px solid #e2e8f0;
            font-size: 12px;
        }

        tr:hover {
            background: #f7fafc;
        }

        .badge {
            display: inline-block;
            padding: 4px 10px;
            border-radius: 6px;
            font-size: 11px;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.03em;
        }

        .badge-youtube {
            background: #fee2e2;
            color: #991b1b;
        }

        .badge-tiktok {
            background: #f3e8ff;
            color: #6b21a8;
        }

        .badge-instagram {
            background: #fef3c7;
            color: #b45309;
        }

        .badge-twitter {
            background: #cffafe;
            color: #164e63;
        }

        .badge-facebook {
            background: #ddd6fe;
            color: #3730a3;
        }

        .badge-linkedin {
            background: #dcfce7;
            color: #15803d;
        }

        .badge-compulsory {
            background: #e0e7ff;
            color: #4338ca;
        }

        .badge-optional {
            background: #fce7f3;
            color: #be185d;
        }

        .user-info {
            font-weight: 700;
            color: #2d3748;
        }

        .user-email {
            font-size: 11px;
            color: #718096;
            margin-top: 2px;
        }

        .profile-link-cell {
            font-size: 11px;
            color: #667eea;
            font-family: 'Courier New', monospace;
            background: #f0f4f8;
            padding: 4px 6px;
            border-radius: 4px;
            border-left: 3px solid #667eea;
            word-break: break-all;
            max-width: 140px;
        }

        .no-data {
            text-align: center;
            padding: 40px 20px;
            color: #718096;
        }

        .result-count {
            color: #718096;
            font-size: 13px;
            margin-bottom: 12px;
            font-weight: 600;
        }

        @media (max-width: 768px) {
            body {
                padding: 12px;
            }

            .admin-header {
                padding: 16px;
                margin-bottom: 12px;
            }

            .admin-header h1 {
                font-size: 18px;
            }

            .stats-grid {
                grid-template-columns: repeat(2, 1fr);
                gap: 10px;
            }

            .stat-card {
                padding: 12px;
            }

            .stat-card h3 {
                font-size: 10px;
            }

            .stat-card .value {
                font-size: 20px;
            }

            .content-section {
                padding: 16px;
                margin-bottom: 12px;
            }

            .filters-section {
                grid-template-columns: 1fr;
                gap: 10px;
            }

            .filter-buttons {
                flex-direction: column;
            }

            .btn-search, .btn-clear {
                width: 100%;
            }

            table {
                min-width: 900px;
                font-size: 11px;
            }

            th {
                padding: 8px;
                font-size: 10px;
            }

            td {
                padding: 8px;
            }
        }
    </style>
</head>
<body>
    <?php include 'side-bar.php'; ?>
    <div class="admin-content">
        <main class="admin-main">
            <div class="admin-header">
                <h1>Watched Videos - Admin Panel</h1>
                <p>Complete video watching transparency: Integrated from 3 tables with real-time tracking</p>
            </div>

            <!-- Stats Grid -->
            <div class="stats-grid">
                <div class="stat-card">
                    <h3>Total Videos</h3>
                    <div class="value"><?php echo number_format($stats['total_videos']); ?></div>
                </div>
                <div class="stat-card">
                    <h3>YouTube</h3>
                    <div class="value"><?php echo number_format($stats['youtube']); ?></div>
                </div>
                <div class="stat-card">
                    <h3>TikTok</h3>
                    <div class="value"><?php echo number_format($stats['tiktok']); ?></div>
                </div>
                <div class="stat-card">
                    <h3>Instagram</h3>
                    <div class="value"><?php echo number_format($stats['instagram']); ?></div>
                </div>
                <div class="stat-card">
                    <h3>Twitter</h3>
                    <div class="value"><?php echo number_format($stats['twitter']); ?></div>
                </div>
                <div class="stat-card">
                    <h3>Facebook</h3>
                    <div class="value"><?php echo number_format($stats['facebook']); ?></div>
                </div>
                <div class="stat-card">
                    <h3>LinkedIn</h3>
                    <div class="value"><?php echo number_format($stats['linkedin']); ?></div>
                </div>
                <div class="stat-card">
                    <h3>Total Earnings</h3>
                    <div class="value">₦<?php echo number_format($stats['total_earned'], 2); ?></div>
                </div>
            </div>

            <!-- Filters -->
            <div class="content-section">
                <form method="GET">
                    <div class="filters-section">
                        <div class="filter-group">
                            <label>Search User</label>
                            <input type="text" name="search_user" placeholder="Username or email..." value="<?php echo htmlspecialchars($search_user); ?>">
                        </div>
                        <div class="filter-group">
                            <label>Search Video Title</label>
                            <input type="text" name="search_video" placeholder="Video title..." value="<?php echo htmlspecialchars($search_video); ?>">
                        </div>
                        <div class="filter-group">
                            <label>Platform</label>
                            <select name="filter_platform">
                                <option value="">All Platforms</option>
                                <option value="youtube" <?php echo ($filter_platform === 'youtube') ? 'selected' : ''; ?>>YouTube</option>
                                <option value="tiktok" <?php echo ($filter_platform === 'tiktok') ? 'selected' : ''; ?>>TikTok</option>
                                <option value="instagram" <?php echo ($filter_platform === 'instagram') ? 'selected' : ''; ?>>Instagram</option>
                                <option value="twitter" <?php echo ($filter_platform === 'twitter') ? 'selected' : ''; ?>>Twitter</option>
                                <option value="facebook" <?php echo ($filter_platform === 'facebook') ? 'selected' : ''; ?>>Facebook</option>
                                <option value="linkedin" <?php echo ($filter_platform === 'linkedin') ? 'selected' : ''; ?>>LinkedIn</option>
                            </select>
                        </div>
                        <div class="filter-group">
                            <label>Video Type</label>
                            <select name="filter_type">
                                <option value="">All Types</option>
                                <option value="compulsory" <?php echo ($filter_type === 'compulsory') ? 'selected' : ''; ?>>Compulsory</option>
                                <option value="optional" <?php echo ($filter_type === 'optional') ? 'selected' : ''; ?>>Optional</option>
                            </select>
                        </div>
                    </div>
                    <div class="filter-buttons">
                        <button type="submit" class="btn-search">Search & Filter</button>
                        <a href="view-watched-videos.php" class="btn-clear">Clear Filters</a>
                    </div>
                </form>
            </div>

            <!-- Videos Table -->
            <div class="content-section">
                <h2>Video Watch Records</h2>
                <?php if (count($all_videos) > 0): ?>
                    <div class="result-count">
                        Showing <strong><?php echo count($all_videos); ?></strong> watch record(s)
                    </div>
                    <div class="table-container">
                        <table>
                            <thead>
                                <tr>
                                    <th>User</th>
                                    <th>Video Title</th>
                                    <th>Platform</th>
                                    <th>Type</th>
                                    <th>Duration (sec)</th>
                                    <th>Earnings</th>
                                    <th>Profile Link</th>
                                    <th>Description</th>
                                    <th>Watched At</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($all_videos as $video): ?>
                                    <tr>
                                        <td>
                                            <div class="user-info"><?php echo htmlspecialchars(substr($video['username'], 0, 20)); ?></div>
                                            <div class="user-email"><?php echo htmlspecialchars(substr($video['user_email'], 0, 25)); ?></div>
                                        </td>
                                        <td><strong><?php echo htmlspecialchars(substr($video['video_title'], 0, 25)); ?></strong></td>
                                        <td>
                                            <?php 
                                            $platform = strtolower($video['platform'] ?? 'youtube');
                                            if ($platform === 'tiktok') {
                                                echo '<span class="badge badge-tiktok">TikTok</span>';
                                            } elseif ($platform === 'instagram') {
                                                echo '<span class="badge badge-instagram">Instagram</span>';
                                            } elseif ($platform === 'twitter') {
                                                echo '<span class="badge badge-twitter">Twitter</span>';
                                            } elseif ($platform === 'facebook') {
                                                echo '<span class="badge badge-facebook">Facebook</span>';
                                            } elseif ($platform === 'linkedin') {
                                                echo '<span class="badge badge-linkedin">LinkedIn</span>';
                                            } else {
                                                echo '<span class="badge badge-youtube">YouTube</span>';
                                            }
                                            ?>
                                        </td>
                                        <td>
                                            <span class="badge <?php echo ($video['is_compulsory']) ? 'badge-compulsory' : 'badge-optional'; ?>">
                                                <?php echo ($video['is_compulsory']) ? 'Compulsory' : 'Optional'; ?>
                                            </span>
                                        </td>
                                        <td><?php echo htmlspecialchars($video['duration'] ?? 0); ?></td>
                                        <td><strong style="color: #059669;">N<?php echo number_format($video['amount_earned'], 2); ?></strong></td>
                                        <td>
                                            <?php if ($video['profile_link']): ?>
                                                <div class="profile-link-cell">
                                                    <?php echo htmlspecialchars($video['profile_link']); ?>
                                                </div>
                                            <?php else: ?>
                                                <small style="color: #cbd5e0;">-</small>
                                            <?php endif; ?>
                                        </td>
                                        <td><small><?php echo htmlspecialchars(substr($video['description'] ?? '', 0, 30)); ?></small></td>
                                        <td style="white-space: nowrap; font-size: 11px;">
                                            <?php echo date('M d, H:i', strtotime($video['watched_at'])); ?>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <div class="no-data">
                        <p>No video watch data found matching your criteria.</p>
                    </div>
                <?php endif; ?>
            </div>
        </main>
    </div>
</body>
</html>
