<?php
session_start();
require_once '../config/database.php';

// Admin auth (same as other admin pages)
if (!isset($_SESSION['user_id'])) {
    header('Location: ../login.php');
    exit();
}

$user_id = $_SESSION['user_id'];
$stmt = $conn->prepare("SELECT is_admin FROM users WHERE id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$user || $user['is_admin'] != 1) {
    header('Location: ../dashboard.php');
    exit();
}

// Search filter
$search = isset($_GET['search']) ? trim($_GET['search']) : '';

// Stats: total commission and total ad purchase amounts
$stats_sql = "SELECT COALESCE(SUM(commission_amount),0) AS total_commission, COALESCE(SUM(ad_purchase_amount),0) AS total_ad_amount, COUNT(*) AS total_records FROM ad_invite_commissions";
$stats_result = $conn->query($stats_sql);
$stats = $stats_result ? $stats_result->fetch_assoc() : ['total_commission' => 0, 'total_ad_amount' => 0, 'total_records' => 0];

// Top referrers by commission
$top_referrers = [];
$top_sql = "SELECT a.referrer_id, u.username, u.email, COALESCE(SUM(a.commission_amount),0) AS total_commission, COUNT(*) AS commission_count
    FROM ad_invite_commissions a
    LEFT JOIN users u ON a.referrer_id = u.id
    GROUP BY a.referrer_id
    ORDER BY total_commission DESC
    LIMIT 10";
$top_result = $conn->query($top_sql);
if ($top_result) $top_referrers = $top_result->fetch_all(MYSQLI_ASSOC);

// Fetch commission rows (with optional search filter)
$commissions = [];
if (!empty($search)) {
    $where = [];
    $params = [];
    $types = '';

    $where[] = '(u1.username LIKE ? OR u1.email LIKE ? OR u2.username LIKE ? OR u2.email LIKE ?)';
    $sparam = '%' . $search . '%';
    $params[] = &$sparam; $params[] = &$sparam; $params[] = &$sparam; $params[] = &$sparam; $types .= 'ssss';

    $where_sql = 'WHERE ' . implode(' AND ', $where);

    $sql = "SELECT a.id, a.referrer_id, a.referred_user_id, a.ad_purchase_amount, a.commission_amount, a.commission_percentage, a.created_at,
        u1.username AS referrer_username, u1.email AS referrer_email,
        u2.username AS referred_username, u2.email AS referred_email
        FROM ad_invite_commissions a
        LEFT JOIN users u1 ON a.referrer_id = u1.id
        LEFT JOIN users u2 ON a.referred_user_id = u2.id
        $where_sql
        ORDER BY a.created_at DESC
        LIMIT 1000";

    $stmt = $conn->prepare($sql);
    if ($stmt) {
        if (!empty($params)) {
            // bind params dynamically
            array_unshift($params, $types);
            call_user_func_array(array($stmt, 'bind_param'), $params);
        }
        $stmt->execute();
        $res = $stmt->get_result();
        $commissions = $res ? $res->fetch_all(MYSQLI_ASSOC) : [];
        $stmt->close();
    }
} else {
    $sql = "SELECT a.id, a.referrer_id, a.referred_user_id, a.ad_purchase_amount, a.commission_amount, a.commission_percentage, a.created_at,
        u1.username AS referrer_username, u1.email AS referrer_email,
        u2.username AS referred_username, u2.email AS referred_email
        FROM ad_invite_commissions a
        LEFT JOIN users u1 ON a.referrer_id = u1.id
        LEFT JOIN users u2 ON a.referred_user_id = u2.id
        ORDER BY a.created_at DESC
        LIMIT 1000";
    $result = $conn->query($sql);
    $commissions = $result ? $result->fetch_all(MYSQLI_ASSOC) : [];
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Downline Commissions - Admin</title>
    <link rel="stylesheet" href="../css/style.css">
    <style>
        /* Reuse admin/referrals.php styles for consistency */
        *{margin:0;padding:0;box-sizing:border-box}
        body{font-family:'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;background:linear-gradient(135deg,#667eea 0%,#764ba2 100%);min-height:100vh;padding:20px}
        .admin-main{flex:1}
        .admin-header{background:rgba(255,255,255,0.95);backdrop-filter:blur(10px);border-radius:20px;padding:24px;margin-bottom:14px;box-shadow:0 8px 32px rgba(0,0,0,.1)}
        .admin-header h1{color:#2d3748;font-size:26px;margin-bottom:6px}
        .admin-header p{color:#718096;font-size:14px}
        .stats-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:14px;margin-bottom:16px}
        .stat-card{background:rgba(255,255,255,0.95);backdrop-filter:blur(10px);border-radius:12px;padding:14px;box-shadow:0 8px 24px rgba(0,0,0,.08)}
        .stat-card h3{color:#718096;font-size:12px;margin-bottom:6px;text-transform:uppercase}
        .stat-card .value{color:#2d3748;font-size:20px;font-weight:700}
        .content-section{background:rgba(255,255,255,0.95);backdrop-filter:blur(10px);border-radius:12px;padding:18px;margin-bottom:18px;box-shadow:0 8px 32px rgba(0,0,0,.08)}
        table{width:100%;border-collapse:collapse;font-size:13px}
        th{text-align:left;padding:10px;color:#4a5568;font-weight:700;border-bottom:2px solid #e2e8f0}
        td{padding:10px;color:#2d3748;border-bottom:1px solid #e2e8f0}
        .small{font-size:12px;color:#64748b}
        .pill{display:inline-block;padding:6px 10px;border-radius:999px;background:#f1f5f9;color:#1f2937;font-weight:700}
        @media(max-width:768px){body{padding:12px}.admin-header{padding:12px}.stat-card{padding:10px}.content-section{padding:12px}table{font-size:12px}th,td{padding:8px}}
    </style>
</head>
<body>
    <?php include 'side-bar.php'; ?>
    <div class="admin-content">
        <main class="admin-main">
            <div class="admin-header">
                <h1>Downline Commissions</h1>
                <p>All commissions earned by uplines when their downline posted a task (ad purchases)</p>
            </div>

            <div class="stats-grid">
                <div class="stat-card">
                    <h3>Total Commissions</h3>
                    <div class="value">₦<?php echo number_format($stats['total_commission'] ?? 0, 2); ?></div>
                </div>
                <div class="stat-card">
                    <h3>Total Ad Purchases</h3>
                    <div class="value">₦<?php echo number_format($stats['total_ad_amount'] ?? 0, 2); ?></div>
                </div>
                <div class="stat-card">
                    <h3>Total Records</h3>
                    <div class="value"><?php echo number_format($stats['total_records'] ?? 0); ?></div>
                </div>
                <div class="stat-card">
                    <h3>Top Referrers (by commission)</h3>
                    <div class="value small">
                        <?php if (count($top_referrers) === 0) { echo 'No data'; } else { foreach ($top_referrers as $tr) { echo htmlspecialchars($tr['username'] ?? 'Unknown') . ' — ₦' . number_format($tr['total_commission'], 2) . '<br>'; } } ?>
                    </div>
                </div>
            </div>

            <div class="content-section">
                <form method="GET" style="display:flex;gap:10px;align-items:center;flex-wrap:wrap;margin-bottom:12px;">
                    <input type="text" name="search" placeholder="Search referrer or referred (username or email)" value="<?php echo htmlspecialchars($search); ?>" style="flex:1;min-width:240px;padding:10px;border:1px solid #e2e8f0;border-radius:8px;font-size:14px;">
                    <button type="submit" style="padding:10px 14px;background:#667eea;color:#fff;border:none;border-radius:8px;cursor:pointer">Filter</button>
                    <a href="downline-commissions.php" style="padding:10px 14px;background:#64748b;color:#fff;border-radius:8px;text-decoration:none">Clear</a>
                </form>

                <div style="overflow-x:auto;">
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Referrer</th>
                            <th>Referred User</th>
                            <th>Ad Purchase Amount</th>
                            <th>Commission Amount</th>
                            <th>Commission %</th>
                            <th>Date</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($commissions)): ?>
                            <tr><td colspan="7" style="text-align:center;color:#64748b;padding:20px">No commission records found</td></tr>
                        <?php else: foreach ($commissions as $c): ?>
                            <tr>
                                <td><strong><?php echo (int)$c['id']; ?></strong></td>
                                <td>
                                    <strong><?php echo htmlspecialchars($c['referrer_username'] ?? 'Unknown'); ?></strong><br>
                                    <small class="small"><?php echo htmlspecialchars($c['referrer_email'] ?? ''); ?></small>
                                </td>
                                <td>
                                    <strong><?php echo htmlspecialchars($c['referred_username'] ?? 'Unknown'); ?></strong><br>
                                    <small class="small"><?php echo htmlspecialchars($c['referred_email'] ?? ''); ?></small>
                                </td>
                                <td>₦<?php echo number_format($c['ad_purchase_amount'] ?? 0, 2); ?></td>
                                <td>₦<?php echo number_format($c['commission_amount'] ?? 0, 2); ?></td>
                                <td><?php echo htmlspecialchars($c['commission_percentage']) ? htmlspecialchars($c['commission_percentage']) . '%' : '-'; ?></td>
                                <td class="small"><?php echo htmlspecialchars($c['created_at']); ?></td>
                            </tr>
                        <?php endforeach; endif; ?>
                    </tbody>
                </table>
                </div>
            </div>

            <div class="content-section">
                <h2 style="margin-bottom:12px">Referral Commissions (signup / upgrades)</h2>
                <p class="small" style="margin-bottom:12px">This section shows other referral commissions recorded in `referral_commissions` (signup / premium upgrades).</p>
                <?php
                $other = $conn->query("SELECT rc.id, rc.referrer_id, rc.referred_user_id, rc.commission_type, rc.commission_amount, rc.created_at, u1.username AS referrer_username, u2.username AS referred_username
                    FROM referral_commissions rc
                    LEFT JOIN users u1 ON rc.referrer_id = u1.id
                    LEFT JOIN users u2 ON rc.referred_user_id = u2.id
                    ORDER BY rc.created_at DESC
                    LIMIT 200");
                $other_rows = $other ? $other->fetch_all(MYSQLI_ASSOC) : [];
                ?>
                <div style="overflow-x:auto;">
                    <table>
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Referrer</th>
                                <th>Referred</th>
                                <th>Type</th>
                                <th>Amount</th>
                                <th>Date</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($other_rows)): ?>
                                <tr><td colspan="6" style="text-align:center;color:#64748b;padding:18px">No records</td></tr>
                            <?php else: foreach ($other_rows as $r): ?>
                                <tr>
                                    <td><?php echo (int)$r['id']; ?></td>
                                    <td><strong><?php echo htmlspecialchars($r['referrer_username'] ?? 'Unknown'); ?></strong></td>
                                    <td><strong><?php echo htmlspecialchars($r['referred_username'] ?? 'Unknown'); ?></strong></td>
                                    <td class="small"><?php echo htmlspecialchars($r['commission_type']); ?></td>
                                    <td>₦<?php echo number_format($r['commission_amount'] ?? 0, 2); ?></td>
                                    <td class="small"><?php echo htmlspecialchars($r['created_at']); ?></td>
                                </tr>
                            <?php endforeach; endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>

        </main>
    </div>
</body>
</html>
