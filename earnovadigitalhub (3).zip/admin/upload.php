<?php
require_once '../config/database.php';
require_once '../includes/session.php';

// Require authentication
requireLogin();
checkSessionTimeout();

// Get current user
$user = getCurrentUser();
$user_id = $user['id'];

// Check if user is admin (you can add admin role check here)
// For now, we'll allow any logged-in user to upload (you should restrict this)

$message = '';
$messageType = '';

// Handle track upload
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'upload_track') {
    try {
        $pdo = getDBConnection();
        
        $title = trim($_POST['title'] ?? '');
        $artist = trim($_POST['artist'] ?? '');
        $album = trim($_POST['album'] ?? '');
        $duration = intval($_POST['duration'] ?? 0);
        $free_reward = floatval($_POST['free_reward'] ?? 0);
        $premium_reward = floatval($_POST['premium_reward'] ?? 0);
        
        // Validate input
        if (empty($title) || empty($artist) || $duration <= 0) {
            $message = 'Please fill in all required fields';
            $messageType = 'error';
        } else {
            // Handle file uploads
            $audio_file = '';
            $cover_image = '';
            
            // Upload audio file
            if (isset($_FILES['audio_file']) && $_FILES['audio_file']['error'] === UPLOAD_ERR_OK) {
                $audio_tmp = $_FILES['audio_file']['tmp_name'];
                $audio_name = basename($_FILES['audio_file']['name']);
                $audio_ext = strtolower(pathinfo($audio_name, PATHINFO_EXTENSION));
                
                // Validate audio file type
                $allowed_audio = ['mp3', 'wav', 'ogg', 'm4a'];
                if (!in_array($audio_ext, $allowed_audio)) {
                    $message = 'Invalid audio file type. Allowed: mp3, wav, ogg, m4a';
                    $messageType = 'error';
                } else {
                    // Generate unique filename
                    $audio_filename = 'track_' . time() . '_' . uniqid() . '.' . $audio_ext;
                    $audio_path = '../uploads/stream_tracks/' . $audio_filename;
                    
                    // Create directory if it doesn't exist
                    if (!is_dir('../uploads/stream_tracks')) {
                        mkdir('../uploads/stream_tracks', 0755, true);
                    }
                    
                    if (move_uploaded_file($audio_tmp, $audio_path)) {
                        $audio_file = 'uploads/stream_tracks/' . $audio_filename;
                    } else {
                        $message = 'Failed to upload audio file';
                        $messageType = 'error';
                    }
                }
            } else {
                $message = 'Please select an audio file';
                $messageType = 'error';
            }
            
            // Upload cover image (optional)
            if (isset($_FILES['cover_image']) && $_FILES['cover_image']['error'] === UPLOAD_ERR_OK) {
                $cover_tmp = $_FILES['cover_image']['tmp_name'];
                $cover_name = basename($_FILES['cover_image']['name']);
                $cover_ext = strtolower(pathinfo($cover_name, PATHINFO_EXTENSION));
                
                // Validate image file type
                $allowed_images = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
                if (in_array($cover_ext, $allowed_images)) {
                    // Generate unique filename
                    $cover_filename = 'cover_' . time() . '_' . uniqid() . '.' . $cover_ext;
                    $cover_path = '../uploads/stream_covers/' . $cover_filename;
                    
                    // Create directory if it doesn't exist
                    if (!is_dir('../uploads/stream_covers')) {
                        mkdir('../uploads/stream_covers', 0755, true);
                    }
                    
                    if (move_uploaded_file($cover_tmp, $cover_path)) {
                        $cover_image = 'uploads/stream_covers/' . $cover_filename;
                    }
                }
            }
            
            // Insert track into database
            if (empty($message) && !empty($audio_file)) {
                $track_id = 'track_' . time() . '_' . uniqid();
                
                $stmt = $pdo->prepare("INSERT INTO stream_tracks (track_id, title, artist, album, duration, cover_image, audio_file, free_reward, premium_reward, uploaded_by) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
                $stmt->execute([
                    $track_id,
                    $title,
                    $artist,
                    $album,
                    $duration,
                    $cover_image,
                    $audio_file,
                    $free_reward,
                    $premium_reward,
                    $user_id
                ]);
                
                $message = 'Track uploaded successfully!';
                $messageType = 'success';
            }
        }
    } catch (PDOException $e) {
        error_log("Track Upload Error: " . $e->getMessage());
        $message = 'An error occurred while uploading the track';
        $messageType = 'error';
    }
}

// Handle video upload
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'upload_video') {
    try {
        $pdo = getDBConnection();
        
        $title = trim($_POST['title'] ?? '');
        $description = trim($_POST['description'] ?? '');
        $video_url = trim($_POST['video_url'] ?? '');
        $platform = trim($_POST['platform'] ?? '');
        $free_reward = floatval($_POST['free_reward'] ?? 0);
        $premium_reward = floatval($_POST['premium_reward'] ?? 0);
        $is_compulsory = isset($_POST['is_compulsory']) ? 1 : 0;
        
        // Validate input
        if (empty($title) || empty($video_url) || empty($platform)) {
            $message = 'Please fill in all required fields';
            $messageType = 'error';
        } else {
            // Handle file uploads
            $thumbnail = '';
            
            // Upload thumbnail image (optional)
            if (isset($_FILES['thumbnail']) && $_FILES['thumbnail']['error'] === UPLOAD_ERR_OK) {
                $thumbnail_tmp = $_FILES['thumbnail']['tmp_name'];
                $thumbnail_name = basename($_FILES['thumbnail']['name']);
                $thumbnail_ext = strtolower(pathinfo($thumbnail_name, PATHINFO_EXTENSION));
                
                // Validate image file type
                $allowed_images = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
                if (in_array($thumbnail_ext, $allowed_images)) {
                    // Generate unique filename
                    $thumbnail_filename = 'thumbnail_' . time() . '_' . uniqid() . '.' . $thumbnail_ext;
                    $thumbnail_path = '../uploads/stream_thumbnails/' . $thumbnail_filename;
                    
                    // Create directory if it doesn't exist
                    if (!is_dir('../uploads/stream_thumbnails')) {
                        mkdir('../uploads/stream_thumbnails', 0755, true);
                    }
                    
                    if (move_uploaded_file($thumbnail_tmp, $thumbnail_path)) {
                        $thumbnail = 'uploads/stream_thumbnails/' . $thumbnail_filename;
                    }
                }
            }
            
            // Insert video into database
            if (empty($message)) {
                $video_id = 'video_' . time() . '_' . uniqid();
                
                $stmt = $pdo->prepare("INSERT INTO stream_videos (video_id, title, description, video_url, platform, free_reward, premium_reward, is_compulsory, uploaded_by) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
                $stmt->execute([
                    $video_id,
                    $title,
                    $description,
                    $video_url,
                    $platform,
                    $free_reward,
                    $premium_reward,
                    $is_compulsory,
                    $user_id
                ]);
                
                $message = 'Video uploaded successfully!';
                $messageType = 'success';
            }
        }
    } catch (PDOException $e) {
        error_log("Video Upload Error: " . $e->getMessage());
        $message = 'An error occurred while uploading the video';
        $messageType = 'error';
    }
}

// Get all tracks
try {
    $pdo = getDBConnection();
    $stmt = $pdo->prepare("SELECT * FROM stream_tracks ORDER BY upload_date DESC");
    $stmt->execute();
    $tracks = $stmt->fetchAll();
} catch (PDOException $e) {
    $tracks = [];
}

// Get all videos
try {
    $pdo = getDBConnection();
    $stmt = $pdo->prepare("SELECT * FROM stream_videos ORDER BY upload_date DESC");
    $stmt->execute();
    $videos = $stmt->fetchAll();
} catch (PDOException $e) {
    $videos = [];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Upload Track & Video - Admin</title>
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; }
        
        body {
            font-family: "Titillium Web", "Segoe UI", sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: #f5f9ff;
            min-height: 100vh;
        }
        
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 2rem;
        }
        
        h1 {
            font-size: 2.5rem;
            margin-bottom: 2rem;
            background: linear-gradient(135deg, #8b5cf6, #ec4899);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }
        
        .upload-form {
            background: rgba(13, 24, 62, 0.84);
            border: 1px solid rgba(86, 139, 241, 0.3);
            border-radius: 24px;
            padding: 2rem;
            margin-bottom: 3rem;
        }
        
        .form-group {
            margin-bottom: 1.5rem;
        }
        
        label {
            display: block;
            margin-bottom: 0.5rem;
            font-weight: 600;
            color: rgba(205, 219, 255, 0.9);
        }
        
        input[type="text"],
        input[type="number"],
        input[type="file"],
        select {
            width: 100%;
            padding: 0.75rem 1rem;
            border-radius: 12px;
            border: 1px solid rgba(86, 139, 241, 0.3);
            background: rgba(6, 16, 48, 0.7);
            color: #f5f9ff;
            font-size: 1rem;
        }
        
        input[type="file"] {
            padding: 0.5rem;
        }
        
        select {
            cursor: pointer;
        }
        
        .checkbox-group {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 12px;
            background: rgba(6, 16, 48, 0.5);
            border-radius: 12px;
            border: 1px solid rgba(86, 139, 241, 0.2);
        }
        
        .checkbox-group input[type="checkbox"] {
            width: 20px;
            height: 20px;
            cursor: pointer;
        }
        
        .checkbox-group label {
            margin: 0;
            cursor: pointer;
        }
        
        .btn {
            padding: 0.875rem 2rem;
            border-radius: 16px;
            border: none;
            font-weight: 600;
            font-size: 1rem;
            cursor: pointer;
            transition: all 0.3s ease;
        }
        
        .btn-primary {
            background: linear-gradient(135deg, #8b5cf6, #ec4899);
            color: #fff;
        }
        
        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 30px rgba(139, 92, 246, 0.4);
        }
        
        .alert {
            padding: 1rem 1.25rem;
            border-radius: 16px;
            margin-bottom: 1.5rem;
            font-size: 0.95rem;
        }
        
        .alert-success {
            background: rgba(77, 225, 193, 0.15);
            border: 1px solid rgba(77, 225, 193, 0.4);
            color: #4de1c1;
        }
        
        .alert-error {
            background: rgba(239, 68, 68, 0.15);
            border: 1px solid rgba(239, 68, 68, 0.4);
            color: #fca5a5;
        }
        
        .tracks-list {
            background: rgba(13, 24, 62, 0.84);
            border: 1px solid rgba(86, 139, 241, 0.3);
            border-radius: 24px;
            padding: 2rem;
        }
        
        .track-item {
            background: rgba(6, 16, 48, 0.7);
            border: 1px solid rgba(139, 92, 246, 0.2);
            border-radius: 16px;
            padding: 1rem;
            margin-bottom: 1rem;
            display: grid;
            grid-template-columns: 60px 1fr auto;
            gap: 1rem;
            align-items: center;
        }
        
        .track-cover {
            width: 60px;
            height: 60px;
            border-radius: 12px;
            background: linear-gradient(135deg, #8b5cf6, #ec4899);
        }
        
        .track-cover img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            border-radius: 12px;
        }
        
        .track-info h3 {
            font-size: 1.1rem;
            margin-bottom: 0.25rem;
        }
        
        .track-info p {
            font-size: 0.9rem;
            color: rgba(205, 219, 255, 0.7);
        }
        
        .track-stats {
            text-align: right;
            font-size: 0.9rem;
            color: rgba(205, 219, 255, 0.7);
        }
        
        /* Added admin sidebar offset */
        .admin-content {
            margin-left: 260px;
            padding: 20px;
            transition: margin-left 0.3s ease;
        }
        
        @media (max-width: 768px) {
            .admin-content {
                margin-left: 0;
            }
        }
    </style>
</head>
<body>
    <!-- Added sidebar include -->
    <?php include 'side-bar.php'; ?>
    
    <div class="admin-content">
        <div class="container">
            <h1>🎵 Upload Track</h1>
            
            <?php if ($message): ?>
                <div class="alert alert-<?php echo $messageType; ?>">
                    <?php echo htmlspecialchars($message); ?>
                </div>
            <?php endif; ?>
            
            <div class="upload-form">
                <h2 style="margin-bottom: 1.5rem;">Upload New Track</h2>
                <form method="POST" enctype="multipart/form-data">
                    <input type="hidden" name="action" value="upload_track">
                    
                    <div class="form-group">
                        <label for="title">Track Title *</label>
                        <input type="text" id="title" name="title" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="artist">Artist Name *</label>
                        <input type="text" id="artist" name="artist" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="album">Album (Optional)</label>
                        <input type="text" id="album" name="album">
                    </div>
                    
                    <div class="form-group">
                        <label for="duration">Duration (seconds) *</label>
                        <input type="number" id="duration" name="duration" min="1" required>
                        <small style="color: rgba(205, 219, 255, 0.6);">Example: 180 for 3 minutes</small>
                    </div>
                    
                    <div class="form-group">
                        <label for="free_reward">Free User Reward (₦) *</label>
                        <input type="number" id="free_reward" name="free_reward" min="0" step="0.01" value="150" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="premium_reward">Premium User Reward (₦) *</label>
                        <input type="number" id="premium_reward" name="premium_reward" min="0" step="0.01" value="700" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="audio_file">Audio File * (mp3, wav, ogg, m4a)</label>
                        <input type="file" id="audio_file" name="audio_file" accept=".mp3,.wav,.ogg,.m4a" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="cover_image">Cover Image (Optional)</label>
                        <input type="file" id="cover_image" name="cover_image" accept="image/*">
                    </div>
                    
                    <button type="submit" class="btn btn-primary">Upload Track</button>
                </form>
            </div>
            
            <div class="tracks-list">
                <h2 style="margin-bottom: 1.5rem;">Uploaded Tracks (<?php echo count($tracks); ?>)</h2>
                <?php if (empty($tracks)): ?>
                    <p style="text-align: center; padding: 2rem; color: rgba(205, 219, 255, 0.6);">
                        No tracks uploaded yet.
                    </p>
                <?php else: ?>
                    <?php foreach ($tracks as $track): ?>
                        <div class="track-item">
                            <div class="track-cover">
                                <?php if ($track['cover_image']): ?>
                                    <img src="../<?php echo htmlspecialchars($track['cover_image']); ?>" alt="Cover">
                                <?php endif; ?>
                            </div>
                            <div class="track-info">
                                <h3><?php echo htmlspecialchars($track['title']); ?></h3>
                                <p><?php echo htmlspecialchars($track['artist']); ?></p>
                            </div>
                            <div class="track-stats">
                                <div><?php echo gmdate("i:s", $track['duration']); ?></div>
                                <div>₦<?php echo number_format($track['free_reward'], 2); ?> free</div>
                                <div>₦<?php echo number_format($track['premium_reward'], 2); ?> premium</div>
                                <div><?php echo $track['play_count']; ?> plays</div>
                                <div style="font-size: 0.75rem;"><?php echo date('M j, Y', strtotime($track['upload_date'])); ?></div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
            
            <h1>🎥 Upload Video</h1>
            
            <?php if ($message): ?>
                <div class="alert alert-<?php echo $messageType; ?>">
                    <?php echo htmlspecialchars($message); ?>
                </div>
            <?php endif; ?>
            
            <div class="upload-form">
                <h2 style="margin-bottom: 1.5rem;">Upload New Video</h2>
                <form method="POST" enctype="multipart/form-data">
                    <input type="hidden" name="action" value="upload_video">
                    
                    <div class="form-group">
                        <label for="title">Video Title *</label>
                        <input type="text" id="title" name="title" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="description">Description</label>
                        <input type="text" id="description" name="description">
                    </div>
                    
                    <div class="form-group">
                        <label for="video_url">Video URL *</label>
                        <input type="text" id="video_url" name="video_url" placeholder="https://youtube.com/watch?v=..." required>
                        <small style="color: rgba(205, 219, 255, 0.6);">YouTube, TikTok, Instagram, Facebook, Twitter, or LinkedIn video URL</small>
                    </div>
                    
                    <div class="form-group">
                        <label for="platform">Platform *</label>
                        <select id="platform" name="platform" required>
                            <option value="">Select Platform</option>
                            <option value="youtube">YouTube</option>
                            <option value="tiktok">TikTok</option>
                            <option value="instagram">Instagram</option>
                            <option value="facebook">Facebook</option>
                            <option value="twitter">Twitter</option>
                            <option value="linkedin">LinkedIn</option>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label for="thumbnail">Thumbnail Image (Optional)</label>
                        <input type="file" id="thumbnail" name="thumbnail" accept="image/*">
                    </div>
                    
                    <div class="form-group">
                        <label for="free_reward">Free User Reward (₦) *</label>
                        <input type="number" id="free_reward" name="free_reward" min="0" step="0.01" value="100" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="premium_reward">Premium User Reward (₦) *</label>
                        <input type="number" id="premium_reward" name="premium_reward" min="0" step="0.01" value="500" required>
                    </div>
                    
                    <div class="form-group">
                        <div class="checkbox-group">
                            <input type="checkbox" id="is_compulsory" name="is_compulsory" value="1">
                            <label for="is_compulsory">Mark as Compulsory Video (Users must complete this video)</label>
                        </div>
                    </div>
                    
                    <button type="submit" class="btn btn-primary">Upload Video</button>
                </form>
            </div>
            
            <div class="tracks-list">
                <h2 style="margin-bottom: 1.5rem;">Uploaded Videos (<?php echo count($videos); ?>)</h2>
                <?php if (empty($videos)): ?>
                    <p style="text-align: center; padding: 2rem; color: rgba(205, 219, 255, 0.6);">
                        No videos uploaded yet.
                    </p>
                <?php else: ?>
                    <?php foreach ($videos as $video): ?>
                        <div class="track-item">
                            <div class="track-cover">
                                <?php if ($video['thumbnail']): ?>
                                    <img src="../<?php echo htmlspecialchars($video['thumbnail']); ?>" alt="Thumbnail">
                                <?php endif; ?>
                            </div>
                            <div class="track-info">
                                <h3><?php echo htmlspecialchars($video['title']); ?></h3>
                                <p><?php echo htmlspecialchars($video['description']); ?></p>
                            </div>
                            <div class="track-stats">
                                <div><?php echo $video['platform']; ?></div>
                                <div><?php echo $video['free_reward']; ?> ₦ free reward</div>
                                <div><?php echo $video['premium_reward']; ?> ₦ premium reward</div>
                                <div style="font-size: 0.75rem;"><?php echo date('M j, Y', strtotime($video['upload_date'])); ?></div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
            
            <div style="margin-top: 2rem; text-align: center;">
                <a href="videos-music.php" style="color: #8b5cf6; text-decoration: none; font-weight: 600;">
                    ← Back to Videos & Music
                </a>
            </div>
        </div>
    </div>
</body>
</html>
