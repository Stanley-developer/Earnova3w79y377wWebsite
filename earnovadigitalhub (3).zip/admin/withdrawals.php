<?php
session_start();
require_once '../config/database2.php';

// Check if user is logged in and is admin
if (!isset($_SESSION['user_id'])) {
    header('Location: ../login.php');
    exit();
}

$user_id = $_SESSION['user_id'];

// Check if user is admin
$stmt = $pdo->prepare("SELECT is_admin FROM users WHERE id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch();

if (!$user || !$user['is_admin']) {
    header('Location: ../dashboard.php');
    exit();
}

// Handle withdrawal actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $withdrawal_id = $_POST['withdrawal_id'] ?? 0;
    
    if ($action === 'approve') {
        $stmt = $pdo->prepare("UPDATE withdrawals SET status = 'completed', processed_at = NOW() WHERE id = ?");
        $stmt->execute([$withdrawal_id]);
        $success = "Withdrawal approved successfully!";
    } elseif ($action === 'reject') {
        $reason = $_POST['reason'] ?? 'Rejected by admin';
        $stmt = $pdo->prepare("UPDATE withdrawals SET status = 'rejected', processed_at = NOW() WHERE id = ?");
        $stmt->execute([$withdrawal_id]);
        
        // Refund the amount back to user
        $stmt = $pdo->prepare("SELECT user_id, amount, withdrawal_type FROM withdrawals WHERE id = ?");
        $stmt->execute([$withdrawal_id]);
        $withdrawal = $stmt->fetch();
        
        if ($withdrawal) {
            // Refund to the correct balance based on withdrawal type
            if ($withdrawal['withdrawal_type'] === 'prime_earnings') {
                $stmt = $pdo->prepare("UPDATE balances SET referral_earnings = referral_earnings + ?, total_balance = total_balance + ? WHERE user_id = ?");
                $stmt->execute([$withdrawal['amount'], $withdrawal['amount'], $withdrawal['user_id']]);
            } else {
                $stmt = $pdo->prepare("UPDATE balances SET task_earnings = task_earnings + ?, total_balance = total_balance + ? WHERE user_id = ?");
                $stmt->execute([$withdrawal['amount'], $withdrawal['amount'], $withdrawal['user_id']]);
            }
        }
        
        $success = "Withdrawal rejected and amount refunded!";
    } elseif ($action === 'manual_complete') {
        // Admin manually marks withdrawal as completed (for failed Paystack transfers)
        $stmt = $pdo->prepare("
            UPDATE withdrawals 
            SET status = 'completed', 
                paystack_status = 'manual_completed',
                paystack_error_message = 'Manually completed by admin',
                processed_at = NOW() 
            WHERE id = ?
        ");
        $stmt->execute([$withdrawal_id]);
        
        // Log the manual completion
        $log_file = __DIR__ . '/../paystack_error_logs';
        $timestamp = date('Y-m-d H:i:s');
        $admin_id = $_SESSION['user_id'];
        file_put_contents($log_file, "[$timestamp] ADMIN MANUAL COMPLETE: Withdrawal #$withdrawal_id marked as completed by admin #$admin_id\n", FILE_APPEND);
        
        $success = "Withdrawal manually marked as completed!";
    } elseif ($action === 'retry_paystack') {
        // Retry Paystack transfer for failed withdrawals
        $stmt = $pdo->prepare("
            UPDATE withdrawals 
            SET paystack_status = 'not_initiated',
                paystack_error_message = NULL
            WHERE id = ? AND withdrawal_type = 'prime_earnings'
        ");
        $stmt->execute([$withdrawal_id]);
        
        // Trigger Paystack processing
        $token = 'sys_' . substr(md5('earnova_paystack_cron'), 0, 16);
        $api_url = 'https://' . $_SERVER['HTTP_HOST'] . '/api/process-paystack-transfer.php?token=' . urlencode($token);
        
        $ch = curl_init();
        curl_setopt_array($ch, [
            CURLOPT_URL => $api_url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_SSL_VERIFYPEER => false
        ]);
        $response = curl_exec($ch);
        curl_close($ch);
        
        $success = "Paystack transfer retry initiated!";
    }
}

// Get filters
$filter = $_GET['filter'] ?? 'pending';
$type_filter = $_GET['type'] ?? 'all';

// Get all withdrawals
$query = "SELECT w.*, u.username, u.email, u.phone 
          FROM withdrawals w 
          JOIN users u ON w.user_id = u.id";

$conditions = [];
$params = [];

if ($filter !== 'all') {
    $conditions[] = "w.status = :status";
    $params['status'] = $filter;
}

if ($type_filter !== 'all') {
    $conditions[] = "w.withdrawal_type = :type";
    $params['type'] = $type_filter;
}

if (!empty($conditions)) {
    $query .= " WHERE " . implode(" AND ", $conditions);
}

$query .= " ORDER BY w.requested_at DESC";

$stmt = $pdo->prepare($query);
$stmt->execute($params);
$withdrawals = $stmt->fetchAll();

// Get stats
// Note: Legacy records have empty string '' for withdrawal_type, which is treated as 'activity_earnings'
$stmt = $pdo->query("SELECT 
    COUNT(*) as total,
    COUNT(CASE WHEN status = 'pending' THEN 1 END) as pending,
    COUNT(CASE WHEN status = 'processing' THEN 1 END) as processing,
    COUNT(CASE WHEN status = 'completed' THEN 1 END) as completed,
    COUNT(CASE WHEN status = 'rejected' THEN 1 END) as rejected,
    SUM(CASE WHEN status = 'completed' THEN amount ELSE 0 END) as total_paid,
    SUM(CASE WHEN status = 'processing' THEN amount ELSE 0 END) as processing_total,
    SUM(CASE WHEN status = 'processing' AND withdrawal_type = 'prime_earnings' THEN amount ELSE 0 END) as prime_processing_total,
    SUM(CASE WHEN status = 'processing' AND (withdrawal_type = 'activity_earnings' OR withdrawal_type = '') THEN amount ELSE 0 END) as activity_processing_total
    FROM withdrawals");
$stats = $stmt->fetch();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Withdrawals - FlowEarner Admin</title>
    <link rel="stylesheet" href="../css/style.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px;
        }

       
        .admin-main {
            flex: 1;
        }

        .admin-header {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            padding: 30px;
            margin-bottom: 20px;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
        }

        .admin-header h1 {
            color: #2d3748;
            font-size: 32px;
            margin-bottom: 10px;
        }

        .admin-header p {
            color: #718096;
            font-size: 16px;
        }

        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 20px;
        }

        .stat-card {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 15px;
            padding: 25px;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
        }

        .stat-card h3 {
            color: #718096;
            font-size: 14px;
            margin-bottom: 10px;
            text-transform: uppercase;
        }

        .stat-card .value {
            color: #2d3748;
            font-size: 32px;
            font-weight: bold;
        }

        .filter-tabs {
            display: flex;
            gap: 10px;
            margin-bottom: 20px;
            flex-wrap: wrap;
        }

        .filter-tab {
            padding: 10px 20px;
            background: rgba(255, 255, 255, 0.95);
            border: none;
            border-radius: 10px;
            cursor: pointer;
            font-size: 14px;
            color: #4a5568;
            text-decoration: none;
            transition: all 0.3s;
        }

        .filter-tab:hover, .filter-tab.active {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
        }

        .withdrawals-table {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            padding: 30px;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
            overflow-x: auto;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th {
            text-align: left;
            padding: 15px;
            color: #4a5568;
            font-weight: 600;
            border-bottom: 2px solid #e2e8f0;
        }

        td {
            padding: 15px;
            color: #2d3748;
            border-bottom: 1px solid #e2e8f0;
        }

        .status-badge {
            display: inline-block;
            padding: 5px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
        }

        .status-pending {
            background: #fef3c7;
            color: #92400e;
        }

        .status-completed {
            background: #d1fae5;
            color: #065f46;
        }

        .status-rejected {
            background: #fee2e2;
            color: #991b1b;
        }

        .action-btn {
            padding: 8px 16px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-size: 13px;
            margin-right: 5px;
            transition: all 0.3s;
        }

        .approve-btn {
            background: #10b981;
            color: white;
        }

        .approve-btn:hover {
            background: #059669;
        }

        .reject-btn {
            background: #ef4444;
            color: white;
        }

        .reject-btn:hover {
            background: #dc2626;
        }

        .manual-btn {
            background: #8b5cf6;
            color: white;
        }

        .manual-btn:hover {
            background: #7c3aed;
        }

        .retry-btn {
            background: #3b82f6;
            color: white;
        }

        .retry-btn:hover {
            background: #2563eb;
        }

        .status-processing {
            background: #dbeafe;
            color: #1e40af;
        }

        .type-prime {
            border-left: 3px solid #8b5cf6;
        }

        .type-prime.active {
            background: linear-gradient(135deg, #8b5cf6 0%, #7c3aed 100%) !important;
        }

        .type-activity {
            border-left: 3px solid #10b981;
        }

        .type-activity.active {
            background: linear-gradient(135deg, #10b981 0%, #059669 100%) !important;
        }

        .filter-tabs + .filter-tabs {
            margin-top: 10px;
        }

        .alert {
            padding: 15px 20px;
            border-radius: 10px;
            margin-bottom: 20px;
        }

        .alert-success {
            background: #d1fae5;
            color: #065f46;
        }

        @media (max-width: 768px) {
            body {
                padding: 12px;
            }

            .admin-main {
                padding: 0;
            }

            .admin-header {
                padding: 16px;
                margin-bottom: 12px;
                border-radius: 12px;
            }

            .admin-header h1 {
                font-size: 18px;
                margin-bottom: 4px;
            }

            .admin-header p {
                font-size: 12px;
            }

            .stats-grid {
                grid-template-columns: 1fr 1fr;
                gap: 10px;
                margin-bottom: 12px;
            }

            .stat-card {
                padding: 12px;
                border-radius: 10px;
            }

            .stat-card h3 {
                font-size: 11px;
                margin-bottom: 4px;
            }

            .stat-card .value {
                font-size: 18px;
            }

            .filter-tabs {
                gap: 6px;
                margin-bottom: 12px;
            }

            .filter-tab {
                padding: 8px 12px;
                font-size: 11px;
                border-radius: 6px;
            }

            .alert {
                padding: 12px;
                margin-bottom: 12px;
                font-size: 12px;
            }

            .withdrawals-table {
                padding: 12px;
                margin-bottom: 0;
                border-radius: 10px;
                overflow-x: auto;
                -webkit-overflow-scrolling: touch;
            }

            table {
                min-width: 800px;
                display: inline-block;
            }

            th {
                padding: 8px;
                font-size: 11px;
            }

            td {
                padding: 8px;
                font-size: 10px;
            }

            .status-badge {
                padding: 3px 8px;
                font-size: 10px;
            }

            .action-btn {
                padding: 6px 10px;
                font-size: 10px;
                margin-right: 3px;
                margin-bottom: 4px;
            }
        }
    </style>
</head>
<body>
    

  <?php include 'side-bar.php'; ?>
<div class="admin-content">
        <main class="admin-main">
            <div class="admin-header">
                <h1>Manage Withdrawals</h1>
                <p>Review and process user withdrawal requests</p>
            </div>

            <?php if (isset($success)): ?>
                <div class="alert alert-success"><?php echo $success; ?></div>
            <?php endif; ?>

             <p>Filter Tabs </p>
            <div class="stats-grid">
                <div class="stat-card">
                    <h3>Total Requests</h3>
                    <div class="value"><?php echo number_format($stats['total']); ?></div>
                </div>
                <div class="stat-card">
                    <h3>Pending</h3>
                    <div class="value" style="color: #f59e0b;"><?php echo number_format($stats['pending']); ?></div>
                </div>
                <div class="stat-card">
                    <h3>Processing</h3>
                    <div class="value" style="color: #3b82f6;"><?php echo number_format($stats['processing']); ?></div>
                </div>
                <div class="stat-card">
                    <h3>Completed</h3>
                    <div class="value" style="color: #10b981;"><?php echo number_format($stats['completed']); ?></div>
                </div>
                <div class="stat-card">
                    <h3>Rejected</h3>
                    <div class="value" style="color: #ef4444;"><?php echo number_format($stats['rejected']); ?></div>
                </div>
                <div class="stat-card">
                    <h3>Total Paid</h3>
                    <div class="value">₦<?php echo number_format($stats['total_paid'], 2); ?></div>
                </div>
                <div class="stat-card">
                    <h3>Processing Amount</h3>
                    <div class="value">₦<?php echo number_format($stats['processing_total'] ?? 0, 2); ?></div>
                </div>
                <div class="stat-card">
                    <h3>Prime Processing</h3>
                    <div class="value" style="color: #8b5cf6;">₦<?php echo number_format($stats['prime_processing_total'] ?? 0, 2); ?></div>
                </div>
                <div class="stat-card">
                    <h3>Activity Processing</h3>
                    <div class="value" style="color: #10b981;">₦<?php echo number_format($stats['activity_processing_total'] ?? 0, 2); ?></div>
                </div>
            </div>

             <p>Status Filter</p>
            <div class="filter-tabs">
                <a href="?filter=pending<?php echo $type_filter !== 'all' ? '&type='.$type_filter : ''; ?>" class="filter-tab <?php echo $filter === 'pending' ? 'active' : ''; ?>">Pending</a>
                <a href="?filter=processing<?php echo $type_filter !== 'all' ? '&type='.$type_filter : ''; ?>" class="filter-tab <?php echo $filter === 'processing' ? 'active' : ''; ?>">Processing</a>
                <a href="?filter=completed<?php echo $type_filter !== 'all' ? '&type='.$type_filter : ''; ?>" class="filter-tab <?php echo $filter === 'completed' ? 'active' : ''; ?>">Completed</a>
                <a href="?filter=rejected<?php echo $type_filter !== 'all' ? '&type='.$type_filter : ''; ?>" class="filter-tab <?php echo $filter === 'rejected' ? 'active' : ''; ?>">Rejected</a>
                <a href="?filter=all<?php echo $type_filter !== 'all' ? '&type='.$type_filter : ''; ?>" class="filter-tab <?php echo $filter === 'all' ? 'active' : ''; ?>">All Status</a>
            </div>

            <p>Earnings Type Filter</p>
            <div class="filter-tabs">
                <a href="?type=all<?php echo $filter !== 'pending' ? '&filter='.$filter : ''; ?>" class="filter-tab <?php echo $type_filter === 'all' ? 'active' : ''; ?>">All Types</a>
                <a href="?type=prime_earnings<?php echo $filter !== 'pending' ? '&filter='.$filter : ''; ?>" class="filter-tab type-prime <?php echo $type_filter === 'prime_earnings' ? 'active' : ''; ?>">Prime Earnings</a>
                <a href="?type=task_earnings<?php echo $filter !== 'pending' ? '&filter='.$filter : ''; ?>" class="filter-tab type-activity <?php echo $type_filter === 'task_earnings' ? 'active' : ''; ?>">Activity Earnings</a>
            </div>

            <p> Withdrawals Table </p>
            <div class="withdrawals-table">
                
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>User</th>
                            <th>Type</th>
                            <th>Amount</th>
                            <th>Method</th>
                            <th>Account Details</th>
                            <th>Status</th>
                            <th>Date</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($withdrawals as $withdrawal): ?>
                            <tr>
                                <td>#<?php echo $withdrawal['id']; ?></td>
                                <td>
                                    <strong><?php echo htmlspecialchars($withdrawal['username']); ?></strong><br>
                                    <small><?php echo htmlspecialchars($withdrawal['email']); ?></small>
                                </td>
                                <td>
                                    <?php 
                                    $type_label = $withdrawal['withdrawal_type'] === 'prime_earnings' ? 'Prime' : 'Activity';
                                    $type_color = $withdrawal['withdrawal_type'] === 'prime_earnings' ? '#8b5cf6' : '#10b981';
                                    ?>
                                    <span style="background: <?php echo $type_color; ?>20; color: <?php echo $type_color; ?>; padding: 3px 8px; border-radius: 5px; font-size: 12px; font-weight: 600;">
                                        <?php echo $type_label; ?>
                                    </span>
                                </td>
                                <td><strong>₦<?php echo number_format($withdrawal['amount'], 2); ?></strong></td>
                                <td><?php echo htmlspecialchars($withdrawal['payment_method']); ?></td>
                                <td>
                                    <?php 
                                    $details = json_decode($withdrawal['account_details'], true);
                                    if ($details) {
                                        foreach ($details as $key => $value) {
                                            echo "<small><strong>" . ucfirst($key) . ":</strong> " . htmlspecialchars($value) . "</small><br>";
                                        }
                                    }
                                    ?>
                                </td>
                                <td>
                                    <span class="status-badge status-<?php echo $withdrawal['status']; ?>">
                                        <?php echo ucfirst($withdrawal['status']); ?>
                                    </span>
                                    
                                    <!-- Display Paystack status for Prime Earnings -->
                                    <?php if ($withdrawal['withdrawal_type'] === 'prime_earnings'): ?>
                                        <br>
                                        <small style="color: #667eea; font-weight: 600;">
                                            Paystack: <?php echo ucfirst($withdrawal['paystack_status'] ?? 'not_initiated'); ?>
                                        </small>
                                        <?php if ($withdrawal['paystack_error_message']): ?>
                                            <br>
                                            <small style="color: #ef4444;">
                                                Error: <?php echo htmlspecialchars($withdrawal['paystack_error_message']); ?>
                                            </small>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo date('M d, Y', strtotime($withdrawal['requested_at'])); ?></td>
                                <td>
                                    <?php if ($withdrawal['status'] === 'pending'): ?>
                                        <form method="POST" style="display: inline;">
                                            <input type="hidden" name="withdrawal_id" value="<?php echo $withdrawal['id']; ?>">
                                            <input type="hidden" name="action" value="approve">
                                            <button type="submit" class="action-btn approve-btn">Approve</button>
                                        </form>
                                        <form method="POST" style="display: inline;">
                                            <input type="hidden" name="withdrawal_id" value="<?php echo $withdrawal['id']; ?>">
                                            <input type="hidden" name="action" value="reject">
                                            <button type="submit" class="action-btn reject-btn">Reject</button>
                                        </form>
                                    <?php elseif ($withdrawal['status'] === 'processing'): ?>
                                        <form method="POST" style="display: inline;">
                                            <input type="hidden" name="withdrawal_id" value="<?php echo $withdrawal['id']; ?>">
                                            <input type="hidden" name="action" value="manual_complete">
                                            <button type="submit" class="action-btn manual-btn" onclick="return confirm('Are you sure you want to manually mark this withdrawal as completed? Only do this if you have already sent the money manually.');">Manual Complete</button>
                                        </form>
                                        <?php if ($withdrawal['withdrawal_type'] === 'prime_earnings'): ?>
                                        <form method="POST" style="display: inline;">
                                            <input type="hidden" name="withdrawal_id" value="<?php echo $withdrawal['id']; ?>">
                                            <input type="hidden" name="action" value="retry_paystack">
                                            <button type="submit" class="action-btn retry-btn">Retry Paystack</button>
                                        </form>
                                        <?php endif; ?>
                                        <form method="POST" style="display: inline;">
                                            <input type="hidden" name="withdrawal_id" value="<?php echo $withdrawal['id']; ?>">
                                            <input type="hidden" name="action" value="reject">
                                            <button type="submit" class="action-btn reject-btn" onclick="return confirm('Are you sure you want to reject this withdrawal? The amount will be refunded to the user.');">Reject & Refund</button>
                                        </form>
                                    <?php else: ?>
                                        <span style="color: #718096;">No actions</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </main>
    </div>
</body>
</html>
