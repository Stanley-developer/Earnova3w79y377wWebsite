<?php
session_start();
require_once '../config/database.php';


if (!isset($_SESSION['user_id'])) {
    header('Location: ../login.php');
    exit();
}

$user_id = $_SESSION['user_id'];
$stmt = $conn->prepare("SELECT is_admin FROM users WHERE id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result()->fetch_assoc();

if (!$result || $result['is_admin'] != 1) {
    header('Location: ../dashboard.php');
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = $_POST['title'];
    $description = $_POST['description'];
    $category = $_POST['category'];
    $budget = floatval($_POST['budget']);
    $location = $_POST['location'];
    $slots = intval($_POST['slots']);
    $deadline = $_POST['deadline'];
    $requirements = $_POST['requirements'];
    $contact_number = $_POST['contact_number'];
    
    $stmt = $conn->prepare("
        INSERT INTO jobs (title, description, category, budget, location, slots, deadline, requirements, contact_number, status, created_at) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'active', NOW())
    ");
    $stmt->bind_param("sssdsssss", $title, $description, $category, $budget, $location, $slots, $deadline, $requirements, $contact_number);
    
    if ($stmt->execute()) {
        $success_message = "Job posted successfully!";
    } else {
        $error_message = "Failed to post job. Please try again.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Post Job - FlowEarner Admin</title>
  <style>
    :root {
      --admin-primary: #6366f1;
      --admin-secondary: #8b5cf6;
      --admin-success: #10b981;
      --admin-warning: #f59e0b;
      --admin-danger: #ef4444;
      --admin-dark: #1e293b;
      --admin-light: #f1f5f9;
    }

    * { box-sizing: border-box; margin: 0; padding: 0; }

    body {
      font-family: "Inter", "Segoe UI", sans-serif;
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      min-height: 100vh;
    }

    .admin-container {
      display: grid;
      grid-template-columns: 260px 1fr;
      min-height: 100vh;
    }

    

    .admin-main {
    
      padding: 32px;
      overflow-y: auto;
    }

    .admin-header {
      background: white;
      padding: 24px;
      border-radius: 16px;
      margin-bottom: 32px;
      box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    }

    .admin-header h1 {
      font-size: 2rem;
      color: var(--admin-dark);
      margin-bottom: 8px;
    }

    .form-card {
      background: white;
      border-radius: 16px;
      padding: 32px;
      box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
      max-width: 800px;
    }

    .form-group {
      margin-bottom: 24px;
    }

    .form-group label {
      display: block;
      font-weight: 600;
      color: var(--admin-dark);
      margin-bottom: 8px;
      font-size: 0.9rem;
    }

    .form-group input,
    .form-group select,
    .form-group textarea {
      width: 100%;
      padding: 12px 16px;
      border: 1px solid #e2e8f0;
      border-radius: 8px;
      font-size: 0.95rem;
      font-family: inherit;
      transition: all 0.3s;
    }

    .form-group input:focus,
    .form-group select:focus,
    .form-group textarea:focus {
      outline: none;
      border-color: var(--admin-primary);
      box-shadow: 0 0 0 3px rgba(99, 102, 241, 0.1);
    }

    .form-group textarea {
      min-height: 120px;
      resize: vertical;
    }

    .form-row {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
      gap: 16px;
    }

    .submit-btn {
      padding: 14px 32px;
      background: var(--admin-primary);
      color: white;
      border: none;
      border-radius: 8px;
      font-weight: 600;
      font-size: 1rem;
      cursor: pointer;
      transition: all 0.3s;
    }

    .submit-btn:hover {
      background: var(--admin-secondary);
      transform: translateY(-2px);
      box-shadow: 0 4px 12px rgba(99, 102, 241, 0.3);
    }

    .alert {
      padding: 16px;
      border-radius: 12px;
      margin-bottom: 24px;
      font-weight: 600;
    }

    .alert-success {
      background: #d1fae5;
      color: #065f46;
    }

    .alert-error {
      background: #fee2e2;
      color: #991b1b;
    }

    @media (max-width: 960px) {
      .admin-container {
        grid-template-columns: 1fr;
      }

      
      .admin-main {
        margin-left: 0;
      }
    }
  </style>
</head>
<body>
    <?php include 'side-bar.php'; ?>
<div class="admin-content">

    <main class="admin-main">
      <div class="admin-header">
        <h1>Post New Job</h1>
        <p style="color: #64748b;">Create a new job opportunity for premium members</p>
      </div>

      <?php if (isset($success_message)): ?>
        <div class="alert alert-success"><?php echo $success_message; ?></div>
      <?php endif; ?>

      <?php if (isset($error_message)): ?>
        <div class="alert alert-error"><?php echo $error_message; ?></div>
      <?php endif; ?>

      <div class="form-card">
        <form method="POST">
          <div class="form-group">
            <label>Job Title *</label>
            <input type="text" name="title" required placeholder="e.g., Social Media Manager" />
          </div>

          <div class="form-group">
            <label>Description *</label>
            <textarea name="description" required placeholder="Detailed job description..."></textarea>
          </div>

          <div class="form-row">
            <div class="form-group">
              <label>Category *</label>
              <select name="category" required>
                <option value="">Select category</option>
                <option value="Marketing">Marketing</option>
                <option value="Design">Design</option>
                <option value="Development">Development</option>
                <option value="Writing">Writing</option>
                <option value="Sales">Sales</option>
                <option value="Customer Service">Customer Service</option>
                <option value="Data Entry">Data Entry</option>
                <option value="Other">Other</option>
              </select>
            </div>

            <div class="form-group">
              <label>Budget (₦) *</label>
              <input type="number" name="budget" required min="0" step="0.01" placeholder="50000" />
            </div>
          </div>

          <div class="form-row">
            <div class="form-group">
              <label>Location *</label>
              <input type="text" name="location" required placeholder="e.g., Lagos, Nigeria or Remote" />
            </div>

            <div class="form-group">
              <label>Available Slots *</label>
              <input type="number" name="slots" required min="1" value="1" />
            </div>
          </div>

          <div class="form-group">
            <label>Application Deadline *</label>
            <input type="date" name="deadline" required />
          </div>

          <div class="form-group">
            <label>Requirements *</label>
            <textarea name="requirements" required placeholder="List job requirements..."></textarea>
          </div>

          <div class="form-group">
            <label>Contact Number (WhatsApp) *</label>
            <input type="tel" name="contact_number" required placeholder="+234XXXXXXXXXX" />
          </div>

          <button type="submit" class="submit-btn">Post Job</button>
        </form>
      </div>
    </main>
  </div>
</body>
</html>
