<?php
session_start();
require_once '../config/database.php';

// Check if user is logged in and is admin
if (!isset($_SESSION['user_id'])) {
    header('Location: ../login.php');
    exit();
}

$user_id = $_SESSION['user_id'];

// Check if user is admin
$stmt = $conn->prepare("SELECT is_admin FROM users WHERE id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();

if (!$user || $user['is_admin'] != 1) {
    header('Location: ../dashboard.php');
    exit();
}

// Get search parameter
$search = isset($_GET['search']) ? trim($_GET['search']) : '';

// Get referral stats
$stats_result = $conn->query("SELECT 
    (SELECT COUNT(*) FROM users WHERE referred_by IS NOT NULL) as total_referrals,
    (SELECT COUNT(DISTINCT referred_by) FROM users WHERE referred_by IS NOT NULL) as total_referrers");
$stats = $stats_result ? $stats_result->fetch_assoc() : ['total_referrals' => 0, 'total_referrers' => 0];
$stats['completed_referrals'] = $stats['total_referrals'];
$stats['pending_referrals'] = 0;

// Get total referral earnings
// Use the dedicated `referral_commissions` table which stores referral commission amounts.
$earnings_result = $conn->query("SELECT COALESCE(SUM(commission_amount), 0) as total_earnings FROM referral_commissions");
$earnings = $earnings_result ? $earnings_result->fetch_assoc() : ['total_earnings' => 0];

// Initialize arrays
$top_referrers = [];
$recent_referrals = [];

// Get top referrers
if (!empty($search)) {
    $search_param = '%' . $search . '%';
    $stmt = $conn->prepare("SELECT u.id, u.username, u.email, u.referral_code, 
        (SELECT COUNT(*) FROM users WHERE referred_by = u.id) as referral_count,
        (SELECT COUNT(*) FROM users WHERE referred_by = u.id AND membership_type = 'free') as free_downline,
        (SELECT COUNT(*) FROM users WHERE referred_by = u.id AND membership_type = 'premium' AND (advertiser_plan IS NULL OR advertiser_plan != 'senior')) as premium_downline,
        (SELECT COUNT(*) FROM users WHERE referred_by = u.id AND membership_type = 'premium' AND advertiser_plan = 'senior') as premium_plus_downline
        FROM users u
        WHERE u.username LIKE ? OR u.email LIKE ?
        GROUP BY u.id, u.username, u.email, u.referral_code
        HAVING referral_count > 0
        ORDER BY referral_count DESC
        LIMIT 100");
    $stmt->bind_param("ss", $search_param, $search_param);
    $stmt->execute();
    $result = $stmt->get_result();
    $top_referrers = $result ? $result->fetch_all(MYSQLI_ASSOC) : [];
    $stmt->close();
} else {
    $result = $conn->query("SELECT u.id, u.username, u.email, u.referral_code, 
        (SELECT COUNT(*) FROM users WHERE referred_by = u.id) as referral_count,
        (SELECT COUNT(*) FROM users WHERE referred_by = u.id AND membership_type = 'free') as free_downline,
        (SELECT COUNT(*) FROM users WHERE referred_by = u.id AND membership_type = 'premium' AND (advertiser_plan IS NULL OR advertiser_plan != 'senior')) as premium_downline,
        (SELECT COUNT(*) FROM users WHERE referred_by = u.id AND membership_type = 'premium' AND advertiser_plan = 'senior') as premium_plus_downline
        FROM users u
        GROUP BY u.id, u.username, u.email, u.referral_code
        HAVING referral_count > 0
        ORDER BY referral_count DESC
        LIMIT 100");
    $top_referrers = $result ? $result->fetch_all(MYSQLI_ASSOC) : [];
}

// Get referred users
if (!empty($search)) {
    $search_param = '%' . $search . '%';
    $stmt = $conn->prepare("SELECT u2.id as referred_user_id, u2.username as referred_name, u2.email as referred_email, u2.membership_type, u2.advertiser_plan,
        u1.username as referrer_name, u2.created_at
        FROM users u2
        LEFT JOIN users u1 ON u2.referred_by = u1.id
        WHERE u2.referred_by IS NOT NULL AND (u2.username LIKE ? OR u2.email LIKE ?)
        ORDER BY u2.created_at DESC
        LIMIT 50");
    $stmt->bind_param("ss", $search_param, $search_param);
    $stmt->execute();
    $result = $stmt->get_result();
    $recent_referrals = $result ? $result->fetch_all(MYSQLI_ASSOC) : [];
    $stmt->close();
} else {
    $result = $conn->query("SELECT u2.id as referred_user_id, u2.username as referred_name, u2.email as referred_email, u2.membership_type, u2.advertiser_plan,
        u1.username as referrer_name, u2.created_at
        FROM users u2
        LEFT JOIN users u1 ON u2.referred_by = u1.id
        WHERE u2.referred_by IS NOT NULL
        ORDER BY u2.created_at DESC
        LIMIT 50");
    $recent_referrals = $result ? $result->fetch_all(MYSQLI_ASSOC) : [];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Referrals - FlowEarner Admin</title>
    <link rel="stylesheet" href="../css/style.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px;
        }

       
        .admin-main {
            flex: 1;
        }

        .admin-header {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            padding: 30px;
            margin-bottom: 20px;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
        }

        .admin-header h1 {
            color: #2d3748;
            font-size: 32px;
            margin-bottom: 10px;
        }

        .admin-header p {
            color: #718096;
            font-size: 16px;
        }

        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 20px;
        }

        .stat-card {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 15px;
            padding: 25px;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
        }

        .stat-card h3 {
            color: #718096;
            font-size: 14px;
            margin-bottom: 10px;
            text-transform: uppercase;
        }

        .stat-card .value {
            color: #2d3748;
            font-size: 32px;
            font-weight: bold;
        }

        .content-section {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            padding: 30px;
            margin-bottom: 20px;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
        }

        .content-section h2 {
            color: #2d3748;
            font-size: 24px;
            margin-bottom: 20px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th {
            text-align: left;
            padding: 15px;
            color: #4a5568;
            font-weight: 600;
            border-bottom: 2px solid #e2e8f0;
        }

        td {
            padding: 15px;
            color: #2d3748;
            border-bottom: 1px solid #e2e8f0;
        }

        .status-badge {
            display: inline-block;
            padding: 5px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
        }

        .status-completed {
            background: #d1fae5;
            color: #065f46;
        }

        .status-pending {
            background: #fef3c7;
            color: #92400e;
        }

        .plan-breakdown-small {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 6px;
            margin-top: 8px;
            font-size: 0.85rem;
        }

        .plan-item-small {
            text-align: center;
            background: #f0f4f8;
            padding: 6px 4px;
            border-radius: 6px;
        }

        .plan-label-small {
            font-size: 0.65rem;
            color: #64748b;
            text-transform: uppercase;
            letter-spacing: 0.05em;
        }

        .plan-count-small {
            font-weight: 700;
            color: #2d3748;
            font-size: 1rem;
        }

        .overlay-backdrop {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0, 0, 0, 0.5);
            backdrop-filter: blur(4px);
            z-index: 999;
        }

        .overlay-backdrop.active {
            display: block;
        }

        .referrer-overlay {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            z-index: 1000;
            overflow-y: auto;
            padding: 20px;
        }

        .referrer-overlay.active {
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .overlay-content {
            background: white;
            border-radius: 20px;
            width: 100%;
            max-width: 900px;
            max-height: 90vh;
            overflow-y: auto;
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
            position: relative;
        }

        .overlay-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 30px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border-radius: 20px 20px 0 0;
        }

        .overlay-header-info h2 {
            font-size: 24px;
            margin-bottom: 8px;
        }

        .overlay-header-info p {
            font-size: 14px;
            opacity: 0.9;
        }

        .overlay-close {
            background: rgba(255, 255, 255, 0.2);
            border: none;
            color: white;
            font-size: 28px;
            cursor: pointer;
            padding: 0;
            width: 40px;
            height: 40px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: all 0.3s;
        }

        .overlay-close:hover {
            background: rgba(255, 255, 255, 0.3);
            transform: scale(1.1);
        }

        .overlay-body {
            padding: 30px;
        }

        .overlay-section {
            margin-bottom: 30px;
        }

        .overlay-section h3 {
            color: #2d3748;
            font-size: 18px;
            margin-bottom: 16px;
            padding-bottom: 12px;
            border-bottom: 2px solid #e2e8f0;
        }

        .info-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 16px;
            margin-bottom: 20px;
        }

        .info-card {
            background: #f7fafc;
            padding: 16px;
            border-radius: 12px;
        }

        .info-label {
            font-size: 12px;
            color: #718096;
            text-transform: uppercase;
            letter-spacing: 0.05em;
            font-weight: 600;
            margin-bottom: 6px;
        }

        .info-value {
            font-size: 16px;
            color: #2d3748;
            font-weight: 700;
        }

        .balance-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
            gap: 12px;
        }

        .balance-card {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 16px;
            border-radius: 12px;
            text-align: center;
        }

        .balance-label {
            font-size: 11px;
            text-transform: uppercase;
            letter-spacing: 0.05em;
            opacity: 0.9;
            margin-bottom: 8px;
        }

        .balance-value {
            font-size: 18px;
            font-weight: 700;
        }

        .downline-table {
            width: 100%;
            border-collapse: collapse;
        }

        .downline-table th {
            text-align: left;
            padding: 12px;
            background: #f7fafc;
            color: #4a5568;
            font-weight: 600;
            border-bottom: 2px solid #e2e8f0;
            font-size: 13px;
        }

        .downline-table td {
            padding: 12px;
            color: #2d3748;
            border-bottom: 1px solid #e2e8f0;
            font-size: 14px;
        }

        .downline-table tbody tr:hover {
            background: #f7fafc;
        }

        .badge-account {
            display: inline-block;
            padding: 4px 8px;
            border-radius: 6px;
            font-size: 11px;
            font-weight: 600;
        }

        .badge-free {
            background: #fee2e2;
            color: #991b1b;
        }

        .badge-premium {
            background: #fef3c7;
            color: #92400e;
        }

        .badge-premium-plus {
            background: #d1fae5;
            color: #065f46;
        }

        .loading-spinner {
            text-align: center;
            padding: 40px 20px;
        }

        .spinner {
            border: 4px solid #e2e8f0;
            border-top: 4px solid #667eea;
            border-radius: 50%;
            width: 40px;
            height: 40px;
            animation: spin 1s linear infinite;
            margin: 0 auto 16px;
        }

        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }

        @media (max-width: 768px) {
            .overlay-content {
                max-width: 100%;
                margin: 0;
                border-radius: 16px;
            }

            .overlay-header {
                padding: 20px;
            }

            .overlay-body {
                padding: 20px;
            }

            .info-grid {
                grid-template-columns: 1fr;
            }

            .downline-table {
                font-size: 12px;
            }

            .downline-table th,
            .downline-table td {
                padding: 8px;
            }
        }

        @media (max-width: 768px) {
            body {
                padding: 12px;
            }

            .admin-main {
                padding: 0;
            }

            .admin-header {
                padding: 16px;
                margin-bottom: 12px;
                border-radius: 12px;
            }

            .admin-header h1 {
                font-size: 18px;
                margin-bottom: 4px;
            }

            .admin-header p {
                font-size: 12px;
            }

            .stats-grid {
                grid-template-columns: 1fr 1fr;
                gap: 10px;
                margin-bottom: 12px;
            }

            .stat-card {
                padding: 12px;
                border-radius: 10px;
            }

            .stat-card h3 {
                font-size: 11px;
                margin-bottom: 4px;
            }

            .stat-card .value {
                font-size: 18px;
            }

            .content-section {
                padding: 12px;
                margin-bottom: 12px;
                border-radius: 10px;
            }

            .content-section h2 {
                font-size: 14px;
                margin-bottom: 12px;
            }

            table {
                min-width: 750px;
                display: inline-block;
                overflow-x: auto;
            }

            th {
                padding: 8px;
                font-size: 11px;
            }

            td {
                padding: 8px;
                font-size: 10px;
            }

            .status-badge {
                padding: 3px 8px;
                font-size: 9px;
            }

            .plan-breakdown-small {
                grid-template-columns: repeat(4, 1fr);
                gap: 4px;
                margin-top: 6px;
                font-size: 0.75rem;
            }

            .plan-item-small {
                padding: 4px 3px;
                border-radius: 4px;
            }

            .plan-label-small {
                font-size: 0.6rem;
            }

            .plan-count-small {
                font-size: 0.85rem;
            }
        }
    </style>
</head>
<body>
     <?php include 'side-bar.php'; ?>
<div class="admin-content">

         Main Content 
        <main class="admin-main">
            <div class="admin-header">
                <h1>Referral System</h1>
                <p>Monitor and manage the referral program</p>
            </div>

             Stats 
            <div class="stats-grid">
                <div class="stat-card">
                    <h3>Total Referrals</h3>
                    <div class="value"><?php echo number_format($stats['total_referrals']); ?></div>
                </div>
                <div class="stat-card">
                    <h3>Active Referrers</h3>
                    <div class="value"><?php echo number_format($stats['total_referrers']); ?></div>
                </div>
                <div class="stat-card">
                    <h3>Completed</h3>
                    <div class="value" style="color: #10b981;"><?php echo number_format($stats['completed_referrals']); ?></div>
                </div>
                <div class="stat-card">
                    <h3>Pending</h3>
                    <div class="value" style="color: #f59e0b;"><?php echo number_format($stats['pending_referrals']); ?></div>
                </div>
                <div class="stat-card">
                    <h3>Total Earnings Paid</h3>
                    <div class="value">₦<?php echo number_format($earnings['total_earnings'] ?? 0, 2); ?></div>
                </div>
            </div>

             Search Section 
            <div class="content-section">
                <div style="margin-bottom: 20px;">
                    <form method="GET" style="display: flex; gap: 10px; align-items: center; flex-wrap: wrap;">
                        <input type="text" name="search" placeholder="Search by username or email..." value="<?php echo htmlspecialchars($search); ?>" style="flex: 1; min-width: 250px; padding: 10px 15px; border: 1px solid #e2e8f0; border-radius: 8px; font-size: 14px;">
                        <button type="submit" style="padding: 10px 20px; background: #667eea; color: white; border: none; border-radius: 8px; font-weight: 600; cursor: pointer; white-space: nowrap;">Search</button>
                        <?php if (!empty($search)): ?>
                            <a href="referrals.php" style="padding: 10px 20px; background: #64748b; color: white; border-radius: 8px; font-weight: 600; text-decoration: none; white-space: nowrap;">Clear</a>
                        <?php endif; ?>
                    </form>
                </div>
            </div>

             Top Referrers 
            <div class="content-section">
                <h2>Top Referrers</h2>
                <div style="overflow-x: auto; -webkit-overflow-scrolling: touch;">
                <table>
                    <thead>
                        <tr>
                            <th>Rank</th>
                            <th>User</th>
                            <th>Referral Code</th>
                            <th>Total Referrals</th>
                            <th>Completed</th>
                            <th>Downline Breakdown</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $rank = 1; foreach ($top_referrers as $referrer): ?>
                            <tr style="cursor: pointer;" onclick="openReferrerOverlay(<?php echo $referrer['id']; ?>)">
                                <td><strong>#<?php echo $rank++; ?></strong></td>
                                <td>
                                    <strong><?php echo htmlspecialchars($referrer['username']); ?></strong><br>
                                    <small><?php echo htmlspecialchars($referrer['email']); ?></small>
                                </td>
                                <td><code><?php echo htmlspecialchars($referrer['referral_code']); ?></code></td>
                                <td><strong><?php echo $referrer['referral_count']; ?></strong></td>
                                <td><strong style="color: #10b981;"><?php echo $referrer['completed_count']; ?></strong></td>
                                <td>
                                    <div class="plan-breakdown-small">
                                        <div class="plan-item-small">
                                            <div class="plan-label-small">Total</div>
                                            <div class="plan-count-small"><?php echo $referrer['total_downline']; ?></div>
                                        </div>
                                        <div class="plan-item-small">
                                            <div class="plan-label-small">Free</div>
                                            <div class="plan-count-small"><?php echo $referrer['free_downline']; ?></div>
                                        </div>
                                        <div class="plan-item-small">
                                            <div class="plan-label-small">Premium</div>
                                            <div class="plan-count-small"><?php echo $referrer['premium_downline']; ?></div>
                                        </div>
                                        <div class="plan-item-small">
                                            <div class="plan-label-small">Plus</div>
                                            <div class="plan-count-small"><?php echo $referrer['premium_plus_downline']; ?></div>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                </div>
            </div>

             Referred Users 
            <div class="content-section">
                <h2>Referred Users <?php if (!empty($search)) echo "- Search Results for \"" . htmlspecialchars($search) . "\""; ?></h2>
                <div style="overflow-x: auto; -webkit-overflow-scrolling: touch;">
                <table>
                    <thead>
                        <tr>
                            <th>Username</th>
                            <th>Email</th>
                            <th>Referred By</th>
                            <th>Plan Type</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (!empty($recent_referrals)): ?>
                            <?php foreach ($recent_referrals as $referral): ?>
                                <tr>
                                    <td><strong><?php echo htmlspecialchars($referral['referred_name']); ?></strong></td>
                                    <td><?php echo htmlspecialchars($referral['referred_email']); ?></td>
                                    <td><strong><?php echo htmlspecialchars($referral['referrer_name']); ?></strong></td>
                                    <td>
                                        <?php 
                                        $plan_type = 'Free';
                                        if ($referral['membership_type'] === 'premium') {
                                            $plan_type = ($referral['advertiser_plan'] === 'senior') ? 'Premium Plus' : 'Premium';
                                        }
                                        echo $plan_type;
                                        ?>
                                    </td>
                                    <td>
                                        <span class="status-badge" style="background: #d1fae5; color: #065f46;">Active</span>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="5" style="text-align: center; color: #64748b;">No referrals found</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
                </div>
            </div>
        </main>
    </div>

    <!-- Referrer Overlay -->
    <div class="overlay-backdrop" id="overlayBackdrop"></div>
    <div class="referrer-overlay" id="referrerOverlay">
        <div class="overlay-content">
            <div class="overlay-header">
                <div class="overlay-header-info">
                    <h2 id="overlayUsername">Loading...</h2>
                    <p id="overlayEmail">Email</p>
                </div>
                <button class="overlay-close" onclick="closeReferrerOverlay()">&times;</button>
            </div>
            <div class="overlay-body" id="overlayBody">
                <div class="loading-spinner">
                    <div class="spinner"></div>
                    <p>Loading referrer details...</p>
                </div>
            </div>
        </div>
    </div>

    <script>
        function openReferrerOverlay(referrerId) {
            const overlay = document.getElementById('referrerOverlay');
            const backdrop = document.getElementById('overlayBackdrop');
            const body = document.getElementById('overlayBody');
            
            overlay.classList.add('active');
            backdrop.classList.add('active');
            
            // Fetch referrer details
            fetch(`api/get-referral-details.php?id=${referrerId}`)
                .then(res => res.json())
                .then(data => {
                    if (data.error) {
                        body.innerHTML = `<p style="color: red; text-align: center; padding: 20px;">Error: ${data.error}</p>`;
                        return;
                    }
                    
                    // Update header
                    document.getElementById('overlayUsername').textContent = data.referrer.username;
                    document.getElementById('overlayEmail').textContent = data.referrer.email;
                    
                    // Build content
                    let accountTypeBadge = 'badge-free';
                    if (data.account_type === 'Premium') accountTypeBadge = 'badge-premium';
                    if (data.account_type === 'Premium Plus') accountTypeBadge = 'badge-premium-plus';
                    
                    let html = `
                        <!-- Account Information Section -->
                        <div class="overlay-section">
                            <h3>Account Information</h3>
                            <div class="info-grid">
                                <div class="info-card">
                                    <div class="info-label">Account Type</div>
                                    <div class="info-value">
                                        <span class="badge-account ${accountTypeBadge}">${data.account_type}</span>
                                    </div>
                                </div>
                                <div class="info-card">
                                    <div class="info-label">Total Downlines</div>
                                    <div class="info-value">${data.downline_stats.total}</div>
                                </div>
                                <div class="info-card">
                                    <div class="info-label">Referral Code</div>
                                    <div class="info-value" style="font-family: monospace; font-size: 14px;">${data.referrer.referral_code || 'N/A'}</div>
                                </div>
                                <div class="info-card">
                                    <div class="info-label">Member Since</div>
                                    <div class="info-value">${new Date(data.referrer.created_at).toLocaleDateString()}</div>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Downline Breakdown Section -->
                        <div class="overlay-section">
                            <h3>Downline Breakdown (4 Account Types)</h3>
                            <div class="balance-grid">
                                <div class="balance-card">
                                    <div class="balance-label">Total</div>
                                    <div class="balance-value">${data.downline_stats.total}</div>
                                </div>
                                <div class="balance-card" style="background: linear-gradient(135deg, #f87171 0%, #dc2626 100%);">
                                    <div class="balance-label">Free Users</div>
                                    <div class="balance-value">${data.downline_stats.free}</div>
                                </div>
                                <div class="balance-card" style="background: linear-gradient(135deg, #fbbf24 0%, #f59e0b 100%);">
                                    <div class="balance-label">Premium</div>
                                    <div class="balance-value">${data.downline_stats.premium}</div>
                                </div>
                                <div class="balance-card" style="background: linear-gradient(135deg, #34d399 0%, #10b981 100%);">
                                    <div class="balance-label">Premium Plus</div>
                                    <div class="balance-value">${data.downline_stats.premium_plus}</div>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Balance Information Section -->
                        <div class="overlay-section">
                            <h3>Earnings Balance</h3>
                            <div class="balance-grid">
                                <div class="balance-card">
                                    <div class="balance-label">Total Balance</div>
                                    <div class="balance-value">₦${parseFloat(data.balance.total_balance || 0).toLocaleString('en-NG', {minimumFractionDigits: 2, maximumFractionDigits: 2})}</div>
                                </div>
                                <div class="balance-card" style="background: linear-gradient(135deg, #60a5fa 0%, #3b82f6 100%);">
                                    <div class="balance-label">Task Earnings</div>
                                    <div class="balance-value">₦${parseFloat(data.balance.task_earnings || 0).toLocaleString('en-NG', {minimumFractionDigits: 2, maximumFractionDigits: 2})}</div>
                                </div>
                                <div class="balance-card" style="background: linear-gradient(135deg, #a78bfa 0%, #8b5cf6 100%);">
                                    <div class="balance-label">Referral Earnings</div>
                                    <div class="balance-value">₦${parseFloat(data.balance.referral_earnings || 0).toLocaleString('en-NG', {minimumFractionDigits: 2, maximumFractionDigits: 2})}</div>
                                </div>
                                <div class="balance-card" style="background: linear-gradient(135deg, #fb7185 0%, #f43f5e 100%);">
                                    <div class="balance-label">Game Earnings</div>
                                    <div class="balance-value">₦${parseFloat(data.balance.game_earnings || 0).toLocaleString('en-NG', {minimumFractionDigits: 2, maximumFractionDigits: 2})}</div>
                                </div>
                            </div>
                        </div>
                        
                        <!-- All Downlines Section -->
                        <div class="overlay-section">
                            <h3>All Downlines (${data.downlines.length})</h3>
                            <div style="overflow-x: auto;">
                                <table class="downline-table">
                                    <thead>
                                        <tr>
                                            <th>Username</th>
                                            <th>Email</th>
                                            <th>Account Type</th>
                                            <th>Joined</th>
                                            <th>Total Balance</th>
                                            <th>Referral Balance</th>
                                            <th>Task Balance</th>
                                            <th>Game Balance</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                    `;
                    
                    if (data.downlines.length === 0) {
                        html += `<tr><td colspan="8" style="text-align: center; color: #718096;">No downlines yet</td></tr>`;
                    } else {
                        data.downlines.forEach(downline => {
                            const accountType = downline.membership_type === 'premium' 
                                ? (downline.advertiser_plan === 'senior' ? 'Premium Plus' : 'Premium')
                                : 'Free';
                            let badgeClass = 'badge-free';
                            if (accountType === 'Premium') badgeClass = 'badge-premium';
                            if (accountType === 'Premium Plus') badgeClass = 'badge-premium-plus';
                            
                            html += `
                                <tr>
                                    <td><strong>${downline.username}</strong></td>
                                    <td>${downline.email}</td>
                                    <td><span class="badge-account ${badgeClass}">${accountType}</span></td>
                                    <td>${new Date(downline.created_at).toLocaleDateString()}</td>
                                    <td>₦${parseFloat(downline.total_balance || 0).toLocaleString('en-NG', {minimumFractionDigits: 2, maximumFractionDigits: 2})}</td>
                                    <td>₦${parseFloat(downline.referral_earnings || 0).toLocaleString('en-NG', {minimumFractionDigits: 2, maximumFractionDigits: 2})}</td>
                                    <td>₦${parseFloat(downline.task_earnings || 0).toLocaleString('en-NG', {minimumFractionDigits: 2, maximumFractionDigits: 2})}</td>
                                    <td>₦${parseFloat(downline.game_earnings || 0).toLocaleString('en-NG', {minimumFractionDigits: 2, maximumFractionDigits: 2})}</td>
                                </tr>
                            `;
                        });
                    }
                    
                    html += `
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    `;
                    
                    body.innerHTML = html;
                })
                .catch(err => {
                    console.error('Error:', err);
                    body.innerHTML = '<p style="color: red; text-align: center; padding: 20px;">Error loading referrer details</p>';
                });
        }
        
        function closeReferrerOverlay() {
            document.getElementById('referrerOverlay').classList.remove('active');
            document.getElementById('overlayBackdrop').classList.remove('active');
        }
        
        // Close overlay when clicking backdrop
        document.getElementById('overlayBackdrop').addEventListener('click', closeReferrerOverlay);
        
        // Close overlay on ESC key
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape') closeReferrerOverlay();
        });
    </script>
</body>
</html>
