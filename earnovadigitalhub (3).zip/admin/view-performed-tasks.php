<?php
session_start();
require_once '../config/database.php';

// Check if user is admin
if (!isset($_SESSION['user_id'])) {
    header('Location: ../login.php');
    exit();
}

$user_id = $_SESSION['user_id'];
$stmt = $conn->prepare("SELECT is_admin FROM users WHERE id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();

if (!$user || $user['is_admin'] != 1) {
    header('Location: ../dashboard.php');
    exit();
}

// Get filter parameters
$search_user = isset($_GET['search_user']) ? trim($_GET['search_user']) : '';
$search_task = isset($_GET['search_task']) ? trim($_GET['search_task']) : '';
$filter_platform = isset($_GET['filter_platform']) ? trim($_GET['filter_platform']) : '';
$filter_status = isset($_GET['filter_status']) ? trim($_GET['filter_status']) : 'completed';

// Get unique platforms for dropdown
$platforms_result = $conn->query("SELECT DISTINCT platform FROM tasks WHERE platform IS NOT NULL ORDER BY platform");
$platforms = $platforms_result ? $platforms_result->fetch_all(MYSQLI_ASSOC) : [];

// Build the main query
$query = "SELECT 
    ut.id as submission_id,
    ut.user_id,
    ut.task_id,
    ut.status,
    ut.proof_url,
    ut.completed_at,
    u.username,
    u.email as user_email,
    t.title as task_title,
    t.platform,
    t.task_type,
    COALESCE(uct.reward_amount, t.reward_amount) as reward_amount,
    t.created_at as task_created_at
    FROM user_tasks ut
    JOIN users u ON ut.user_id = u.id
    JOIN tasks t ON ut.task_id = t.id
    LEFT JOIN user_completed_tasks uct ON uct.user_id = ut.user_id AND uct.task_id = ut.task_id
    WHERE 1=1";

$params = [];
$types = "";

// Apply filters
if (!empty($search_user)) {
    $query .= " AND (u.username LIKE ? OR u.email LIKE ?)";
    $search_param = '%' . $search_user . '%';
    $params[] = $search_param;
    $params[] = $search_param;
    $types .= "ss";
}

if (!empty($search_task)) {
    $query .= " AND t.title LIKE ?";
    $search_param = '%' . $search_task . '%';
    $params[] = $search_param;
    $types .= "s";
}

if (!empty($filter_platform)) {
    $query .= " AND t.platform = ?";
    $params[] = $filter_platform;
    $types .= "s";
}

if (!empty($filter_status)) {
    $query .= " AND ut.status = ?";
    $params[] = $filter_status;
    $types .= "s";
}

$query .= " ORDER BY ut.completed_at DESC LIMIT 500";

// Execute query
$stmt = $conn->prepare($query);
if (!empty($params)) {
    $stmt->bind_param($types, ...$params);
}
$stmt->execute();
$submissions = $stmt->get_result()->fetch_all(MYSQLI_ASSOC) ?: [];

// Get stats
$stats_query = "SELECT 
    (SELECT COUNT(*) FROM user_tasks WHERE status = 'completed') as total_completed,
    (SELECT COUNT(DISTINCT user_id) FROM user_tasks WHERE status = 'completed') as unique_users,
    (SELECT COUNT(*) FROM tasks) as total_tasks,
    (SELECT COUNT(DISTINCT platform) FROM tasks) as total_platforms,
    (SELECT COALESCE(SUM(reward_amount), 0) FROM user_completed_tasks) as total_earned";
$stats = $conn->query($stats_query)->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Performed Tasks - FlowEarner Admin</title>
    <link rel="stylesheet" href="../css/style.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        html, body {
            width: 100%;
            overflow-x: hidden;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px;
        }

        .admin-content {
            display: flex;
            width: 100%;
            max-width: 100%;
        }

        .admin-main {
            flex: 1;
            width: 100%;
            max-width: 100%;
            overflow-x: hidden;
        }

        .admin-header {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            padding: 30px;
            margin-bottom: 20px;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
        }

        .admin-header h1 {
            color: #2d3748;
            font-size: 32px;
            margin-bottom: 10px;
        }

        .admin-header p {
            color: #718096;
            font-size: 16px;
        }

        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
            gap: 15px;
            margin-bottom: 20px;
        }

        .stat-card {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 15px;
            padding: 20px;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
            text-align: center;
        }

        .stat-card h3 {
            color: #718096;
            font-size: 12px;
            text-transform: uppercase;
            letter-spacing: 0.05em;
            margin-bottom: 8px;
        }

        .stat-card .value {
            color: #2d3748;
            font-size: 28px;
            font-weight: bold;
        }

        .content-section {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            padding: 30px;
            margin-bottom: 20px;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
        }

        .content-section h2 {
            color: #2d3748;
            font-size: 24px;
            margin-bottom: 20px;
        }

        .filters-section {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
            margin-bottom: 20px;
        }

        .filter-group {
            display: flex;
            flex-direction: column;
        }

        .filter-group label {
            font-size: 13px;
            color: #4a5568;
            text-transform: uppercase;
            letter-spacing: 0.05em;
            font-weight: 600;
            margin-bottom: 8px;
        }

        .filter-group input,
        .filter-group select {
            padding: 12px 15px;
            border: 1px solid #e2e8f0;
            border-radius: 8px;
            font-size: 14px;
            transition: all 0.3s;
        }

        .filter-group input:focus,
        .filter-group select:focus {
            outline: none;
            border-color: #667eea;
            box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
        }

        .filter-buttons {
            display: flex;
            gap: 10px;
            align-items: flex-end;
        }

        .btn-search {
            padding: 12px 24px;
            background: #667eea;
            color: white;
            border: none;
            border-radius: 8px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
        }

        .btn-search:hover {
            background: #5568d3;
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(102, 126, 234, 0.4);
        }

        .btn-clear {
            padding: 12px 24px;
            background: #e2e8f0;
            color: #4a5568;
            border: none;
            border-radius: 8px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
        }

        .btn-clear:hover {
            background: #cbd5e0;
        }

        .tasks-table {
            background: white;
            border-radius: 12px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            overflow-x: auto;
            -webkit-overflow-scrolling: touch;
            width: 100%;
            max-width: 100%;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            font-size: 14px;
            table-layout: auto;
        }

        th {
            text-align: left;
            padding: 15px;
            color: #4a5568;
            font-weight: 600;
            background: #f7fafc;
            border-bottom: 2px solid #e2e8f0;
            white-space: nowrap;
        }

        td {
            padding: 12px 15px;
            color: #2d3748;
            border-bottom: 1px solid #e2e8f0;
        }

        tr:hover {
            background: #f7fafc;
        }

        .badge {
            display: inline-block;
            padding: 4px 10px;
            border-radius: 20px;
            font-size: 11px;
            font-weight: 600;
        }

        .badge-completed {
            background: #d1fae5;
            color: #065f46;
        }

        .badge-pending {
            background: #fef3c7;
            color: #92400e;
        }

        .badge-in-progress {
            background: #bfdbfe;
            color: #1e3a8a;
        }

        .badge-rejected {
            background: #fecaca;
            color: #991b1b;
        }

        .badge-platform {
            background: #e0e7ff;
            color: #3730a3;
            font-weight: 700;
        }

        .proof-url {
            max-width: 300px;
            word-break: break-all;
            font-family: 'Courier New', monospace;
            font-size: 12px;
            background: #f0f4f8;
            padding: 8px;
            border-radius: 6px;
            border-left: 3px solid #667eea;
        }

        .proof-link {
            color: #667eea;
            text-decoration: none;
            word-break: break-all;
        }

        .proof-link:hover {
            text-decoration: underline;
        }

        .user-info {
            display: flex;
            flex-direction: column;
        }

        .username {
            font-weight: 700;
            color: #2d3748;
        }

        .user-email {
            font-size: 12px;
            color: #718096;
        }

        .task-info {
            display: flex;
            flex-direction: column;
        }

        .task-title {
            font-weight: 700;
            color: #2d3748;
            max-width: 200px;
            white-space: normal;
        }

        .task-type {
            font-size: 11px;
            color: #718096;
            text-transform: uppercase;
        }

        .timestamp {
            font-size: 12px;
            color: #718096;
        }

        .no-data {
            text-align: center;
            padding: 40px 20px;
            color: #718096;
        }

        .table-wrapper {
            overflow-x: auto;
            -webkit-overflow-scrolling: touch;
        }

        .result-count {
            color: #718096;
            font-size: 14px;
            margin-bottom: 15px;
        }

        @media (max-width: 768px) {
            html, body {
                width: 100%;
                overflow-x: hidden;
                margin: 0;
                padding: 0;
            }

            body {
                padding: 12px;
            }

            .admin-content {
                width: 100%;
                max-width: 100%;
                overflow-x: hidden;
            }

            .admin-main {
                padding: 0;
                width: 100%;
                max-width: 100%;
                overflow-x: hidden;
            }

            .admin-header {
                padding: 16px;
                margin-bottom: 12px;
                border-radius: 12px;
            }

            .admin-header h1 {
                font-size: 18px;
                margin-bottom: 4px;
            }

            .admin-header p {
                font-size: 12px;
            }

            .stats-grid {
                grid-template-columns: repeat(2, 1fr);
                gap: 10px;
                margin-bottom: 12px;
            }

            .stat-card {
                padding: 12px;
                border-radius: 10px;
            }

            .stat-card h3 {
                font-size: 10px;
                margin-bottom: 4px;
            }

            .stat-card .value {
                font-size: 20px;
            }

            .content-section {
                padding: 16px;
                margin-bottom: 12px;
                border-radius: 10px;
                width: 100%;
                max-width: 100%;
                overflow-x: hidden;
            }

            .content-section h2 {
                font-size: 16px;
                margin-bottom: 12px;
            }

            .filters-section {
                grid-template-columns: 1fr;
                gap: 10px;
                margin-bottom: 12px;
            }

            .filter-group label {
                font-size: 11px;
                margin-bottom: 6px;
            }

            .filter-group input,
            .filter-group select {
                padding: 10px 12px;
                font-size: 13px;
            }

            .filter-buttons {
                flex-direction: column;
                gap: 8px;
            }

            .btn-search, .btn-clear {
                width: 100%;
                padding: 10px 16px;
                font-size: 13px;
            }

            .result-count {
                font-size: 12px;
                margin-bottom: 10px;
            }

            .tasks-table {
                border-radius: 8px;
                width: 100%;
                max-width: 100%;
                overflow-x: auto;
                -webkit-overflow-scrolling: touch;
                margin: 0;
                padding: 0;
            }

            table {
                min-width: 900px;
                font-size: 12px;
                width: 100%;
                table-layout: fixed;
            }

            th {
                padding: 10px 8px;
                font-size: 11px;
            }

            td {
                padding: 10px 8px;
                font-size: 11px;
            }

            .user-info,
            .task-info {
                flex-direction: column;
                gap: 2px;
            }

            .username {
                font-size: 12px;
            }

            .user-email {
                font-size: 10px;
            }

            .task-title {
                font-size: 11px;
                max-width: 120px;
                line-height: 1.3;
            }

            .task-type {
                font-size: 10px;
            }

            .badge {
                padding: 3px 6px;
                font-size: 10px;
            }

            .badge-platform {
                font-size: 9px;
                padding: 3px 5px;
            }

            .proof-url {
                max-width: 120px;
                font-size: 10px;
                padding: 6px;
            }

            .timestamp {
                font-size: 10px;
                white-space: nowrap;
            }
        }
    </style>
</head>
<body>
    <?php include 'side-bar.php'; ?>
    <div class="admin-content">
        <main class="admin-main">
            <!-- Header -->
            <div class="admin-header">
                <h1>Performed Tasks Tracker</h1>
                <p>View all user task submissions with complete transparency</p>
            </div>

            <!-- Stats -->
            <div class="stats-grid">
                <div class="stat-card">
                    <h3>Total Completions</h3>
                    <div class="value"><?php echo number_format($stats['total_completed'] ?? 0); ?></div>
                </div>
                <div class="stat-card">
                    <h3>Unique Users</h3>
                    <div class="value"><?php echo number_format($stats['unique_users'] ?? 0); ?></div>
                </div>
                <div class="stat-card">
                    <h3>Total Tasks</h3>
                    <div class="value"><?php echo number_format($stats['total_tasks'] ?? 0); ?></div>
                </div>
                <div class="stat-card">
                    <h3>Platforms</h3>
                    <div class="value"><?php echo number_format($stats['total_platforms'] ?? 0); ?></div>
                </div>
                <div class="stat-card">
                    <h3>Total Earned</h3>
                    <div class="value">₦<?php echo number_format($stats['total_earned'] ?? 0, 2); ?></div>
                </div>
            </div>

            <!-- Filters Section -->
            <div class="content-section">
                <form method="GET" style="display: block;">
                    <div class="filters-section">
                        <div class="filter-group">
                            <label for="search_user">Search User</label>
                            <input type="text" id="search_user" name="search_user" placeholder="Username or email..." value="<?php echo htmlspecialchars($search_user); ?>">
                        </div>

                        <div class="filter-group">
                            <label for="search_task">Search Task</label>
                            <input type="text" id="search_task" name="search_task" placeholder="Task title..." value="<?php echo htmlspecialchars($search_task); ?>">
                        </div>

                        <div class="filter-group">
                            <label for="filter_platform">Platform</label>
                            <select id="filter_platform" name="filter_platform">
                                <option value="">All Platforms</option>
                                <?php foreach ($platforms as $p): ?>
                                    <option value="<?php echo htmlspecialchars($p['platform']); ?>" <?php echo ($filter_platform === $p['platform']) ? 'selected' : ''; ?>>
                                        <?php echo ucfirst($p['platform']); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div class="filter-group">
                            <label for="filter_status">Status</label>
                            <select id="filter_status" name="filter_status">
                                <option value="completed" <?php echo ($filter_status === 'completed') ? 'selected' : ''; ?>>Completed</option>
                                <option value="pending" <?php echo ($filter_status === 'pending') ? 'selected' : ''; ?>>Pending</option>
                                <option value="in_progress" <?php echo ($filter_status === 'in_progress') ? 'selected' : ''; ?>>In Progress</option>
                                <option value="rejected" <?php echo ($filter_status === 'rejected') ? 'selected' : ''; ?>>Rejected</option>
                                <option value="">All Statuses</option>
                            </select>
                        </div>
                    </div>

                    <div class="filter-buttons">
                        <button type="submit" class="btn-search">Search & Filter</button>
                        <a href="view-performed-tasks.php" class="btn-clear" style="text-decoration: none; text-align: center;">Clear Filters</a>
                    </div>
                </form>
            </div>

            <!-- Submissions Table -->
            <div class="content-section">
                <h2>Task Submissions</h2>
                <?php if (count($submissions) > 0): ?>
                    <div class="result-count">
                        Showing <strong><?php echo count($submissions); ?></strong> submission(s)
                    </div>
                    <div class="tasks-table">
                        <table>
                            <thead>
                                <tr>
                                    <th>User</th>
                                    <th>Task</th>
                                    <th>Platform</th>
                                    <th>Type</th>
                                    <th>Status</th>
                                    <th>Proof URL / Contact</th>
                                    <th>Reward</th>
                                    <th>Completed</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($submissions as $submission): ?>
                                    <tr>
                                        <td>
                                            <div class="user-info">
                                                <span class="username"><?php echo htmlspecialchars($submission['username']); ?></span>
                                                <span class="user-email"><?php echo htmlspecialchars($submission['user_email']); ?></span>
                                            </div>
                                        </td>
                                        <td>
                                            <div class="task-info">
                                                <span class="task-title"><?php echo htmlspecialchars($submission['task_title']); ?></span>
                                                <span class="task-type"><?php echo str_replace('_', ' ', $submission['task_type']); ?></span>
                                            </div>
                                        </td>
                                        <td>
                                            <span class="badge badge-platform"><?php echo ucfirst($submission['platform']); ?></span>
                                        </td>
                                        <td><?php echo str_replace('_', ' ', $submission['task_type']); ?></td>
                                        <td>
                                            <?php 
                                            $status = $submission['status'];
                                            $badge_class = 'badge-' . $status;
                                            ?>
                                            <span class="badge <?php echo $badge_class; ?>"><?php echo ucfirst($status); ?></span>
                                        </td>
                                        <td>
                                            <div class="proof-url">
                                                <?php 
                                                $proof = htmlspecialchars($submission['proof_url']);
                                                // Check if it looks like a URL
                                                if (strpos($proof, 'http') === 0): ?>
                                                    <a href="<?php echo htmlspecialchars($submission['proof_url']); ?>" target="_blank" class="proof-link">View Proof</a>
                                                <?php else: ?>
                                                    <span><?php echo $proof; ?></span>
                                                <?php endif; ?>
                                            </div>
                                        </td>
                                        <td><strong>₦<?php echo number_format($submission['reward_amount'], 2); ?></strong></td>
                                        <td>
                                            <span class="timestamp"><?php echo date('M d, Y', strtotime($submission['completed_at'])); ?></span>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <div class="no-data">
                        <p>No task submissions found matching your criteria.</p>
                    </div>
                <?php endif; ?>
            </div>
        </main>
    </div>
</body>
</html>
