<?php
session_start();
require_once '../config/database.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: ../login.php');
    exit();
}

$user_id = $_SESSION['user_id'];
$stmt = $conn->prepare("SELECT is_admin FROM users WHERE id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();

if (!$user || $user['is_admin'] != 1) {
    header('Location: ../dashboard.php');
    exit();
}

$search_user = isset($_GET['search_user']) ? trim($_GET['search_user']) : '';
$search_track = isset($_GET['search_track']) ? trim($_GET['search_track']) : '';
$filter_type = isset($_GET['filter_type']) ? trim($_GET['filter_type']) : '';
$tab = isset($_GET['tab']) ? trim($_GET['tab']) : 'all';

$streams = [];
$ad_streams = [];
$verified_emails = [];
// Function to fetch unfiltered stream statistics used by stat-cards
// Replace the single stats function with independent queries for each stat-card so filters/search do not affect totals
function query_total_streams($conn) {
    $count = 0;
    if ($conn->query("SELECT 1 FROM stream_earnings LIMIT 1")) {
        $res = $conn->query("SELECT COUNT(*) AS count FROM stream_earnings");
        if ($res) $count += (int)($res->fetch_assoc()['count'] ?? 0);
    }
    if ($conn->query("SELECT 1 FROM stream_ads_earnings LIMIT 1")) {
        $res = $conn->query("SELECT COUNT(*) AS count FROM stream_ads_earnings");
        if ($res) $count += (int)($res->fetch_assoc()['count'] ?? 0);
    }
    return $count;
}

function query_ad_streams($conn) {
    $count = 0;
    if ($conn->query("SELECT 1 FROM stream_ads_earnings LIMIT 1")) {
        $res = $conn->query("SELECT COUNT(*) AS count FROM stream_ads_earnings");
        if ($res) $count += (int)($res->fetch_assoc()['count'] ?? 0);
    }
    if ($conn->query("SELECT 1 FROM stream_earnings LIMIT 1") && $conn->query("SELECT 1 FROM stream_tracks LIMIT 1")) {
        $res = $conn->query("SELECT COUNT(*) AS count FROM stream_earnings se LEFT JOIN stream_tracks st ON se.track_id = st.track_id WHERE COALESCE(st.track_link, '') != ''");
        if ($res) $count += (int)($res->fetch_assoc()['count'] ?? 0);
    }
    return $count;
}

function query_unique_users($conn) {
    $union_subquery = [];
    if ($conn->query("SELECT 1 FROM stream_earnings LIMIT 1")) $union_subquery[] = "SELECT user_id FROM stream_earnings";
    if ($conn->query("SELECT 1 FROM stream_ads_earnings LIMIT 1")) $union_subquery[] = "SELECT user_id FROM stream_ads_earnings";
    if (empty($union_subquery)) return 0;
    $union_sql = implode(" UNION ", $union_subquery);
    $res = $conn->query("SELECT COUNT(DISTINCT user_id) AS count FROM (".$union_sql.") AS all_users");
    return (int)($res->fetch_assoc()['count'] ?? 0);
}

function query_total_payouts($conn) {
    $total = 0.0;
    if ($conn->query("SELECT 1 FROM stream_earnings LIMIT 1")) {
        $res = $conn->query("SELECT COALESCE(SUM(payout_amount), 0) as total FROM stream_earnings WHERE payout_status = 'paid'");
        if ($res) $total += (float)($res->fetch_assoc()['total'] ?? 0);
    }
    if ($conn->query("SELECT 1 FROM stream_ads_earnings LIMIT 1")) {
        $res = $conn->query("SELECT COALESCE(SUM(payout_amount), 0) as total FROM stream_ads_earnings WHERE payout_status = 'paid'");
        if ($res) $total += (float)($res->fetch_assoc()['total'] ?? 0);
    }
    return $total;
}

function query_eligible_streams($conn) {
    $count = 0;
    if ($conn->query("SELECT 1 FROM stream_earnings LIMIT 1")) {
        $res = $conn->query("SELECT COUNT(*) AS count FROM stream_earnings WHERE is_eligible = 1");
        if ($res) $count += (int)($res->fetch_assoc()['count'] ?? 0);
    }
    if ($conn->query("SELECT 1 FROM stream_ads_earnings LIMIT 1")) {
        $res = $conn->query("SELECT COUNT(*) AS count FROM stream_ads_earnings WHERE is_eligible = 1");
        if ($res) $count += (int)($res->fetch_assoc()['count'] ?? 0);
    }
    return $count;
}

function query_verified_emails_count($conn) {
    if ($conn->query("SELECT 1 FROM stream_ad_verified_emails LIMIT 1")) {
        $res = $conn->query("SELECT COUNT(*) AS count FROM stream_ad_verified_emails");
        if ($res) return (int)($res->fetch_assoc()['count'] ?? 0);
    }
    return 0;
}

function query_regular_tracks_count($conn) {
    $count = 0;
    if ($conn->query("SELECT 1 FROM stream_earnings LIMIT 1") && $conn->query("SELECT 1 FROM stream_tracks LIMIT 1")) {
        $res = $conn->query("SELECT COUNT(*) AS count FROM stream_earnings se LEFT JOIN stream_tracks st ON se.track_id = st.track_id WHERE COALESCE(st.track_link, '') = ''");
        if ($res) $count += (int)($res->fetch_assoc()['count'] ?? 0);
    }
    return $count;
}

// Initialize fallback stats array (for backward compatibility if other code references it)
$stats = [
    'total_streams' => 0,
    'unique_users' => 0,
    'ad_streams' => 0,
    'total_payouts' => 0,
    'eligible_streams' => 0,
    'verified_emails' => 0,
    'regular_tracks' => 0
];

// Compute independent stats before any content-related operations so filters/search can't affect them
$total_streams_count = query_total_streams($conn);
$ad_stream_count = query_ad_streams($conn);
$unique_users_count = query_unique_users($conn);
$total_payouts_amount = query_total_payouts($conn);
$eligible_streams_count = query_eligible_streams($conn);
$published_verified_emails_count = query_verified_emails_count($conn);
$regular_tracks_count = query_regular_tracks_count($conn);

// Mirror compute results into $stats array to keep compatibility with older code
$stats['total_streams'] = $total_streams_count;
$stats['ad_streams'] = $ad_stream_count;
$stats['unique_users'] = $unique_users_count;
$stats['total_payouts'] = $total_payouts_amount;
$stats['eligible_streams'] = $eligible_streams_count;
$stats['verified_emails'] = $published_verified_emails_count;
$stats['regular_tracks'] = $regular_tracks_count;

try {
    // Main stream_earnings data - Regular track streams
    if ($conn->query("SELECT 1 FROM stream_earnings LIMIT 1")) {
        $query = "SELECT 
            'regular' as stream_type,
            se.id as stream_id,
            se.user_id,
            se.track_id,
            se.track_title,
            se.stream_duration,
            se.completion_percentage,
            se.payout_amount,
            se.is_eligible,
            se.payout_status,
            se.ip_address,
            se.streamed_at,
            u.username,
            u.email as user_email,
            (CASE WHEN COALESCE(st.track_link, '') != '' THEN se.email ELSE NULL END) as email,
            COALESCE(st.track_link, '') as track_link,
            (CASE WHEN COALESCE(st.track_link, '') != '' THEN 1 ELSE 0 END) as is_ad
            FROM stream_earnings se
            JOIN users u ON se.user_id = u.id
            LEFT JOIN stream_tracks st ON se.track_id = st.track_id
            WHERE 1=1";

        $params = [];
        $types = "";

        if (!empty($search_user)) {
            $query .= " AND (u.username LIKE ? OR u.email LIKE ?)";
            $search_param = '%' . $search_user . '%';
            $params[] = $search_param;
            $params[] = $search_param;
            $types .= "ss";
        }

        if (!empty($search_track)) {
            $query .= " AND se.track_title LIKE ?";
            $search_param = '%' . $search_track . '%';
            $params[] = $search_param;
            $types .= "s";
        }

        if ($filter_type === 'ad' || $tab === 'ads') {
            $query .= " AND COALESCE(st.track_link, '') != ''";
        } elseif ($filter_type === 'normal' || $tab === 'regular') {
            $query .= " AND COALESCE(st.track_link, '') = ''";
        }

        $query .= " ORDER BY se.streamed_at DESC LIMIT 500";

        $stmt = $conn->prepare($query);
        if (!empty($params)) {
            $stmt->bind_param($types, ...$params);
        }
        $stmt->execute();
        $streams = array_merge($streams, $stmt->get_result()->fetch_all(MYSQLI_ASSOC) ?: []);
    }

    // Ad-specific streams from stream_ads_earnings
    if ($conn->query("SELECT 1 FROM stream_ads_earnings LIMIT 1")) {
        $query = "SELECT 
            'ad' as stream_type,
            sae.id as stream_id,
            sae.user_id,
            sae.track_id,
            sae.track_title,
            sae.stream_duration,
            sae.completion_percentage,
            sae.payout_amount,
            sae.is_eligible,
            sae.payout_status,
            sae.ip_address,
            sae.streamed_at,
            u.username,
            u.email as user_email,
            (CASE WHEN COALESCE(st.track_link, '') != '' THEN sae.proof_email ELSE NULL END) as email,
            COALESCE(st.track_link, '') as track_link,
            (CASE WHEN COALESCE(st.track_link, '') != '' THEN 1 ELSE 0 END) as is_ad
            FROM stream_ads_earnings sae
            JOIN users u ON sae.user_id = u.id
            LEFT JOIN stream_tracks st ON sae.track_id = st.track_id
            WHERE 1=1";

        $params = [];
        $types = "";

        if (!empty($search_user)) {
            $query .= " AND (u.username LIKE ? OR u.email LIKE ?)";
            $search_param = '%' . $search_user . '%';
            $params[] = $search_param;
            $params[] = $search_param;
            $types .= "ss";
        }

        if (!empty($search_track)) {
            $query .= " AND sae.track_title LIKE ?";
            $search_param = '%' . $search_track . '%';
            $params[] = $search_param;
            $types .= "s";
        }

        if ($filter_type !== 'normal' && ($filter_type === 'ad' || $tab === 'ads' || $tab === 'all')) {
            if ($filter_type === 'ad' || $tab === 'ads') {
                $query .= " AND COALESCE(st.track_link, '') != ''";
            } elseif ($filter_type === 'normal' || $tab === 'regular') {
                $query .= " AND COALESCE(st.track_link, '') = ''";
            }
            $query .= " ORDER BY sae.streamed_at DESC LIMIT 500";
            $stmt = $conn->prepare($query);
            if (!empty($params)) {
                $stmt->bind_param($types, ...$params);
            }
            $stmt->execute();
            $ad_streams = $stmt->get_result()->fetch_all(MYSQLI_ASSOC) ?: [];
        }
    }

    // Get verified emails for ad streams (latest 100 list)
    if ($conn->query("SELECT 1 FROM stream_ad_verified_emails LIMIT 1")) {
        $result = $conn->query("SELECT save.email, save.verified_at, save.track_id, save.user_id, u.username FROM stream_ad_verified_emails save LEFT JOIN users u ON save.user_id = u.id ORDER BY save.verified_at DESC LIMIT 100");
        $verified_emails = $result->fetch_all(MYSQLI_ASSOC) ?: [];
    }

    // Stats already computed before content operations; no action required here


} catch (Exception $e) {
    // Silently continue with empty data
}

// Merge and sort all streams
$all_streams = array_merge($streams, $ad_streams);
usort($all_streams, function($a, $b) {
    return strtotime($b['streamed_at']) - strtotime($a['streamed_at']);
});

// Filter by tab
if ($tab === 'ads') {
    $all_streams = array_filter($all_streams, fn($s) => !empty($s['is_ad']) && $s['is_ad'] == 1);
} elseif ($tab === 'regular') {
    $all_streams = array_filter($all_streams, fn($s) => empty($s['is_ad']) || $s['is_ad'] == 0);
} elseif ($tab === 'verified-emails') {
    $all_streams = [];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Streamed Tracks - FlowEarner Admin</title>
    <link rel="stylesheet" href="../css/style.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        html, body {
            width: 100%;
            overflow-x: hidden;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px;
        }

        .admin-content {
            display: flex;
            width: 100%;
            max-width: 100%;
        }

        .admin-main {
            flex: 1;
            width: 100%;
            max-width: 100%;
            overflow-x: hidden;
        }

        .admin-header {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            padding: 30px;
            margin-bottom: 20px;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
        }

        .admin-header h1 {
            color: #2d3748;
            font-size: 32px;
            margin-bottom: 10px;
        }

        .admin-header p {
            color: #718096;
            font-size: 16px;
        }

        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(160px, 1fr));
            gap: 15px;
            margin-bottom: 20px;
        }

        .stat-card {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 15px;
            padding: 20px;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
            text-align: center;
        }

        .stat-card h3 {
            color: #718096;
            font-size: 11px;
            text-transform: uppercase;
            letter-spacing: 0.05em;
            margin-bottom: 8px;
            font-weight: 600;
        }

        .stat-card .value {
            color: #2d3748;
            font-size: 28px;
            font-weight: bold;
        }

        .tab-navigation {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 15px;
            padding: 0;
            margin-bottom: 20px;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
            display: flex;
            overflow-x: auto;
        }

        .tab-btn {
            flex: 1;
            padding: 15px 20px;
            background: transparent;
            border: none;
            color: #718096;
            font-weight: 600;
            cursor: pointer;
            border-bottom: 3px solid transparent;
            transition: all 0.3s;
            white-space: nowrap;
            text-align: center;
        }

        .tab-btn:hover {
            color: #667eea;
        }

        .tab-btn.active {
            color: #667eea;
            border-bottom-color: #667eea;
        }

        .content-section {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            padding: 30px;
            margin-bottom: 20px;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 100%;
            overflow-x: hidden;
        }

        .content-section h2 {
            color: #2d3748;
            font-size: 20px;
            margin-bottom: 20px;
        }

        .filters-section {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
            margin-bottom: 20px;
        }

        .filter-group {
            display: flex;
            flex-direction: column;
        }

        .filter-group label {
            font-size: 12px;
            color: #4a5568;
            text-transform: uppercase;
            letter-spacing: 0.05em;
            font-weight: 600;
            margin-bottom: 6px;
        }

        .filter-group input,
        .filter-group select {
            padding: 10px 12px;
            border: 1px solid #e2e8f0;
            border-radius: 8px;
            font-size: 13px;
        }

        .filter-group input:focus,
        .filter-group select:focus {
            outline: none;
            border-color: #667eea;
            box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
        }

        .filter-buttons {
            display: flex;
            gap: 10px;
            align-items: flex-end;
        }

        .btn-search {
            padding: 10px 20px;
            background: #667eea;
            color: white;
            border: none;
            border-radius: 8px;
            font-weight: 600;
            cursor: pointer;
            font-size: 13px;
        }

        .btn-search:hover {
            background: #5568d3;
        }

        .btn-clear {
            padding: 10px 20px;
            background: #e2e8f0;
            color: #4a5568;
            border: none;
            border-radius: 8px;
            font-weight: 600;
            cursor: pointer;
            font-size: 13px;
            text-decoration: none;
            display: inline-block;
        }

        .btn-clear:hover {
            background: #cbd5e0;
        }

        .table-container {
            background: white;
            border-radius: 12px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            overflow-x: auto;
            -webkit-overflow-scrolling: touch;
            width: 100%;
            max-width: 100%;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            font-size: 13px;
            min-width: 1200px;
        }

        th {
            text-align: left;
            padding: 12px;
            color: #4a5568;
            font-weight: 600;
            background: #f7fafc;
            border-bottom: 2px solid #e2e8f0;
            white-space: nowrap;
        }

        td {
            padding: 10px 12px;
            color: #2d3748;
            border-bottom: 1px solid #e2e8f0;
            font-size: 12px;
        }

        tr:hover {
            background: #f7fafc;
        }

        .badge {
            display: inline-block;
            padding: 4px 8px;
            border-radius: 6px;
            font-size: 11px;
            font-weight: 600;
            text-transform: uppercase;
        }

        .badge-ad {
            background: #fef3c7;
            color: #d97706;
        }

        .badge-regular {
            background: #d1fae5;
            color: #059669;
        }

        .badge-paid {
            background: #dbeafe;
            color: #0284c7;
        }

        .badge-pending {
            background: #fce7f3;
            color: #be185d;
        }

        .badge-eligible {
            background: #d1d5db;
            color: #374151;
        }

        .user-info {
            font-weight: 600;
            color: #2d3748;
        }

        .user-email {
            font-size: 11px;
            color: #718096;
            margin-top: 2px;
        }

        .email {
            font-size: 11px;
            color: #667eea;
            font-family: 'Courier New', monospace;
            background: #f0f4f8;
            padding: 4px 6px;
            border-radius: 4px;
            border-left: 3px solid #667eea;
            word-break: break-all;
            max-width: 150px;
        }

        .no-data {
            text-align: center;
            padding: 40px 20px;
            color: #718096;
        }

        .result-count {
            color: #718096;
            font-size: 13px;
            margin-bottom: 12px;
        }

        .verified-email-item {
            background: #f0f4f8;
            border-left: 4px solid #667eea;
            padding: 12px;
            margin-bottom: 10px;
            border-radius: 6px;
        }

        .verified-email-item strong {
            color: #2d3748;
            font-family: 'Courier New', monospace;
            display: block;
            margin-bottom: 4px;
        }

        .verified-email-item small {
            color: #718096;
        }

        @media (max-width: 768px) {
            body {
                padding: 12px;
            }

            .admin-header {
                padding: 16px;
                margin-bottom: 12px;
            }

            .admin-header h1 {
                font-size: 18px;
            }

            .stats-grid {
                grid-template-columns: repeat(2, 1fr);
                gap: 10px;
            }

            .stat-card {
                padding: 12px;
            }

            .stat-card h3 {
                font-size: 10px;
            }

            .stat-card .value {
                font-size: 20px;
            }

            .content-section {
                padding: 16px;
                margin-bottom: 12px;
            }

            .filters-section {
                grid-template-columns: 1fr;
                gap: 10px;
            }

            .filter-buttons {
                flex-direction: column;
            }

            .btn-search, .btn-clear {
                width: 100%;
            }

            table {
                min-width: 1000px;
                font-size: 11px;
            }

            th {
                padding: 8px;
                font-size: 10px;
            }

            td {
                padding: 8px;
            }

            .tab-navigation {
                border-radius: 10px;
            }

            .tab-btn {
                padding: 12px 10px;
                font-size: 12px;
            }
        }
    </style>
</head>
<body>
    <?php include 'side-bar.php'; ?>
    <div class="admin-content">
        <main class="admin-main">
            <div class="admin-header">
                <h1>Streamed Tracks - Complete Transparency</h1>
                <p>Multi-table blockchain-like tracking of all music streaming activities</p>
            </div>

            <!-- Stats Grid -->
            <div class="stats-grid">
                    <div class="stat-card">
                        <h3>Total Streams</h3>
                        <div class="value"><?php echo number_format($total_streams_count); ?></div>
                    </div>
                <div class="stat-card">
                    <h3>Ad Streams</h3>
                    <div class="value"><?php echo number_format($ad_stream_count); ?></div>
                </div>
                <div class="stat-card">
                    <h3>Regular Tracks</h3>
                    <div class="value"><?php echo number_format($regular_tracks_count); ?></div>
                </div>
                <div class="stat-card">
                    <h3>Unique Users</h3>
                    <div class="value"><?php echo number_format($unique_users_count); ?></div>
                </div>
                <div class="stat-card">
                    <h3>Total Payouts</h3>
                    <div class="value">₦<?php echo number_format($total_payouts_amount, 0); ?></div>
                </div>
                <div class="stat-card">
                    <h3>Eligible</h3>
                    <div class="value"><?php echo number_format($eligible_streams_count); ?></div>
                </div>
                <div class="stat-card">
                    <h3>Verified Emails</h3>
                    <div class="value"><?php echo number_format($published_verified_emails_count); ?></div>
                </div>
            </div>

            <!-- Tab Navigation -->
            <div class="tab-navigation">
                <button class="tab-btn <?php echo ($tab === 'all') ? 'active' : ''; ?>" onclick="location.href='?tab=all'">All Streams</button>
                <button class="tab-btn <?php echo ($tab === 'ads') ? 'active' : ''; ?>" onclick="location.href='?tab=ads'">Ad Streams</button>
                <button class="tab-btn <?php echo ($tab === 'regular') ? 'active' : ''; ?>" onclick="location.href='?tab=regular'">Regular Streams</button>
                <button class="tab-btn <?php echo ($tab === 'verified-emails') ? 'active' : ''; ?>" onclick="location.href='?tab=verified-emails'">Verified Emails</button>
            </div>

            <!-- Filters -->
            <div class="content-section">
                <form method="GET">
                    <input type="hidden" name="tab" value="<?php echo htmlspecialchars($tab); ?>">
                    <div class="filters-section">
                        <div class="filter-group">
                            <label>Search User</label>
                            <input type="text" name="search_user" placeholder="Username or email..." value="<?php echo htmlspecialchars($search_user); ?>">
                        </div>
                        <div class="filter-group">
                            <label>Search Track</label>
                            <input type="text" name="search_track" placeholder="Track title..." value="<?php echo htmlspecialchars($search_track); ?>">
                        </div>
                        <div class="filter-group">
                            <label>Track Type</label>
                            <select name="filter_type">
                                <option value="">All Types</option>
                                <option value="ad" <?php echo ($filter_type === 'ad') ? 'selected' : ''; ?>>Ad Tracks</option>
                                <option value="normal" <?php echo ($filter_type === 'normal') ? 'selected' : ''; ?>>Regular Tracks</option>
                            </select>
                        </div>
                    </div>
                    <div class="filter-buttons">
                        <button type="submit" class="btn-search">Search & Filter</button>
                        <a href="?tab=<?php echo htmlspecialchars($tab); ?>" class="btn-clear">Clear</a>
                    </div>
                </form>
            </div>

            <!-- Content by Tab -->
            <?php if ($tab === 'verified-emails'): ?>
                <div class="content-section">
                    <h2>Verified Emails for Ad Streams</h2>
                    <?php if (count($verified_emails) > 0): ?>
                        <div class="result-count">
                            <strong><?php echo count($verified_emails); ?></strong> verified email(s)
                        </div>
                        <?php foreach ($verified_emails as $email): ?>
                            <div class="verified-email-item">
                                <strong><?php echo htmlspecialchars($email['email']); ?></strong>
                                <?php if (!empty($email['username'])): ?>
                                    <small style="color: #667eea; font-weight: 600;">Username: <?php echo htmlspecialchars($email['username']); ?></small>
                                <?php endif; ?>
                                <small>Verified: <?php echo date('M d, Y H:i', strtotime($email['verified_at'])); ?></small>
                                <?php if ($email['track_id']): ?>
                                    <small> | Track: <?php echo htmlspecialchars($email['track_id']); ?></small>
                                <?php endif; ?>
                            </div>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <div class="no-data">
                            <p>No verified emails yet.</p>
                        </div>
                    <?php endif; ?>
                </div>
            <?php else: ?>
                <div class="content-section">
                    <h2><?php echo ($tab === 'ads') ? 'Ad Streams' : (($tab === 'regular') ? 'Regular Streams' : 'All Streams'); ?></h2>
                    <?php if (count($all_streams) > 0): ?>
                        <div class="result-count">
                            Showing <strong><?php echo count($all_streams); ?></strong> stream(s)
                        </div>
                        <div class="table-container">
                            <table>
                                <thead>
                                    <tr>
                                        <th>User</th>
                                        <th>Track Title</th>
                                        <th>Type</th>
                                        <th>Duration</th>
                                        <th>Completion</th>
                                        <th>Payout</th>
                                        <th>Eligible</th>
                                        <th>Status</th>
                                        <th>Email</th>
                                        <th>IP Address</th>
                                        <th>Streamed At</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($all_streams as $stream): ?>
                                        <tr>
                                            <td>
                                                <div class="user-info"><?php echo htmlspecialchars($stream['username']); ?></div>
                                                <div class="user-email"><?php echo htmlspecialchars($stream['user_email']); ?></div>
                                            </td>
                                            <td><?php echo htmlspecialchars(substr($stream['track_title'], 0, 30)); ?></td>
                                            <td>
                                                <span class="badge <?php echo (!empty($stream['is_ad']) && $stream['is_ad'] == 1) ? 'badge-ad' : 'badge-regular'; ?>">
                                                    <?php echo (!empty($stream['is_ad']) && $stream['is_ad'] == 1) ? 'Ad' : 'Regular'; ?>
                                                </span>
                                            </td>
                                            <td><?php echo $stream['stream_duration']; ?>s</td>
                                            <td><?php echo $stream['completion_percentage']; ?>%</td>
                                            <td><strong>₦<?php echo number_format($stream['payout_amount'], 2); ?></strong></td>
                                            <td>
                                                <span class="badge <?php echo ($stream['is_eligible']) ? 'badge-eligible' : ''; ?>">
                                                    <?php echo ($stream['is_eligible']) ? 'Yes' : 'No'; ?>
                                                </span>
                                            </td>
                                            <td>
                                                <span class="badge <?php echo ($stream['payout_status'] === 'paid') ? 'badge-paid' : 'badge-pending'; ?>">
                                                    <?php echo ucfirst($stream['payout_status']); ?>
                                                </span>
                                            </td>
                                            <td>
                                                <?php if (!empty($stream['is_ad']) && $stream['is_ad'] == 1 && !empty($stream['email'])): ?>
                                                    <div class="email"><?php echo htmlspecialchars($stream['email']); ?></div>
                                                <?php else: ?>
                                                    <small style="color: #cbd5e0;">-</small>
                                                <?php endif; ?>
                                            </td>
                                            <td style="font-size: 11px; font-family: monospace;"><?php echo htmlspecialchars(substr($stream['ip_address'], 0, 15)); ?></td>
                                            <td style="white-space: nowrap;"><?php echo date('M d, H:i', strtotime($stream['streamed_at'])); ?></td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php else: ?>
                        <div class="no-data">
                            <p>No streaming data found. Streams will appear here once users begin streaming tracks.</p>
                        </div>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        </main>
    </div>
</body>
</html>
