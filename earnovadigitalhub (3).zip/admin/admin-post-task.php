<?php
session_start();
require_once '../config/database.php';

// Check database connection and handle errors
if (!isset($conn) || $conn->connect_error) {
    http_response_code(500);
    header('Content-Type: application/json');
    echo json_encode(['error' => 'Database connection failed']);
    error_log('Admin Post Task - Database Connection Error: ' . ($conn->connect_error ?? 'No connection'));
    exit();
}

// Check if user is admin
if (!isset($_SESSION['user_id'])) {
    header('Location: ../login.php');
    exit();
}

$user_id = $_SESSION['user_id'];
$stmt = $conn->prepare("SELECT is_admin FROM users WHERE id = ?");
if (!$stmt) {
    http_response_code(500);
    header('Content-Type: application/json');
    echo json_encode(['error' => 'Database prepare failed: ' . $conn->error]);
    error_log('Admin Post Task - Prepare Error: ' . $conn->error);
    exit();
}

$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result()->fetch_assoc();

if (!$result || $result['is_admin'] != 1) {
    header('Location: ../dashboard.php');
    exit();
}

$success_message = '';
$error_message = '';

// Handle form submission and actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? 'create';
    
    // Validate CSRF token for security
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        $error_message = 'Security token validation failed.';
    } else {
        if ($action === 'delete') {
            // Handle delete action
            $task_id = intval($_POST['task_id'] ?? 0);
            if ($task_id > 0) {
                // Check if task has any submissions or completions
                $stmt = $conn->prepare("SELECT COUNT(*) as count FROM user_tasks WHERE task_id = ?");
                if (!$stmt) {
                    $error_message = 'Database error: ' . $conn->error;
                } else {
                    $stmt->bind_param("i", $task_id);
                    $stmt->execute();
                    $result = $stmt->get_result()->fetch_assoc();
                    $user_tasks_count = $result['count'] ?? 0;
                    $stmt->close();
                    
                    // Check completed tasks as well
                    $stmt = $conn->prepare("SELECT COUNT(*) as count FROM user_completed_tasks WHERE task_id = ?");
                    $stmt->bind_param("i", $task_id);
                    $stmt->execute();
                    $result = $stmt->get_result()->fetch_assoc();
                    $completed_count = $result['count'] ?? 0;
                    $stmt->close();
                    
                    $total_submissions = $user_tasks_count + $completed_count;
                    
                    // If task has submissions, don't allow deletion
                    if ($total_submissions > 0) {
                        $error_message = "Cannot delete this task. It has $total_submissions user submission(s). Please deactivate the task instead by using the pause button.";
                        error_log("Admin Post Task Delete - Task has $total_submissions submissions (ID: $task_id)");
                    } else {
                        // No submissions, safe to delete
                        $stmt = $conn->prepare("DELETE FROM tasks WHERE id = ? AND posted_by_admin = 1");
                        if (!$stmt) {
                            $error_message = 'Database error: ' . $conn->error;
                            error_log('Admin Post Task Delete - Prepare Error: ' . $conn->error);
                        } else {
                            $stmt->bind_param("i", $task_id);
                            if ($stmt->execute()) {
                                if ($conn->affected_rows > 0) {
                                    $success_message = 'Task deleted successfully!';
                                } else {
                                    $error_message = 'Task not found or you do not have permission to delete it.';
                                }
                            } else {
                                $error_message = 'Failed to delete task: ' . $stmt->error;
                                error_log('Admin Post Task Delete - Execute Error: ' . $stmt->error);
                            }
                            $stmt->close();
                        }
                    }
                }
            } else {
                $error_message = 'Invalid task ID.';
            }
        } elseif ($action === 'edit') {
            // Handle edit task action
            $task_id = intval($_POST['task_id'] ?? 0);
            $title = trim($_POST['title'] ?? '');
            $description = trim($_POST['description'] ?? '');
            $task_type = trim($_POST['task_type'] ?? '');
            $task_url = trim($_POST['task_url'] ?? '');
            $is_pinned = isset($_POST['is_pinned']) ? 1 : 0;
            $reward_type = $_POST['reward_type'] ?? 'fixed';
            
            // Validate inputs
            if ($task_id <= 0) {
                $error_message = 'Invalid task ID.';
            } else if (empty($title) || empty($description) || empty($task_type) || empty($task_url)) {
                $error_message = 'All fields are required.';
            } else if (strlen($title) > 255) {
                $error_message = 'Title must be less than 255 characters.';
            } else if (strlen($description) > 2000) {
                $error_message = 'Description must be less than 2000 characters.';
            } else if (filter_var($task_url, FILTER_VALIDATE_URL) === false) {
                $error_message = 'Invalid URL format.';
            } else {
                // Get reward amounts based on reward type
                if ($reward_type === 'fixed') {
                    $fixed_reward = floatval($_POST['fixed_reward'] ?? 0);
                    $member_reward = $fixed_reward;
                    $non_member_reward = $fixed_reward;
                } else {
                    $member_reward = floatval($_POST['member_reward'] ?? 0);
                    $non_member_reward = floatval($_POST['non_member_reward'] ?? 0);
                }
                
                if ($member_reward <= 0 || $non_member_reward <= 0) {
                    $error_message = 'Reward amounts must be greater than 0.';
                } else if ($member_reward > 100000 || $non_member_reward > 100000) {
                    $error_message = 'Reward amounts cannot exceed ₦100,000.';
                } else {
                    // Update task in database
                    $stmt = $conn->prepare("UPDATE tasks SET title = ?, description = ?, task_type = ?, platform = ?, task_url = ?, is_pinned = ?, member_reward = ?, non_member_reward = ? WHERE id = ? AND posted_by_admin = 1");
                    $stmt->bind_param("ssssssibi", $title, $description, $task_type, $task_type, $task_url, $is_pinned, $member_reward, $non_member_reward, $task_id);
                    
                    if ($stmt->execute()) {
                        $success_message = 'Task updated successfully!';
                    } else {
                        $error_message = 'Failed to update task. Please try again.';
                    }
                }
            }
        } elseif ($action === 'toggle_status') {
            // Handle activate/deactivate action
            $task_id = intval($_POST['task_id'] ?? 0);
            if ($task_id > 0) {
                // Get current status
                $stmt = $conn->prepare("SELECT is_active FROM tasks WHERE id = ? AND posted_by_admin = 1");
                $stmt->bind_param("i", $task_id);
                $stmt->execute();
                $result = $stmt->get_result()->fetch_assoc();
                
                if ($result) {
                    $new_status = $result['is_active'] ? 0 : 1;
                    $stmt = $conn->prepare("UPDATE tasks SET is_active = ? WHERE id = ? AND posted_by_admin = 1");
                    $stmt->bind_param("ii", $new_status, $task_id);
                    if ($stmt->execute()) {
                        $status_text = $new_status ? 'activated' : 'deactivated';
                        $success_message = 'Task ' . $status_text . ' successfully!';
                    } else {
                        $error_message = 'Failed to update task status. Please try again.';
                    }
                } else {
                    $error_message = 'Task not found.';
                }
            } else {
                $error_message = 'Invalid task ID.';
            }
        } else {
            // Handle create task action
            $title = trim($_POST['title'] ?? '');
            $description = trim($_POST['description'] ?? '');
            $task_type = trim($_POST['task_type'] ?? '');
            $task_url = trim($_POST['task_url'] ?? '');
            $is_pinned = isset($_POST['is_pinned']) ? 1 : 0;
            $reward_type = $_POST['reward_type'] ?? 'fixed';
            
            // Validate inputs
            if (empty($title) || empty($description) || empty($task_type) || empty($task_url)) {
                $error_message = 'All fields are required.';
            } else if (strlen($title) > 255) {
                $error_message = 'Title must be less than 255 characters.';
            } else if (strlen($description) > 2000) {
                $error_message = 'Description must be less than 2000 characters.';
            } else if (filter_var($task_url, FILTER_VALIDATE_URL) === false) {
                $error_message = 'Invalid URL format.';
            } else {
                // Get reward amounts based on reward type
                if ($reward_type === 'fixed') {
                    $fixed_reward = floatval($_POST['fixed_reward'] ?? 0);
                    $member_reward = $fixed_reward;
                    $non_member_reward = $fixed_reward;
                } else {
                    $member_reward = floatval($_POST['member_reward'] ?? 0);
                    $non_member_reward = floatval($_POST['non_member_reward'] ?? 0);
                }
                
                if ($member_reward <= 0 || $non_member_reward <= 0) {
                    $error_message = 'Reward amounts must be greater than 0.';
                } else if ($member_reward > 100000 || $non_member_reward > 100000) {
                    $error_message = 'Reward amounts cannot exceed ₦100,000.';
                } else {
                    // Insert task into database
                    $stmt = $conn->prepare("INSERT INTO tasks (title, description, task_type, platform, task_url, is_active, is_pinned, posted_by_admin, member_reward, non_member_reward, created_at) VALUES (?, ?, ?, ?, ?, 1, ?, 1, ?, ?, NOW())");
                    $stmt->bind_param("sssssidd", $title, $description, $task_type, $task_type, $task_url, $is_pinned, $member_reward, $non_member_reward);
                    
                    if ($stmt->execute()) {
                        $success_message = 'Task posted successfully!';
                        // Clear form
                        $_POST = [];
                    } else {
                        $error_message = 'Failed to post task. Please try again.';
                    }
                }
            }
        }
    }
}

// Generate CSRF token if not exists
if (!isset($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

// Handle JSON request for task data
if (isset($_GET['get_task_json'])) {
    $task_id = intval($_GET['get_task_json']);
    $stmt = $conn->prepare("SELECT id, title, description, task_type, task_url, member_reward, non_member_reward, is_pinned FROM tasks WHERE id = ? AND posted_by_admin = 1");
    $stmt->bind_param("i", $task_id);
    $stmt->execute();
    $result = $stmt->get_result()->fetch_assoc();
    
    header('Content-Type: application/json');
    if ($result) {
        echo json_encode(['success' => true, 'task' => $result]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Task not found']);
    }
    exit();
}

// Fetch all admin tasks
$recent_tasks = $conn->query("SELECT * FROM tasks WHERE posted_by_admin = 1 ORDER BY created_at DESC")->fetch_all(MYSQLI_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Post Admin Task - FlowEarner</title>
  <style>
    :root {
      --admin-primary: #6366f1;
      --admin-secondary: #8b5cf6;
      --admin-success: #10b981;
      --admin-warning: #f59e0b;
      --admin-danger: #ef4444;
      --admin-dark: #1e293b;
      --admin-light: #f1f5f9;
    }

    * { box-sizing: border-box; margin: 0; padding: 0; }

    body {
      font-family: "Inter", "Segoe UI", sans-serif;
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      min-height: 100vh;
    }

    .admin-main {
      padding: 32px;
      overflow-y: auto;
    }

    .admin-header {
      background: white;
      padding: 24px;
      border-radius: 16px;
      margin-bottom: 32px;
      box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    }

    .admin-header h1 {
      font-size: 2rem;
      color: var(--admin-dark);
      margin-bottom: 8px;
    }

    .form-container {
      background: white;
      padding: 32px;
      border-radius: 16px;
      box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
      margin-bottom: 32px;
    }

    .form-group {
      margin-bottom: 24px;
    }

    .form-group label {
      display: block;
      font-weight: 600;
      color: var(--admin-dark);
      margin-bottom: 8px;
    }

    .form-group input,
    .form-group textarea,
    .form-group select {
      width: 100%;
      padding: 12px 16px;
      border: 1px solid #e2e8f0;
      border-radius: 8px;
      font-size: 1rem;
      font-family: inherit;
      transition: border-color 0.3s;
    }

    .form-group input:focus,
    .form-group textarea:focus,
    .form-group select:focus {
      outline: none;
      border-color: var(--admin-primary);
    }

    .form-group textarea {
      min-height: 120px;
      resize: vertical;
    }

    .checkbox-group {
      display: flex;
      align-items: center;
      gap: 12px;
    }

    .checkbox-group input[type="checkbox"] {
      width: auto;
      cursor: pointer;
    }

    .reward-options {
      display: grid;
      grid-template-columns: repeat(2, 1fr);
      gap: 16px;
      margin-top: 16px;
    }

    .reward-option {
      padding: 16px;
      border: 2px solid #e2e8f0;
      border-radius: 8px;
      cursor: pointer;
      transition: all 0.3s;
    }

    .reward-option:hover {
      border-color: var(--admin-primary);
    }

    .reward-option.active {
      border-color: var(--admin-primary);
      background: rgba(99, 102, 241, 0.05);
    }

    .reward-option input[type="radio"] {
      margin-right: 8px;
    }

    .reward-inputs {
      display: none;
      margin-top: 16px;
    }

    .reward-inputs.active {
      display: block;
    }

    .btn-primary {
      background: var(--admin-primary);
      color: white;
      padding: 14px 32px;
      border: none;
      border-radius: 8px;
      font-size: 1rem;
      font-weight: 600;
      cursor: pointer;
      transition: all 0.3s;
    }

    .btn-primary:hover {
      background: var(--admin-secondary);
      transform: translateY(-2px);
    }

    .alert {
      padding: 16px;
      border-radius: 8px;
      margin-bottom: 24px;
    }

    .alert-success {
      background: rgba(16, 185, 129, 0.1);
      border: 1px solid var(--admin-success);
      color: var(--admin-success);
    }

    .alert-error {
      background: rgba(239, 68, 68, 0.1);
      border: 1px solid var(--admin-danger);
      color: var(--admin-danger);
    }

    .tasks-table {
      background: white;
      padding: 24px;
      border-radius: 16px;
      box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    }

    .tasks-table h2 {
      font-size: 1.5rem;
      color: var(--admin-dark);
      margin-bottom: 16px;
    }

    table {
      width: 100%;
      border-collapse: collapse;
    }

    th, td {
      padding: 12px;
      text-align: left;
      border-bottom: 1px solid #e2e8f0;
    }

    th {
      font-weight: 600;
      color: var(--admin-dark);
      background: var(--admin-light);
    }

    .badge {
      display: inline-block;
      padding: 4px 12px;
      border-radius: 12px;
      font-size: 0.875rem;
      font-weight: 600;
    }

    .badge-pinned {
      background: rgba(239, 68, 68, 0.1);
      color: var(--admin-danger);
    }

    .badge-normal {
      background: rgba(100, 116, 139, 0.1);
      color: #64748b;
    }

    .badge-active {
      background: rgba(16, 185, 129, 0.1);
      color: var(--admin-success);
    }

    .badge-inactive {
      background: rgba(107, 114, 128, 0.1);
      color: #6b7280;
    }

    .action-buttons {
      display: flex;
      gap: 8px;
      flex-wrap: wrap;
    }

    .btn-small {
      padding: 6px 12px;
      border: none;
      border-radius: 6px;
      font-size: 0.75rem;
      font-weight: 600;
      cursor: pointer;
      transition: all 0.3s;
      display: inline-flex;
      align-items: center;
      gap: 4px;
    }

    .btn-edit {
      background: var(--admin-primary);
      color: white;
    }

    .btn-edit:hover {
      background: var(--admin-secondary);
      transform: translateY(-1px);
    }

    .btn-toggle {
      background: var(--admin-warning);
      color: white;
    }

    .btn-toggle:hover {
      background: #d97706;
      transform: translateY(-1px);
    }

    .btn-delete {
      background: var(--admin-danger);
      color: white;
    }

    .btn-delete:hover {
      background: #dc2626;
      transform: translateY(-1px);
    }

    .modal {
      display: none;
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: rgba(0, 0, 0, 0.5);
      z-index: 1000;
      align-items: center;
      justify-content: center;
    }

    .modal.active {
      display: flex;
    }

    .modal-content {
      background: white;
      padding: 32px;
      border-radius: 16px;
      max-width: 500px;
      width: 90%;
      box-shadow: 0 20px 25px rgba(0, 0, 0, 0.2);
    }

    .modal-header {
      font-size: 1.5rem;
      font-weight: 700;
      color: var(--admin-dark);
      margin-bottom: 16px;
    }

    .modal-body {
      margin-bottom: 24px;
      color: #64748b;
    }

    .modal-footer {
      display: flex;
      gap: 12px;
      justify-content: flex-end;
    }

    .btn-cancel {
      padding: 10px 20px;
      background: #e2e8f0;
      color: var(--admin-dark);
      border: none;
      border-radius: 8px;
      cursor: pointer;
      font-weight: 600;
      transition: all 0.3s;
    }

    .btn-cancel:hover {
      background: #cbd5e1;
    }

    .btn-confirm {
      padding: 10px 20px;
      background: var(--admin-danger);
      color: white;
      border: none;
      border-radius: 8px;
      cursor: pointer;
      font-weight: 600;
      transition: all 0.3s;
    }

    .btn-confirm:hover {
      background: #dc2626;
    }

    @media (max-width: 960px) {
      .admin-container {
        grid-template-columns: 1fr;
      }

      .reward-options {
        grid-template-columns: 1fr;
      }
    }

    @media (max-width: 768px) {
      .admin-main {
        padding: 16px;
      }

      .admin-header {
        padding: 16px;
        margin-bottom: 16px;
      }

      .admin-header h1 {
        font-size: 1.5rem;
        margin-bottom: 4px;
      }

      .admin-header p {
        font-size: 0.9rem;
      }

      .form-container {
        padding: 16px;
        margin-bottom: 16px;
      }

      .form-group {
        margin-bottom: 16px;
      }

      .form-group label {
        font-size: 0.9rem;
        margin-bottom: 6px;
      }

      .form-group input,
      .form-group textarea,
      .form-group select {
        padding: 10px 12px;
        font-size: 16px;
      }

      .form-group textarea {
        min-height: 100px;
      }

      .reward-options {
        grid-template-columns: 1fr;
        gap: 12px;
      }

      .reward-option {
        padding: 12px;
      }

      .btn-primary {
        padding: 12px 24px;
        font-size: 0.95rem;
      }

      .alert {
        padding: 12px;
        font-size: 0.9rem;
      }

      .tasks-table {
        padding: 16px;
        overflow-x: auto;
        -webkit-overflow-scrolling: touch;
      }

      .tasks-table h2 {
        font-size: 1.2rem;
        margin-bottom: 12px;
      }

      table {
        min-width: 650px;
        display: inline-block;
      }

      th, td {
        padding: 10px 8px;
        font-size: 0.8rem;
      }

      .badge {
        padding: 3px 8px;
        font-size: 0.75rem;
      }
    }
  </style>
</head>
<body>
   <?php include 'side-bar.php'; ?>
<div class="admin-content">

    <main class="admin-main">
      <div class="admin-header">
        <h1>Post Admin Task</h1>
        <p style="color: #64748b;">Create tasks for users to complete. Pinned tasks appear as compulsory for all users.</p>
      </div>

      <?php if ($success_message): ?>
        <div class="alert alert-success"><?php echo $success_message; ?></div>
      <?php endif; ?>

      <?php if ($error_message): ?>
        <div class="alert alert-error"><?php echo $error_message; ?></div>
      <?php endif; ?>

      <div class="form-container">
        <form method="POST" action="">
          <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
          <input type="hidden" name="action" value="create">
          <div class="form-group">
            <label for="title">Task Title *</label>
            <input type="text" id="title" name="title" required placeholder="e.g., Follow us on Instagram" maxlength="255">
          </div>

          <div class="form-group">
            <label for="description">Task Description *</label>
            <textarea id="description" name="description" required placeholder="Describe what users need to do..."></textarea>
          </div>

          <div class="form-group">
            <label for="task_type">Task Type *</label>
            <select id="task_type" name="task_type" required>
              <option value="">Select task type</option>
              <option value="tiktok">TikTok</option>
              <option value="instagram">Instagram</option>
              <option value="facebook">Facebook</option>
              <option value="twitter">Twitter</option>
              <option value="youtube">YouTube</option>
              <option value="whatsapp">WhatsApp</option>
              <option value="telegram">Telegram</option>
              <option value="linkedin">LinkedIn</option>
              <option value="snapchat">Snapchat</option>
              <option value="pinterest">Pinterest</option>
              <option value="reddit">Reddit</option>
              <option value="discord">Discord</option>
              <option value="twitch">Twitch</option>
              <option value="playstore">Play Store</option>
              <option value="appstore">App Store</option>
              <option value="audiomack">Audiomack</option>
              <option value="boomplay">Boomplay</option>
              <option value="spotify">Spotify</option>
              <option value="applemusic">Apple Music</option>
              <option value="soundcloud">SoundCloud</option>
            </select>
          </div>

          <div class="form-group">
            <label for="task_url">Task URL *</label>
            <input type="url" id="task_url" name="task_url" required placeholder="https://...">
          </div>

          <div class="form-group">
            <div class="checkbox-group">
              <input type="checkbox" id="is_pinned" name="is_pinned">
              <label for="is_pinned" style="margin: 0;">Mark as Pinned/Compulsory Task</label>
            </div>
            <small style="color: #64748b; display: block; margin-top: 8px;">
              Pinned tasks appear at the top for all users and disappear after completion.
            </small>
          </div>

          <div class="form-group">
            <label>Reward Structure *</label>
            <div class="reward-options">
              <div class="reward-option active" onclick="selectRewardType('fixed')">
                <input type="radio" name="reward_type" value="fixed" checked>
                <strong>Fixed Reward</strong>
                <p style="font-size: 0.875rem; color: #64748b; margin-top: 4px;">Same amount for all users</p>
              </div>
              <div class="reward-option" onclick="selectRewardType('tiered')">
                <input type="radio" name="reward_type" value="tiered">
                <strong>Tiered Reward</strong>
                <p style="font-size: 0.875rem; color: #64748b; margin-top: 4px;">Different amounts for members vs non-members</p>
              </div>
            </div>

            <div class="reward-inputs active" id="fixedRewardInputs">
              <div class="form-group">
                <label for="fixed_reward">Reward Amount (₦) *</label>
                <input type="number" id="fixed_reward" name="fixed_reward" step="0.01" min="0" placeholder="50.00">
              </div>
            </div>

            <div class="reward-inputs" id="tieredRewardInputs">
              <div class="form-group">
                <label for="member_reward">Member Reward (₦) *</label>
                <input type="number" id="member_reward" name="member_reward" step="0.01" min="0" placeholder="100.00">
              </div>
              <div class="form-group">
                <label for="non_member_reward">Non-Member Reward (₦) *</label>
                <input type="number" id="non_member_reward" name="non_member_reward" step="0.01" min="0" placeholder="50.00">
              </div>
            </div>
          </div>

          <button type="submit" class="btn-primary">Post Task</button>
        </form>
      </div>

      <div class="tasks-table">
        <h2>Recent Admin Tasks</h2>
        <?php if (empty($recent_tasks)): ?>
          <p style="color: #64748b; text-align: center; padding: 32px;">No tasks posted yet.</p>
        <?php else: ?>
          <table>
            <thead>
              <tr>
                <th>Title</th>
                <th>Type</th>
                <th>Platform</th>
                <th>Status</th>
                <th>Member Reward</th>
                <th>Non-Member Reward</th>
                <th>Created</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              <?php foreach ($recent_tasks as $task): ?>
                <tr>
                  <td><?php echo htmlspecialchars($task['title']); ?></td>
                  <td><?php echo ucfirst($task['task_type']); ?></td>
                  <td><?php echo ucfirst($task['platform']); ?></td>
                  <td>
                    <?php if ($task['is_pinned']): ?>
                      <span class="badge badge-pinned">Pinned</span>
                    <?php else: ?>
                      <span class="badge badge-normal">Normal</span>
                    <?php endif; ?>
                  </td>
                  <td>₦<?php echo number_format($task['member_reward'], 2); ?></td>
                  <td>₦<?php echo number_format($task['non_member_reward'], 2); ?></td>
                  <td><?php echo date('M d, Y', strtotime($task['created_at'])); ?></td>
                  <td>
                    <div class="action-buttons">
                      <button type="button" class="btn-small btn-edit" onclick="editTask(<?php echo $task['id']; ?>)">Edit</button>
                      <button type="button" class="btn-small btn-toggle" onclick="toggleStatus(<?php echo $task['id']; ?>, <?php echo $task['is_active'] ? 'true' : 'false'; ?>)">
                        <?php echo $task['is_active'] ? 'Pause' : 'Activate'; ?>
                      </button>
                      <button type="button" class="btn-small btn-delete" onclick="showDeleteModal(<?php echo $task['id']; ?>, '<?php echo htmlspecialchars($task['title'], ENT_QUOTES); ?>')">Delete</button>
                    </div>
                  </td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        <?php endif; ?>
      </div>
    </main>
  </div>

  <!-- Edit Task Modal -->
  <div id="editModal" class="modal">
    <div class="modal-content" style="max-width: 600px;">
      <div class="modal-header">Edit Task</div>
      <form method="POST" action="" style="padding: 0;">
        <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
        <input type="hidden" name="action" value="edit">
        <input type="hidden" name="task_id" id="editTaskId">
        
        <div style="padding: 24px; max-height: 70vh; overflow-y: auto;">
          <div class="form-group" style="margin-bottom: 16px;">
            <label for="editTitle" style="display: block; font-weight: 600; color: #1e293b; margin-bottom: 6px;">Task Title *</label>
            <input type="text" id="editTitle" name="title" required maxlength="255" style="width: 100%; padding: 10px; border: 1px solid #e2e8f0; border-radius: 6px; font-size: 0.95rem;">
          </div>

          <div class="form-group" style="margin-bottom: 16px;">
            <label for="editDescription" style="display: block; font-weight: 600; color: #1e293b; margin-bottom: 6px;">Task Description *</label>
            <textarea id="editDescription" name="description" required style="width: 100%; padding: 10px; border: 1px solid #e2e8f0; border-radius: 6px; font-size: 0.95rem; min-height: 100px; resize: vertical;"></textarea>
          </div>

          <div class="form-group" style="margin-bottom: 16px;">
            <label for="editTaskType" style="display: block; font-weight: 600; color: #1e293b; margin-bottom: 6px;">Task Type *</label>
            <select id="editTaskType" name="task_type" required style="width: 100%; padding: 10px; border: 1px solid #e2e8f0; border-radius: 6px; font-size: 0.95rem;">
              <option value="">Select task type</option>
              <option value="tiktok">TikTok</option>
              <option value="instagram">Instagram</option>
              <option value="facebook">Facebook</option>
              <option value="twitter">Twitter</option>
              <option value="youtube">YouTube</option>
              <option value="whatsapp">WhatsApp</option>
              <option value="telegram">Telegram</option>
              <option value="linkedin">LinkedIn</option>
              <option value="snapchat">Snapchat</option>
              <option value="pinterest">Pinterest</option>
              <option value="reddit">Reddit</option>
              <option value="discord">Discord</option>
              <option value="twitch">Twitch</option>
              <option value="playstore">Play Store</option>
              <option value="appstore">App Store</option>
            </select>
          </div>

          <div class="form-group" style="margin-bottom: 16px;">
            <label for="editTaskUrl" style="display: block; font-weight: 600; color: #1e293b; margin-bottom: 6px;">Task URL *</label>
            <input type="url" id="editTaskUrl" name="task_url" required style="width: 100%; padding: 10px; border: 1px solid #e2e8f0; border-radius: 6px; font-size: 0.95rem;">
          </div>

          <div class="form-group" style="margin-bottom: 16px;">
            <label for="editMemberReward" style="display: block; font-weight: 600; color: #1e293b; margin-bottom: 6px;">Member Reward (₦) *</label>
            <input type="number" id="editMemberReward" name="member_reward" required step="0.01" min="0" style="width: 100%; padding: 10px; border: 1px solid #e2e8f0; border-radius: 6px; font-size: 0.95rem;">
          </div>

          <div class="form-group" style="margin-bottom: 16px;">
            <label for="editNonMemberReward" style="display: block; font-weight: 600; color: #1e293b; margin-bottom: 6px;">Non-Member Reward (₦) *</label>
            <input type="number" id="editNonMemberReward" name="non_member_reward" required step="0.01" min="0" style="width: 100%; padding: 10px; border: 1px solid #e2e8f0; border-radius: 6px; font-size: 0.95rem;">
          </div>

          <div class="form-group" style="margin-bottom: 0;">
            <label style="display: flex; align-items: center; gap: 10px; cursor: pointer; font-weight: 600; color: #1e293b;">
              <input type="checkbox" id="editIsPinned" name="is_pinned" style="width: 18px; height: 18px; cursor: pointer;">
              Mark as Pinned/Compulsory Task
            </label>
            <small style="color: #64748b; display: block; margin-top: 6px;">Pinned tasks appear at the top for all users and disappear after completion.</small>
          </div>
        </div>

        <div class="modal-footer" style="padding: 16px 24px; border-top: 1px solid #e2e8f0; background: #f8fafc;">
          <button type="button" class="btn-cancel" onclick="closeEditModal()">Cancel</button>
          <button type="submit" class="btn-confirm" style="background: #6366f1;">Save Changes</button>
        </div>
      </form>
    </div>
  </div>

  <!-- Delete Confirmation Modal -->
  <div id="deleteModal" class="modal">
    <div class="modal-content">
      <div class="modal-header">Delete Task</div>
      <div class="modal-body">
        <p>Are you sure you want to delete "<span id="taskTitle"></span>"?</p>
        <p style="margin-top: 12px; font-size: 0.875rem; color: #ef4444;">This action cannot be undone.</p>
      </div>
      <div class="modal-footer">
        <button class="btn-cancel" onclick="closeDeleteModal()">Cancel</button>
        <form method="POST" style="display: inline;">
          <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
          <input type="hidden" name="action" value="delete">
          <input type="hidden" name="task_id" id="deleteTaskId">
          <button type="submit" class="btn-confirm">Delete Task</button>
        </form>
      </div>
    </div>
  </div>

  <script>
    function selectRewardType(type) {
      // Update radio buttons
      document.querySelectorAll('input[name="reward_type"]').forEach(radio => {
        radio.checked = radio.value === type;
      });

      // Update option styling
      document.querySelectorAll('.reward-option').forEach(option => {
        option.classList.remove('active');
      });
      event.currentTarget.classList.add('active');

      // Show/hide reward inputs
      document.getElementById('fixedRewardInputs').classList.toggle('active', type === 'fixed');
      document.getElementById('tieredRewardInputs').classList.toggle('active', type === 'tiered');
    }

    function editTask(taskId) {
      // Fetch task data and open edit modal
      fetch('?get_task_json=' + taskId)
        .then(response => response.json())
        .then(data => {
          if (data.success) {
            const task = data.task;
            
            // Populate edit form with all fields
            document.getElementById('editTaskId').value = task.id;
            document.getElementById('editTitle').value = task.title;
            document.getElementById('editDescription').value = task.description;
            document.getElementById('editTaskType').value = task.task_type.toLowerCase();
            document.getElementById('editTaskUrl').value = task.task_url;
            document.getElementById('editMemberReward').value = task.member_reward;
            document.getElementById('editNonMemberReward').value = task.non_member_reward;
            document.getElementById('editIsPinned').checked = task.is_pinned == 1;
            
            // Show edit modal
            document.getElementById('editModal').classList.add('active');
          } else {
            alert('Failed to load task data');
          }
        })
        .catch(error => {
          console.error('Error:', error);
          alert('Failed to load task data');
        });
    }

    function closeEditModal() {
      document.getElementById('editModal').classList.remove('active');
    }

    function showDeleteModal(taskId, taskTitle) {
      document.getElementById('deleteModal').classList.add('active');
      document.getElementById('deleteTaskId').value = taskId;
      document.getElementById('taskTitle').textContent = taskTitle;
    }

    function closeDeleteModal() {
      document.getElementById('deleteModal').classList.remove('active');
    }

    function toggleStatus(taskId, isActive) {
      if (confirm('Are you sure you want to ' + (isActive ? 'pause' : 'activate') + ' this task?')) {
        const form = document.createElement('form');
        form.method = 'POST';
        form.innerHTML = `
          <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
          <input type="hidden" name="action" value="toggle_status">
          <input type="hidden" name="task_id" value="${taskId}">
        `;
        document.body.appendChild(form);
        form.submit();
      }
    }

    // Close modals when clicking outside
    document.getElementById('editModal')?.addEventListener('click', function(e) {
      if (e.target === this) {
        closeEditModal();
      }
    });

    document.getElementById('deleteModal')?.addEventListener('click', function(e) {
      if (e.target === this) {
        closeDeleteModal();
      }
    });
  </script>
</body>
</html>
