<?php
session_start();
require_once '../config/database.php';


if (!isset($_SESSION['user_id'])) {
    header('Location: ../login.php');
    exit();
}

$user_id = $_SESSION['user_id'];
$stmt = $conn->prepare("SELECT is_admin FROM users WHERE id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result()->fetch_assoc();

if (!$result || $result['is_admin'] != 1) {
    header('Location: ../dashboard.php');
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $job_id = intval($_POST['job_id']);
    $action = $_POST['action'];
    
    if ($action === 'close') {
        $stmt = $conn->prepare("UPDATE jobs SET status = 'closed' WHERE id = ?");
        $stmt->bind_param("i", $job_id);
        $stmt->execute();
        $success_message = "Job closed successfully";
    } elseif ($action === 'reopen') {
        $stmt = $conn->prepare("UPDATE jobs SET status = 'active' WHERE id = ?");
        $stmt->bind_param("i", $job_id);
        $stmt->execute();
        $success_message = "Job reopened successfully";
    } elseif ($action === 'delete') {
        $stmt = $conn->prepare("DELETE FROM jobs WHERE id = ?");
        $stmt->bind_param("i", $job_id);
        $stmt->execute();
        $success_message = "Job deleted successfully";
    }
}

$jobs = $conn->query("
    SELECT j.*, 
           (SELECT COUNT(*) FROM job_bids WHERE job_id = j.id) as total_bids,
           (SELECT COUNT(*) FROM job_bids WHERE job_id = j.id AND status = 'approved') as approved_bids
    FROM jobs j 
    ORDER BY j.created_at DESC
")->fetch_all(MYSQLI_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Manage Jobs - FlowEarner Admin</title>
  <style>
    :root {
      --admin-primary: #6366f1;
      --admin-secondary: #8b5cf6;
      --admin-success: #10b981;
      --admin-warning: #f59e0b;
      --admin-danger: #ef4444;
      --admin-dark: #1e293b;
      --admin-light: #f1f5f9;
    }

    * { box-sizing: border-box; margin: 0; padding: 0; }

    body {
      font-family: "Inter", "Segoe UI", sans-serif;
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      min-height: 100vh;
    }

    .admin-container {
      display: grid;
      grid-template-columns: 260px 1fr;
      min-height: 100vh;
    }


    .admin-main {
      
      padding: 32px;
      overflow-y: auto;
    }

    .admin-header {
      background: white;
      padding: 24px;
      border-radius: 16px;
      margin-bottom: 32px;
      box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    }

    .admin-header h1 {
      font-size: 2rem;
      color: var(--admin-dark);
      margin-bottom: 8px;
    }

    .jobs-grid {
      display: grid;
      gap: 24px;
    }

    .job-card {
      background: white;
      border-radius: 16px;
      padding: 24px;
      box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    }

    .job-header {
      display: flex;
      justify-content: space-between;
      align-items: start;
      margin-bottom: 16px;
    }

    .job-title {
      font-size: 1.25rem;
      font-weight: 700;
      color: var(--admin-dark);
      margin-bottom: 8px;
    }

    .job-meta {
      display: flex;
      gap: 16px;
      flex-wrap: wrap;
      margin-bottom: 16px;
      font-size: 0.9rem;
      color: #64748b;
    }

    .job-meta span {
      display: flex;
      align-items: center;
      gap: 4px;
    }

    .job-description {
      color: #64748b;
      line-height: 1.6;
      margin-bottom: 16px;
    }

    .job-stats {
      display: flex;
      gap: 24px;
      padding: 16px;
      background: var(--admin-light);
      border-radius: 8px;
      margin-bottom: 16px;
    }

    .stat-item {
      display: flex;
      flex-direction: column;
      gap: 4px;
    }

    .stat-label {
      font-size: 0.75rem;
      text-transform: uppercase;
      color: #64748b;
      font-weight: 600;
    }

    .stat-value {
      font-size: 1.25rem;
      font-weight: 700;
      color: var(--admin-dark);
    }

    .badge {
      display: inline-block;
      padding: 4px 12px;
      border-radius: 12px;
      font-size: 0.75rem;
      font-weight: 600;
      text-transform: uppercase;
    }

    .badge-active {
      background: #d1fae5;
      color: #065f46;
    }

    .badge-closed {
      background: #fee2e2;
      color: #991b1b;
    }

    .action-buttons {
      display: flex;
      gap: 8px;
      flex-wrap: wrap;
    }

    .action-btn {
      padding: 8px 16px;
      border: none;
      border-radius: 6px;
      cursor: pointer;
      font-size: 0.85rem;
      font-weight: 600;
      transition: all 0.3s;
    }

    .btn-close {
      background: #fee2e2;
      color: #991b1b;
    }

    .btn-reopen {
      background: #d1fae5;
      color: #065f46;
    }

    .btn-delete {
      background: #fecaca;
      color: #7f1d1d;
    }

    .btn-view {
      background: #dbeafe;
      color: #1e40af;
    }

    .action-btn:hover {
      transform: translateY(-2px);
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.15);
    }

    .alert {
      padding: 16px;
      border-radius: 12px;
      margin-bottom: 24px;
      font-weight: 600;
    }

    .alert-success {
      background: #d1fae5;
      color: #065f46;
    }

    @media (max-width: 960px) {
      .admin-container {
        grid-template-columns: 1fr;
      }

      

      .admin-main {
        margin-left: 0;
      }
    }
  </style>
</head>
<body>
    <?php include 'side-bar.php'; ?>
<div class="admin-content">

    <main class="admin-main">
      <div class="admin-header">
        <h1>Manage Jobs</h1>
        <p style="color: #64748b;">View, edit, and manage all job postings</p>
      </div>

      <?php if (isset($success_message)): ?>
        <div class="alert alert-success"><?php echo $success_message; ?></div>
      <?php endif; ?>

      <div class="jobs-grid">
        <?php if (empty($jobs)): ?>
          <div class="job-card">
            <p style="text-align: center; color: #64748b;">No jobs posted yet</p>
          </div>
        <?php else: ?>
          <?php foreach ($jobs as $job): ?>
            <div class="job-card">
              <div class="job-header">
                <div>
                  <h3 class="job-title"><?php echo htmlspecialchars($job['title']); ?></h3>
                  <span class="badge badge-<?php echo $job['status']; ?>">
                    <?php echo strtoupper($job['status']); ?>
                  </span>
                </div>
              </div>

              <div class="job-meta">
                <span>📂 <?php echo htmlspecialchars($job['category']); ?></span>
                <span>💰 ₦<?php echo number_format($job['budget'], 2); ?></span>
                <span>📍 <?php echo htmlspecialchars($job['location']); ?></span>
                <span>👥 <?php echo $job['slots']; ?> slots</span>
                <span>📅 Deadline: <?php echo date('M d, Y', strtotime($job['deadline'])); ?></span>
              </div>

              <p class="job-description"><?php echo nl2br(htmlspecialchars(substr($job['description'], 0, 200))); ?>...</p>

              <div class="job-stats">
                <div class="stat-item">
                  <span class="stat-label">Total Bids</span>
                  <span class="stat-value"><?php echo $job['total_bids']; ?></span>
                </div>
                <div class="stat-item">
                  <span class="stat-label">Approved</span>
                  <span class="stat-value"><?php echo $job['approved_bids']; ?></span>
                </div>
                <div class="stat-item">
                  <span class="stat-label">Posted</span>
                  <span class="stat-value"><?php echo date('M d', strtotime($job['created_at'])); ?></span>
                </div>
              </div>

              <div class="action-buttons">
                <a href="job-bids.php?job_id=<?php echo $job['id']; ?>" class="action-btn btn-view">View Bids</a>
                <form method="POST" style="display: inline;">
                  <input type="hidden" name="job_id" value="<?php echo $job['id']; ?>" />
                  <?php if ($job['status'] === 'active'): ?>
                    <button type="submit" name="action" value="close" class="action-btn btn-close">Close Job</button>
                  <?php else: ?>
                    <button type="submit" name="action" value="reopen" class="action-btn btn-reopen">Reopen Job</button>
                  <?php endif; ?>
                  <button type="submit" name="action" value="delete" class="action-btn btn-delete" onclick="return confirm('Are you sure you want to delete this job?')">Delete</button>
                </form>
              </div>
            </div>
          <?php endforeach; ?>
        <?php endif; ?>
      </div>
    </main>
  </div>
</body>
</html>
