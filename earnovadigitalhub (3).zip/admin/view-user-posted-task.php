<?php
session_start();
require_once '../config/database.php';

// Check if user is logged in and is admin
if (!isset($_SESSION['user_id'])) {
    header('Location: ../login.php');
    exit();
}

$user_id = $_SESSION['user_id'];
$stmt = $conn->prepare("SELECT is_admin FROM users WHERE id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();

if (!$user || $user['is_admin'] != 1) {
    header('Location: ../dashboard.php');
    exit();
}

// Generate CSRF token if not exists
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

$success_message = '';
$error_message = '';

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        $error_message = 'Security token validation failed.';
    } else {
        $action = $_POST['action'] ?? '';
        $task_id = intval($_POST['task_id'] ?? 0);

        if ($action === 'disable') {
            $stmt = $conn->prepare("UPDATE tasks SET is_active = 0, is_permanently_disabled = 1 WHERE id = ? AND posted_by_admin = 0");
            $stmt->bind_param("i", $task_id);
            if ($stmt->execute()) {
                $success_message = 'Task disabled successfully!';
            } else {
                $error_message = 'Failed to disable task.';
            }
            $stmt->close();
        } elseif ($action === 'activate') {
            $stmt = $conn->prepare("UPDATE tasks SET is_active = 1, is_permanently_disabled = 0 WHERE id = ? AND posted_by_admin = 0");
            $stmt->bind_param("i", $task_id);
            if ($stmt->execute()) {
                $success_message = 'Task activated successfully!';
            } else {
                $error_message = 'Failed to activate task.';
            }
            $stmt->close();
        } elseif ($action === 'edit_task') {
            $title = trim($_POST['title'] ?? '');
            $description = trim($_POST['description'] ?? '');
            $task_type = trim($_POST['task_type'] ?? '');
            $platform = trim($_POST['platform'] ?? '');
            $reward_amount = floatval($_POST['reward_amount'] ?? 0);
            $participants_count = intval($_POST['participants_count'] ?? 10);
            $task_url = trim($_POST['task_url'] ?? '');
            $is_premium_only = isset($_POST['is_premium_only']) ? 1 : 0;
            $member_reward = floatval($_POST['member_reward'] ?? 0);
            $non_member_reward = floatval($_POST['non_member_reward'] ?? 0);

            if (empty($title)) {
                $error_message = 'Title is required.';
            } elseif (empty($description)) {
                $error_message = 'Description is required.';
            } elseif ($reward_amount < 0) {
                $error_message = 'Reward amount must be 0 or greater.';
            } elseif ($participants_count < 1) {
                $error_message = 'Participants count must be at least 1.';
            } else {
                $stmt = $conn->prepare("UPDATE tasks SET title = ?, description = ?, task_type = ?, platform = ?, reward_amount = ?, participants_count = ?, task_url = ?, is_premium_only = ?, member_reward = ?, non_member_reward = ?, updated_at = NOW() WHERE id = ? AND posted_by_admin = 0");
                $stmt->bind_param("ssssddsdddsi", $title, $description, $task_type, $platform, $reward_amount, $participants_count, $task_url, $is_premium_only, $member_reward, $non_member_reward, $task_id);
                if ($stmt->execute()) {
                    $success_message = 'Task updated successfully!';
                } else {
                    $error_message = 'Failed to update task: ' . $stmt->error;
                }
                $stmt->close();
            }
        }
    }
}

// Get search parameter
$search = isset($_GET['search']) ? trim($_GET['search']) : '';

// Build search query for users who posted tasks
$where_clause = "WHERE posted_by_admin = 0";
$params = [];
$types = "";

if (!empty($search)) {
    $where_clause .= " AND (posted_by_username LIKE ? OR posted_by_fullname LIKE ?)";
    $search_param = '%' . $search . '%';
    $params = [$search_param, $search_param];
    $types = "ss";
}

// Get overall stats
$stats_query = "SELECT 
    COUNT(DISTINCT posted_by_username) as total_posters,
    COUNT(*) as total_tasks,
    SUM(CASE WHEN is_active = 1 THEN 1 ELSE 0 END) as active_tasks,
    SUM(completed_count) as total_completions
    FROM tasks WHERE posted_by_admin = 0";
$stats_result = $conn->query($stats_query);
$stats = $stats_result ? $stats_result->fetch_assoc() : ['total_posters' => 0, 'total_tasks' => 0, 'active_tasks' => 0, 'total_completions' => 0];

// Total money users spent posting tasks (transactions of type 'ad_purchase')
$spent_query = 'SELECT 
    COALESCE((SELECT SUM(amount) FROM transactions WHERE transaction_type = \'ad_purchase\' AND (reference_id IS NULL OR reference_id NOT IN (SELECT reference FROM korapay_post_task_payments WHERE status = \'success\'))), 0) 
    + COALESCE((SELECT SUM(amount) FROM korapay_post_task_payments WHERE status = \'success\' AND JSON_UNQUOTE(JSON_EXTRACT(metadata, \'$.payment_type\')) = \'post_task_deposit\'), 0) 
    AS total_spent';
$spent_result = $conn->query($spent_query);
$total_spent = $spent_result ? $spent_result->fetch_assoc()['total_spent'] : 0;

// Get users who posted tasks with their stats
 $query = 'SELECT 
    user_id,
    ANY_VALUE(posted_by_username) AS posted_by_username,
    ANY_VALUE(posted_by_fullname) AS posted_by_fullname,
    COUNT(*) as total_posted,
    SUM(CASE WHEN is_active = 1 THEN 1 ELSE 0 END) as active_count,
    SUM(CASE WHEN is_active = 0 THEN 1 ELSE 0 END) as inactive_count,
    SUM(completed_count) as total_completions,
    (
        (SELECT COALESCE(SUM(amount),0) FROM transactions WHERE transaction_type = \'ad_purchase\' AND user_id = tasks.user_id AND (reference_id IS NULL OR reference_id NOT IN (SELECT reference FROM korapay_post_task_payments WHERE status = \'success\')))
        + (SELECT COALESCE(SUM(amount),0) FROM korapay_post_task_payments kpp WHERE kpp.status = \'success\' AND kpp.user_id = tasks.user_id AND JSON_UNQUOTE(JSON_EXTRACT(kpp.metadata, \'$.payment_type\')) = \'post_task_deposit\')
    ) as total_spent_by_user,
    MAX(created_at) as last_posted,
    SUM(reward_amount) as total_rewards
    FROM tasks
    ' . $where_clause . '
    GROUP BY user_id
    ORDER BY total_posted DESC, last_posted DESC
    LIMIT 200';

if (!empty($params)) {
    $stmt = $conn->prepare($query);
    if ($stmt) {
        $stmt->bind_param($types, ...$params);
        $stmt->execute();
        $result = $stmt->get_result();
        $posters = $result ? $result->fetch_all(MYSQLI_ASSOC) : [];
        $stmt->close();
    } else {
        $posters = [];
    }
} else {
    $result = $conn->query($query);
    $posters = $result ? $result->fetch_all(MYSQLI_ASSOC) : [];
}

$all_tasks_query = 'SELECT *,
    (
        (SELECT COALESCE(SUM(amount), 0) FROM transactions WHERE transaction_type = \'ad_purchase\' AND reference_id = CONCAT(\'TASK-\', tasks.id))
        + (SELECT COALESCE(SUM(kpp.amount), 0) FROM korapay_post_task_payments kpp WHERE kpp.status = \'success\' AND kpp.user_id = tasks.user_id AND (
            (JSON_UNQUOTE(JSON_EXTRACT(kpp.metadata, \'$.task_url\')) = tasks.task_url OR JSON_UNQUOTE(JSON_EXTRACT(kpp.metadata, \'$.title\')) = tasks.title)
            AND ABS(TIMESTAMPDIFF(MINUTE, kpp.created_at, tasks.created_at)) <= 10
        ))
    ) AS task_spent
    FROM tasks WHERE posted_by_admin = 0 ORDER BY created_at DESC LIMIT 500';
$all_tasks_result = $conn->query($all_tasks_query);
$all_tasks = $all_tasks_result ? $all_tasks_result->fetch_all(MYSQLI_ASSOC) : [];
// Deduplicate tasks by `id` to prevent duplicate rows in the UI if query returns duplicates
if (!empty($all_tasks)) {
    $unique_tasks = [];
    foreach ($all_tasks as $t) {
        if (isset($t['id'])) {
            $unique_tasks[$t['id']] = $t;
        }
    }
    $all_tasks = array_values($unique_tasks);
}
?>
<?php include "side-bar.php"; ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Track User-Posted Tasks - FlowEarner Admin</title>
    <style>
        :root {
            --admin-primary: #6366f1;
            --admin-secondary: #8b5cf6;
            --admin-success: #10b981;
            --admin-warning: #f59e0b;
            --admin-danger: #ef4444;
            --admin-dark: #1e293b;
            --admin-light: #f1f5f9;
        }

        * { box-sizing: border-box; margin: 0; padding: 0; }

        body {
            font-family: "Inter", "Segoe UI", sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
        }

        .admin-main {
            padding: 32px;
            overflow-y: auto;
        }

        .admin-header {
            background: white;
            padding: 24px;
            border-radius: 16px;
            margin-bottom: 24px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }

        .admin-header h1 {
            font-size: 2rem;
            color: var(--admin-dark);
            margin-bottom: 8px;
        }

        .admin-header p {
            color: #64748b;
        }

        .stats-container {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(140px, 1fr));
            gap: 10px;
            margin-bottom: 12px;
        }

        .stat-card {
            background: white;
            padding: 10px 12px;
            border-radius: 8px;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.06);
            border-left: 3px solid var(--admin-primary);
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: flex-start;
        }

        .stat-card h3 {
            font-size: 0.75rem;
            color: #64748b;
            margin-bottom: 6px;
            text-transform: uppercase;
            letter-spacing: 0.02em;
        }

        .stat-card .value {
            font-size: 1.1rem;
            font-weight: 700;
            color: var(--admin-dark);
        }

        .filters-bar {
            background: white;
            padding: 16px;
            border-radius: 12px;
            display: flex;
            gap: 12px;
            margin-bottom: 24px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            flex-wrap: wrap;
        }

        .filters-bar input {
            flex: 1;
            min-width: 200px;
            padding: 10px 12px;
            border: 1px solid #e2e8f0;
            border-radius: 8px;
            font-size: 0.9rem;
        }

        .filters-bar button {
            padding: 10px 20px;
            background: var(--admin-primary);
            color: white;
            border: none;
            border-radius: 8px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
        }

        .filters-bar button:hover {
            background: var(--admin-secondary);
        }

        .posters-table {
            background: white;
            border-radius: 12px;
            overflow: hidden;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            overflow-x: auto;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            min-width: 950px;
        }

        thead {
            background: var(--admin-light);
            border-bottom: 2px solid #e2e8f0;
        }

        th {
            padding: 16px;
            text-align: left;
            font-weight: 600;
            color: var(--admin-dark);
            font-size: 0.9rem;
        }

        td {
            padding: 16px;
            border-bottom: 1px solid #e2e8f0;
        }

        tbody tr:hover {
            background: #f8fafc;
        }

        .user-cell {
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .user-avatar {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            overflow: hidden;
            background: linear-gradient(135deg, #8b5cf6, #ec4899);
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: 700;
            font-size: 14px;
            flex-shrink: 0;
        }

        .user-info {
            display: flex;
            flex-direction: column;
            gap: 2px;
        }

        .user-info strong {
            color: var(--admin-dark);
            font-size: 0.95rem;
        }

        .user-info small {
            color: #64748b;
            font-size: 0.8rem;
        }

        .stat-cell {
            text-align: center;
        }

        .stat-cell strong {
            display: block;
            font-size: 1rem;
            color: var(--admin-dark);
        }

        .action-buttons {
            display: flex;
            gap: 6px;
        }

        .action-btn {
            padding: 8px 12px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-weight: 600;
            font-size: 0.75rem;
            transition: all 0.3s;
            white-space: nowrap;
        }

        .btn-view {
            background: #3b82f6;
            color: white;
        }

        .btn-view:hover {
            background: #2563eb;
        }

        .empty-state {
            text-align: center;
            padding: 60px 20px;
            color: #999;
        }

        .empty-state h3 {
            color: #666;
            margin-bottom: 10px;
            font-size: 1.2rem;
        }

        .alert-message {
            position: fixed;
            top: 20px;
            right: -400px;
            padding: 16px 24px;
            border-radius: 12px;
            color: white;
            font-size: 15px;
            z-index: 10000;
            opacity: 0;
            box-shadow: 0 10px 40px rgba(0, 0, 0, 0.2);
            transition: right 0.6s ease, opacity 0.6s ease;
        }

        .alert-message.show {
            right: 20px;
            opacity: 1;
        }

        .alert-message.success {
            background: var(--admin-success);
        }

        .alert-message.error {
            background: var(--admin-danger);
        }

        .modal-overlay {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.5);
            z-index: 2000;
            justify-content: center;
            align-items: center;
            padding: 20px;
            overflow-y: auto;
        }

        .modal-overlay.active {
            display: flex;
        }

        #editModal {
            z-index: 3000;
        }

        #editModal.active {
            z-index: 3000;
        }

        .modal-content {
            background: white;
            border-radius: 16px;
            padding: 32px;
            width: 100%;
            max-width: 800px;
            max-height: 90vh;
            overflow-y: auto;
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
            margin: auto;
        }

        .modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 24px;
            border-bottom: 1px solid #e2e8f0;
            padding-bottom: 16px;
        }

        .modal-header h2 {
            color: var(--admin-dark);
            margin: 0;
            font-size: 1.5rem;
        }

        .modal-close {
            background: none;
            border: none;
            font-size: 24px;
            cursor: pointer;
            color: #64748b;
        }

        .task-detail {
            margin-bottom: 20px;
            padding: 16px;
            background: #f8fafc;
            border-radius: 8px;
        }

        .task-detail label {
            font-weight: 600;
            color: var(--admin-dark);
            display: block;
            margin-bottom: 4px;
            font-size: 0.9rem;
        }

        .task-detail span {
            color: #475569;
            word-break: break-all;
        }

        .task-info-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 12px;
            margin-bottom: 12px;
            font-size: 0.85rem;
        }

        .task-info-item {
            padding: 10px;
            background: white;
            border-radius: 6px;
        }

        .task-info-item label {
            font-size: 0.8rem;
            color: #64748b;
        }

        .task-info-item span {
            display: block;
            color: var(--admin-dark);
            font-weight: 500;
            margin-top: 4px;
        }

        .completion-metrics {
            margin-bottom: 20px;
            padding: 16px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border-radius: 8px;
            color: white;
        }

        .completion-metrics-title {
            font-weight: 600;
            font-size: 0.9rem;
            margin-bottom: 12px;
            opacity: 0.9;
        }

        .completion-metrics-content {
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 16px;
        }

        .completion-stats {
            display: flex;
            gap: 20px;
            flex: 1;
        }

        .completion-stat {
            display: flex;
            flex-direction: column;
            gap: 4px;
        }

        .completion-stat-value {
            font-size: 1.8rem;
            font-weight: 700;
        }

        .completion-stat-label {
            font-size: 0.85rem;
            opacity: 0.9;
        }

        .completion-progress {
            flex: 1;
        }

        .progress-bar {
            width: 100%;
            height: 8px;
            background: rgba(255, 255, 255, 0.3);
            border-radius: 4px;
            overflow: hidden;
            margin-bottom: 6px;
        }

        .progress-fill {
            height: 100%;
            background: white;
            border-radius: 4px;
            transition: width 0.3s ease;
        }

        .progress-text {
            font-size: 0.8rem;
            opacity: 0.9;
        }

        .task-actions {
            display: flex;
            gap: 10px;
            margin-top: 24px;
            padding-top: 24px;
            border-top: 1px solid #e2e8f0;
            flex-wrap: wrap;
        }

        .task-action-btn {
            padding: 10px 16px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-weight: 600;
            transition: all 0.3s;
            flex: 1;
            min-width: 100px;
        }

        .task-action-btn.edit {
            background: #3b82f6;
            color: white;
        }

        .task-action-btn.edit:hover {
            background: #2563eb;
        }

        .task-action-btn.disable {
            background: #dc3545;
            color: white;
        }

        .task-action-btn.disable:hover {
            background: #c82333;
        }

        .task-action-btn.activate {
            background: #10b981;
            color: white;
        }

        .task-action-btn.activate:hover {
            background: #059669;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            font-weight: 600;
            color: var(--admin-dark);
            margin-bottom: 8px;
            font-size: 0.9rem;
        }

        .form-group input,
        .form-group textarea,
        .form-group select {
            width: 100%;
            padding: 10px 12px;
            border: 1px solid #e2e8f0;
            border-radius: 8px;
            font-size: 0.9rem;
            font-family: inherit;
        }

        .form-group textarea {
            resize: vertical;
            min-height: 100px;
        }

        .form-group input:focus,
        .form-group textarea:focus,
        .form-group select:focus {
            outline: none;
            border-color: var(--admin-primary);
            box-shadow: 0 0 0 3px rgba(99, 102, 241, 0.1);
        }

        .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 15px;
        }

        .checkbox-group {
            display: flex;
            align-items: center;
            gap: 10px;
            margin-top: 8px;
        }

        .checkbox-group input {
            width: 18px;
            height: 18px;
            cursor: pointer;
        }

        .modal-buttons {
            display: flex;
            gap: 10px;
            justify-content: flex-end;
            margin-top: 24px;
            padding-top: 24px;
            border-top: 1px solid #e2e8f0;
        }

        .btn-submit {
            padding: 10px 20px;
            background: var(--admin-primary);
            color: white;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-weight: 600;
            transition: all 0.3s;
        }

        .btn-submit:hover {
            background: var(--admin-secondary);
        }

        .btn-cancel {
            padding: 10px 20px;
            background: #6c757d;
            color: white;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-weight: 600;
            transition: all 0.3s;
        }

        .btn-cancel:hover {
            background: #5a6268;
        }

        .url-link {
            color: #3b82f6;
            text-decoration: none;
            word-break: break-all;
        }

        .url-link:hover {
            text-decoration: underline;
        }

        @media (max-width: 768px) {
            .admin-main {
                padding: 16px;
            }

            .admin-header h1 {
                font-size: 1.5rem;
            }

            .stats-container {
                grid-template-columns: 1fr 1fr;
            }

            .filters-bar {
                flex-direction: column;
            }

            .filters-bar input,
            .filters-bar button {
                width: 100%;
            }

            table {
                min-width: 700px;
                font-size: 0.85rem;
            }

            th, td {
                padding: 12px 8px;
            }

            .action-buttons {
                flex-direction: column;
            }

            .action-btn {
                width: 100%;
            }

            .modal-content {
                padding: 20px;
            }

            .modal-header h2 {
                font-size: 1.2rem;
            }

            .task-actions {
                flex-direction: column;
            }

            .task-action-btn {
                width: 100%;
                min-width: auto;
            }

            .form-row {
                grid-template-columns: 1fr;
            }

            .task-info-grid {
                grid-template-columns: 1fr;
            }

            .completion-metrics-content {
                flex-direction: column;
            }

            .completion-stats {
                flex-direction: column;
                width: 100%;
                margin-bottom: 16px;
            }

            .completion-stat {
                width: 100%;
            }

            .completion-progress {
                width: 100%;
            }
        }
    </style>
</head>
<body>

<div class="admin-content">
    <main class="admin-main">
        <div class="admin-header">
            <h1>Track User-Posted Tasks</h1>
            <p>Monitor users who post tasks and their activity</p>
        </div>

        <?php if ($success_message): ?>
            <div class="alert-message success show"><?php echo htmlspecialchars($success_message); ?></div>
        <?php endif; ?>

        <?php if ($error_message): ?>
            <div class="alert-message error show"><?php echo htmlspecialchars($error_message); ?></div>
        <?php endif; ?>

        <!-- Stats Grid -->
        <div class="stats-container">
            <div class="stat-card">
                <h3>Total Posters</h3>
                <div class="value"><?php echo $stats['total_posters'] ?? 0; ?></div>
            </div>
            <div class="stat-card">
                <h3>Total Tasks</h3>
                <div class="value"><?php echo $stats['total_tasks'] ?? 0; ?></div>
            </div>
            <div class="stat-card">
                <h3>Total Spent Posting</h3>
                <div class="value"><?php echo '₦' . number_format(floatval($total_spent), 2); ?></div>
            </div>
            <div class="stat-card">
                <h3>Active Tasks</h3>
                <div class="value"><?php echo $stats['active_tasks'] ?? 0; ?></div>
            </div>
            <div class="stat-card">
                <h3>Total Completions</h3>
                <div class="value"><?php echo $stats['total_completions'] ?? 0; ?></div>
            </div>
        </div>

        <!-- Search -->
        <form class="filters-bar" method="GET">
            <input type="text" name="search" placeholder="Search by username or name..." value="<?php echo htmlspecialchars($search); ?>" />
            <button type="submit">Search</button>
        </form>

        <!-- Posters Table -->
        <?php if (count($posters) > 0): ?>
            <div class="posters-table">
                <table>
                    <thead>
                        <tr>
                            <th>User</th>
                            <th>Total Posts</th>
                            <th>Active</th>
                            <th>Inactive</th>
                            <th>Completions</th>
                            <!--<th>Total Rewards</th>-->
                            <th>Last Posted</th>
                            <th>Spent (₦)</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($posters as $poster): ?>
                            <tr>
                                <td>
                                    <div class="user-cell">
                                        <div class="user-avatar">
                                            <?php echo strtoupper($poster['posted_by_username'][0] ?? 'U'); ?>
                                        </div>
                                        <div class="user-info">
                                            <strong><?php echo htmlspecialchars($poster['posted_by_username']); ?></strong>
                                            <small><?php echo htmlspecialchars($poster['posted_by_fullname'] ?? ''); ?></small>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <div class="stat-cell">
                                        <strong><?php echo $poster['total_posted']; ?></strong>
                                    </div>
                                </td>
                                <td>
                                    <div class="stat-cell">
                                        <strong style="color: #10b981;"><?php echo $poster['active_count']; ?></strong>
                                    </div>
                                </td>
                                <td>
                                    <div class="stat-cell">
                                        <strong style="color: #f59e0b;"><?php echo $poster['inactive_count']; ?></strong>
                                    </div>
                                </td>
                                <td>
                                    <div class="stat-cell">
                                        <strong><?php echo $poster['total_completions'] ?? 0; ?></strong>
                                    </div>
                                </td>

                                <td><?php echo date('M d, Y', strtotime($poster['last_posted'])); ?></td>

                                <td style="text-align: center;">
                                    <strong><?php echo '₦' . number_format(floatval($poster['total_spent_by_user'] ?? 0), 2); ?></strong>
                                </td>

                                <td>
                                    <div class="action-buttons">
                                        <button class="action-btn btn-view" onclick="viewUserTasks('<?php echo htmlspecialchars($poster['posted_by_username']); ?>')">View Tasks</button>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php else: ?>
            <div class="posters-table">
                <div class="empty-state">
                    <h3>No users found</h3>
                    <p>No users have posted any tasks yet.</p>
                </div>
            </div>
        <?php endif; ?>
    </main>
</div>

<!-- Tasks Modal -->
<div id="tasksModal" class="modal-overlay">
    <div class="modal-content">
        <div class="modal-header">
            <h2>User's Tasks</h2>
            <button class="modal-close" onclick="closeModal('tasksModal')">&times;</button>
        </div>
        <div id="tasksContainer"></div>
    </div>
</div>

<!-- Edit Task Modal -->
<div id="editModal" class="modal-overlay">
    <div class="modal-content">
        <div class="modal-header">
            <h2>Edit Task</h2>
            <button class="modal-close" onclick="closeModal('editModal')">&times;</button>
        </div>
        <form method="POST" id="editForm">
            <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token']); ?>">
            <input type="hidden" name="action" value="edit_task">
            <input type="hidden" name="task_id" id="editTaskId">

            <div class="form-group">
                <label>Task Title</label>
                <input type="text" name="title" id="editTitle" required>
            </div>

            <div class="form-group">
                <label>Description</label>
                <textarea name="description" id="editDescription" required></textarea>
            </div>

            <div class="form-row">
                <div class="form-group">
                    <label>Task Type</label>
                    <select name="task_type" id="editTaskType">
                        <option value="social_media">Social Media</option>
                        <option value="website_visit">Website Visit</option>
                        <option value="group_join">Group Join</option>
                        <option value="like_comment">Like/Comment</option>
                        <option value="other">Other</option>
                    </select>
                </div>

                <div class="form-group">
                    <label>Platform</label>
                    <input type="text" name="platform" id="editPlatform">
                </div>
            </div>

            <div class="form-row">
                <div class="form-group">
                    <label>Reward Amount (₦)</label>
                    <input type="number" name="reward_amount" id="editRewardAmount" step="0.01" min="0" required>
                </div>

                <div class="form-group">
                    <label>Participants Count</label>
                    <input type="number" name="participants_count" id="editParticipantsCount" min="1" required>
                </div>
            </div>

            <div class="form-row">
                <div class="form-group">
                    <label>Member Reward (₦)</label>
                    <input type="number" name="member_reward" id="editMemberReward" step="0.01" min="0">
                </div>

                <div class="form-group">
                    <label>Non-Member Reward (₦)</label>
                    <input type="number" name="non_member_reward" id="editNonMemberReward" step="0.01" min="0">
                </div>
            </div>

            <div class="form-group">
                <label>Task URL</label>
                <input type="url" name="task_url" id="editTaskUrl">
            </div>

            <div class="form-group">
                <label style="display: flex; align-items: center; gap: 8px; font-weight: 400; cursor: pointer;">
                    <input type="checkbox" name="is_premium_only" id="editPremiumOnly" style="width: auto;">
                    Premium Only Task
                </label>
            </div>

            <div class="modal-buttons">
                <button type="button" class="btn-cancel" onclick="closeModal('editModal')">Cancel</button>
                <button type="submit" class="btn-submit">Save Changes</button>
            </div>
        </form>
    </div>
</div>

<script>
    const allTasks = <?php echo json_encode($all_tasks); ?>;

    function viewUserTasks(username) {
        const userTasks = allTasks.filter(t => t.posted_by_username === username);
        
        let html = '<div style="max-height: 600px; overflow-y: auto;">';
        
        if (userTasks.length === 0) {
            html += '<p style="color: #999; text-align: center;">No tasks found for this user.</p>';
        } else {
            userTasks.forEach(task => {
                // Determine status based on is_active flag
                let statusColor, statusText;
                if (task.is_active == 1) {
                    statusColor = '#10b981';
                    statusText = 'ACTIVE';
                } else if (task.is_permanently_disabled == 1) {
                    statusColor = '#ef4444';
                    statusText = 'DISABLED';
                } else {
                    statusColor = '#f59e0b';
                    statusText = 'INACTIVE';
                }
                
                const createdDate = new Date(task.created_at).toLocaleString();
                const updatedDate = new Date(task.updated_at).toLocaleString();
                
                let taskUrl = task.task_url ? `<a href="${escapeHtml(task.task_url)}" target="_blank" class="url-link">${escapeHtml(task.task_url)}</a>` : 'N/A';
                
                const completedCount = parseInt(task.completed_count) || 0;
                const participantsCount = parseInt(task.participants_count) || 1;
                const completionPercentage = Math.round((completedCount / participantsCount) * 100);
                
                html += `
                    <div class="task-detail">
                        <div style="margin-bottom: 12px; display: flex; justify-content: space-between; align-items: start;">
                            <strong style="font-size: 1.05rem; color: var(--admin-dark);">${escapeHtml(task.title)}</strong>
                            <span style="padding: 4px 10px; background: ${statusColor}; color: white; border-radius: 20px; font-size: 0.75rem; font-weight: 600; white-space: nowrap; margin-left: 10px;">● ${statusText}</span>
                        </div>

                        <div class="completion-metrics">
                            <div class="completion-metrics-title">Completion Metrics</div>
                            <div class="completion-metrics-content">
                                <div class="completion-stats">
                                    <div class="completion-stat">
                                        <div class="completion-stat-value">${completedCount}</div>
                                        <div class="completion-stat-label">Users Completed</div>
                                    </div>
                                    <div class="completion-stat">
                                        <div class="completion-stat-value">${participantsCount}</div>
                                        <div class="completion-stat-label">Total Participants</div>
                                    </div>
                                </div>
                                <div class="completion-progress">
                                    <div class="progress-bar">
                                        <div class="progress-fill" style="width: ${completionPercentage}%;"></div>
                                    </div>
                                    <div class="progress-text">${completionPercentage}% Complete</div>
                                </div>
                            </div>
                        </div>

                        <div style="margin-bottom: 12px;">
                            <label style="color: #64748b; font-size: 0.85rem;">Description:</label>
                            <span style="display: block; color: #475569; margin-top: 4px;">${escapeHtml(task.description.substring(0, 200))}</span>
                        </div>

                        <div class="task-info-grid">
                            <div class="task-info-item">
                                <label>Platform</label>
                                <span>${escapeHtml(task.platform)}</span>
                            </div>
                            <div class="task-info-item">
                                <label>Task Type</label>
                                <span>${escapeHtml(task.task_type)}</span>
                            </div>
                            <div class="task-info-item" style="display: none;">
                                <label>Reward</label>
                                <span>₦${parseFloat(task.reward_amount).toFixed(2)}</span>
                            </div>
                            <div class="task-info-item">
                                <label>Participants</label>
                                <span>${task.participants_count}</span>
                            </div>
                            <div class="task-info-item">
                                <label>Amount Spent (₦)</label>
                                <span>₦${parseFloat(task.task_spent || 0).toFixed(2)}</span>
                            </div>
                            <div class="task-info-item">
                                <label>Completed</label>
                                <span>${task.completed_count}</span>
                            </div>
                            <div class="task-info-item" style="display: none;">
                                <label>Member Reward</label>
                                <span>₦${parseFloat(task.member_reward).toFixed(2)}</span>
                            </div>
                            <div class="task-info-item" style="display: none;">
                                <label>Non-Member Reward</label>
                                <span>₦${parseFloat(task.non_member_reward).toFixed(2)}</span>
                            </div>
                            <div class="task-info-item">
                                <label>Premium Only</label>
                                <span>${task.is_premium_only ? 'Yes' : 'No'}</span>
                            </div>
                        </div>

                        <div style="margin-bottom: 12px; padding: 12px; background: white; border-radius: 6px;">
                            <label style="color: #64748b; font-size: 0.85rem; display: block; margin-bottom: 4px;">Task URL:</label>
                            <span style="color: #475569;">${taskUrl}</span>
                        </div>

                        <div style="margin-bottom: 12px; padding: 12px; background: white; border-radius: 6px; display: grid; grid-template-columns: 1fr 1fr; gap: 10px;">
                            <div>
                                <label style="color: #64748b; font-size: 0.85rem; display: block; margin-bottom: 4px;">Created:</label>
                                <span style="color: #475569; font-size: 0.9rem;">${createdDate}</span>
                            </div>
                            <div>
                                <label style="color: #64748b; font-size: 0.85rem; display: block; margin-bottom: 4px;">Updated:</label>
                                <span style="color: #475569; font-size: 0.9rem;">${updatedDate}</span>
                            </div>
                        </div>
                        
                        <div class="task-actions" style="gap: 8px; display: flex; flex-wrap: wrap;">
                            <button type="button" class="task-action-btn" style="flex: 1;" onclick="viewTaskDetails(${task.id}, event)">View Task</button>
                           
                            ${task.is_active == 1 ? 
                                `<button type="button" class="task-action-btn disable" style="flex: 1;" onclick="disableTask(${task.id})">Disable</button>` : 
                                `<button type="button" class="task-action-btn activate" style="flex: 1;" onclick="activateTask(${task.id})">Activate</button>`
                            }
                        </div>
                    </div>
                `;
            });
        }

        html += '</div>';
        document.getElementById('tasksContainer').innerHTML = html;
        openModal('tasksModal');
    }

    function viewTaskDetails(taskId, event) {
        if (event) {
            event.preventDefault();
            event.stopPropagation();
        }
        
        const task = allTasks.find(t => t.id === taskId);
        if (!task || !task.task_url) {
            alert('No task URL available');
            return;
        }
        
        window.open(task.task_url, '_blank');
    }

    function openEditModal(taskId, event) {
        if (event) {
            event.preventDefault();
            event.stopPropagation();
        }
        
        const task = allTasks.find(t => t.id === taskId);
        if (!task) return;

        document.getElementById('editTaskId').value = taskId;
        document.getElementById('editTitle').value = task.title;
        document.getElementById('editDescription').value = task.description;
        document.getElementById('editTaskType').value = task.task_type;
        document.getElementById('editPlatform').value = task.platform;
        document.getElementById('editRewardAmount').value = task.reward_amount;
        document.getElementById('editParticipantsCount').value = task.participants_count;
        document.getElementById('editMemberReward').value = task.member_reward;
        document.getElementById('editNonMemberReward').value = task.non_member_reward;
        document.getElementById('editTaskUrl').value = task.task_url;
        document.getElementById('editPremiumOnly').checked = task.is_premium_only ? true : false;

        // Close tasks modal and open edit modal
        setTimeout(() => {
            closeModal('tasksModal');
            openModal('editModal');
        }, 50);
    }

    function disableTask(taskId) {
        if (confirm('Are you sure you want to disable this task? User cannot reactivate it.')) {
            submitAction('disable', taskId);
        }
    }

    function activateTask(taskId) {
        if (confirm('Are you sure you want to activate this task?')) {
            submitAction('activate', taskId);
        }
    }

    function submitAction(action, taskId) {
        const form = document.createElement('form');
        form.method = 'POST';
        form.innerHTML = `
            <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token']); ?>">
            <input type="hidden" name="action" value="${action}">
            <input type="hidden" name="task_id" value="${taskId}">
        `;
        document.body.appendChild(form);
        form.submit();
    }

    function openModal(modalId) {
        document.getElementById(modalId).classList.add('active');
    }

    function closeModal(modalId) {
        document.getElementById(modalId).classList.remove('active');
    }

    function escapeHtml(text) {
        const map = {
            '&': '&amp;',
            '<': '&lt;',
            '>': '&gt;',
            '"': '&quot;',
            "'": '&#039;'
        };
        return text.replace(/[&<>"']/g, m => map[m]);
    }

    // Auto-hide alerts after 4 seconds
    document.addEventListener('DOMContentLoaded', () => {
        const alerts = document.querySelectorAll('.alert-message.show');
        alerts.forEach(alert => {
            setTimeout(() => {
                alert.classList.remove('show');
            }, 4000);
        });
    });

    // Close modal when clicking outside
    ['tasksModal', 'editModal'].forEach(modalId => {
        document.getElementById(modalId).addEventListener('click', (e) => {
            if (e.target.id === modalId) {
                closeModal(modalId);
            }
        });
    });
</script>

</body>
</html>
