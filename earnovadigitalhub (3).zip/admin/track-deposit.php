<?php
session_start();
require_once '../config/database2.php';

// Check if user is logged in and is admin
if (!isset($_SESSION['user_id'])) {
    header('Location: ../login.php');
    exit();
}

$user_id = $_SESSION['user_id'];

// Check if user is admin
$stmt = $pdo->prepare("SELECT is_admin FROM users WHERE id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch();

if (!$user || !$user['is_admin']) {
    header('Location: ../dashboard.php');
    exit();
}

// Get filters
$search = $_GET['search'] ?? '';
$gateway = strtolower(trim($_GET['gateway'] ?? ''));
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$per_page = 50;
$offset = ($page - 1) * $per_page;

// Build queries for Paystack and Korapay deposits
// Exclude transactions that are recorded as Korapay (they will be shown from korapay_transactions)
$paystack_select = "SELECT t.id, t.user_id, t.amount, t.reference_id AS reference_id, 'Paystack' AS gateway, t.description, t.created_at, u.username, u.email, u.full_name 
          FROM transactions t 
          JOIN users u ON t.user_id = u.id 
          LEFT JOIN korapay_transactions kt ON kt.korapay_reference = t.reference_id
          WHERE t.transaction_type = 'deposit' AND kt.id IS NULL";

// Korapay sources: post-task payments and general VBA/transactions
$korapay_select = "SELECT k.id, k.user_id, k.amount, k.reference AS reference_id, 'Korapay' AS gateway, k.metadata AS description, k.created_at, u.username, u.email, u.full_name 
          FROM korapay_post_task_payments k 
          JOIN users u ON k.user_id = u.id 
          WHERE k.status = 'success'";

$korapay_select_vba = "SELECT kt.id, kt.user_id, kt.amount, kt.korapay_reference AS reference_id, 'Korapay' AS gateway, kt.description AS description, kt.received_at AS created_at, u.username, u.email, u.full_name 
          FROM korapay_transactions kt 
          JOIN users u ON kt.user_id = u.id 
          WHERE kt.status = 'success'";

// Membership and advertiser payments (show membership upgrades)
$premium_select = "SELECT p.id, p.user_id, p.amount, p.payment_reference AS reference_id, UPPER(p.payment_method) AS gateway, CONCAT('Premium upgrade via ', UPPER(p.payment_method)) AS description, p.created_at, u.username, u.email, u.full_name 
          FROM premium_payments p 
          JOIN users u ON p.user_id = u.id 
          WHERE p.status = 'completed'";

$advertiser_select = "SELECT a.id, a.user_id, a.amount, a.payment_reference AS reference_id, UPPER(a.payment_method) AS gateway, CONCAT('Advertiser plan via ', UPPER(a.payment_method)) AS description, a.created_at, u.username, u.email, u.full_name 
          FROM advertiser_payments a 
          JOIN users u ON a.user_id = u.id 
          WHERE a.status = 'completed'";

$params = [];

if ($search) {
    $paystack_search_sql = " AND (u.username LIKE :search OR u.email LIKE :search OR u.full_name LIKE :search OR t.reference_id LIKE :search)";
    $korapay_search_sql = " AND (u.username LIKE :search OR u.email LIKE :search OR u.full_name LIKE :search OR k.reference LIKE :search)";
    $korapay_vba_search_sql = " AND (u.username LIKE :search OR u.email LIKE :search OR u.full_name LIKE :search OR kt.korapay_reference LIKE :search)";
    $paystack_select .= $paystack_search_sql;
    $korapay_select .= $korapay_search_sql;
    $korapay_select_vba .= $korapay_vba_search_sql;
    $params['search'] = "%$search%";
}

// Decide which query to use based on gateway filter
if ($gateway === 'paystack') {
    $query = $paystack_select;
} elseif ($gateway === 'korapay' || $gateway === 'kora' || $gateway === 'korapay') {
    // show both korapay tables
    $query = $korapay_select . " UNION ALL " . $korapay_select_vba;
} else {
    // both gateways + membership selects
    $query = $paystack_select . " UNION ALL " . $korapay_select . " UNION ALL " . $korapay_select_vba . " UNION ALL " . $premium_select . " UNION ALL " . $advertiser_select;
}

// Get total count for pagination (wrap query when needed)
if (stripos($query, 'union all') !== false) {
    $count_query = "SELECT COUNT(*) as total FROM (" . $query . ") AS combined";
} else {
    $count_query = "SELECT COUNT(*) as total FROM (" . $query . ") AS combined";
}
try {
    error_log("[v0] Count Query: " . $count_query);
    error_log("[v0] Params: " . print_r($params, true));

    $count_stmt = $pdo->prepare($count_query);

    // Bind all filter parameters
    foreach ($params as $key => $value) {
        $count_stmt->bindValue(":$key", $value);
    }

    $count_stmt->execute();
    $total_records = $count_stmt->fetch()['total'] ?? 0;
    $total_pages = $total_records ? ceil($total_records / $per_page) : 1;

    error_log("[v0] Total records: " . $total_records);
} catch (PDOException $e) {
    error_log("[v0] Count Query Error: " . $e->getMessage());
    error_log("[v0] Query: " . $count_query);
    error_log("[v0] Params: " . print_r($params, true));
    die("Database error: " . $e->getMessage() . "<br>Query: " . htmlspecialchars($count_query) . "<br>Params: " . htmlspecialchars(print_r($params, true)));
}

// Get deposits with pagination
$query .= " ORDER BY created_at DESC LIMIT :limit OFFSET :offset";
try {
    error_log("[v0] Main Query: " . $query);
    
    $stmt = $pdo->prepare($query);
    foreach ($params as $key => $value) {
        $stmt->bindValue(":$key", $value);
    }
    $stmt->bindValue(':limit', $per_page, PDO::PARAM_INT);
    $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
    
    $stmt->execute();
    $deposits = $stmt->fetchAll();
    
    error_log("[v0] Fetched " . count($deposits) . " deposits");
} catch (PDOException $e) {
    error_log("[v0] Main Query Error: " . $e->getMessage());
    error_log("[v0] Query: " . $query);
    error_log("[v0] Params: " . print_r($params, true));
    die("Database error: " . $e->getMessage() . "<br>Query: " . htmlspecialchars($query) . "<br>Params: " . htmlspecialchars(print_r($params, true)));
}

// Get stats: total Paystack and Korapay deposits
$stats = [
    'paystack_count' => 0,
    'paystack_amount' => 0,
    'korapay_count' => 0,
    'korapay_amount' => 0,
    'paystack_today_count' => 0,
    'paystack_today_amount' => 0,
    'korapay_today_count' => 0,
    'korapay_today_amount' => 0,
];

// Paystack stats: exclude transactions that are actually Korapay (by reference present in korapay_transactions)
try {
    $stmt = $pdo->query("SELECT COUNT(*) as cnt, SUM(amount) as sum, COUNT(CASE WHEN DATE(created_at)=CURDATE() THEN 1 END) as today_cnt, SUM(CASE WHEN DATE(created_at)=CURDATE() THEN amount ELSE 0 END) as today_sum FROM transactions WHERE transaction_type = 'deposit' AND (reference_id IS NULL OR reference_id NOT IN (SELECT korapay_reference FROM korapay_transactions))");
    $r = $stmt->fetch();
    if ($r) {
        $stats['paystack_count'] = (int)$r['cnt'];
        $stats['paystack_amount'] = (float)$r['sum'];
        $stats['paystack_today_count'] = (int)$r['today_cnt'];
        $stats['paystack_today_amount'] = (float)$r['today_sum'];
    }
} catch (Exception $e) {
    error_log('Paystack stats fetch error: ' . $e->getMessage());
}

// Korapay stats: include both post_task_payments and korapay_transactions
try {
    $korapay_cnt = 0; $korapay_sum = 0; $korapay_today_cnt = 0; $korapay_today_sum = 0;
    $stmt = $pdo->query("SELECT COUNT(*) as cnt, SUM(amount) as sum, COUNT(CASE WHEN DATE(created_at)=CURDATE() THEN 1 END) as today_cnt, SUM(CASE WHEN DATE(created_at)=CURDATE() THEN amount ELSE 0 END) as today_sum FROM korapay_post_task_payments WHERE status = 'success'");
    $r = $stmt->fetch();
    if ($r) {
        $korapay_cnt += (int)$r['cnt'];
        $korapay_sum += (float)$r['sum'];
        $korapay_today_cnt += (int)$r['today_cnt'];
        $korapay_today_sum += (float)$r['today_sum'];
    }
    $stmt = $pdo->query("SELECT COUNT(*) as cnt, SUM(amount) as sum, COUNT(CASE WHEN DATE(received_at)=CURDATE() THEN 1 END) as today_cnt, SUM(CASE WHEN DATE(received_at)=CURDATE() THEN amount ELSE 0 END) as today_sum FROM korapay_transactions WHERE status = 'success'");
    $r2 = $stmt->fetch();
    if ($r2) {
        $korapay_cnt += (int)$r2['cnt'];
        $korapay_sum += (float)$r2['sum'];
        $korapay_today_cnt += (int)$r2['today_cnt'];
        $korapay_today_sum += (float)$r2['today_sum'];
    }
    $stats['korapay_count'] = $korapay_cnt;
    $stats['korapay_amount'] = $korapay_sum;
    $stats['korapay_today_count'] = $korapay_today_cnt;
    $stats['korapay_today_amount'] = $korapay_today_sum;
} catch (Exception $e) {
    error_log('Korapay stats fetch error: ' . $e->getMessage());
}

// Post-process deposits to determine purpose for admin UI without changing DB
foreach ($deposits as &$d) {
    $d['purpose'] = 'General Balance';

    $desc = trim((string)($d['description'] ?? ''));
    $deposit_gateway = strtoupper($d['gateway'] ?? '');

    // Korapay post-task payments often store JSON metadata in description
    if ($deposit_gateway === 'KORAPAY') {
        // If metadata looks like JSON and contains task keys, mark as Advert Publish
        $maybe = json_decode($desc, true);
        if (is_array($maybe) && (!empty($maybe['title']) || !empty($maybe['task_url']))) {
            $d['purpose'] = 'Advert Publish (Post Task)';
            // set friendly description if available
            if (!empty($maybe['title'])) $d['description'] = 'Posted task: ' . $maybe['title'];
        } else {
            // fallback: if description mentions post task
            if (stripos($desc, 'post task') !== false || stripos($desc, 'post_task') !== false || stripos($desc, 'post task') !== false) {
                $d['purpose'] = 'Advert Publish (Post Task)';
            }
        }
    }

    // Paystack companion deposits for task posting have textual markers
    if ($deposit_gateway === 'PAYSTACK') {
        if (!empty($desc) && (stripos($desc, 'task posting') !== false || stripos($desc, 'post task') !== false || stripos($desc, 'advert') !== false || stripos($desc, 'advertisement') !== false)) {
            $d['purpose'] = 'Advert Publish (Post Task)';
        }
    }

    // Premium / Advertiser unioned selects will have description containing 'Premium' or 'Advertiser'
    if (stripos($desc, 'premium') !== false || stripos($desc, 'upgrade') !== false || stripos($desc, 'advertiser plan') !== false) {
        $d['purpose'] = 'Membership Upgrade';
    }
}
unset($d);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Track Deposits - FlowEarner Admin</title>
    <link rel="stylesheet" href="../css/style.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px;
        }

        .admin-container {
            display: flex;
            gap: 20px;
            max-width: 1400px;
            margin: 0 auto;
        }

        .admin-main {
            flex: 1;
        }

        .admin-header {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            padding: 30px;
            margin-bottom: 20px;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
        }

        .admin-header h1 {
            color: #2d3748;
            font-size: 32px;
            margin-bottom: 10px;
        }

        .admin-header p {
            color: #718096;
            font-size: 16px;
        }

        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 20px;
        }

        .stat-card {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 15px;
            padding: 25px;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
        }

        .stat-card h3 {
            color: #718096;
            font-size: 14px;
            margin-bottom: 10px;
            text-transform: uppercase;
        }

        .stat-card .value {
            color: #2d3748;
            font-size: 32px;
            font-weight: bold;
        }

        .filters-section {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 15px;
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
        }

        .filter-row {
            display: flex;
            gap: 15px;
            flex-wrap: wrap;
            align-items: flex-end;
        }

        .filter-group {
            flex: 1;
            min-width: 200px;
        }

        .filter-group label {
            display: block;
            margin-bottom: 8px;
            color: #4a5568;
            font-size: 14px;
            font-weight: 600;
        }

        .filter-group input {
            width: 100%;
            padding: 12px 20px;
            border: 2px solid #e2e8f0;
            border-radius: 10px;
            font-size: 14px;
        }

        .filter-btn {
            padding: 12px 30px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border: none;
            border-radius: 10px;
            cursor: pointer;
            font-size: 14px;
            font-weight: 600;
            transition: transform 0.3s;
        }

        .filter-btn:hover {
            transform: translateY(-2px);
        }

        .deposits-table {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            padding: 30px;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
            overflow-x: auto;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th {
            text-align: left;
            padding: 15px;
            color: #4a5568;
            font-weight: 600;
            border-bottom: 2px solid #e2e8f0;
        }

        td {
            padding: 15px;
            color: #2d3748;
            border-bottom: 1px solid #e2e8f0;
        }

        .amount-cell {
            font-weight: 700;
            color: #10b981;
            font-size: 16px;
        }

        .pagination {
            display: flex;
            justify-content: center;
            gap: 10px;
            margin-top: 20px;
        }

        .pagination a {
            padding: 10px 16px;
            background: white;
            border: 2px solid #e2e8f0;
            border-radius: 8px;
            color: #4a5568;
            text-decoration: none;
            transition: all 0.3s;
        }

        .pagination a:hover, .pagination a.active {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border-color: transparent;
        }

        .no-data {
            text-align: center;
            padding: 40px;
            color: #718096;
            font-size: 16px;
        }

        @media (max-width: 768px) {
            .admin-container {
                flex-direction: column;
            }

            .admin-main {
                padding: 0;
            }

            .admin-header {
                padding: 16px;
                margin-bottom: 12px;
                border-radius: 12px;
            }

            .admin-header h1 {
                font-size: 18px;
                margin-bottom: 4px;
            }

            .admin-header p {
                font-size: 12px;
            }

            .stats-grid {
                grid-template-columns: 1fr 1fr;
                gap: 12px;
                margin-bottom: 12px;
            }

            .stat-card {
                padding: 12px;
                border-radius: 10px;
            }

            .stat-card h3 {
                font-size: 11px;
                margin-bottom: 6px;
            }

            .stat-card .value {
                font-size: 18px;
            }

            .filters-section {
                padding: 12px;
                margin-bottom: 12px;
                border-radius: 10px;
            }

            .filter-row {
                gap: 10px;
                flex-direction: column;
            }

            .filter-group {
                min-width: 100%;
            }

            .filter-group input {
                padding: 10px 12px;
                font-size: 14px;
            }

            .filter-btn {
                padding: 10px 20px;
                font-size: 12px;
                width: 100%;
            }

            .deposits-table {
                padding: 12px;
                border-radius: 10px;
                overflow-x: auto;
                -webkit-overflow-scrolling: touch;
            }

            table {
                min-width: 700px;
                display: inline-block;
            }

            th {
                padding: 8px;
                font-size: 12px;
            }

            td {
                padding: 8px;
                font-size: 11px;
            }

            .amount-cell {
                font-size: 12px;
            }

            .pagination {
                gap: 5px;
                margin-top: 12px;
            }

            .pagination a {
                padding: 8px 12px;
                font-size: 11px;
            }

            .no-data {
                padding: 20px;
                font-size: 13px;
            }

            body {
                padding: 12px;
            }
        }
    </style>
</head>
<body>
    <?php include 'side-bar.php'; ?>
    <div class="admin-content"> 
        <main class="admin-main">
            <div class="admin-header">
                <h1 style="font-size: 20px;">Track Deposits</h1>
                <p>Monitor all deposits made through Paystack</p>
            </div>

            <!-- Stats -->
            <div class="stats-grid">
                <div class="stat-card">
                    <h3>Total Paystack Deposits</h3>
                    <div class="value"><?php echo number_format($stats['paystack_count']); ?></div>
                </div>
                <div class="stat-card">
                    <h3>Paystack Amount</h3>
                    <div class="value" style="color: #10b981;">₦<?php echo number_format($stats['paystack_amount'], 2); ?></div>
                </div>
                <div class="stat-card">
                    <h3>Total Korapay Deposits</h3>
                    <div class="value"><?php echo number_format($stats['korapay_count']); ?></div>
                </div>
                <div class="stat-card">
                    <h3>Korapay Amount</h3>
                    <div class="value" style="color: #10b981;">₦<?php echo number_format($stats['korapay_amount'], 2); ?></div>
                </div>
            </div>

            <!-- Filters -->
            <div class="filters-section">
                <form method="GET" class="filter-row">
                    <div class="filter-group">
                        <label>Search</label>
                        <input type="text" name="search" placeholder="Username, email, or reference..." value="<?php echo htmlspecialchars($search); ?>">
                    </div>
                    <div class="filter-group">
                        <label>Gateway</label>
                        <select name="gateway" style="padding:12px 16px; border-radius:8px; border:1px solid #e2e8f0;">
                            <option value="" <?php echo $gateway === '' ? 'selected' : ''; ?>>All</option>
                            <option value="paystack" <?php echo $gateway === 'paystack' ? 'selected' : ''; ?>>Paystack</option>
                            <option value="korapay" <?php echo $gateway === 'korapay' ? 'selected' : ''; ?>>Korapay</option>
                        </select>
                    </div>
                    <button type="submit" class="filter-btn">Search</button>
                </form>
            </div>

            <!-- Deposits Table -->
            <div class="deposits-table">
                <?php if (count($deposits) > 0): ?>
                    <table>
                        <thead>
                            <tr>
                                <th>Deposit ID</th>
                                <th>User</th>
                                <th>Amount</th>
                                <th>Payment Reference</th>
                                <th>Gateway</th>
                                <th>Purpose</th>
                                <th>Date</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($deposits as $deposit): ?>
                                <tr>
                                    <td>#<?php echo $deposit['id']; ?></td>
                                    <td>
                                        <strong><?php echo htmlspecialchars($deposit['username']); ?></strong><br>
                                        <small style="color: #718096;"><?php echo htmlspecialchars($deposit['email']); ?></small>
                                    </td>
                                    <td class="amount-cell">₦<?php echo number_format($deposit['amount'], 2); ?></td>
                                    <td>
                                        <code style="background: #f7fafc; padding: 4px 8px; border-radius: 4px; font-size: 12px;">
                                            <?php echo htmlspecialchars($deposit['reference_id'] ?? 'N/A'); ?>
                                        </code>
                                    </td>
                                    <td>
                                        <span style="display: inline-block; padding: 4px 12px; background: #dbeafe; color: #1e40af; border-radius: 12px; font-size: 12px; font-weight: 600;">
                                            <?php echo htmlspecialchars($deposit['gateway'] ?? 'Paystack'); ?>
                                        </span>
                                    </td>
                                    <td><?php echo htmlspecialchars($deposit['purpose'] ?? $deposit['description']); ?></td>
                                    <td><?php echo date('M d, Y H:i', strtotime($deposit['created_at'])); ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>

                    <!-- Pagination -->
                    <?php if ($total_pages > 1): ?>
                        <div class="pagination">
                            <?php if ($page > 1): ?>
                                <a href="?page=<?php echo $page - 1; ?>&search=<?php echo urlencode($search); ?>&gateway=<?php echo urlencode($gateway); ?>">← Previous</a>
                            <?php endif; ?>
                            
                            <?php for ($i = max(1, $page - 2); $i <= min($total_pages, $page + 2); $i++): ?>
                                          <a href="?page=<?php echo $i; ?>&search=<?php echo urlencode($search); ?>&gateway=<?php echo urlencode($gateway); ?>" 
                                              class="<?php echo $i === $page ? 'active' : ''; ?>">
                                    <?php echo $i; ?>
                                </a>
                            <?php endfor; ?>
                            
                            <?php if ($page < $total_pages): ?>
                                <a href="?page=<?php echo $page + 1; ?>&search=<?php echo urlencode($search); ?>&gateway=<?php echo urlencode($gateway); ?>">Next →</a>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
                <?php else: ?>
                    <div class="no-data">
                        <p>No deposits found matching your criteria.</p>
                    </div>
                <?php endif; ?>
            </div>
        </main>
    </div>
</body>
</html>
