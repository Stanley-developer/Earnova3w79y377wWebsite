<?php
session_start();
require_once '../config/database.php';

// Check if user is admin
if (!isset($_SESSION['user_id'])) {
    header('Location: ../login.php');
    exit();
}

$user_id = $_SESSION['user_id'];
$stmt = $conn->prepare("SELECT is_admin FROM users WHERE id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result()->fetch_assoc();

if (!$result || $result['is_admin'] != 1) {
    header('Location: ../dashboard.php');
    exit();
}

// Fetch all users with pagination
$page = isset($_GET['page']) ? intval($_GET['page']) : 1;
$per_page = 20;
$offset = ($page - 1) * $per_page;

$search = isset($_GET['search']) ? $conn->real_escape_string($_GET['search']) : '';
$filter = isset($_GET['filter']) ? $_GET['filter'] : 'all';

$where_clause = "WHERE 1=1";
if ($search) {
    $where_clause .= " AND (u.username LIKE '%$search%' OR u.email LIKE '%$search%' OR u.full_name LIKE '%$search%')";
}
if ($filter === 'premium_plus') {
    $where_clause .= " AND u.advertiser_plan IS NOT NULL";
} elseif ($filter === 'premium') {
    $where_clause .= " AND u.membership_type = 'premium' AND (u.advertiser_plan IS NULL OR u.advertiser_plan = '')";
} elseif ($filter === 'free') {
    $where_clause .= " AND u.membership_type = 'free'";
} elseif ($filter === 'banned') {
    $where_clause .= " AND u.status = 'banned'";
}

$total_users = $conn->query("SELECT COUNT(*) as total FROM users u $where_clause")->fetch_assoc()['total'];
$total_pages = ceil($total_users / $per_page);

$users = $conn->query("
    SELECT 
    u.id, u.username, u.email, u.full_name, u.profile_picture, u.membership_type, u.advertiser_plan, u.status, u.created_at, u.how_heard, u.country,
    b.total_balance, b.task_earnings, b.referral_earnings, b.game_earnings
    FROM users u 
    LEFT JOIN balances b ON u.id = b.user_id
    $where_clause 
    ORDER BY u.created_at DESC 
    LIMIT $per_page OFFSET $offset
")->fetch_all(MYSQLI_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Manage Users - FlowEarner Admin</title>
  <style>
    :root {
      --admin-primary: #6366f1;
      --admin-secondary: #8b5cf6;
      --admin-success: #10b981;
      --admin-warning: #f59e0b;
      --admin-danger: #ef4444;
      --admin-dark: #1e293b;
      --admin-light: #f1f5f9;
    }

    * { box-sizing: border-box; margin: 0; padding: 0; }

    body {
      font-family: "Inter", "Segoe UI", sans-serif;
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      min-height: 100vh;
    }

    .admin-main {
      padding: 32px;
      overflow-y: auto;
    }

    .admin-header {
      background: white;
      padding: 24px;
      border-radius: 16px;
      margin-bottom: 24px;
      box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    }

    .admin-header h1 {
      font-size: 2rem;
      color: var(--admin-dark);
      margin-bottom: 8px;
    }

    .admin-header p {
      color: #64748b;
    }

    .filters-bar {
      background: white;
      padding: 16px;
      border-radius: 12px;
      display: flex;
      gap: 12px;
      margin-bottom: 24px;
      box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
      flex-wrap: wrap;
    }

    .filters-bar input,
    .filters-bar select {
      padding: 10px 12px;
      border: 1px solid #e2e8f0;
      border-radius: 8px;
      font-size: 0.9rem;
    }

    .filters-bar input {
      flex: 1;
      min-width: 200px;
    }

    .filters-bar select {
      min-width: 150px;
    }

    .filters-bar button {
      padding: 10px 20px;
      background: var(--admin-primary);
      color: white;
      border: none;
      border-radius: 8px;
      font-weight: 600;
      cursor: pointer;
      transition: all 0.3s;
    }

    .filters-bar button:hover {
      background: var(--admin-secondary);
    }

    .users-table {
      background: white;
      border-radius: 12px;
      overflow: hidden;
      box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
      overflow-x: auto;
    }

    table {
      width: 100%;
      border-collapse: collapse;
      min-width: 900px;
    }

    thead {
      background: var(--admin-light);
      border-bottom: 2px solid #e2e8f0;
    }

    th {
      padding: 16px;
      text-align: left;
      font-weight: 600;
      color: var(--admin-dark);
      font-size: 0.9rem;
    }

    td {
      padding: 16px;
      border-bottom: 1px solid #e2e8f0;
    }

    tbody tr:hover {
      background: #f8fafc;
      cursor: pointer;
    }

    .user-cell {
      display: flex;
      align-items: center;
      gap: 12px;
    }

    .user-avatar {
      width: 40px;
      height: 40px;
      border-radius: 50%;
      overflow: hidden;
      background: linear-gradient(135deg, #8b5cf6, #ec4899);
      display: flex;
      align-items: center;
      justify-content: center;
      color: white;
      font-weight: 700;
      font-size: 14px;
      flex-shrink: 0;
      position: relative;
    }

    .user-avatar img {
      width: 100%;
      height: 100%;
      object-fit: cover;
      position: absolute;
    }

    .user-avatar span {
      position: relative;
      z-index: 1;
    }

    .user-info {
      display: flex;
      flex-direction: column;
      gap: 2px;
    }

    .user-info strong {
      color: var(--admin-dark);
      font-size: 0.95rem;
    }

    .user-info small {
      color: #64748b;
      font-size: 0.8rem;
    }

    .badge {
      display: inline-block;
      padding: 6px 12px;
      border-radius: 6px;
      font-weight: 600;
      font-size: 0.8rem;
      text-align: center;
      width: fit-content;
    }

    .badge-free {
      background: #f1f5f9;
      color: #475569;
    }

    .badge-premium {
      background: #dcfce7;
      color: #166534;
    }

    .badge-premium-plus {
      background: #fef3c7;
      color: #92400e;
    }

    .badge-active {
      background: #dcfce7;
      color: #166534;
    }

    .badge-banned {
      background: #fee2e2;
      color: #991b1b;
    }

    .action-btn {
      padding: 8px 12px;
      border: none;
      border-radius: 6px;
      cursor: pointer;
      font-weight: 600;
      font-size: 0.85rem;
      transition: all 0.3s;
      background: var(--admin-primary);
      color: white;
    }

    .action-btn:hover {
      transform: translateY(-2px);
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.15);
    }

    .pagination {
      display: flex;
      justify-content: center;
      gap: 8px;
      margin-top: 24px;
    }

    .pagination a {
      padding: 8px 16px;
      background: white;
      color: var(--admin-primary);
      text-decoration: none;
      border-radius: 8px;
      font-weight: 600;
      transition: all 0.3s;
    }

    .pagination a:hover, .pagination a.active {
      background: var(--admin-primary);
      color: white;
    }

    .alert-message {
      position: fixed;
      top: 20px;
      right: -400px;
      padding: 16px 24px;
      border-radius: 12px;
      color: white;
      font-family: 'Segoe UI', sans-serif;
      font-size: 15px;
      z-index: 10000;
      opacity: 0;
      box-shadow: 0 10px 40px rgba(0, 0, 0, 0.2);
      transition: right 0.6s ease, opacity 0.6s ease;
    }

    .alert-message.show {
      right: 20px;
      opacity: 1;
    }

    .alert-message.success {
      background: var(--admin-success);
    }

    .alert-message.error {
      background: var(--admin-danger);
    }

    .alert-message.info {
      background: var(--admin-primary);
    }

    .modal-overlay {
      display: none;
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: rgba(0, 0, 0, 0.5);
      z-index: 2000;
      justify-content: center;
      align-items: center;
      padding: 20px;
      overflow-y: auto;
    }

    .modal-overlay.active {
      display: flex;
    }

    .user-modal {
      background: white;
      border-radius: 16px;
      padding: 32px;
      width: 100%;
      max-width: 500px;
      max-height: 90vh;
      overflow-y: auto;
      box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
      margin: auto;
    }

    .modal-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 24px;
      border-bottom: 1px solid #e2e8f0;
      padding-bottom: 16px;
    }

    .modal-header h2 {
      color: var(--admin-dark);
      margin: 0;
      font-size: 1.5rem;
    }

    .modal-close {
      background: none;
      border: none;
      font-size: 24px;
      cursor: pointer;
      color: #64748b;
    }

    .user-profile-section {
      text-align: center;
      margin-bottom: 24px;
      padding-bottom: 16px;
      border-bottom: 1px solid #e2e8f0;
    }

    .user-avatar-large {
      width: 60px;
      height: 60px;
      border-radius: 50%;
      margin: 0 auto 12px;
      background: linear-gradient(135deg, #8b5cf6, #ec4899);
      display: flex;
      align-items: center;
      justify-content: center;
      color: white;
      font-weight: 700;
      font-size: 24px;
      overflow: hidden;
      position: relative;
    }

    .user-avatar-large img {
      width: 100%;
      height: 100%;
      object-fit: cover;
      position: absolute;
    }

    .user-avatar-large span {
      position: relative;
      z-index: 1;
    }

    .user-profile-section strong {
      display: block;
      color: var(--admin-dark);
      margin-bottom: 4px;
    }

    .user-profile-section .membership-badge {
      display: inline-block;
      margin-top: 8px;
    }

    .modal-field {
      margin-bottom: 20px;
    }

    .modal-field label {
      display: block;
      font-weight: 600;
      color: var(--admin-dark);
      margin-bottom: 8px;
    }

    .modal-field input,
    .modal-field select {
      width: 100%;
      padding: 10px 12px;
      border: 1px solid #e2e8f0;
      border-radius: 8px;
      font-size: 0.9rem;
    }

    .earning-fields {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 12px;
      background: #f8fafc;
      padding: 16px;
      border-radius: 8px;
      margin-bottom: 20px;
    }

    .earning-field {
      display: flex;
      flex-direction: column;
    }

    .earning-field label {
      font-weight: 600;
      color: var(--admin-dark);
      margin-bottom: 6px;
      font-size: 0.9rem;
    }

    .earning-field input {
      padding: 8px 10px;
      border: 1px solid #e2e8f0;
      border-radius: 6px;
      font-size: 0.85rem;
    }

    .modal-actions {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 12px;
      margin-top: 24px;
      padding-top: 24px;
      border-top: 1px solid #e2e8f0;
    }

    .modal-btn {
      padding: 10px 16px;
      border: none;
      border-radius: 8px;
      cursor: pointer;
      font-weight: 600;
      font-size: 0.9rem;
      transition: all 0.3s;
    }

    .modal-btn-primary {
      background: var(--admin-primary);
      color: white;
      grid-column: span 2;
    }

    .modal-btn-primary:hover {
      background: var(--admin-secondary);
    }

    .modal-btn-danger {
      background: #fee2e2;
      color: #991b1b;
    }

    .modal-btn-danger:hover {
      background: #fecaca;
    }

    .modal-btn-warn {
      background: #fef3c7;
      color: #92400e;
    }

    .modal-btn-warn:hover {
      background: #fde68a;
    }

    @media (max-width: 768px) {
      .admin-main {
        padding: 16px;
      }

      .admin-header h1 {
        font-size: 1.5rem;
      }

      .filters-bar {
        flex-direction: column;
      }

      .filters-bar input {
        min-width: auto;
        width: 100%;
      }

      .filters-bar select,
      .filters-bar button {
        width: 100%;
      }

      table {
        min-width: 700px;
        font-size: 0.85rem;
      }

      th, td {
        padding: 12px 8px;
      }

      .user-modal {
        padding: 20px;
      }

      .modal-header h2 {
        font-size: 1.2rem;
      }

      .earning-fields {
        grid-template-columns: 1fr;
      }
    }
  </style>
</head>
<body>

<?php include 'side-bar.php'; ?>
<div class="admin-content">

    <main class="admin-main">
      <div class="admin-header">
        <h1>Manage Users</h1>
        <p>View, edit, ban, or delete user accounts</p>
      </div>

      <form class="filters-bar" method="GET">
        <input type="text" name="search" placeholder="Search users..." value="<?php echo htmlspecialchars($search); ?>" />
        <select name="filter">
          <option value="all" <?php echo $filter === 'all' ? 'selected' : ''; ?>>All Users</option>
          <option value="free" <?php echo $filter === 'free' ? 'selected' : ''; ?>>Free Only</option>
          <option value="premium" <?php echo $filter === 'premium' ? 'selected' : ''; ?>>Premium Only</option>
          <option value="premium_plus" <?php echo $filter === 'premium_plus' ? 'selected' : ''; ?>>Premium Plus Only</option>
          <option value="banned" <?php echo $filter === 'banned' ? 'selected' : ''; ?>>Banned Only</option>
        </select>
        <button type="submit">Filter</button>
      </form>

      <div class="users-table">
        <table>
          <thead>
            <tr>
              <th>User</th>
              <th>Email</th>
              <th>Plan</th>
              <th>Balance</th>
              <th>Status</th>
              <th>How Heard & Country</th>
              <th>Joined</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($users as $user): 
              $is_premium_plus = !empty($user['advertiser_plan']);
              $plan_badge = $is_premium_plus ? 'premium-plus' : $user['membership_type'];
              $plan_display = $is_premium_plus ? 'Premium Plus' : (($user['membership_type'] === 'premium') ? 'Premium' : 'Free');
            ?>
              <tr onclick="openUserModal(<?php echo htmlspecialchars(json_encode($user)); ?>)">
                <td>
                  <div class="user-cell">
                    <div class="user-avatar">
                      <?php if (!empty($user['profile_picture'])): ?>
                        <img src="<?php echo htmlspecialchars($user['profile_picture']); ?>" alt="<?php echo htmlspecialchars($user['username']); ?>" onerror="this.style.display='none'">
                      <?php endif; ?>
                      <span><?php echo strtoupper($user['username'][0] ?? 'U'); ?></span>
                    </div>
                    <div class="user-info">
                      <strong><?php echo htmlspecialchars($user['username']); ?></strong>
                      <small><?php echo htmlspecialchars($user['full_name'] ?? '-'); ?></small>
                    </div>
                  </div>
                </td>
                <td><?php echo htmlspecialchars($user['email']); ?></td>
                <td>
                  <span class="badge badge-<?php echo $plan_badge; ?>">
                    <?php echo $plan_display; ?>
                  </span>
                </td>
                <td>₦<?php echo number_format($user['total_balance'] ?? 0, 2); ?></td>
                <td>
                  <span class="badge badge-<?php echo $user['status'] ?? 'active'; ?>">
                    <?php echo strtoupper($user['status'] ?? 'active'); ?>
                  </span>
                </td>
                <td>
                  <div style="font-size: 0.85rem;">
                    <div style="display: flex; align-items: center; gap: 4px; margin-bottom: 4px;">
                      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path><polyline points="9 22 9 12 15 12 15 22"></polyline></svg>
                      <span><?php echo htmlspecialchars($user['how_heard'] ?? 'Unknown'); ?></span>
                    </div>
                    <div style="display: flex; align-items: center; gap: 4px; color: #64748b;">
                      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path><circle cx="12" cy="10" r="3"></circle></svg>
                      <span><?php echo htmlspecialchars($user['country'] ?? 'N/A'); ?></span>
                    </div>
                  </div>
                </td>
                <td><?php echo date('M d, Y', strtotime($user['created_at'])); ?></td>
                <td>
                  <button type="button" class="action-btn" onclick="event.stopPropagation(); openUserModal(<?php echo htmlspecialchars(json_encode($user)); ?>)">Manage</button>
                </td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>

      <div class="pagination">
        <?php for ($i = 1; $i <= $total_pages; $i++): ?>
          <a href="?page=<?php echo $i; ?>&search=<?php echo urlencode($search); ?>&filter=<?php echo $filter; ?>" 
             class="<?php echo $i === $page ? 'active' : ''; ?>">
            <?php echo $i; ?>
          </a>
        <?php endfor; ?>
      </div>
    </main>
  </div>

  <div class="modal-overlay" id="userModal">
    <div class="user-modal">
      <div class="modal-header">
        <h2>Manage User</h2>
        <button class="modal-close" onclick="closeUserModal()">&times;</button>
      </div>

      <div class="user-profile-section">
        <div class="user-avatar-large">
          <img id="avatarImg" src="" alt="">
          <span id="avatarText">A</span>
        </div>
        <strong id="modalUsername">Username</strong>
        <div style="font-size: 0.9rem; color: #64748b; margin-bottom: 8px;" id="modalEmail">email@example.com</div>
        <span class="badge membership-badge" id="membershipBadge">Free</span>
      </div>

      <!-- BALANCE DISPLAY GRID -->
      <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 12px; margin: 16px 0; padding: 12px; background: #f0f4f8; border-radius: 8px;">
        <div>
          <div style="font-size: 0.85rem; color: #64748b;">Total Balance</div>
          <div style="font-size: 1.3rem; font-weight: bold; color: #1e293b;" id="displayTotalBalance">₦0.00</div>
        </div>
        <div>
          <div style="font-size: 0.85rem; color: #64748b;">Task Earnings</div>
          <div style="font-size: 1.3rem; font-weight: bold; color: #1e293b;" id="displayTaskEarnings">₦0.00</div>
        </div>
        <div>
          <div style="font-size: 0.85rem; color: #64748b;">Referral Earnings</div>
          <div style="font-size: 1.3rem; font-weight: bold; color: #1e293b;" id="displayReferralEarnings">₦0.00</div>
        </div>
        <div>
          <div style="font-size: 0.85rem; color: #64748b;">Game Earnings</div>
          <div style="font-size: 1.3rem; font-weight: bold; color: #1e293b;" id="displayGameEarnings">₦0.00</div>
        </div>
      </div>

      <div class="modal-field">
        <label>Membership Type</label>
        <select id="membershipSelect">
          <option value="free">Free</option>
          <option value="premium">Premium</option>
          <option value="premium_plus">Premium Plus</option>
        </select>
      </div>

      <!-- ADD TO EARNINGS SECTION -->
      <div class="modal-field" style="background: #f0fdf4; border: 1px solid #bbf7d0; padding: 12px; border-radius: 6px;">
        <label style="font-weight: 600; color: #166534;">➕ Add to Earnings</label>
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 10px; margin-top: 10px;">
          <div>
            <label style="font-size: 0.9rem;">Select Earning Type</label>
            <select id="addEarningsTypeSelect">
              <option value="task">Task Earnings</option>
              <option value="referral">Referral Earnings</option>
              <option value="game">Game Earnings</option>
            </select>
          </div>
          <div>
            <label style="font-size: 0.9rem;">Amount to Add</label>
            <input type="number" id="addEarningsAmountInput" placeholder="0.00" step="0.01" min="0">
          </div>
        </div>
        <button class="modal-btn modal-btn-primary" onclick="addEarnings()" style="width: 100%; margin-top: 10px;">Add Earnings</button>
      </div>

      <!-- DEDUCT FROM BALANCE SECTION -->
      <div class="modal-field" style="background: #fef2f2; border: 1px solid #fecaca; padding: 12px; border-radius: 6px;">
        <label style="font-weight: 600; color: #7f1d1d;">➖ Deduct from Balance</label>
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 10px; margin-top: 10px;">
          <div>
            <label style="font-size: 0.9rem;">From Which Earning?</label>
            <select id="subtractBalanceSourceSelect">
              <option value="task">Task Earnings</option>
              <option value="referral">Referral Earnings</option>
              <option value="game">Game Earnings</option>
            </select>
          </div>
          <div>
            <label style="font-size: 0.9rem;">Amount to Deduct</label>
            <input type="number" id="subtractBalanceAmountInput" placeholder="0.00" step="0.01" min="0">
          </div>
        </div>
        <button class="modal-btn modal-btn-danger" onclick="subtractBalance()" style="width: 100%; margin-top: 10px;">Deduct from Balance</button>
      </div>

      <div class="modal-actions">
        <button class="modal-btn modal-btn-warn" onclick="toggleBanStatus()" id="banBtn">Suspend</button>
        <button class="modal-btn modal-btn-danger" onclick="confirmDeleteUser()">Delete</button>
        <button class="modal-btn modal-btn-primary" onclick="saveUserChanges()">Save Changes</button>
      </div>
    </div>
  </div>

  <div id="toastContainer"></div>

  <script>
    let currentUser = null;

    function showToast(message, type = 'info') {
      const container = document.getElementById('toastContainer');
      const toast = document.createElement('div');
      toast.className = `alert-message ${type} show`;
      toast.textContent = message;
      container.appendChild(toast);

      setTimeout(() => {
        toast.classList.remove('show');
        setTimeout(() => toast.remove(), 600);
      }, 3000);
    }

    function openUserModal(user) {
      currentUser = user;
      document.getElementById('userModal').classList.add('active');
      
      const initial = user.username ? user.username.charAt(0).toUpperCase() : 'U';
      const avatarText = document.getElementById('avatarText');
      const avatarImg = document.getElementById('avatarImg');
      
      avatarText.textContent = initial;
      
      if (user.profile_picture && user.profile_picture.trim() !== '') {
        avatarImg.src = user.profile_picture;
        avatarImg.style.display = 'block';
      } else {
        avatarImg.style.display = 'none';
      }
      
      document.getElementById('modalUsername').textContent = user.username;
      document.getElementById('modalEmail').textContent = user.email;
      
      const isPremiumPlus = user.advertiser_plan && user.advertiser_plan.trim() !== '';
      const currentPlan = isPremiumPlus ? 'premium_plus' : user.membership_type;
      document.getElementById('membershipSelect').value = currentPlan;
      document.getElementById('membershipBadge').className = `badge badge-${isPremiumPlus ? 'premium-plus' : user.membership_type} membership-badge`;
      document.getElementById('membershipBadge').textContent = isPremiumPlus ? 'Premium Plus' : (user.membership_type === 'premium' ? 'Premium' : 'Free');
      
      // Display balances in the grid
      document.getElementById('displayTotalBalance').textContent = '₦' + (parseFloat(user.total_balance || 0).toFixed(2));
      document.getElementById('displayTaskEarnings').textContent = '₦' + (parseFloat(user.task_earnings || 0).toFixed(2));
      document.getElementById('displayReferralEarnings').textContent = '₦' + (parseFloat(user.referral_earnings || 0).toFixed(2));
      document.getElementById('displayGameEarnings').textContent = '₦' + (parseFloat(user.game_earnings || 0).toFixed(2));
      
      // Clear input fields
      document.getElementById('addEarningsAmountInput').value = '';
      document.getElementById('subtractBalanceAmountInput').value = '';
      document.getElementById('addEarningsTypeSelect').value = 'task';
      document.getElementById('subtractBalanceSourceSelect').value = 'task';
      
      const banBtn = document.getElementById('banBtn');
      if (user.status === 'banned') {
        banBtn.textContent = 'Unsuspend';
        banBtn.classList.remove('modal-btn-warn');
        banBtn.classList.add('modal-btn-primary');
      } else {
        banBtn.textContent = 'Suspend';
        banBtn.classList.remove('modal-btn-primary');
        banBtn.classList.add('modal-btn-warn');
      }
    }

    function closeUserModal() {
      document.getElementById('userModal').classList.remove('active');
      currentUser = null;
    }

    function refreshBanButtonState() {
      const banBtn = document.getElementById('banBtn');
      if (currentUser.status === 'banned') {
        banBtn.textContent = 'Unsuspend';
        banBtn.classList.remove('modal-btn-warn');
        banBtn.classList.add('modal-btn-primary');
      } else {
        banBtn.textContent = 'Suspend';
        banBtn.classList.remove('modal-btn-primary');
        banBtn.classList.add('modal-btn-warn');
      }
    }

    function toggleBanStatus() {
      if (!currentUser) return;
      const newStatus = currentUser.status === 'banned' ? 'active' : 'banned';
      updateUserField('status', newStatus);
    }

    function confirmDeleteUser() {
      if (!currentUser) return;
      if (confirm('Delete this user permanently? This cannot be undone.')) {
        updateUserField('action', 'delete');
      }
    }

    function saveUserChanges() {
      if (!currentUser) return;
      
      const membership = document.getElementById('membershipSelect').value;
      
      const isPremiumPlus = currentUser.advertiser_plan && currentUser.advertiser_plan.trim() !== '';
      const currentPlan = isPremiumPlus ? 'premium_plus' : currentUser.membership_type;
      
      if (membership !== currentPlan) {
        updateUserField('membership_type', membership);
      } else {
        showToast('No membership changes', 'info');
      }
    }

    function addEarnings() {
      if (!currentUser) return;
      
      const earningType = document.getElementById('addEarningsTypeSelect').value;
      const amount = parseFloat(document.getElementById('addEarningsAmountInput').value) || 0;
      
      if (amount <= 0) {
        showToast('Enter a valid amount', 'info');
        return;
      }
      
      const data = {
        task_earnings: earningType === 'task' ? amount : 0,
        referral_earnings: earningType === 'referral' ? amount : 0,
        game_earnings: earningType === 'game' ? amount : 0
      };
      
      updateUserField('add_earnings', JSON.stringify(data));
    }

    function subtractBalance() {
      if (!currentUser) return;
      
      const amount = parseFloat(document.getElementById('subtractBalanceAmountInput').value) || 0;
      const source = document.getElementById('subtractBalanceSourceSelect').value;
      
      if (amount <= 0) {
        showToast('Enter a valid amount', 'info');
        return;
      }
      
      updateUserField('subtract_balance', JSON.stringify({
        amount: amount,
        source: source
      }));
    }

    function updateUserField(field, value) {
      if (!currentUser) return;
      
      const formData = new FormData();
      formData.append('user_id', currentUser.id);
      formData.append('field', field);
      formData.append('value', value);
      
      fetch('../api/admin-user-manager.php', {
        method: 'POST',
        body: formData
      })
      .then(response => response.json())
      .then(data => {
        if (data.success) {
          // Update currentUser immediately if status was changed
          if (field === 'status') {
            currentUser.status = value;
            refreshBanButtonState();
          }
          
          showToast(data.message || 'User updated successfully', 'success');
          setTimeout(() => {
            closeUserModal();
            location.reload();
          }, 1500);
        } else {
          showToast(data.message || 'Error updating user', 'error');
          console.error('API Error:', data);
        }
      })
      .catch(error => {
        console.error('Error:', error);
        showToast('Error updating user: ' + error.message, 'error');
      });
    }

    document.getElementById('userModal').addEventListener('click', function(e) {
      if (e.target === this) {
        closeUserModal();
      }
    });
  </script>
</body>
</html>
