<?php
session_start();
require_once '../config/database.php';


if (!isset($_SESSION['user_id'])) {
    header('Location: ../login.php');
    exit();
}

$user_id = $_SESSION['user_id'];
$stmt = $conn->prepare("SELECT is_admin FROM users WHERE id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result()->fetch_assoc();

if (!$result || $result['is_admin'] != 1) {
    header('Location: ../dashboard.php');
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $bid_id = intval($_POST['bid_id']);
    $action = $_POST['action'];
    
    if ($action === 'approve') {
        $stmt = $conn->prepare("UPDATE job_bids SET status = 'approved', reviewed_at = NOW() WHERE id = ?");
        $stmt->bind_param("i", $bid_id);
        $stmt->execute();
        $success_message = "Bid approved successfully";
    } elseif ($action === 'reject') {
        $stmt = $conn->prepare("UPDATE job_bids SET status = 'rejected', reviewed_at = NOW() WHERE id = ?");
        $stmt->bind_param("i", $bid_id);
        $stmt->execute();
        $success_message = "Bid rejected";
    }
}

$job_filter = isset($_GET['job_id']) ? intval($_GET['job_id']) : 0;
$where_clause = $job_filter > 0 ? "WHERE jb.job_id = $job_filter" : "";

$bids = $conn->query("
    SELECT jb.*, j.title as job_title, u.username, u.email, u.full_name, v.phone_number
    FROM job_bids jb
    JOIN jobs j ON jb.job_id = j.id
    JOIN users u ON jb.user_id = u.id
    LEFT JOIN user_verification v ON u.id = v.user_id
    $where_clause
    ORDER BY jb.created_at DESC
")->fetch_all(MYSQLI_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Job Bids - FlowEarner Admin</title>
  <style>
    :root {
      --admin-primary: #6366f1;
      --admin-secondary: #8b5cf6;
      --admin-success: #10b981;
      --admin-warning: #f59e0b;
      --admin-danger: #ef4444;
      --admin-dark: #1e293b;
      --admin-light: #f1f5f9;
    }

    * { box-sizing: border-box; margin: 0; padding: 0; }

    body {
      font-family: "Inter", "Segoe UI", sans-serif;
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      min-height: 100vh;
    }

    .admin-container {
      display: grid;
      grid-template-columns: 260px 1fr;
      min-height: 100vh;
    }

    
    .admin-main {
      
      padding: 32px;
      overflow-y: auto;
    }

    .admin-header {
      background: white;
      padding: 24px;
      border-radius: 16px;
      margin-bottom: 32px;
      box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    }

    .admin-header h1 {
      font-size: 2rem;
      color: var(--admin-dark);
      margin-bottom: 8px;
    }

    .bids-grid {
      display: grid;
      gap: 24px;
    }

    .bid-card {
      background: white;
      border-radius: 16px;
      padding: 24px;
      box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    }

    .bid-header {
      display: flex;
      justify-content: space-between;
      align-items: start;
      margin-bottom: 16px;
      padding-bottom: 16px;
      border-bottom: 2px solid #e2e8f0;
    }

    .bid-info {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
      gap: 16px;
      margin-bottom: 16px;
    }

    .info-item {
      display: flex;
      flex-direction: column;
      gap: 4px;
    }

    .info-label {
      font-size: 0.75rem;
      text-transform: uppercase;
      color: #64748b;
      font-weight: 600;
    }

    .info-value {
      font-size: 0.95rem;
      color: var(--admin-dark);
      font-weight: 500;
    }

    .badge {
      display: inline-block;
      padding: 4px 12px;
      border-radius: 12px;
      font-size: 0.75rem;
      font-weight: 600;
      text-transform: uppercase;
    }

    .badge-pending {
      background: #fef3c7;
      color: #92400e;
    }

    .badge-approved {
      background: #d1fae5;
      color: #065f46;
    }

    .badge-rejected {
      background: #fee2e2;
      color: #991b1b;
    }

    .action-buttons {
      display: flex;
      gap: 12px;
      margin-top: 16px;
    }

    .btn {
      padding: 10px 20px;
      border: none;
      border-radius: 8px;
      font-weight: 600;
      cursor: pointer;
      transition: all 0.3s;
    }

    .btn-approve {
      background: var(--admin-success);
      color: white;
    }

    .btn-reject {
      background: var(--admin-danger);
      color: white;
    }

    .btn:hover {
      transform: translateY(-2px);
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
    }

    .alert {
      padding: 16px;
      border-radius: 12px;
      margin-bottom: 24px;
      font-weight: 600;
    }

    .alert-success {
      background: #d1fae5;
      color: #065f46;
    }

    @media (max-width: 960px) {
      .admin-container {
        grid-template-columns: 1fr;
      }

      .admin-main {
        margin-left: 0;
      }
    }
  </style>
</head>
<body>
   <?php include 'side-bar.php'; ?>
<div class="admin-content">

    <main class="admin-main">
      <div class="admin-header">
        <h1>Job Bids</h1>
        <p style="color: #64748b;">Review and approve job applications from premium members</p>
      </div>

      <?php if (isset($success_message)): ?>
        <div class="alert alert-success"><?php echo $success_message; ?></div>
      <?php endif; ?>

      <div class="bids-grid">
        <?php if (empty($bids)): ?>
          <div class="bid-card">
            <p style="text-align: center; color: #64748b;">No bids found</p>
          </div>
        <?php else: ?>
          <?php foreach ($bids as $bid): ?>
            <div class="bid-card">
              <div class="bid-header">
                <div>
                  <h3 style="margin: 0; color: var(--admin-dark);"><?php echo htmlspecialchars($bid['full_name']); ?></h3>
                  <p style="color: #64748b; margin: 4px 0 0;">Applied for: <strong><?php echo htmlspecialchars($bid['job_title']); ?></strong></p>
                </div>
                <span class="badge badge-<?php echo $bid['status']; ?>">
                  <?php echo strtoupper($bid['status']); ?>
                </span>
              </div>

              <div class="bid-info">
                <div class="info-item">
                  <span class="info-label">Username</span>
                  <span class="info-value">@<?php echo htmlspecialchars($bid['username']); ?></span>
                </div>
                <div class="info-item">
                  <span class="info-label">Email</span>
                  <span class="info-value"><?php echo htmlspecialchars($bid['email']); ?></span>
                </div>
                <div class="info-item">
                  <span class="info-label">Phone</span>
                  <span class="info-value"><?php echo htmlspecialchars($bid['phone_number'] ?? 'N/A'); ?></span>
                </div>
                <div class="info-item">
                  <span class="info-label">Proposed Rate</span>
                  <span class="info-value">₦<?php echo number_format($bid['proposed_rate'], 2); ?></span>
                </div>
                <div class="info-item">
                  <span class="info-label">Applied</span>
                  <span class="info-value"><?php echo date('M d, Y', strtotime($bid['created_at'])); ?></span>
                </div>
              </div>

              <div class="info-item">
                <span class="info-label">Cover Letter</span>
                <p style="color: var(--admin-dark); line-height: 1.6; margin-top: 8px;">
                  <?php echo nl2br(htmlspecialchars($bid['cover_letter'])); ?>
                </p>
              </div>

              <?php if ($bid['status'] === 'pending'): ?>
                <div class="action-buttons">
                  <form method="POST" style="display: inline;">
                    <input type="hidden" name="bid_id" value="<?php echo $bid['id']; ?>" />
                    <button type="submit" name="action" value="approve" class="btn btn-approve">✓ Approve</button>
                    <button type="submit" name="action" value="reject" class="btn btn-reject">✗ Reject</button>
                  </form>
                </div>
              <?php endif; ?>
            </div>
          <?php endforeach; ?>
        <?php endif; ?>
      </div>
    </main>
  </div>
</body>
</html>
