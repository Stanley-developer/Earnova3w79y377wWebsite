<?php
// Enable error logging to browser console for development debugging
ini_set('display_errors', 1);
ini_set('log_errors', 1);
error_reporting(E_ALL);

// Set up error handler to log to browser console
set_error_handler(function($errno, $errstr, $errfile, $errline) {
    echo "<script>console.error('PHP Error [$errno]: $errstr in $errfile:$errline');</script>";
    return false;
});

require_once '../config/database.php';
require_once '../includes/session.php';

// Require authentication
requireLogin();
checkSessionTimeout();

// Get current user
$user = getCurrentUser();
$user_id = $user['id'];

// Create database connection (THIS WAS MISSING)
$pdo = getDBConnection();

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: ../login.php');
    exit();
}

$user_id = $_SESSION['user_id'];

// Check if user is admin
$stmt = $pdo->prepare("SELECT is_admin FROM users WHERE id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch();

if (!$user || !$user['is_admin']) {
    header('Location: ../dashboard.php');
    exit();
}

$message = '';
$messageType = '';

// Handle delete, edit, and toggle actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    if ($action === 'delete') {
        try {
            $track_id = $_POST['track_id'] ?? '';
            if ($track_id) {
                $stmt = $pdo->prepare("DELETE FROM stream_tracks WHERE id = ?");
                $stmt->execute([$track_id]);
                $message = 'Track deleted successfully!';
                $messageType = 'success';
            }
        } catch (Exception $e) {
            $message = 'Failed to delete track: ' . htmlspecialchars($e->getMessage());
            $messageType = 'error';
        }
    } elseif ($action === 'toggle_status') {
        try {
            $track_id = $_POST['track_id'] ?? '';
            if ($track_id) {
                $stmt = $pdo->prepare("SELECT is_active FROM stream_tracks WHERE id = ?");
                $stmt->execute([$track_id]);
                $track = $stmt->fetch();
                
                if ($track) {
                    $new_status = $track['is_active'] ? 0 : 1;
                    $stmt = $pdo->prepare("UPDATE stream_tracks SET is_active = ? WHERE id = ?");
                    $stmt->execute([$new_status, $track_id]);
                    $status_text = $new_status ? 'activated' : 'paused';
                    $message = 'Track ' . $status_text . ' successfully!';
                    $messageType = 'success';
                }
            }
        } catch (Exception $e) {
            $message = 'Failed to update track status: ' . htmlspecialchars($e->getMessage());
            $messageType = 'error';
        }
    } elseif ($action === 'edit') {
        try {
            $track_id = $_POST['track_id'] ?? '';
            $title = trim($_POST['title'] ?? '');
            $artist = trim($_POST['artist'] ?? '');
            $album = trim($_POST['album'] ?? '');
            $duration = intval($_POST['duration'] ?? 0);
            $free_reward = floatval($_POST['free_reward'] ?? 0);
            $premium_reward = floatval($_POST['premium_reward'] ?? 0);
            $track_link = trim($_POST['track_link'] ?? '');
            
            if (!$track_id || !$title || !$artist || $duration <= 0) {
                $message = 'Please fill in all required fields.';
                $messageType = 'error';
            } elseif ($free_reward <= 0 || $premium_reward <= 0) {
                $message = 'Rewards must be greater than 0.';
                $messageType = 'error';
            } else {
                $stmt = $pdo->prepare("UPDATE stream_tracks SET title = ?, artist = ?, album = ?, duration = ?, free_reward = ?, premium_reward = ?, track_link = ? WHERE id = ?");
                $stmt->execute([$title, $artist, $album, $duration, $free_reward, $premium_reward, $track_link, $track_id]);
                $message = 'Track updated successfully!';
                $messageType = 'success';
            }
        } catch (Exception $e) {
            $message = 'Failed to update track: ' . htmlspecialchars($e->getMessage());
            $messageType = 'error';
        }
    }
}

// Handle track upload
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'upload_track') {
    try {
        $pdo = getDBConnection();
        
        $title = trim($_POST['title'] ?? '');
        $artist = trim($_POST['artist'] ?? '');
        $album = trim($_POST['album'] ?? '');
        $duration = intval($_POST['duration'] ?? 0);
        $free_reward = floatval($_POST['free_reward'] ?? 0);
        $premium_reward = floatval($_POST['premium_reward'] ?? 0);
        $track_link = trim($_POST['track_link'] ?? '');
        
        // Validate input
        if (empty($title) || empty($artist) || $duration <= 0) {
            $message = 'Please fill in all required fields';
            $messageType = 'error';
        } else {
            // Handle file uploads
            $audio_file = '';
            $cover_image = '';
            
            // Upload audio file
            if (isset($_FILES['audio_file'])) {
                if ($_FILES['audio_file']['error'] !== UPLOAD_ERR_OK) {
                    $upload_errors = [
                        UPLOAD_ERR_INI_SIZE => 'File exceeds maximum upload size',
                        UPLOAD_ERR_FORM_SIZE => 'File exceeds form maximum size',
                        UPLOAD_ERR_PARTIAL => 'File was only partially uploaded',
                        UPLOAD_ERR_NO_FILE => 'No file was uploaded',
                        UPLOAD_ERR_NO_TMP_DIR => 'Missing temporary folder',
                        UPLOAD_ERR_CANT_WRITE => 'Failed to write file to disk',
                        UPLOAD_ERR_EXTENSION => 'File upload blocked by extension'
                    ];
                    $message = $upload_errors[$_FILES['audio_file']['error']] ?? 'File upload failed';
                    $messageType = 'error';
                } else {
                    $audio_tmp = $_FILES['audio_file']['tmp_name'];
                    $audio_name = basename($_FILES['audio_file']['name']);
                    $audio_ext = strtolower(pathinfo($audio_name, PATHINFO_EXTENSION));
                    
                    // Validate audio file type
                    $allowed_audio = ['mp3', 'wav', 'ogg', 'm4a', 'mp4'];
                    if (!in_array($audio_ext, $allowed_audio)) {
                        $message = 'Invalid audio file type. Allowed: mp3, wav, ogg, m4a, mp4';
                        $messageType = 'error';
                    } else {
                        // Generate unique filename
                        $audio_filename = 'track_' . time() . '_' . uniqid() . '.' . $audio_ext;
                        $audio_path = '../uploads/stream_tracks/' . $audio_filename;
                        
                        // Create directory if it doesn't exist
                        if (!is_dir('../uploads/stream_tracks')) {
                            mkdir('../uploads/stream_tracks', 0755, true);
                        }
                        
                        if (move_uploaded_file($audio_tmp, $audio_path)) {
                            $audio_file = 'uploads/stream_tracks/' . $audio_filename;
                        } else {
                            $message = 'Failed to upload audio file';
                            $messageType = 'error';
                        }
                    }
                }
            } else {
                $message = 'Please select an audio file';
                $messageType = 'error';
            }
            
            // Upload cover image (optional)
            if (isset($_FILES['cover_image']) && $_FILES['cover_image']['error'] === UPLOAD_ERR_OK) {
                $cover_tmp = $_FILES['cover_image']['tmp_name'];
                $cover_name = basename($_FILES['cover_image']['name']);
                $cover_ext = strtolower(pathinfo($cover_name, PATHINFO_EXTENSION));
                
                // Validate image file type
                $allowed_images = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
                if (in_array($cover_ext, $allowed_images)) {
                    // Generate unique filename
                    $cover_filename = 'cover_' . time() . '_' . uniqid() . '.' . $cover_ext;
                    $cover_path = '../uploads/stream_covers/' . $cover_filename;
                    
                    // Create directory if it doesn't exist
                    if (!is_dir('../uploads/stream_covers')) {
                        mkdir('../uploads/stream_covers', 0755, true);
                    }
                    
                    if (move_uploaded_file($cover_tmp, $cover_path)) {
                        $cover_image = 'uploads/stream_covers/' . $cover_filename;
                    }
                }
            }
            
            // Insert track into database
            if (empty($message) && !empty($audio_file)) {
                $track_id = 'track_' . time() . '_' . uniqid();
                
                $stmt = $pdo->prepare("INSERT INTO stream_tracks (track_id, title, artist, album, duration, cover_image, audio_file, track_link, free_reward, premium_reward, uploaded_by) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
                $stmt->execute([
                    $track_id,
                    $title,
                    $artist,
                    $album,
                    $duration,
                    $cover_image,
                    $audio_file,
                    $track_link,
                    $free_reward,
                    $premium_reward,
                    $user_id
                ]);
                
                $message = 'Track uploaded successfully!';
                $messageType = 'success';
            }
        }
    } catch (PDOException $e) {
        error_log("Track Upload Error: " . $e->getMessage());
        $message = 'An error occurred while uploading the track';
        $messageType = 'error';
    }
}

// Handle JSON request for track data
if (isset($_GET['get_track_json'])) {
    $track_id = intval($_GET['get_track_json']);
    try {
        $stmt = $pdo->prepare("SELECT id, title, artist, album, duration, free_reward, premium_reward, track_link FROM stream_tracks WHERE id = ?");
        $stmt->execute([$track_id]);
        $track = $stmt->fetch();
        
        header('Content-Type: application/json');
        if ($track) {
            echo json_encode(['success' => true, 'track' => $track]);
        } else {
            echo json_encode(['success' => false, 'message' => 'Track not found']);
        }
        exit();
    } catch (Exception $e) {
        header('Content-Type: application/json');
        echo json_encode(['success' => false, 'message' => $e->getMessage()]);
        exit();
    }
}

// Get all tracks
try {
    $pdo = getDBConnection();
    $stmt = $pdo->prepare("SELECT * FROM stream_tracks ORDER BY upload_date DESC");
    $stmt->execute();
    $tracks = $stmt->fetchAll();
} catch (PDOException $e) {
    $tracks = [];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Upload Track - Admin</title>
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; }
        
        body {
            font-family: "Titillium Web", "Segoe UI", sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: #f5f9ff;
            min-height: 100vh;
        }
        
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 2rem;
        }
        
        h1 {
            font-size: 2.5rem;
            margin-bottom: 2rem;
            background: linear-gradient(135deg, #8b5cf6, #ec4899);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }
        
        .upload-form {
            background: white;
            border: none;
            border-radius: 16px;
            padding: 32px;
            margin-bottom: 3rem;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        
        .upload-form h2 {
            color: #1e293b;
            margin-bottom: 24px;
        }
        
        .form-group {
            margin-bottom: 24px;
        }
        
        label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: #1e293b;
        }
        
        input[type="text"],
        input[type="number"],
        input[type="file"],
        input[type="url"],
        select {
            width: 100%;
            padding: 12px 16px;
            border-radius: 8px;
            border: 1px solid #e2e8f0;
            background: white;
            color: #1e293b;
            font-size: 1rem;
            transition: border-color 0.3s;
        }
        
        input[type="text"]:focus,
        input[type="number"]:focus,
        input[type="file"]:focus,
        input[type="url"]:focus,
        select:focus {
            outline: none;
            border-color: #6366f1;
        }
        
        input[type="file"] {
            padding: 0.5rem;
        }
        
        select {
            cursor: pointer;
        }
        
        .checkbox-group {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 12px;
            background: rgba(6, 16, 48, 0.5);
            border-radius: 12px;
            border: 1px solid rgba(86, 139, 241, 0.2);
        }
        
        .checkbox-group input[type="checkbox"] {
            width: 20px;
            height: 20px;
            cursor: pointer;
        }
        
        .checkbox-group label {
            margin: 0;
            cursor: pointer;
        }
        
        .btn {
            padding: 0.875rem 2rem;
            border-radius: 16px;
            border: none;
            font-weight: 600;
            font-size: 1rem;
            cursor: pointer;
            transition: all 0.3s ease;
        }
        
        .btn-primary {
            background: linear-gradient(135deg, #8b5cf6, #ec4899);
            color: #fff;
        }
        
        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 30px rgba(139, 92, 246, 0.4);
        }
        
        .alert {
            padding: 16px 20px;
            border-radius: 8px;
            margin-bottom: 24px;
            font-size: 0.95rem;
        }
        
        .alert-success {
            background: #d1fae5;
            border: 1px solid #6ee7b7;
            color: #047857;
        }
        
        .alert-error {
            background: #fee2e2;
            border: 1px solid #fca5a5;
            color: #dc2626;
        }
        
        .tracks-list {
            background: white;
            border: none;
            border-radius: 16px;
            padding: 32px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        
        .tracks-list h2 {
            color: #1e293b;
            margin-bottom: 24px;
        }
        
        .track-item {
            background: #f8fafc;
            border: 1px solid #e2e8f0;
            border-radius: 8px;
            padding: 16px;
            margin-bottom: 16px;
            display: grid;
            grid-template-columns: 60px 1fr auto;
            gap: 16px;
            align-items: center;
        }
        
        .track-cover {
            width: 60px;
            height: 60px;
            border-radius: 12px;
            background: linear-gradient(135deg, #8b5cf6, #ec4899);
        }
        
        .track-cover img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            border-radius: 12px;
        }
        
        .track-info h3 {
            font-size: 1.1rem;
            margin-bottom: 4px;
            color: #1e293b;
        }
        
        .track-info p {
            font-size: 0.9rem;
            color: #64748b;
        }
        
        .track-stats {
            text-align: right;
            font-size: 0.9rem;
            color: #64748b;
        }
        
        /* Added admin sidebar offset */
        .admin-content {
            margin-left: 260px;
            padding: 20px;
            transition: margin-left 0.3s ease;
        }
        
        @media (max-width: 1024px) {
            .track-item {
                grid-template-columns: 55px 1fr 65px;
                gap: 12px;
                padding: 14px;
            }
            
            .track-cover {
                width: 55px;
                height: 55px;
            }
            
            .track-stats {
                font-size: 0.85rem;
            }
        }
        
        @media (max-width: 768px) {
            .admin-content {
                margin-left: 0;
                padding: 12px;
            }
            
            .container {
                max-width: 100%;
                padding: 1rem 0.5rem;
                margin: 0;
            }
            
            h1 {
                font-size: 1.6rem;
                margin-bottom: 1rem;
            }
            
            .upload-form {
                padding: 16px;
                margin-bottom: 1.5rem;
                border-radius: 12px;
                box-shadow: 0 2px 4px rgba(0, 0, 0, 0.08);
            }
            
            .upload-form h2 {
                font-size: 1.1rem;
                margin-bottom: 12px;
            }
            
            .form-group {
                margin-bottom: 12px;
            }
            
            label {
                font-size: 0.9rem;
                margin-bottom: 4px;
            }
            
            input[type="text"],
            input[type="number"],
            input[type="file"],
            input[type="url"],
            select {
                padding: 10px 12px;
                font-size: 16px;
                border-radius: 6px;
            }
            
            input[type="file"] {
                padding: 8px 0;
            }
            
            .checkbox-group {
                padding: 10px;
                gap: 8px;
                font-size: 0.9rem;
                flex-wrap: wrap;
            }
            
            .checkbox-group input[type="checkbox"] {
                width: 18px;
                height: 18px;
            }
            
            .btn {
                padding: 0.7rem 1.5rem;
                font-size: 0.9rem;
                width: 100%;
                border-radius: 12px;
            }
            
            .alert {
                font-size: 0.9rem;
                padding: 12px 16px;
                margin-bottom: 12px;
            }
            
            .tracks-list {
                padding: 16px;
                margin-top: 1rem;
                border-radius: 12px;
                overflow-x: auto;
                -webkit-overflow-scrolling: touch;
                box-shadow: 0 2px 4px rgba(0, 0, 0, 0.08);
            }
            
            .tracks-list h2 {
                font-size: 1.1rem;
                margin-bottom: 12px;
                margin-right: 16px;
            }
            
            .track-item {
                grid-template-columns: 48px 1fr 60px;
                gap: 10px;
                padding: 12px;
                margin-bottom: 10px;
                border-radius: 6px;
                min-width: fit-content;
                flex-shrink: 0;
            }
            
            .track-cover {
                width: 48px;
                height: 48px;
                border-radius: 6px;
                flex-shrink: 0;
            }
            
            .track-info h3 {
                font-size: 0.95rem;
                margin-bottom: 2px;
            }
            
            .track-info p {
                font-size: 0.8rem;
                line-height: 1.2;
                overflow: hidden;
                text-overflow: ellipsis;
                display: -webkit-box;
                -webkit-line-clamp: 1;
            }
            
            .track-stats {
                font-size: 0.75rem;
                text-align: center;
                word-break: break-word;
                min-width: 60px;
                flex-shrink: 0;
            }
        }
        
        @media (max-width: 480px) {
            .admin-content {
                padding: 8px;
            }
            
            .container {
                padding: 0.5rem 0.25rem;
            }
            
            h1 {
                font-size: 1.3rem;
                margin-bottom: 0.75rem;
            }
            
            .upload-form {
                padding: 12px;
                margin-bottom: 1rem;
            }
            
            .upload-form h2 {
                font-size: 1rem;
                margin-bottom: 10px;
            }
            
            .form-group {
                margin-bottom: 10px;
            }
            
            label {
                font-size: 0.85rem;
            }
            
            input[type="text"],
            input[type="number"],
            input[type="file"],
            input[type="url"],
            select {
                padding: 9px 10px;
                font-size: 16px;
            }
            
            .btn {
                font-size: 0.85rem;
                padding: 0.6rem 1rem;
            }
            
            .tracks-list {
                padding: 12px;
                overflow-x: auto;
                -webkit-overflow-scrolling: touch;
            }
            
            .tracks-list h2 {
                font-size: 1rem;
                margin-bottom: 10px;
            }
            
            .track-item {
                grid-template-columns: 40px 1fr 50px;
                gap: 8px;
                padding: 10px;
                margin-bottom: 8px;
            }
            
            .track-cover {
                width: 40px;
                height: 40px;
            }
            
            .track-info h3 {
                font-size: 0.9rem;
            }
            
            .track-info p {
                font-size: 0.75rem;
            }
            
            .track-stats {
                min-width: 50px;
                font-size: 0.7rem;
            }
        }
    </style>
</head>
<body>
    <!-- Added sidebar include -->
    <?php include 'side-bar.php'; ?>
    
    <div class="admin-content">
        <div class="container">
            <h1>🎵 Upload Track</h1>
            
            <?php if ($message): ?>
                <div class="alert alert-<?php echo $messageType; ?>">
                    <?php echo htmlspecialchars($message); ?>
                </div>
            <?php endif; ?>
            
            <div class="upload-form">
                <h2 style="margin-bottom: 1.5rem;">Upload New Track</h2>
                <form method="POST" enctype="multipart/form-data">
                    <input type="hidden" name="action" value="upload_track">
                    
                    <div class="form-group">
                        <label for="title">Track Title *</label>
                        <input type="text" id="title" name="title" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="artist">Artist Name *</label>
                        <input type="text" id="artist" name="artist" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="album">Album (Optional)</label>
                        <input type="text" id="album" name="album">
                    </div>
                    
                    <div class="form-group">
                        <label for="duration">Duration (seconds) *</label>
                        <input type="number" id="duration" name="duration" required>
                        <small style="color: rgba(205, 219, 255, 0.6);">Example: 180 for 3 minutes</small>
                    </div>
                    
                    <div class="form-group">
                        <label for="free_reward">Free User Reward (₦) *</label>
                        <input type="number" id="free_reward" name="free_reward" step="0.01" value="150" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="premium_reward">Premium User Reward (₦) *</label>
                        <input type="number" id="premium_reward" name="premium_reward" step="0.01" value="700" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="audio_file">Audio File * (mp3, wav, ogg, m4a, mp4)</label>
                        <input type="file" id="audio_file" name="audio_file" accept=".mp3,.wav,.ogg,.m4a,.mp4" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="cover_image">Cover Image (Optional)</label>
                        <input type="file" id="cover_image" name="cover_image" accept="image/*">
                    </div>
                    
                    <div class="form-group">
                        <label for="track_link">Ad Redirect Link (Optional)</label>
                        <input type="url" id="track_link" name="track_link" placeholder="https://example.com/ad-target">
                        <small style="color: rgba(205, 219, 255, 0.6);">External link users will be redirected to after listening to the audio ad</small>
                    </div>
                    
                    <button type="submit" class="btn btn-primary">Upload Track</button>
                </form>
            </div>
            
            <div class="tracks-list">
                <h2 style="margin-bottom: 1.5rem;">Uploaded Tracks (<?php echo count($tracks); ?>)</h2>
                <?php if (empty($tracks)): ?>
                    <p style="text-align: center; padding: 2rem; color: rgba(205, 219, 255, 0.6);">
                        No tracks uploaded yet.
                    </p>
                <?php else: ?>
                    <?php foreach ($tracks as $track): ?>
                        <div class="track-item" style="display: grid; grid-template-columns: 60px 1fr auto; gap: 16px; align-items: center;">
                            <div class="track-cover">
                                <?php if ($track['cover_image']): ?>
                                    <img src="../<?php echo htmlspecialchars($track['cover_image']); ?>" alt="Cover">
                                <?php endif; ?>
                            </div>
                            <div class="track-info">
                                <h3><?php echo htmlspecialchars($track['title']); ?></h3>
                                <p><?php echo htmlspecialchars($track['artist']); ?></p>
                                <small style="color: #64748b;">
                                    <span style="margin-right: 12px;"> <?php echo gmdate("i:s", $track['duration']); ?></span>
                                    <span style="margin-right: 12px;">₦<?php echo number_format($track['free_reward'], 2); ?> free</span>
                                    <span style="margin-right: 12px;">₦<?php echo number_format($track['premium_reward'], 2); ?> premium</span>
                                    <span style="margin-right: 12px;"> <?php echo $track['play_count']; ?> plays</span>
                                    <span><?php echo date('M j, Y', strtotime($track['upload_date'])); ?></span>
                                    <span style="background: <?php echo ($track['is_active'] ?? 1) ? '#d1fae5' : '#fee2e2'; ?>; color: <?php echo ($track['is_active'] ?? 1) ? '#047857' : '#dc2626'; ?>; padding: 2px 6px; border-radius: 4px; font-size: 0.75rem; margin-left: 8px;"><?php echo ($track['is_active'] ?? 1) ? 'Active' : 'Paused'; ?></span>
                                </small>
                            </div>
                            <div style="display: flex; gap: 8px; flex-direction: column; align-items: stretch;">
                                <button onclick="editTrack(<?php echo $track['id']; ?>)" style="padding: 6px 12px; background: #3b82f6; color: white; border: none; border-radius: 6px; cursor: pointer; font-size: 0.85rem; font-weight: 600;">Edit</button>
                                <form method="POST" style="display: inline;">
                                    <input type="hidden" name="action" value="toggle_status">
                                    <input type="hidden" name="track_id" value="<?php echo $track['id']; ?>">
                                    <button type="submit" style="padding: 6px 12px; background: <?php echo ($track['is_active'] ?? 1) ? '#f97316' : '#10b981'; ?>; color: white; border: none; border-radius: 6px; cursor: pointer; font-size: 0.85rem; font-weight: 600;">
                                        <?php echo ($track['is_active'] ?? 1) ? 'Pause' : 'Activate'; ?>
                                    </button>
                                </form>
                                <button onclick="deleteTrack(<?php echo $track['id']; ?>, '<?php echo htmlspecialchars($track['title'], ENT_QUOTES); ?>')" style="padding: 6px 12px; background: #ef4444; color: white; border: none; border-radius: 6px; cursor: pointer; font-size: 0.85rem; font-weight: 600;">Delete</button>
                            </div>
                        </div>
                    <?php endforeach; ?>
                    
                    <!-- Edit Track Modal -->
                    <div id="editModal" style="display: none; position: fixed; top: 0; left: 0; right: 0; bottom: 0; background: rgba(0,0,0,0.7); z-index: 1000; align-items: center; justify-content: center;">
                        <div style="background: white; border-radius: 16px; padding: 32px; max-width: 600px; width: 90%; max-height: 80vh; overflow-y: auto;">
                            <h2 style="color: #1e293b; margin-bottom: 24px;">Edit Track</h2>
                            <form method="POST">
                                <input type="hidden" name="action" value="edit">
                                <input type="hidden" name="track_id" id="editTrackId">
                                
                                <div class="form-group">
                                    <label for="editTitle">Track Title *</label>
                                    <input type="text" id="editTitle" name="title" required>
                                </div>
                                
                                <div class="form-group">
                                    <label for="editArtist">Artist Name *</label>
                                    <input type="text" id="editArtist" name="artist" required>
                                </div>
                                
                                <div class="form-group">
                                    <label for="editAlbum">Album</label>
                                    <input type="text" id="editAlbum" name="album">
                                </div>
                                
                                <div class="form-group">
                                    <label for="editDuration">Duration (seconds) *</label>
                                    <input type="number" id="editDuration" name="duration" required>
                                </div>
                                
                                <div class="form-group">
                                    <label for="editFreeReward">Free User Reward (₦) *</label>
                                    <input type="number" id="editFreeReward" name="free_reward" step="0.01" required>
                                </div>
                                
                                <div class="form-group">
                                    <label for="editPremiumReward">Premium User Reward (₦) *</label>
                                    <input type="number" id="editPremiumReward" name="premium_reward" step="0.01" required>
                                </div>
                                
                                <div class="form-group">
                                    <label for="editTrackLink">Ad Redirect Link (Optional)</label>
                                    <input type="url" id="editTrackLink" name="track_link">
                                </div>
                                
                                <div style="display: flex; gap: 12px; margin-top: 24px;">
                                    <button type="button" onclick="closeEditModal()" style="flex: 1; padding: 10px; background: #e2e8f0; color: #1e293b; border: none; border-radius: 8px; cursor: pointer; font-weight: 600;">Cancel</button>
                                    <button type="submit" style="flex: 1; padding: 10px; background: linear-gradient(135deg, #8b5cf6, #ec4899); color: white; border: none; border-radius: 8px; cursor: pointer; font-weight: 600;">Save Changes</button>
                                </div>
                            </form>
                        </div>
                    </div>
                    
                    <!-- Delete Confirmation Modal -->
                    <div id="deleteModal" style="display: none; position: fixed; top: 0; left: 0; right: 0; bottom: 0; background: rgba(0,0,0,0.7); z-index: 1000; align-items: center; justify-content: center;">
                        <div style="background: white; border-radius: 16px; padding: 32px; max-width: 400px; width: 90%;">
                            <h2 style="color: #1e293b; margin-bottom: 16px;">Delete Track?</h2>
                            <p style="color: #64748b; margin-bottom: 24px;">Are you sure you want to delete "<span id="deleteTrackTitle"></span>"? This action cannot be undone.</p>
                            
                            <div style="display: flex; gap: 12px;">
                                <button type="button" onclick="closeDeleteModal()" style="flex: 1; padding: 10px; background: #e2e8f0; color: #1e293b; border: none; border-radius: 8px; cursor: pointer; font-weight: 600;">Cancel</button>
                                <form method="POST" style="flex: 1;">
                                    <input type="hidden" name="action" value="delete">
                                    <input type="hidden" name="track_id" id="deleteTrackId">
                                    <button type="submit" style="width: 100%; padding: 10px; background: #ef4444; color: white; border: none; border-radius: 8px; cursor: pointer; font-weight: 600;">Delete Track</button>
                                </form>
                            </div>
                        </div>
                    </div>
                    
                    <script>
                        function editTrack(trackId) {
                            fetch('?get_track_json=' + trackId)
                                .then(response => response.json())
                                .then(data => {
                                    if (data.success) {
                                        const track = data.track;
                                        document.getElementById('editTrackId').value = track.id;
                                        document.getElementById('editTitle').value = track.title;
                                        document.getElementById('editArtist').value = track.artist;
                                        document.getElementById('editAlbum').value = track.album;
                                        document.getElementById('editDuration').value = track.duration;
                                        document.getElementById('editFreeReward').value = track.free_reward;
                                        document.getElementById('editPremiumReward').value = track.premium_reward;
                                        document.getElementById('editTrackLink').value = track.track_link || '';
                                        
                                        document.getElementById('editModal').style.display = 'flex';
                                    } else {
                                        alert('Failed to load track data');
                                    }
                                })
                                .catch(error => {
                                    console.error('Error:', error);
                                    alert('Failed to load track data');
                                });
                        }
                        
                        function closeEditModal() {
                            document.getElementById('editModal').style.display = 'none';
                        }
                        
                        function deleteTrack(trackId, trackTitle) {
                            document.getElementById('deleteTrackId').value = trackId;
                            document.getElementById('deleteTrackTitle').textContent = trackTitle;
                            document.getElementById('deleteModal').style.display = 'flex';
                        }
                        
                        function closeDeleteModal() {
                            document.getElementById('deleteModal').style.display = 'none';
                        }
                        
                        document.getElementById('editModal').addEventListener('click', function(e) {
                            if (e.target === this) closeEditModal();
                        });
                        
                        document.getElementById('deleteModal').addEventListener('click', function(e) {
                            if (e.target === this) closeDeleteModal();
                        });
                    </script>
                <?php endif; ?>
            </div>
        </div>
    </div>
</body>
</html>
