<?php
session_start();
require_once '../config/database2.php';

// Check if user is logged in and is admin
if (!isset($_SESSION['user_id'])) {
    header('Location: ../login.php');
    exit();
}

$user_id = $_SESSION['user_id'];

// Check if user is admin
$stmt = $pdo->prepare("SELECT is_admin FROM users WHERE id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch();

if (!$user || !$user['is_admin']) {
    header('Location: ../dashboard.php');
    exit();
}

// Handle settings update
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    if ($action === 'update_settings') {
        // In a real application, you would store these in a settings table
        // For now, we'll just show a success message
        $success = "Settings updated successfully!";
    }
}

// Get platform stats for display
$stmt = $pdo->query("SELECT COUNT(*) as total_users FROM users");
$user_count = $stmt->fetch();

$stmt = $pdo->query("SELECT SUM(total_balance) as total_balance FROM balances");
$balance_stats = $stmt->fetch();

$stmt = $pdo->query("SELECT COUNT(*) as pending_withdrawals FROM withdrawals WHERE status = 'pending'");
$withdrawal_stats = $stmt->fetch();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Settings - FlowEarner Admin</title>
    <link rel="stylesheet" href="../css/style.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px;
        }

       
        .admin-main {
            flex: 1;
        }

        .admin-header {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            padding: 30px;
            margin-bottom: 20px;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
        }

        .admin-header h1 {
            color: #2d3748;
            font-size: 32px;
            margin-bottom: 10px;
        }

        .admin-header p {
            color: #718096;
            font-size: 16px;
        }

        .content-section {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            padding: 30px;
            margin-bottom: 20px;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
        }

        .content-section h2 {
            color: #2d3748;
            font-size: 24px;
            margin-bottom: 20px;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            color: #4a5568;
            font-weight: 600;
            margin-bottom: 8px;
        }

        .form-group input, .form-group select, .form-group textarea {
            width: 100%;
            padding: 12px;
            border: 2px solid #e2e8f0;
            border-radius: 10px;
            font-size: 14px;
        }

        .form-group small {
            color: #718096;
            font-size: 13px;
        }

        .btn {
            padding: 12px 24px;
            border: none;
            border-radius: 10px;
            cursor: pointer;
            font-size: 14px;
            font-weight: 600;
            transition: all 0.3s;
        }

        .btn-primary {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
        }

        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(102, 126, 234, 0.4);
        }

        .alert {
            padding: 15px 20px;
            border-radius: 10px;
            margin-bottom: 20px;
        }

        .alert-success {
            background: #d1fae5;
            color: #065f46;
        }

        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 20px;
        }

        .stat-card {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 15px;
            padding: 25px;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
        }

        .stat-card h3 {
            color: #718096;
            font-size: 14px;
            margin-bottom: 10px;
            text-transform: uppercase;
        }

        .stat-card .value {
            color: #2d3748;
            font-size: 32px;
            font-weight: bold;
        }

        @media (max-width: 768px) {
            .admin-container {
                flex-direction: column;
            }

           

            .stats-grid {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
      <?php include 'side-bar.php'; ?>
<div class="admin-content">

        
        <main class="admin-main">
            <div class="admin-header">
                <h1>Admin Settings</h1>
                <p>Configure platform settings and preferences</p>
            </div>

            <?php if (isset($success)): ?>
                <div class="alert alert-success"><?php echo $success; ?></div>
            <?php endif; ?>

             Platform Stats 
            <div class="stats-grid">
                <div class="stat-card">
                    <h3>Total Users</h3>
                    <div class="value"><?php echo number_format($user_count['total_users']); ?></div>
                </div>
                <div class="stat-card">
                    <h3>Total Balance</h3>
                    <div class="value">₦<?php echo number_format($balance_stats['total_balance'] ?? 0, 2); ?></div>
                </div>
                <div class="stat-card">
                    <h3>Pending Withdrawals</h3>
                    <div class="value" style="color: #f59e0b;"><?php echo number_format($withdrawal_stats['pending_withdrawals']); ?></div>
                </div>
            </div>

             General Settings 
            <div class="content-section">
                <h2>General Settings</h2>
                <form method="POST">
                    <input type="hidden" name="action" value="update_settings">
                    
                    <div class="form-group">
                        <label>Platform Name</label>
                        <input type="text" name="platform_name" value="FlowEarner">
                    </div>

                    <div class="form-group">
                        <label>Support Email</label>
                        <input type="email" name="support_email" value="support@flowearner.com">
                        <small>Email address for user support inquiries</small>
                    </div>

                    <div class="form-group">
                        <label>Minimum Withdrawal Amount (₦)</label>
                        <input type="number" name="min_withdrawal" value="5000">
                        <small>Minimum amount users can withdraw</small>
                    </div>

                    <div class="form-group">
                        <label>Referral Bonus (₦)</label>
                        <input type="number" name="referral_bonus" value="1000">
                        <small>Amount earned per successful referral</small>
                    </div>

                    <div class="form-group">
                        <label>Premium Membership Price (₦)</label>
                        <input type="number" name="premium_price" value="5000">
                        <small>Monthly subscription price for premium membership</small>
                    </div>

                    <button type="submit" class="btn btn-primary">Save Settings</button>
                </form>
            </div>

             Earning Settings 
            <div class="content-section">
                <h2>Earning Settings</h2>
                <form method="POST">
                    <input type="hidden" name="action" value="update_settings">
                    
                    <div class="form-group">
                        <label>Daily Task Limit</label>
                        <input type="number" name="daily_task_limit" value="10">
                        <small>Maximum tasks a user can complete per day</small>
                    </div>

                    <div class="form-group">
                        <label>Video Watch Reward - Free Users (₦)</label>
                        <input type="number" name="video_free_reward" value="100">
                    </div>

                    <div class="form-group">
                        <label>Video Watch Reward - Premium Users (₦)</label>
                        <input type="number" name="video_premium_reward" value="500">
                    </div>

                    <div class="form-group">
                        <label>Music Listen Reward - Free Users (₦)</label>
                        <input type="number" name="music_free_reward" value="150">
                    </div>

                    <div class="form-group">
                        <label>Music Listen Reward - Premium Users (₦)</label>
                        <input type="number" name="music_premium_reward" value="700">
                    </div>

                    <button type="submit" class="btn btn-primary">Save Earning Settings</button>
                </form>
            </div>

             Notification Settings 
            <div class="content-section">
                <h2>Notification Settings</h2>
                <form method="POST">
                    <input type="hidden" name="action" value="update_settings">
                    
                    <div class="form-group">
                        <label>Email Notifications</label>
                        <select name="email_notifications">
                            <option value="1">Enabled</option>
                            <option value="0">Disabled</option>
                        </select>
                        <small>Send email notifications to users</small>
                    </div>

                    <div class="form-group">
                        <label>Withdrawal Notifications</label>
                        <select name="withdrawal_notifications">
                            <option value="1">Enabled</option>
                            <option value="0">Disabled</option>
                        </select>
                        <small>Notify admin of new withdrawal requests</small>
                    </div>

                    <button type="submit" class="btn btn-primary">Save Notification Settings</button>
                </form>
            </div>
        </main>
    </div>
</body>
</html>
