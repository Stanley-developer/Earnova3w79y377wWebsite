<?php
session_start();
require_once '../config/database2.php';

// Check if user is logged in and is admin
if (!isset($_SESSION['user_id'])) {
    header('Location: ../login.php');
    exit();
}

$user_id = $_SESSION['user_id'];

// Check if user is admin
$stmt = $pdo->prepare("SELECT is_admin FROM users WHERE id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch();

if (!$user || !$user['is_admin']) {
    header('Location: ../dashboard.php');
    exit();
}

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    if ($action === 'add_video') {
        $title = $_POST['title'];
        $url = $_POST['url'];
        $duration = $_POST['duration'];
        $free_reward = $_POST['free_reward'];
        $premium_reward = $_POST['premium_reward'];
        
        $stmt = $pdo->prepare("INSERT INTO available_videos (title, video_url, duration_seconds, free_user_reward, premium_user_reward) VALUES (?, ?, ?, ?, ?)");
        $stmt->execute([$title, $url, $duration, $free_reward, $premium_reward]);
        $success = "Video added successfully!";
    } elseif ($action === 'add_music') {
        $title = $_POST['title'];
        $artist = $_POST['artist'];
        $url = $_POST['url'];
        $duration = $_POST['duration'];
        $free_reward = $_POST['free_reward'];
        $premium_reward = $_POST['premium_reward'];
        
        $stmt = $pdo->prepare("INSERT INTO available_music (title, artist, audio_url, duration_seconds, free_user_reward, premium_user_reward) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->execute([$title, $artist, $url, $duration, $free_reward, $premium_reward]);
        $success = "Music added successfully!";
    } elseif ($action === 'delete_video') {
        $id = $_POST['id'];
        $stmt = $pdo->prepare("DELETE FROM available_videos WHERE id = ?");
        $stmt->execute([$id]);
        $success = "Video deleted successfully!";
    } elseif ($action === 'delete_music') {
        $id = $_POST['id'];
        $stmt = $pdo->prepare("DELETE FROM available_music WHERE id = ?");
        $stmt->execute([$id]);
        $success = "Music deleted successfully!";
    }
}

// Get all videos
$stmt = $pdo->query("SELECT * FROM available_videos ORDER BY created_at DESC");
$videos = $stmt->fetchAll();

// Get all music
$stmt = $pdo->query("SELECT * FROM available_music ORDER BY created_at DESC");
$music = $stmt->fetchAll();

// Get stats
$stmt = $pdo->query("SELECT COUNT(*) as video_count FROM available_videos");
$video_stats = $stmt->fetch();

$stmt = $pdo->query("SELECT COUNT(*) as music_count FROM available_music");
$music_stats = $stmt->fetch();

$stmt = $pdo->query("SELECT COUNT(*) as total_views FROM video_earnings");
$view_stats = $stmt->fetch();

$stmt = $pdo->query("SELECT COUNT(*) as total_listens FROM music_earnings");
$listen_stats = $stmt->fetch();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Videos & Music - FlowEarner Admin</title>
    <link rel="stylesheet" href="../css/style.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px;
        }

        
        .admin-main {
            flex: 1;
        }

        .admin-header {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            padding: 30px;
            margin-bottom: 20px;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
        }

        .admin-header h1 {
            color: #2d3748;
            font-size: 32px;
            margin-bottom: 10px;
        }

        .admin-header p {
            color: #718096;
            font-size: 16px;
        }

        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 20px;
        }

        .stat-card {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 15px;
            padding: 25px;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
        }

        .stat-card h3 {
            color: #718096;
            font-size: 14px;
            margin-bottom: 10px;
            text-transform: uppercase;
        }

        .stat-card .value {
            color: #2d3748;
            font-size: 32px;
            font-weight: bold;
        }

        .content-section {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            padding: 30px;
            margin-bottom: 20px;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
        }

        .content-section h2 {
            color: #2d3748;
            font-size: 24px;
            margin-bottom: 20px;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            color: #4a5568;
            font-weight: 600;
            margin-bottom: 8px;
        }

        .form-group input, .form-group textarea {
            width: 100%;
            padding: 12px;
            border: 2px solid #e2e8f0;
            border-radius: 10px;
            font-size: 14px;
        }

        .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 15px;
        }

        .btn {
            padding: 12px 24px;
            border: none;
            border-radius: 10px;
            cursor: pointer;
            font-size: 14px;
            font-weight: 600;
            transition: all 0.3s;
        }

        .btn-primary {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
        }

        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(102, 126, 234, 0.4);
        }

        .btn-danger {
            background: #ef4444;
            color: white;
            padding: 8px 16px;
            font-size: 13px;
        }

        .btn-danger:hover {
            background: #dc2626;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th {
            text-align: left;
            padding: 15px;
            color: #4a5568;
            font-weight: 600;
            border-bottom: 2px solid #e2e8f0;
        }

        td {
            padding: 15px;
            color: #2d3748;
            border-bottom: 1px solid #e2e8f0;
        }

        .alert {
            padding: 15px 20px;
            border-radius: 10px;
            margin-bottom: 20px;
        }

        .alert-success {
            background: #d1fae5;
            color: #065f46;
        }

        @media (max-width: 768px) {
            .admin-container {
                flex-direction: column;
            }

          

            .stats-grid {
                grid-template-columns: 1fr;
            }

            .form-row {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
      <?php include 'side-bar.php'; ?>
<div class="admin-content">
        <main class="admin-main">
            <div class="admin-header">
                <h1>Videos & Music Management</h1>
                <p>Add and manage earning content</p>
            </div>

            <?php if (isset($success)): ?>
                <div class="alert alert-success"><?php echo $success; ?></div>
            <?php endif; ?>

             Stats 
            <div class="stats-grid">
                <div class="stat-card">
                    <h3>Total Videos</h3>
                    <div class="value"><?php echo number_format($video_stats['video_count']); ?></div>
                </div>
                <div class="stat-card">
                    <h3>Total Music</h3>
                    <div class="value"><?php echo number_format($music_stats['music_count']); ?></div>
                </div>
                <div class="stat-card">
                    <h3>Total Views</h3>
                    <div class="value"><?php echo number_format($view_stats['total_views']); ?></div>
                </div>
                <div class="stat-card">
                    <h3>Total Listens</h3>
                    <div class="value"><?php echo number_format($listen_stats['total_listens']); ?></div>
                </div>
            </div>

             Add Video Form 
            <div class="content-section">
                <h2>Add New Video</h2>
                <form method="POST">
                    <input type="hidden" name="action" value="add_video">
                    <div class="form-group">
                        <label>Video Title</label>
                        <input type="text" name="title" required>
                    </div>
                    <div class="form-group">
                        <label>Video URL</label>
                        <input type="url" name="url" placeholder="https://video.com/watch?v=..." required>
                    </div>
                    <div class="form-row">
                        <div class="form-group">
                            <label>Duration (seconds)</label>
                            <input type="number" name="duration" required>
                        </div>
                        <div class="form-group">
                            <label>Free User Reward (₦)</label>
                            <input type="number" name="free_reward" value="100" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <label>Premium User Reward (₦)</label>
                        <input type="number" name="premium_reward" value="500" required>
                    </div>
                    <button type="submit" class="btn btn-primary">Add Video</button>
                </form>
            </div>

             Add Music Form 
            <div class="content-section">
                <h2>Add New Music</h2>
                <form method="POST">
                    <input type="hidden" name="action" value="add_music">
                    <div class="form-row">
                        <div class="form-group">
                            <label>Song Title</label>
                            <input type="text" name="title" required>
                        </div>
                        <div class="form-group">
                            <label>Artist Name</label>
                            <input type="text" name="artist" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <label>Audio File URL</label>
                        <input type="url" name="url" placeholder="https://example.com/audio.mp3" required>
                    </div>
                    <div class="form-row">
                        <div class="form-group">
                            <label>Duration (seconds)</label>
                            <input type="number" name="duration" required>
                        </div>
                        <div class="form-group">
                            <label>Free User Reward (₦)</label>
                            <input type="number" name="free_reward" value="150" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <label>Premium User Reward (₦)</label>
                        <input type="number" name="premium_reward" value="700" required>
                    </div>
                    <button type="submit" class="btn btn-primary">Add Music</button>
                </form>
            </div>

             Videos List 
            <div class="content-section">
                <h2>All Videos</h2>
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Title</th>
                            <th>Duration</th>
                            <th>Free Reward</th>
                            <th>Premium Reward</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($videos as $video): ?>
                            <tr>
                                <td>#<?php echo $video['id']; ?></td>
                                <td><?php echo htmlspecialchars($video['title']); ?></td>
                                <td><?php echo $video['duration']; ?>s</td>
                                <td>₦<?php echo number_format($video['free_reward'], 2); ?></td>
                                <td>₦<?php echo number_format($video['premium_reward'], 2); ?></td>
                                <td>
                                    <form method="POST" style="display: inline;">
                                        <input type="hidden" name="action" value="delete_video">
                                        <input type="hidden" name="id" value="<?php echo $video['id']; ?>">
                                        <button type="submit" class="btn btn-danger" onclick="return confirm('Delete this video?')">Delete</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>

             Music List 
            <div class="content-section">
                <h2>All Music</h2>
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Title</th>
                            <th>Artist</th>
                            <th>Duration</th>
                            <th>Free Reward</th>
                            <th>Premium Reward</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($music as $track): ?>
                            <tr>
                                <td>#<?php echo $track['id']; ?></td>
                                <td><?php echo htmlspecialchars($track['title']); ?></td>
                                <td><?php echo htmlspecialchars($track['artist']); ?></td>
                                <td><?php echo $track['duration']; ?>s</td>
                                <td>₦<?php echo number_format($track['free_reward'], 2); ?></td>
                                <td>₦<?php echo number_format($track['premium_reward'], 2); ?></td>
                                <td>
                                    <form method="POST" style="display: inline;">
                                        <input type="hidden" name="action" value="delete_music">
                                        <input type="hidden" name="id" value="<?php echo $track['id']; ?>">
                                        <button type="submit" class="btn btn-danger" onclick="return confirm('Delete this music?')">Delete</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </main>
    </div>
</body>
</html>
