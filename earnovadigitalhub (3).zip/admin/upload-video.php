<?php
// Enable error logging for debugging
ini_set('display_errors', 1);
ini_set('log_errors', 1);
error_reporting(E_ALL);

require_once '../config/database.php';
require_once '../includes/session.php';

// Require authentication
requireLogin();
checkSessionTimeout();

// Get current user
$user = getCurrentUser();
$user_id = $user['id'];

// Create PDO connection
$pdo = getDBConnection();

// Check if user is admin
$stmt = $pdo->prepare("SELECT is_admin FROM users WHERE id = ?");
$stmt->execute([$user_id]);
$userCheck = $stmt->fetch();

if (!$userCheck || !$userCheck['is_admin']) {
    header('Location: ../dashboard.php');
    exit();
}

$message = '';
$messageType = '';

// Handle delete, edit, and toggle actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    if ($action === 'delete') {
        try {
            $video_id = $_POST['video_id'] ?? '';
            if ($video_id) {
                $stmt = $pdo->prepare("DELETE FROM available_videos WHERE id = ?");
                $stmt->execute([$video_id]);
                $message = 'Video deleted successfully!';
                $messageType = 'success';
            }
        } catch (Exception $e) {
            $message = 'Failed to delete video: ' . htmlspecialchars($e->getMessage());
            $messageType = 'error';
        }
    } elseif ($action === 'toggle_status') {
        try {
            $video_id = $_POST['video_id'] ?? '';
            if ($video_id) {
                $stmt = $pdo->prepare("SELECT is_active FROM available_videos WHERE id = ?");
                $stmt->execute([$video_id]);
                $video = $stmt->fetch();
                
                if ($video) {
                    $new_status = $video['is_active'] ? 0 : 1;
                    $stmt = $pdo->prepare("UPDATE available_videos SET is_active = ? WHERE id = ?");
                    $stmt->execute([$new_status, $video_id]);
                    $status_text = $new_status ? 'activated' : 'paused';
                    $message = 'Video ' . $status_text . ' successfully!';
                    $messageType = 'success';
                }
            }
        } catch (Exception $e) {
            $message = 'Failed to update video status: ' . htmlspecialchars($e->getMessage());
            $messageType = 'error';
        }
    } elseif ($action === 'edit') {
        try {
            $video_id = $_POST['video_id'] ?? '';
            $title = trim($_POST['title'] ?? '');
            $description = trim($_POST['description'] ?? '');
            $video_url = trim($_POST['video_url'] ?? '');
            $platform = trim($_POST['platform'] ?? '');
            $free_reward = floatval($_POST['free_reward'] ?? 0);
            $premium_reward = floatval($_POST['premium_reward'] ?? 0);
            $is_compulsory = isset($_POST['is_compulsory']) ? 1 : 0;
            
            if (!$video_id || !$title || !$video_url || !$platform) {
                $message = 'Please fill in all required fields.';
                $messageType = 'error';
            } elseif ($free_reward <= 0 || $premium_reward <= 0) {
                $message = 'Rewards must be greater than 0.';
                $messageType = 'error';
            } else {
                $stmt = $pdo->prepare("UPDATE available_videos SET title = ?, description = ?, video_url = ?, platform = ?, free_reward = ?, premium_reward = ?, is_compulsory = ? WHERE id = ?");
                $stmt->execute([$title, $description, $video_url, $platform, $free_reward, $premium_reward, $is_compulsory, $video_id]);
                $message = 'Video updated successfully!';
                $messageType = 'success';
            }
        } catch (Exception $e) {
            $message = 'Failed to update video: ' . htmlspecialchars($e->getMessage());
            $messageType = 'error';
        }
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'upload_video') {
    try {
        $title = trim($_POST['title'] ?? '');
        $description = trim($_POST['description'] ?? '');
        $video_url = trim($_POST['video_url'] ?? '');
        $platform = trim($_POST['platform'] ?? '');
        $free_reward = floatval($_POST['free_reward'] ?? 0);
        $premium_reward = floatval($_POST['premium_reward'] ?? 0);
        $is_compulsory = isset($_POST['is_compulsory']) ? 1 : 0;

        if ($title === '' || $video_url === '' || $platform === '') {
            $message = 'Please fill in all required fields.';
            $messageType = 'error';
        } else {
            // Handle thumbnail
            $thumbnail = '';
            if (isset($_FILES['thumbnail']) && $_FILES['thumbnail']['error'] === UPLOAD_ERR_OK) {
                $ext = strtolower(pathinfo($_FILES['thumbnail']['name'], PATHINFO_EXTENSION));
                $allowed = ['jpg','jpeg','png','gif','webp'];
                if (in_array($ext,$allowed)) {
                    if (!is_dir('../uploads/stream_thumbnails')) mkdir('../uploads/stream_thumbnails',0755,true);
                    $newname = 'thumbnail_' . time() . '_' . uniqid() . '.' . $ext;
                    $path = '../uploads/stream_thumbnails/' . $newname;
                    if (!move_uploaded_file($_FILES['thumbnail']['tmp_name'],$path)) {
                        throw new Exception('Failed to move uploaded thumbnail file.');
                    }
                    $thumbnail = 'uploads/stream_thumbnails/' . $newname;
                } else {
                    throw new Exception('Invalid thumbnail file type.');
                }
            }

           
            $video_id = 'video_' . time() . '_' . uniqid();
            $created_at = date('Y-m-d H:i:s');
            
            // Corrected INSERT query
            $stmt = $pdo->prepare("
                INSERT INTO available_videos
                (video_id, title, description, video_url, platform, free_reward, premium_reward, is_compulsory, thumbnail_url, is_active, created_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?)
            ");
            
            $stmt->execute([
                $video_id,
                $title,
                $description,
                $video_url,
                $platform,
                $free_reward,
                $premium_reward,
                $is_compulsory,
                $thumbnail,       // now goes into thumbnail_url
                $created_at
            ]);



            $message = 'Video uploaded successfully!';
            $messageType = 'success';
        }

    } catch (Exception $e) {
        error_log('Upload error: ' . $e->getMessage());
        $message = 'Upload failed: ' . htmlspecialchars($e->getMessage());
        $messageType = 'error';
    }
}


// Handle JSON request for video data
if (isset($_GET['get_video_json'])) {
    $video_id = intval($_GET['get_video_json']);
    try {
        $stmt = $pdo->prepare("SELECT id, title, description, video_url, platform, free_reward, premium_reward, is_compulsory FROM available_videos WHERE id = ?");
        $stmt->execute([$video_id]);
        $video = $stmt->fetch();
        
        header('Content-Type: application/json');
        if ($video) {
            echo json_encode(['success' => true, 'video' => $video]);
        } else {
            echo json_encode(['success' => false, 'message' => 'Video not found']);
        }
        exit();
    } catch (Exception $e) {
        header('Content-Type: application/json');
        echo json_encode(['success' => false, 'message' => $e->getMessage()]);
        exit();
    }
}

// Fetch all videos for admin view
try {
    $stmt = $pdo->prepare("SELECT * FROM available_videos ORDER BY created_at DESC");
    $stmt->execute();
    $videos = $stmt->fetchAll();
} catch (Exception $e) {
    $videos = [];
    error_log('Fetch videos error: ' . $e->getMessage());
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Upload Video - Admin</title>
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; }
        
        body {
            font-family: "Titillium Web", "Segoe UI", sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: #f5f9ff;
            min-height: 100vh;
        }
        
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 2rem;
        }
        
        h1 {
            font-size: 2.5rem;
            margin-bottom: 2rem;
            background: linear-gradient(135deg, #8b5cf6, #ec4899);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }
        
        .upload-form {
            background: white;
            border: none;
            border-radius: 16px;
            padding: 32px;
            margin-bottom: 3rem;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        
        .upload-form h2 {
            color: #1e293b;
            margin-bottom: 24px;
        }
        
        .form-group {
            margin-bottom: 24px;
        }
        
        label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: #1e293b;
        }
        
        input[type="text"],
        input[type="number"],
        input[type="file"],
        input[type="url"],
        select {
            width: 100%;
            padding: 12px 16px;
            border-radius: 8px;
            border: 1px solid #e2e8f0;
            background: white;
            color: #1e293b;
            font-size: 1rem;
            transition: border-color 0.3s;
        }
        
        input[type="text"]:focus,
        input[type="number"]:focus,
        input[type="file"]:focus,
        input[type="url"]:focus,
        select:focus {
            outline: none;
            border-color: #6366f1;
        }
        
        input[type="file"] {
            padding: 0.5rem;
        }
        
        select {
            cursor: pointer;
        }
        
        .checkbox-group {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 12px;
            background: rgba(6, 16, 48, 0.5);
            border-radius: 12px;
            border: 1px solid rgba(86, 139, 241, 0.2);
        }
        
        .checkbox-group input[type="checkbox"] {
            width: 20px;
            height: 20px;
            cursor: pointer;
        }
        
        .checkbox-group label {
            margin: 0;
            cursor: pointer;
        }
        
        .btn {
            padding: 0.875rem 2rem;
            border-radius: 16px;
            border: none;
            font-weight: 600;
            font-size: 1rem;
            cursor: pointer;
            transition: all 0.3s ease;
        }
        
        .btn-primary {
            background: linear-gradient(135deg, #8b5cf6, #ec4899);
            color: #fff;
        }
        
        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 30px rgba(139, 92, 246, 0.4);
        }
        
        .alert {
            padding: 16px 20px;
            border-radius: 8px;
            margin-bottom: 24px;
            font-size: 0.95rem;
        }
        
        .alert-success {
            background: #d1fae5;
            border: 1px solid #6ee7b7;
            color: #047857;
        }
        
        .alert-error {
            background: #fee2e2;
            border: 1px solid #fca5a5;
            color: #dc2626;
        }
        
        .tracks-list {
            background: white;
            border: none;
            border-radius: 16px;
            padding: 32px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        
        .tracks-list h2 {
            color: #1e293b;
            margin-bottom: 24px;
        }
        
        .track-item {
            background: #f8fafc;
            border: 1px solid #e2e8f0;
            border-radius: 8px;
            padding: 16px;
            margin-bottom: 16px;
            display: grid;
            grid-template-columns: 60px 1fr auto;
            gap: 16px;
            align-items: center;
        }
        
        .track-cover {
            width: 60px;
            height: 60px;
            border-radius: 12px;
            background: linear-gradient(135deg, #8b5cf6, #ec4899);
        }
        
        .track-cover img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            border-radius: 12px;
        }
        
        .track-info h3 {
            font-size: 1.1rem;
            margin-bottom: 4px;
            color: #1e293b;
        }
        
        .track-info p {
            font-size: 0.9rem;
            color: #64748b;
        }
        
        .track-stats {
            text-align: right;
            font-size: 0.9rem;
            color: #64748b;
        }
        
        /* Added admin sidebar offset */
        .admin-content {
            margin-left: 260px;
            padding: 20px;
            transition: margin-left 0.3s ease;
        }
        
        @media (max-width: 1024px) {
            .track-item {
                grid-template-columns: 55px 1fr 65px;
                gap: 12px;
                padding: 14px;
            }
            
            .track-cover {
                width: 55px;
                height: 55px;
            }
            
            .track-stats {
                font-size: 0.85rem;
            }
        }
        
        @media (max-width: 768px) {
            .admin-content {
                margin-left: 0;
                padding: 12px;
            }
            
            .container {
                max-width: 100%;
                padding: 1rem 0.5rem;
                margin: 0;
            }
            
            h1 {
                font-size: 1.6rem;
                margin-bottom: 1rem;
            }
            
            .upload-form {
                padding: 16px;
                margin-bottom: 1.5rem;
                border-radius: 12px;
                box-shadow: 0 2px 4px rgba(0, 0, 0, 0.08);
            }
            
            .upload-form h2 {
                font-size: 1.1rem;
                margin-bottom: 12px;
            }
            
            .form-group {
                margin-bottom: 12px;
            }
            
            label {
                font-size: 0.9rem;
                margin-bottom: 4px;
            }
            
            input[type="text"],
            input[type="number"],
            input[type="file"],
            input[type="url"],
            select {
                padding: 10px 12px;
                font-size: 16px;
                border-radius: 6px;
            }
            
            input[type="file"] {
                padding: 8px 0;
            }
            
            .checkbox-group {
                padding: 10px;
                gap: 8px;
                font-size: 0.9rem;
                flex-wrap: wrap;
            }
            
            .checkbox-group input[type="checkbox"] {
                width: 18px;
                height: 18px;
            }
            
            .btn {
                padding: 0.7rem 1.5rem;
                font-size: 0.9rem;
                width: 100%;
                border-radius: 12px;
            }
            
            .alert {
                font-size: 0.9rem;
                padding: 12px 16px;
                margin-bottom: 12px;
            }
            
            .tracks-list {
                padding: 16px;
                margin-top: 1rem;
                border-radius: 12px;
                overflow-x: auto;
                -webkit-overflow-scrolling: touch;
                box-shadow: 0 2px 4px rgba(0, 0, 0, 0.08);
            }
            
            .tracks-list h2 {
                font-size: 1.1rem;
                margin-bottom: 12px;
                margin-right: 16px;
            }
            
            .track-item {
                grid-template-columns: 48px 1fr 60px;
                gap: 10px;
                padding: 12px;
                margin-bottom: 10px;
                border-radius: 6px;
                min-width: fit-content;
                flex-shrink: 0;
            }
            
            .track-cover {
                width: 48px;
                height: 48px;
                border-radius: 6px;
                flex-shrink: 0;
            }
            
            .track-info h3 {
                font-size: 0.95rem;
                margin-bottom: 2px;
            }
            
            .track-info p {
                font-size: 0.8rem;
                line-height: 1.2;
                overflow: hidden;
                text-overflow: ellipsis;
                display: -webkit-box;
                -webkit-line-clamp: 1;
            }
            
            .track-stats {
                font-size: 0.75rem;
                text-align: center;
                word-break: break-word;
                min-width: 60px;
                flex-shrink: 0;
            }
        }
        
        @media (max-width: 480px) {
            .admin-content {
                padding: 8px;
            }
            
            .container {
                padding: 0.5rem 0.25rem;
            }
            
            h1 {
                font-size: 1.3rem;
                margin-bottom: 0.75rem;
            }
            
            .upload-form {
                padding: 12px;
                margin-bottom: 1rem;
            }
            
            .upload-form h2 {
                font-size: 1rem;
                margin-bottom: 10px;
            }
            
            .form-group {
                margin-bottom: 10px;
            }
            
            label {
                font-size: 0.85rem;
            }
            
            input[type="text"],
            input[type="number"],
            input[type="file"],
            input[type="url"],
            select {
                padding: 9px 10px;
                font-size: 16px;
            }
            
            .btn {
                font-size: 0.85rem;
                padding: 0.6rem 1rem;
            }
            
            .tracks-list {
                padding: 12px;
                overflow-x: auto;
                -webkit-overflow-scrolling: touch;
            }
            
            .tracks-list h2 {
                font-size: 1rem;
                margin-bottom: 10px;
            }
            
            .track-item {
                grid-template-columns: 40px 1fr 50px;
                gap: 8px;
                padding: 10px;
                margin-bottom: 8px;
            }
            
            .track-cover {
                width: 40px;
                height: 40px;
            }
            
            .track-info h3 {
                font-size: 0.9rem;
            }
            
            .track-info p {
                font-size: 0.75rem;
            }
            
            .track-stats {
                min-width: 50px;
                font-size: 0.7rem;
            }
        }
    </style>
</head>
<body>
    <!-- Added sidebar include -->
    <?php include 'side-bar.php'; ?>
    
    <div class="admin-content">
        <div class="container">
            <h1>🎥 Upload Video</h1>
            
            <?php if ($message): ?>
                <div class="alert alert-<?php echo $messageType; ?>">
                    <?php echo htmlspecialchars($message); ?>
                </div>
            <?php endif; ?>
            
            <div class="upload-form">
                <h2 style="margin-bottom: 1.5rem;">Upload New Video</h2>
                <form method="POST" enctype="multipart/form-data">
                    <input type="hidden" name="action" value="upload_video">
                    
                    <div class="form-group">
                        <label for="title">Video Title *</label>
                        <input type="text" id="title" name="title" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="description">Description</label>
                        <input type="text" id="description" name="description">
                    </div>
                    
                    <div class="form-group">
                        <label for="video_url">Video URL *</label>
                        <input type="text" id="video_url" name="video_url" placeholder="https://youtube.com/watch?v=..." required>
                        <small style="color: rgba(205, 219, 255, 0.6);">YouTube, TikTok, Instagram, Facebook, Twitter, or LinkedIn video URL</small>
                    </div>
                    
                    <div class="form-group">
                        <label for="platform">Platform *</label>
                        <select id="platform" name="platform" required>
                            <option value="">Select Platform</option>
                            <option value="youtube">YouTube</option>
                            <option value="tiktok">TikTok</option>
                            <option value="instagram">Instagram</option>
                            <option value="facebook">Facebook</option>
                            <option value="twitter">Twitter</option>
                            <option value="linkedin">LinkedIn</option>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label for="thumbnail">Thumbnail Image (Optional)</label>
                        <input type="file" id="thumbnail" name="thumbnail" accept="image/*">
                    </div>
                    
                    <div class="form-group">
                        <label for="free_reward">Free User Reward (₦) *</label>
                        <input type="number" id="free_reward" name="free_reward" step="0.01" value="100" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="premium_reward">Premium User Reward (₦) *</label>
                        <input type="number" id="premium_reward" name="premium_reward" step="0.01" value="500" required>
                    </div>
                    
                    <div class="form-group">
                        <div class="checkbox-group">
                            <input type="checkbox" id="is_compulsory" name="is_compulsory" value="1">
                            <label for="is_compulsory">Mark as Compulsory Video (Users must complete this video)</label>
                        </div>
                    </div>
                    
                    <button type="submit" class="btn btn-primary">Upload Video</button>
                </form>
            </div>
            
            <div class="tracks-list">
                <h2>Uploaded Videos (<?php echo count($videos); ?>)</h2>
                <?php if(empty($videos)): ?>
                    <p style="text-align:center;padding:2rem;color:rgba(205,219,255,0.6);">No videos uploaded yet.</p>
                <?php else: ?>
                    <?php foreach($videos as $video): ?>
                        <div class="track-item" style="display: grid; grid-template-columns: 60px 1fr auto; gap: 16px; align-items: center;">
                            <div class="track-cover">
                                <?php
                                $thumb = $video['thumbnail_url'] ?? '';
                                if($thumb) echo '<img src="../'.htmlspecialchars($thumb).'" alt="Thumbnail">';
                                ?>
                            </div>
                            <div class="track-info">
                                <h3><?php echo htmlspecialchars($video['title']); ?></h3>
                                <p><?php echo htmlspecialchars($video['description']); ?></p>
                                <small style="color: #64748b;">
                                    <span style="margin-right: 12px;"> <?php echo htmlspecialchars($video['platform']); ?></span>
                                    <span style="margin-right: 12px;">₦<?php echo number_format($video['free_reward'], 2); ?> free</span>
                                    <span style="margin-right: 12px;">₦<?php echo number_format($video['premium_reward'], 2); ?> premium</span>
                                    <span><?php echo isset($video['created_at']) ? date('M j, Y', strtotime($video['created_at'])) : 'N/A'; ?></span>
                                    <?php if ($video['is_compulsory']): ?><span style="background: #fbbf24; color: #78350f; padding: 2px 6px; border-radius: 4px; font-size: 0.75rem; margin-left: 8px;">Compulsory</span><?php endif; ?>
                                    <span style="background: <?php echo $video['is_active'] ? '#d1fae5' : '#fee2e2'; ?>; color: <?php echo $video['is_active'] ? '#047857' : '#dc2626'; ?>; padding: 2px 6px; border-radius: 4px; font-size: 0.75rem; margin-left: 8px;"><?php echo $video['is_active'] ? 'Active' : 'Paused'; ?></span>
                                </small>
                            </div>
                            <div style="display: flex; gap: 8px; flex-direction: column; align-items: stretch;">
                                <button onclick="editVideo(<?php echo $video['id']; ?>)" style="padding: 6px 12px; background: #3b82f6; color: white; border: none; border-radius: 6px; cursor: pointer; font-size: 0.85rem; font-weight: 600;">Edit</button>
                                <form method="POST" style="display: inline;">
                                    <input type="hidden" name="action" value="toggle_status">
                                    <input type="hidden" name="video_id" value="<?php echo $video['id']; ?>">
                                    <button type="submit" style="padding: 6px 12px; background: <?php echo $video['is_active'] ? '#f97316' : '#10b981'; ?>; color: white; border: none; border-radius: 6px; cursor: pointer; font-size: 0.85rem; font-weight: 600;">
                                        <?php echo $video['is_active'] ? 'Pause' : 'Activate'; ?>
                                    </button>
                                </form>
                                <button onclick="deleteVideo(<?php echo $video['id']; ?>, '<?php echo htmlspecialchars($video['title'], ENT_QUOTES); ?>')" style="padding: 6px 12px; background: #ef4444; color: white; border: none; border-radius: 6px; cursor: pointer; font-size: 0.85rem; font-weight: 600;">Delete</button>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
            
            <!-- Edit Video Modal -->
            <div id="editModal" style="display: none; position: fixed; top: 0; left: 0; right: 0; bottom: 0; background: rgba(0,0,0,0.7); z-index: 1000; align-items: center; justify-content: center;">
                <div style="background: white; border-radius: 16px; padding: 32px; max-width: 600px; width: 90%; max-height: 80vh; overflow-y: auto;">
                    <h2 style="color: #1e293b; margin-bottom: 24px;">Edit Video</h2>
                    <form method="POST">
                        <input type="hidden" name="action" value="edit">
                        <input type="hidden" name="video_id" id="editVideoId">
                        
                        <div class="form-group">
                            <label for="editTitle">Video Title *</label>
                            <input type="text" id="editTitle" name="title" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="editDescription">Description</label>
                            <input type="text" id="editDescription" name="description">
                        </div>
                        
                        <div class="form-group">
                            <label for="editVideoUrl">Video URL *</label>
                            <input type="text" id="editVideoUrl" name="video_url" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="editPlatform">Platform *</label>
                            <select id="editPlatform" name="platform" required>
                                <option value="">Select Platform</option>
                                <option value="youtube">YouTube</option>
                                <option value="tiktok">TikTok</option>
                                <option value="instagram">Instagram</option>
                                <option value="facebook">Facebook</option>
                                <option value="twitter">Twitter</option>
                                <option value="linkedin">LinkedIn</option>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <label for="editFreeReward">Free User Reward (₦) *</label>
                            <input type="number" id="editFreeReward" name="free_reward" step="0.01" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="editPremiumReward">Premium User Reward (₦) *</label>
                            <input type="number" id="editPremiumReward" name="premium_reward" step="0.01" required>
                        </div>
                        
                        <div class="form-group">
                            <div class="checkbox-group">
                                <input type="checkbox" id="editIsCompulsory" name="is_compulsory" value="1">
                                <label for="editIsCompulsory">Mark as Compulsory Video</label>
                            </div>
                        </div>
                        
                        <div style="display: flex; gap: 12px; margin-top: 24px;">
                            <button type="button" onclick="closeEditModal()" style="flex: 1; padding: 10px; background: #e2e8f0; color: #1e293b; border: none; border-radius: 8px; cursor: pointer; font-weight: 600;">Cancel</button>
                            <button type="submit" style="flex: 1; padding: 10px; background: linear-gradient(135deg, #8b5cf6, #ec4899); color: white; border: none; border-radius: 8px; cursor: pointer; font-weight: 600;">Save Changes</button>
                        </div>
                    </form>
                </div>
            </div>
            
            <!-- Delete Confirmation Modal -->
            <div id="deleteModal" style="display: none; position: fixed; top: 0; left: 0; right: 0; bottom: 0; background: rgba(0,0,0,0.7); z-index: 1000; align-items: center; justify-content: center;">
                <div style="background: white; border-radius: 16px; padding: 32px; max-width: 400px; width: 90%;">
                    <h2 style="color: #1e293b; margin-bottom: 16px;">Delete Video?</h2>
                    <p style="color: #64748b; margin-bottom: 24px;">Are you sure you want to delete "<span id="deleteVideoTitle"></span>"? This action cannot be undone.</p>
                    
                    <div style="display: flex; gap: 12px;">
                        <button type="button" onclick="closeDeleteModal()" style="flex: 1; padding: 10px; background: #e2e8f0; color: #1e293b; border: none; border-radius: 8px; cursor: pointer; font-weight: 600;">Cancel</button>
                        <form method="POST" style="flex: 1;">
                            <input type="hidden" name="action" value="delete">
                            <input type="hidden" name="video_id" id="deleteVideoId">
                            <button type="submit" style="width: 100%; padding: 10px; background: #ef4444; color: white; border: none; border-radius: 8px; cursor: pointer; font-weight: 600;">Delete Video</button>
                        </form>
                    </div>
                </div>
            </div>
            
            <script>
                function editVideo(videoId) {
                    fetch('?get_video_json=' + videoId)
                        .then(response => response.json())
                        .then(data => {
                            if (data.success) {
                                const video = data.video;
                                document.getElementById('editVideoId').value = video.id;
                                document.getElementById('editTitle').value = video.title;
                                document.getElementById('editDescription').value = video.description;
                                document.getElementById('editVideoUrl').value = video.video_url;
                                document.getElementById('editPlatform').value = video.platform;
                                document.getElementById('editFreeReward').value = video.free_reward;
                                document.getElementById('editPremiumReward').value = video.premium_reward;
                                document.getElementById('editIsCompulsory').checked = video.is_compulsory == 1;
                                
                                document.getElementById('editModal').style.display = 'flex';
                            } else {
                                alert('Failed to load video data');
                            }
                        })
                        .catch(error => {
                            console.error('Error:', error);
                            alert('Failed to load video data');
                        });
                }
                
                function closeEditModal() {
                    document.getElementById('editModal').style.display = 'none';
                }
                
                function deleteVideo(videoId, videoTitle) {
                    document.getElementById('deleteVideoId').value = videoId;
                    document.getElementById('deleteVideoTitle').textContent = videoTitle;
                    document.getElementById('deleteModal').style.display = 'flex';
                }
                
                function closeDeleteModal() {
                    document.getElementById('deleteModal').style.display = 'none';
                }
                
                document.getElementById('editModal').addEventListener('click', function(e) {
                    if (e.target === this) closeEditModal();
                });
                
                document.getElementById('deleteModal').addEventListener('click', function(e) {
                    if (e.target === this) closeDeleteModal();
                });
            </script>
</div>
</body>
</html>
