<?php
session_start();
require_once '../config/database.php';

// Check if user is admin
if (!isset($_SESSION['user_id'])) {
    header('Location: ../login.php');
    exit();
}

$user_id = $_SESSION['user_id'];
$stmt = $conn->prepare("SELECT is_admin FROM users WHERE id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result()->fetch_assoc();

if (!$result || $result['is_admin'] != 1) {
    header('Location: ../dashboard.php');
    exit();
}

$success_message = '';
$error_message = '';

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    if ($_POST['action'] === 'add_skill') {
        $title = trim($_POST['title'] ?? '');
        $description = trim($_POST['description'] ?? '');
        $professor_name = trim($_POST['professor_name'] ?? '');
        $external_link = trim($_POST['external_link'] ?? '');
        $promo_badge = trim($_POST['promo_badge'] ?? '');
        $active_hours = !empty($_POST['active_hours']) ? intval($_POST['active_hours']) : null;
        
        // Handle image upload
        $image_url = '';
        if (isset($_FILES['skill_image']) && $_FILES['skill_image']['error'] === UPLOAD_ERR_OK) {
            $upload_dir = '../uploads/skills/';
            if (!file_exists($upload_dir)) {
                mkdir($upload_dir, 0777, true);
            }
            
            $file_extension = pathinfo($_FILES['skill_image']['name'], PATHINFO_EXTENSION);
            $file_name = 'skill_' . time() . '_' . uniqid() . '.' . $file_extension;
            $upload_path = $upload_dir . $file_name;
            
            if (move_uploaded_file($_FILES['skill_image']['tmp_name'], $upload_path)) {
                $image_url = 'uploads/skills/' . $file_name;
            }
        }
        
        // Validate inputs
        if (empty($title) || empty($external_link)) {
            $error_message = 'Title and External Link are required.';
        } elseif (!filter_var($external_link, FILTER_VALIDATE_URL)) {
            $error_message = 'Please provide a valid URL.';
        } else {
            // Insert skill into database
            $stmt = $conn->prepare("
                INSERT INTO skills 
                (title, description, professor_name, external_link, image_url, promo_badge, active_hours, is_active, created_at) 
                VALUES (?, ?, ?, ?, ?, ?, ?, 1, NOW())
            ");
            $stmt->bind_param("ssssssi", $title, $description, $professor_name, $external_link, $image_url, $promo_badge, $active_hours);
            
            if ($stmt->execute()) {
                $success_message = 'Skill posted successfully!';
                $_POST = [];
            } else {
                $error_message = 'Failed to post skill. Please try again.';
            }
        }
    } elseif ($_POST['action'] === 'edit_skill') {
        $skill_id = intval($_POST['skill_id'] ?? 0);
        $title = trim($_POST['title'] ?? '');
        $description = trim($_POST['description'] ?? '');
        $professor_name = trim($_POST['professor_name'] ?? '');
        $external_link = trim($_POST['external_link'] ?? '');
        $promo_badge = trim($_POST['promo_badge'] ?? '');
        $active_hours = !empty($_POST['active_hours']) ? intval($_POST['active_hours']) : null;
        
        if ($skill_id > 0 && !empty($title) && !empty($external_link)) {
            if (!filter_var($external_link, FILTER_VALIDATE_URL)) {
                $error_message = 'Please provide a valid URL.';
            } else {
                $stmt = $conn->prepare("
                    UPDATE skills 
                    SET title = ?, description = ?, professor_name = ?, external_link = ?, promo_badge = ?, active_hours = ?
                    WHERE id = ?
                ");
                $stmt->bind_param("sssssii", $title, $description, $professor_name, $external_link, $promo_badge, $active_hours, $skill_id);
                
                if ($stmt->execute()) {
                    $success_message = 'Skill updated successfully!';
                    $_POST = [];
                } else {
                    $error_message = 'Failed to update skill. Please try again.';
                }
            }
        }
    } elseif ($_POST['action'] === 'delete_skill') {
        $skill_id = intval($_POST['skill_id'] ?? 0);
        if ($skill_id > 0) {
            $stmt = $conn->prepare("DELETE FROM skills WHERE id = ?");
            $stmt->bind_param("i", $skill_id);
            if ($stmt->execute()) {
                $success_message = 'Skill deleted successfully!';
            } else {
                $error_message = 'Failed to delete skill.';
            }
        }
    } elseif ($_POST['action'] === 'toggle_active') {
        $skill_id = intval($_POST['skill_id'] ?? 0);
        $is_active = intval($_POST['is_active'] ?? 0);
        if ($skill_id > 0) {
            $stmt = $conn->prepare("UPDATE skills SET is_active = ? WHERE id = ?");
            $stmt->bind_param("ii", $is_active, $skill_id);
            if ($stmt->execute()) {
                $success_message = 'Skill status updated!';
            }
        }
    }
}

// Fetch all skills
$skills = $conn->query("
    SELECT * FROM skills 
    ORDER BY created_at DESC
")->fetch_all(MYSQLI_ASSOC);

// Get skill to edit if edit_id is provided
$edit_skill = null;
if (isset($_GET['edit_id'])) {
    $edit_id = intval($_GET['edit_id']);
    $stmt = $conn->prepare("SELECT * FROM skills WHERE id = ?");
    $stmt->bind_param("i", $edit_id);
    $stmt->execute();
    $edit_skill = $stmt->get_result()->fetch_assoc();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Manage Skills - FlowEarner Admin</title>
  <style>
    :root {
      --admin-primary: #6366f1;
      --admin-secondary: #8b5cf6;
      --admin-success: #10b981;
      --admin-warning: #f59e0b;
      --admin-danger: #ef4444;
      --admin-dark: #1e293b;
      --admin-light: #f1f5f9;
    }

    * { box-sizing: border-box; margin: 0; padding: 0; }

    body {
      font-family: "Inter", "Segoe UI", sans-serif;
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      min-height: 100vh;
    }

    .admin-main {
      padding: 32px;
      overflow-y: auto;
    }

    .admin-header {
      background: white;
      padding: 24px;
      border-radius: 16px;
      margin-bottom: 32px;
      box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    }

    .admin-header h1 {
      font-size: 2rem;
      color: var(--admin-dark);
      margin-bottom: 8px;
    }

    .form-container {
      background: white;
      padding: 32px;
      border-radius: 16px;
      box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
      margin-bottom: 32px;
    }

    .form-group {
      margin-bottom: 24px;
    }

    .form-group label {
      display: block;
      font-weight: 600;
      color: var(--admin-dark);
      margin-bottom: 8px;
    }

    .form-group input,
    .form-group textarea {
      width: 100%;
      padding: 12px 16px;
      border: 1px solid #e2e8f0;
      border-radius: 8px;
      font-size: 1rem;
      font-family: inherit;
      transition: border-color 0.3s;
    }

    .form-group input:focus,
    .form-group textarea:focus {
      outline: none;
      border-color: var(--admin-primary);
    }

    .form-group textarea {
      min-height: 100px;
      resize: vertical;
    }

    .form-group small {
      display: block;
      margin-top: 6px;
      color: #64748b;
      font-size: 0.875rem;
    }

    .form-row {
      display: grid;
      grid-template-columns: repeat(2, 1fr);
      gap: 16px;
    }

    .btn-primary {
      background: var(--admin-primary);
      color: white;
      padding: 14px 32px;
      border: none;
      border-radius: 8px;
      font-size: 1rem;
      font-weight: 600;
      cursor: pointer;
      transition: all 0.3s;
    }

    .btn-primary:hover {
      background: var(--admin-secondary);
      transform: translateY(-2px);
    }

    .btn-secondary {
      background: #64748b;
      color: white;
      padding: 14px 32px;
      border: none;
      border-radius: 8px;
      font-size: 1rem;
      font-weight: 600;
      cursor: pointer;
      transition: all 0.3s;
      margin-left: 10px;
    }

    .btn-secondary:hover {
      background: #475569;
      transform: translateY(-2px);
    }

    .btn-danger {
      background: var(--admin-danger);
      color: white;
      padding: 8px 16px;
      border: none;
      border-radius: 6px;
      font-size: 0.875rem;
      font-weight: 600;
      cursor: pointer;
      transition: all 0.3s;
    }

    .btn-edit {
      background: var(--admin-secondary);
      color: white;
      padding: 8px 16px;
      border: none;
      border-radius: 6px;
      font-size: 0.875rem;
      font-weight: 600;
      cursor: pointer;
      transition: all 0.3s;
      margin-right: 6px;
    }

    .btn-toggle {
      background: var(--admin-warning);
      color: white;
      padding: 8px 16px;
      border: none;
      border-radius: 6px;
      font-size: 0.875rem;
      font-weight: 600;
      cursor: pointer;
      transition: all 0.3s;
    }

    .alert {
      padding: 16px;
      border-radius: 8px;
      margin-bottom: 24px;
    }

    .alert-success {
      background: rgba(16, 185, 129, 0.1);
      border: 1px solid var(--admin-success);
      color: var(--admin-success);
    }

    .alert-error {
      background: rgba(239, 68, 68, 0.1);
      border: 1px solid var(--admin-danger);
      color: var(--admin-danger);
    }

    .skills-table {
      background: white;
      padding: 24px;
      border-radius: 16px;
      box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
      overflow-x: auto;
    }

    .skills-table h2 {
      font-size: 1.5rem;
      color: var(--admin-dark);
      margin-bottom: 16px;
    }

    table {
      width: 100%;
      border-collapse: collapse;
    }

    th, td {
      padding: 12px;
      text-align: left;
      border-bottom: 1px solid #e2e8f0;
    }

    th {
      font-weight: 600;
      color: var(--admin-dark);
      background: var(--admin-light);
    }

    .badge {
      display: inline-block;
      padding: 4px 12px;
      border-radius: 12px;
      font-size: 0.875rem;
      font-weight: 600;
    }

    .badge-active {
      background: rgba(16, 185, 129, 0.1);
      color: var(--admin-success);
    }

    .badge-inactive {
      background: rgba(100, 116, 139, 0.1);
      color: #64748b;
    }

    .skill-image-preview {
      width: 80px;
      height: 60px;
      object-fit: cover;
      border-radius: 8px;
    }

    .form-actions {
      display: flex;
      gap: 10px;
    }

    @media (max-width: 960px) {
      .form-row {
        grid-template-columns: 1fr;
      }
    }

    @media (max-width: 768px) {
      .admin-main {
        padding: 16px;
      }

      .admin-header {
        padding: 16px;
        margin-bottom: 16px;
      }

      .admin-header h1 {
        font-size: 1.5rem;
        margin-bottom: 4px;
      }

      .admin-header p {
        font-size: 0.9rem;
      }

      .form-container {
        padding: 16px;
        margin-bottom: 16px;
      }

      .form-container h2 {
        font-size: 1.2rem;
        margin-bottom: 16px;
      }

      .form-group {
        margin-bottom: 16px;
      }

      .form-group label {
        font-size: 0.9rem;
        margin-bottom: 6px;
      }

      .form-group input,
      .form-group textarea {
        padding: 10px 12px;
        font-size: 16px;
      }

      .form-group textarea {
        min-height: 80px;
      }

      .form-row {
        grid-template-columns: 1fr;
        gap: 12px;
      }

      .btn-primary,
      .btn-secondary {
        padding: 12px 24px;
        font-size: 0.95rem;
        width: 100%;
      }

      .btn-secondary {
        margin-left: 0;
        margin-top: 8px;
      }

      .alert {
        padding: 12px;
        font-size: 0.9rem;
      }

      .skills-table {
        padding: 16px;
        overflow-x: auto;
        -webkit-overflow-scrolling: touch;
      }

      .skills-table h2 {
        font-size: 1.2rem;
        margin-bottom: 12px;
      }

      table {
        min-width: 700px;
        display: inline-block;
      }

      th, td {
        padding: 10px 8px;
        font-size: 0.8rem;
      }

      .badge {
        padding: 3px 8px;
        font-size: 0.75rem;
      }

      .btn-edit,
      .btn-danger,
      .btn-toggle {
        padding: 6px 10px;
        font-size: 0.75rem;
      }

      .skill-image-preview {
        width: 60px;
        height: 45px;
      }
    }
  </style>
</head>
<body>
  <?php include 'side-bar.php'; ?>
  <div class="admin-content">
    <main class="admin-main">
      <div class="admin-header">
        <h1><?php echo $edit_skill ? 'Edit Skill' : 'Manage Skills'; ?></h1>
        <p style="color: #64748b;">Post and manage learning opportunities for premium members.</p>
      </div>

      <?php if ($success_message): ?>
        <div class="alert alert-success"><?php echo $success_message; ?></div>
      <?php endif; ?>

      <?php if ($error_message): ?>
        <div class="alert alert-error"><?php echo $error_message; ?></div>
      <?php endif; ?>

      <div class="form-container">
        <h2 style="margin-bottom: 24px; color: var(--admin-dark);"><?php echo $edit_skill ? 'Edit Skill' : 'Add New Skill'; ?></h2>
        <form method="POST" action="" enctype="multipart/form-data">
          <input type="hidden" name="action" value="<?php echo $edit_skill ? 'edit_skill' : 'add_skill'; ?>">
          <?php if ($edit_skill): ?>
            <input type="hidden" name="skill_id" value="<?php echo $edit_skill['id']; ?>">
          <?php endif; ?>
          
          <div class="form-group">
            <label for="title">Skill Title *</label>
            <input type="text" id="title" name="title" required placeholder="e.g., Advanced Web Development" value="<?php echo $edit_skill ? htmlspecialchars($edit_skill['title']) : ''; ?>">
          </div>

          <div class="form-group">
            <label for="description">Description</label>
            <textarea id="description" name="description" placeholder="Brief description of the skill or course..."><?php echo $edit_skill ? htmlspecialchars($edit_skill['description']) : ''; ?></textarea>
            <small>Optional - Leave blank to skip</small>
          </div>

          <div class="form-row">
            <div class="form-group">
              <label for="professor_name">Professor Name</label>
              <input type="text" id="professor_name" name="professor_name" placeholder="e.g., John Smith" value="<?php echo $edit_skill ? htmlspecialchars($edit_skill['professor_name']) : ''; ?>">
              <small>Optional - Leave blank to skip</small>
            </div>

            <div class="form-group">
              <label for="active_hours">Active Hours</label>
              <input type="number" id="active_hours" name="active_hours" min="1" placeholder="e.g., 2, 3, 24" value="<?php echo $edit_skill && $edit_skill['active_hours'] ? $edit_skill['active_hours'] : ''; ?>">
              <small>Optional - Leave blank to skip time badge</small>
            </div>
          </div>

          <div class="form-row">
            <div class="form-group">
              <label for="promo_badge">Promo Badge</label>
              <input type="text" id="promo_badge" name="promo_badge" placeholder="e.g., NEW, HOT, LIMITED" value="<?php echo $edit_skill ? htmlspecialchars($edit_skill['promo_badge']) : ''; ?>">
              <small>Optional - Leave blank to skip promo badge</small>
            </div>

            <div class="form-group">
              <label for="skill_image">Skill Image</label>
              <input type="file" id="skill_image" name="skill_image" accept="image/*">
              <small>Optional - Recommended size: 640x400px</small>
            </div>
          </div>

          <div class="form-group">
            <label for="external_link">External Link *</label>
            <input type="url" id="external_link" name="external_link" required placeholder="https://..." value="<?php echo $edit_skill ? htmlspecialchars($edit_skill['external_link']) : ''; ?>">
            <small>Link to the course or learning resource</small>
          </div>

          <div class="form-actions">
            <button type="submit" class="btn-primary"><?php echo $edit_skill ? 'Update Skill' : 'Post Skill'; ?></button>
            <?php if ($edit_skill): ?>
              <a href="admin-skill-require.php" class="btn-secondary" style="text-decoration: none; display: inline-block; text-align: center;">Cancel</a>
            <?php endif; ?>
          </div>
        </form>
      </div>

      <div class="skills-table">
        <h2>All Skills</h2>
        <?php if (empty($skills)): ?>
          <p style="color: #64748b; text-align: center; padding: 32px;">No skills posted yet.</p>
        <?php else: ?>
          <table>
            <thead>
              <tr>
                <th>Image</th>
                <th>Title</th>
                <th>Professor</th>
                <th>Clicks</th>
                <th>Status</th>
                <th>Created</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              <?php foreach ($skills as $skill): ?>
                <tr>
                  <td>
                    <?php if (!empty($skill['image_url'])): ?>
                      <img src="../<?php echo htmlspecialchars($skill['image_url']); ?>" alt="Skill" class="skill-image-preview">
                    <?php else: ?>
                      <div style="width: 80px; height: 60px; background: #e2e8f0; border-radius: 8px;"></div>
                    <?php endif; ?>
                  </td>
                  <td>
                    <strong><?php echo htmlspecialchars($skill['title']); ?></strong>
                    <?php if (!empty($skill['promo_badge'])): ?>
                      <br><small style="color: #f59e0b;"><?php echo htmlspecialchars($skill['promo_badge']); ?></small>
                    <?php endif; ?>
                  </td>
                  <td><?php echo !empty($skill['professor_name']) ? htmlspecialchars($skill['professor_name']) : '-'; ?></td>
                  <td><?php echo number_format($skill['clicks']); ?></td>
                  <td>
                    <?php if ($skill['is_active']): ?>
                      <span class="badge badge-active">Active</span>
                    <?php else: ?>
                      <span class="badge badge-inactive">Inactive</span>
                    <?php endif; ?>
                  </td>
                  <td><?php echo date('M d, Y', strtotime($skill['created_at'])); ?></td>
                  <td>
                    <a href="admin-skill-require.php?edit_id=<?php echo $skill['id']; ?>" class="btn-edit">Edit</a>
                    <form method="POST" style="display: inline;">
                      <input type="hidden" name="action" value="toggle_active">
                      <input type="hidden" name="skill_id" value="<?php echo $skill['id']; ?>">
                      <input type="hidden" name="is_active" value="<?php echo $skill['is_active'] ? 0 : 1; ?>">
                      <button type="submit" class="btn-toggle"><?php echo $skill['is_active'] ? 'Deactivate' : 'Activate'; ?></button>
                    </form>
                    <form method="POST" style="display: inline;" onsubmit="return confirm('Are you sure you want to delete this skill?');">
                      <input type="hidden" name="action" value="delete_skill">
                      <input type="hidden" name="skill_id" value="<?php echo $skill['id']; ?>">
                      <button type="submit" class="btn-danger">Delete</button>
                    </form>
                  </td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        <?php endif; ?>
      </div>
    </main>
  </div>
</body>
</html>
