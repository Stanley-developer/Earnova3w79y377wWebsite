<?php
session_start();
require_once '../config/database.php';

// Check if user is admin
if (!isset($_SESSION['user_id'])) {
    header('Location: ../login.php');
    exit();
}

$user_id = $_SESSION['user_id'];
$stmt = $conn->prepare("SELECT is_admin FROM users WHERE id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result()->fetch_assoc();

if (!$result || $result['is_admin'] != 1) {
    header('Location: ../dashboard.php');
    exit();
}

// Handle notification actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        switch ($_POST['action']) {
            case 'create':
                $title = trim($_POST['title']);
                $message = trim($_POST['message']);
                $is_active = isset($_POST['is_active']) ? 1 : 0;
                $target_type = isset($_POST['target_type']) ? $_POST['target_type'] : 'all';
                
                if (!empty($title) && !empty($message)) {
                    $stmt = $conn->prepare("INSERT INTO admin_messages (title, message, is_active, target_type) VALUES (?, ?, ?, ?)");
                    $stmt->bind_param("ssis", $title, $message, $is_active, $target_type);
                    if ($stmt->execute()) {
                        $message_id = $stmt->insert_id;
                        
                        // If target_type is 'specific', save recipients
                        if ($target_type === 'specific' && isset($_POST['selected_users'])) {
                            $selected_users = json_decode($_POST['selected_users'], true);
                            if (!empty($selected_users)) {
                                $stmt = $conn->prepare("INSERT INTO notification_recipients (message_id, user_id) VALUES (?, ?)");
                                foreach ($selected_users as $uid) {
                                    $uid = intval($uid);
                                    $stmt->bind_param("ii", $message_id, $uid);
                                    $stmt->execute();
                                }
                            }
                        }
                        
                        $success_message = "Notification created successfully!";
                    } else {
                        $error_message = "Failed to create notification.";
                    }
                }
                break;
                
            case 'toggle':
                $msg_id = intval($_POST['message_id']);
                $stmt = $conn->prepare("UPDATE admin_messages SET is_active = NOT is_active WHERE id = ?");
                $stmt->bind_param("i", $msg_id);
                $stmt->execute();
                $success_message = "Notification status updated!";
                break;
                
            case 'delete':
                $msg_id = intval($_POST['message_id']);
                $stmt = $conn->prepare("DELETE FROM admin_messages WHERE id = ?");
                $stmt->bind_param("i", $msg_id);
                $stmt->execute();
                $success_message = "Notification deleted successfully!";
                break;
        }
    }
}

// Fetch all notifications with recipient and read count
$query = "
    SELECT 
        am.id,
        am.title,
        am.message,
        am.is_active,
        am.created_at,
        am.updated_at,
        IFNULL(am.target_type, 'all') as target_type,
        COUNT(DISTINCT umr.user_id) as read_count,
        (SELECT COUNT(*) FROM users WHERE status = 'active') as total_users,
        (SELECT COUNT(*) FROM notification_recipients WHERE message_id = am.id) as specific_recipient_count
    FROM admin_messages am
    LEFT JOIN user_message_reads umr ON am.id = umr.message_id
    GROUP BY am.id, am.title, am.message, am.is_active, am.created_at, am.updated_at, am.target_type
    ORDER BY am.created_at DESC
";
$notifications = $conn->query($query)->fetch_all(MYSQLI_ASSOC);

// Calculate recipient count for each notification
foreach ($notifications as &$notif) {
    if ($notif['target_type'] === 'specific') {
        $notif['recipient_count'] = intval($notif['specific_recipient_count']);
    } else {
        $notif['recipient_count'] = intval($notif['total_users']);
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Manage Notifications - FlowEarner Admin</title>
  <style>
    :root {
      --admin-primary: #6366f1;
      --admin-secondary: #8b5cf6;
      --admin-success: #10b981;
      --admin-warning: #f59e0b;
      --admin-danger: #ef4444;
      --admin-dark: #1e293b;
      --admin-light: #f1f5f9;
    }

    * { box-sizing: border-box; margin: 0; padding: 0; }

    body {
      font-family: "Inter", "Segoe UI", sans-serif;
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      min-height: 100vh;
    }

    .admin-main {
      padding: 32px;
      overflow-y: auto;
    }

    .admin-header {
      background: white;
      padding: 24px;
      border-radius: 16px;
      margin-bottom: 32px;
      box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    }

    .admin-header h1 {
      font-size: 2rem;
      color: var(--admin-dark);
      margin-bottom: 8px;
    }

    .create-form {
      background: white;
      padding: 24px;
      border-radius: 16px;
      margin-bottom: 32px;
      box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    }

    .create-form h2 {
      color: var(--admin-dark);
      margin-bottom: 20px;
      font-size: 1.5rem;
    }

    .form-group {
      margin-bottom: 20px;
    }

    .form-group label {
      display: block;
      margin-bottom: 8px;
      color: var(--admin-dark);
      font-weight: 600;
      font-size: 0.9rem;
    }

    .form-group input[type="text"],
    .form-group textarea,
    .form-group select {
      width: 100%;
      padding: 12px 16px;
      border: 1px solid #e2e8f0;
      border-radius: 8px;
      font-size: 0.95rem;
      font-family: inherit;
    }

    .form-group textarea {
      min-height: 120px;
      resize: vertical;
    }

    .form-row {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 20px;
    }

    .target-type-section {
      display: flex;
      gap: 20px;
      margin: 20px 0;
    }

    .target-option {
      display: flex;
      align-items: center;
      gap: 8px;
      cursor: pointer;
    }

    .target-option input[type="radio"] {
      width: 20px;
      height: 20px;
      cursor: pointer;
    }

    .user-selection-panel {
      display: none;
      margin-top: 20px;
      padding: 16px;
      background: #f8fafc;
      border-radius: 8px;
      border: 1px solid #e2e8f0;
    }

    .user-selection-panel.active {
      display: block;
    }

    .user-search {
      margin-bottom: 16px;
    }

    .user-search input {
      width: 100%;
      padding: 10px 16px;
      border: 1px solid #e2e8f0;
      border-radius: 8px;
      font-size: 0.95rem;
    }

    .user-list {
      max-height: 300px;
      overflow-y: auto;
      border: 1px solid #e2e8f0;
      border-radius: 8px;
      background: white;
    }

    .user-item {
      padding: 12px 16px;
      border-bottom: 1px solid #e2e8f0;
      display: flex;
      align-items: center;
      gap: 12px;
      cursor: pointer;
      transition: background 0.2s;
    }

    .user-item:hover {
      background: #f1f5f9;
    }

    .user-item input[type="checkbox"] {
      width: 20px;
      height: 20px;
      cursor: pointer;
    }

    .user-info {
      flex: 1;
      display: flex;
      flex-direction: column;
    }

    .user-name {
      font-weight: 600;
      color: var(--admin-dark);
    }

    .user-email {
      font-size: 0.85rem;
      color: #64748b;
    }

    .selected-users-count {
      display: inline-block;
      padding: 4px 12px;
      background: var(--admin-primary);
      color: white;
      border-radius: 12px;
      font-size: 0.85rem;
      font-weight: 600;
      margin-top: 10px;
    }

    .checkbox-group {
      display: flex;
      align-items: center;
      gap: 8px;
    }

    .checkbox-group input[type="checkbox"] {
      width: 20px;
      height: 20px;
      cursor: pointer;
    }

    .btn-primary {
      padding: 12px 24px;
      background: var(--admin-primary);
      color: white;
      border: none;
      border-radius: 8px;
      cursor: pointer;
      font-weight: 600;
      font-size: 1rem;
      transition: all 0.3s;
    }

    .btn-primary:hover {
      background: var(--admin-secondary);
      transform: translateY(-2px);
      box-shadow: 0 4px 12px rgba(99, 102, 241, 0.3);
    }

    .notifications-list {
      display: grid;
      gap: 20px;
    }

    .notification-card {
      background: white;
      padding: 24px;
      border-radius: 16px;
      box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
      position: relative;
    }

    .notification-card.inactive {
      opacity: 0.6;
      border-left: 4px solid var(--admin-danger);
    }

    .notification-card.active {
      border-left: 4px solid var(--admin-success);
    }

    .notification-header {
      display: flex;
      justify-content: space-between;
      align-items: start;
      margin-bottom: 12px;
    }

    .notification-title {
      font-size: 1.25rem;
      font-weight: 700;
      color: var(--admin-dark);
      margin-bottom: 4px;
    }

    .notification-meta {
      font-size: 0.85rem;
      color: #64748b;
      margin-bottom: 12px;
    }

    .notification-message {
      color: #475569;
      line-height: 1.6;
      margin-bottom: 16px;
    }

    .notification-stats {
      display: flex;
      gap: 20px;
      margin-bottom: 16px;
      padding: 12px;
      background: var(--admin-light);
      border-radius: 8px;
    }

    .stat-item {
      display: flex;
      flex-direction: column;
    }

    .stat-label {
      font-size: 0.75rem;
      color: #64748b;
      text-transform: uppercase;
      letter-spacing: 0.05em;
    }

    .stat-value {
      font-size: 1.25rem;
      font-weight: 700;
      color: var(--admin-dark);
    }

    .notification-target {
      display: inline-block;
      padding: 4px 12px;
      background: #e0e7ff;
      color: #4f46e5;
      border-radius: 12px;
      font-size: 0.75rem;
      font-weight: 600;
      margin-bottom: 12px;
      text-transform: uppercase;
    }

    .notification-actions {
      display: flex;
      gap: 8px;
      flex-wrap: wrap;
    }

    .action-btn {
      padding: 8px 16px;
      border: none;
      border-radius: 6px;
      cursor: pointer;
      font-size: 0.85rem;
      font-weight: 600;
      transition: all 0.3s;
    }

    .btn-toggle {
      background: #fef3c7;
      color: #92400e;
    }

    .btn-delete {
      background: #fecaca;
      color: #7f1d1d;
    }

    .action-btn:hover {
      transform: translateY(-2px);
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.15);
    }

    .badge {
      display: inline-block;
      padding: 4px 12px;
      border-radius: 12px;
      font-size: 0.75rem;
      font-weight: 600;
      text-transform: uppercase;
    }

    .badge-active {
      background: #d1fae5;
      color: #065f46;
    }

    .badge-inactive {
      background: #fee2e2;
      color: #991b1b;
    }

    .alert {
      padding: 16px;
      border-radius: 12px;
      margin-bottom: 24px;
      font-weight: 600;
    }

    .alert-success {
      background: #d1fae5;
      color: #065f46;
    }

    .alert-error {
      background: #fee2e2;
      color: #991b1b;
    }

    .empty-state {
      text-align: center;
      padding: 60px 20px;
      color: #64748b;
    }

    .empty-state svg {
      width: 80px;
      height: 80px;
      margin-bottom: 16px;
      opacity: 0.5;
    }

    @media (max-width: 1024px) {
      .form-row {
        grid-template-columns: 1fr;
      }
      
      .admin-main {
        padding: 20px;
      }

      .admin-header {
        padding: 16px;
        margin-bottom: 20px;
      }

      .admin-header h1 {
        font-size: 1.5rem;
      }

      .create-form {
        padding: 16px;
        margin-bottom: 20px;
      }

      .create-form h2 {
        font-size: 1.2rem;
        margin-bottom: 12px;
      }

      .form-group {
        margin-bottom: 12px;
      }

      .notification-card {
        padding: 16px;
      }

      .notification-title {
        font-size: 1.1rem;
      }

      .notification-stats {
        gap: 12px;
        padding: 10px;
      }

      .stat-value {
        font-size: 1.1rem;
      }
    }

    @media (max-width: 768px) {
      .admin-main {
        padding: 12px;
      }

      .admin-header {
        padding: 12px;
        margin-bottom: 12px;
        border-radius: 12px;
      }

      .admin-header h1 {
        font-size: 1.2rem;
        margin-bottom: 4px;
      }

      .admin-header p {
        font-size: 0.8rem;
      }

      .create-form {
        padding: 12px;
        margin-bottom: 12px;
        border-radius: 12px;
      }

      .create-form h2 {
        font-size: 1rem;
        margin-bottom: 10px;
      }

      .form-group {
        margin-bottom: 10px;
      }

      .form-group label {
        font-size: 0.85rem;
        margin-bottom: 4px;
      }

      .form-group input[type="text"],
      .form-group textarea,
      .form-group select {
        padding: 10px 12px;
        font-size: 0.9rem;
      }

      .form-group textarea {
        min-height: 80px;
      }

      .checkbox-group {
        font-size: 0.9rem;
      }

      .btn-primary {
        padding: 10px 16px;
        font-size: 0.9rem;
        width: 100%;
      }

      .target-type-section {
        flex-direction: column;
      }

      .notification-card {
        padding: 12px;
        border-radius: 12px;
      }

      .notification-header {
        flex-direction: column;
        margin-bottom: 8px;
      }

      .notification-title {
        font-size: 1rem;
        margin-bottom: 2px;
      }

      .notification-meta {
        font-size: 0.75rem;
        margin-bottom: 8px;
      }

      .notification-message {
        font-size: 0.9rem;
        margin-bottom: 10px;
      }

      .notification-stats {
        flex-direction: row;
        gap: 8px;
        margin-bottom: 10px;
        padding: 8px;
      }

      .stat-item {
        flex: 1;
      }

      .stat-label {
        font-size: 0.65rem;
      }

      .stat-value {
        font-size: 1rem;
      }

      .action-btn {
        padding: 6px 12px;
        font-size: 0.75rem;
      }

      .notifications-list {
        gap: 10px;
      }

      .alert {
        padding: 12px;
        margin-bottom: 12px;
        font-size: 0.9rem;
      }

      .user-list {
        max-height: 200px;
      }

      .user-item {
        padding: 10px 12px;
      }
    }

    @media (max-width: 480px) {
      .admin-main {
        padding: 8px;
      }

      .admin-header {
        padding: 10px;
        margin-bottom: 10px;
      }

      .admin-header h1 {
        font-size: 1rem;
        margin-bottom: 2px;
      }

      .admin-header p {
        font-size: 0.75rem;
      }

      .create-form {
        padding: 10px;
        margin-bottom: 10px;
      }

      .create-form h2 {
        font-size: 0.95rem;
        margin-bottom: 8px;
      }

      .form-group {
        margin-bottom: 8px;
      }

      .form-group label {
        font-size: 0.8rem;
        margin-bottom: 3px;
      }

      .form-group input[type="text"],
      .form-group textarea,
      .form-group select {
        padding: 8px 10px;
        font-size: 16px;
      }

      .form-group textarea {
        min-height: 70px;
      }

      .btn-primary {
        padding: 9px 12px;
        font-size: 0.85rem;
      }

      .notification-card {
        padding: 10px;
        margin-bottom: 8px;
      }

      .notification-title {
        font-size: 0.95rem;
      }

      .notification-meta {
        font-size: 0.7rem;
        margin-bottom: 6px;
      }

      .notification-message {
        font-size: 0.85rem;
        margin-bottom: 8px;
        line-height: 1.4;
      }

      .notification-stats {
        flex-direction: column;
        gap: 6px;
        margin-bottom: 8px;
        padding: 6px;
      }

      .stat-label {
        font-size: 0.6rem;
      }

      .stat-value {
        font-size: 0.9rem;
      }

      .action-btn {
        padding: 5px 10px;
        font-size: 0.7rem;
      }

      .notifications-list {
        gap: 8px;
      }

      .alert {
        padding: 10px;
        margin-bottom: 10px;
        font-size: 0.85rem;
      }

      .empty-state {
        padding: 30px 10px;
      }

      .empty-state svg {
        width: 60px;
        height: 60px;
      }
    }
  </style>
</head>
<body>

  <?php include 'side-bar.php'; ?>
  
  <div class="admin-content">
    <main class="admin-main">
      <div class="admin-header">
        <h1>Manage Notifications</h1>
        <p style="color: #64748b;">Create and manage dashboard notifications for users</p>
      </div>

      <?php if (isset($success_message)): ?>
        <div class="alert alert-success"><?php echo $success_message; ?></div>
      <?php endif; ?>

      <?php if (isset($error_message)): ?>
        <div class="alert alert-error"><?php echo $error_message; ?></div>
      <?php endif; ?>

      <div class="create-form">
        <h2>Create New Notification</h2>
        <form method="POST" id="notificationForm">
          <input type="hidden" name="action" value="create" />
          <input type="hidden" name="selected_users" id="selectedUsersInput" value="[]" />
          
          <div class="form-group">
            <label for="title">Notification Title</label>
            <input type="text" id="title" name="title" placeholder="Enter notification title..." required />
          </div>

          <div class="form-group">
            <label for="message">Notification Message</label>
            <textarea id="message" name="message" placeholder="Enter notification message..." required></textarea>
          </div>

          <div class="form-group">
            <label>Send Notification To:</label>
            <div class="target-type-section">
              <label class="target-option">
                <input type="radio" name="target_type" value="all" checked onChange="toggleUserSelection()" />
                <span>All Active Users</span>
              </label>
              <label class="target-option">
                <input type="radio" name="target_type" value="specific" onChange="toggleUserSelection()" />
                <span>Select Specific Users</span>
              </label>
            </div>
          </div>

          <div id="userSelectionPanel" class="user-selection-panel">
            <div class="user-search">
              <input type="text" id="userSearchInput" placeholder="Search users by name or email..." />
            </div>
            <div class="user-list" id="userList"></div>
            <div class="selected-users-count">
              Selected: <span id="selectedCount">0</span> users
            </div>
          </div>

          <div class="form-group">
            <div class="checkbox-group">
              <input type="checkbox" id="is_active" name="is_active" checked />
              <label for="is_active" style="margin: 0;">Activate immediately</label>
            </div>
          </div>

          <button type="submit" class="btn-primary">Create Notification</button>
        </form>
      </div>

      <div class="notifications-list">
        <?php if (empty($notifications)): ?>
          <div class="notification-card">
            <div class="empty-state">
              <svg viewBox="0 0 24 24" fill="currentColor">
                <path d="M12 22c1.1 0 2-.9 2-2h-4c0 1.1.9 2 2 2zm6-6v-5c0-3.07-1.63-5.64-4.5-6.32V4c0-.83-.67-1.5-1.5-1.5s-1.5.67-1.5 1.5v.68C7.64 5.36 6 7.92 6 11v5l-2 2v1h16v-1l-2-2zm-2 1H8v-6c0-2.48 1.51-4.5 4-4.5s4 2.02 4 4.5v6z"/>
              </svg>
              <h3>No notifications yet</h3>
              <p>Create your first notification to get started</p>
            </div>
          </div>
        <?php else: ?>
          <?php foreach ($notifications as $notif): ?>
            <div class="notification-card <?php echo $notif['is_active'] ? 'active' : 'inactive'; ?>">
              <div class="notification-header">
                <div style="flex: 1;">
                  <div class="notification-title"><?php echo htmlspecialchars($notif['title']); ?></div>
                  <div class="notification-meta">
                    Created: <?php echo date('M d, Y \a\t g:i A', strtotime($notif['created_at'])); ?>
                    <span class="badge badge-<?php echo $notif['is_active'] ? 'active' : 'inactive'; ?>">
                      <?php echo $notif['is_active'] ? 'Active' : 'Inactive'; ?>
                    </span>
                  </div>
                  <div class="notification-target">
                    <?php echo $notif['target_type'] === 'specific' ? ' Specific Users' : ' All Users'; ?>
                  </div>
                </div>
              </div>

              <div class="notification-message">
                <?php echo nl2br(htmlspecialchars($notif['message'])); ?>
              </div>

              <div class="notification-stats">
                <div class="stat-item">
                  <span class="stat-label">Recipients</span>
                  <span class="stat-value"><?php echo number_format($notif['recipient_count']); ?></span>
                </div>
                <div class="stat-item">
                  <span class="stat-label">Views</span>
                  <span class="stat-value"><?php echo number_format($notif['read_count']); ?></span>
                </div>
                <div class="stat-item">
                  <span class="stat-label">View Rate</span>
                  <span class="stat-value">
                    <?php 
                      $rate = $notif['recipient_count'] > 0 ? ($notif['read_count'] / $notif['recipient_count']) * 100 : 0;
                      echo number_format($rate, 1) . '%';
                    ?>
                  </span>
                </div>
              </div>

              <div class="notification-actions">
                <button type="button" class="action-btn" style="background: #c7d2fe; color: #4338ca; cursor: pointer;" onclick="viewReaders(<?php echo $notif['id']; ?>, '<?php echo htmlspecialchars($notif['title']); ?>')">
                  ️ View Readers (<?php echo $notif['read_count']; ?>)
                </button>

                <form method="POST" style="display: inline;">
                  <input type="hidden" name="action" value="toggle" />
                  <input type="hidden" name="message_id" value="<?php echo $notif['id']; ?>" />
                  <button type="submit" class="action-btn btn-toggle">
                    <?php echo $notif['is_active'] ? 'Deactivate' : 'Activate'; ?>
                  </button>
                </form>

                <form method="POST" style="display: inline;">
                  <input type="hidden" name="action" value="delete" />
                  <input type="hidden" name="message_id" value="<?php echo $notif['id']; ?>" />
                  <button type="submit" class="action-btn btn-delete" onclick="return confirm('Are you sure you want to delete this notification?')">
                    Delete
                  </button>
                </form>
              </div>
            </div>
          <?php endforeach; ?>
        <?php endif; ?>
      </div>
    </main>
  </div>

  <script>
    let allUsers = [];
    let selectedUsers = new Set();

    function toggleUserSelection() {
      const panel = document.getElementById('userSelectionPanel');
      const targetType = document.querySelector('input[name="target_type"]:checked').value;
      
      if (targetType === 'specific') {
        panel.classList.add('active');
        if (allUsers.length === 0) {
          loadUsers();
        }
      } else {
        panel.classList.remove('active');
        selectedUsers.clear();
        updateSelectedCount();
      }
    }

    function loadUsers() {
      fetch('api/get-users.php')
        .then(res => res.json())
        .then(data => {
          allUsers = data;
          renderUserList(allUsers);
        })
        .catch(err => console.error('Error loading users:', err));
    }

    function renderUserList(users) {
      const userList = document.getElementById('userList');
      userList.innerHTML = '';
      
      users.forEach(user => {
        const userItem = document.createElement('div');
        userItem.className = 'user-item';
        
        const checked = selectedUsers.has(user.id) ? 'checked' : '';
        userItem.innerHTML = `
          <input type="checkbox" value="${user.id}" ${checked} onChange="toggleUserSelection2(this)" />
          <div class="user-info">
            <div class="user-name">${escapeHtml(user.username)}</div>
            <div class="user-email">${escapeHtml(user.email)}</div>
          </div>
        `;
        
        userList.appendChild(userItem);
      });
    }

    function toggleUserSelection2(checkbox) {
      const userId = parseInt(checkbox.value);
      if (checkbox.checked) {
        selectedUsers.add(userId);
      } else {
        selectedUsers.delete(userId);
      }
      updateSelectedCount();
    }

    function updateSelectedCount() {
      document.getElementById('selectedCount').textContent = selectedUsers.size;
      document.getElementById('selectedUsersInput').value = JSON.stringify(Array.from(selectedUsers));
    }

    function searchUsers() {
      const searchTerm = document.getElementById('userSearchInput').value.toLowerCase();
      const filtered = allUsers.filter(user => 
        user.username.toLowerCase().includes(searchTerm) || 
        user.email.toLowerCase().includes(searchTerm)
      );
      renderUserList(filtered);
    }

    function escapeHtml(text) {
      const map = {
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#039;'
      };
      return text.replace(/[&<>"']/g, m => map[m]);
    }

    document.getElementById('userSearchInput')?.addEventListener('input', searchUsers);

    document.getElementById('notificationForm').addEventListener('submit', function(e) {
      const targetType = document.querySelector('input[name="target_type"]:checked').value;
      if (targetType === 'specific' && selectedUsers.size === 0) {
        e.preventDefault();
        alert('Please select at least one user to send the notification to.');
      }
    });
  </script>
</body>
</html>

  <!-- Modal for viewing readers -->
  <div id="readersModal" style="display: none; position: fixed; z-index: 1000; left: 0; top: 0; width: 100%; height: 100%; background-color: rgba(0,0,0,0.6);">
    <div style="background-color: white; margin: 5% auto; padding: 20px; border-radius: 12px; width: 90%; max-width: 500px; max-height: 70vh; overflow-y: auto;">
      <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
        <h3 id="modalTitle" style="color: var(--admin-dark); margin: 0;"></h3>
        <button onclick="closeModal()" style="background: none; border: none; font-size: 1.5rem; cursor: pointer; color: #64748b;">×</button>
      </div>
      <div id="readersList" style="display: flex; flex-direction: column; gap: 12px;"></div>
    </div>
  </div>

  <script>
    async function viewReaders(messageId, title) {
      try {
        const response = await fetch(`api/get-notification-readers.php?message_id=${messageId}`);
        const data = await response.json();
        
        document.getElementById('modalTitle').textContent = `Users who read: ${title}`;
        const readersList = document.getElementById('readersList');
        
        if (data.readers.length === 0) {
          readersList.innerHTML = '<p style="color: #64748b; text-align: center;">No one has read this notification yet</p>';
        } else {
          readersList.innerHTML = data.readers.map(reader => `
            <div style="padding: 12px; background: #f8fafc; border-radius: 8px; border: 1px solid #e2e8f0;">
              <div style="font-weight: 600; color: var(--admin-dark);">${escapeHtml(reader.username)}</div>
              <div style="font-size: 0.85rem; color: #64748b; margin-bottom: 4px;">${escapeHtml(reader.email)}</div>
              <div style="font-size: 0.75rem; color: #94a3b8;">Read at: ${new Date(reader.read_at).toLocaleString()}</div>
            </div>
          `).join('');
        }
        
        document.getElementById('readersModal').style.display = 'block';
      } catch (error) {
        alert('Error loading readers: ' + error.message);
      }
    }

    function closeModal() {
      document.getElementById('readersModal').style.display = 'none';
    }

    function escapeHtml(text) {
      const map = {'&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#039;'};
      return text.replace(/[&<>"']/g, m => map[m]);
    }

    window.onclick = function(event) {
      const modal = document.getElementById('readersModal');
      if (event.target == modal) {
        modal.style.display = 'none';
      }
    }
  </script>
