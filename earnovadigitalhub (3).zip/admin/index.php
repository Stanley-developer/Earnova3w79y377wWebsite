<?php
session_start();
require_once '../config/database.php';

// Check if user is admin
if (!isset($_SESSION['user_id'])) {
    header('Location: ../login.php');
    exit();
}

$user_id = $_SESSION['user_id'];
$stmt = $conn->prepare("SELECT is_admin FROM users WHERE id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result()->fetch_assoc();

if (!$result || $result['is_admin'] != 1) {
    header('Location: ../dashboard.php');
    exit();
}

// Fetch dashboard statistics
$stats = [];

// Total users
$result = $conn->query("SELECT COUNT(*) as total FROM users");
$stats['total_users'] = $result->fetch_assoc()['total'];

// Premium users (exclude premium-plus / advertiser_plan = 'senior')
$result = $conn->query("SELECT COUNT(*) as total FROM users WHERE membership_type = 'premium' AND (advertiser_plan IS NULL OR advertiser_plan = '')");
$stats['premium_users'] = $result->fetch_assoc()['total'];

// Total balance: sum of the `total_balance` column from balances table
$result = $conn->query("SELECT COALESCE(SUM(total_balance), 0) as total FROM balances");
$stats['total_balance'] = $result->fetch_assoc()['total'] ?? 0;

// Pending withdrawals
$result = $conn->query("SELECT COUNT(*) as total, SUM(amount) as amount FROM withdrawals WHERE status = 'pending'");
$withdrawal_data = $result->fetch_assoc();
$stats['pending_withdrawals'] = $withdrawal_data['total'];
$stats['pending_amount'] = $withdrawal_data['amount'] ?? 0;

// Pending verifications
$result = $conn->query("SELECT COUNT(*) as total FROM user_verification WHERE verification_status = 'pending'");
$stats['pending_verifications'] = $result->fetch_assoc()['total'];

// Total jobs
$result = $conn->query("SELECT COUNT(*) as total FROM jobs WHERE status = 'active'");
$stats['active_jobs'] = $result->fetch_assoc()['total'];

// Pending bids
$result = $conn->query("SELECT COUNT(*) as total FROM job_bids WHERE status = 'pending'");
$stats['pending_bids'] = $result->fetch_assoc()['total'];

// Recent activities
$recent_users = $conn->query("SELECT id, username, full_name, created_at, how_heard, country FROM users ORDER BY created_at DESC LIMIT 5")->fetch_all(MYSQLI_ASSOC);

// Prime wallet total (current referral_earnings from balances table)
$result = $conn->query("SELECT COALESCE(SUM(referral_earnings),0) as total FROM balances");
$row = $result->fetch_assoc();
$stats['prime_wallet_total'] = $row['total'] ?? 0;

// Activity earnings total (sum of task_earnings from balances)
$result = $conn->query("SELECT COALESCE(SUM(task_earnings),0) as total FROM balances");
$row = $result->fetch_assoc();
$stats['activity_earnings_total'] = $row['total'] ?? 0;

// User type breakdowns
$result = $conn->query("SELECT COUNT(*) as total FROM users WHERE membership_type = 'free'");
$stats['free_users'] = $result->fetch_assoc()['total'];

$result = $conn->query("SELECT COUNT(*) as total FROM users WHERE advertiser_plan = 'senior'");
$stats['premium_plus_users'] = $result->fetch_assoc()['total'];

// Active / Inactive users
$result = $conn->query("SELECT COUNT(*) as total FROM users WHERE is_active = 1");
$stats['active_users_count'] = $result->fetch_assoc()['total'];

$result = $conn->query("SELECT COUNT(*) as total FROM users WHERE is_active = 0");
$stats['inactive_users_count'] = $result->fetch_assoc()['total'];

// Search functionality for active/inactive users
$search = isset($_GET['search']) ? $conn->real_escape_string($_GET['search']) : '';

// Pagination for active/inactive user lists
$perPage = 10;
$activePage = isset($_GET['active_page']) ? max(1, intval($_GET['active_page'])) : 1;
$inactivePage = isset($_GET['inactive_page']) ? max(1, intval($_GET['inactive_page'])) : 1;
$activeOffset = ($activePage - 1) * $perPage;
$inactiveOffset = ($inactivePage - 1) * $perPage;

// Build search where clause
$search_where = "";
if ($search) {
    $search_where = " AND (username LIKE '%$search%' OR email LIKE '%$search%')";
}

// Fetch total counts for pagination (with search filter)
$active_total_count = $conn->query("SELECT COUNT(*) as total FROM users WHERE is_active = 1 $search_where")->fetch_assoc()['total'];
$inactive_total_count = $conn->query("SELECT COUNT(*) as total FROM users WHERE is_active = 0 $search_where")->fetch_assoc()['total'];

// Fetch paginated lists (safe because values are ints)
$active_users = $conn->query("SELECT id, username, email, how_heard, country FROM users WHERE is_active = 1 $search_where ORDER BY updated_at DESC LIMIT $perPage OFFSET $activeOffset")->fetch_all(MYSQLI_ASSOC);
$inactive_users = $conn->query("SELECT id, username, email, how_heard, country FROM users WHERE is_active = 0 $search_where ORDER BY updated_at DESC LIMIT $perPage OFFSET $inactiveOffset")->fetch_all(MYSQLI_ASSOC);

// Total pages (use search-filtered counts if searching)
$stats['active_total_pages'] = max(1, (int)ceil($active_total_count / $perPage));
$stats['inactive_total_pages'] = max(1, (int)ceil($inactive_total_count / $perPage));
$stats['active_search_count'] = $active_total_count;
$stats['inactive_search_count'] = $inactive_total_count;
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Admin Dashboard - FlowEarner</title>
  <style>
    :root {
      --admin-primary: #6366f1;
      --admin-secondary: #8b5cf6;
      --admin-success: #10b981;
      --admin-warning: #f59e0b;
      --admin-danger: #ef4444;
      --admin-dark: #1e293b;
      --admin-light: #f1f5f9;
    }

    * { box-sizing: border-box; margin: 0; padding: 0; }

    body {
      font-family: "Inter", "Segoe UI", sans-serif;
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      min-height: 100vh;
    }

    .admin-container {
      display: grid;
      grid-template-columns: 260px 1fr;
      min-height: 100vh;
    }

    .admin-sidebar {
      background: rgba(30, 41, 59, 0.95);
      backdrop-filter: blur(10px);
      padding: 24px;
      border-right: 1px solid rgba(255, 255, 255, 0.1);
    }

    .admin-logo {
      font-size: 1.5rem;
      font-weight: 700;
      color: white;
      margin-bottom: 32px;
      text-align: center;
    }

    .admin-nav {
      display: flex;
      flex-direction: column;
      gap: 8px;
    }

    .admin-nav a {
      padding: 12px 16px;
      border-radius: 8px;
      color: rgba(255, 255, 255, 0.7);
      text-decoration: none;
      transition: all 0.3s;
      display: flex;
      align-items: center;
      gap: 12px;
    }

    .admin-nav a:hover, .admin-nav a.active {
      background: rgba(99, 102, 241, 0.2);
      color: white;
    }

    .admin-main {
      padding: 32px;
      overflow-y: auto;
    }

    .admin-header {
      background: white;
      padding: 24px;
      border-radius: 16px;
      margin-bottom: 32px;
      box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    }

    .admin-header h1 {
      font-size: 2rem;
      color: var(--admin-dark);
      margin-bottom: 8px;
    }

    .stats-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
      gap: 24px;
      margin-bottom: 32px;
    }

    .stat-card {
      background: white;
      padding: 24px;
      border-radius: 16px;
      box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    }

    .stat-label {
      font-size: 0.875rem;
      color: #64748b;
      margin-bottom: 8px;
    }

    .stat-value {
      font-size: 2rem;
      font-weight: 700;
      color: var(--admin-dark);
    }

    .recent-section {
      background: white;
      padding: 24px;
      border-radius: 16px;
      box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    }

    .recent-section h2 {
      font-size: 1.25rem;
      margin-bottom: 16px;
      color: var(--admin-dark);
    }

    .recent-item {
      padding: 12px;
      border-bottom: 1px solid #e2e8f0;
      display: flex;
      justify-content: space-between;
      align-items: center;
    }

    .recent-item:last-child {
      border-bottom: none;
    }

    /* Horizontal scroll helpers */
    .horizontal-scroll {
      display: flex;
      gap: 16px;
      overflow-x: auto;
      -webkit-overflow-scrolling: touch;
      padding-bottom: 8px;
    }

    .horizontal-scroll .recent-item {
      flex: 0 0 260px;
      min-width: 220px;
      border-bottom: none;
      display: block;
      background: white;
      border-radius: 12px;
      box-shadow: 0 6px 18px rgba(15, 23, 42, 0.06);
      padding: 12px;
    }

    .search-bar {
      background: white;
      padding: 16px;
      border-radius: 12px;
      margin-bottom: 24px;
      box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
      display: flex;
      gap: 12px;
      flex-wrap: wrap;
    }

    .search-bar input {
      padding: 10px 12px;
      border: 1px solid #e2e8f0;
      border-radius: 8px;
      font-size: 0.9rem;
      flex: 1;
      min-width: 200px;
    }

    .search-bar button {
      padding: 10px 20px;
      background: var(--admin-primary);
      color: white;
      border: none;
      border-radius: 8px;
      font-weight: 600;
      cursor: pointer;
      transition: all 0.3s;
    }

    .search-bar button:hover {
      background: var(--admin-secondary);
    }

    .search-bar a {
      padding: 10px 20px;
      background: #f1f5f9;
      color: var(--admin-dark);
      border: none;
      border-radius: 8px;
      font-weight: 600;
      cursor: pointer;
      text-decoration: none;
      transition: all 0.3s;
    }

    .search-bar a:hover {
      background: #e2e8f0;
    }

    @media (max-width: 960px) {
      .admin-container {
        grid-template-columns: 1fr;
      }

      .admin-sidebar {
        position: relative;
      }

      /* Make stat cards swipe horizontally on mid-size screens */
      .stats-grid {
        display: flex;
        gap: 12px;
        overflow-x: auto;
        padding-bottom: 8px;
        -webkit-overflow-scrolling: touch;
      }

      .stats-grid .stat-card {
        flex: 0 0 240px;
        min-width: 200px;
      }
    }

    /* Match admin/users.php mobile adjustments for <=768px */
    @media (max-width: 768px) {
      .admin-main {
        padding: 16px;
      }

      .admin-header h1 {
        font-size: 1.5rem;
      }

      .stats-grid {
        gap: 10px;
      }

      .stat-card {
        padding: 16px;
      }

      .recent-section {
        padding: 16px;
      }

      .horizontal-scroll {
        gap: 12px;
      }

      .horizontal-scroll .recent-item {
        flex: 0 0 220px;
        min-width: 200px;
        padding: 10px;
      }

      .recent-item strong {
        font-size: 0.95rem;
      }

      .recent-item small {
        font-size: 0.8rem;
      }

      .search-bar {
        flex-direction: column;
      }

      .search-bar input {
        min-width: auto;
        width: 100%;
      }

      .search-bar button,
      .search-bar a {
        width: 100%;
      }
    }
  </style>
</head>
<body>
 <?php include 'side-bar.php'; ?>
<div class="admin-content">
  <!-- Your admin page content here -->



    <main class="admin-main">
      <div class="admin-header">
        <h1>Admin Dashboard</h1>
        <p style="color: #64748b;">Welcome back! Here's what's happening with FlowEarner today.</p>
      </div>

      <div class="stats-grid">
        <div class="stat-card">
            <div class="stat-label">Total Users</div>
            <div style="display:flex; justify-content:space-between; align-items:center; gap:12px;">
              <div class="stat-value"><?php echo number_format($stats['total_users']); ?></div>
              <div style="text-align:right;">
                <small style="color: #10b981; display:block;"><?php echo number_format($stats['premium_users']); ?> Premium</small>
                <small style="color: #8b5cf6; display:block;"><?php echo number_format($stats['premium_plus_users']); ?> Premium-Plus</small>
                <small style="color: #64748b; display:block;"><?php echo number_format($stats['free_users']); ?> Free</small>
              </div>
            </div>
        </div>

        <div class="stat-card">
          <div class="stat-label">Total Balance</div>
          <div class="stat-value">₦<?php echo number_format($stats['total_balance'], 2); ?></div>
          <small style="color: #64748b;">Prime + Activity earnings</small>
        </div>

        <div class="stat-card">
          <div class="stat-label">Prime Wallet Total</div>
          <div class="stat-value">₦<?php echo number_format($stats['prime_wallet_total'], 2); ?></div>
          <small style="color: #64748b;">Current referral (prime) balances</small>
        </div>

        <div class="stat-card">
          <div class="stat-label">Activity Earnings Total</div>
          <div class="stat-value">₦<?php echo number_format($stats['activity_earnings_total'], 2); ?></div>
          <small style="color: #64748b;">Sum of task earnings across users</small>
        </div>

        <div class="stat-card">
          <div class="stat-label">Free Users</div>
          <div class="stat-value"><?php echo number_format($stats['free_users']); ?></div>
        </div>

        <div class="stat-card">
          <div class="stat-label">Premium Users</div>
          <div class="stat-value"><?php echo number_format($stats['premium_users']); ?></div>
          <small style="color: #8b5cf6;">Premium (excludes Premium-Plus)</small>
        </div>

        <div class="stat-card">
          <div class="stat-label">Premium-Plus</div>
          <div class="stat-value"><?php echo number_format($stats['premium_plus_users']); ?></div>
          <small style="color: #8b5cf6;"></small>
        </div>
       

       
      </div>

      <!-- Search Bar -->
      <form class="search-bar" method="GET">
        <input type="text" name="search" placeholder="Search users by username or email..." value="<?php echo htmlspecialchars($search); ?>" />
        <button type="submit">Search</button>
        <?php if ($search): ?>
          <a href="?">Clear</a>
        <?php endif; ?>
      </form>

      <div class="recent-section">
        <h2>Recent Users</h2>
        <?php foreach ($recent_users as $user): ?>
          <div class="recent-item" style="display: block;">
            <div>
              <strong><?php echo htmlspecialchars($user['full_name']); ?></strong>
              <small style="display: block; color: #64748b;">@<?php echo htmlspecialchars($user['username']); ?></small>
              <small style="display: block; color: #64748b; margin-top: 4px; display: flex; gap: 12px; align-items: center; flex-wrap: wrap;">
                <span style="display: flex; align-items: center; gap: 4px;">
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path><circle cx="12" cy="10" r="3"></circle></svg>
                  <?php echo htmlspecialchars($user['country'] ?? 'N/A'); ?>
                </span>
                <span style="display: flex; align-items: center; gap: 4px;">
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path><polyline points="9 22 9 12 15 12 15 22"></polyline></svg>
                  <?php echo htmlspecialchars($user['how_heard'] ?? 'Unknown'); ?>
                </span>
              </small>
            </div>
            <small style="color: #64748b;"><?php echo date('M d, Y', strtotime($user['created_at'])); ?></small>
          </div>
        <?php endforeach; ?>
      </div>

      <div class="recent-section" style="margin-top:24px; display:flex; gap:16px; flex-wrap:wrap;">
        <div style="flex:1; min-width:260px;">
          <h2>Active Users (<?php echo number_format($stats['active_search_count']); ?>)</h2>
          <?php if (!empty($active_users)): ?>
            <?php foreach ($active_users as $au): ?>
              <div class="recent-item" style="display:block;">
                <div>
                  <strong><?php echo htmlspecialchars($au['username']); ?></strong>
                  <small style="display:block; color:#64748b;"><?php echo htmlspecialchars($au['email']); ?></small>
                  <small style="display:block; color:#64748b; margin-top:4px; display: flex; gap: 12px; align-items: center; flex-wrap: wrap;">
                    <span style="display: flex; align-items: center; gap: 4px;">
                      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path><circle cx="12" cy="10" r="3"></circle></svg>
                      <?php echo htmlspecialchars($au['country'] ?? 'N/A'); ?>
                    </span>
                    <span style="display: flex; align-items: center; gap: 4px;">
                      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path><polyline points="9 22 9 12 15 12 15 22"></polyline></svg>
                      <?php echo htmlspecialchars($au['how_heard'] ?? 'Unknown'); ?>
                    </span>
                  </small>
                </div>
              </div>
            <?php endforeach; ?>
            <div style="padding:12px; display:flex; gap:8px; align-items:center;">
              <?php if ($activePage > 1): ?>
                <a href="?active_page=<?php echo $activePage - 1; ?><?php echo $search ? '&search=' . urlencode($search) : ''; ?>" style="padding:6px 10px; background:#e2e8f0; border-radius:6px; text-decoration:none; color:#0f172a;">Previous</a>
              <?php endif; ?>
              <span style="color:#64748b;">Page <?php echo $activePage; ?> / <?php echo $stats['active_total_pages']; ?></span>
              <?php if ($activePage < $stats['active_total_pages']): ?>
                <a href="?active_page=<?php echo $activePage + 1; ?><?php echo $search ? '&search=' . urlencode($search) : ''; ?>" style="padding:6px 10px; background:#e2e8f0; border-radius:6px; text-decoration:none; color:#0f172a;">Next</a>
              <?php endif; ?>
            </div>
          <?php else: ?>
            <div style="padding:12px; color:#64748b;">No active users found.</div>
          <?php endif; ?>
        </div>

        <div style="flex:1; min-width:260px;">
          <h2>Inactive Users (<?php echo number_format($stats['inactive_search_count']); ?>)</h2>
          <?php if (!empty($inactive_users)): ?>
            <?php foreach ($inactive_users as $iu): ?>
              <div class="recent-item" style="display:block;">
                <div>
                  <strong><?php echo htmlspecialchars($iu['username']); ?></strong>
                  <small style="display:block; color:#64748b;"><?php echo htmlspecialchars($iu['email']); ?></small>
                  <small style="display:block; color:#64748b; margin-top:4px; display: flex; gap: 12px; align-items: center; flex-wrap: wrap;">
                    <span style="display: flex; align-items: center; gap: 4px;">
                      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path><circle cx="12" cy="10" r="3"></circle></svg>
                      <?php echo htmlspecialchars($iu['country'] ?? 'N/A'); ?>
                    </span>
                    <span style="display: flex; align-items: center; gap: 4px;">
                      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path><polyline points="9 22 9 12 15 12 15 22"></polyline></svg>
                      <?php echo htmlspecialchars($iu['how_heard'] ?? 'Unknown'); ?>
                    </span>
                  </small>
                </div>
              </div>
            <?php endforeach; ?>
            <div style="padding:12px; display:flex; gap:8px; align-items:center;">
              <?php if ($inactivePage > 1): ?>
                <a href="?inactive_page=<?php echo $inactivePage - 1; ?><?php echo $search ? '&search=' . urlencode($search) : ''; ?>" style="padding:6px 10px; background:#e2e8f0; border-radius:6px; text-decoration:none; color:#0f172a;">Previous</a>
              <?php endif; ?>
              <span style="color:#64748b;">Page <?php echo $inactivePage; ?> / <?php echo $stats['inactive_total_pages']; ?></span>
              <?php if ($inactivePage < $stats['inactive_total_pages']): ?>
                <a href="?inactive_page=<?php echo $inactivePage + 1; ?><?php echo $search ? '&search=' . urlencode($search) : ''; ?>" style="padding:6px 10px; background:#e2e8f0; border-radius:6px; text-decoration:none; color:#0f172a;">Next</a>
              <?php endif; ?>
            </div>
          <?php else: ?>
            <div style="padding:12px; color:#64748b;">No inactive users found.</div>
          <?php endif; ?>
        </div>
      </div>
    </main>
  </div>
</body>
</html>
