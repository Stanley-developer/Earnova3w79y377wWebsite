<?php
ini_set('display_errors', 1);
ini_set('log_errors', 1);
error_reporting(E_ALL);

require_once '../config/database.php';
require_once '../includes/session.php';

// Require authentication
requireLogin();
checkSessionTimeout();

// Get current user
$user = getCurrentUser();
$user_id = $user['id'];

// Create PDO connection
$pdo = getDBConnection();

// Check if user is admin
$stmt = $pdo->prepare("SELECT is_admin FROM users WHERE id = ?");
$stmt->execute([$user_id]);
$userCheck = $stmt->fetch();

if (!$userCheck || !$userCheck['is_admin']) {
    header('Location: ../dashboard.php');
    exit();
}

// Fetch all user-uploaded videos
try {
    $stmt = $pdo->prepare("
        SELECT v.*, u.username, u.full_name 
        FROM available_videos v
        LEFT JOIN users u ON v.uploaded_by_user_id = u.id
        WHERE v.uploaded_by_user_id IS NOT NULL
        ORDER BY v.created_at DESC
    ");
    $stmt->execute();
    $user_videos = $stmt->fetchAll();
} catch (Exception $e) {
    $user_videos = [];
    error_log('Fetch user videos error: ' . $e->getMessage());
}

$message = '';
$messageType = '';

// Handle delete action
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'delete') {
    try {
        $video_id = $_POST['video_id'] ?? '';
        if ($video_id) {
            $stmt = $pdo->prepare("DELETE FROM available_videos WHERE id = ?");
            $stmt->execute([$video_id]);
            $message = 'Video deleted successfully!';
            $messageType = 'success';
            
            // Refresh list
            $stmt = $pdo->prepare("
                SELECT v.*, u.username, u.full_name 
                FROM available_videos v
                LEFT JOIN users u ON v.uploaded_by_user_id = u.id
                WHERE v.uploaded_by_user_id IS NOT NULL
                ORDER BY v.created_at DESC
            ");
            $stmt->execute();
            $user_videos = $stmt->fetchAll();
        }
    } catch (Exception $e) {
        $message = 'Failed to delete video: ' . htmlspecialchars($e->getMessage());
        $messageType = 'error';
    }
}

// Handle toggle status
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'toggle_status') {
    try {
        $video_id = $_POST['video_id'] ?? '';
        if ($video_id) {
            $stmt = $pdo->prepare("SELECT is_active FROM available_videos WHERE id = ?");
            $stmt->execute([$video_id]);
            $video = $stmt->fetch();
            
            if ($video) {
                $new_status = $video['is_active'] ? 0 : 1;
                $stmt = $pdo->prepare("UPDATE available_videos SET is_active = ? WHERE id = ?");
                $stmt->execute([$new_status, $video_id]);
                $status_text = $new_status ? 'activated' : 'paused';
                $message = 'Video ' . $status_text . ' successfully!';
                $messageType = 'success';
                
                // Refresh list
                $stmt = $pdo->prepare("
                    SELECT v.*, u.username, u.full_name 
                    FROM available_videos v
                    LEFT JOIN users u ON v.uploaded_by_user_id = u.id
                    WHERE v.uploaded_by_user_id IS NOT NULL
                    ORDER BY v.created_at DESC
                ");
                $stmt->execute();
                $user_videos = $stmt->fetchAll();
            }
        }
    } catch (Exception $e) {
        $message = 'Failed to update video status: ' . htmlspecialchars($e->getMessage());
        $messageType = 'error';
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage User Videos - Admin</title>
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; }
        
        body {
            font-family: "Titillium Web", "Segoe UI", sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: #f5f9ff;
            min-height: 100vh;
            padding: 2rem;
        }
        
        .container {
            max-width: 1400px;
            margin: 0 auto;
        }
        
        h1 {
            font-size: 2.5rem;
            margin-bottom: 2rem;
            background: linear-gradient(135deg, #8b5cf6, #ec4899);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }
        
        .alert-message {
            padding: 16px 24px;
            border-radius: 12px;
            margin-bottom: 24px;
            font-size: 15px;
        }
        
        .alert-success {
            background: rgba(77, 225, 193, 0.95);
            color: #030922;
        }
        
        .alert-error {
            background: rgba(255, 77, 77, 0.95);
            color: #fff;
        }
        
        .videos-table {
            background: white;
            border-radius: 16px;
            padding: 24px;
            overflow-x: auto;
        }
        
        table {
            width: 100%;
            border-collapse: collapse;
        }
        
        th, td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #e2e8f0;
            color: #1e293b;
        }
        
        th {
            background: #f8fafc;
            font-weight: 600;
            color: #0f172a;
        }
        
        .status-badge {
            display: inline-block;
            padding: 4px 12px;
            border-radius: 12px;
            font-size: 0.85rem;
            font-weight: 600;
        }
        
        .status-active {
            background: #d1fae5;
            color: #065f46;
        }
        
        .status-inactive {
            background: #fee2e2;
            color: #991b1b;
        }
        
        .action-btn {
            padding: 6px 12px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-size: 0.85rem;
            font-weight: 600;
            margin-right: 8px;
            transition: all 0.3s ease;
        }
        
        .btn-toggle {
            background: #3b82f6;
            color: white;
        }
        
        .btn-delete {
            background: #ef4444;
            color: white;
        }
        
        .action-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
        }
        
        .back-link {
            display: inline-block;
            margin-bottom: 24px;
            color: #fff;
            text-decoration: none;
            font-weight: 600;
        }
        
        .back-link:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="container">
        <a href="admin-dashboard.php" class="back-link">← Back to Admin Dashboard</a>
        
        <h1>Manage User-Uploaded Videos</h1>
        
        <?php if ($message): ?>
            <div class="alert-message alert-<?php echo $messageType; ?>">
                <?php echo htmlspecialchars($message); ?>
            </div>
        <?php endif; ?>
        
        <div class="videos-table">
            <h2 style="color: #1e293b; margin-bottom: 16px;">User Uploaded Videos (<?php echo count($user_videos); ?>)</h2>
            
            <?php if (empty($user_videos)): ?>
                <p style="color: #64748b;">No user-uploaded videos found.</p>
            <?php else: ?>
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Title</th>
                            <th>Platform</th>
                            <th>Uploaded By</th>
                            <th>Duration</th>
                            <th>Status</th>
                            <th>Created</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($user_videos as $video): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($video['id']); ?></td>
                                <td><?php echo htmlspecialchars($video['title']); ?></td>
                                <td><?php echo htmlspecialchars(strtoupper($video['platform'])); ?></td>
                                <td><?php echo htmlspecialchars($video['username'] ?? 'Unknown'); ?></td>
                                <td><?php echo $video['duration'] > 0 ? $video['duration'] . 's' : 'N/A'; ?></td>
                                <td>
                                    <span class="status-badge status-<?php echo $video['is_active'] ? 'active' : 'inactive'; ?>">
                                        <?php echo $video['is_active'] ? 'Active' : 'Inactive'; ?>
                                    </span>
                                </td>
                                <td><?php echo date('M d, Y', strtotime($video['created_at'])); ?></td>
                                <td>
                                    <form method="POST" style="display: inline;">
                                        <input type="hidden" name="action" value="toggle_status">
                                        <input type="hidden" name="video_id" value="<?php echo $video['id']; ?>">
                                        <button type="submit" class="action-btn btn-toggle">
                                            <?php echo $video['is_active'] ? 'Pause' : 'Activate'; ?>
                                        </button>
                                    </form>
                                    
                                    <form method="POST" style="display: inline;" onsubmit="return confirm('Are you sure you want to delete this video?');">
                                        <input type="hidden" name="action" value="delete">
                                        <input type="hidden" name="video_id" value="<?php echo $video['id']; ?>">
                                        <button type="submit" class="action-btn btn-delete">Delete</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>
