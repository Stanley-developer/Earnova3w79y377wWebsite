<?php
session_start();
require_once '../config/database.php';


if (!isset($_SESSION['user_id'])) {
    header('Location: ../login.php');
    exit();
}

$user_id = $_SESSION['user_id'];
$stmt = $conn->prepare("SELECT is_admin FROM users WHERE id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result()->fetch_assoc();

if (!$result || $result['is_admin'] != 1) {
    header('Location: ../dashboard.php');
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $verification_id = intval($_POST['verification_id']);
    $action = $_POST['action'];
    
    if ($action === 'approve') {
        $stmt = $conn->prepare("UPDATE user_verification SET verification_status = 'approved', verified_at = NOW() WHERE id = ?");
        $stmt->bind_param("i", $verification_id);
        $stmt->execute();
        $success_message = "User verification approved successfully";
    } elseif ($action === 'reject') {
        $rejection_reason = $_POST['rejection_reason'] ?? 'Verification failed';
        $stmt = $conn->prepare("UPDATE user_verification SET verification_status = 'rejected', rejection_reason = ? WHERE id = ?");
        $stmt->bind_param("si", $rejection_reason, $verification_id);
        $stmt->execute();
        $success_message = "User verification rejected";
    }
}

$verifications = $conn->query("
    SELECT v.*, u.username, u.email, u.full_name 
    FROM user_verification v 
    JOIN users u ON v.user_id = u.id 
    WHERE v.verification_status = 'pending' 
    ORDER BY v.submitted_at DESC
")->fetch_all(MYSQLI_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Verify Users - FlowEarner Admin</title>
  <style>
    :root {
      --admin-primary: #6366f1;
      --admin-secondary: #8b5cf6;
      --admin-success: #10b981;
      --admin-warning: #f59e0b;
      --admin-danger: #ef4444;
      --admin-dark: #1e293b;
      --admin-light: #f1f5f9;
    }

    * { box-sizing: border-box; margin: 0; padding: 0; }

    body {
      font-family: "Inter", "Segoe UI", sans-serif;
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      min-height: 100vh;
    }

    

   

    .admin-main {
     
      padding: 32px;
      overflow-y: auto;
    }

    .admin-header {
      background: white;
      padding: 24px;
      border-radius: 16px;
      margin-bottom: 32px;
      box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    }

    .admin-header h1 {
      font-size: 2rem;
      color: var(--admin-dark);
      margin-bottom: 8px;
    }

    .verification-grid {
      display: grid;
      gap: 24px;
    }

    .verification-card {
      background: white;
      border-radius: 16px;
      padding: 24px;
      box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    }

    .verification-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 20px;
      padding-bottom: 16px;
      border-bottom: 2px solid #e2e8f0;
    }

    .verification-info {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
      gap: 16px;
      margin-bottom: 20px;
    }

    .info-item {
      display: flex;
      flex-direction: column;
      gap: 4px;
    }

    .info-label {
      font-size: 0.75rem;
      text-transform: uppercase;
      color: #64748b;
      font-weight: 600;
      letter-spacing: 0.05em;
    }

    .info-value {
      font-size: 0.95rem;
      color: var(--admin-dark);
      font-weight: 500;
    }

    .document-preview {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
      gap: 16px;
      margin: 20px 0;
    }

    .document-item img {
      width: 100%;
      border-radius: 8px;
      border: 2px solid #e2e8f0;
    }

    .document-label {
      font-size: 0.85rem;
      font-weight: 600;
      color: var(--admin-dark);
      margin-bottom: 8px;
    }

    .action-buttons {
      display: flex;
      gap: 12px;
      margin-top: 20px;
    }

    .btn {
      padding: 12px 24px;
      border: none;
      border-radius: 8px;
      font-weight: 600;
      cursor: pointer;
      transition: all 0.3s;
    }

    .btn-approve {
      background: var(--admin-success);
      color: white;
    }

    .btn-reject {
      background: var(--admin-danger);
      color: white;
    }

    .btn-contact {
      background: var(--admin-primary);
      color: white;
    }

    .btn:hover {
      transform: translateY(-2px);
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
    }

    .alert {
      padding: 16px;
      border-radius: 12px;
      margin-bottom: 24px;
      font-weight: 600;
    }

    .alert-success {
      background: #d1fae5;
      color: #065f46;
    }

    .modal {
      display: none;
      position: fixed;
      inset: 0;
      background: rgba(0, 0, 0, 0.5);
      z-index: 1000;
      align-items: center;
      justify-content: center;
    }

    .modal.active {
      display: flex;
    }

    .modal-content {
      background: white;
      padding: 32px;
      border-radius: 16px;
      max-width: 500px;
      width: 90%;
    }

    .modal-content h3 {
      margin-bottom: 16px;
      color: var(--admin-dark);
    }

    .modal-content textarea {
      width: 100%;
      padding: 12px;
      border: 1px solid #e2e8f0;
      border-radius: 8px;
      min-height: 100px;
      font-family: inherit;
    }

    @media (max-width: 960px) {
      .admin-container {
        grid-template-columns: 1fr;
      }

      .admin-sidebar {
        position: relative;
        width: 100%;
      }

      .admin-main {
        margin-left: 0;
      }
    }
  </style>
</head>
<body>

  <?php include 'side-bar.php'; ?>
<div class="admin-content">

    <main class="admin-main">
      <div class="admin-header">
        <h1>Verify Users</h1>
        <p style="color: #64748b;">Review and approve user verification requests for job bidding</p>
      </div>

      <?php if (isset($success_message)): ?>
        <div class="alert alert-success"><?php echo $success_message; ?></div>
      <?php endif; ?>

      <div class="verification-grid">
        <?php if (empty($verifications)): ?>
          <div class="verification-card">
            <p style="text-align: center; color: #64748b;">No pending verifications</p>
          </div>
        <?php else: ?>
          <?php foreach ($verifications as $verification): ?>
            <div class="verification-card">
              <div class="verification-header">
                <div>
                  <h3 style="margin: 0; color: var(--admin-dark);"><?php echo htmlspecialchars($verification['full_name']); ?></h3>
                  <p style="color: #64748b; margin: 4px 0 0;">@<?php echo htmlspecialchars($verification['username']); ?></p>
                </div>
                <span style="font-size: 0.85rem; color: #64748b;">
                  Submitted: <?php echo date('M d, Y', strtotime($verification['submitted_at'])); ?>
                </span>
              </div>

              <div class="verification-info">
                <div class="info-item">
                  <span class="info-label">NIN</span>
                  <span class="info-value"><?php echo htmlspecialchars($verification['nin']); ?></span>
                </div>
                <div class="info-item">
                  <span class="info-label">Date of Birth</span>
                  <span class="info-value"><?php echo date('M d, Y', strtotime($verification['date_of_birth'])); ?></span>
                </div>
                <div class="info-item">
                  <span class="info-label">Location</span>
                  <span class="info-value"><?php echo htmlspecialchars($verification['location']); ?></span>
                </div>
                <div class="info-item">
                  <span class="info-label">Phone</span>
                  <span class="info-value"><?php echo htmlspecialchars($verification['phone_number']); ?></span>
                </div>
                <div class="info-item">
                  <span class="info-label">Email</span>
                  <span class="info-value"><?php echo htmlspecialchars($verification['email']); ?></span>
                </div>
              </div>

              <div class="document-preview">
                <div class="document-item">
                  <div class="document-label">Profile Picture</div>
                  <img src="../<?php echo htmlspecialchars($verification['profile_picture']); ?>" alt="Profile" />
                </div>
                <div class="document-item">
                  <div class="document-label">Portfolio/CV</div>
                  <a href="../<?php echo htmlspecialchars($verification['portfolio_cv']); ?>" target="_blank" style="color: var(--admin-primary); font-weight: 600;">View Document</a>
                </div>
              </div>

              <div class="info-item">
                <span class="info-label">Recent Jobs Delivered</span>
                <p style="color: var(--admin-dark); line-height: 1.6; margin-top: 8px;">
                  <?php echo nl2br(htmlspecialchars($verification['recent_jobs'])); ?>
                </p>
              </div>

              <div class="action-buttons">
                <form method="POST" style="display: inline;">
                  <input type="hidden" name="verification_id" value="<?php echo $verification['id']; ?>" />
                  <button type="submit" name="action" value="approve" class="btn btn-approve">✓ Approve</button>
                </form>
                <button class="btn btn-reject" onclick="openRejectModal(<?php echo $verification['id']; ?>)">✗ Reject</button>
                <a href="mailto:<?php echo htmlspecialchars($verification['email']); ?>" class="btn btn-contact">📧 Email</a>
                <a href="https://wa.me/<?php echo preg_replace('/[^0-9]/', '', $verification['phone_number']); ?>" target="_blank" class="btn btn-contact">💬 WhatsApp</a>
              </div>
            </div>
          <?php endforeach; ?>
        <?php endif; ?>
      </div>
    </main>
  </div>

  <div class="modal" id="rejectModal">
    <div class="modal-content">
      <h3>Reject Verification</h3>
      <form method="POST">
        <input type="hidden" name="verification_id" id="reject_verification_id" />
        <textarea name="rejection_reason" placeholder="Enter rejection reason..." required></textarea>
        <div style="display: flex; gap: 12px; margin-top: 16px;">
          <button type="submit" name="action" value="reject" class="btn btn-reject">Reject</button>
          <button type="button" class="btn" style="background: #e2e8f0; color: var(--admin-dark);" onclick="closeRejectModal()">Cancel</button>
        </div>
      </form>
    </div>
  </div>

  <script>
    function openRejectModal(verificationId) {
      document.getElementById('reject_verification_id').value = verificationId;
      document.getElementById('rejectModal').classList.add('active');
    }

    function closeRejectModal() {
      document.getElementById('rejectModal').classList.remove('active');
    }
  </script>
</body>
</html>
