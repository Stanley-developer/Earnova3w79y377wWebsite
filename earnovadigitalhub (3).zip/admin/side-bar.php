<?php
// Get current page filename for active state
$current_page = basename($_SERVER['PHP_SELF']);
?>

<style>
  /* Sidebar base */
  .admin-sidebar {
    background: rgba(30, 41, 59, 0.95);
    backdrop-filter: blur(10px);
    padding: 24px;
    border-right: 1px solid rgba(255, 255, 255, 0.1);
    position: fixed;
    left: 0;
    top: 0;
    height: 100vh;
    width: 260px;
    transition: transform 0.3s ease;
    z-index: 1000;
    overflow-y: auto;
    overflow-x: hidden;
  }

  .admin-sidebar::-webkit-scrollbar {
    width: 6px;
  }

  .admin-sidebar::-webkit-scrollbar-track {
    background: rgba(255, 255, 255, 0.05);
    border-radius: 10px;
  }

  .admin-sidebar::-webkit-scrollbar-thumb {
    background: rgba(99, 102, 241, 0.5);
    border-radius: 10px;
  }

  .admin-sidebar::-webkit-scrollbar-thumb:hover {
    background: rgba(99, 102, 241, 0.7);
  }

  .admin-logo {
    font-size: 1.5rem;
    font-weight: 700;
    color: white;
    margin-bottom: 32px;
    text-align: center;
    display: flex;
    justify-content: center;
    align-items: center;
    gap: 8px;
  }

  .admin-nav {
    display: flex;
    flex-direction: column;
    gap: 6px;
    padding-bottom: 20px;
  }

  .admin-nav a {
    padding: 12px 16px;
    border-radius: 8px;
    color: rgba(255, 255, 255, 0.75);
    text-decoration: none;
    transition: all 0.3s ease;
    display: flex;
    align-items: center;
    gap: 12px;
  }

  .admin-nav a:hover,
  .admin-nav a.active {
    background: rgba(99, 102, 241, 0.25);
    color: white;
  }

  .admin-nav svg {
    width: 20px;
    height: 20px;
    fill: currentColor;
  }

  /* Content wrapper offset */
  .admin-content {
    margin-left: 260px;
    padding: 20px;
    transition: margin-left 0.3s ease;
  }

  /* Toggle button for mobile */
  .sidebar-toggle {
    display: none;
    position: fixed;
    top: 20px;
    left: 20px;
    background: rgba(99, 102, 241, 0.9);
    color: white;
    border: none;
    padding: 10px 12px;
    border-radius: 6px;
    cursor: pointer;
    z-index: 1100;
  }

  @media (max-width: 768px) {
    .admin-sidebar {
      transform: translateX(-100%);
    }

    .admin-sidebar.active {
      transform: translateX(0);
    }

    .admin-content {
      margin-left: 0;
    }

    .sidebar-toggle {
      display: block;
    }
  }
</style>

<button class="sidebar-toggle" onclick="toggleSidebar()">
  ☰
</button>

<aside class="admin-sidebar" id="adminSidebar">
  <div class="admin-logo">
     Earnova Admin
  </div>
  <nav class="admin-nav">
    <a href="index.php" class="<?= $current_page === 'index.php' ? 'active' : '' ?>">
      <svg viewBox="0 0 24 24"><path d="M3 13h8V3H3v10zm0 8h8v-6H3v6zm10 0h8V11h-8v10zm0-18v6h8V3h-8z"/></svg>
      Dashboard
    </a>

    <a href="users.php" class="<?= $current_page === 'users.php' ? 'active' : '' ?>">
      <svg viewBox="0 0 24 24"><path d="M16 11c1.66 0 2.99-1.34 2.99-3S17.66 5 16 5s-3 1.34-3 3 1.34 3 3 3zm-8 
      0c1.66 0 2.99-1.34 2.99-3S9.66 5 8 5 5 6.34 5 8s1.34 3 3 3zm0 2c-2.33 
      0-7 1.17-7 3.5V20h14v-3.5C18 14.17 13.33 13 11 13zm8 0c-.29 
      0-.62.02-.97.05C18.14 14.1 20 15.28 20 16.5V20h3v-3.5c0-2.33-4.67-3.5-7-3.5z"/></svg>
      Users
    </a>

   

    <a href="admin-post-task.php" class="<?= $current_page === 'admin-post-task.php' ? 'active' : '' ?>">
      <svg viewBox="0 0 24 24"><path d="M9 16.17l-3.88-3.88L4 13.41 
      9 18.41 20 7.41 18.59 6l-9.59 9.59z"/></svg>
      Post Tasks
    </a>
    
     <a href="view-user-posted-task.php" class="<?= $current_page === 'view-user-posted-task.php' ? 'active' : '' ?>">
      <svg viewBox="0 0 24 24"><path d="M9 16.17l-3.88-3.88L4 13.41 
      9 18.41 20 7.41 18.59 6l-9.59 9.59z"/></svg>
      User Posted Tasks
    </a>

    <a href="admin-skill-require.php" class="<?= $current_page === 'admin-skill-require.php' ? 'active' : '' ?>">
      <svg viewBox="0 0 24 24"><path d="M12 3L1 9l11 6 9-4.91V17h2V9L12 3z"/></svg>
      Skills & Learning
    </a>

  

     <a href="track-deposit.php" class="<?= $current_page === 'track-deposit.php' ? 'active' : '' ?>">
      <svg viewBox="0 0 24 24"><path d="M9 16.17l-3.88-3.88L4 13.41 
      9 18.41 20 7.41 18.59 6l-9.59 9.59z"/></svg>
      Deposits
    </a>

    <a href="withdrawals.php" class="<?= $current_page === 'withdrawals.php' ? 'active' : '' ?>">
      <svg viewBox="0 0 24 24"><path d="M12 3v10.55A4 
      4 0 1 0 14 17h2a6 
      6 0 1 1-6-6V3h2z"/></svg>
      Withdrawals
    </a>

    <a href="transactions.php" class="<?= $current_page === 'transactions.php' ? 'active' : '' ?>">
      <svg viewBox="0 0 24 24"><path d="M3 17v2h6v-2H3zm0-8v2h10V9H3zm0 
      4v2h8v-2H3zm12 4v2h6v-2h-6zm0-8v2h8V9h-8zm0 
      4v2h4v-2h-4z"/></svg>
      Transactions
    </a>

    <a href="referrals.php" class="<?= $current_page === 'referrals.php' ? 'active' : '' ?>">
      <svg viewBox="0 0 24 24"><path d="M16 11c1.66 
      0 2.99-1.34 2.99-3S17.66 5 16 
      5s-3 1.34-3 3 1.34 3 3 
      3zm-8 0c1.66 0 2.99-1.34 
      2.99-3S9.66 5 8 5 5 6.34 
      5 8s1.34 3 3 3zm0 2c-2.33 
      0-7 1.17-7 3.5V20h14v-3.5C18 
      14.17 13.33 13 11 13z"/></svg>
      Referrals
    </a>

    <a href="downline-commissions.php" class="<?= $current_page === 'downline-commissions.php' ? 'active' : '' ?>">
      <svg viewBox="0 0 24 24"><path d="M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20zm1 15h-2v-2h2v2zm0-4h-2V7h2v6z"/></svg>
      Downline Commissions
    </a>

    <a href="view-performed-tasks.php" class="<?= $current_page === 'view-performed-tasks.php' ? 'active' : '' ?>">
      <svg viewBox="0 0 24 24"><path d="M9 16.17l-3.88-3.88L4 13.41 9 18.41 20 7.41 18.59 6l-9.59 9.59z"/></svg>
      Task Tracker
    </a>

    <a href="view-streamed-tracks.php" class="<?= $current_page === 'view-streamed-tracks.php' ? 'active' : '' ?>">
      <svg viewBox="0 0 24 24"><path d="M12 3v9.28c-1.66-2.16-5.13-2.27-7.66-0.25-2.53 2.02-3.44 5.87-0.75 8.98 2.69 3.11 7.68 3.11 10.37 0 1.34-1.55 1.95-3.6 1.95-5.52V5h4v9.28c0 2.03 0.69 4.05 2 5.64v2.08c-1.48-1.04-2.76-2.5-3.7-4.15-0.94 1.65-2.22 3.11-3.7 4.15v-2.08c1.31-1.59 2-3.61 2-5.64V5z"/></svg>
      Stream Tracker
    </a>
    
    <a href="view-watched-videos.php" class="<?= $current_page === 'view-watched-videos.php' ? 'active' : '' ?>">
  <svg viewBox="0 0 24 24"><path d="M4 6h16V4H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h4v2h10v-2h4V6zm10 6l-5-3.5v7l5-3.5z"/></svg>
  Video Tracker
</a>

    <a href="upload-video.php" class="<?= $current_page === 'videos-video.php' ? 'active' : '' ?>">
      <svg viewBox="0 0 24 24"><path d="M12 3v10.55A4 
      4 0 1 0 14 17h2a6 
      6 0 1 1-6-6V3h2z"/></svg>
      Upload Videos
    </a>

    <a href="upload-track.php" class="<?= $current_page === 'upload-track.php' ? 'active' : '' ?>">
      <svg viewBox="0 0 24 24"><path d="M9 16h6v-6h4l-7-7-7 7h4zm-4 2h14v2H5z"/></svg>
      Upload Tracks
    </a>

    <a href="chat-earn.php" class="<?= $current_page === 'chat-earn.php' ? 'active' : '' ?>">
      <svg viewBox="0 0 24 24"><path d="M20 2H4c-1.1 
      0-2 .9-2 2v18l4-4h14c1.1 
      0 2-.9 2-2V4c0-1.1-.9-2-2-2z"/></svg>
      Chat & Earn
    </a>

    <a href="notifications.php" class="<?= $current_page === 'notifications.php' ? 'active' : '' ?>">
      <svg viewBox="0 0 24 24"><path d="M12 22c1.1 0 2-.9 2-2h-4c0 1.1.9 2 2 2zm6-6v-5c0-3.07-1.64-5.64-4.5-6.32V4c0-.83-.67-1.5-1.5-1.5s-1.5.67-1.5 1.5v.68C7.63 5.36 6 7.92 6 11v5l-2 2v1h16v-1l-2-2z"/></svg>
      Notifications
    </a>

    <a href="settings.php" class="<?= $current_page === 'settings.php' ? 'active' : '' ?>">
      <svg viewBox="0 0 24 24"><path d="M19.14 12.94c.04-.31.06-.63.06-.94 
      0-.31-.02-.63-.06-.94l2.03-1.58a.5.5 
      0 0 0 .11-.66l-1.92-3.32a.5.5 
      0 0 0-.61-.22l-2.39.96a7.028 
      7.028 0 0 0-1.62-.94l-.36-2.54A.5.5 
      0 0 0 14.5 2h-5a.5.5 0 0 0-.5.42l-.36 
      2.54c-.6.24-1.14.56-1.62.94l-2.39-.96a.5.5 
      0 0 0-.61.22L2.1 8.78a.5.5 0 0 0 
      .11.66l2.03 1.58c-.04.31-.06.63-.06.94 
      0 .31.02.63.06.94l-2.03 1.58a.5.5 
      0 0 0-.11.66l1.92 3.32c.14.24.43.34.7.22l2.39-.96c.48.38 
      1.02.7 1.62.94l.36 2.54c.05.27.27.46.5.46h5c.23 
      0 .45-.19.5-.46l.36-2.54c.6-.24 
      1.14-.56 1.62-.94l2.39.96c.27.12.56.02.7-.22l1.92-3.32a.5.5 
      0 0 0-.11-.66l-2.03-1.58z"/></svg>
      Settings
    </a>


    <a href="../dashboard.php">
      <svg viewBox="0 0 24 24"><path d="M10 20v-6h4v6h5v-8h3L12 
      3 2 12h3v8z"/></svg>
      Back to Site
    </a>
  </nav>
</aside>

<script>
  function toggleSidebar() {
    document.getElementById('adminSidebar').classList.toggle('active');
  }
</script>
