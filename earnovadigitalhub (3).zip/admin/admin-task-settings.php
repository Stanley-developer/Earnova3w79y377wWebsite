<?php
require_once 'config/database.php';
require_once 'includes/session.php';
require_once 'includes/connect.php';

// Require authentication and admin check
requireLogin();
checkSessionTimeout();

$user = getCurrentUser();

// Check if user is admin (you may need to adjust this based on your admin system)
if (!isset($user['is_admin']) || $user['is_admin'] != 1) {
    header('Location: dashboard.php');
    exit;
}

$pdo = getDBConnection();

// Handle form submission
$message = '';
$message_type = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_settings'])) {
    $fake_total_tasks = intval($_POST['fake_total_tasks'] ?? 50);
    
    try {
        $stmt = $pdo->prepare("
            UPDATE task_display_settings 
            SET setting_value = ? 
            WHERE setting_key = 'fake_total_tasks'
        ");
        
        if ($stmt->execute([$fake_total_tasks])) {
            $message = 'Settings updated successfully!';
            $message_type = 'success';
        } else {
            $message = 'Failed to update settings.';
            $message_type = 'error';
        }
    } catch (PDOException $e) {
        $message = 'Database error: ' . $e->getMessage();
        $message_type = 'error';
    }
}

// Get current settings
try {
    $stmt = $pdo->prepare("SELECT * FROM task_display_settings WHERE setting_key = 'fake_total_tasks'");
    $stmt->execute();
    $current_setting = $stmt->fetch();
    $current_fake_total = $current_setting ? intval($current_setting['setting_value']) : 50;
    
    // Get real total tasks count
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM tasks WHERE is_active = 1");
    $stmt->execute();
    $real_total_tasks = $stmt->fetchColumn();
    
    // Get recent sync log
    $stmt = $pdo->prepare("
        SELECT * FROM task_count_sync_log 
        ORDER BY created_at DESC 
        LIMIT 20
    ");
    $stmt->execute();
    $sync_logs = $stmt->fetchAll();
    
} catch (PDOException $e) {
    $message = 'Error loading settings: ' . $e->getMessage();
    $message_type = 'error';
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Task Display Settings - Admin</title>
    <link rel="stylesheet" href="perform-task-page.css">
    <style>
        .admin-container {
            max-width: 1200px;
            margin: 40px auto;
            padding: 0 20px;
        }
        
        .admin-card {
            background: rgba(6, 16, 48, 0.95);
            border: 1px solid rgba(100, 154, 255, 0.3);
            border-radius: 24px;
            padding: 32px;
            margin-bottom: 24px;
        }
        
        .admin-header {
            margin-bottom: 32px;
        }
        
        .admin-header h1 {
            color: var(--page-white);
            font-size: 2rem;
            margin: 0 0 8px;
        }
        
        .admin-header p {
            color: rgba(205, 219, 255, 0.7);
            margin: 0;
        }
        
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 32px;
        }
        
        .stat-card {
            background: linear-gradient(135deg, rgba(77, 225, 193, 0.1), rgba(44, 92, 245, 0.1));
            border: 1px solid rgba(77, 225, 193, 0.3);
            border-radius: 16px;
            padding: 24px;
        }
        
        .stat-card h3 {
            color: rgba(205, 219, 255, 0.7);
            font-size: 0.9rem;
            margin: 0 0 8px;
            text-transform: uppercase;
            letter-spacing: 0.05em;
        }
        
        .stat-card .value {
            color: var(--page-mint);
            font-size: 2.5rem;
            font-weight: 700;
            margin: 0;
        }
        
        .form-group {
            margin-bottom: 24px;
        }
        
        .form-group label {
            display: block;
            color: var(--page-white);
            font-weight: 600;
            margin-bottom: 8px;
        }
        
        .form-group input[type="number"] {
            width: 100%;
            max-width: 300px;
            padding: 14px 16px;
            border-radius: 12px;
            border: 1px solid rgba(100, 154, 255, 0.3);
            background: rgba(8, 21, 64, 0.6);
            color: var(--page-white);
            font-size: 1rem;
            font-family: inherit;
        }
        
        .form-group input[type="number"]:focus {
            outline: none;
            border-color: rgba(77, 225, 193, 0.5);
        }
        
        .form-group .help-text {
            color: rgba(205, 219, 255, 0.6);
            font-size: 0.85rem;
            margin-top: 6px;
        }
        
        .btn-save {
            padding: 14px 32px;
            border-radius: 12px;
            border: none;
            background: linear-gradient(135deg, var(--page-mint), rgba(44, 92, 245, 0.9));
            color: var(--page-white);
            font-weight: 600;
            font-size: 1rem;
            cursor: pointer;
            transition: all 0.3s ease;
        }
        
        .btn-save:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 24px rgba(77, 225, 193, 0.3);
        }
        
        .alert {
            padding: 16px 20px;
            border-radius: 12px;
            margin-bottom: 24px;
            font-weight: 500;
        }
        
        .alert.success {
            background: rgba(77, 225, 193, 0.2);
            border: 1px solid rgba(77, 225, 193, 0.4);
            color: var(--page-mint);
        }
        
        .alert.error {
            background: rgba(255, 77, 77, 0.2);
            border: 1px solid rgba(255, 77, 77, 0.4);
            color: #ff4d4d;
        }
        
        .log-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 24px;
        }
        
        .log-table th {
            background: rgba(77, 225, 193, 0.1);
            color: var(--page-white);
            padding: 12px;
            text-align: left;
            font-weight: 600;
            border-bottom: 2px solid rgba(77, 225, 193, 0.3);
        }
        
        .log-table td {
            padding: 12px;
            color: rgba(205, 219, 255, 0.8);
            border-bottom: 1px solid rgba(100, 154, 255, 0.15);
        }
        
        .log-table tr:hover {
            background: rgba(77, 225, 193, 0.05);
        }
        
        .badge {
            display: inline-block;
            padding: 4px 12px;
            border-radius: 8px;
            font-size: 0.75rem;
            font-weight: 600;
            text-transform: uppercase;
        }
        
        .badge.completed {
            background: rgba(77, 225, 193, 0.2);
            color: var(--page-mint);
        }
        
        .badge.added {
            background: rgba(44, 92, 245, 0.2);
            color: #649aff;
        }
    </style>
</head>
<body>
    <?php include "header2.php"; ?>
    
    <div class="admin-container">
        <div class="admin-header">
            <h1>Task Display Settings</h1>
            <p>Manage fake and real task counts for free and premium users</p>
        </div>
        
        <?php if ($message): ?>
            <div class="alert <?php echo $message_type; ?>">
                <?php echo htmlspecialchars($message); ?>
            </div>
        <?php endif; ?>
        
        <div class="stats-grid">
            <div class="stat-card">
                <h3>Real Total Tasks</h3>
                <div class="value"><?php echo number_format($real_total_tasks); ?></div>
                <p style="color: rgba(205, 219, 255, 0.6); margin: 8px 0 0; font-size: 0.85rem;">
                    Shown to Premium Users
                </p>
            </div>
            
            <div class="stat-card">
                <h3>Fake Total Tasks</h3>
                <div class="value"><?php echo number_format($current_fake_total); ?></div>
                <p style="color: rgba(205, 219, 255, 0.6); margin: 8px 0 0; font-size: 0.85rem;">
                    Shown to Free Users
                </p>
            </div>
        </div>
        
        <div class="admin-card">
            <h2 style="color: var(--page-white); margin: 0 0 24px; font-size: 1.5rem;">Update Settings</h2>
            
            <form method="POST">
                <div class="form-group">
                    <label for="fake_total_tasks">Fake Total Tasks (Free Users)</label>
                    <input 
                        type="number" 
                        id="fake_total_tasks" 
                        name="fake_total_tasks" 
                        value="<?php echo $current_fake_total; ?>" 
                        min="0" 
                        max="10000"
                        required
                    >
                    <div class="help-text">
                        This number will be shown to free users as the total available tasks. It decreases when tasks are completed and increases when new tasks are added.
                    </div>
                </div>
                
                <button type="submit" name="update_settings" class="btn-save">
                    Save Settings
                </button>
            </form>
        </div>
        
        <div class="admin-card">
            <h2 style="color: var(--page-white); margin: 0 0 16px; font-size: 1.5rem;">Recent Sync Log</h2>
            <p style="color: rgba(205, 219, 255, 0.7); margin: 0 0 24px;">
                Track how fake and real task counts change when tasks are completed or added
            </p>
            
            <?php if (!empty($sync_logs)): ?>
                <table class="log-table">
                    <thead>
                        <tr>
                            <th>Action</th>
                            <th>Task ID</th>
                            <th>User ID</th>
                            <th>Fake Count</th>
                            <th>Real Count</th>
                            <th>Date</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($sync_logs as $log): ?>
                            <tr>
                                <td>
                                    <span class="badge <?php echo $log['action_type'] === 'task_completed' ? 'completed' : 'added'; ?>">
                                        <?php echo str_replace('_', ' ', $log['action_type']); ?>
                                    </span>
                                </td>
                                <td>#<?php echo $log['task_id']; ?></td>
                                <td><?php echo $log['user_id'] ? '#' . $log['user_id'] : 'N/A'; ?></td>
                                <td><?php echo $log['fake_count_before']; ?> → <?php echo $log['fake_count_after']; ?></td>
                                <td><?php echo $log['real_count_before']; ?> → <?php echo $log['real_count_after']; ?></td>
                                <td><?php echo date('M d, Y H:i', strtotime($log['created_at'])); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <p style="color: rgba(205, 219, 255, 0.6); text-align: center; padding: 40px;">
                    No sync logs yet
                </p>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>
