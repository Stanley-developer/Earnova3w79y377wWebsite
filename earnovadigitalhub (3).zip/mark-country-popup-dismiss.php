<?php
header('Content-Type: application/json; charset=utf-8');

require_once 'config/database.php';
require_once 'includes/session.php';
require_once 'includes/connect.php';

// Require authentication
if (!isLoggedIn()) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Not authenticated']);
    exit;
}

$user = getCurrentUser();
if (!$user) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'User not found']);
    exit;
}

$user_id = $user['id'];

try {
    $pdo = getDBConnection();

    // Update users.country_popup_dismissed to 1
    $stmt = $pdo->prepare("UPDATE users SET country_popup_dismissed = 1 WHERE id = ?");
    $result = $stmt->execute([$user_id]);

    if ($result) {
        http_response_code(200);
        echo json_encode(['success' => true, 'message' => 'Country popup dismissed']);
    } else {
        http_response_code(500);
        echo json_encode(['success' => false, 'message' => 'Update failed']);
    }
} catch (PDOException $e) {
    error_log('Country popup dismiss error: ' . $e->getMessage());
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
} catch (Exception $e) {
    error_log('Country popup dismiss error: ' . $e->getMessage());
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Error: ' . $e->getMessage()]);
}

exit;
?>
