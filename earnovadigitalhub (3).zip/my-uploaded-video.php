<?php
require_once 'config/database.php';
require_once 'includes/session.php';
require_once 'includes/connect.php';

// Require authentication
requireLogin();
checkSessionTimeout();

// Get current user data
$user = getCurrentUser();
$user_id = $user['id'];

try {
    $pdo = getDBConnection();
    
    // Fetch user details with balances
    $stmt = $pdo->prepare("
        SELECT u.*, b.total_balance, b.task_earnings, b.referral_earnings
        FROM users u
        LEFT JOIN balances b ON u.id = b.user_id
        WHERE u.id = ?
    ");
    $stmt->execute([$user_id]);
    $user_data = $stmt->fetch();
    
    if (!$user_data) {
        header('Location: login.php');
        exit;
    }
    
    // Platform prices per 10 participants (in Naira)
    $platform_prices = [
        'youtube' => ['name' => 'YouTube', 'price' => 400],
        'tiktok' => ['name' => 'TikTok', 'price' => 320],
        'instagram' => ['name' => 'Instagram', 'price' => 350],
        'facebook' => ['name' => 'Facebook', 'price' => 350],
        'twitter' => ['name' => 'Twitter/X', 'price' => 380],
        'linkedin' => ['name' => 'LinkedIn', 'price' => 350]
    ];
    
    // Handle actions
    $message = '';
    $messageType = '';
    
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $action = $_POST['action'] ?? '';
        $video_id = intval($_POST['video_id'] ?? 0);
        
        if ($action === 'pause' && $video_id > 0) {
            // Pause video
            $stmt = $pdo->prepare("UPDATE available_videos SET is_active = 0 WHERE id = ? AND uploaded_by_user_id = ?");
            $stmt->execute([$video_id, $user_id]);
            $_SESSION['video_message'] = 'Video paused successfully';
            $_SESSION['video_message_type'] = 'success';
            header('Location: my-uploaded-video.php');
            exit;
            
        } elseif ($action === 'resume' && $video_id > 0) {
            // Resume video
            $stmt = $pdo->prepare("UPDATE available_videos SET is_active = 1 WHERE id = ? AND uploaded_by_user_id = ?");
            $stmt->execute([$video_id, $user_id]);
            $_SESSION['video_message'] = 'Video resumed successfully';
            $_SESSION['video_message_type'] = 'success';
            header('Location: my-uploaded-video.php');
            exit;
            
        } elseif ($action === 'edit' && $video_id > 0) {
            // Edit video
            $title = trim($_POST['title'] ?? '');
            $description = trim($_POST['description'] ?? '');
            $video_url = trim($_POST['video_url'] ?? '');
            
            if (empty($title) || empty($description) || empty($video_url)) {
                $_SESSION['video_message'] = 'Please fill in all fields';
                $_SESSION['video_message_type'] = 'error';
            } elseif (!filter_var($video_url, FILTER_VALIDATE_URL)) {
                $_SESSION['video_message'] = 'Please provide a valid URL';
                $_SESSION['video_message_type'] = 'error';
            } else {
                // Get original video to verify platform matches
                $stmt = $pdo->prepare("SELECT platform FROM available_videos WHERE id = ? AND uploaded_by_user_id = ?");
                $stmt->execute([$video_id, $user_id]);
                $original_video = $stmt->fetch();
                
                if ($original_video) {
                    // Update video
                    $stmt = $pdo->prepare("UPDATE available_videos SET title = ?, description = ?, video_url = ? WHERE id = ? AND uploaded_by_user_id = ?");
                    $stmt->execute([$title, $description, $video_url, $video_id, $user_id]);
                    
                    $_SESSION['video_message'] = 'Video updated successfully';
                    $_SESSION['video_message_type'] = 'success';
                }
            }
            header('Location: my-uploaded-video.php');
            exit;
            
        } elseif ($action === 'extend' && $video_id > 0) {
            $additional_participants = intval($_POST['additional_participants'] ?? 0);
            
            if ($additional_participants < 10) {
                $_SESSION['video_message'] = 'Minimum 10 additional participants required';
                $_SESSION['video_message_type'] = 'error';
            } elseif ($additional_participants > 1000) {
                $_SESSION['video_message'] = 'Maximum 1000 additional participants allowed';
                $_SESSION['video_message_type'] = 'error';
            } else {
                // Get video details
                $stmt = $pdo->prepare("
                    SELECT * FROM available_videos 
                    WHERE id = ? AND uploaded_by_user_id = ?
                ");
                $stmt->execute([$video_id, $user_id]);
                $video = $stmt->fetch();
                
                if ($video) {
                    $base_price = $platform_prices[$video['platform']]['price'];
                    $extension_cost = ($additional_participants / 10) * $base_price;
                    
                    $available_balance = $user_data['referral_earnings'];
                    
                    if ($available_balance < $extension_cost) {
                        $_SESSION['video_message'] = 'Insufficient Balance for extension';
                        $_SESSION['video_message_type'] = 'error';
                    } else {
                        $pdo->beginTransaction();
                        try {
                            // Deduct from user's balance
                            $stmt = $pdo->prepare("UPDATE balances SET referral_earnings = referral_earnings - ?, total_balance = total_balance - ? WHERE user_id = ?");
                            $stmt->execute([$extension_cost, $extension_cost, $user_id]);
                            
                            // Record transaction
                            $stmt = $pdo->prepare("INSERT INTO transactions (user_id, transaction_type, amount, balance_type, description, reference_id, created_at) VALUES (?, 'video_extension', ?, 'prime_earnings', ?, ?, NOW())");
                            $description_text = "Extended video: {$video['title']} by {$additional_participants} participants";
                            $stmt->execute([$user_id, $extension_cost, $description_text, "EXTEND-VIDEO-{$video_id}"]);
                            
                            $pdo->commit();
                            $_SESSION['video_message'] = "Video extended successfully! Added {$additional_participants} participants.";
                            $_SESSION['video_message_type'] = 'success';
                            
                            // Refresh user data
                            $stmt = $pdo->prepare("SELECT u.*, b.total_balance, b.task_earnings, b.referral_earnings FROM users u LEFT JOIN balances b ON u.id = b.user_id WHERE u.id = ?");
                            $stmt->execute([$user_id]);
                            $user_data = $stmt->fetch();
                            
                        } catch (Exception $e) {
                            $pdo->rollBack();
                            $_SESSION['video_message'] = 'Failed to extend video';
                            $_SESSION['video_message_type'] = 'error';
                        }
                    }
                }
            }
            header('Location: my-uploaded-video.php');
            exit;
        }
    }
    
    $message = $_SESSION['video_message'] ?? '';
    $messageType = $_SESSION['video_message_type'] ?? '';
    if ($message) {
        unset($_SESSION['video_message']);
        unset($_SESSION['video_message_type']);
    }
    
    // Fetch user's uploaded videos
    $stmt = $pdo->prepare("
        SELECT 
            id,
            video_id,
            title,
            description,
            video_url,
            platform,
            thumbnail_url,
            duration,
            free_reward,
            premium_reward,
            is_active,
            created_at,
            video_file_path
        FROM available_videos
        WHERE uploaded_by_user_id = ?
        ORDER BY created_at DESC
    ");
    $stmt->execute([$user_id]);
    $uploaded_videos = $stmt->fetchAll();
    
} catch (PDOException $e) {
    error_log("My Uploaded Videos Error: " . $e->getMessage());
    $error_message = "Unable to load videos.";
}

$username = htmlspecialchars($user_data['username'] ?? 'User');

function getVideoViewCount($pdo, $video_id, $user_id) {
    try {
        // Get count of users who watched the video
        $stmt = $pdo->prepare("SELECT COUNT(DISTINCT user_id) as count FROM video_watch WHERE video_id = ? AND status = 'completed'");
        $stmt->execute([$video_id]);
        $result = $stmt->fetch();
        return $result['count'] ?? 0;
    } catch (Exception $e) {
        error_log("Error getting video view count: " . $e->getMessage());
        return 0;
    }
}
?>
<?php include "doctype.php"; ?>
<link rel="stylesheet" href="my-posted-task.css" />

<body>
    
<?php include "embed.php"; ?>
<?php include "header2.php"; ?>
<div class="page-shell">
    
    <main>
      <!-- Alert message -->
      <?php if ($message): ?>
        <div id="toast-<?php echo $messageType; ?>" class="toast-message <?php echo $messageType; ?>">
          <?php echo htmlspecialchars($message); ?>
        </div>
      <?php endif; ?>

      <section class="hero-section">
        <div class="hero-content">
          <h1 style="font-size: 18px;">Video Management Center
             <div class="stats-box">
        <h4>Quick Stats</h4>
        <div class="stat-item">
          <span>Total Videos</span>
          <strong><?php echo count($uploaded_videos); ?></strong>
        </div>
        <div class="stat-item">
          <span>Active Videos</span>
          <strong><?php echo count(array_filter($uploaded_videos, fn($v) => $v['is_active'])); ?></strong>
        </div>
          </h1>
          <p>Monitor your uploaded videos, track viewer engagement, and manage video settings all in one place.</p>
        </div>
        <a href="upload-video.php" class="btn-primary">+ Upload New Video</a>
      </section>

      <?php if (empty($uploaded_videos)): ?>
        <section class="empty-state">
          <svg viewBox="0 0 24 24" width="80" height="80" fill="rgba(77, 225, 193, 0.3)">
            <path d="M17 10.5V7a1 1 0 0 0-1-1H4a1 1 0 0 0-1 1v10a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-3.5l4 4v-11l-4 4z"/>
          </svg>
          <h2>No Videos Uploaded Yet</h2>
          <p>Start by uploading your first video and reach thousands of users across multiple platforms.</p>
          <a href="upload-video.php" class="btn-primary">Upload Your First Video</a>
        </section>
      <?php else: ?>
        <section class="tasks-grid">
          <?php foreach ($uploaded_videos as $video): 
            $platform = $video['platform'];
            $view_count = getVideoViewCount($pdo, $video['video_id'], $user_id);
            $total_views = 10; // Fixed at 10 participants for user uploads
            $completion_rate = $total_views > 0 ? ($view_count / $total_views) * 100 : 0;
          ?>
            <article class="task-card <?php echo $video['is_active'] ? 'active' : 'paused'; ?>">
              <div class="task-header">
                <div class="platform-icon" data-platform="<?php echo $platform; ?>">
                  <?php echo getPlatformSVG($platform); ?>
                </div>
                <div class="task-status">
                  <?php if ($video['is_active']): ?>
                      <span class="status-badge active">Active</span>
                  <?php else: ?>
                      <span class="status-badge paused">Paused</span>
                  <?php endif; ?>
                </div>
              </div>
              
              <h3 class="task-title"><?php echo htmlspecialchars($video['title']); ?></h3>
              <p class="task-description"><?php echo htmlspecialchars(substr($video['description'], 0, 100)) . (strlen($video['description']) > 100 ? '...' : ''); ?></p>
              
              <!-- Added video player for users to watch their uploaded videos -->
              <?php if (!empty($video['video_file_path']) && file_exists($video['video_file_path'])): ?>
              <div class="video-player-container">
                <video 
                  id="video-<?php echo $video['id']; ?>"
                  class="video-player" 
                  controls 
                  controlsList="nodownload"
                  preload="metadata"
                >
                  <source src="<?php echo htmlspecialchars($video['video_file_path']); ?>" type="video/mp4">
                  Your browser does not support the video tag.
                </video>
                <button class="fullscreen-btn" onclick="toggleFullscreen('video-<?php echo $video['id']; ?>')">
                  <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M7 14H5v5h5v-2H7v-3zm-2-4h2V7h3V5H5v5zm12 7h-3v2h5v-5h-2v3zM14 5v2h3v3h2V5h-5z"/>
                  </svg>
                  Fullscreen
                </button>
              </div>
              <?php endif; ?>
              <!-- </CHANGE> -->
              
              <div class="task-stats">
                <div class="stat">
                  <span class="stat-label">Views</span>
                  <span class="stat-value"><?php echo $view_count; ?> / <?php echo $total_views; ?></span>
                </div>
                
                <div class="stat">
                  <span class="stat-label">Duration</span>
                  <span class="stat-value"><?php echo round($video['duration']); ?>s</span>
                </div>
                
                <div class="stat">
                  <span class="stat-label">Platform</span>
                  <span class="stat-value"><?php echo $platform_prices[$platform]['name'] ?? ucfirst($platform); ?></span>
                </div>
              </div>
              
              <div class="progress-bar">
                <div class="progress-fill" style="width: <?php echo round($completion_rate); ?>%"></div>
              </div>
              <p class="progress-text"><?php echo round($completion_rate); ?>% Complete</p>
              
              <div class="task-actions">
                <?php if ($video['is_active']): ?>
                  <form method="POST" style="display: inline;">
                    <input type="hidden" name="action" value="pause">
                    <input type="hidden" name="video_id" value="<?php echo $video['id']; ?>">
                    <button type="submit" class="btn-action btn-pause">
                      <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" fill="currentColor" viewBox="0 0 24 24">
                        <path d="M6 4h4v16H6zM14 4h4v16h-4z"/>
                      </svg>
                    </button>
                  </form>
                <?php else: ?>
                  <form method="POST" style="display: inline;">
                    <input type="hidden" name="action" value="resume">
                    <input type="hidden" name="video_id" value="<?php echo $video['id']; ?>">
                    <button type="submit" class="btn-action btn-resume">
                      <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" fill="currentColor" viewBox="0 0 24 24">
                        <path d="M8 5v14l11-7z"/>
                      </svg>
                    </button>
                  </form>
                <?php endif; ?>
                
                <button class="btn-action btn-edit" onclick="openEditModal(<?php echo htmlspecialchars(json_encode($video)); ?>)">
                  <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M3 17.25V21h3.75L17.81 9.94l-3.75-3.75L3 17.25zM20.71 7.04a1.003 1.003 0 0 0 0-1.42l-2.34-2.34a1.003 1.003 0 0 0-1.42 0l-1.83 1.83 3.75 3.75 1.84-1.82z"/>
                  </svg>
                </button>
                
                <button class="btn-action btn-extend" onclick="openExtendModal(<?php echo $video['id']; ?>, '<?php echo $platform; ?>')">
                  <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M12 8v5l4 2 .75-1.23-3.25-1.52V8h-1.5zM12 2a10 10 0 1 0 0 18 10 10 0 0 0 0-16z"/>
                  </svg>
                </button>
              </div>
              
              <div class="task-meta">
                <span>Uploaded: <?php echo date('M d, Y', strtotime($video['created_at'])); ?></span>
                <a href="<?php echo htmlspecialchars($video['video_url']); ?>" target="_blank" class="task-link">View Video →</a>
              </div>
            </article>
          <?php endforeach; ?>
        </section>
      <?php endif; ?>

   
  <div id="editModal" class="modal">
    <div class="modal-content">
      <span class="close" onclick="closeEditModal()">&times;</span>
      <h2>Edit Video</h2>
      <form method="POST" id="editForm">
        <input type="hidden" name="action" value="edit">
        <input type="hidden" name="video_id" id="edit_video_id">
        
        <div class="form-group">
          <label for="edit_title">Video Title</label>
          <input type="text" id="edit_title" name="title" required>
        </div>
        
        <div class="form-group">
          <label for="edit_description">Description</label>
          <textarea id="edit_description" name="description" rows="4" required></textarea>
        </div>
        
        <div class="form-group">
          <label for="edit_video_url">Video URL</label>
          <input type="url" id="edit_video_url" name="video_url" required>
          <small>Platform-specific URL for your video</small>
        </div>
        
        <button type="submit" class="btn-primary">Save Changes</button>
      </form>
    </div>
  </div>

   
  <div id="extendModal" class="modal">
    <div class="modal-content">
      <span class="close" onclick="closeExtendModal()">&times;</span>
      <h2>Extend Video Reach</h2>
      <form method="POST" id="extendForm" onsubmit="return validateExtendForm()">
        <input type="hidden" name="action" value="extend">
        <input type="hidden" name="video_id" id="extend_video_id">
        
        <div class="form-group">
          <label for="additional_participants">Additional Participants</label>
          <input type="text" id="additional_participants" name="additional_participants" value="10" inputmode="numeric" pattern="[0-9]*" required>
          <small>Minimum 10, Maximum 1000 participants</small>
        </div>
        
        <div class="pricing-summary">
          <h3>Extension Cost</h3>
          <div class="summary-row">
            <span>Platform:</span>
            <span id="extend_platform">--</span>
          </div>
          <div class="summary-row">
            <span>Additional Participants:</span>
            <span id="extend_participants">10</span>
          </div>
          <div class="summary-row total">
            <span>Total Cost:</span>
            <span id="extend_cost">₦0.00</span>
          </div>
          <p class="note">Payment will be deducted from your Prime earnings.</p>
        </div>
        
        <button type="submit" class="btn-primary">Extend Video</button>
      </form>
    </div>
  </div>

   <nav class="mobile-fintech-footer">
    
  <a href="dashboard.php">
    <svg viewBox="0 0 24 24"><path d="M12 3a9 9 0 1 1 0 18 9 9 0 0 1 0-18Zm1 4h-2v6h6v-2h-4V7Z"/></svg>
    <span>Dashboard</span>
  </a>

  <a href="membership.php">
    <svg viewBox="0 0 24 24"><path d="M5 7l2.5 5 4.5-4 4.5 4L19 7l2 13H3l2-13Z"/></svg>
    <span>Premium</span>
  </a>

  <a href="upload-video.php">
    <svg viewBox="0 0 24 24" aria-hidden="true">
      <path d="M17 10.5V7a1 1 0 0 0-1-1H4a1 1 0 0 0-1 1v10a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-3.5l4 4v-11l-4 4z"/>
    </svg>
    <span>Upload Video</span>
  </a>

  <a href="history.php">
    <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
      <path d="M13 3a9 9 0 1 0 9 9h-2a7 7 0 1 1-7-7V3l4 4-4 4V7a5 5 0 1 0 5 5h2a7 7 0 1 1-7-7z"/>
    </svg>
    <span>History</span>
  </a>

  <a href="profile.php">
    <svg viewBox="0 0 24 24"><path d="M12 2a6 6 0 0 1 6 6c0 3.31-2.69 6-6 6s-6-2.69-6-6a6 6 0 0 1 6-6Zm0 14c4.42 0 8 1.79 8 4v2H4v-2c0-2.21 3.58-4 8-4Z"/></svg>
    <span>Profile</span>
  </a>
</nav>

    </main>
  </div>

  <!-- Toast message styles -->
  <style>
    .toast-message {
      position: fixed;
      top: 20px;
      right: -400px;
      padding: 16px 24px;
      border-radius: 12px;
      color: white;
      font-family: 'Segoe UI', sans-serif;
      font-size: 15px;
      z-index: 1000;
      opacity: 0;
      box-shadow: 0 10px 40px rgba(0, 0, 0, 0.2);
      transition: right 0.6s ease, opacity 0.6s ease;
    }

    .toast-message.success {
      background: rgba(77, 225, 193, 0.95);
      color: #030922;
      box-shadow: 0 10px 40px rgba(77, 225, 193, 0.4);
    }

    .toast-message.error {
      background: rgba(255, 77, 77, 0.95);
      color: #fff;
      box-shadow: 0 10px 40px rgba(255, 77, 77, 0.4);
    }

    .toast-message.show {
      right: 20px;
      opacity: 1;
    }
    
    /* Added video player styles */
    .video-player-container {
      position: relative;
      width: 100%;
      margin: 15px 0;
      border-radius: 12px;
      overflow: hidden;
      background: #000;
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
    }
    
    .video-player {
      width: 100%;
      max-height: 250px;
      display: block;
      background: #000;
    }
    
    .fullscreen-btn {
      position: absolute;
      bottom: 12px;
      right: 12px;
      background: rgba(3, 9, 34, 0.85);
      color: rgba(77, 225, 193, 1);
      border: 1px solid rgba(77, 225, 193, 0.3);
      padding: 8px 16px;
      border-radius: 8px;
      font-size: 13px;
      font-weight: 500;
      cursor: pointer;
      display: flex;
      align-items: center;
      gap: 6px;
      transition: all 0.3s ease;
      z-index: 10;
    }
    
    .fullscreen-btn:hover {
      background: rgba(77, 225, 193, 0.15);
      border-color: rgba(77, 225, 193, 0.6);
      transform: translateY(-2px);
    }
    
    .fullscreen-btn svg {
      width: 16px;
      height: 16px;
    }
    
    @media (max-width: 768px) {
      .video-player {
        max-height: 200px;
      }
      
      .fullscreen-btn {
        padding: 6px 12px;
        font-size: 12px;
        bottom: 8px;
        right: 8px;
      }
    }
    /* </CHANGE> */
  </style>

<script>

// Initialize toasts when page loads
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', initializeToast);
} else {
  initializeToast();
}

function toggleFullscreen(videoId) {
  const video = document.getElementById(videoId);
  
  if (!video) return;
  
  if (!document.fullscreenElement) {
    if (video.requestFullscreen) {
      video.requestFullscreen();
    } else if (video.webkitRequestFullscreen) {
      video.webkitRequestFullscreen();
    } else if (video.msRequestFullscreen) {
      video.msRequestFullscreen();
    }
  } else {
    if (document.exitFullscreen) {
      document.exitFullscreen();
    } else if (document.webkitExitFullscreen) {
      document.webkitExitFullscreen();
    } else if (document.msExitFullscreen) {
      document.msExitFullscreen();
    }
  }
}
// </CHANGE>
</script>

<?php
function getPlatformSVG($platform) {
    $svgs = [
        'tiktok' => '<svg viewBox="0 0 24 24" fill="#ffffff" aria-hidden="true"><path d="M19.59 6.69a4.83 4.83 0 0 1-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 0 1-5.2 1.74 2.89 2.89 0 0 1 2.31-4.64 2.93 2.93 0 0 1 .88.13V9.4a6.84 6.84 0 0 0-1-.05A6.33 6.33 0 0 0 5 20.1a6.34 6.34 0 0 0 10.86-4.43v-7a8.16 8.16 0 0 0 4.77 1.52v-3.4a4.85 4.85 0 0 1-1-.1z"/></svg>',
        'instagram' => '<svg viewBox="0 0 24 24" aria-hidden="true"><defs><linearGradient id="igGrad" x1="0" x2="1" y1="0" y2="1"><stop offset="0" stop-color="#f58529"/><stop offset="0.3" stop-color="#dd2a7b"/><stop offset="0.6" stop-color="#8134af"/><stop offset="1" stop-color="#515bd4"/></linearGradient></defs><path fill="url(#igGrad)" d="M7.8 2h8.4C19.4 2 22 4.6 22 7.8v8.4a5.8 5.8 0 0 1-5.8 5.8H7.8C4.6 22 2 19.4 2 16.2V7.8A5.8 5.8 0 0 1 7.8 2m-.2 2A3.6 3.6 0 0 0 4 7.6v8.8C4 18.39 5.61 20 7.6 20h8.8a3.6 3.6 0 0 0 3.6-3.6V7.6C20 5.61 18.39 4 16.4 4H7.6m9.65 1.5a1.25 1.25 0 0 1 1.25 1.25A1.25 1.25 0 0 1 17.25 8 1.25 1.25 0 0 1 16 6.75a1.25 1.25 0 0 1 1.25-1.25m0 2a3 3 0 0 0-3 3 3 3 0 0 0 3 3 3 3 0 0 0 3-3 3 3 0 0 0-3-3z"/></svg>',
        'youtube' => '<svg viewBox="0 0 24 24" fill="#FF0000" aria-hidden="true"><path d="M10 15l5.19-3L10 9v6m11.56-7.83c.13.47.22 1.1.28 1.9.07.8.1 1.49.1 2.09L22 12c0 2.19-.16 3.8-.44 4.83-.25.9-.83 1.48-1.73 1.73-.47.13-1.33.22-2.65.28-1.3.07-2.49.1-3.59.1L12 5c-4.19 0-6.8.16-7.83.44-.9.25-1.48.83-1.73 1.73-.13-.47-.22-1.1-.28-1.9-.07-.8-.1-1.49-.1-2.09L2 12c0-2.19.16-3.8.44-4.83.25-.9.83-1.48 1.73-1.73.47-.13 1.33-.22 2.65-.28 1.3-.07 2.49-.1 3.59-.1L12 5c4.19 0 6.8.16 7.83.44.9.25 1.48.83 1.73 1.73z"/></svg>',
        'facebook' => '<svg viewBox="0 0 24 24" fill="#1877F2" aria-hidden="true"><path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/></svg>',
        'twitter' => '<svg viewBox="0 0 24 24" fill="#ffffff" aria-hidden="true" xmlns="http://www.w3.org/2000/svg"><path fill="currentColor" d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24h-6.66l-5.214-6.817-5.97 6.817H1.67l7.73-8.835L1.254 2.25h6.83l4.713 6.231 5.447-6.231zm-1.161 17.52h1.833L7.084 4.126H5.117l11.966 15.644z"/></svg>',
        'linkedin' => '<svg viewBox="0 0 24 24" fill="#0077B5" aria-hidden="true"><path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433c-1.144 0-2.063-.926-2.063-2.065 0-1.138.92-2.063 2.063-2.063 1.14 0 2.064.925 2.064 2.063 0 1.139-.925 2.065-2.064 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z"/></svg>',
    ];
    
    return $svgs[$platform] ?? '<svg viewBox="0 0 24 24" fill="#ffffff" aria-hidden="true"><path d="M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20z"/></svg>';
}
?>

</body>
</html>
