<?php
require_once 'config/database.php';
require_once 'includes/session.php';
require_once 'includes/connect.php';

// Require authentication
requireLogin();
checkSessionTimeout();

// Get current user data
$user = getCurrentUser();
$user_id = $user['id'];

try {
    $pdo = getDBConnection();
    
    // Fetch user details with balance
    $stmt = $pdo->prepare("SELECT u.*, b.total_balance, b.referral_earnings, b.game_earnings, b.task_earnings FROM users u LEFT JOIN balances b ON u.id = b.user_id WHERE u.id = ?");
    $stmt->execute([$user_id]);
    $user_data = $stmt->fetch();
    
    if (!$user_data) {
        header('Location: login.php');
        exit;
    }
    
    $is_premium = ($user_data['membership_type'] === 'premium');
    
} catch (PDOException $e) {
    error_log("Plinko 3D Error: " . $e->getMessage());
    $error_message = "Unable to load game data.";
}

$referral_earnings = $user_data['referral_earnings'] ?? 0;
$game_earnings = $user_data['game_earnings'] ?? 0;
$task_earnings = $user_data['task_earnings'] ?? 0;
$membership_type = $user_data['membership_type'] ?? 'free';
$user_email = $user_data['email'] ?? '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Plinko 3D - FlowEarner</title>
    <link rel="stylesheet" href="assets/css/gamified-fintech-theme.css">
    <script src="https://cdn.jsdelivr.net/npm/three@0.160.0/build/three.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/three@0.160.0/examples/js/controls/OrbitControls.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/matter-js/0.19.0/matter.min.js"></script>
    <style>
        :root {
            --page-blue-900: #030922;
            --page-blue-800: #0a1642;
            --page-blue-700: #0a164a;
            --page-blue-500: #142e7e;
            --page-mint: #4de1c1;
            --page-white: #f5f9ff;
            --page-orange: #fb923c;
            --page-gold: #fbbf24;
        }

        * { box-sizing: border-box; margin: 0; padding: 0; }

        body {
            font-family: 'Inter', sans-serif;
            background: linear-gradient(135deg, #0a0e27 0%, #1a1f3a 100%);
            color: #fff;
            overflow-x: hidden;
        }
        
        .container {
            max-width: 1400px;
            margin: 0 auto;
            padding: 20px;
        }
        
        .page-header {
            text-align: center;
            padding: 30px 20px;
            background: linear-gradient(135deg, rgba(44, 91, 245, 0.2), rgba(77, 225, 193, 0.1));
            border-radius: 20px;
            margin-bottom: 20px;
        }
        
        .page-header h1 {
            font-size: 2.5rem;
            margin: 0 0 10px;
            background: linear-gradient(135deg, #2c5bf5, #4de1c1);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }
        
        .back-link {
            display: inline-block;
            margin-bottom: 20px;
            color: var(--page-mint);
            text-decoration: none;
            font-size: 1rem;
            transition: color 0.3s ease;
        }
        
        .back-link:hover {
            color: #fff;
        }
        
        .game-layout {
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 20px;
            margin-bottom: 30px;
        }
        
        .game-canvas-container {
            background: linear-gradient(135deg, #1a2a5e 0%, #0f1937 100%);
            border: 2px solid rgba(77, 225, 193, 0.2);
            border-radius: 30px;
            padding: 20px 0;
            position: relative;
            width: 100%;
            max-width: 850px;
            height: 720px;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: space-between;
            overflow: hidden;
            box-shadow: 0 10px 40px rgba(0, 0, 0, 0.5);
        }
        
        .top-balance-bar {
            display: flex;
            justify-content: flex-end;
            align-items: center;
            width: 100%;
            padding: 10px 20px;
            gap: 15px;
        }
        
        .balance-chip {
            background: rgba(10, 22, 66, 0.8);
            border: 2px solid rgba(77, 225, 193, 0.3);
            border-radius: 25px;
            padding: 8px 20px;
            display: flex;
            align-items: center;
            gap: 10px;
            cursor: pointer;
            transition: all 0.3s ease;
        }
        
        .balance-chip:hover {
            background: rgba(10, 22, 66, 1);
            border-color: var(--page-mint);
        }
        
        .balance-chip-icon {
            font-size: 1.2rem;
        }
        
        .balance-chip-value {
            color: #fff;
            font-weight: 600;
            font-size: 1rem;
        }
        
        .deposit-chip {
            background: linear-gradient(135deg, #fb923c, #f97316);
            border: none;
            color: #fff;
            font-weight: 700;
            padding: 10px 25px;
        }
        
        .deposit-chip:hover {
            transform: scale(1.05);
        }
        
        .canvas-wrapper {
            width: 100%;
            flex: 1;
            display: flex;
            align-items: center;
            justify-content: center;
            position: relative;
            padding: 0;
        }
        
        #plinko3DCanvas {
            width: 100%;
            height: 100%;
            border-radius: 0;
        }
        
        .bottom-controls {
            width: 100%;
            background: rgba(10, 22, 66, 0.6);
            border-radius: 20px;
            padding: 20px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 15px;
        }
        
        .bet-controls {
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .bet-label {
            color: rgba(255, 255, 255, 0.7);
            font-size: 0.9rem;
            margin-right: 5px;
        }
        
        .bet-btn {
            width: 40px;
            height: 40px;
            border-radius: 10px;
            border: 2px solid rgba(251, 146, 60, 0.5);
            background: rgba(251, 146, 60, 0.1);
            color: var(--page-orange);
            font-size: 1.2rem;
            cursor: pointer;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        .bet-btn:hover {
            background: rgba(251, 146, 60, 0.3);
            border-color: var(--page-orange);
        }
        
        .bet-display {
            background: rgba(10, 22, 66, 0.8);
            border: 2px solid rgba(77, 225, 193, 0.3);
            border-radius: 12px;
            padding: 10px 30px;
            color: #fff;
            font-size: 1.2rem;
            font-weight: 600;
            min-width: 120px;
            text-align: center;
        }
        
        .play-button {
            background: linear-gradient(135deg, #fb923c, #f97316);
            border: none;
            border-radius: 15px;
            padding: 12px 50px;
            color: #fff;
            font-size: 1.3rem;
            font-weight: 700;
            cursor: pointer;
            transition: all 0.3s ease;
            text-transform: uppercase;
            letter-spacing: 1px;
        }
        
        .play-button:hover:not(:disabled) {
            transform: scale(1.05);
            box-shadow: 0 0 30px rgba(251, 146, 60, 0.8);
        }
        
        .play-button:disabled {
            opacity: 0.5;
            cursor: not-allowed;
        }
        
        .info-btn {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            border: 2px solid rgba(77, 225, 193, 0.5);
            background: rgba(77, 225, 193, 0.1);
            color: var(--page-mint);
            font-size: 1.2rem;
            cursor: pointer;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        .info-btn:hover {
            background: rgba(77, 225, 193, 0.3);
        }
        
        .particles {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            pointer-events: none;
            overflow: hidden;
        }
        
        .particle {
            position: absolute;
            width: 3px;
            height: 3px;
            background: var(--page-gold);
            border-radius: 50%;
            animation: float 10s infinite;
            opacity: 0.6;
        }
        
        @keyframes float {
            0%, 100% {
                transform: translateY(0) translateX(0);
                opacity: 0;
            }
            10% {
                opacity: 0.6;
            }
            90% {
                opacity: 0.6;
            }
            100% {
                transform: translateY(-100vh) translateX(50px);
                opacity: 0;
            }
        }
        
        .modal-overlay {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.9);
            z-index: 1000;
            align-items: center;
            justify-content: center;
            opacity: 0;
            transition: opacity 0.3s ease;
        }
        
        .modal-overlay.active {
            display: flex;
            opacity: 1;
        }
        
        .modal-content {
            background: linear-gradient(135deg, #0a0e27, #1a1f3a);
            border-radius: 30px;
            padding: 40px;
            max-width: 600px;
            width: 90%;
            border: 2px solid rgba(77, 225, 193, 0.3);
            text-align: center;
            position: relative;
            max-height: 90vh;
            overflow-y: auto;
            transform: scale(0.95);
            transition: transform 0.3s ease;
        }

        .modal-overlay.active .modal-content {
            transform: scale(1);
        }
        
        .modal-close {
            position: absolute;
            top: 20px;
            right: 20px;
            background: rgba(255, 59, 48, 0.2);
            border: 2px solid rgba(255, 59, 48, 0.5);
            color: #ff3b30;
            padding: 8px 16px;
            border-radius: 10px;
            cursor: pointer;
            font-weight: 600;
            z-index: 10;
        }
        
        .modal-icon {
            font-size: 5rem;
            margin-bottom: 20px;
        }
        
        .modal-title {
            font-size: 2rem;
            margin-bottom: 15px;
        }
        
        .modal-message {
            font-size: 1.1rem;
            color: rgba(255, 255, 255, 0.8);
            line-height: 1.6;
            margin-bottom: 30px;
        }
        
        .modal-btn {
            padding: 15px 40px;
            border-radius: 15px;
            border: none;
            background: linear-gradient(135deg, #2c5bf5, #4de1c1);
            color: #fff;
            font-size: 1.1rem;
            font-weight: 700;
            cursor: pointer;
            margin: 0 10px;
            transition: all 0.3s ease;
        }
        
        .modal-btn:hover {
            transform: scale(1.05);
        }
        
        .tutorial-steps {
            text-align: left;
            margin: 20px 0;
            position: relative;
        }
        
        .tutorial-step {
            background: rgba(77, 225, 193, 0.1);
            padding: 20px;
            border-radius: 15px;
            margin-bottom: 15px;
            display: none;
        }
        
        .tutorial-step.active {
            display: block;
            animation: slideIn 0.3s ease;
        }
        
        @keyframes slideIn {
            from {
                opacity: 0;
                transform: translateX(-20px);
            }
            to {
                opacity: 1;
                transform: translateX(0);
            }
        }
        
        .tutorial-step h4 {
            color: var(--page-mint);
            margin-bottom: 12px;
            font-size: 1.3rem;
        }
        
        .tutorial-step p {
            line-height: 1.6;
            font-size: 1rem;
        }
        
        .tutorial-navigation {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-top: 30px;
            gap: 15px;
        }
        
        .tutorial-nav-btn {
            padding: 12px 30px;
            border-radius: 12px;
            border: none;
            background: linear-gradient(135deg, #2c5bf5, #4de1c1);
            color: #fff;
            font-size: 1rem;
            font-weight: 600;
            cursor: pointer;
            display: flex;
            align-items: center;
            gap: 8px;
            transition: all 0.3s ease;
        }
        
        .tutorial-nav-btn:hover {
            transform: scale(1.05);
        }
        
        .tutorial-nav-btn:disabled {
            opacity: 0.3;
            cursor: not-allowed;
            transform: scale(1);
        }
        
        .tutorial-progress {
            text-align: center;
            color: rgba(255, 255, 255, 0.7);
            font-size: 0.9rem;
        }
        
        .tutorial-dots {
            display: flex;
            justify-content: center;
            gap: 8px;
            margin-top: 10px;
        }
        
        .tutorial-dot {
            width: 10px;
            height: 10px;
            border-radius: 50%;
            background: rgba(255, 255, 255, 0.3);
            transition: all 0.3s ease;
        }
        
        .tutorial-dot.active {
            background: var(--page-mint);
            width: 30px;
            border-radius: 5px;
        }
        
        .exchange-input {
            width: 100%;
            padding: 15px;
            border-radius: 10px;
            border: 2px solid rgba(77, 225, 193, 0.3);
            background: rgba(255, 255, 255, 0.05);
            color: #fff;
            font-size: 1.2rem;
            margin: 20px 0;
            text-align: center;
        }
        
        .upgrade-modal .modal-content {
            border-color: rgba(251, 146, 60, 0.5);
        }
        
        @media (max-width: 768px) {
            .game-canvas-container {
                height: 500px;
                max-width: 100%;
                padding: 15px 0;
                margin: 0 10px;
            }
            
            .page-header h1 {
                font-size: 1.8rem;
            }
            
            .modal-content {
                padding: 25px;
                max-width: 95%;
            }
            
            .tutorial-navigation {
                flex-direction: column;
            }
            
            .tutorial-nav-btn {
                width: 100%;
                justify-content: center;
            }
            
            .bottom-controls {
                flex-wrap: wrap;
                justify-content: center;
            }
            
            .bet-controls {
                order: 1;
                width: 100%;
                justify-content: center;
            }
            
            .play-button {
                order: 2;
                width: 100%;
            }
            
            .info-btn {
                order: 3;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <a href="play-earn.php" class="back-link">← Back to Games</a>
        
        <div class="page-header">
            <h1>Plinko 3D</h1>
            <p>Drop the ball and win big rewards!</p>
        </div>
        
        <div class="game-layout">
            <div class="game-canvas-container">
                <div class="particles" id="particles"></div>
                
                <div class="top-balance-bar">
                    <div class="balance-chip" onclick="openBalanceModal('game')">
                        <span class="balance-chip-icon"></span>
                        <span class="balance-chip-value" id="gameBalance">₦<?php echo number_format($game_earnings, 2); ?></span>
                    </div>
                    <button class="balance-chip" id="volumeBtn" onclick="toggleMute()" style="cursor: pointer; border: none; background: rgba(10, 22, 66, 0.8);">
                        <span id="volumeIcon">🔊</span>
                    </button>
                    <div class="balance-chip deposit-chip" onclick="window.location.href='membership.php'">
                        Deposit
                    </div>
                </div>
                
                <div class="canvas-wrapper">
                    <canvas id="plinko3DCanvas"></canvas>
                </div>
                
                <div class="bottom-controls">
                    <div class="bet-controls">
                        <span class="bet-label">Bet:</span>
                        <button class="bet-btn" onclick="decreaseBet()">↓</button>
                        <button class="bet-btn" onclick="decreaseBetSmall()">−</button>
                        <div class="bet-display" id="betDisplay">1</div>
                        <button class="bet-btn" onclick="increaseBetSmall()">+</button>
                        <button class="bet-btn" onclick="increaseBet()">↑</button>
                    </div>
                    <button class="play-button" id="playBtn" onclick="playGame()">PLAY</button>
                    <button class="info-btn" onclick="showTutorial()">ⓘ</button>
                </div>
            </div>
        </div>
    </div>
    
    <div class="modal-overlay" id="tutorialModal">
        <div class="modal-content">
            <button class="modal-close" onclick="closeTutorial()">✕</button>
            <div class="modal-icon" id="tutorialIcon">🎓</div>
            <h2 class="modal-title">How to Play Plinko</h2>
            
            <div class="tutorial-steps">
                <div class="tutorial-step active" data-step="1">
                    <h4>Step 1: Set Your Bet</h4>
                    <p>Use the + and - buttons to adjust your bet amount. Minimum bet is ₦1,000. Your bet will be deducted from your Play Balance (referral earnings).</p>
                </div>
                <div class="tutorial-step" data-step="2">
                    <h4>Step 2: Drop the Ball</h4>
                    <p>Click the orange "PLAY" button to drop the ball. Watch it bounce through the 3D pegs as it falls down the board in a realistic physics simulation!</p>
                </div>
                <div class="tutorial-step" data-step="3">
                    <h4>Step 3: Win Rewards</h4>
                    <p>The ball lands in a slot with a multiplier (0.25x to 5.0x). Your winnings are calculated based on your bet × multiplier and added to Game Earnings! 70% win rate, 30% loss rate.</p>
                </div>
                <div class="tutorial-step" data-step="4">
                    <h4>Step 4: Exchange Earnings</h4>
                    <p>Click on your Game Earnings balance (top left) to exchange it to Task Balance for withdrawals. Task Balance can be withdrawn to your bank account!</p>
                </div>
            </div>
            
            <div class="tutorial-progress">
                <span id="tutorialStepText">Step 1 of 4</span>
                <div class="tutorial-dots">
                    <div class="tutorial-dot active"></div>
                    <div class="tutorial-dot"></div>
                    <div class="tutorial-dot"></div>
                    <div class="tutorial-dot"></div>
                </div>
            </div>
            
            <div class="tutorial-navigation">
                <button class="tutorial-nav-btn" id="tutorialPrevBtn" onclick="previousTutorialStep()" disabled>
                    ← Back
                </button>
                <button class="tutorial-nav-btn" id="tutorialNextBtn" onclick="nextTutorialStep()">
                    Next →
                </button>
            </div>
            
            <p style="margin: 20px 0; color: rgba(255, 255, 255, 0.7);">
                Need more help? <a href="https://www.youtube.com/watch?v=plinko-tutorial" target="_blank" style="color: var(--page-mint);">Watch Tutorial Video</a>
            </p>
        </div>
    </div>
    
    <div class="modal-overlay" id="exchangeModal">
        <div class="modal-content">
            <button class="modal-close" onclick="closeExchangeModal()">✕</button>
            <div class="modal-icon">💱</div>
            <h2 class="modal-title">Exchange Game Earnings</h2>
            <p class="modal-message">Convert your Game Earnings to Task Balance for withdrawals.</p>
            <div style="background: rgba(77, 225, 193, 0.1); padding: 15px; border-radius: 10px; margin: 20px 0;">
                <p style="margin-bottom: 10px;">Available Game Earnings:</p>
                <p style="font-size: 2rem; font-weight: 700; color: var(--page-mint);" id="availableGameEarnings">₦0.00</p>
            </div>
            <input type="number" class="exchange-input" id="exchangeAmount" placeholder="Enter amount to exchange" min="100" step="100">
            <button class="modal-btn" onclick="exchangeBalance()">Exchange Now</button>
        </div>
    </div>
    
    <div class="modal-overlay upgrade-modal" id="upgradeModal">
        <div class="modal-content">
            <button class="modal-close" onclick="closeUpgradeModal()">✕</button>
            <div class="modal-icon">🔒</div>
            <h2 class="modal-title">Premium Membership Required</h2>
            <p class="modal-message">
                This game is exclusively for Premium Members. Upgrade now to unlock all games and start winning real rewards!
            </p>
            <div style="background: rgba(251, 146, 60, 0.1); padding: 20px; border-radius: 10px; margin: 20px 0; text-align: left;">
                <h4 style="color: var(--page-orange); margin-bottom: 15px;">Premium Benefits:</h4>
                <p style="margin-bottom: 8px;">✓ Access to all games</p>
                <p style="margin-bottom: 8px;">✓ Higher winning rates</p>
                <p style="margin-bottom: 8px;">✓ Exclusive tournaments</p>
                <p>✓ Priority support</p>
            </div>
            <button class="modal-btn" onclick="window.location.href='membership.php'" style="background: linear-gradient(135deg, #fb923c, #f97316);">
                Upgrade to Premium
            </button>
        </div>
    </div>
    
    <div class="modal-overlay" id="resultModal">
        <div class="modal-content">
            <button class="modal-close" onclick="closeResultModal()">✕</button>
            <div class="modal-icon" id="resultIcon">🎉</div>
            <h2 class="modal-title" id="resultTitle">You Won!</h2>
            <p style="font-size: 3rem; font-weight: 900; color: var(--page-mint); margin: 20px 0;" id="resultAmount">₦0.00</p>
            <p style="font-size: 1.2rem; color: rgba(255,255,255,0.7); margin: 10px 0;" id="resultMultiplier">Multiplier: 1.0x</p>
            <p class="modal-message" id="resultMessage">Your winnings have been added to Game Earnings!</p>
            <button class="modal-btn" onclick="closeResultModal()">Claim Reward</button>
            <button class="modal-btn" onclick="playAgain()" style="background: rgba(255, 255, 255, 0.1);">Play Again</button>
        </div>
    </div>
    
    <div class="modal-overlay" id="notificationModal">
        <div class="modal-content">
            <button class="modal-close" onclick="closeNotificationModal()">✕</button>
            <div class="modal-icon" id="notificationIcon">ℹ️</div>
            <h2 class="modal-title" id="notificationTitle">Notification</h2>
            <p class="modal-message" id="notificationMessage"></p>
            <button class="modal-btn" onclick="closeNotificationModal()">OK</button>
        </div>
    </div>
    
    <script>
        const PAYSTACK_PUBLIC_KEY = 'pk_test_2889acc30e717c743676ced0e02e0e1ad4d274fe';
        const USER_EMAIL = '<?php echo $user_email; ?>';
        const IS_PREMIUM = <?php echo $is_premium ? 'true' : 'false'; ?>;
        
        let matterEngine, matterWorld, matterBall, matterPegs = [], matterSlots = [];
        let scene, camera, renderer, ball, pegs = [], slots = [], slotLabels = [], walls = [];
        let isPlaying = false;
        let hasSeenTutorial = localStorage.getItem('plinko_tutorial_seen') === 'true';
        let currentTutorialStep = 1;
        const totalTutorialSteps = 4;
        let betAmount = 1;
        
        const isMobile = window.innerWidth <= 700;
        const pegSizeMultiplier = isMobile ? 1.5 : 1;
        const slotSizeMultiplier = isMobile ? 1.4 : 1;

        const sounds = {
            background: new Audio('assets/sounds/background-music.mp3'),
            bounce: new Audio('assets/sounds/bounce.mp3'),
            win: new Audio('assets/sounds/win.mp3'),
            bigWin: new Audio('assets/sounds/big-win.mp3'),
            lose: new Audio('assets/sounds/lose.mp3')
        };
        
        sounds.background.loop = true;
        sounds.background.volume = 0.3;
        sounds.bounce.volume = 0.4;
        sounds.win.volume = 0.6;
        sounds.bigWin.volume = 0.7;
        sounds.lose.volume = 0.5;
        
        let isMuted = localStorage.getItem('plinko_sound_muted') === 'true';
        
        if (isMuted) {
            Object.values(sounds).forEach(sound => sound.muted = true);
            document.getElementById('volumeIcon').textContent = '🔇';
        }
        
        function toggleMute() {
            isMuted = !isMuted;
            localStorage.setItem('plinko_sound_muted', isMuted);
            Object.values(sounds).forEach(sound => sound.muted = isMuted);
            document.getElementById('volumeIcon').textContent = isMuted ? '🔇' : '🔊';
            if (!isMuted) {
                playBackgroundMusic();
            } else {
                stopBackgroundMusic();
            }
        }
        
        let isBackgroundMusicPlaying = false;
        
        function playBackgroundMusic() {
            if (!isBackgroundMusicPlaying && !isMuted) {
                sounds.background.play().catch(err => {
                    console.log('Background music autoplay prevented.');
                });
                isBackgroundMusicPlaying = true;
            }
        }
        
        function stopBackgroundMusic() {
            if (isBackgroundMusicPlaying) {
                sounds.background.pause();
                sounds.background.currentTime = 0;
                isBackgroundMusicPlaying = false;
            }
        }
        
        function playBounceSound() {
            const bounceClone = sounds.bounce.cloneNode();
            bounceClone.volume = sounds.bounce.volume;
            bounceClone.play().catch(err => console.log('Bounce sound error:', err));
        }
        
        function playResultSound(multiplier) {
            if (multiplier >= 3) {
                sounds.bigWin.play().catch(err => console.log('Big win sound error:', err));
            } else if (multiplier > 1) {
                sounds.win.play().catch(err => console.log('Win sound error:', err));
            } else {
                sounds.lose.play().catch(err => console.log('Lose sound error:', err));
            }
        }
        
        document.addEventListener('click', function initAudio() {
            playBackgroundMusic();
            document.removeEventListener('click', initAudio);
        }, { once: true });
        
        function createParticles() {
            const particlesContainer = document.getElementById('particles');
            for (let i = 0; i < 20; i++) {
                const particle = document.createElement('div');
                particle.className = 'particle';
                particle.style.left = Math.random() * 100 + '%';
                particle.style.animationDelay = Math.random() * 10 + 's';
                particle.style.animationDuration = (Math.random() * 10 + 10) + 's';
                particlesContainer.appendChild(particle);
            }
        }
        
        createParticles();
        
        if (!hasSeenTutorial) {
            document.getElementById('tutorialModal').classList.add('active');
        }
        
        function showTutorial() {
            currentTutorialStep = 1;
            updateTutorialDisplay();
            document.getElementById('tutorialModal').classList.add('active');
        }
        
        function nextTutorialStep() {
            if (currentTutorialStep < totalTutorialSteps) {
                currentTutorialStep++;
                updateTutorialDisplay();
            } else {
                closeTutorial();
            }
        }
        
        function previousTutorialStep() {
            if (currentTutorialStep > 1) {
                currentTutorialStep--;
                updateTutorialDisplay();
            }
        }
        
        function updateTutorialDisplay() {
            document.querySelectorAll('.tutorial-step').forEach((step, index) => {
                step.classList.toggle('active', index + 1 === currentTutorialStep);
            });
            
            document.querySelectorAll('.tutorial-dot').forEach((dot, index) => {
                dot.classList.toggle('active', index + 1 === currentTutorialStep);
            });
            
            document.getElementById('tutorialStepText').textContent = `Step ${currentTutorialStep} of ${totalTutorialSteps}`;
            
            document.getElementById('tutorialPrevBtn').disabled = currentTutorialStep === 1;
            document.getElementById('tutorialNextBtn').textContent = currentTutorialStep === totalTutorialSteps ? "Let's Play! 🎮" : "Next →";
            
            const icons = ['🎓', '🎯', '🎰', '💱'];
            document.getElementById('tutorialIcon').textContent = icons[currentTutorialStep - 1];
        }
        
        function closeTutorial() {
            localStorage.setItem('plinko_tutorial_seen', 'true');
            document.getElementById('tutorialModal').classList.remove('active');
        }
        
        function increaseBet() {
            betAmount = Math.min(betAmount + 5, 100);
            updateBetDisplay();
        }
        
        function decreaseBet() {
            betAmount = Math.max(betAmount - 5, 1);
            updateBetDisplay();
        }
        
        function increaseBetSmall() {
            betAmount = Math.min(betAmount + 1, 100);
            updateBetDisplay();
        }
        
        function decreaseBetSmall() {
            betAmount = Math.max(betAmount - 1, 1);
            updateBetDisplay();
        }
        
        function updateBetDisplay() {
            document.getElementById('betDisplay').textContent = '₦' + (betAmount * 1000).toLocaleString();
        }
        
        function init3DScene() {
            const canvas = document.getElementById('plinko3DCanvas');
            const container = canvas.parentElement;
            
            matterEngine = Matter.Engine.create();
            matterWorld = matterEngine.world;
            matterWorld.gravity.y = 1;
            
            scene = new THREE.Scene();
            scene.background = new THREE.Color(0x1a2a5e);
            
            camera = new THREE.PerspectiveCamera(75, container.clientWidth / container.clientHeight, 0.1, 1000);
            camera.position.set(0, 2, 12);
            camera.lookAt(0, 0, 0);
            
            renderer = new THREE.WebGLRenderer({ canvas, antialias: true });
            renderer.setSize(container.clientWidth, container.clientHeight);
            renderer.shadowMap.enabled = true;
            
            const ambientLight = new THREE.AmbientLight(0xffffff, 0.6);
            scene.add(ambientLight);
            
            const pointLight = new THREE.PointLight(0x4de1c1, 1.2, 100);
            pointLight.position.set(0, 10, 10);
            pointLight.castShadow = true;
            scene.add(pointLight);
            
            const pegGeometry = new THREE.SphereGeometry(0.2 * pegSizeMultiplier, 16, 16);
            const pegMaterial = new THREE.MeshStandardMaterial({ 
                color: 0xe0e7ff, 
                metalness: 0.4, 
                roughness: 0.6,
                emissive: 0x6b7fff,
                emissiveIntensity: 0.2
            });
            
            const rows = 12;
            const horizontalSpacing = 1.4;
            const verticalSpacing = 1.1;
            const startY = 6;
            const pegRadius = 0.2 * pegSizeMultiplier;
            
            for (let row = 0; row < rows; row++) {
                const pegsInRow = row + 2;
                const rowWidth = (pegsInRow - 1) * horizontalSpacing;
                
                for (let col = 0; col < pegsInRow; col++) {
                    const x = -rowWidth / 2 + col * horizontalSpacing;
                    const y = startY - row * verticalSpacing;
                    
                    const peg = new THREE.Mesh(pegGeometry, pegMaterial.clone());
                    peg.position.x = x;
                    peg.position.y = y;
                    peg.position.z = 0;
                    peg.castShadow = true;
                    peg.receiveShadow = true;
                    scene.add(peg);
                    pegs.push(peg);
                    
                    const matterPeg = Matter.Bodies.circle(
                        x * 50,
                        -y * 50,
                        pegRadius * 50,
                        { 
                            isStatic: true,
                            restitution: 0.9,
                            friction: 0.1,
                            frictionStatic: 0.3,
                            label: 'peg'
                        }
                    );
                    Matter.World.add(matterWorld, matterPeg);
                    matterPegs.push({ visual: peg, physics: matterPeg });
                }
            }
            
            const wallOptions = { isStatic: true, restitution: 0.9, friction: 0.1, frictionStatic: 0.3 };
            const wallHeight = 15 * 50;
            const wallWidth = 0.3 * 50;
            const wallX = 10 * 50;

            const leftWall = Matter.Bodies.rectangle(-wallX, 0, wallWidth, wallHeight, wallOptions);
            const rightWall = Matter.Bodies.rectangle(wallX, 0, wallWidth, wallHeight, wallOptions);
            Matter.World.add(matterWorld, [leftWall, rightWall]);
            
            const wallMaterial = new THREE.MeshBasicMaterial({ visible: false });
            const wallGeometry = new THREE.BoxGeometry(0.3, 15, 1);
            
            const leftWallMesh = new THREE.Mesh(wallGeometry, wallMaterial);
            leftWallMesh.position.set(-10, 0, 0);
            scene.add(leftWallMesh);
            walls.push(leftWallMesh);
            
            const rightWallMesh = new THREE.Mesh(wallGeometry, wallMaterial);
            rightWallMesh.position.set(10, 0, 0);
            scene.add(rightWallMesh);
            walls.push(rightWallMesh);
            
            const holderGeometry = new THREE.CylinderGeometry(0.35, 0.3, 0.4, 32, 1, true);
            const holderMaterial = new THREE.MeshStandardMaterial({ 
                color: 0xfbbf24,
                metalness: 0.6,
                roughness: 0.4,
                emissive: 0xfbbf24,
                emissiveIntensity: 0.3,
                side: THREE.DoubleSide
            });
            const holder = new THREE.Mesh(holderGeometry, holderMaterial);
            holder.position.set(0, startY + 1.2, 0);
            holder.rotation.x = Math.PI;
            scene.add(holder);
            
            const slotGeometry = new THREE.BoxGeometry(0.85 * slotSizeMultiplier, 0.5, 0.8 * slotSizeMultiplier);
            const multipliers = [4, 3, 2.5, 1.5, 0.5, 0.25, 0.5, 1.5, 2.5, 3, 4];
            const colors = [0xfbbf24, 0xfbbf24, 0xfbbf24, 0xfbbf24, 0xef4444, 0xef4444, 0xef4444, 0xfbbf24, 0xfbbf24, 0xfbbf24, 0xfbbf24];
            
            const slotY = startY - rows * verticalSpacing - 1.2;
            const slotSpacing = 1.05 * 1.4;
            const totalSlotWidth = (multipliers.length - 1) * slotSpacing;
            
            for (let i = 0; i < multipliers.length; i++) {
                const x = -totalSlotWidth / 2 + i * slotSpacing;
                
                const slotMaterial = new THREE.MeshStandardMaterial({ 
                    color: 0x0a1642,
                    metalness: 0.3,
                    roughness: 0.7
                });
                const slot = new THREE.Mesh(slotGeometry, slotMaterial);
                slot.position.x = x;
                slot.position.y = slotY;
                slot.position.z = 0;
                slot.userData.multiplier = multipliers[i];
                slot.receiveShadow = true;
                scene.add(slot);
                slots.push(slot);
                
                const matterSlot = Matter.Bodies.rectangle(
                    x * 50,
                    -slotY * 50,
                    (0.85 * slotSizeMultiplier) * 50,
                    (0.5) * 50,
                    { 
                        isStatic: true,
                        isSensor: true,
                        label: 'slot_' + i
                    }
                );
                matterSlot.multiplier = multipliers[i];
                Matter.World.add(matterWorld, matterSlot);
                matterSlots.push(matterSlot);
                
                const borderGeometry = new THREE.BoxGeometry(0.92 * slotSizeMultiplier, 0.55, 0.85 * slotSizeMultiplier);
                const borderMaterial = new THREE.MeshStandardMaterial({ 
                    color: colors[i],
                    metalness: 0.6,
                    roughness: 0.4,
                    emissive: colors[i],
                    emissiveIntensity: 0.4
                });
                const border = new THREE.Mesh(borderGeometry, borderMaterial);
                border.position.copy(slot.position);
                border.position.z = -0.05;
                scene.add(border);
                
                const canvas2d = document.createElement('canvas');
                const context = canvas2d.getContext('2d');
                canvas2d.width = 256;
                canvas2d.height = 128;
                context.fillStyle = '#' + colors[i].toString(16).padStart(6, '0');
                context.font = 'bold 90px Arial';
                context.textAlign = 'center';
                context.textBaseline = 'middle';
                context.fillText(multipliers[i] + 'x', 128, 64);
                
                const texture = new THREE.CanvasTexture(canvas2d);
                const spriteMaterial = new THREE.SpriteMaterial({ map: texture });
                const sprite = new THREE.Sprite(spriteMaterial);
                sprite.position.set(slot.position.x, slot.position.y, 0.6);
                sprite.scale.set(1.0 * slotSizeMultiplier, 0.5, 1);
                scene.add(sprite);
                slotLabels.push(sprite);
            }
            
            Matter.Events.on(matterEngine, 'collisionStart', function(event) {
                const pairs = event.pairs;
                
                pairs.forEach(pair => {
                    let bodyA = pair.bodyA;
                    let bodyB = pair.bodyB;

                    if (bodyB === matterBall) {
                        [bodyA, bodyB] = [bodyB, bodyA];
                    }

                    if (bodyA === matterBall && (bodyB.label === 'peg')) {
                        const pegData = matterPegs.find(p => p.physics === bodyB);
                        if (pegData) {
                            playBounceSound();
                            
                            pegData.visual.material.emissiveIntensity = 0.8;
                            pegData.visual.material.emissive = new THREE.Color(0x4de1c1);
                            setTimeout(() => {
                                pegData.visual.material.emissiveIntensity = 0.2;
                                pegData.visual.material.emissive = new THREE.Color(0x6b7fff);
                            }, 200);
                        }
                    }
                    
                    if (bodyA === matterBall && bodyB.label && bodyB.label.startsWith('slot_')) {
                        if (isPlaying) {
                            const multiplier = bodyB.multiplier;
                            const slotIndex = parseInt(bodyB.label.split('_')[1]);
                            
                            slots[slotIndex].material.emissive = new THREE.Color(0x4de1c1);
                            slots[slotIndex].material.emissiveIntensity = 0.8;
                            setTimeout(() => {
                                slots[slotIndex].material.emissiveIntensity = 0;
                            }, 2000);
                            
                            handleBallLanded(multiplier);
                            
                            if (matterBall) {
                                Matter.World.remove(matterWorld, matterBall);
                                matterBall = null;
                            }
                            if (ball) {
                                scene.remove(ball);
                                ball = null;
                            }
                            isPlaying = false;
                        }
                    }
                });
            });
            
            animate();
            window.addEventListener('resize', onWindowResize);
        }

        function onWindowResize() {
            const container = document.getElementById('plinko3DCanvas').parentElement;
            camera.aspect = container.clientWidth / container.clientHeight;
            camera.updateProjectionMatrix();
            renderer.setSize(container.clientWidth, container.clientHeight);
        }

        function animate() {
            requestAnimationFrame(animate);
            
            Matter.Engine.update(matterEngine, 1000 / 60);
            
            pegs.forEach((peg, index) => {
                peg.rotation.y += 0.01;
            });
            
            if (ball && matterBall && isPlaying) {
                ball.position.x = matterBall.position.x / 50;
                ball.position.y = -matterBall.position.y / 50;
                ball.rotation.z = matterBall.angle;
            }
            
            renderer.render(scene, camera);
        }
        
        function dropBall() {
            const ballRadius = 0.28;
            const ballGeometry = new THREE.SphereGeometry(ballRadius, 32, 32);
            const ballMaterial = new THREE.MeshStandardMaterial({ 
                color: 0xfbbf24,
                metalness: 0.8,
                roughness: 0.2,
                emissive: 0xfbbf24,
                emissiveIntensity: 0.6
            });
            ball = new THREE.Mesh(ballGeometry, ballMaterial);
            
            ball.position.set(0, 7.5, 0);
            ball.castShadow = true;
            ball.receiveShadow = true;
            scene.add(ball);
            
            matterBall = Matter.Bodies.circle(
                0,
                -7.5 * 50,
                ballRadius * 50,
                {
                    restitution: 0.8,
                    friction: 0.05,
                    density: 0.001,
                    frictionAir: 0.002,
                    label: 'ball'
                }
            );
            
            Matter.Body.setVelocity(matterBall, {
                x: (Math.random() - 0.5) * 0.6,
                y: 0
            });
            
            Matter.World.add(matterWorld, matterBall);
        }

        function playGame() {
            if (isPlaying) return;
            
            if (!IS_PREMIUM) {
                document.getElementById('upgradeModal').classList.add('active');
                return;
            }
            
            const actualBetAmount = betAmount * 1000;
            
            const balanceText = document.getElementById('gameBalance').textContent.replace('₦', '').replace(/,/g, '');
            const currentBalance = Number(balanceText);
            
            if (currentBalance < actualBetAmount) {
                showInsufficientBalanceModal(actualBetAmount, currentBalance);
                return;
            }
            
            stopBackgroundMusic();
            
            isPlaying = true;
            document.getElementById('playBtn').disabled = true;
            
            dropBall();
        }
        
        function showInsufficientBalanceModal(requiredAmount, currentBalance) {
            const modal = document.getElementById('notificationModal');
            const modalIcon = document.getElementById('notificationIcon');
            const modalTitle = document.getElementById('notificationTitle');
            const modalMessage = document.getElementById('notificationMessage');
            
            modalIcon.textContent = '⚠️';
            modalTitle.textContent = 'Insufficient Balance';
            modalMessage.innerHTML = `
                You need <strong>₦${requiredAmount.toLocaleString('en-NG')}</strong> to play, but you only have <strong>₦${currentBalance.toLocaleString('en-NG', {minimumFractionDigits: 2, maximumFractionDigits: 2})}</strong> in your Play Balance.<br><br>
                <a href="membership.php" style="color: var(--page-mint); text-decoration: underline; font-weight: 600;">Click here to deposit</a> and continue playing.
            `;
            
            modal.style.display = 'flex';
            setTimeout(() => modal.classList.add('active'), 10);
        }
        
        async function handleBallLanded(multiplier) {
            const actualBetAmount = betAmount * 1000;
            
            try {
                const response = await fetch('api/plinko-play-v2.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ bet_amount: actualBetAmount, multiplier: multiplier })
                });
                
                const data = await response.json();
                
                if (data.success) {
                    document.getElementById('gameBalance').textContent = '₦' + parseFloat(data.game_earnings).toLocaleString('en-NG', {minimumFractionDigits: 2, maximumFractionDigits: 2});
                    showResult(data.win_amount, data.multiplier);
                } else {
                    if (data.upgrade_required) {
                        document.getElementById('upgradeModal').classList.add('active');
                    } else if (data.insufficient_balance) {
                        showInsufficientBalanceModal(actualBetAmount, parseFloat(document.getElementById('gameBalance').textContent.replace('₦', '').replace(/,/g, '')));
                    } else {
                        showNotification('Error', data.message || 'An error occurred', '⚠️');
                    }
                }
            } catch (error) {
                console.error('Error:', error);
                showNotification('Connection Error', 'Connection error. Please try again.', '⚠️');
            }
            
            document.getElementById('playBtn').disabled = false;
        }
        
        function showResult(amount, multiplier) {
            const resultModal = document.getElementById('resultModal');
            const resultIcon = document.getElementById('resultIcon');
            const resultTitle = document.getElementById('resultTitle');
            const resultAmount = document.getElementById('resultAmount');
            const resultMultiplier = document.getElementById('resultMultiplier');
            const resultMessage = document.getElementById('resultMessage');
            
            playResultSound(multiplier);
            
            if (multiplier >= 3) {
                resultIcon.textContent = '🎰';
                resultTitle.textContent = 'JACKPOT!';
            } else if (multiplier >= 1.5) {
                resultIcon.textContent = '🎉';
                resultTitle.textContent = 'Big Win!';
            } else if (multiplier > 1) {
                resultIcon.textContent = '✨';
                resultTitle.textContent = 'You Won!';
            } else {
                resultIcon.textContent = '😔';
                resultTitle.textContent = 'Try Again!';
            }
            
            resultAmount.textContent = '₦' + parseFloat(amount).toLocaleString('en-NG', {minimumFractionDigits: 2, maximumFractionDigits: 2});
            resultMultiplier.textContent = 'Multiplier: ' + multiplier + 'x';
            resultMessage.textContent = multiplier > 0 ? 'Your winnings have been added to Game Earnings!' : 'Better luck next time!';
            resultModal.classList.add('active');
            
            setTimeout(() => {
                playBackgroundMusic();
            }, 3000);
        }
        
        function closeResultModal() {
            document.getElementById('resultModal').classList.remove('active');
        }
        
        function playAgain() {
            closeResultModal();
        }
        
        function openBalanceModal(type) {
            if (type === 'game') {
                const gameBalance = document.getElementById('gameBalance').textContent.replace('₦', '').replace(/,/g, '');
                document.getElementById('availableGameEarnings').textContent = '₦' + parseFloat(gameBalance).toLocaleString('en-NG', {minimumFractionDigits: 2, maximumFractionDigits: 2});
                document.getElementById('exchangeModal').classList.add('active');
            }
        }
        
        function closeExchangeModal() {
            document.getElementById('exchangeModal').classList.remove('active');
        }
        
        async function exchangeBalance() {
            const amount = parseFloat(document.getElementById('exchangeAmount').value);
            
            if (isNaN(amount) || amount <= 0) {
                showNotification('Invalid Amount', 'Please enter a valid amount', '⚠️');
                return;
            }
            
            try {
                const response = await fetch('api/exchange-balance.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ amount })
                });
                
                const data = await response.json();
                
                if (data.success) {
                    document.getElementById('gameBalance').textContent = '₦' + parseFloat(data.game_earnings).toLocaleString('en-NG', {minimumFractionDigits: 2, maximumFractionDigits: 2});
                    
                    showNotification('Success', 'Balance exchanged successfully to Task Balance!', '✅');
                    closeExchangeModal();
                    
                    setTimeout(() => location.reload(), 1000);
                } else {
                    showNotification('Exchange Failed', data.message || 'Exchange failed', '⚠️');
                }
            } catch (error) {
                console.error('Error:', error);
                showNotification('Connection Error', 'Connection error. Please try again.', '⚠️');
            }
        }

        function showNotification(title, message, icon = 'ℹ️') {
            const modal = document.getElementById('notificationModal');
            document.getElementById('notificationIcon').textContent = icon;
            document.getElementById('notificationTitle').textContent = title;
            document.getElementById('notificationMessage').innerHTML = message;
            modal.style.display = 'flex';
            setTimeout(() => modal.classList.add('active'), 10);
        }
        
        function closeNotificationModal() {
            const modal = document.getElementById('notificationModal');
            modal.classList.remove('active');
            setTimeout(() => modal.style.display = 'none', 300);
        }
        
        function closeUpgradeModal() {
            document.getElementById('upgradeModal').classList.remove('active');
        }
        
        init3DScene();
        updateBetDisplay();

    </script>
</body>
</html>
