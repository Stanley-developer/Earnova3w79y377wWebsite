<?php
ob_clean(); 

require_once 'config/database.php';
require_once 'includes/session.php';
require_once 'includes/connect.php';

// Require authentication
requireLogin();
checkSessionTimeout();

ini_set('display_errors', 0);
error_reporting(E_ALL);


// Get current user data
$user = getCurrentUser();
$userId = $user['id'];
$username = $user['username'] ?? 'User';
$membershipType = $user['membership_type'] ?? 'free';

// Check if user is premium/senior member
$isPremium = ($membershipType === 'premium' || $membershipType === 'senior');

// Check if user agreed to terms
$watch_agreed = isset($_SESSION['watch_agreed_' . $userId]) ? $_SESSION['watch_agreed_' . $userId] : false;

// Get user balances
$pdo = getDBConnection();
$stmt = $pdo->prepare("SELECT * FROM balances WHERE user_id = ?");
$stmt->execute([$userId]);
$balances = $stmt->fetch();

if (!$balances) {
    $stmt = $pdo->prepare("INSERT INTO balances (user_id, task_earnings) VALUES (?, 0.00)");
    $stmt->execute([$userId]);
    $balances = ['total_balance' => 0.00, 'task_earnings' => 0.00, 'referral_earnings' => 0.00];
}

// Handle AJAX requests
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['ajax'])) {
    header('Content-Type: application/json');

    $action = $_POST['action'] ?? '';

    if ($action === 'agree_terms') {
        $_SESSION['watch_agreed_' . $userId] = true;
        echo json_encode(['success' => true, 'message' => 'Watch Instructions agreed']);
        exit;
    }

    if ($action === 'start_video') {
        $videoId = intval($_POST['video_id'] ?? 0);

        // Get video details
        $stmt = $pdo->prepare("SELECT * FROM available_videos WHERE id = ? AND is_active = 1");
        $stmt->execute([$videoId]);
        $video = $stmt->fetch();

        if (!$video) {
            echo json_encode(['success' => false, 'message' => 'Video not found']);
            exit;
        }

        // Check if user already watched this video today
        $today = date('Y-m-d');
        $stmt = $pdo->prepare("SELECT * FROM video_earnings WHERE user_id = ? AND video_id = ? AND DATE(watched_at) = ?");
        $stmt->execute([$userId, $video['video_id'], $today]);
        $alreadyWatched = $stmt->fetch();

        if ($alreadyWatched) {
            echo json_encode(['success' => false, 'message' => 'You already earned from this video today']);
            exit;
        }

        echo json_encode([
            'success' => true,
            'video_url' => $video['video_url'],
            'video_file_path' => $video['video_file_path'],
            'start_time' => time()
        ]);
        exit;

    } elseif ($action === 'claim_reward') {
        $videoId = intval($_POST['video_id'] ?? 0);
        $videoTitle = $_POST['video_title'] ?? '';
        $profileLink = trim($_POST['profile_link'] ?? '');

        // Get video details
        $stmt = $pdo->prepare("SELECT * FROM available_videos WHERE id = ? AND is_active = 1");
        $stmt->execute([$videoId]);
        $video = $stmt->fetch();

        if (!$video) {
            echo json_encode(['success' => false, 'message' => 'Video not found']);
            exit;
        }

        // Check if free user
        if (!$isPremium) {
            echo json_encode([
                'success' => false, 
                'message' => 'This feature is for premium members only. Upgrade to premium to earn from videos!',
                'is_free_user' => true
            ]);
            exit;
        }

        // Validate profile link
        if (empty($profileLink) || !filter_var($profileLink, FILTER_VALIDATE_URL)) {
            echo json_encode(['success' => false, 'message' => 'Provide a valid profile link']);
            exit;
        }

        // Check if it's a base URL
        $baseSocialUrls = [
            'tiktok.com',
            'instagram.com',
            'twitter.com',
            'x.com',
            'facebook.com',
            'youtube.com',
            'linkedin.com'
        ];

        $parsedUrl = parse_url($profileLink);
        $host = $parsedUrl['host'] ?? '';
        $path = $parsedUrl['path'] ?? '/';

        foreach ($baseSocialUrls as $baseUrl) {
            if (stripos($host, $baseUrl) !== false && ($path === '/' || $path === '')) {
                echo json_encode(['success' => false, 'message' => 'Please provide your full profile link, not just the base URL']);
                exit;
            }
        }

        // Check if profile link already used
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM video_earnings WHERE video_id = ? AND profile_link = ?");
        $stmt->execute([$video['video_id'], $profileLink]);
        $duplicate_count = $stmt->fetchColumn();

        if ($duplicate_count > 0) {
            echo json_encode(['success' => false, 'message' => 'This profile link has already been used for this video']);
            exit;
        }

        // Validate platform match
        $platform = strtolower($video['platform'] ?? 'youtube');
        if (stripos($profileLink, $platform) === false) {
            echo json_encode(['success' => false, 'message' => 'Profile link must match video platform: ' . ucfirst($platform)]);
            exit;
        }

        // Check if user already watched this video today
        $today = date('Y-m-d');
        $stmt = $pdo->prepare("SELECT * FROM video_earnings WHERE user_id = ? AND video_id = ? AND DATE(watched_at) = ?");
        $stmt->execute([$userId, $video['video_id'], $today]);
        $alreadyWatched = $stmt->fetch();

        if ($alreadyWatched) {
            echo json_encode(['success' => false, 'message' => 'You already earned from this video today']);
            exit;
        }

        // Award earnings
        $earnAmount = $isPremium ? $video['premium_reward'] : $video['free_reward'];

        $pdo->beginTransaction();
        try {
            // Record video earning with profile link
            $stmt = $pdo->prepare("INSERT INTO video_earnings (user_id, video_id, video_title, amount_earned, profile_link) VALUES (?, ?, ?, ?, ?)");
            $stmt->execute([$userId, $video['video_id'], $videoTitle, $earnAmount, $profileLink]);

            $stmt = $pdo->prepare("UPDATE balances SET task_earnings = task_earnings + ?, total_balance = total_balance + ? WHERE user_id = ?");
            $stmt->execute([$earnAmount, $earnAmount, $userId]);

            // Create transaction record
            $description = "Watched video: " . $videoTitle;
            $stmt = $pdo->prepare("INSERT INTO transactions (user_id, transaction_type, amount, balance_type, description) VALUES (?, 'video_earning', ?, 'activity_earnings', ?)");
            $stmt->execute([$userId, $earnAmount, $description]);

            // Mark video as completed
            $stmt = $pdo->prepare("INSERT IGNORE INTO user_completed_videos (user_id, video_id) VALUES (?, ?)");
            $stmt->execute([$userId, $video['video_id']]);

            // Increment participants counter for the video (create column if missing)
            try {
                $stmt = $pdo->prepare("UPDATE available_videos SET participants_count = COALESCE(participants_count,0) + 1 WHERE id = ?");
                $stmt->execute([$videoId]);

                // After increment, check if we've reached the target and deactivate if so
                $stmt = $pdo->prepare("SELECT COALESCE(participants_count,0) AS participants_count, COALESCE(participants_target,0) AS participants_target FROM available_videos WHERE id = ?");
                $stmt->execute([$videoId]);
                $counts = $stmt->fetch();

                if ($counts) {
                    $current = intval($counts['participants_count']);
                    $target = intval($counts['participants_target']);
                    if ($target > 0 && $current >= $target) {
                        // Deactivate the video so it no longer appears in watch-earn
                        $stmt = $pdo->prepare("UPDATE available_videos SET is_active = 0 WHERE id = ?");
                        $stmt->execute([$videoId]);
                    }
                }
            } catch (Exception $e) {
                // If column doesn't exist, ignore here — migrations should add it.
                error_log('Participants count update skipped: ' . $e->getMessage());
            }

            $pdo->commit();

            echo json_encode([
                'success' => true,
                'reward' => floatval($earnAmount),
                'message' => 'Congratulations! You earned ₦' . number_format($earnAmount, 2) . ' from watching the video!'
            ]);
            exit;

        } catch (Exception $e) {
            $pdo->rollBack();
            error_log("Video reward error: " . $e->getMessage());
            echo json_encode(['success' => false, 'message' => 'Error processing your reward. Please try again.']);
            exit;
        }
    }

    echo json_encode(['success' => false, 'message' => 'Invalid action']);
    exit;
}

// Get completed video IDs
$stmt = $pdo->prepare("SELECT video_id FROM user_completed_videos WHERE user_id = ?");
$stmt->execute([$userId]);
$completedVideoIds = $stmt->fetchAll(PDO::FETCH_COLUMN);

// Get all active videos that still need participants (participants_target = 0 means unlimited)
$stmt = $pdo->prepare("SELECT * FROM available_videos WHERE is_active = 1 AND (COALESCE(participants_target,0) = 0 OR COALESCE(participants_count,0) < COALESCE(participants_target,0)) ORDER BY is_compulsory DESC, created_at DESC");
$stmt->execute();
$allVideos = $stmt->fetchAll();

// Filter out completed videos and separate by type for sorting (compulsory first)
$compulsory_videos = [];
$regular_videos = [];

foreach ($allVideos as $video) {
    if (!in_array($video['video_id'], $completedVideoIds)) {
        if ($video['is_compulsory'] == 1) {
            $compulsory_videos[] = $video;
        } else {
            $regular_videos[] = $video;
        }
    }
}

// Merge arrays with compulsory videos first
$videos = array_merge($compulsory_videos, $regular_videos);

// Get today's earnings
$today = date('Y-m-d');
$stmt = $pdo->prepare("SELECT COUNT(*) as video_count FROM video_earnings WHERE user_id = ? AND DATE(watched_at) = ?");
$stmt->execute([$userId, $today]);
$todayVideos = $stmt->fetch()['video_count'];

// Get total earnings
$stmt = $pdo->prepare("SELECT SUM(amount_earned) as total FROM video_earnings WHERE user_id = ?");
$stmt->execute([$userId]);
$totalVideoEarnings = $stmt->fetch()['total'] ?? 0;

// Helper function to detect platform from video URL
function detectVideoPlatform($url, $platform = null) {
    if (!empty($platform)) {
        return strtolower($platform);
    }

    $platforms = [
        'youtube' => 'YouTube',
        'tiktok' => 'TikTok',
        'instagram' => 'Instagram',
        'facebook' => 'Facebook',
        'twitter' => 'Twitter',
        'linkedin' => 'LinkedIn'
    ];

    $url_lower = strtolower($url);

    foreach ($platforms as $key => $name) {
        if (stripos($url_lower, $key) !== false || stripos($url_lower, $name) !== false) {
            return $key;
        }
    }
    return 'youtube'; // default
}

function getPlatformColor($platform) {
    $colors = [
        'youtube' => '#FF0000',
        'tiktok' => '#fff',
        'instagram' => '#E4405F',
        'facebook' => '#1877F2',
        'twitter' => '#1DA1F2',
        'linkedin' => '#0A66C2'
    ];

    return $colors[$platform] ?? '#FF0000';
}

function getPlatformColorWithAlpha($platform, $alpha = 0.6) {
    $colors = [
        'youtube' => "rgba(255, 0, 0, {$alpha})",
        'tiktok' => "rgba(255, 255, 255, {$alpha})",
        'instagram' => "rgba(228, 64, 95, {$alpha})",
        'facebook' => "rgba(24, 119, 242, {$alpha})",
        'twitter' => "rgba(29, 161, 242, {$alpha})",
        'linkedin' => "rgba(10, 102, 194, {$alpha})"
    ];

    return $colors[$platform] ?? "rgba(255, 0, 0, {$alpha})";
}


function getPlatformGlowColor($platform) {
    $glowColors = [
        'youtube' => 'rgba(255, 0, 0, 0.6)',
        'tiktok' => 'rgba(255, 255, 255, 0.6)',
        'instagram' => 'rgba(228, 64, 95, 0.6)',
        'facebook' => 'rgba(24, 119, 242, 0.6)',
        'twitter' => 'rgba(29, 161, 242, 0.6)',
        'linkedin' => 'rgba(10, 102, 194, 0.6)'
    ];

    return $glowColors[$platform] ?? 'rgba(255, 0, 0, 0.6)';
}

function getPlatformSVG($platform) {
    $svgs = [
        'youtube' => '<svg viewBox="0 0 24 24" fill="#FF0000"><path d="M10 15l5.19-3L10 9v6m11.56-7.83c.13.47.22 1.1.28 1.9.07.8.1 1.49.1 2.09L22 12c0 2.19-.16 3.8-.44 4.83-.25.9-.83 1.48-1.73 1.73-.47.13-1.33.22-2.65.28-1.3.07-2.49.1-3.59.1L12 19c-4.19 0-6.8-.16-7.83-.44-.9-.25-1.48-.83-1.73-1.73-.13-.47-.22-1.1-.28-1.9-.07-.8-.1-1.49-.1-2.09L2 12c0-2.19.16-3.8.44-4.83.25-.9.83-1.48 1.73-1.73.47-.13 1.33-.22 2.65-.28 1.3-.07 2.49-.1 3.59-.1L12 5c4.19 0 6.8.16 7.83.44.9.25 1.48.83 1.73 1.73z"/></svg>',

        'tiktok' => '<svg viewBox="0 0 24 24" fill="#ffffff"><path d="M19.59 6.69a4.83 4.83 0 0 1-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 0 1-5.2 1.74 2.89 2.89 0 0 1 2.31-4.64 2.93 2.93 0 0 1 .88.13V9.4a6.84 6.84 0 0 0-1-.05A6.33 6.33 0 0 0 5 20.1a6.34 6.34 0 0 0 10.86-4.43v-7a8.16 8.16 0 0 0 4.77 1.52v-3.4a4.85 4.85 0 0 1-1-.1z"/></svg>',

        'instagram' => '<svg viewBox="0 0 24 24"><defs><linearGradient id="igGrad" x1="0" x2="1" y1="0" y2="1"><stop offset="0" stop-color="#f58529"/><stop offset="0.3" stop-color="#dd2a7b"/><stop offset="0.6" stop-color="#8134af"/><stop offset="1" stop-color="#515bd4"/></linearGradient></defs><path fill="url(#igGrad)" d="M7.8 2h8.4C19.4 2 22 4.6 22 7.8v8.4a5.8 5.8 0 0 1-5.8 5.8H7.8C4.6 22 2 19.4 2 16.2V7.8A5.8 5.8 0 0 1 7.8 2m-.2 2A3.6 3.6 0 0 0 4 7.6v8.8C4 18.39 5.61 20 7.6 20h8.8a3.6 3.6 0 0 0 3.6-3.6V7.6C20 5.61 18.39 4 16.4 4H7.6m9.65 1.5a1.25 1.25 0 0 1 1.25 1.25A1.25 1.25 0 0 1 17.25 8 1.25 1.25 0 0 1 16 6.75a1.25 1.25 0 0 1 1.25-1.25M12 7a5 5 0 0 1 5 5 5 5 0 0 1-5 5 5 5 0 0 1-5-5 5 5 0 0 1 5-5m0 2a3 3 0 0 0-3 3 3 3 0 0 0 3 3 3 3 0 0 0 3-3 3 3 0 0 0-3-3z"/></svg>',

        'facebook' => '<svg viewBox="0 0 24 24" fill="#1877F2"><path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/></svg>',

        'twitter' => '<svg viewBox="0 0 24 24" fill="#1DA1F2"><path d="M23.953 4.57a10 10 0 01-2.825.775 4.958 4.958 0 002.163-2.723c-.951.555-2.005.959-3.127 1.184a4.92 4.92 0 00-8.384 4.482C7.69 8.095 4.067 6.13 1.64 3.162a4.822 4.822 0 00-.666 2.475c0 1.71.87 3.213 2.188 4.096a4.904 4.904 0 01-2.228-.616v.06a4.923 4.923 0 003.946 4.827 4.996 4.996 0 01-2.212.085 4.936 4.936 0 004.604 3.417 9.867 9.867 0 01-6.102 2.105c-.39 0-.779-.023-1.17-.067a13.995 13.995 0 007.557 2.209c9.053 0 13.998-7.496 13.998-13.985 0-.21 0-.42-.015-.63A9.935 9.935 0 0024 4.59z"/></svg>',

        'linkedin' => '<svg viewBox="0 0 24 24" fill="#0077B5"><path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433c-1.144 0-2.063-.926-2.063-2.065 0-1.138.92-2.063 2.063-2.063 1.14 0 2.064.925 2.064 2.063 0 1.139-.925 2.065-2.064 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z"/></svg>'
    ];

    return $svgs[$platform] ?? $svgs['youtube'];
}
?>
<?php include "doctype.php"; ?>
  <link rel="stylesheet" href="perform-socials.css" />
  <!-- Link new task-card design CSS file -->
  <link rel="stylesheet" href="watch-earn.css">
  <style>
    :root {
      --page-blue-900: #030922;
      --page-blue-700: #0a164a;
      --page-blue-500: #142a7e;
      --page-blue-300: #2c5bf5;
      --page-mint: #4de1c1;
      --page-white: #f5f9ff;
      --panel-glass: rgba(13, 24, 62, 0.84);
      --panel-border: rgba(86, 139, 241, 0.3);
      --shadow-heavy: 0 40px 120px rgba(4, 10, 36, 0.65);
      --transition-long: 0.85s cubic-bezier(0.19, 1, 0.22, 1);
      --transition-short: 0.4s ease;
      --watch-purple: #a855f7;
      --watch-pink: #ec4899;
    }

    * { box-sizing: border-box; }

    body {
      margin: 0;
      font-family: "Titillium Web", "Segoe UI", sans-serif;
      background: #030922;
      color: var(--page-white);
      overflow-x: hidden;
    }

    .page-shell { 
      min-height: 100vh; 
      display: flex;
    }

   aside {
      position: fixed;
      left: 0;
      top: 0;
      bottom: 0;
      width: 320px;
      background: rgba(5, 15, 44, 0.92);
      backdrop-filter: blur(18px);
      padding: clamp(1.25rem, 3vw, 2.25rem) clamp(1rem, 2.5vw, 2rem);
      display: flex;
      flex-direction: column;
      gap: clamp(1.25rem, 2.5vw, 2rem);
      border-right: 1px solid var(--panel-border);
      overflow-y: auto;
      z-index: 100;
      transition: transform var(--transition-short);
    }

    aside::before {
      content: "";
      position: absolute;
      inset: 0;
      background: 
        radial-gradient(circle at 20% 30%, rgba(251, 191, 36, 0.15), transparent 50%),
        radial-gradient(circle at 80% 70%, rgba(245, 158, 11, 0.12), transparent 45%);
      pointer-events: none;
    }


    main {
      margin-left: 0;
      flex: 1;
      padding: 32px 40px;
      display: grid;
      gap: 32px;
    }

    @media (max-width: 700px) {
      .page-shell {
        flex-direction: column;
      }

      aside {
        position: relative;
        top: 0;
        width: 100%;
        height: auto;
        border-right: none;
        border-bottom: 1px solid var(--panel-border);
        padding: clamp(1rem, 2.5vw, 1.75rem) clamp(0.875rem, 2vw, 1.25rem);
        gap: clamp(0.875rem, 2vw, 1.25rem);
      }

      main {
        width: 100%;
        padding: 24px 16px 120px;
      }

      .vector-cluster {
        display: none;
      }
    }

    .back-link {
      display: inline-flex;
      align-items: center;
      gap: 10px;
      font-weight: 600;
      font-size: clamp(0.75rem, 1.5vw, 0.875rem);
      letter-spacing: 0.1em;
      text-transform: uppercase;
      color: rgba(210, 226, 255, 0.78);
      transition: color var(--transition-short), transform var(--transition-short);
      text-decoration: none;
    }

    .back-link:hover { color: var(--page-white); transform: translateX(-4px); }

    .page-title {
      font-size: clamp(1rem, 3vw, 1.5rem);
      letter-spacing: 0.1em;
      text-transform: uppercase;
      margin: 0 0 clamp(0.5rem, 1vw, 0.75rem);
      font-weight: 700;
    }


    .side-description { 
      color: rgba(206, 224, 255, 0.74); 
      line-height: 1.7; 
      font-size: 1rem;
    }

    .vector-cluster {
      position: relative;
      border-radius: 24px;
      padding: 1.5rem;
      background: 
        linear-gradient(135deg, rgba(168, 85, 247, 0.3), rgba(236, 72, 153, 0.6)),
        rgba(12, 29, 82, 0.9);
      box-shadow: var(--shadow-heavy);
      overflow: hidden;
    }

    .vector-cluster::after {
      content: "";
      position: absolute;
      width: 320px;
      height: 320px;
      top: -150px;
      right: -120px;
      border-radius: 50%;
      background: radial-gradient(circle, rgba(236, 72, 153, 0.35), transparent 60%);
    }

    .vector-cluster img {
      width: 100%;
      border-radius: 18px;
      display: block;
      filter: drop-shadow(0 28px 80px rgba(168, 85, 247, 0.4));
    }


     .aside-welcome {
      display: grid;
      grid-template-columns: auto 1fr;
      align-items: center;
      gap: clamp(0.75rem, 1.5vw, 1rem);
      background: linear-gradient(135deg, rgba(44, 91, 245, 0.3), rgba(26, 58, 171, 0.2));
      border: 1px solid rgba(44, 91, 245, 0.5);
      box-shadow: 0 0 10px rgba(44, 91, 245, 0.6);
      border-radius: 20px;
      padding: clamp(0.875rem, 1.75vw, 1.125rem);

      position: relative;
      z-index: 2;
    }

    .aside-avatar {
      width: clamp(48px, 10vw, 64px);
      height: clamp(48px, 10vw, 64px);
      border-radius: 50%;
      overflow: hidden;
      border: 4px solid rgba(251, 191, 36, 0.35);
      box-shadow: 0 14px 34px rgba(3, 9, 30, 0.55);
    }

    .aside-avatar img {
      width: 100%;
      display: block;
    }

    .welcome-tag {
      margin: 0;
      font-size: clamp(0.6875rem, 1.25vw, 0.75rem);
      letter-spacing: 0.12em;
      text-transform: uppercase;
      color: rgba(205, 219, 255, 0.62);
    }

    .aside-welcome h3 {
      margin: clamp(0.25rem, 0.5vw, 0.375rem) 0 clamp(0.125rem, 0.25vw, 0.25rem);
      font-size: clamp(1rem, 2vw, 1.12rem);
      letter-spacing: 0.04em;
      color: var(--page-white);
      font-weight: 700;
    }

    .welcome-meta {
      font-size: clamp(0.75rem, 1.5vw, 0.8rem);
      letter-spacing: 0.08em;
      color: rgba(149, 183, 255, 0.7);
    }

    .watch-hero {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
      gap: 1.75rem;
      align-items: center;
      background: var(--panel-glass);
      border-radius: 26px;
      border: 1px solid var(--panel-border);
      padding: 2.375rem;
      box-shadow: var(--shadow-heavy);
      position: relative;
      overflow: hidden;
    }

    .watch-hero::before {
      content: "";
      position: absolute;
      inset: 0;
      background: url("front/assets/images/header-right-img.png") right/contain no-repeat;
      opacity: 0.08;
    }

    .watch-copy { position: relative; z-index: 2; }

    .watch-copy h1 { 
      margin: 0 0 0.75rem; 
      font-size: clamp(1.75rem, 4vw, 2.4rem);
      font-weight: 700;
    }

    .watch-copy p { 
      margin: 0; 
      color: rgba(218, 231, 255, 0.78); 
      line-height: 1.7; 
      font-size: 1rem;
    }

    .stats-row {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(min(100%, 200px), 1fr));
      gap: 1.375rem;
    }

    @media (max-width: 700px) {
      .stats-row {
        grid-template-columns: repeat(2, 1fr);
      }
    }

    .stat-card {
      padding: 1.5rem;
      border-radius: 20px;
      background: rgba(6, 16, 48, 0.9);
      border: 1px solid rgba(100, 154, 255, 0.24);
      box-shadow: var(--shadow-heavy);
      position: relative;
      overflow: hidden;
    }

    .stat-card::after {
      content: "";
      position: absolute;
      width: 110px;
      height: 110px;
      top: -26px;
      right: -16px;
      border-radius: 50%;
      background: radial-gradient(circle, rgba(168, 85, 247, 0.28), transparent 60%);
    }

    .stat-label {
      font-size: 0.875rem;
      letter-spacing: 0.08em;
      text-transform: uppercase;
      color: rgba(205, 219, 255, 0.7);
      margin-bottom: 0.75rem;
      position: relative;
      z-index: 2;
    }

    .stat-value {
      font-size: 2rem;
      font-weight: 700;
      color: var(--watch-purple);
      position: relative;
      z-index: 2;
    }

    .section-title {
      font-size: clamp(1.25rem, 2.5vw, 1.5rem);
      font-weight: 700;
      letter-spacing: 0.04em;
      margin: 0 0 1.5rem;
      display: flex;
      align-items: center;
      gap: 12px;
    }

    .section-title::before {
      content: "";
      width: 4px;
      height: 28px;
      background: linear-gradient(180deg, var(--watch-purple), var(--watch-pink));
      border-radius: 4px;
    }

    .media-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(min(100%, 320px), 1fr));
      gap: 1.75rem;
    }

    .media-card {
      padding: 1rem;
      border-radius: 20px;
      background: rgba(6, 16, 48, 0.9);
      border: 1px solid rgba(100, 154, 255, 0.24);
      box-shadow: var(--shadow-heavy);
      position: relative;
      overflow: hidden;
      transition: transform var(--transition-long), border-color var(--transition-short);
      display: flex;
      flex-direction: column;
      height: auto;
    }

    .media-card:hover {
      transform: translateY(-8px);
      border-color: rgba(168, 85, 247, 0.45);
    }

    .media-card::after {
      content: "";
      position: absolute;
      width: 110px;
      height: 110px;
      top: -26px;
      right: -16px;
      border-radius: 50%;
      background: radial-gradient(circle, rgba(168, 85, 247, 0.28), transparent 60%);
    }

    .media-title {
      font-size: 1.1rem;
      font-weight: 700;
      letter-spacing: 0.03em;
      position: relative;
      z-index: 2;
      margin-bottom: 0.75rem;
    }

    .media-player {
      width: 100%;
      border-radius: 12px;
      margin: 1rem 0;
      position: relative;
      z-index: 2;
    }

    .media-player iframe {
      width: 100%;
      height: 200px;
      border-radius: 12px;
      border: none;
    }

    .media-player audio {
      width: 100%;
      border-radius: 12px;
    }

    .media-footer {
      display: flex;
      justify-content: space-between;
      align-items: center;
      gap: 0.75rem;
      flex-wrap: wrap;
      position: relative;
      z-index: 2;
      margin-top: 1rem;
    }

    .reward-badge {
      font-weight: 600;
      font-size: 0.875rem;
      letter-spacing: 0.08em;
      text-transform: uppercase;
      color: var(--watch-purple);
      background: rgba(168, 85, 247, 0.15);
      padding: 8px 16px;
      border-radius: 12px;
      border: 1px solid rgba(168, 85, 247, 0.3);
    }

    .claim-btn {
      border: none;
      border-radius: 16px;
      padding: 0.75rem 1.125rem;
      font-weight: 600;
      font-size: 0.875rem;
      letter-spacing: 0.04em;
      text-transform: uppercase;
      cursor: pointer;
      background: linear-gradient(135deg, var(--watch-purple), var(--watch-pink));
      color: var(--page-white);
      border: 1px solid rgba(168, 85, 247, 0.4);
      transition: transform var(--transition-short), box-shadow var(--transition-short);
      box-shadow: 0 10px 30px rgba(168, 85, 247, 0.3);
    }

    .claim-btn:hover { 
      transform: translateY(-4px); 
      box-shadow: 0 15px 40px rgba(168, 85, 247, 0.4);
    }

    .claim-btn:disabled {
      opacity: 0.5;
      cursor: not-allowed;
      background: rgba(100, 116, 139, 0.5);
      box-shadow: none;
    }

    .alert {
      padding: 16px 20px;
      border-radius: 18px;
      margin-bottom: 24px;
      font-size: 0.95rem;
      font-weight: 500;
      letter-spacing: 0.02em;
    }

    .alert-success {
      background: rgba(77, 225, 193, 0.15);
      border: 1px solid rgba(77, 225, 193, 0.4);
      color: #4de1c1;
    }

    .alert-error {
      background: rgba(239, 68, 68, 0.15);
      border: 1px solid rgba(239, 68, 68, 0.4);
      color: #fca5a5;
    }

    .ticker {
      border-radius: 24px;
      border: 1px solid rgba(168, 85, 247, 0.32);
      background: rgba(8, 18, 52, 0.78);
      padding: 1rem;
      box-shadow: var(--shadow-heavy);
      overflow: hidden;
    }

    .ticker-track {
      display: inline-flex;
      gap: 42px;
      animation: tickerMove 30s linear infinite;
      letter-spacing: 0.16em;
      text-transform: uppercase;
      color: rgba(204, 228, 255, 0.82);
      font-weight: 600;
      font-size: 0.875rem;
      white-space: nowrap;
    }

    @keyframes tickerMove { from { transform: translateX(0); } to { transform: translateX(-50%); } }

   /* Updated mobile footer with 5 icons */
    .mobile-fintech-footer {
      display: none;
      position: fixed;
      left: 12px;
      right: 12px;
      bottom: 16px;
      padding: 10px;
      background: transparent;
      border: 1px solid rgba(86, 139, 241, 0.35);
      border-radius: 32px;
      backdrop-filter: blur(50px);
      box-shadow: 0 20px 60px rgba(4, 10, 36, 0.7);
      justify-content: space-around;
      align-items: center;
      z-index: 90;
    }

    .mobile-fintech-footer a {
      flex: 1;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      gap: 4px;
      text-decoration: none;
      color: rgba(205, 219, 255, 0.75);
      font-size: 0.45rem;
      letter-spacing: 0.06em;
      text-transform: uppercase;
      transition: all var(--transition-short);
      padding: 8px 4px;
      border-radius: 16px;
    }

    .card-badge {
      display: inline-block;
      padding: 8px 16px;
      background: rgba(77, 225, 193, 0.2);
      border: 1px solid rgba(77, 225, 193, 0.3);
      border-radius: 20px;
      font-size: clamp(0.7rem, 1.5vw, 0.75rem);
      letter-spacing: 0.1em;
      text-transform: uppercase;
      color: var(--page-mint);
      margin-bottom: 16px;
      font-weight: 600;
    }

    /* Special styling for middle icon (3rd icon - Withdraw) */
    /* .mobile-fintech-footer a:nth-child(3) {
      position: relative;
      transform: translateY(-12px);
    } */

    .mobile-fintech-footer a:nth-child(3) .icon-wrapper {
      width: 56px;
      height: 56px;
      border-radius: 50%;
      background: linear-gradient(135deg, rgba(77, 225, 193, 0.25), rgba(47, 91, 234, 0.25));
      backdrop-filter: blur(12px);
      border: 2px solid rgba(77, 225, 193, 0.4);
      display: flex;
      align-items: center;
      justify-content: center;
      box-shadow: 0 8px 24px rgba(77, 225, 193, 0.3);
    }

    .mobile-fintech-footer a:nth-child(3) svg {
      width: 28px;
      height: 28px;
    }

    .mobile-fintech-footer a.active {
      color: var(--page-mint);
    }

    .mobile-fintech-footer svg {
      width: 22px;
      height: 22px;
      fill: currentColor;
      filter: drop-shadow(0 4px 12px rgba(4, 10, 36, 0.4));
    }

    .mobile-fintech-footer a:hover {
      color: var(--page-mint);
      transform: translateY(-2px);
    }

    .mobile-fintech-footer a:nth-child(3):hover {
      transform: translateY(-14px);
    }

    @media (max-width: 680px) {
      body {
        padding-bottom: 100px;
      }

      .mobile-fintech-footer {
        display: flex;
      }
    }

    /* Profile.php error toast styles */
    .toast-message {
      position: fixed;
      top: 20px;
      right: -400px;
      padding: 16px 24px;
      border-radius: 12px;
      color: white;
      font-family: 'Segoe UI', sans-serif;
      font-size: 15px;
      z-index: 10000;
      opacity: 0;
      box-shadow: 0 10px 40px rgba(0, 0, 0, 0.2);
      transition: right 0.6s ease, opacity 0.6s ease;
    }

    .toast-message.success {
      background: rgba(77, 225, 193, 0.95);
      color: #030922;
      box-shadow: 0 10px 40px rgba(77, 225, 193, 0.4);
    }

    .toast-message.error {
      background: rgba(255, 77, 77, 0.95);
      color: #fff;
      box-shadow: 0 10px 40px rgba(255, 77, 77, 0.4);
    }

    .toast-message.show {
      right: 20px;
      opacity: 1;
    }

    /* Withdrawal-style success popup */
    .success-overlay {
      position: fixed;
      inset: 0;
      background: rgba(3, 9, 34, 0.9);
      backdrop-filter: blur(8px);
      display: none;
      justify-content: center;
      align-items: center;
      z-index: 9999;
      opacity: 0;
      transition: opacity 0.4s ease;
    }

    .success-overlay.show {
      display: flex;
      opacity: 1;
    }

    .success-card {
      background: #0a153d;
      border-radius: 22px;
      border: 1px solid rgba(100, 160, 255, 0.25);
      box-shadow: 0 25px 90px rgba(0,0,0,0.5);
      max-width: 450px;
      width: 90%;
      text-align: center;
      padding: 32px 24px;
      color: #f5f9ff;
      animation: popIn 0.5s ease forwards;
    }

    @keyframes popIn {
      from { transform: scale(0.8); opacity: 0; }
      to { transform: scale(1); opacity: 1; }
    }

    .success-check svg {
      width: 80px;
      margin: 16px auto;
      display: block;
      animation: checkPulse 1.3s ease;
    }

    @keyframes checkPulse {
      0% { transform: scale(0.5); opacity: 0; }
      100% { transform: scale(1); opacity: 1; }
    }

    .success-card h2 {
      color: #4de1c1;
      margin: 16px 0;
      font-size: 1.8rem;
    }

    .success-details {
      background: rgba(255,255,255,0.06);
      border-radius: 14px;
      padding: 20px;
      margin: 20px 0;
      text-align: left;
      line-height: 1.8;
    }

    .success-details div {
      display: flex;
      justify-content: space-between;
      margin-bottom: 12px;
    }

    .success-details strong {
      color: rgba(205, 219, 255, 0.7);
    }

    .close-success {
      background: linear-gradient(135deg, #2c5bf5, #4de1c1);
      border: none;
      border-radius: 12px;
      padding: 14px 32px;
      font-weight: 600;
      color: #0a153d;
      cursor: pointer;
      transition: 0.3s;
      font-size: 1rem;
      text-transform: uppercase;
      letter-spacing: 0.05em;
    }

    .close-success:hover {
      transform: translateY(-3px);
      box-shadow: 0 6px 20px rgba(77, 225, 193, 0.3);
    }

    /* Video locking - prevent clicking other videos while one is playing */
    .media-card.locked {
      opacity: 0.5;
      pointer-events: none;
      cursor: not-allowed;
    }

    /* Added styles for watch-earn specific features */
    .video-thumbnail {
      position: relative;
      width: 100%;
      padding-top: 56.25%; /* 16:9 aspect ratio */
      background: #000;
      border-radius: 16px;
      overflow: hidden;
      cursor: pointer;
      margin: 12px 0;
      border: 2px solid var(--platform-glow-border);
      box-shadow: 
        0 0 12px var(--platform-glow-color),
        inset 0 0 8px rgba(255, 255, 255, 0.05);
      transition: border-color 0.3s ease, box-shadow 0.3s ease;
    }

    .video-thumbnail:hover {
      border-color: var(--platform-glow-border-hover);
      box-shadow: 
        0 0 16px var(--platform-glow-color),
        inset 0 0 8px rgba(255, 255, 255, 0.08);
    }

    .video-thumbnail img {
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      object-fit: cover;
    }

    /* Added (ad) badge styling */
    .ad-badge {
      position: absolute;
      top: 12px;
      left: 12px;
      background: rgba(255, 255, 255, 0.95);
      color: #000;
      font-size: 0.75rem;
      font-weight: 700;
      padding: 4px 10px;
      border-radius: 50px;
      border: 2px solid rgba(255, 255, 255, 1);
      z-index: 3;
      letter-spacing: 0.05em;
      text-transform: uppercase;
      box-shadow: 0 2px 8px rgba(0, 0, 0, 0.3);
    }

    .video-play-overlay {
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      display: flex;
      align-items: center;
      justify-content: center;
      background: rgba(0, 0, 0, 0.5);
      backdrop-filter: blur(4px);
      transition: all 0.3s ease;
      opacity: 1;
    }

    .video-thumbnail:hover .video-play-overlay {
      background: rgba(0, 0, 0, 0.65);
      backdrop-filter: blur(6px);
    }

    .video-play-overlay svg {
      width: 80px;
      height: 80px;
      color: #fff;
      transition: transform 0.3s ease, filter 0.3s ease, box-shadow 0.3s ease;
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 20px;
      background: var(--platform-glow-bg);
      border: 2px solid var(--platform-glow-border);
      border-radius: 50%;
      box-shadow: 
        0 0 12px var(--platform-glow-color),
        inset 0 0 10px rgba(255, 255, 255, 0.08);
      filter: drop-shadow(0 6px 16px rgba(0, 0, 0, 0.7));
    }

    .video-thumbnail:hover .video-play-overlay svg {
      transform: scale(1.1);
      border-color: var(--platform-glow-border-hover);
      background: var(--platform-glow-bg-hover);
      box-shadow: 
        0 0 18px var(--platform-glow-color),
        inset 0 0 10px rgba(255, 255, 255, 0.12);
      filter: drop-shadow(0 8px 20px rgba(0, 0, 0, 0.8));
    }

    .premium-badge {
      position: absolute;
      top: 12px;
      right: 12px;
      background: linear-gradient(135deg, #fbbf24, #f59e0b);
      color: #000;
      padding: 6px 12px;
      border-radius: 8px;
      font-size: 0.75rem;
      font-weight: 700;
      letter-spacing: 0.05em;
      z-index: 2;
    }

    .free-user-modal {
      display: none;
      position: fixed;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      background: rgba(3, 9, 34, 0.9);
      backdrop-filter: blur(8px);
      z-index: 9999999;
      align-items: center;
      justify-content: center;
      padding: 20px;
    }

    .free-user-modal.active {
      display: flex;
    }

    .free-user-content {
      background: rgba(6, 16, 48, 0.98);
      border: 1px solid rgba(100, 154, 255, 0.3);
      border-radius: 24px;
      padding: 32px;
      max-width: 500px;
      width: 100%;
      text-align: center;
    }

    .free-user-content svg {
      width: 80px;
      height: 80px;
      margin-bottom: 24px;
      color: #fbbf24;
    }

    .free-user-content h2 {
      margin: 0 0 16px;
      font-size: 1.5rem;
      color: var(--page-white);
    }

    .free-user-content p {
      color: rgba(205, 219, 255, 0.7);
      line-height: 1.7;
      margin-bottom: 24px;
    }

    .upgrade-btn {
      display: inline-block;
      padding: 14px 32px;
      background: linear-gradient(135deg, #fbbf24, #f59e0b);
      color: #000;
      border-radius: 12px;
      text-decoration: none;
      font-weight: 700;
      font-size: 1rem;
      text-transform: uppercase;
      letter-spacing: 0.05em;
      transition: all 0.3s ease;
      margin-right: 12px;
    }

    .upgrade-btn:hover {
      transform: translateY(-2px);
      box-shadow: 0 8px 24px rgba(251, 191, 36, 0.4);
    }

    .close-modal-btn {
      display: inline-block;
      padding: 14px 32px;
      background: rgba(100, 154, 255, 0.2);
      color: var(--page-white);
      border-radius: 12px;
      text-decoration: none;
      font-weight: 600;
      font-size: 1rem;
      cursor: pointer;
      transition: all 0.3s ease;
    }

    .close-modal-btn:hover {
      background: rgba(100, 154, 255, 0.3);
    }

    .view-toggle {
      display: flex;
      gap: 8px;
      background: rgba(8, 21, 64, 0.6);
      border-radius: 16px;
      padding: 6px;
      border: 1px solid rgba(100, 154, 255, 0.25);
    }

    .view-toggle button {
      padding: 10px 20px;
      border: none;
      background: transparent;
      color: rgba(205, 219, 255, 0.7);
      border-radius: 12px;
      cursor: pointer;
      transition: all 0.3s ease;
      font-weight: 600;
      font-size: 0.85rem;
      text-transform: uppercase;
      letter-spacing: 0.04em;
    }

    .view-toggle button.active {
      background: linear-gradient(135deg, rgba(77, 225, 193, 0.3), rgba(44, 92, 245, 0.3));
      color: var(--page-white);
      border: 1px solid rgba(77, 225, 193, 0.4);
    }

    .tasks-list-view {
      display: none;
      flex-direction: column;
      gap: 16px;
    }

    .tasks-list-view.active {
      display: flex;
    }

    .task-list-item {
      display: grid;
      grid-template-columns: auto 1fr auto;
      gap: 20px;
      align-items: center;
      background: rgba(6, 16, 48, 0.9);
      border: 1px solid rgba(100, 154, 255, 0.24);
      border-radius: 20px;
      padding: 20px;
      transition: all 0.3s ease;
    }

    .task-list-item:hover {
      border-color: rgba(77, 225, 193, 0.45);
      transform: translateX(4px);
    }

    .task-list-icon {
      width: 56px;
      height: 56px;
      border-radius: 14px;
      background: linear-gradient(135deg, rgba(77, 225, 193, 0.2), rgba(44, 92, 245, 0.2));
      display: flex;
      align-items: center;
      justify-content: center;
      border: 1px solid rgba(77, 225, 193, 0.3);
    }

    .task-list-icon svg {
      width: 32px;
      height: 32px;
    }

    .task-list-info h3 {
      margin: 0 0 8px;
      font-size: 1.1rem;
      color: var(--page-white);
    }

    .task-list-info p {
      margin: 0;
      color: rgba(205, 219, 255, 0.7);
      font-size: 0.9rem;
    }

    .task-list-action {
      display: flex;
      flex-direction: column;
      align-items: flex-end;
      gap: 8px;
    }

    .task-reward {
      font-size: 1.3rem;
      font-weight: 700;
      color: var(--page-mint);
    }


    .verification-modal {
      display: none;
      position: fixed;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      background: rgba(3, 9, 34, 0.9);
      backdrop-filter: blur(8px);
      z-index: 2000;
      align-items: center;
      justify-content: center;
      padding: 20px;
    }

    .verification-modal.active {
      display: flex;
    }

    .verification-content {
      background: rgba(6, 16, 48, 0.98);
      border: 1px solid rgba(100, 154, 255, 0.3);
      border-radius: 24px;
      padding: 32px;
      max-width: 600px;
      width: 100%;
      max-height: 90vh;
      overflow-y: auto;
    }

    .verification-step {
      display: none;
    }

    .verification-step.active {
      display: block;
    }

    .verification-step h2 {
      margin: 0 0 24px;
      font-size: 1.5rem;
      color: var(--page-white);
    }

    .verification-step p {
      color: rgba(205, 219, 255, 0.7);
      line-height: 1.7;
      margin-bottom: 24px;
    }

    .form-input {
      width: 100%;
      padding: 14px 16px;
      border-radius: 12px;
      border: 1px solid rgba(100, 154, 255, 0.3);
      background: rgba(8, 21, 64, 0.6);
      color: var(--page-white);
      font-size: 0.95rem;
      font-family: inherit;
      transition: border-color 0.3s ease;
      margin-bottom: 24px;
    }

    .form-input:focus {
      outline: none;
      border-color: rgba(77, 225, 193, 0.5);
    }

    .verification-actions {
      display: flex;
      gap: 12px;
      justify-content: flex-end;
    }

    .btn-secondary {
      padding: 12px 24px;
      border-radius: 12px;
      border: 1px solid rgba(100, 154, 255, 0.3);
      background: rgba(8, 21, 64, 0.6);
      color: var(--page-white);
      font-weight: 600;
      font-size: 0.9rem;
      cursor: pointer;
      transition: all 0.3s ease;
    }

    .btn-secondary:hover {
      border-color: rgba(77, 225, 193, 0.5);
    }

    .alert-message {
      position: fixed;
      top: 20px;
      right: -400px;
      padding: 16px 24px;
      border-radius: 12px;
      color: white;
      font-family: 'Segoe UI', sans-serif;
      font-size: 15px;
      z-index: 10000;
      opacity: 0;
      box-shadow: 0 10px 40px rgba(0, 0, 0, 0.2);
      transition: right 0.6s ease, opacity 0.6s ease;
    }

    .alert-message.show {
      right: 20px;
      opacity: 1;
    }

    .alert-success { 
      background: rgba(77, 225, 193, 0.95);
      color: #030922;
      box-shadow: 0 10px 40px rgba(77, 225, 193, 0.4); 
    }

    .alert-error {
      background: rgba(255, 77, 77, 0.95);
      color: #fff;
      box-shadow: 0 10px 40px rgba(255, 77, 77, 0.4);
    }

    .alert-warning {
      background: rgba(255, 193, 7, 0.95);
      color: #030922;
      box-shadow: 0 10px 40px rgba(255, 193, 7, 0.4);
    }

    @keyframes spin {
      to { transform: rotate(360deg); }
    }

    /* Terms and Services modal styles */
    .ts-modal {
      display: none;
      position: fixed;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      background: rgba(3, 9, 34, 0.9);
      backdrop-filter: blur(8px);
      align-items: center;
      justify-content: center;
      padding: 20px;
      z-index: 900;
    }

    .ts-modal.active {
      display: flex;
    }

    .ts-modal-content {
      background: rgba(6, 16, 48, 0.98);
      border: 1px solid rgba(100, 154, 255, 0.3);
      border-radius: 24px;
      padding: 32px;
      max-width: 600px;
      width: 100%;
      max-height: 80vh;
      overflow-y: auto;
      display: flex;
      flex-direction: column;
    }

    .ts-modal-header {
      margin-bottom: 24px;
      border-bottom: 1px solid rgba(100, 154, 255, 0.2);
      padding-bottom: 16px;
    }

    .ts-modal-header h2 {
      margin: 0;
      font-size: 1.5rem;
      color: var(--page-white);
    }

    .ts-modal-body {
      flex: 1;
      overflow-y: auto;
      margin-right: 8px;
      padding-right: 8px;
    }

    .ts-modal-body::-webkit-scrollbar {
      width: 6px;
    }

    .ts-modal-body::-webkit-scrollbar-track {
      background: rgba(100, 154, 255, 0.1);
      border-radius: 3px;
    }

    .ts-modal-body::-webkit-scrollbar-thumb {
      background: rgba(77, 225, 193, 0.3);
      border-radius: 3px;
    }

    .ts-modal-body::-webkit-scrollbar-thumb:hover {
      background: rgba(77, 225, 193, 0.5);
    }

    .ts-modal-body h3 {
      color: var(--page-white);
      margin-top: 20px;
      margin-bottom: 12px;
      font-size: 1.1rem;
    }

    .ts-modal-body p {
      color: rgba(205, 219, 255, 0.8);
      line-height: 1.6;
      margin-bottom: 12px;
      font-size: 0.95rem;
    }

    .ts-modal-body ul {
      color: rgba(205, 219, 255, 0.8);
      line-height: 1.6;
      margin-bottom: 12px;
      margin-left: 20px;
      font-size: 0.95rem;
    }

    .ts-modal-body li {
      margin-bottom: 8px;
    }

    .ts-modal-footer {
      display: flex;
      gap: 12px;
      justify-content: flex-end;
      align-items: center;
      border-top: 1px solid rgba(100, 154, 255, 0.2);
      padding-top: 20px;
    }

    .ts-checkbox-container {
      display: flex;
      align-items: center;
      gap: 8px;
    }

    .ts-checkbox {
      width: 20px;
      height: 20px;
      cursor: pointer;
      accent-color: var(--page-mint);
    }

    .ts-checkbox-label {
      color: rgba(205, 219, 255, 0.8);
      font-size: 0.9rem;
      cursor: pointer;
    }

    .ts-modal-actions {
      display: flex;
      gap: 12px;
      justify-content: flex-end;
    }

    .ts-checkbox-wrapper {
      background: rgba(77, 225, 193, 0.08);
      border: 1px solid rgba(77, 225, 193, 0.3);
      border-radius: 12px;
      padding: 16px;
      margin-bottom: 24px;
      display: flex;
      align-items: center;
      gap: 12px;
    }

    .ts-checkbox-wrapper input[type="checkbox"]:disabled {
      opacity: 0.5;
      cursor: not-allowed;
    }

    .ts-checkbox-wrapper input[type="checkbox"]:disabled + label {
      opacity: 0.5;
      cursor: not-allowed;
    }
  </style>

<body>
  <?php include "embed.php"; ?>
  <?php include "header2.php"; ?>

  <!-- Free User Modal -->
  <div class="free-user-modal" id="freeUserModal">
    <div class="free-user-content">
      <svg viewBox="0 0 24 24" fill="currentColor">
        <path d="M12 2L2 7l10 5 10-5-10-5zm0 18.5l-8-4v-7l8 4 8-4v7l-8 4z"/>
      </svg>
      <h2>Premium Access</h2>
      <p>Unlock Watch & Earn by activating your premium account. Start earning instantly from watching videos!</p>
      <div>
        <a href="membership.php" class="upgrade-btn">Activate Now</a>
        <button class="close-modal-btn" onclick="closeFreeUserModal()">Maybe Later</button>
      </div>
    </div>
  </div>

  <!-- Watch & Instructions Modal -->
  <div class="ts-modal" id="tsModal">
    <div class="ts-modal-content">
      <div class="ts-modal-header">
        <h2>Watch & Instructions</h2>
      </div>
      <div class="ts-modal-body">
        <p><strong>Earnova Digital – 2025 Watch & Earn</strong></p>

        <h3>1. Introduction</h3>
        <p>Welcome to our Watch & Earn Platform. By using our services, you agree to comply with and be bound by these Terms and Services. If you do not agree with any part of these terms, please do not use our platform.</p>

        <h3>2. User Responsibilities</h3>
        <p>As a user, you are responsible for:</p>
        <ul>
          <li>Providing accurate and truthful information</li>
          <li>Watching videos honestly and thoroughly</li>
          <li>Not using fake profiles or misleading information</li>
          <li>Not engaging in fraudulent or deceptive practices</li>
          <li>Maintaining the confidentiality of your account credentials</li>
        </ul>

        <h3>3. Video Watching Requirements</h3>
        <p>When watching videos:</p>
        <ul>
          <li>You must watch videos for the full duration required</li>
          <li>You must use your genuine profile or account</li>
          <li>Profile links and information must be valid and not duplicated</li>
          <li>Any violation may result in rejection and account suspension</li>
        </ul>

        <h3>4. Verification and Approval</h3>
        <p>All video submissions are subject to verification. We reserve the right to:</p>
        <ul>
          <li>Review and verify all video submissions</li>
          <li>Reject submissions that don't meet requirements</li>
          <li>Flag suspicious activity for investigation</li>
          <li>Withhold or reverse earnings for fraudulent submissions</li>
        </ul>

        <h3>5. Prohibited Activities</h3>
        <p>You agree not to:</p>
        <ul>
          <li>Use duplicate or fake accounts</li>
          <li>Submit false profile links or information</li>
          <li>Use bots or automated tools to watch videos</li>
          <li>Engage in collusion with other users</li>
          <li>Attempt to exploit platform vulnerabilities</li>
          <li>Use abusive, harassing, or offensive language</li>
        </ul>

        <h3>6. Earnings and Payments</h3>
        <p>Your earnings are calculated based on:</p>
        <ul>
          <li>Successfully watched and verified videos</li>
          <li>Your membership tier</li>
          <li>Platform-specific reward rates</li>
        </ul>
        <p>We reserve the right to modify payment terms and rates at any time with notice.</p>

        <h3>7. Account Suspension and Termination</h3>
        <p>We may suspend or terminate your account if you:</p>
        <ul>
          <li>Violate these terms and conditions</li>
          <li>Engage in fraudulent activity</li>
          <li>Submit false or misleading information</li>
          <li>Violate platform policies</li>
        </ul>

        <h3>8. Liability Disclaimer</h3>
        <p>The platform is provided "as is" without warranties. We are not liable for:</p>
        <ul>
          <li>Lost earnings due to video rejection</li>
          <li>Technical issues or platform downtime</li>
          <li>Actions of third parties or external platforms</li>
        </ul>

        <h3>9. Changes to Terms</h3>
        <p>We reserve the right to modify these terms at any time. Your continued use of the platform constitutes acceptance of any changes.</p>
        <h3>10. Video Feature & Content Promotion</h3>
<p>Want your videos to be featured on our website? We offer content promotion services to help your videos gain visibility on the Earnova platform.</p>
<div style="
  background: linear-gradient(135deg, rgba(77, 225, 193, 0.15) 0%, rgba(99, 102, 241, 0.15) 100%);
  border: 1px solid rgba(77, 225, 193, 0.3);
  border-radius: 12px;
  padding: 20px;
  margin: 16px 0;
  backdrop-filter: blur(10px);
">
  <div style="display: flex; align-items: flex-start; gap: 12px;">
    <div style="flex: 1; display: flex; flex-direction: column; align-items: flex-start;">
      <h4 style="color: #f5f9ff; margin: 0 0 8px 0; font-size: 1rem;">Watch & Earn Video Submission Notice</h4>
      <p style="color: rgba(205, 219, 255, 0.8); margin: 0 0 12px 0; font-size: 0.95rem; line-height: 1.5;">
       All videos featured in the Watch & Earn section are manually uploaded by our team.
If you would like your video content to be available on this page, please reach out to our Support Team to submit your material for review and approve.

      </p>
      <a href="https://t.me/m/wLoWjx5sZGVk" target="_blank" style="
        display: inline-block;
        background: linear-gradient(135deg, #4DE1C1 0%, #3BC9B0 100%);
        color: #030922;
        padding: 10px 20px;
        border-radius: 8px;
        text-decoration: none;
        font-weight: 600;
        font-size: 0.95rem;
        transition: all 0.3s ease;
        border: none;
        cursor: pointer;
      " onmouseover="this.style.opacity='0.9'; this.style.transform='translateY(-2px)';" onmouseout="this.style.opacity='1'; this.style.transform='translateY(0)';">
        Message Us on Telegram
      </a>
    </div>
  </div>
</div>
<h3>11. Contact Information</h3>
<p>For questions or concerns, please contact our support team through the help section of your account.</p>
       
      </div>
      <div class="ts-modal-footer">
        <div class="ts-checkbox-wrapper">
          <input type="checkbox" id="tsCheckbox" class="ts-checkbox" <?php echo $watch_agreed ? 'checked disabled' : ''; ?>>
          <label for="tsCheckbox" class="ts-checkbox-label"><span style="font-size: 13px;">I agree</span></label>
        </div>
        <div class="ts-modal-actions">
          <button class="btn-secondary" id="tsCloseBtn" onclick="closeTSModal()" style="<?php echo $watch_agreed ? 'display: block;' : 'display: none;'; ?>">Close</button>
          <button class="btn-primary" id="tsAgreeBtn" onclick="agreeTSAndClose()" style="<?php echo $watch_agreed ? 'display: none;' : 'display: block;'; ?>">Agree & Continue</button>
        </div>
      </div>
    </div>
  </div>

  <!-- Verification Modal -->
  <div class="verification-modal" id="verificationModal">
    <div class="verification-content">
      <!-- Step 1: Submit Profile Link -->
      <div class="verification-step active" id="step1">
        <h2>Submit Profile Link</h2>
        <p>Provide a link to your profile that matches the video platform.</p>

        <!-- Countdown timer -->
        <div id="countdownTimer" style="text-align: center; padding: 40px 20px;">
          <div style="width: 80px; height: 80px; border: 4px solid rgba(77, 225, 193, 0.3); border-top-color: var(--page-mint); border-radius: 50%; animation: spin 1s linear infinite; margin: 0 auto 24px;"></div>
          <h3 style="color: var(--page-mint); margin-bottom: 12px;">Please wait...</h3>
          <p style="color: rgba(205, 219, 255, 0.7); font-size: 1.2rem; font-weight: 600;" id="countdownText">60</p>
          <p style="color: rgba(205, 219, 255, 0.5); font-size: 0.9rem;">seconds remaining</p>
        </div>

        <div id="profileLinkForm" style="display: none;">
          <input type="url" class="form-input" id="profileLink" placeholder="https://platform.com/your-profile" onkeyup="validateProfileLink()">
          <small style="color: rgba(205, 219, 255, 0.6); display: block; margin-top: -16px; margin-bottom: 24px;">
            The link must match the video platform.
          </small>

          <div class="verification-actions">
            <button class="btn-secondary" onclick="cancelVerification()">Cancel</button>
            <button class="btn-primary" id="step1Next" onclick="submitVerification()" disabled>Submit</button>
          </div>
        </div>
      </div>

      <!-- Step 2: Processing -->
      <div class="verification-step" id="step2">
        <h2>Processing...</h2>
        <div style="text-align: center; padding: 40px 20px;">
          <div style="width: 64px; height: 64px; border: 4px solid rgba(77, 225, 193, 0.3); border-top-color: var(--page-mint); border-radius: 50%; animation: spin 1s linear infinite; margin: 0 auto 24px;"></div>
          <p style="color: rgba(205, 219, 255, 0.7);">Verifying your submission...</p>
        </div>
      </div>

      <!-- Step 3: Success -->
      <div class="verification-step" id="step3">
  <h2>Video Completed!</h2>
  <div style="text-align: center; padding: 40px 20px;">

    <!-- Improved SVG: centered, resized, shadow -->
    <svg viewBox="0 0 52 52" 
         style="width: 90px; height: 90px; margin-bottom: 18px; filter: drop-shadow(0 4px 10px rgba(0,0,0,0.15));">
      <circle cx="26" cy="26" r="26" fill="#4de1c1"></circle>
      <path d="M38 18L22.6 33.4 14 25"
            fill="none" stroke="#fff" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"/>
    </svg>

    <h3 style="margin: 0 0 12px; color: var(--page-mint); font-size: 1.4rem; font-weight: 600;">
      Congratulations!
    </h3>

    <p style="color: rgba(205, 219, 255, 0.75); margin-bottom: 26px; font-size: 1rem;">
      You earned <span id="rewardAmount" style="font-weight: bold; color: #4de1c1;">₦0</span> from watching the video!
    </p>
  </div>

  <!-- Improved button: rounded, gradient, shadow, hover effect -->
  <div class="verification-actions">
    <button onclick="closeVerification()" 
            style="width: 100%;
                   padding: 14px;
                   font-size: 1.1rem;
                   font-weight: 600;
                   cursor: pointer;
                   background: linear-gradient(135deg, #4de1c1, #25bfa3);
                   color: white;
                   border: none;
                   border-radius: 10px;
                   transition: 0.25s ease;
                   box-shadow: 0 6px 16px rgba(0, 255, 188, 0.25);"
            onmouseover="this.style.transform='scale(1.03)'"
            onmouseout="this.style.transform='scale(1)'">
      Continue
    </button>
  </div>
</div>

    </div>
  </div>

  <!-- Video Player Modal for watching ads -->
  <div class="verification-modal" id="videoPlayerModal" style="z-index: 10000;">
    <div class="verification-content" style="max-width: 800px;">
      <div style="position: relative; background: #000; border-radius: 12px; overflow: hidden;">
        <video id="videoPlayer" controls controlsList="nodownload" style="width: 100%; display: block; max-height: 70vh;">
          <source id="videoSource" type="video/mp4">
          Your browser does not support the video tag.
        </video>
        <div id="videoOverlayMessage" style="position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); background: rgba(0,0,0,0.8); color: white; padding: 20px 30px; border-radius: 8px; font-size: 16px; opacity: 0; transition: opacity 0.3s; pointer-events: none;">
          Please watch the full video first
        </div>
      </div>
      <div style="text-align: center; margin-top: 16px;">
        <button class="btn-secondary" onclick="closeVideoPlayer()" style="padding: 10px 30px;">Close</button>
      </div>
    </div>
  </div>

  <!-- Video Details Popup -->
  <div id="videoDetailsPopup" style="
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0,0,0,0.7);
    display: flex;
    align-items: center;
    justify-content: center;
    z-index: 10001;
    opacity: 0;
    visibility: hidden;
    transition: opacity 0.3s ease, visibility 0.3s ease;
  ">
    <div style="
      background: linear-gradient(135deg, #1a1f3a 0%, #0f1228 100%);
      border: 1px solid rgba(77, 225, 193, 0.3);
      border-radius: 16px;
      padding: 32px;
      max-width: 500px;
      width: 90%;
      text-align: center;
      transform: translateY(20px);
      transition: transform 0.3s ease;
    " id="videoDetailsPopupInner">
      <svg viewBox="0 0 52 52" style="width: 70px; height: 70px; margin-bottom: 20px;">
        <circle cx="26" cy="26" r="26" fill="#4de1c1"></circle>
        <path d="M38 18L22.6 33.4 14 25" fill="none" stroke="#fff" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"/>
      </svg>
      <h2 style="color: var(--page-mint); margin-bottom: 12px; font-size: 1.5rem;">Great Job!</h2>
      <p style="color: rgba(205, 219, 255, 0.7); margin-bottom: 24px;">You've watched the ad. Now continue to watch the full video!</p>
      
      <div style="background: rgba(77, 225, 193, 0.1); border: 1px solid rgba(77, 225, 193, 0.3); border-radius: 12px; padding: 20px; margin-bottom: 24px; text-align: left;">
        <h3 style="color: var(--page-mint); margin-bottom: 8px; font-size: 1.1rem;" id="popupVideoTitle">Video Title</h3>
        <p style="color: rgba(205, 219, 255, 0.6); margin-bottom: 12px; font-size: 0.9rem;" id="popupVideoDescription">Video description</p>
        <p style="color: rgba(205, 219, 255, 0.5); font-size: 0.85rem;">Platform: <span style="color: var(--page-mint); font-weight: 600;" id="popupVideoPlatform">YouTube</span></p>
      </div>

      <div style="display: flex; gap: 12px;">
        <button class="btn-secondary" onclick="closeVideoDetailsPopup()" style="flex: 1; padding: 12px;">Cancel</button>
        <a id="watchExternalLink" href="#" target="_blank" onclick="handleExternalWatch()" style="
          flex: 2;
          display: inline-block;
          background: linear-gradient(135deg, #4de1c1, #25bfa3);
          color: white;
          padding: 12px;
          border-radius: 8px;
          text-decoration: none;
          font-weight: 600;
          transition: transform 0.2s;
        " onmouseover="this.style.transform='scale(1.05)'" onmouseout="this.style.transform='scale(1)'">
          Watch Full Video
        </a>
      </div>
    </div>
  </div>

    <main>
      <section class="hero-section" style=" background: linear-gradient(135deg, rgba(77, 225, 193, 0.08), rgba(13, 24, 62, 0.78));
   border: 1px solid rgba(101, 154, 255, 0.32); 
      padding: 20px;
      border-radius: 20px">
        <div class="hero-content" >
          <h1 style="font-size: 20px;">Watch & Earn</h1>
          <p>Watch videos on external platforms and earn rewards. Premium members only!</p>
        </div>
        <!-- Added clickable checkbox in hero section to view instructions again -->
        <div style="background: rgba(77, 225, 193, 0.08); border: 1px solid rgba(77, 225, 193, 0.3); border-radius: 12px; padding: 16px; margin-bottom: 16px; display: flex; align-items: center; gap: 12px; cursor: pointer;" onclick="openWatchInstructionsModal()">
          <input type="checkbox" id="watchHeroCheckbox" style="width: 20px; height: 20px; cursor: pointer; accent-color: var(--page-mint);" onclick="event.stopPropagation(); openWatchInstructionsModal();">
          <label for="watchHeroCheckbox" style="color: rgba(205, 219, 255, 0.8); font-size: 0.9rem; cursor: pointer; margin: 0;">View Watch & Instructions</label>
        </div>
        <div style="display: flex; gap: 12px; align-items: center; flex-wrap: wrap;">
          <!-- Platform filter dropdown -->
          <select id="platformFilter" onchange="filterVideos()" style="padding: 10px 16px; border-radius: 12px; border: 1px solid rgba(100, 154, 255, 0.3); background: rgba(8, 21, 64, 0.6); color: var(--page-white); font-size: 0.85rem; font-weight: 600; cursor: pointer; min-width: 150px;">
            <option value="all">All Platforms</option>
            <option value="youtube">YouTube</option>
            <option value="tiktok">TikTok</option>
            <option value="instagram">Instagram</option>
            <option value="facebook">Facebook</option>
            <option value="twitter">Twitter</option>
            <option value="linkedin">LinkedIn</option>
          </select>

          <div class="view-toggle">
            <button class="active" onclick="switchView('box')">
              <svg viewBox="0 0 24 24" width="16" height="16" fill="currentColor" style="vertical-align: middle; margin-right: 4px;">
                <path d="M4 11h6V5H4v6zm0 8h6v-6H4v6zm8 0h6v-6h-6v6zm0-16v6h6V5h-6z"/>
              </svg>
              Box
            </button>
            <button onclick="switchView('list')">
              <svg viewBox="0 0 24 24" width="16" height="16" fill="currentColor" style="vertical-align: middle; margin-right: 4px;">
                <path d="M3 13h2v-2H3v2zm0 4h2v-2H3v2zm0-8h2V7H3v2zm4 4h14v-2H7v2zm0 4h14v-2H7v2zM7 7v2h14V7H7z"/>
              </svg>
              List
            </button>
          </div>
        </div>
      </section>

      <section class="stats-row">
        <div class="stat-card" style="background: linear-gradient(135deg, rgba(77, 225, 193, 0.08), rgba(13, 24, 62, 0.78));">
          <div class="stat-label">Today's Videos</div>
          <div class="stat-value" style="color: #fbbf24;"><?php echo $todayVideos; ?></div>
        </div>
         <div class="stat-card" style="background: linear-gradient(135deg, rgba(77, 225, 193, 0.08), rgba(13, 24, 62, 0.78));">
          <div class="stat-label">Total Earnings</div>
          <div class="stat-value" style="color: #fbbf24;">₦<?php echo number_format($totalVideoEarnings, 0); ?></div>
        </div>
      </section>

      <!-- Box View -->
      <section class="tasks-grid" id="boxView">
        <?php if (empty($videos)): ?>
          <div style="grid-column: 1 / -1; text-align: center; padding: 48px 24px;">
            <svg viewBox="0 0 24 24" width="80" height="80" fill="rgba(77, 225, 193, 0.3)" style="margin-bottom: 24px;">
              <path d="M10 15l5.19-3L10 9v6m11.56-7.83c.13.47.22 1.1.28 1.9.07.8.1 1.49.1 2.09L22 12c0 2.19-.16 3.8-.44 4.83-.25.9-.83 1.48-1.73 1.73-.47.13-1.33.22-2.65.28-1.3.07-2.49.1-3.59.1L12 19c-4.19 0-6.8-.16-7.83-.44-.9-.25-1.48-.83-1.73-1.73-.13-.47-.22-1.1-.28-1.9-.07-.8-.1-1.49-.1-2.09L2 12c0-2.19.16-3.8.44-4.83.25-.9.83-1.48 1.73-1.73.47-.13 1.33-.22 2.65-.28 1.3-.07 2.49-.1 3.59-.1L12 5c4.19 0 6.8.16 7.83.44.9.25 1.48.83 1.73 1.73z"/>
            </svg>
            <h2>No Videos Available</h2>
            <p>Check back soon for new videos!</p>
          </div>
        <?php else: ?>
          <?php foreach ($videos as $video): 
            $platform = strtolower($video['platform'] ?? 'youtube');
            $free_reward = $video['free_reward'] ?? 0;
            $premium_reward = $video['premium_reward'] ?? 0;
            $earning = $isPremium ? $premium_reward : $free_reward;
            $platformColor = getPlatformColor($platform);
            $thumbnail = $video['thumbnail_url'] ?? 'front/assets/images/video-placeholder.jpg';
          ?>
            <article class="task-card" data-platform="<?php echo $platform; ?>" style="--platform-border: <?php echo htmlspecialchars(getPlatformColorWithAlpha($platform, 0.6)); ?>; --platform-border-hover: <?php echo htmlspecialchars(getPlatformColorWithAlpha($platform, 0.85)); ?>; --platform-glow-color: <?php echo htmlspecialchars(getPlatformColorWithAlpha($platform, 0.6)); ?>; --platform-glow-border: <?php echo htmlspecialchars(getPlatformColorWithAlpha($platform, 0.5)); ?>; --platform-glow-border-hover: <?php echo htmlspecialchars(getPlatformColorWithAlpha($platform, 0.8)); ?>; --platform-glow-bg: <?php echo htmlspecialchars(getPlatformColorWithAlpha($platform, 0.12)); ?>; --platform-glow-bg-hover: <?php echo htmlspecialchars(getPlatformColorWithAlpha($platform, 0.2)); ?>;">
              <div class="task-header">
                <div class="platform-icon" style="background: <?php echo $platformColor; ?>15; border-color: <?php echo $platformColor; ?>40;">
                  <div style="color: <?php echo $platformColor; ?>;">
                    <?php echo getPlatformSVG($platform); ?>
                  </div>
                </div>
                <div class="task-status">
                  <span class="status-badge active" style="display: flex; gap: 2px; padding: 3px 8px;">
                    <span style="font-size: 0.7rem; color: #fbbf24;">Reward: ₦<?php echo number_format($premium_reward, 0); ?></span>
                  </span>
                </div>
              </div>

              <h3 class="task-title"><?php echo htmlspecialchars($video['title']); ?></h3>

              <div class="video-thumbnail" onclick="startVideo(<?php echo $video['id']; ?>, '<?php echo htmlspecialchars($video['video_url']); ?>', '<?php echo htmlspecialchars($video['title']); ?>', '<?php echo $platform; ?>', '<?php echo htmlspecialchars($video['description'] ?? ''); ?>', '<?php echo htmlspecialchars($video['video_file_path'] ?? ''); ?>')" style="--platform-glow-color: <?php echo htmlspecialchars(getPlatformColorWithAlpha($platform, 0.6)); ?>; --platform-glow-border: <?php echo htmlspecialchars(getPlatformColorWithAlpha($platform, 0.5)); ?>; --platform-glow-border-hover: <?php echo htmlspecialchars(getPlatformColorWithAlpha($platform, 0.8)); ?>;">
                <!-- Added (ad) badge -->
                <span class="ad-badge">ad</span>
                <img src="<?php echo htmlspecialchars($thumbnail); ?>" alt="<?php echo htmlspecialchars($video['title']); ?>">
                <div class="video-play-overlay" style="--platform-glow-color: <?php echo htmlspecialchars(getPlatformColorWithAlpha($platform, 0.6)); ?>; --platform-glow-border: <?php echo htmlspecialchars(getPlatformColorWithAlpha($platform, 0.5)); ?>; --platform-glow-border-hover: <?php echo htmlspecialchars(getPlatformColorWithAlpha($platform, 0.8)); ?>; --platform-glow-bg: <?php echo htmlspecialchars(getPlatformColorWithAlpha($platform, 0.12)); ?>; --platform-glow-bg-hover: <?php echo htmlspecialchars(getPlatformColorWithAlpha($platform, 0.2)); ?>;">
                  <svg viewBox="0 0 24 24" fill="currentColor"><path d="M8 5v14l11-7z"/></svg>
                </div>
              </div>

              <p class="task-description"><?php echo htmlspecialchars(substr($video['description'] ?? '', 0, 80)) . (strlen($video['description'] ?? '') > 80 ? '...' : ''); ?></p>

              <div class="task-meta">
                <span>Platform: <?php echo ucfirst($platform); ?></span>
              </div>
            </article>
          <?php endforeach; ?>
        <?php endif; ?>
      </section>

      <!-- List View -->
      <section class="tasks-list-view" id="listView">
        <?php if (!empty($videos)): ?>
          <?php foreach ($videos as $video): 
            $platform = strtolower($video['platform'] ?? 'youtube');
            $free_reward = $video['free_reward'] ?? 0;
            $premium_reward = $video['premium_reward'] ?? 0;
            $earning = $isPremium ? $premium_reward : $free_reward;
            $platformColor = getPlatformColor($platform);
          ?>
            <div class="task-list-item" data-platform="<?php echo $platform; ?>" onclick="startVideo(<?php echo $video['id']; ?>, '<?php echo htmlspecialchars($video['video_url']); ?>', '<?php echo htmlspecialchars($video['title']); ?>', '<?php echo $platform; ?>', '<?php echo htmlspecialchars($video['description'] ?? ''); ?>', '<?php echo htmlspecialchars($video['video_file_path'] ?? ''); ?>')">
              <div class="task-list-icon" style="background: <?php echo $platformColor; ?>15; border-color: <?php echo $platformColor; ?>40;">
                <div style="color: <?php echo $platformColor; ?>;">
                  <?php echo getPlatformSVG($platform); ?>
                </div>
              </div>
              <div class="task-list-info">
                <h3><?php echo htmlspecialchars($video['title']); ?></h3>
                <p><?php echo htmlspecialchars(substr($video['description'] ?? '', 0, 150)) . (strlen($video['description'] ?? '') > 150 ? '...' : ''); ?></p>
              </div>
              <div class="task-list-action">
                <div class="task-reward" style="display: flex; flex-direction: column; gap: 2px; text-align: right;">
                  <span style="font-size: 0.9rem; color: #fbbf24;">Reward: ₦<?php echo number_format($premium_reward, 0); ?></span>
                </div>
                <button class="btn-action btn-resume" style="background: <?php echo $platformColor; ?>;">Watch Now</button>
              </div>
            </div>
          <?php endforeach; ?>
        <?php endif; ?>
      </section>
    </main>
  </div>

    <nav class="mobile-fintech-footer">

  <a href="dashboard.php">
    <svg viewBox="0 0 24 24"><path d="M12 3a9 9 0 1 1 0 18 9 9 0 0 1 0-18Zm1 4h-2v6h6v-2h-4V7Z"/></svg>
    <span>Dashboard</span>
  </a>

  <!-- Premium (crown icon) -->
  <a href="membership.php">
    <svg viewBox="0 0 24 24"><path d="M5 7l2.5 5 4.5-4 4.5 4L19 7l2 13H3l2-13Z"/></svg>
    <span>Premium</span>
  </a>

  <a href="post-task.php">
<svg viewBox="0 0 24 24" aria-hidden="true">
  <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8l-6-6Zm1 14h-3v3h-2v-3H7v-2h3v-3h2v3h3v2Zm-3-9V3.5L18.5 8H12Z"/>
</svg>

    <span>Post Advert</span>
  </a>



  <a href="history.php">
  <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
    <path d="M13 3a9 9 0 1 0 9 9h-2a7 7 0 1 1-7-7V3l4 4-4 4V7a5 5 0 1 0 5 5h2a7 7 0 1 1-7-7z"/>
  </svg>
  <span>History</span>
</a>


  <a href="profile.php">
    <svg viewBox="0 0 24 24"><path d="M12 2a6 6 0 0 1 6 6c0 3.31-2.69 6-6 6s-6-2.69-6-6a6 6 0 0 1 6-6Zm0 14c4.42 0 8 1.79 8 4v2H4v-2c0-2.21 3.58-4 8-4Z"/></svg>
    <span>Profile</span>
  </a>
</nav>

  <script>
    const isPremiumUser = <?php echo $isPremium ? 'true' : 'false'; ?>;
    const tsAgreed = <?php echo $watch_agreed ? 'true' : 'false'; ?>;
    let currentVideoId = null;
    let currentVideoTitle = null;
    let currentVideoPlatform = null;
    let videoStartTime = null;
    let videoWindow = null;
    let countdownInterval = null;
    let clickedVideos = new Set();
    let hasWatchedFull = false; // Moved to global scope
    let currentVideoUrl = ''; // Moved to global scope
    let currentVideoDescription = ''; // Moved to global scope
    let videoFilePath = ''; // Moved to global scope


    // Terms and Services Modal Functions
    document.addEventListener('DOMContentLoaded', function() {
      const tsCheckbox = document.getElementById('tsCheckbox');
      if (tsCheckbox) {
        tsCheckbox.disabled = false;
      }

      // Show modal on first visit if not agreed
      <?php if (!$watch_agreed): ?>
        document.getElementById('tsModal').classList.add('active');
      <?php endif; ?>
    });

    function openTSModal() {
      const modal = document.getElementById('tsModal');
      if (modal) {
        modal.classList.add('active');
      }
    }

    function closeTSModal() {
      const modal = document.getElementById('tsModal');
      if (modal) {
        modal.classList.remove('active');
      }
      // Ensure checkbox is unchecked and buttons are reset if modal is closed without agreeing
      const tsCheckbox = document.getElementById('tsCheckbox');
      const tsAgreeBtn = document.getElementById('tsAgreeBtn');
      const tsCloseBtn = document.getElementById('tsCloseBtn');

      if (tsCheckbox && !tsCheckbox.disabled) { // Only reset if not permanently agreed
        tsCheckbox.checked = false;
        if(tsAgreeBtn) tsAgreeBtn.style.display = 'block';
        if(tsCloseBtn) tsCloseBtn.style.display = 'none';
      }
    }

  function agreeTSAndClose() {
  // Set checkbox as checked
  const tsCheckbox = document.getElementById('tsCheckbox');
  if(tsCheckbox) tsCheckbox.checked = true;

  // Disable checkbox and buttons after agreeing
  if(tsCheckbox) tsCheckbox.disabled = true;
  const tsAgreeBtn = document.getElementById('tsAgreeBtn');
  const tsCloseBtn = document.getElementById('tsCloseBtn');
  if(tsAgreeBtn) tsAgreeBtn.style.display = 'none';
  if(tsCloseBtn) tsCloseBtn.style.display = 'block';

  // Send AJAX request to store agreement in session
  fetch('watch-earn.php', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/x-www-form-urlencoded',
    },
    body: 'ajax=1&action=agree_terms'
  })
  .then(response => response.json())
  .then(data => {
    if (data.success) {
      // Close modal and show success
      closeTSModal();
      showToast('Watch instructions accepted!', 'success');

      // 🔥 Automatically refresh page after 1.2 seconds
      setTimeout(() => {
        location.reload();
      }, 1200);

    } else {
      // Re-enable buttons if AJAX fails
      if(tsCheckbox) tsCheckbox.disabled = false;
      if(tsCheckbox) tsCheckbox.checked = false;
      if(tsAgreeBtn) tsAgreeBtn.style.display = 'block';
      if(tsCloseBtn) tsCloseBtn.style.display = 'none';
      showToast('Failed to save agreement. Please try again.', 'error');
    }
  })
  .catch(error => {
    console.error('Error agreeing to instructions:', error);
    // Re-enable buttons if AJAX fails
    if(tsCheckbox) tsCheckbox.disabled = false;
    if(tsCheckbox) tsCheckbox.checked = false;
    if(tsAgreeBtn) tsAgreeBtn.style.display = 'block';
    if(tsCloseBtn) tsCloseBtn.style.display = 'none';
    showToast('Failed to save agreement. Please try again.', 'error');
  });
}


    function showToast(message, type = 'info') {
      const toast = document.createElement('div');
      toast.className = `alert-message alert-${type}`;
      toast.textContent = message;
      document.body.appendChild(toast);

      setTimeout(() => {
        toast.classList.add('show');
      }, 50);

      setTimeout(() => {
        toast.classList.remove('show');
        setTimeout(() => toast.remove(), 600);
      }, 4000);
    }

    function openWatchInstructionsModal() {
      const modal = document.getElementById('tsModal');
      if (modal) modal.classList.add('active');
    }

    function closeWatchInstructionsModal() {
      const modal = document.getElementById('tsModal');
      if (modal) modal.classList.remove('active');
    }

    function filterVideos() {
      const selectedPlatform = document.getElementById('platformFilter').value;
      const allVideos = document.querySelectorAll('.task-card, .task-list-item');

      allVideos.forEach(video => {
        if (selectedPlatform === 'all') {
          video.style.display = '';
        } else {
          const videoPlatform = video.getAttribute('data-platform');
          if (videoPlatform === selectedPlatform) {
            video.style.display = '';
          } else {
            video.style.display = 'none';
          }
        }
      });
    }

    function switchView(view) {
      const boxView = document.getElementById('boxView');
      const listView = document.getElementById('listView');
      const buttons = document.querySelectorAll('.view-toggle button');

      buttons.forEach(btn => btn.classList.remove('active'));

      if (view === 'box') {
        boxView.style.display = 'grid';
        listView.classList.remove('active');
        buttons[0].classList.add('active');
      } else {
        boxView.style.display = 'none';
        listView.classList.add('active');
        buttons[1].classList.add('active');
      }
    }

    function startVideo(videoId, videoUrl, videoTitle, platform, description, filePath) {
      // Check if user agreed to terms
      if (!tsAgreed) {
        showToast('Please agree to the Watch Instructions before watching videos.', 'warning');
        document.getElementById('tsModal').classList.add('active');
        return;
      }

      if (!isPremiumUser) {
        document.getElementById('freeUserModal').classList.add('active');
        return;
      }

      // Check if user clicked another video within 1 minute
      if (clickedVideos.size > 0 && !clickedVideos.has(videoId)) {
        showToast('Please wait 1 minute before watching another video', 'error');
        return;
      }

      currentVideoId = videoId;
      currentVideoTitle = videoTitle;
      currentVideoPlatform = platform;
      currentVideoUrl = videoUrl;
      currentVideoDescription = description;
      videoFilePath = filePath;
      hasWatchedFull = false; // Reset this flag for new video

      // Add to clicked videos
      clickedVideos.add(videoId);

      // Remove from clicked videos after 1 minute
      setTimeout(() => {
        clickedVideos.delete(videoId);
      }, 60000);

      // Make AJAX request to start video
      fetch('watch-earn.php', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: `ajax=1&action=start_video&video_id=${videoId}`
      })
      .then(response => response.json())
      .then(data => {
        if (data.success) {
          videoStartTime = data.start_time;

          if (videoFilePath && videoFilePath !== '') {
            // Play uploaded video file
            const videoPlayer = document.getElementById('videoPlayer');
            const videoSource = document.getElementById('videoSource');
            const videoPlayerModal = document.getElementById('videoPlayerModal');
            
            videoSource.src = videoFilePath;
            videoPlayer.load();
            videoPlayerModal.classList.add('active');
            
            videoPlayer.addEventListener('loadedmetadata', function() {
              console.log('[v0] Video loaded, duration:', videoPlayer.duration);
            });

            videoPlayer.addEventListener('seeking', function() {
              if (!hasWatchedFull && videoPlayer.currentTime > videoPlayer.dataset.maxTime) {
                console.log('[v0] Seeking prevented');
                videoPlayer.currentTime = videoPlayer.dataset.maxTime || 0;
                const overlay = document.getElementById('videoOverlayMessage');
                overlay.classList.add('show');
                setTimeout(() => overlay.classList.remove('show'), 2000);
              }
            });

            videoPlayer.addEventListener('timeupdate', function() {
              if (!hasWatchedFull) {
                videoPlayer.dataset.maxTime = videoPlayer.currentTime;
              }
            });

            videoPlayer.addEventListener('ended', function() {
              console.log('[v0] Video ended, showing popup');
              hasWatchedFull = true; // Mark video as fully watched
              showVideoDetailsPopup();
            });

            videoPlayer.play();
          } else {
            // No video file, show toast
            showToast('Video file not available. Please contact support.', 'error');
          }
        } else {
          showToast(data.message, 'error');
        }
      })
      .catch(error => {
        console.error('Error:', error);
        showToast('Failed to start video. Please try again.', 'error');
      });
    }

    function closeVideoPlayer() {
      const videoPlayer = document.getElementById('videoPlayer');
      if (videoPlayer) {
        videoPlayer.pause();
        videoPlayer.removeAttribute('src'); // Clear source
        videoPlayer.load();
      }
      document.getElementById('videoPlayerModal').classList.remove('active');
    }

    function showVideoDetailsPopup() {
      const popup = document.getElementById('videoDetailsPopup');
      const innerPopup = document.getElementById('videoDetailsPopupInner'); // Added for animation
      const titleEl = document.getElementById('popupVideoTitle');
      const descEl = document.getElementById('popupVideoDescription');
      const platformEl = document.getElementById('popupVideoPlatform');
      const linkEl = document.getElementById('watchExternalLink');

      titleEl.textContent = currentVideoTitle;
      descEl.textContent = currentVideoDescription || 'Watch this amazing video!';
      platformEl.textContent = currentVideoPlatform.charAt(0).toUpperCase() + currentVideoPlatform.slice(1);
      linkEl.href = currentVideoUrl;

      popup.style.visibility = 'visible'; // Make visible
      popup.style.opacity = '1';
      innerPopup.style.transform = 'translateY(0)'; // Animate in
    }

    function closeVideoDetailsPopup() {
      const popup = document.getElementById('videoDetailsPopup');
      const innerPopup = document.getElementById('videoDetailsPopupInner');

      innerPopup.style.transform = 'translateY(20px)'; // Animate out
      popup.style.opacity = '0';
      popup.style.visibility = 'hidden'; // Hide after animation

      // Also close the video player modal if it's open
      closeVideoPlayer();
    }

    function handleExternalWatch() {
      // Open external link
      videoWindow = window.open(currentVideoUrl, '_blank');
      
      // Close video player modal and popup
      closeVideoPlayer();
      closeVideoDetailsPopup();
      
      // Show verification modal after 1 minute
      setTimeout(() => {
        document.getElementById('verificationModal').classList.add('active');
        startCountdown();
      }, 60000);
      
      return false;
    }

    function startCountdown() {
      let seconds = 60;
      const countdownText = document.getElementById('countdownText');
      const countdownTimer = document.getElementById('countdownTimer');
      const profileLinkForm = document.getElementById('profileLinkForm');

      // Reset state if countdown is restarted
      if (countdownInterval) clearInterval(countdownInterval);

      countdownInterval = setInterval(() => {
        seconds--;
        countdownText.textContent = seconds;

        if (seconds <= 0) {
          clearInterval(countdownInterval);
          countdownTimer.style.display = 'none';
          profileLinkForm.style.display = 'block';
        }
      }, 1000);
    }

    function cancelVerification() {
      const modal = document.createElement('div');
      modal.className = 'verification-modal active';
      modal.innerHTML = `
        <div class="verification-content" style="max-width: 400px;">
          <h2>Cancel Video?</h2>
          <p>Are you sure you want to cancel? Your progress will be lost.</p>
          <div class="verification-actions">
            <button class="btn-secondary" onclick="this.closest('.verification-modal').remove()">No, Continue</button>
            <button class="btn-primary" onclick="confirmCancel()">Yes, Cancel</button>
          </div>
        </div>
      `;
      document.body.appendChild(modal);
    }

    function confirmCancel() {
      document.querySelectorAll('.verification-modal').forEach(m => m.remove());
      closeVerification();
      if (countdownInterval) {
        clearInterval(countdownInterval);
      }
      // No reload needed here, just close modals and reset state
    }

    function closeVerification() {
      const step3Active = document.getElementById('step3').classList.contains('active');

      document.getElementById('verificationModal').classList.remove('active');
      document.querySelectorAll('.verification-step').forEach(step => step.classList.remove('active'));
      document.getElementById('step1').classList.add('active');
      document.getElementById('profileLink').value = '';
      document.getElementById('step1Next').disabled = true;
      document.getElementById('countdownTimer').style.display = 'block';
      document.getElementById('profileLinkForm').style.display = 'none';
      document.getElementById('countdownText').textContent = '60';
      if (countdownInterval) {
        clearInterval(countdownInterval);
      }

      // Reload page if coming from step3 (success)
      if (step3Active) {
        location.reload();
      }
    }

    function nextStep(step) {
      document.querySelectorAll('.verification-step').forEach(s => s.classList.remove('active'));
      document.getElementById(`step${step}`).classList.add('active');
    }

    function validateProfileLink() {
      const link = document.getElementById('profileLink').value;
      const isValid = link.length > 0 && link.startsWith('http');
      document.getElementById('step1Next').disabled = !isValid;
    }

    function submitVerification() {
      const profileLink = document.getElementById('profileLink').value;

      if (!profileLink) {
        showToast('Please provide a profile link', 'error');
        return;
      }

      // Show processing step
      nextStep(2);

      fetch('watch-earn.php', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: `ajax=1&action=claim_reward&video_id=${currentVideoId}&video_title=${encodeURIComponent(currentVideoTitle)}&profile_link=${encodeURIComponent(profileLink)}`
      })
      .then(response => response.json())
      .then(data => {
        if (data.success) {
          // Show success step
          document.getElementById('rewardAmount').textContent = `₦${data.reward.toFixed(2)}`;
          nextStep(3);
        } else {
          if (data.is_free_user) {
            // Show free user modal
            closeVerification();
            document.getElementById('freeUserModal').classList.add('active');
          } else {
            showToast(data.message, 'error');
            nextStep(1);
            // Reset countdown
            document.getElementById('countdownTimer').style.display = 'block';
            document.getElementById('profileLinkForm').style.display = 'none';
            document.getElementById('countdownText').textContent = '60';
            if (countdownInterval) {
              clearInterval(countdownInterval);
            }
            startCountdown(); // Restart countdown
          }
        }
      })
      .catch(error => {
        console.error('Error:', error);
        showToast('Failed to submit verification. Please try again.', 'error');
        nextStep(1);
        // Reset countdown
        document.getElementById('countdownTimer').style.display = 'block';
        document.getElementById('profileLinkForm').style.display = 'none';
        document.getElementById('countdownText').textContent = '60';
        if (countdownInterval) {
          clearInterval(countdownInterval);
        }
        startCountdown(); // Restart countdown
      });
    }

    function closeFreeUserModal() {
      document.getElementById('freeUserModal').classList.remove('active');
    }
  </script>
</body>
</html>
