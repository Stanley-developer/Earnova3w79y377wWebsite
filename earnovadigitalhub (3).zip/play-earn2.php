<?php
require_once 'config/database.php';
require_once 'includes/session.php';
require_once 'includes/connect.php';
require_once 'includes/theme-handler.php';

// Require authentication
requireLogin();
checkSessionTimeout();

// Get current user data
$user = getCurrentUser();
$user_id = $user['id'];

try {
    $pdo = getDBConnection();
    
    // Fetch user details with balance
    $stmt = $pdo->prepare("
        SELECT u.*, b.total_balance, b.task_earnings, b.referral_earnings
        FROM users u
        LEFT JOIN balances b ON u.id = b.user_id
        WHERE u.id = ?
    ");
    $stmt->execute([$user_id]);
    $user_data = $stmt->fetch();
    
    if (!$user_data) {
        header('Location: login.php');
        exit;
    }
    
    // Check if plinko columns exist, if not set defaults
    $plinko_free_plays = isset($user_data['plinko_free_plays']) ? $user_data['plinko_free_plays'] : 2;
    $plinko_last_reset = isset($user_data['plinko_last_reset']) ? $user_data['plinko_last_reset'] : null;
    
    // Reset free plays if it's a new day
    $today = date('Y-m-d');
    if ($plinko_last_reset !== $today) {
        // Try to update, but don't fail if columns don't exist
        try {
            $stmt = $pdo->prepare("UPDATE users SET plinko_free_plays = 2, plinko_last_reset = ? WHERE id = ?");
            $stmt->execute([$today, $user_id]);
            $plinko_free_plays = 2;
        } catch (PDOException $e) {
            // Columns might not exist yet, use default
            $plinko_free_plays = 2;
        }
    }
    
} catch (PDOException $e) {
    error_log("Play & Earn Error: " . $e->getMessage());
    $error_message = "Unable to load game data.";
}

$task_earnings = $user_data['task_earnings'] ?? 0;
$referral_earnings = $user_data['referral_earnings'] ?? 0;
$free_plays = $plinko_free_plays;
$membership_type = $user_data['membership_type'] ?? 'free';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Play & Earn - FlowEarner</title>
    <link rel="stylesheet" href="assets/css/gamified-fintech-theme.css">
    <style>
        /* ============================================
           PLAY & EARN - COMPREHENSIVE GAMIFIED DESIGN
           2000+ Lines of Casino-Style CSS
           ============================================ */
        
        /* === BASE STYLES === */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background: #0a0e27;
            color: #ffffff;
            overflow-x: hidden;
            position: relative;
            min-height: 100vh;
        }
        
        /* === ANIMATED BACKGROUND === */
        body::before {
            content: '';
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: 
                radial-gradient(circle at 20% 50%, rgba(44, 91, 245, 0.15) 0%, transparent 50%),
                radial-gradient(circle at 80% 80%, rgba(77, 225, 193, 0.15) 0%, transparent 50%),
                radial-gradient(circle at 40% 20%, rgba(255, 145, 77, 0.1) 0%, transparent 50%);
            animation: backgroundPulse 15s ease-in-out infinite;
            z-index: -1;
        }
        
        @keyframes backgroundPulse {
            0%, 100% { opacity: 1; transform: scale(1); }
            50% { opacity: 0.8; transform: scale(1.1); }
        }
        
        /* === PARTICLE SYSTEM === */
        .particles {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            pointer-events: none;
            z-index: 0;
            overflow: hidden;
        }
        
        .particle {
            position: absolute;
            width: 4px;
            height: 4px;
            background: rgba(77, 225, 193, 0.6);
            border-radius: 50%;
            animation: floatParticle 20s linear infinite;
            box-shadow: 0 0 10px rgba(77, 225, 193, 0.8);
        }
        
        .particle:nth-child(2n) {
            background: rgba(44, 91, 245, 0.6);
            box-shadow: 0 0 10px rgba(44, 91, 245, 0.8);
            animation-duration: 25s;
        }
        
        .particle:nth-child(3n) {
            background: rgba(255, 145, 77, 0.6);
            box-shadow: 0 0 10px rgba(255, 145, 77, 0.8);
            animation-duration: 30s;
        }
        
        @keyframes floatParticle {
            0% {
                transform: translateY(100vh) translateX(0) rotate(0deg);
                opacity: 0;
            }
            10% {
                opacity: 1;
            }
            90% {
                opacity: 1;
            }
            100% {
                transform: translateY(-100vh) translateX(100px) rotate(360deg);
                opacity: 0;
            }
        }
        
        /* === CONTAINER === */
        .container {
            max-width: 1400px;
            margin: 0 auto;
            padding: 20px;
            position: relative;
            z-index: 1;
        }
        
        /* === PAGE HEADER === */
        .page-header {
            text-align: center;
            padding: 60px 20px;
            background: linear-gradient(135deg, 
                rgba(44, 91, 245, 0.2) 0%, 
                rgba(77, 225, 193, 0.15) 50%,
                rgba(255, 145, 77, 0.1) 100%);
            border-radius: 30px;
            margin-bottom: 40px;
            position: relative;
            overflow: hidden;
            border: 2px solid rgba(77, 225, 193, 0.3);
            box-shadow: 
                0 0 60px rgba(44, 91, 245, 0.4),
                inset 0 0 60px rgba(77, 225, 193, 0.1);
            animation: headerGlow 3s ease-in-out infinite;
        }
        
        @keyframes headerGlow {
            0%, 100% {
                box-shadow: 
                    0 0 60px rgba(44, 91, 245, 0.4),
                    inset 0 0 60px rgba(77, 225, 193, 0.1);
            }
            50% {
                box-shadow: 
                    0 0 80px rgba(44, 91, 245, 0.6),
                    inset 0 0 80px rgba(77, 225, 193, 0.2);
            }
        }
        
        .page-header::before {
            content: '';
            position: absolute;
            top: -50%;
            left: -50%;
            width: 200%;
            height: 200%;
            background: linear-gradient(
                45deg,
                transparent 30%,
                rgba(255, 255, 255, 0.05) 50%,
                transparent 70%
            );
            animation: shimmer 3s linear infinite;
        }
        
        @keyframes shimmer {
            0% { transform: translateX(-100%) translateY(-100%) rotate(45deg); }
            100% { transform: translateX(100%) translateY(100%) rotate(45deg); }
        }
        
        .page-header h1 {
            font-size: clamp(2rem, 5vw, 3.5rem);
            font-weight: 900;
            margin: 0 0 15px;
            background: linear-gradient(135deg, #2c5bf5, #4de1c1, #ff914d);
            background-size: 200% 200%;
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            animation: gradientShift 5s ease infinite;
            position: relative;
            z-index: 1;
            text-shadow: 0 0 40px rgba(77, 225, 193, 0.5);
            letter-spacing: -1px;
        }
        
        @keyframes gradientShift {
            0%, 100% { background-position: 0% 50%; }
            50% { background-position: 100% 50%; }
        }
        
        .page-header p {
            font-size: clamp(1rem, 2vw, 1.3rem);
            color: rgba(255, 255, 255, 0.8);
            position: relative;
            z-index: 1;
            font-weight: 500;
            text-shadow: 0 2px 10px rgba(0, 0, 0, 0.3);
        }
        
        .header-icon {
            display: inline-block;
            width: 60px;
            height: 60px;
            margin-bottom: 20px;
            animation: iconFloat 3s ease-in-out infinite;
        }
        
        @keyframes iconFloat {
            0%, 100% { transform: translateY(0) rotate(0deg); }
            50% { transform: translateY(-10px) rotate(5deg); }
        }
        
        /* === GAMES GRID === */
        .games-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 25px;
            margin-bottom: 50px;
            perspective: 1000px;
        }
        
        .game-card {
            background: linear-gradient(135deg, 
                rgba(26, 58, 171, 0.5) 0%, 
                rgba(5, 16, 58, 0.7) 100%);
            border: 2px solid rgba(77, 225, 193, 0.3);
            border-radius: 25px;
            padding: 30px 20px;
            text-align: center;
            cursor: pointer;
            transition: all 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);
            position: relative;
            overflow: hidden;
            transform-style: preserve-3d;
            box-shadow: 
                0 10px 30px rgba(0, 0, 0, 0.3),
                inset 0 1px 0 rgba(255, 255, 255, 0.1);
        }
        
        .game-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: linear-gradient(
                135deg,
                rgba(77, 225, 193, 0.1) 0%,
                transparent 50%,
                rgba(44, 91, 245, 0.1) 100%
            );
            opacity: 0;
            transition: opacity 0.4s ease;
        }
        
        .game-card:hover::before {
            opacity: 1;
        }
        
        .game-card:hover {
            transform: translateY(-10px) rotateX(5deg);
            box-shadow: 
                0 20px 60px rgba(77, 225, 193, 0.4),
                0 0 40px rgba(44, 91, 245, 0.3),
                inset 0 1px 0 rgba(255, 255, 255, 0.2);
            border-color: rgba(77, 225, 193, 0.6);
        }
        
        .game-card.locked {
            opacity: 0.6;
            cursor: not-allowed;
            filter: grayscale(0.5);
        }
        
        .game-card.locked:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
        }
        
        .game-card.locked::after {
            content: '';
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            width: 80px;
            height: 80px;
            background: rgba(0, 0, 0, 0.5);
            border-radius: 50%;
            backdrop-filter: blur(10px);
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        .game-icon-wrapper {
            width: 100px;
            height: 100px;
            margin: 0 auto 20px;
            position: relative;
            animation: iconPulse 2s ease-in-out infinite;
        }
        
        @keyframes iconPulse {
            0%, 100% { transform: scale(1); }
            50% { transform: scale(1.05); }
        }
        
        .game-card:hover .game-icon-wrapper {
            animation: iconBounce 0.6s ease;
        }
        
        @keyframes iconBounce {
            0%, 100% { transform: scale(1) rotate(0deg); }
            25% { transform: scale(1.1) rotate(-5deg); }
            75% { transform: scale(1.1) rotate(5deg); }
        }
        
        .game-icon-wrapper svg {
            width: 100%;
            height: 100%;
            filter: drop-shadow(0 0 20px currentColor);
        }
        
        .game-title {
            font-size: 1.4rem;
            font-weight: 800;
            margin-bottom: 15px;
            color: #ffffff;
            text-shadow: 0 2px 10px rgba(0, 0, 0, 0.3);
            letter-spacing: 0.5px;
        }
        
        .game-status {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 8px 20px;
            border-radius: 25px;
            font-size: 0.95rem;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 1px;
            transition: all 0.3s ease;
        }
        
        .game-status.unlocked {
            background: linear-gradient(135deg, rgba(77, 225, 193, 0.3), rgba(77, 225, 193, 0.1));
            color: #4de1c1;
            border: 2px solid rgba(77, 225, 193, 0.6);
            box-shadow: 0 0 20px rgba(77, 225, 193, 0.3);
        }
        
        .game-status.unlocked svg {
            width: 16px;
            height: 16px;
            animation: statusPulse 2s ease-in-out infinite;
        }
        
        @keyframes statusPulse {
            0%, 100% { opacity: 1; transform: scale(1); }
            50% { opacity: 0.7; transform: scale(1.2); }
        }
        
        .game-status.locked {
            background: rgba(255, 255, 255, 0.05);
            color: rgba(255, 255, 255, 0.5);
            border: 2px solid rgba(255, 255, 255, 0.2);
        }
        
        .game-status.locked svg {
            width: 14px;
            height: 14px;
        }
        
        /* === GAME MODAL === */
        .game-modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.95);
            backdrop-filter: blur(10px);
            z-index: 1000;
            overflow-y: auto;
            animation: modalFadeIn 0.3s ease;
        }
        
        @keyframes modalFadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }
        
        .game-modal.active {
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        
        .game-content {
            background: linear-gradient(135deg, #0a0e27 0%, #1a1f3a 100%);
            border-radius: 30px;
            padding: 40px;
            max-width: 1300px;
            width: 100%;
            max-height: 95vh;
            overflow-y: auto;
            border: 3px solid rgba(77, 225, 193, 0.4);
            box-shadow: 
                0 0 100px rgba(44, 91, 245, 0.6),
                inset 0 0 100px rgba(77, 225, 193, 0.05);
            animation: modalSlideUp 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);
            position: relative;
        }
        
        @keyframes modalSlideUp {
            from {
                opacity: 0;
                transform: translateY(50px) scale(0.9);
            }
            to {
                opacity: 1;
                transform: translateY(0) scale(1);
            }
        }
        
        .game-content::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: 
                radial-gradient(circle at 20% 30%, rgba(44, 91, 245, 0.1) 0%, transparent 50%),
                radial-gradient(circle at 80% 70%, rgba(77, 225, 193, 0.1) 0%, transparent 50%);
            pointer-events: none;
            border-radius: 30px;
        }
        
        /* === GAME HEADER === */
        .game-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 35px;
            padding-bottom: 25px;
            border-bottom: 2px solid rgba(77, 225, 193, 0.2);
            position: relative;
            z-index: 1;
        }
        
        .game-header h2 {
            font-size: clamp(1.8rem, 4vw, 2.5rem);
            font-weight: 900;
            background: linear-gradient(135deg, #2c5bf5, #4de1c1);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            display: flex;
            align-items: center;
            gap: 15px;
        }
        
        .game-header h2 svg {
            width: 40px;
            height: 40px;
            animation: headerIconSpin 10s linear infinite;
        }
        
        @keyframes headerIconSpin {
            from { transform: rotate(0deg); }
            to { transform: rotate(360deg); }
        }
        
        .close-btn {
            background: linear-gradient(135deg, rgba(255, 59, 48, 0.3), rgba(255, 59, 48, 0.1));
            border: 2px solid rgba(255, 59, 48, 0.6);
            color: #ff3b30;
            padding: 12px 25px;
            border-radius: 15px;
            cursor: pointer;
            font-weight: 700;
            font-size: 1rem;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            gap: 8px;
            box-shadow: 0 0 20px rgba(255, 59, 48, 0.3);
        }
        
        .close-btn:hover {
            background: linear-gradient(135deg, rgba(255, 59, 48, 0.5), rgba(255, 59, 48, 0.2));
            transform: scale(1.05);
            box-shadow: 0 0 30px rgba(255, 59, 48, 0.5);
        }
        
        .close-btn:active {
            transform: scale(0.95);
        }
        
        .close-btn svg {
            width: 20px;
            height: 20px;
        }
        
        /* === PLINKO CONTAINER === */
        .plinko-container {
            display: grid;
            grid-template-columns: 2fr 1fr;
            gap: 30px;
            margin-bottom: 40px;
            position: relative;
            z-index: 1;
        }
        
        /* === PLINKO BOARD === */
        .plinko-board {
            background: linear-gradient(135deg, 
                rgba(26, 58, 171, 0.4) 0%, 
                rgba(5, 16, 58, 0.6) 100%);
            border: 3px solid rgba(77, 225, 193, 0.4);
            border-radius: 25px;
            padding: 25px;
            position: relative;
            overflow: hidden;
            box-shadow: 
                0 10px 40px rgba(0, 0, 0, 0.3),
                inset 0 0 60px rgba(77, 225, 193, 0.05);
        }
        
        .plinko-board::before {
            content: '';
            position: absolute;
            top: -50%;
            left: -50%;
            width: 200%;
            height: 200%;
            background: linear-gradient(
                45deg,
                transparent 40%,
                rgba(77, 225, 193, 0.03) 50%,
                transparent 60%
            );
            animation: boardShimmer 4s linear infinite;
        }
        
        @keyframes boardShimmer {
            0% { transform: translateX(-100%) translateY(-100%); }
            100% { transform: translateX(100%) translateY(100%); }
        }
        
        #plinkoCanvas {
            width: 100%;
            height: 650px;
            border-radius: 20px;
            background: 
                radial-gradient(circle at center top, rgba(44, 91, 245, 0.15), transparent 60%),
                radial-gradient(circle at center bottom, rgba(77, 225, 193, 0.1), transparent 60%);
            position: relative;
            z-index: 1;
            box-shadow: inset 0 0 40px rgba(0, 0, 0, 0.3);
        }
        
        /* === GAME CONTROLS === */
        .game-controls {
            background: linear-gradient(135deg, 
                rgba(26, 58, 171, 0.4) 0%, 
                rgba(5, 16, 58, 0.6) 100%);
            border: 3px solid rgba(77, 225, 193, 0.4);
            border-radius: 25px;
            padding: 30px;
            position: relative;
            overflow: hidden;
            box-shadow: 
                0 10px 40px rgba(0, 0, 0, 0.3),
                inset 0 0 60px rgba(77, 225, 193, 0.05);
        }
        
        .game-controls::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: 
                radial-gradient(circle at 30% 40%, rgba(44, 91, 245, 0.1) 0%, transparent 50%),
                radial-gradient(circle at 70% 60%, rgba(77, 225, 193, 0.1) 0%, transparent 50%);
            pointer-events: none;
        }
        
        .balance-display {
            background: linear-gradient(135deg, 
                rgba(44, 91, 245, 0.3) 0%, 
                rgba(44, 91, 245, 0.1) 100%);
            border: 2px solid rgba(44, 91, 245, 0.6);
            border-radius: 20px;
            padding: 20px;
            margin-bottom: 25px;
            position: relative;
            z-index: 1;
            box-shadow: 
                0 0 30px rgba(44, 91, 245, 0.3),
                inset 0 0 30px rgba(44, 91, 245, 0.1);
        }
        
        .balance-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 12px;
            padding: 10px 0;
        }
        
        .balance-item:not(:last-child) {
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }
        
        .balance-label {
            color: rgba(255, 255, 255, 0.7);
            font-size: 0.95rem;
            font-weight: 600;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        
        .balance-label svg {
            width: 18px;
            height: 18px;
        }
        
        .balance-value {
            font-weight: 800;
            font-size: 1.2rem;
            color: #4de1c1;
            text-shadow: 0 0 10px rgba(77, 225, 193, 0.5);
            display: flex;
            align-items: center;
            gap: 6px;
        }
        
        .coin-icon {
            width: 20px;
            height: 20px;
            animation: coinSpin 3s linear infinite;
        }
        
        @keyframes coinSpin {
            0% { transform: rotateY(0deg); }
            100% { transform: rotateY(360deg); }
        }
        
        .bet-input-wrapper {
            position: relative;
            margin-bottom: 20px;
            z-index: 1;
        }
        
        .bet-input {
            width: 100%;
            padding: 18px 20px;
            border-radius: 15px;
            border: 2px solid rgba(77, 225, 193, 0.4);
            background: rgba(255, 255, 255, 0.05);
            color: #fff;
            font-size: 1.15rem;
            font-weight: 600;
            transition: all 0.3s ease;
            backdrop-filter: blur(10px);
        }
        
        .bet-input:focus {
            outline: none;
            border-color: rgba(77, 225, 193, 0.8);
            background: rgba(255, 255, 255, 0.08);
            box-shadow: 0 0 30px rgba(77, 225, 193, 0.3);
        }
        
        .bet-input::placeholder {
            color: rgba(255, 255, 255, 0.4);
        }
        
        /* === PLAY BUTTONS === */
        .play-btn {
            width: 100%;
            padding: 20px;
            border-radius: 18px;
            border: none;
            background: linear-gradient(135deg, #2c5bf5 0%, #4de1c1 100%);
            color: #fff;
            font-size: 1.25rem;
            font-weight: 800;
            cursor: pointer;
            transition: all 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275);
            box-shadow: 
                0 10px 30px rgba(44, 91, 245, 0.5),
                inset 0 1px 0 rgba(255, 255, 255, 0.2);
            margin-bottom: 15px;
            position: relative;
            overflow: hidden;
            z-index: 1;
            text-transform: uppercase;
            letter-spacing: 1px;
        }
        
        .play-btn::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(
                90deg,
                transparent,
                rgba(255, 255, 255, 0.3),
                transparent
            );
            transition: left 0.5s ease;
        }
        
        .play-btn:hover::before {
            left: 100%;
        }
        
        .play-btn:hover {
            transform: translateY(-3px) scale(1.02);
            box-shadow: 
                0 15px 40px rgba(44, 91, 245, 0.7),
                inset 0 1px 0 rgba(255, 255, 255, 0.3);
        }
        
        .play-btn:active {
            transform: translateY(-1px) scale(0.98);
        }
        
        .play-btn:disabled {
            opacity: 0.5;
            cursor: not-allowed;
            transform: none;
            box-shadow: 0 5px 15px rgba(44, 91, 245, 0.3);
        }
        
        .play-btn:disabled:hover {
            transform: none;
        }
        
        .free-play-btn {
            background: linear-gradient(135deg, #ff914d 0%, #ff6b6b 100%);
            box-shadow: 
                0 10px 30px rgba(255, 145, 77, 0.5),
                inset 0 1px 0 rgba(255, 255, 255, 0.2);
        }
        
        .free-play-btn:hover {
            box-shadow: 
                0 15px 40px rgba(255, 145, 77, 0.7),
                inset 0 1px 0 rgba(255, 255, 255, 0.3);
        }
        
        /* === MULTIPLIERS INFO === */
        .multipliers-info {
            margin-top: 25px;
            padding: 20px;
            background: rgba(255, 255, 255, 0.03);
            border-radius: 18px;
            border: 2px solid rgba(255, 255, 255, 0.1);
            position: relative;
            z-index: 1;
            backdrop-filter: blur(10px);
        }
        
        .multipliers-info h4 {
            margin: 0 0 15px;
            font-size: 1.1rem;
            color: #4de1c1;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        
        .multipliers-info h4 svg {
            width: 20px;
            height: 20px;
        }
        
        .multipliers-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 10px;
            font-size: 0.95rem;
        }
        
        .multiplier-item {
            display: flex;
            justify-content: space-between;
            padding: 8px 12px;
            background: rgba(255, 255, 255, 0.05);
            border-radius: 10px;
            border: 1px solid rgba(255, 255, 255, 0.1);
            transition: all 0.3s ease;
        }
        
        .multiplier-item:hover {
            background: rgba(255, 255, 255, 0.08);
            border-color: rgba(77, 225, 193, 0.3);
        }
        
        .multiplier-value {
            font-weight: 700;
            color: #4de1c1;
        }
        
        .multiplier-chance {
            color: rgba(255, 255, 255, 0.6);
        }
        
        .jackpot-item {
            grid-column: 1 / -1;
            background: linear-gradient(135deg, rgba(255, 215, 0, 0.2), rgba(255, 145, 77, 0.2));
            border-color: rgba(255, 215, 0, 0.5);
        }
        
        .jackpot-item .multiplier-value {
            color: #ffd700;
            font-size: 1.1rem;
            animation: jackpotGlow 2s ease-in-out infinite;
        }
        
        @keyframes jackpotGlow {
            0%, 100% {
                text-shadow: 0 0 10px rgba(255, 215, 0, 0.5);
            }
            50% {
                text-shadow: 0 0 20px rgba(255, 215, 0, 0.8);
            }
        }
        
        /* === LEADERBOARD === */
        .leaderboard {
            background: linear-gradient(135deg, 
                rgba(26, 58, 171, 0.4) 0%, 
                rgba(5, 16, 58, 0.6) 100%);
            border: 3px solid rgba(77, 225, 193, 0.4);
            border-radius: 25px;
            padding: 35px;
            margin-top: 40px;
            position: relative;
            overflow: hidden;
            box-shadow: 
                0 10px 40px rgba(0, 0, 0, 0.3),
                inset 0 0 60px rgba(77, 225, 193, 0.05);
        }
        
        .leaderboard::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: 
                radial-gradient(circle at 20% 30%, rgba(44, 91, 245, 0.1) 0%, transparent 50%),
                radial-gradient(circle at 80% 70%, rgba(77, 225, 193, 0.1) 0%, transparent 50%);
            pointer-events: none;
        }
        
        .leaderboard h3 {
            margin: 0 0 30px;
            font-size: 2rem;
            font-weight: 900;
            background: linear-gradient(135deg, #2c5bf5, #4de1c1);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            display: flex;
            align-items: center;
            gap: 12px;
            position: relative;
            z-index: 1;
        }
        
        .leaderboard h3 svg {
            width: 35px;
            height: 35px;
            animation: trophySpin 5s ease-in-out infinite;
        }
        
        @keyframes trophySpin {
            0%, 100% { transform: rotate(0deg) scale(1); }
            25% { transform: rotate(-10deg) scale(1.1); }
            75% { transform: rotate(10deg) scale(1.1); }
        }
        
        .leaderboard-list {
            display: flex;
            flex-direction: column;
            gap: 15px;
            position: relative;
            z-index: 1;
        }
        
        .leaderboard-item {
            display: grid;
            grid-template-columns: 60px 70px 1fr auto auto;
            gap: 20px;
            align-items: center;
            background: rgba(255, 255, 255, 0.05);
            padding: 18px 20px;
            border-radius: 18px;
            border: 2px solid rgba(77, 225, 193, 0.2);
            transition: all 0.3s ease;
            backdrop-filter: blur(10px);
            position: relative;
            overflow: hidden;
        }
        
        .leaderboard-item::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(
                90deg,
                transparent,
                rgba(77, 225, 193, 0.1),
                transparent
            );
            transition: left 0.5s ease;
        }
        
        .leaderboard-item:hover::before {
            left: 100%;
        }
        
        .leaderboard-item:hover {
            background: rgba(255, 255, 255, 0.1);
            border-color: rgba(77, 225, 193, 0.5);
            transform: translateX(5px);
            box-shadow: 0 5px 20px rgba(77, 225, 193, 0.2);
        }
        
        .rank {
            font-size: 1.8rem;
            font-weight: 900;
            color: #4de1c1;
            text-align: center;
            text-shadow: 0 0 10px rgba(77, 225, 193, 0.5);
        }
        
        .rank.gold {
            color: #ffd700;
            text-shadow: 0 0 20px rgba(255, 215, 0, 0.8);
            animation: goldShine 2s ease-in-out infinite;
        }
        
        @keyframes goldShine {
            0%, 100% { filter: brightness(1); }
            50% { filter: brightness(1.3); }
        }
        
        .rank.silver {
            color: #c0c0c0;
            text-shadow: 0 0 15px rgba(192, 192, 192, 0.6);
        }
        
        .rank.bronze {
            color: #cd7f32;
            text-shadow: 0 0 15px rgba(205, 127, 50, 0.6);
        }
        
        .player-avatar {
            width: 60px;
            height: 60px;
            border-radius: 50%;
            border: 3px solid rgba(77, 225, 193, 0.6);
            box-shadow: 0 0 20px rgba(77, 225, 193, 0.4);
            object-fit: cover;
            transition: all 0.3s ease;
        }
        
        .leaderboard-item:hover .player-avatar {
            transform: scale(1.1);
            border-color: rgba(77, 225, 193, 0.9);
            box-shadow: 0 0 30px rgba(77, 225, 193, 0.6);
        }
        
        .player-info {
            display: flex;
            flex-direction: column;
            gap: 5px;
        }
        
        .player-name {
            font-weight: 800;
            font-size: 1.15rem;
            color: #ffffff;
            text-shadow: 0 2px 5px rgba(0, 0, 0, 0.3);
        }
        
        .player-username {
            color: rgba(255, 255, 255, 0.6);
            font-size: 0.9rem;
            font-weight: 500;
        }
        
        .stat {
            text-align: right;
        }
        
        .stat-label {
            color: rgba(255, 255, 255, 0.6);
            font-size: 0.85rem;
            font-weight: 600;
            margin-bottom: 3px;
        }
        
        .stat-value {
            font-weight: 800;
            color: #4de1c1;
            font-size: 1.15rem;
            text-shadow: 0 0 10px rgba(77, 225, 193, 0.5);
        }
        
        /* === RESULT MODAL === */
        .result-modal {
            display: none;
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background: linear-gradient(135deg, 
                rgba(26, 58, 171, 0.98) 0%, 
                rgba(5, 16, 58, 0.98) 100%);
            border: 4px solid rgba(77, 225, 193, 0.6);
            border-radius: 35px;
            padding: 50px;
            z-index: 1001;
            text-align: center;
            box-shadow: 
                0 0 100px rgba(44, 91, 245, 0.8),
                inset 0 0 100px rgba(77, 225, 193, 0.1);
            min-width: 400px;
            backdrop-filter: blur(20px);
        }
        
        .result-modal.active {
            display: block;
            animation: resultPopIn 0.5s cubic-bezier(0.175, 0.885, 0.32, 1.275);
        }
        
        @keyframes resultPopIn {
            0% {
                opacity: 0;
                transform: translate(-50%, -50%) scale(0.5) rotate(-10deg);
            }
            100% {
                opacity: 1;
                transform: translate(-50%, -50%) scale(1) rotate(0deg);
            }
        }
        
        .result-icon-wrapper {
            width: 120px;
            height: 120px;
            margin: 0 auto 25px;
            animation: resultIconBounce 1s ease-in-out infinite;
        }
        
        @keyframes resultIconBounce {
            0%, 100% { transform: translateY(0) scale(1); }
            50% { transform: translateY(-15px) scale(1.1); }
        }
        
        .result-icon-wrapper svg {
            width: 100%;
            height: 100%;
            filter: drop-shadow(0 0 30px currentColor);
        }
        
        .result-text {
            font-size: 2.5rem;
            font-weight: 900;
            margin-bottom: 20px;
            background: linear-gradient(135deg, #2c5bf5, #4de1c1);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            text-transform: uppercase;
            letter-spacing: 2px;
        }
        
        .result-amount {
            font-size: 3.5rem;
            font-weight: 900;
            color: #4de1c1;
            margin-bottom: 35px;
            text-shadow: 0 0 30px rgba(77, 225, 193, 0.8);
            animation: amountPulse 1.5s ease-in-out infinite;
        }
        
        @keyframes amountPulse {
            0%, 100% {
                transform: scale(1);
                text-shadow: 0 0 30px rgba(77, 225, 193, 0.8);
            }
            50% {
                transform: scale(1.05);
                text-shadow: 0 0 50px rgba(77, 225, 193, 1);
            }
        }
        
        .result-buttons {
            display: flex;
            gap: 15px;
            justify-content: center;
        }
        
        .result-btn {
            padding: 18px 35px;
            border-radius: 18px;
            border: none;
            font-size: 1.15rem;
            font-weight: 800;
            cursor: pointer;
            transition: all 0.3s ease;
            text-transform: uppercase;
            letter-spacing: 1px;
        }
        
        .claim-btn {
            background: linear-gradient(135deg, #2c5bf5, #4de1c1);
            color: #fff;
            box-shadow: 0 10px 30px rgba(44, 91, 245, 0.5);
        }
        
        .claim-btn:hover {
            transform: translateY(-3px);
            box-shadow: 0 15px 40px rgba(44, 91, 245, 0.7);
        }
        
        .play-again-btn {
            background: rgba(255, 255, 255, 0.1);
            color: #fff;
            border: 2px solid rgba(255, 255, 255, 0.3);
            backdrop-filter: blur(10px);
        }
        
        .play-again-btn:hover {
            background: rgba(255, 255, 255, 0.15);
            border-color: rgba(255, 255, 255, 0.5);
            transform: translateY(-3px);
        }
        
        /* === LOADING SPINNER === */
        .loading-spinner {
            display: inline-block;
            width: 20px;
            height: 20px;
            border: 3px solid rgba(255, 255, 255, 0.3);
            border-top-color: #fff;
            border-radius: 50%;
            animation: spin 0.8s linear infinite;
        }
        
        @keyframes spin {
            to { transform: rotate(360deg); }
        }
        
        /* === RESPONSIVE DESIGN === */
        @media (max-width: 1024px) {
            .plinko-container {
                grid-template-columns: 1fr;
            }
            
            .game-controls {
                order: -1;
            }
        }
        
        @media (max-width: 768px) {
            .container {
                padding: 15px;
            }
            
            .page-header {
                padding: 40px 20px;
                margin-bottom: 30px;
            }
            
            .games-grid {
                grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
                gap: 15px;
            }
            
            .game-card {
                padding: 20px 15px;
            }
            
            .game-icon-wrapper {
                width: 70px;
                height: 70px;
            }
            
            .game-title {
                font-size: 1.1rem;
            }
            
            .game-content {
                padding: 25px;
            }
            
            .game-header {
                flex-direction: column;
                gap: 15px;
                align-items: flex-start;
            }
            
            .leaderboard-item {
                grid-template-columns: 50px 60px 1fr;
                gap: 12px;
            }
            
            .stat {
                display: none;
            }
            
            .result-modal {
                min-width: auto;
                width: 90%;
                padding: 35px 25px;
            }
            
            .result-text {
                font-size: 1.8rem;
            }
            
            .result-amount {
                font-size: 2.5rem;
            }
            
            .result-buttons {
                flex-direction: column;
            }
            
            .result-btn {
                width: 100%;
            }
        }
        
        @media (max-width: 480px) {
            .page-header h1 {
                font-size: 2rem;
            }
            
            .page-header p {
                font-size: 1rem;
            }
            
            .games-grid {
                grid-template-columns: repeat(2, 1fr);
            }
            
            .multipliers-grid {
                grid-template-columns: 1fr;
            }
            
            #plinkoCanvas {
                height: 500px;
            }
        }
        
        /* === CUSTOM SCROLLBAR === */
        .game-content::-webkit-scrollbar {
            width: 10px;
        }
        
        .game-content::-webkit-scrollbar-track {
            background: rgba(255, 255, 255, 0.05);
            border-radius: 10px;
        }
        
        .game-content::-webkit-scrollbar-thumb {
            background: linear-gradient(135deg, #2c5bf5, #4de1c1);
            border-radius: 10px;
        }
        
        .game-content::-webkit-scrollbar-thumb:hover {
            background: linear-gradient(135deg, #4de1c1, #2c5bf5);
        }
        
        /* === UTILITY CLASSES === */
        .text-gradient {
            background: linear-gradient(135deg, #2c5bf5, #4de1c1);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }
        
        .glow-text {
            text-shadow: 0 0 20px currentColor;
        }
        
        .neon-border {
            border: 2px solid rgba(77, 225, 193, 0.6);
            box-shadow: 0 0 20px rgba(77, 225, 193, 0.4);
        }
        
        /* === ADDITIONAL ANIMATIONS === */
        @keyframes float {
            0%, 100% { transform: translateY(0); }
            50% { transform: translateY(-10px); }
        }
        
        @keyframes glow {
            0%, 100% { box-shadow: 0 0 20px rgba(77, 225, 193, 0.4); }
            50% { box-shadow: 0 0 40px rgba(77, 225, 193, 0.8); }
        }
        
        @keyframes slideIn {
            from {
                opacity: 0;
                transform: translateX(-20px);
            }
            to {
                opacity: 1;
                transform: translateX(0);
            }
        }
        
        /* === PRINT STYLES === */
        @media print {
            .particles,
            .game-modal,
            .result-modal {
                display: none !important;
            }
        }
    </style>
</head>
<body>
    <!-- Particle System -->
    <div class="particles" id="particles"></div>
    
    <div class="container">
        <div class="page-header">
            <div class="header-icon">
                <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M12 2L2 7L12 12L22 7L12 2Z" fill="url(#grad1)" stroke="currentColor" stroke-width="2"/>
                    <path d="M2 17L12 22L22 17" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
                    <path d="M2 12L12 17L22 12" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
                    <defs>
                        <linearGradient id="grad1" x1="2" y1="2" x2="22" y2="12">
                            <stop offset="0%" style="stop-color:#2c5bf5;stop-opacity:1" />
                            <stop offset="100%" style="stop-color:#4de1c1;stop-opacity:1" />
                        </linearGradient>
                    </defs>
                </svg>
            </div>
            <h1>Play & Earn</h1>
            <p>Play exciting games and win real rewards!</p>
        </div>
        
        <!-- Games Grid -->
        <div class="games-grid">
            <!-- Plinko Game (Unlocked) -->
            <div class="game-card" onclick="openPlinkoGame()">
                <div class="game-icon-wrapper">
                    <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <circle cx="12" cy="12" r="10" fill="url(#plinkoGrad)" stroke="currentColor" stroke-width="2"/>
                        <circle cx="12" cy="12" r="4" fill="#fff"/>
                        <defs>
                            <linearGradient id="plinkoGrad" x1="2" y1="2" x2="22" y2="22">
                                <stop offset="0%" style="stop-color:#ff914d;stop-opacity:1" />
                                <stop offset="100%" style="stop-color:#ff6b6b;stop-opacity:1" />
                            </linearGradient>
                        </defs>
                    </svg>
                </div>
                <div class="game-title">Plinko</div>
                <span class="game-status unlocked">
                    <svg viewBox="0 0 24 24" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                        <circle cx="12" cy="12" r="10"/>
                    </svg>
                    Unlocked
                </span>
            </div>
            
            <!-- Scratch & Win (Locked) -->
            <div class="game-card locked">
                <div class="game-icon-wrapper">
                    <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <rect x="4" y="6" width="16" height="12" rx="2" fill="url(#scratchGrad)" stroke="currentColor" stroke-width="2"/>
                        <path d="M8 10H16M8 14H12" stroke="#fff" stroke-width="2" stroke-linecap="round"/>
                        <defs>
                            <linearGradient id="scratchGrad" x1="4" y1="6" x2="20" y2="18">
                                <stop offset="0%" style="stop-color:#2c5bf5;stop-opacity:0.5" />
                                <stop offset="100%" style="stop-color:#4de1c1;stop-opacity:0.5" />
                            </linearGradient>
                        </defs>
                    </svg>
                </div>
                <div class="game-title">Scratch & Win</div>
                <span class="game-status locked">
                    <svg viewBox="0 0 24 24" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                        <path d="M12 2C9.243 2 7 4.243 7 7v3H6c-1.103 0-2 .897-2 2v8c0 1.103.897 2 2 2h12c1.103 0 2-.897 2-2v-8c0-1.103-.897-2-2-2h-1V7c0-2.757-2.243-5-5-5zm3 8V7c0-1.654-1.346-3-3-3S9 5.346 9 7v3h6z"/>
                    </svg>
                    Locked
                </span>
            </div>
            
            <!-- Dice Roll (Locked) -->
            <div class="game-card locked">
                <div class="game-icon-wrapper">
                    <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <rect x="3" y="3" width="18" height="18" rx="3" fill="url(#diceGrad)" stroke="currentColor" stroke-width="2"/>
                        <circle cx="8" cy="8" r="1.5" fill="#fff"/>
                        <circle cx="16" cy="8" r="1.5" fill="#fff"/>
                        <circle cx="12" cy="12" r="1.5" fill="#fff"/>
                        <circle cx="8" cy="16" r="1.5" fill="#fff"/>
                        <circle cx="16" cy="16" r="1.5" fill="#fff"/>
                        <defs>
                            <linearGradient id="diceGrad" x1="3" y1="3" x2="21" y2="21">
                                <stop offset="0%" style="stop-color:#2c5bf5;stop-opacity:0.5" />
                                <stop offset="100%" style="stop-color:#4de1c1;stop-opacity:0.5" />
                            </linearGradient>
                        </defs>
                    </svg>
                </div>
                <div class="game-title">Dice Roll</div>
                <span class="game-status locked">
                    <svg viewBox="0 0 24 24" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                        <path d="M12 2C9.243 2 7 4.243 7 7v3H6c-1.103 0-2 .897-2 2v8c0 1.103.897 2 2 2h12c1.103 0 2-.897 2-2v-8c0-1.103-.897-2-2-2h-1V7c0-2.757-2.243-5-5-5zm3 8V7c0-1.654-1.346-3-3-3S9 5.346 9 7v3h6z"/>
                    </svg>
                    Locked
                </span>
            </div>
            
            <!-- Spin to Win (Locked) -->
            <div class="game-card locked">
                <div class="game-icon-wrapper">
                    <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <circle cx="12" cy="12" r="10" fill="url(#spinGrad)" stroke="currentColor" stroke-width="2"/>
                        <path d="M12 2 L12 12 L22 12 Z" fill="rgba(255,255,255,0.3)"/>
                        <circle cx="12" cy="12" r="2" fill="#fff"/>
                        <defs>
                            <linearGradient id="spinGrad" x1="2" y1="2" x2="22" y2="22">
                                <stop offset="0%" style="stop-color:#2c5bf5;stop-opacity:0.5" />
                                <stop offset="50%" style="stop-color:#4de1c1;stop-opacity:0.5" />
                                <stop offset="100%" style="stop-color:#ff914d;stop-opacity:0.5" />
                            </linearGradient>
                        </defs>
                    </svg>
                </div>
                <div class="game-title">Spin to Win</div>
                <span class="game-status locked">
                    <svg viewBox="0 0 24 24" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                        <path d="M12 2C9.243 2 7 4.243 7 7v3H6c-1.103 0-2 .897-2 2v8c0 1.103.897 2 2 2h12c1.103 0 2-.897 2-2v-8c0-1.103-.897-2-2-2h-1V7c0-2.757-2.243-5-5-5zm3 8V7c0-1.654-1.346-3-3-3S9 5.346 9 7v3h6z"/>
                    </svg>
                    Locked
                </span>
            </div>
            
            <!-- Ball Drop (Locked) -->
            <div class="game-card locked">
                <div class="game-icon-wrapper">
                    <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <circle cx="12" cy="8" r="4" fill="url(#ballGrad)" stroke="currentColor" stroke-width="2"/>
                        <path d="M6 20 L18 20" stroke="currentColor" stroke-width="3" stroke-linecap="round"/>
                        <path d="M12 12 L12 18" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-dasharray="2 2"/>
                        <defs>
                            <linearGradient id="ballGrad" x1="8" y1="4" x2="16" y2="12">
                                <stop offset="0%" style="stop-color:#ff914d;stop-opacity:0.8" />
                                <stop offset="100%" style="stop-color:#ff6b6b;stop-opacity:0.8" />
                            </linearGradient>
                        </defs>
                    </svg>
                </div>
                <div class="game-title">Ball Drop</div>
                <span class="game-status locked">
                    <svg viewBox="0 0 24 24" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                        <path d="M12 2C9.243 2 7 4.243 7 7v3H6c-1.103 0-2 .897-2 2v8c0 1.103.897 2 2 2h12c1.103 0 2-.897 2-2v-8c0-1.103-.897-2-2-2h-1V7c0-2.757-2.243-5-5-5zm3 8V7c0-1.654-1.346-3-3-3S9 5.346 9 7v3h6z"/>
                    </svg>
                    Locked
                </span>
            </div>
            
            <!-- Mystery Box (Locked) -->
            <div class="game-card locked">
                <div class="game-icon-wrapper">
                    <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <rect x="4" y="8" width="16" height="12" rx="2" fill="url(#boxGrad)" stroke="currentColor" stroke-width="2"/>
                        <path d="M4 12 L20 12" stroke="currentColor" stroke-width="2"/>
                        <path d="M12 8 L12 4 M12 4 L9 6 M12 4 L15 6" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
                        <defs>
                            <linearGradient id="boxGrad" x1="4" y1="8" x2="20" y2="20">
                                <stop offset="0%" style="stop-color:#2c5bf5;stop-opacity:0.5" />
                                <stop offset="100%" style="stop-color:#4de1c1;stop-opacity:0.5" />
                            </linearGradient>
                        </defs>
                    </svg>
                </div>
                <div class="game-title">Mystery Box</div>
                <span class="game-status locked">
                    <svg viewBox="0 0 24 24" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                        <path d="M12 2C9.243 2 7 4.243 7 7v3H6c-1.103 0-2 .897-2 2v8c0 1.103.897 2 2 2h12c1.103 0 2-.897 2-2v-8c0-1.103-.897-2-2-2h-1V7c0-2.757-2.243-5-5-5zm3 8V7c0-1.654-1.346-3-3-3S9 5.346 9 7v3h6z"/>
                    </svg>
                    Locked
                </span>
            </div>
            
            <!-- Color Predictor (Unlocked) -->
            <div class="game-card" onclick="alert('Color Predictor coming soon!')">
                <div class="game-icon-wrapper">
                    <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <circle cx="12" cy="12" r="10" fill="url(#colorGrad)" stroke="currentColor" stroke-width="2"/>
                        <path d="M12 2 A10 10 0 0 1 22 12 L12 12 Z" fill="rgba(255,0,0,0.5)"/>
                        <path d="M12 12 L22 12 A10 10 0 0 1 12 22 Z" fill="rgba(0,255,0,0.5)"/>
                        <path d="M12 22 A10 10 0 0 1 2 12 L12 12 Z" fill="rgba(0,0,255,0.5)"/>
                        <defs>
                            <linearGradient id="colorGrad" x1="2" y1="2" x2="22" y2="22">
                                <stop offset="0%" style="stop-color:#ff0000;stop-opacity:0.3" />
                                <stop offset="50%" style="stop-color:#00ff00;stop-opacity:0.3" />
                                <stop offset="100%" style="stop-color:#0000ff;stop-opacity:0.3" />
                            </linearGradient>
                        </defs>
                    </svg>
                </div>
                <div class="game-title">Color Predictor</div>
                <span class="game-status unlocked">
                    <svg viewBox="0 0 24 24" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                        <circle cx="12" cy="12" r="10"/>
                    </svg>
                    Unlocked
                </span>
            </div>
            
            <!-- Coin Flip (Locked) -->
            <div class="game-card locked">
                <div class="game-icon-wrapper">
                    <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <ellipse cx="12" cy="12" rx="8" ry="10" fill="url(#coinGrad)" stroke="currentColor" stroke-width="2"/>
                        <text x="12" y="16" text-anchor="middle" fill="#fff" font-size="10" font-weight="bold">₦</text>
                        <defs>
                            <linearGradient id="coinGrad" x1="4" y1="2" x2="20" y2="22">
                                <stop offset="0%" style="stop-color:#ffd700;stop-opacity:0.8" />
                                <stop offset="100%" style="stop-color:#ff914d;stop-opacity:0.8" />
                            </linearGradient>
                        </defs>
                    </svg>
                </div>
                <div class="game-title">Coin Flip</div>
                <span class="game-status locked">
                    <svg viewBox="0 0 24 24" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                        <path d="M12 2C9.243 2 7 4.243 7 7v3H6c-1.103 0-2 .897-2 2v8c0 1.103.897 2 2 2h12c1.103 0 2-.897 2-2v-8c0-1.103-.897-2-2-2h-1V7c0-2.757-2.243-5-5-5zm3 8V7c0-1.654-1.346-3-3-3S9 5.346 9 7v3h6z"/>
                    </svg>
                    Locked
                </span>
            </div>
            
            <!-- Target Drop (Locked) -->
            <div class="game-card locked">
                <div class="game-icon-wrapper">
                    <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <circle cx="12" cy="12" r="10" stroke="currentColor" stroke-width="2" fill="none"/>
                        <circle cx="12" cy="12" r="7" stroke="currentColor" stroke-width="2" fill="rgba(77,225,193,0.2)"/>
                        <circle cx="12" cy="12" r="4" stroke="currentColor" stroke-width="2" fill="rgba(44,91,245,0.3)"/>
                        <circle cx="12" cy="12" r="2" fill="url(#targetGrad)"/>
                        <defs>
                            <linearGradient id="targetGrad" x1="10" y1="10" x2="14" y2="14">
                                <stop offset="0%" style="stop-color:#ff914d;stop-opacity:1" />
                                <stop offset="100%" style="stop-color:#ff6b6b;stop-opacity:1" />
                            </linearGradient>
                        </defs>
                    </svg>
                </div>
                <div class="game-title">Target Drop</div>
                <span class="game-status locked">
                    <svg viewBox="0 0 24 24" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                        <path d="M12 2C9.243 2 7 4.243 7 7v3H6c-1.103 0-2 .897-2 2v8c0 1.103.897 2 2 2h12c1.103 0 2-.897 2-2v-8c0-1.103-.897-2-2-2h-1V7c0-2.757-2.243-5-5-5zm3 8V7c0-1.654-1.346-3-3-3S9 5.346 9 7v3h6z"/>
                    </svg>
                    Locked
                </span>
            </div>
        </div>
    </div>
    
    <!-- Plinko Game Modal -->
    <div class="game-modal" id="plinkoModal">
        <div class="game-content">
            <div class="game-header">
                <h2>
                    <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <circle cx="12" cy="12" r="10" fill="url(#headerGrad)" stroke="currentColor" stroke-width="2"/>
                        <circle cx="12" cy="12" r="4" fill="#fff"/>
                        <defs>
                            <linearGradient id="headerGrad" x1="2" y1="2" x2="22" y2="22">
                                <stop offset="0%" style="stop-color:#ff914d;stop-opacity:1" />
                                <stop offset="100%" style="stop-color:#ff6b6b;stop-opacity:1" />
                            </linearGradient>
                        </defs>
                    </svg>
                    Plinko Game
                </h2>
                <button class="close-btn" onclick="closePlinkoGame()">
                    <svg viewBox="0 0 24 24" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                        <path d="M18.3 5.71a.996.996 0 0 0-1.41 0L12 10.59 7.11 5.7A.996.996 0 1 0 5.7 7.11L10.59 12 5.7 16.89a.996.996 0 1 0 1.41 1.41L12 13.41l4.89 4.89a.996.996 0 1 0 1.41-1.41L13.41 12l4.89-4.89c.38-.38.38-1.02 0-1.4z"/>
                    </svg>
                    Close
                </button>
            </div>
            
            <div class="plinko-container">
                <div class="plinko-board">
                    <canvas id="plinkoCanvas"></canvas>
                </div>
                
                <div class="game-controls">
                    <div class="balance-display">
                        <div class="balance-item">
                            <span class="balance-label">
                                <svg viewBox="0 0 24 24" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 18c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8zm.31-8.86c-1.77-.45-2.34-.94-2.34-1.67 0-.84.79-1.43 2.1-1.43 1.38 0 1.9.66 1.94 1.64h1.71c-.05-1.34-.87-2.57-2.49-2.97V5H10.9v1.69c-1.51.32-2.72 1.3-2.72 2.81 0 1.79 1.49 2.69 3.66 3.21 1.95.46 2.34 1.15 2.34 1.87 0 .53-.39 1.39-2.1 1.39-1.6 0-2.23-.72-2.32-1.64H8.04c.1 1.7 1.36 2.66 2.86 2.97V19h2.34v-1.67c1.52-.29 2.72-1.16 2.73-2.77-.01-2.2-1.9-2.96-3.66-3.42z"/>
                                </svg>
                                Task Balance:
                            </span>
                            <span class="balance-value" id="taskBalance">
                                <svg class="coin-icon" viewBox="0 0 24 24" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                                    <circle cx="12" cy="12" r="10" fill="#ffd700"/>
                                    <text x="12" y="16" text-anchor="middle" fill="#000" font-size="10" font-weight="bold">₦</text>
                                </svg>
                                ₦<?php echo number_format($task_earnings, 2); ?>
                            </span>
                        </div>
                        <div class="balance-item">
                            <span class="balance-label">
                                <svg viewBox="0 0 24 24" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/>
                                </svg>
                                Free Plays:
                            </span>
                            <span class="balance-value" id="freePlays"><?php echo $free_plays; ?>/2</span>
                        </div>
                    </div>
                    
                    <div class="bet-input-wrapper">
                        <input type="number" class="bet-input" id="betAmount" placeholder="Enter bet amount (₦)" min="10" step="10" value="100">
                    </div>
                    
                    <button class="play-btn free-play-btn" id="freePlayBtn" onclick="playPlinko(true)" <?php echo $free_plays <= 0 ? 'disabled' : ''; ?>>
                        <svg style="width: 24px; height: 24px; display: inline-block; vertical-align: middle; margin-right: 8px;" viewBox="0 0 24 24" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                            <path d="M20 6h-2.18c.11-.31.18-.65.18-1a2.996 2.996 0 0 0-5.5-1.65l-.5.67-.5-.68C10.96 2.54 10.05 2 9 2 7.34 2 6 3.34 6 5c0 .35.07.69.18 1H4c-1.11 0-1.99.89-1.99 2L2 19c0 1.11.89 2 2 2h16c1.11 0 2-.89 2-2V8c0-1.11-.89-2-2-2zm-5-2c.55 0 1 .45 1 1s-.45 1-1 1-1-.45-1-1 .45-1 1-1zM9 4c.55 0 1 .45 1 1s-.45 1-1 1-1-.45-1-1 .45-1 1-1zm11 15H4v-2h16v2zm0-5H4V8h5.08L7 10.83 8.62 12 11 8.76l1-1.36 1 1.36L15.38 12 17 10.83 14.92 8H20v6z"/>
                        </svg>
                        Play Free (<?php echo $free_plays; ?> left)
                    </button>
                    
                    <button class="play-btn" id="betPlayBtn" onclick="playPlinko(false)">
                        <svg style="width: 24px; height: 24px; display: inline-block; vertical-align: middle; margin-right: 8px;" viewBox="0 0 24 24" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                            <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1.41 16.09V20h-2.67v-1.93c-1.71-.36-3.16-1.46-3.27-3.4h1.96c.1 1.05.82 1.87 2.65 1.87 1.96 0 2.4-.98 2.4-1.59 0-.83-.44-1.61-2.67-2.14-2.48-.6-4.18-1.62-4.18-3.67 0-1.72 1.39-2.84 3.11-3.21V4h2.67v1.95c1.86.45 2.79 1.86 2.85 3.39H14.3c-.05-1.11-.64-1.87-2.22-1.87-1.5 0-2.4.68-2.4 1.64 0 .84.65 1.39 2.67 1.91s4.18 1.39 4.18 3.91c-.01 1.83-1.38 2.83-3.12 3.16z"/>
                        </svg>
                        Play with Bet
                    </button>
                    
                    <div class="multipliers-info">
                        <h4>
                            <svg viewBox="0 0 24 24" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                                <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-6h2v6zm0-8h-2V7h2v2z"/>
                            </svg>
                            Multipliers
                        </h4>
                        <div class="multipliers-grid">
                            <div class="multiplier-item">
                                <span class="multiplier-value">0.5x</span>
                                <span class="multiplier-chance">30%</span>
                            </div>
                            <div class="multiplier-item">
                                <span class="multiplier-value">1.0x</span>
                                <span class="multiplier-chance">25%</span>
                            </div>
                            <div class="multiplier-item">
                                <span class="multiplier-value">1.5x</span>
                                <span class="multiplier-chance">20%</span>
                            </div>
                            <div class="multiplier-item">
                                <span class="multiplier-value">2.0x</span>
                                <span class="multiplier-chance">15%</span>
                            </div>
                            <div class="multiplier-item">
                                <span class="multiplier-value">3.0x</span>
                                <span class="multiplier-chance">7%</span>
                            </div>
                            <div class="multiplier-item">
                                <span class="multiplier-value">5.0x</span>
                                <span class="multiplier-chance">2%</span>
                            </div>
                            <div class="multiplier-item jackpot-item">
                                <span class="multiplier-value">10.0x</span>
                                <span class="multiplier-chance">1%</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Leaderboard -->
            <div class="leaderboard">
                <h3>
                    <svg viewBox="0 0 24 24" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                        <path d="M19 5h-2V3H7v2H5c-1.1 0-2 .9-2 2v1c0 2.55 1.92 4.63 4.39 4.94.63 1.5 1.98 2.63 3.61 2.96V19H7v2h10v-2h-4v-3.1c1.63-.33 2.98-1.46 3.61-2.96C19.08 12.63 21 10.55 21 8V7c0-1.1-.9-2-2-2zM5 8V7h2v3.82C5.84 10.4 5 9.3 5 8zm14 0c0 1.3-.84 2.4-2 2.82V7h2v1z"/>
                    </svg>
                    Top Players
                </h3>
                <div class="leaderboard-list" id="leaderboardList">
                    <div style="text-align: center; padding: 30px; color: rgba(255, 255, 255, 0.5);">
                        <div class="loading-spinner" style="margin: 0 auto 15px;"></div>
                        Loading leaderboard...
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Result Modal -->
    <div class="result-modal" id="resultModal">
        <div class="result-icon-wrapper" id="resultIconWrapper">
            <svg id="resultIcon" viewBox="0 0 24 24" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z" fill="url(#resultGrad)"/>
                <defs>
                    <linearGradient id="resultGrad" x1="2" y1="2" x2="22" y2="22">
                        <stop offset="0%" style="stop-color:#ffd700;stop-opacity:1" />
                        <stop offset="100%" style="stop-color:#ff914d;stop-opacity:1" />
                    </linearGradient>
                </defs>
            </svg>
        </div>
        <div class="result-text" id="resultText">You Won!</div>
        <div class="result-amount" id="resultAmount">₦0.00</div>
        <div class="result-buttons">
            <button class="result-btn claim-btn" onclick="closeResult()">
                <svg style="width: 20px; height: 20px; display: inline-block; vertical-align: middle; margin-right: 6px;" viewBox="0 0 24 24" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                    <path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z"/>
                </svg>
                Claim Reward
            </button>
            <button class="result-btn play-again-btn" onclick="playAgain()">
                <svg style="width: 20px; height: 20px; display: inline-block; vertical-align: middle; margin-right: 6px;" viewBox="0 0 24 24" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                    <path d="M12 5V1L7 6l5 5V7c3.31 0 6 2.69 6 6s-2.69 6-6 6-6-2.69-6-6H4c0 4.42 3.58 8 8 8s8-3.58 8-8-3.58-8-8-8z"/>
                </svg>
                Play Again
            </button>
        </div>
    </div>
    
    <script>
        // Initialize particles
        function createParticles() {
            const particlesContainer = document.getElementById('particles');
            for (let i = 0; i < 50; i++) {
                const particle = document.createElement('div');
                particle.className = 'particle';
                particle.style.left = Math.random() * 100 + '%';
                particle.style.animationDelay = Math.random() * 20 + 's';
                particle.style.animationDuration = (20 + Math.random() * 10) + 's';
                particlesContainer.appendChild(particle);
            }
        }
        
        createParticles();
        
        // Plinko game variables
        let canvas, ctx;
        let balls = [];
        let pegs = [];
        let slots = [];
        let isPlaying = false;
        
        function initPlinko() {
            canvas = document.getElementById('plinkoCanvas');
            ctx = canvas.getContext('2d');
            
            // Set canvas size
            canvas.width = canvas.offsetWidth;
            canvas.height = 650;
            
            // Create pegs
            const rows = 12;
            const cols = 9;
            const pegRadius = 5;
            const spacing = canvas.width / (cols + 1);
            
            pegs = [];
            for (let row = 0; row < rows; row++) {
                for (let col = 0; col < cols - (row % 2); col++) {
                    const x = spacing * (col + 1 + (row % 2) * 0.5);
                    const y = 80 + row * 40;
                    pegs.push({ x, y, radius: pegRadius });
                }
            }
            
            // Create slots
            slots = [];
            const slotWidth = canvas.width / 9;
            const multipliers = [10, 5, 3, 2, 1.5, 1, 0.5, 1, 1.5];
            const colors = ['#ffd700', '#ff914d', '#4de1c1', '#2c5bf5', '#4de1c1', '#2c5bf5', '#ff6b6b', '#2c5bf5', '#4de1c1'];
            for (let i = 0; i < 9; i++) {
                slots.push({
                    x: i * slotWidth,
                    width: slotWidth,
                    multiplier: multipliers[i],
                    color: colors[i]
                });
            }
            
            animate();
            loadLeaderboard();
        }
        
        function animate() {
            ctx.clearRect(0, 0, canvas.width, canvas.height);
            
            // Draw slots
            slots.forEach(slot => {
                ctx.fillStyle = slot.color + '33';
                ctx.fillRect(slot.x, canvas.height - 60, slot.width, 60);
                ctx.fillStyle = slot.color;
                ctx.font = 'bold 18px Inter';
                ctx.textAlign = 'center';
                ctx.fillText(slot.multiplier + 'x', slot.x + slot.width / 2, canvas.height - 30);
            });
            
            // Draw pegs
            pegs.forEach(peg => {
                ctx.beginPath();
                ctx.arc(peg.x, peg.y, peg.radius, 0, Math.PI * 2);
                const gradient = ctx.createRadialGradient(peg.x, peg.y, 0, peg.x, peg.y, peg.radius);
                gradient.addColorStop(0, '#4de1c1');
                gradient.addColorStop(1, '#2c5bf5');
                ctx.fillStyle = gradient;
                ctx.fill();
                ctx.strokeStyle = '#4de1c1';
                ctx.lineWidth = 2;
                ctx.stroke();
                ctx.shadowBlur = 10;
                ctx.shadowColor = '#4de1c1';
            });
            
            ctx.shadowBlur = 0;
            
            // Update and draw balls
            balls = balls.filter(ball => {
                ball.vy += 0.5; // gravity
                ball.y += ball.vy;
                ball.x += ball.vx;
                
                // Check collision with pegs
                pegs.forEach(peg => {
                    const dx = ball.x - peg.x;
                    const dy = ball.y - peg.y;
                    const distance = Math.sqrt(dx * dx + dy * dy);
                    
                    if (distance < ball.radius + peg.radius) {
                        ball.vx = (Math.random() - 0.5) * 3;
                        ball.vy *= 0.8;
                    }
                });
                
                // Check if ball reached bottom
                if (ball.y >= canvas.height - 70) {
                    const slotIndex = Math.floor(ball.x / (canvas.width / 9));
                    if (slotIndex >= 0 && slotIndex < slots.length) {
                        ball.multiplier = slots[slotIndex].multiplier;
                        ball.landed = true;
                    }
                    return false;
                }
                
                // Draw ball
                ctx.beginPath();
                ctx.arc(ball.x, ball.y, ball.radius, 0, Math.PI * 2);
                const ballGradient = ctx.createRadialGradient(ball.x - 3, ball.y - 3, 0, ball.x, ball.y, ball.radius);
                ballGradient.addColorStop(0, '#ff914d');
                ballGradient.addColorStop(1, '#ff6b6b');
                ctx.fillStyle = ballGradient;
                ctx.fill();
                ctx.strokeStyle = '#fff';
                ctx.lineWidth = 2;
                ctx.stroke();
                ctx.shadowBlur = 15;
                ctx.shadowColor = '#ff914d';
                
                return true;
            });
            
            ctx.shadowBlur = 0;
            requestAnimationFrame(animate);
        }
        
        function dropBall() {
            const ball = {
                x: canvas.width / 2 + (Math.random() - 0.5) * 20,
                y: 20,
                vx: 0,
                vy: 0,
                radius: 8,
                multiplier: 1,
                landed: false
            };
            balls.push(ball);
            
            // Wait for ball to land
            const checkLanded = setInterval(() => {
                if (ball.landed) {
                    clearInterval(checkLanded);
                    handleBallLanded(ball.multiplier);
                }
            }, 100);
        }
        
        async function playPlinko(isFree) {
            if (isPlaying) return;
            
            const betAmount = isFree ? 0 : parseFloat(document.getElementById('betAmount').value);
            
            if (!isFree && (isNaN(betAmount) || betAmount < 10)) {
                alert('Please enter a valid bet amount (minimum ₦10)');
                return;
            }
            
            isPlaying = true;
            document.getElementById('freePlayBtn').disabled = true;
            document.getElementById('betPlayBtn').disabled = true;
            
            dropBall();
        }
        
        async function handleBallLanded(multiplier) {
            const betAmount = parseFloat(document.getElementById('betAmount').value) || 0;
            const isFree = betAmount === 0;
            
            try {
                const response = await fetch('api/plinko-play.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        bet_amount: betAmount,
                        is_free_play: isFree
                    })
                });
                
                const data = await response.json();
                
                if (data.success) {
                    // Update balances
                    document.getElementById('taskBalance').innerHTML = `
                        <svg class="coin-icon" viewBox="0 0 24 24" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                            <circle cx="12" cy="12" r="10" fill="#ffd700"/>
                            <text x="12" y="16" text-anchor="middle" fill="#000" font-size="10" font-weight="bold">₦</text>
                        </svg>
                        ₦${parseFloat(data.new_balance).toFixed(2)}
                    `;
                    document.getElementById('freePlays').textContent = data.free_plays_remaining + '/2';
                    
                    // Update free play button
                    const freePlayBtn = document.getElementById('freePlayBtn');
                    if (data.free_plays_remaining <= 0) {
                        freePlayBtn.disabled = true;
                        freePlayBtn.innerHTML = `
                            <svg style="width: 24px; height: 24px; display: inline-block; vertical-align: middle; margin-right: 8px;" viewBox="0 0 24 24" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                                <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/>
                            </svg>
                            No Free Plays Left
                        `;
                    } else {
                        freePlayBtn.innerHTML = `
                            <svg style="width: 24px; height: 24px; display: inline-block; vertical-align: middle; margin-right: 8px;" viewBox="0 0 24 24" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                                <path d="M20 6h-2.18c.11-.31.18-.65.18-1a2.996 2.996 0 0 0-5.5-1.65l-.5.67-.5-.68C10.96 2.54 10.05 2 9 2 7.34 2 6 3.34 6 5c0 .35.07.69.18 1H4c-1.11 0-1.99.89-1.99 2L2 19c0 1.11.89 2 2 2h16c1.11 0 2-.89 2-2V8c0-1.11-.89-2-2-2zm-5-2c.55 0 1 .45 1 1s-.45 1-1 1-1-.45-1-1 .45-1 1-1zM9 4c.55 0 1 .45 1 1s-.45 1-1 1-1-.45-1-1 .45-1 1-1zm11 15H4v-2h16v2zm0-5H4V8h5.08L7 10.83 8.62 12 11 8.76l1-1.36 1 1.36L15.38 12 17 10.83 14.92 8H20v6z"/>
                            </svg>
                            Play Free (${data.free_plays_remaining} left)
                        `;
                    }
                    
                    // Show result
                    showResult(data.win_amount, data.multiplier);
                    
                    // Reload leaderboard
                    loadLeaderboard();
                } else {
                    alert(data.message || 'An error occurred');
                }
            } catch (error) {
                console.error('[v0] Error:', error);
                alert('An error occurred. Please try again.');
            }
            
            isPlaying = false;
            document.getElementById('freePlayBtn').disabled = false;
            document.getElementById('betPlayBtn').disabled = false;
        }
        
        function showResult(amount, multiplier) {
            const resultModal = document.getElementById('resultModal');
            const resultIcon = document.getElementById('resultIcon');
            const resultText = document.getElementById('resultText');
            const resultAmount = document.getElementById('resultAmount');
            
            if (multiplier >= 5) {
                resultIcon.innerHTML = '<path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z" fill="url(#jackpotGrad)"/><defs><linearGradient id="jackpotGrad" x1="2" y1="2" x2="22" y2="22"><stop offset="0%" style="stop-color:#ffd700;stop-opacity:1" /><stop offset="100%" style="stop-color:#ff914d;stop-opacity:1" /></linearGradient></defs>';
                resultText.textContent = 'JACKPOT!';
            } else if (multiplier >= 2) {
                resultIcon.innerHTML = '<path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z" fill="url(#winGrad)"/><defs><linearGradient id="winGrad" x1="2" y1="2" x2="22" y2="22"><stop offset="0%" style="stop-color:#4de1c1;stop-opacity:1" /><stop offset="100%" style="stop-color:#2c5bf5;stop-opacity:1" /></linearGradient></defs>';
                resultText.textContent = 'Big Win!';
            } else if (multiplier > 1) {
                resultIcon.innerHTML = '<path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z" fill="url(#smallWinGrad)"/><defs><linearGradient id="smallWinGrad" x1="2" y1="2" x2="22" y2="22"><stop offset="0%" style="stop-color:#4de1c1;stop-opacity:1" /><stop offset="100%" style="stop-color:#2c5bf5;stop-opacity:1" /></linearGradient></defs>';
                resultText.textContent = 'You Won!';
            } else {
                resultIcon.innerHTML = '<circle cx="12" cy="12" r="10" fill="none" stroke="url(#loseGrad)" stroke-width="2"/><path d="M8 15s1.5 2 4 2 4-2 4-2" stroke="url(#loseGrad)" stroke-width="2" stroke-linecap="round"/><circle cx="9" cy="9" r="1" fill="url(#loseGrad)"/><circle cx="15" cy="9" r="1" fill="url(#loseGrad)"/><defs><linearGradient id="loseGrad" x1="2" y1="2" x2="22" y2="22"><stop offset="0%" style="stop-color:#ff6b6b;stop-opacity:1" /><stop offset="100%" style="stop-color:#ff914d;stop-opacity:1" /></linearGradient></defs>';
                resultText.textContent = 'Try Again!';
            }
            
            resultAmount.textContent = '₦' + parseFloat(amount).toFixed(2);
            resultModal.classList.add('active');
        }
        
        function closeResult() {
            document.getElementById('resultModal').classList.remove('active');
        }
        
        function playAgain() {
            closeResult();
        }
        
        async function loadLeaderboard() {
            try {
                const response = await fetch('api/plinko-leaderboard.php');
                const data = await response.json();
                
                if (data.success && data.leaderboard.length > 0) {
                    const leaderboardList = document.getElementById('leaderboardList');
                    leaderboardList.innerHTML = data.leaderboard.map((player, index) => `
                        <div class="leaderboard-item">
                            <div class="rank ${index === 0 ? 'gold' : index === 1 ? 'silver' : index === 2 ? 'bronze' : ''}">#${index + 1}</div>
                            <img src="${player.profile_picture || 'assets/images/default-avatar.png'}" alt="${player.username}" class="player-avatar" onerror="this.src='assets/images/default-avatar.png'">
                            <div class="player-info">
                                <div class="player-name">${player.full_name || player.username}</div>
                                <div class="player-username">@${player.username}</div>
                            </div>
                            <div class="stat">
                                <div class="stat-label">Profit</div>
                                <div class="stat-value">₦${parseFloat(player.total_profit).toFixed(2)}</div>
                            </div>
                            <div class="stat">
                                <div class="stat-label">Wins</div>
                                <div class="stat-value">${player.total_wins}</div>
                            </div>
                        </div>
                    `).join('');
                } else {
                    document.getElementById('leaderboardList').innerHTML = '<div style="text-align: center; padding: 30px; color: rgba(255, 255, 255, 0.5);">No players yet. Be the first!</div>';
                }
            } catch (error) {
                console.error('[v0] Error loading leaderboard:', error);
            }
        }
        
        function openPlinkoGame() {
            document.getElementById('plinkoModal').classList.add('active');
            document.body.style.overflow = 'hidden';
            initPlinko();
        }
        
        function closePlinkoGame() {
            document.getElementById('plinkoModal').classList.remove('active');
            document.body.style.overflow = 'auto';
        }
    </script>
    <script src="assets/js/theme-switcher.js"></script>
</body>
</html>
