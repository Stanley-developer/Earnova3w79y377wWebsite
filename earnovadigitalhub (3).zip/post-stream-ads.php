<?php
ob_start();

require_once 'config/database.php';
require_once 'includes/session.php';
require_once 'includes/connect.php';

// Require authentication
requireLogin();
checkSessionTimeout();

// Get current user data
$user = getCurrentUser();
$user_id = $user['id'];

try {
    $pdo = getDBConnection();
    
    // Fetch user details with balances
    $stmt = $pdo->prepare("SELECT u.*, b.total_balance, b.task_earnings, b.referral_earnings FROM users u LEFT JOIN balances b ON u.id = b.user_id WHERE u.id = ?");
    $stmt->execute([$user_id]);
    $user_data = $stmt->fetch();
    
    if (!$user_data) {
        header('Location: login.php');
        exit;
    }
    
    // Check if user agreed to post-stream-ad terms
    $stream_ad_post_agreed = isset($_SESSION['post_stream_ad_agreed_' . $user_id]) ? $_SESSION['post_stream_ad_agreed_' . $user_id] : false;
    
    // Handle AJAX request to agree stream ad terms
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['ajax']) && $_POST['ajax'] && isset($_POST['action']) && $_POST['action'] === 'agree_stream_ad_terms') {
      ob_end_clean();
      header('Content-Type: application/json; charset=utf-8');
      $_SESSION['post_stream_ad_agreed_' . $user_id] = true;
      echo json_encode(['success' => true, 'message' => 'Post Stream Ad Terms agreed']);
      exit;
    }
    
    // Platform prices per 10 participants (in Naira) - for music streaming platforms
    $platform_prices = [
        'spotify' => ['name' => 'Spotify', 'price' => 400],
        'audiomack' => ['name' => 'Audiomack', 'price' => 320],
        'apple_music' => ['name' => 'Apple Music', 'price' => 400],
        'youtube_music' => ['name' => 'YouTube Music', 'price' => 380],
        'soundcloud' => ['name' => 'SoundCloud', 'price' => 350],
        'tidal' => ['name' => 'Tidal', 'price' => 400],
        'deezer' => ['name' => 'Deezer', 'price' => 350],
        'boomplay' => ['name' => 'Boomplay', 'price' => 300]
    ];

    // Platform URL patterns used to validate that provided links match the selected platform
    $platform_url_patterns = [
      'spotify' => ['spotify.com', 'open.spotify.com'],
      'audiomack' => ['audiomack.com'],
      'apple_music' => ['music.apple.com', 'itunes.apple.com'],
      'youtube_music' => ['music.youtube.com', 'youtube.com/watch'],
      'soundcloud' => ['soundcloud.com'],
      'tidal' => ['tidal.com', 'listen.tidal.com'],
      'deezer' => ['deezer.com'],
      'boomplay' => ['boomplay.com']
    ];

    function validatePlatformUrl($url, $platform, $patterns) {
      $url_lower = strtolower($url);
      if (!isset($patterns[$platform])) {
        return false;
      }
      foreach ($patterns[$platform] as $pattern) {
        if (strpos($url_lower, $pattern) !== false) {
          return true;
        }
      }
      return false;
    }
    
    // Handle form submission
    $message = '';
    $messageType = '';
    
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'upload_stream_ad') {
        $track_title = trim($_POST['track_title'] ?? '');
        $artist_name = trim($_POST['artist_name'] ?? '');
        $album = trim($_POST['album'] ?? '');
        $ad_redirect_link = trim($_POST['ad_redirect_link'] ?? '');
        $platform = $_POST['platform'] ?? '';
        $audio_duration = floatval($_POST['audio_duration'] ?? 0);
        $audio_file = null;
        $cover_image = null;
        $participants = intval($_POST['participants'] ?? 10);
        
        // Validation
        if (empty($track_title) || empty($artist_name) || empty($ad_redirect_link) || empty($platform)) {
            $message = 'Please fill in all required fields (Track Title, Artist Name, Ad Redirect Link, Platform)';
            $messageType = 'error';
        } elseif (!filter_var($ad_redirect_link, FILTER_VALIDATE_URL)) {
            $message = 'Please provide a valid Ad Redirect Link';
            $messageType = 'error';
        } elseif (!isset($platform_prices[$platform])) {
            $message = 'Invalid platform selected';
            $messageType = 'error';
        } elseif (!validatePlatformUrl($ad_redirect_link, $platform, $platform_url_patterns)) {
          $message = 'Ad Redirect Link does not match selected platform.';
          $messageType = 'error';
        } elseif ($participants < 10 || $participants > 1000) {
              $message = 'Participants must be between 10 and 1000';
              $messageType = 'error';
        } else {
            try {
                $track_duration = $audio_duration;
                
                // Handle audio file upload (required)
                if (!isset($_FILES['audio_file']) || $_FILES['audio_file']['error'] !== UPLOAD_ERR_OK) {
                    throw new Exception('Audio file is required');
                }
                
                $audio_tmp = $_FILES['audio_file']['tmp_name'];
                $audio_name = basename($_FILES['audio_file']['name']);
                $audio_ext = strtolower(pathinfo($audio_name, PATHINFO_EXTENSION));
                
                // Validate audio file type
                $allowed_audio = ['mp3', 'wav', 'ogg', 'm4a', 'mp4'];
                if (!in_array($audio_ext, $allowed_audio)) {
                    throw new Exception('Invalid audio file type. Allowed: mp3, wav, ogg, m4a, mp4');
                }
                
                $audio_filename = 'audio_' . time() . '_' . uniqid() . '.' . $audio_ext;
                $audio_path = 'uploads/user_stream_ads/' . $audio_filename;
                
                if (!is_dir('uploads/user_stream_ads')) {
                    mkdir('uploads/user_stream_ads', 0755, true);
                }
                
                if (!move_uploaded_file($audio_tmp, $audio_path)) {
                    throw new Exception('Failed to upload audio file');
                }
                
                $audio_file = $audio_path;
                
                // Handle cover image upload (optional)
                if (isset($_FILES['cover_image']) && $_FILES['cover_image']['error'] === UPLOAD_ERR_OK) {
                    $cover_tmp = $_FILES['cover_image']['tmp_name'];
                    $cover_name = basename($_FILES['cover_image']['name']);
                    $cover_ext = strtolower(pathinfo($cover_name, PATHINFO_EXTENSION));
                    
                    // Validate image file type
                    $allowed_images = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
                    if (in_array($cover_ext, $allowed_images)) {
                        $cover_filename = 'cover_' . time() . '_' . uniqid() . '.' . $cover_ext;
                        $cover_path = 'uploads/user_stream_covers/' . $cover_filename;
                        
                        if (!is_dir('uploads/user_stream_covers')) {
                            mkdir('uploads/user_stream_covers', 0755, true);
                        }
                        
                        if (move_uploaded_file($cover_tmp, $cover_path)) {
                            $cover_image = $cover_path;
                        }
                    }
                }
                
                // Calculate cost based on platform and participants
                $base_price = $platform_prices[$platform]['price'];
                $total_cost = ($participants / 10) * $base_price;
                
                // Check if user has sufficient balance
                $available_balance = $user_data['referral_earnings'];
                
                if ($available_balance < $total_cost) {
                    $message = 'Insufficient balance. You need ₦' . number_format($total_cost, 2) . ' to post this stream ad. Please deposit funds.';
                    $messageType = 'error';
                } else {
                    // Begin transaction
                    $pdo->beginTransaction();
                    
                    try {
                        // Generate unique track ID
                        $track_id = 'track_' . time() . '_' . uniqid();
                        $created_at = date('Y-m-d H:i:s');
                        
                        // Set rewards for free and premium users (6% of total cost distributed)
                        $reward_total = $total_cost * 0.06;
                        $free_reward = $reward_total / $participants;
                        $premium_reward = $free_reward * 1.5; // Premium users get 50% more
                        
                        // Insert track into stream_tracks table
                        $stmt = $pdo->prepare("
                            INSERT INTO stream_tracks
                            (track_id, title, artist, album, duration, cover_image, audio_file, track_link, is_ad_track, free_reward, premium_reward, is_active, upload_date, uploaded_by, uploaded_by_user_id, participants_target, post_cost, platform_type)
                            VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1, ?, ?, 1, ?, 0, ?, ?, ?, ?)
                        ");

                        $stmt->execute([
                          $track_id,
                          $track_title,
                          $artist_name,
                          $album,
                          $track_duration,
                          $cover_image,
                          $audio_file,
                          $ad_redirect_link,
                          $free_reward,
                          $premium_reward,
                          $created_at,
                          $user_id,
                          $participants,
                          $total_cost,
                          $platform
                        ]);
                        
                        // Deduct from user's balance
                        $stmt = $pdo->prepare("UPDATE balances SET referral_earnings = referral_earnings - ? WHERE user_id = ?");
                        $stmt->execute([$total_cost, $user_id]);
                        
                        // Record transaction
                        $stmt = $pdo->prepare("INSERT INTO transactions (user_id, transaction_type, amount, balance_type, description, reference_id, created_at) VALUES (?, ?, ?, ?, ?, ?, NOW())");
                        $description_text = "Posted stream ad: {$track_title} by {$artist_name} on {$platform_prices[$platform]['name']}";
                        $stmt->execute([$user_id, 'stream_ad_post', $total_cost, 'prime_earnings', $description_text, "STREAM-AD-{$track_id}"]);
                        
                        $pdo->commit();
                        
                        $message = 'Stream ad posted successfully! Your audio ad is now available for users to listen and earn.';
                        $messageType = 'success';
                        
                        // Refresh user data
                        $stmt = $pdo->prepare("SELECT u.*, b.total_balance, b.task_earnings, b.referral_earnings FROM users u LEFT JOIN balances b ON u.id = b.user_id WHERE u.id = ?");
                        $stmt->execute([$user_id]);
                        $user_data = $stmt->fetch();
                        
                    } catch (Exception $e) {
                        $pdo->rollBack();
                        throw $e;
                    }
                }
            } catch (Exception $e) {
                $message = 'Upload failed: ' . htmlspecialchars($e->getMessage());
                $messageType = 'error';
                error_log('Stream ad upload error: ' . $e->getMessage());
            }
        }
    }
    
} catch (PDOException $e) {
    error_log("Post Stream Ad Error: " . $e->getMessage());
    $error_message = "Unable to load page data.";
}

$username = htmlspecialchars($user_data['username'] ?? 'User');
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Post Stream Ad - Earnova</title>
  <!-- Using internal CSS -->
  <style>
    :root {
      --bg-primary: linear-gradient(180deg, rgba(3, 9, 34, 1), rgba(4, 10, 36, 1));
      --bg-secondary: rgba(13, 24, 62, 0.82);
      --page-white: #f5f9ff;
      --page-mint: #4de1c1;
      --page-soft-blue: rgba(100, 154, 255, 0.2);
      --text-secondary: rgba(205, 219, 255, 0.8);
    }

    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }

    body {
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      background: var(--bg-primary);
      color: var(--page-white);
      min-height: 100vh;
    }

    .page-shell {
      display: flex;
      min-height: 100vh;
      padding-bottom: 80px;
    }

    aside#sidebar {
      display: none;
    }

    .back-link {
      display: inline-flex;
      align-items: center;
      gap: 8px;
      color: var(--page-mint);
      text-decoration: none;
      font-weight: 600;
      font-size: 0.9rem;
      margin-bottom: 24px;
      transition: transform 0.2s ease;
    }

    .back-link:hover {
      transform: translateX(-4px);
    }

    .aside-welcome {
      display: flex;
      gap: 12px;
      margin-bottom: 32px;
      padding: 16px;
      background: rgba(77, 225, 193, 0.08);
      border: 1px solid rgba(77, 225, 193, 0.2);
      border-radius: 12px;
    }

    .aside-avatar {
      width: 48px;
      height: 48px;
      border-radius: 50%;
      overflow: hidden;
      border: 2px solid var(--page-mint);
    }

    .aside-avatar img {
      width: 100%;
      height: 100%;
      object-fit: cover;
    }

    .welcome-tag {
      font-size: 0.75rem;
      color: var(--text-secondary);
      margin-bottom: 4px;
    }

    .aside-welcome h3 {
      font-size: 1.1rem;
      margin-bottom: 4px;
    }

    .welcome-meta {
      font-size: 0.85rem;
      color: var(--page-mint);
      font-weight: 600;
    }

    .page-title {
      font-size: 1.8rem;
      margin-bottom: 12px;
      color: var(--page-white);
    }

    .side-description {
      color: var(--text-secondary);
      line-height: 1.6;
      font-size: 0.95rem;
    }

    main {
      flex: 1;
      max-width: none;
      width: 100%;
      margin: 0;
      padding: 40px 24px;
    }

    .hero-section {
      background: linear-gradient(135deg, rgba(77, 225, 193, 0.08), rgba(13, 24, 62, 0.78));
      border: 1px solid rgba(100, 154, 255, 0.3);
      border-radius: 20px;
      padding: 32px;
      margin-bottom: 32px;
    }

    .hero-content h1 {
      font-size: 2rem;
      margin-bottom: 12px;
      color: var(--page-white);
    }

    .hero-content p {
      color: var(--text-secondary);
      font-size: 1rem;
      line-height: 1.6;
    }

    .form-section {
      background: rgba(13, 24, 62, 0.6);
      border: 1px solid rgba(100, 154, 255, 0.25);
      border-radius: 20px;
      padding: 32px;
    }

    .task-form {
      display: flex;
      flex-direction: column;
      gap: 24px;
    }

    .form-group {
      display: flex;
      flex-direction: column;
      gap: 8px;
    }

    .form-group label {
      font-weight: 600;
      color: var(--page-white);
      font-size: 0.95rem;
    }

    .form-group input[type="text"],
    .form-group input[type="url"],
    .form-group input[type="file"],
    .form-group input[type="number"],
    .form-group textarea,
    .form-group select {
      padding: 14px 16px;
      background: rgba(6, 16, 48, 0.6);
      border: 1px solid rgba(100, 154, 255, 0.3);
      border-radius: 12px;
      color: var(--page-white);
      font-size: 0.95rem;
      transition: all 0.3s ease;
    }

    .form-group input:focus,
    .form-group textarea:focus,
    .form-group select:focus {
      outline: none;
      border-color: var(--page-mint);
      box-shadow: 0 0 0 3px rgba(77, 225, 193, 0.1);
    }

    .form-group small {
      color: var(--text-secondary);
      font-size: 0.85rem;
    }

    .word-count-container {
      margin-top: 8px;
      display: flex;
      justify-content: space-between;
      align-items: center;
    }

    .word-counter {
      font-size: 0.9rem;
      color: rgba(245, 249, 255, 0.7);
      font-weight: 600;
    }

    .word-counter.warning {
      color: #FFB84D;
    }

    .word-counter.error {
      color: #FF6B6B;
    }

    .pricing-summary {
      background: rgba(77, 225, 193, 0.08);
      border: 1px solid rgba(77, 225, 193, 0.3);
      border-radius: 12px;
      padding: 20px;
      margin-top: 8px;
    }

    .pricing-summary h3 {
      font-size: 1.1rem;
      margin-bottom: 16px;
      color: var(--page-white);
    }

    .summary-row {
      display: flex;
      justify-content: space-between;
      padding: 10px 0;
      border-bottom: 1px solid rgba(77, 225, 193, 0.15);
      color: var(--text-secondary);
    }

    .summary-row:last-child {
      border-bottom: none;
    }

    .summary-row.total {
      font-weight: 700;
      font-size: 1.1rem;
      color: var(--page-white);
      margin-top: 8px;
      padding-top: 16px;
      border-top: 2px solid rgba(77, 225, 193, 0.3);
    }

    .submit-btn {
      padding: 16px 32px;
      background: linear-gradient(135deg, var(--page-mint), #2ec4b6);
      border: none;
      border-radius: 12px;
      color: #030922;
      font-weight: 700;
      font-size: 1rem;
      cursor: pointer;
      transition: all 0.3s ease;
      margin-top: 16px;
    }

    .submit-btn:hover {
      transform: translateY(-2px);
      box-shadow: 0 8px 20px rgba(77, 225, 193, 0.4);
    }

    .alert-message {
      position: fixed;
      top: 20px;
      right: -400px;
      padding: 16px 24px;
      border-radius: 12px;
      font-family: 'Segoe UI', sans-serif;
      font-size: 15px;
      z-index: 10000;
      opacity: 0;
      box-shadow: 0 10px 40px rgba(0, 0, 0, 0.2);
      transition: right 0.6s ease, opacity 0.6s ease;
      color: #fff;
      max-width: 400px;
    }

    .alert-success {
      background: rgba(77, 225, 193, 0.95);
      color: #030922;
      box-shadow: 0 10px 40px rgba(77, 225, 193, 0.4);
    }

    .alert-error {
      background: rgba(255, 77, 77, 0.95);
      color: #fff;
      box-shadow: 0 10px 40px rgba(255, 77, 77, 0.4);
    }

    .alert-message.show {
      right: 20px;
      opacity: 1;
    }

   .mobile-fintech-footer {
      display: none;
      position: fixed;
      left: 12px;
      right: 12px;
      bottom: 16px;
      padding: 10px;
      background: transparent;
      border: 1px solid rgba(86, 139, 241, 0.35);
      border-radius: 32px;
      backdrop-filter: blur(50px);
      box-shadow: 0 20px 60px rgba(4, 10, 36, 0.7);
      justify-content: space-around;
      align-items: center;
      z-index: 90;
    }

    .mobile-fintech-footer a {
      flex: 1;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      gap: 4px;
      text-decoration: none;
      color: rgba(205, 219, 255, 0.75);
      font-size: 0.45rem;
      letter-spacing: 0.06em;
      text-transform: uppercase;
      transition: all 0.3s ease;
      padding: 8px 4px;
      border-radius: 16px;
    }

    .mobile-fintech-footer a:nth-child(3) .icon-wrapper {
      width: 56px;
      height: 56px;
      border-radius: 50%;
      background: linear-gradient(135deg, rgba(77, 225, 193, 0.25), rgba(47, 91, 234, 0.25));
      backdrop-filter: blur(12px);
      border: 2px solid rgba(77, 225, 193, 0.4);
      display: flex;
      align-items: center;
      justify-content: center;
      margin-top: -28px;
      box-shadow: 0 8px 24px rgba(77, 225, 193, 0.15);
      transition: all 0.3s ease;
    }

    .mobile-fintech-footer a:nth-child(3) .icon-wrapper svg {
      width: 24px;
      height: 24px;
    }

    .mobile-fintech-footer a.active {
      color: var(--page-mint);
    }

    .mobile-fintech-footer a svg {
      width: 22px;
      height: 22px;
      flex-shrink: 0;
    }

    .ts-modal {
      display: none;
      position: fixed;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      background: rgba(3, 9, 34, 0.9);
      backdrop-filter: blur(8px);
      z-index: 99999;
      align-items: center;
      justify-content: center;
      padding: 20px;
    }

    .ts-modal.active {
      display: flex;
    }

    .ts-modal-content {
      background: rgba(6, 16, 48, 0.98);
      border: 1px solid rgba(100, 154, 255, 0.3);
      border-radius: 24px;
      padding: 32px;
      max-width: 600px;
      width: 100%;
      max-height: 80vh;
      overflow-y: auto;
      display: flex;
      flex-direction: column;
    }

    .ts-modal-header { margin-bottom: 24px; border-bottom: 1px solid rgba(100, 154, 255, 0.2); padding-bottom: 16px; }
    .ts-modal-header h2 { margin: 0; font-size: 1.5rem; color: var(--page-white); }

    .ts-modal-body { flex: 1; overflow-y: auto; margin-right: 8px; padding-right: 8px; }
    .ts-modal-body::-webkit-scrollbar { width: 6px; }
    .ts-modal-body::-webkit-scrollbar-track { background: rgba(100, 154, 255, 0.1); border-radius: 3px; }
    .ts-modal-body::-webkit-scrollbar-thumb { background: rgba(77, 225, 193, 0.3); border-radius: 3px; }
    .ts-modal-body::-webkit-scrollbar-thumb:hover { background: rgba(77, 225, 193, 0.5); }

    .ts-modal-body h3 { color: var(--page-white); margin-top: 20px; margin-bottom: 12px; font-size: 1.1rem; }
    .ts-modal-body p, .ts-modal-body ul { color: rgba(205, 219, 255, 0.8); line-height: 1.6; margin-bottom: 12px; font-size: 0.95rem; }

    .ts-modal-footer { display: flex; gap: 12px; justify-content: flex-end; align-items: center; border-top: 1px solid rgba(100, 154, 255, 0.2); padding-top: 20px; }

    .ts-checkbox-wrapper { background: rgba(77, 225, 193, 0.08); border: 1px solid rgba(77, 225, 193, 0.3); border-radius: 12px; padding: 16px; margin-bottom: 0; display: flex; align-items: center; gap: 12px; }
    .ts-checkbox { width: 20px; height: 20px; cursor: pointer; accent-color: var(--page-mint); }
    .ts-checkbox-label { color: rgba(205, 219, 255, 0.8); font-size: 0.9rem; cursor: pointer; }

    .ts-modal-actions { display: flex; gap: 12px; justify-content: flex-end; }

    .ts-btn { padding: 10px 16px; border-radius: 10px; border: 1px solid rgba(100, 154, 255, 0.08); background: transparent; color: var(--page-white); cursor: pointer; }
    .ts-btn.primary, .btn-primary { background: linear-gradient(135deg, var(--page-mint), #2ec4b6); color: #030922; border: none; font-weight: 700; }
    .btn-secondary { background: transparent; border: 1px solid rgba(100,154,255,0.12); color: var(--page-white); padding: 10px 14px; border-radius: 8px; }
    
    body.ts-modal-open .page-shell,
    body.ts-modal-open header,
    body.ts-modal-open nav.mobile-fintech-footer {
      visibility: hidden !important;
      opacity: 0 !important;
      pointer-events: none !important;
    }

    @media (max-width: 768px) {
      main {
        padding: 24px 16px;
      }

      .hero-section {
        padding: 24px;
      }

      .form-section {
        padding: 24px;
      }

      .hero-content h1 {
        font-size: 1.5rem;
      }

      .mobile-fintech-footer {
        display: flex;
      }
    }
  </style>
</head>
<body>
  <?php include 'header2.php'; ?>

  <div class="page-shell">
    <main>
      <a href="dashboard.php" class="back-link">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <path d="M19 12H5M12 19l-7-7 7-7"/>
        </svg>
        Back to Dashboard
      </a>

      <div class="hero-section">
        <div class="hero-content">
          <h1>Post Stream Ad</h1>
          <p>Upload your audio track and reach listeners across popular music streaming platforms. Users will listen to your track and visit your platform to earn rewards.</p>
        </div>
      </div>

      <div class="form-section">
        <form method="POST" enctype="multipart/form-data" class="task-form" id="streamAdForm">
          <input type="hidden" name="action" value="upload_stream_ad" />
          <input type="hidden" name="audio_duration" id="audioDuration" value="0" />

          <div class="form-group">
            <label for="trackTitle">Track Title <span style="color: #FF6B6B;">*</span></label>
            <input type="text" id="trackTitle" name="track_title" placeholder="Enter track title" required />
            <small>The name of your audio track</small>
          </div>

          <div class="form-group">
            <label for="artistName">Artist Name <span style="color: #FF6B6B;">*</span></label>
            <input type="text" id="artistName" name="artist_name" placeholder="Enter artist name" required />
            <small>The artist or creator of the track</small>
          </div>

          <div class="form-group">
            <label for="album">Album (Optional)</label>
            <input type="text" id="album" name="album" placeholder="Enter album name" />
            <small>The album this track belongs to (optional)</small>
          </div>

          <div class="form-group">
            <label for="audioFile">Audio File <span style="color: #FF6B6B;">*</span></label>
            <input type="file" id="audioFile" name="audio_file" accept=".mp3,.wav,.ogg,.m4a,.mp4" required />
            <small>Upload your audio file (mp3, wav, ogg, m4a, mp4). Duration will be detected automatically.</small>
            <div id="audioDurationDisplay" style="display: none; margin-top: 8px; color: var(--page-mint); font-weight: 600;">
              Duration: <span id="durationText">0:00</span>
            </div>
          </div>

          <div class="form-group">
            <label for="platform">Platform <span style="color: #FF6B6B;">*</span></label>
            <select id="platform" name="platform" required>
              <option value="">Select platform</option>
              <?php foreach ($platform_prices as $key => $data): ?>
                <option value="<?php echo htmlspecialchars($key); ?>" data-price="<?php echo $data['price']; ?>">
                  <?php echo htmlspecialchars($data['name']); ?> - ₦<?php echo number_format($data['price']); ?>/10 participants
                </option>
              <?php endforeach; ?>
            </select>
            <small>Choose the streaming platform where users will listen to your track</small>
          </div>

          <div class="form-group">
            <label for="participants">Participants <span style="color: #FF6B6B;">*</span></label>
            <input type="number" id="participants" name="participants" value="10" min="10" max="1000" step="10" required />
            <small>Number of users you want to reach (minimum 10, maximum 1000)</small>
          </div>

          <div class="form-group">
            <label for="coverImage">Cover Image (Optional)</label>
            <input type="file" id="coverImage" name="cover_image" accept="image/*" />
            <small>Upload a cover image for your track (jpg, png, gif, webp)</small>
          </div>

          <div class="form-group">
            <label for="adRedirectLink">Ad Redirect Link <span style="color: #FF6B6B;">*</span></label>
            <input type="url" id="adRedirectLink" name="ad_redirect_link" placeholder="https://spotify.com/your-track" required />
            <small>The link where users will be redirected after listening (must match selected platform)</small>
          </div>

          <div class="pricing-summary" id="pricingSummary">
            <h3>Cost Summary</h3>
            <div class="summary-row">
              <span>Platform:</span>
              <span id="selectedPlatform">Not selected</span>
            </div>
            <div class="summary-row">
              <span>Price per 10 participants:</span>
              <span id="pricePerTen">₦0.00</span>
            </div>
            <div class="summary-row">
              <span>Participants:</span>
              <span id="participantCount">10</span>
            </div>
            <div class="summary-row total">
              <span>Total Cost:</span>
              <span id="totalCost">₦0.00</span>
            </div>
            <div class="summary-row" style="border-top: 1px solid rgba(77, 225, 193, 0.15); padding-top: 12px; margin-top: 8px;">
              <span>Your Prime Wallet Balance:</span>
              <span style="color: var(--page-mint); font-weight: 700;">₦<?php echo number_format($user_data['referral_earnings'], 2); ?></span>
            </div>
          </div>

          <button type="submit" class="submit-btn">Post Stream Ad</button>
        </form>
      </div>
    </main>
  </div>

  <!-- Post Stream Ad Terms Modal -->
  <div id="stream-ad-terms-modal" class="ts-modal" aria-hidden="true" role="dialog">
    <div class="ts-modal-content" role="document">
      <div class="ts-modal-header">
        <h2>Post Stream Ad Guidelines</h2>
      </div>
      <div class="ts-modal-body">
        <p><strong>Earnova Digital – Post Stream Ad Terms & Conditions</strong></p>

        <h3>1. Introduction</h3>
        <p>By posting a stream ad, you agree to these terms and confirm that you have the legal right to distribute the audio content. You also confirm that the content does not infringe on any copyrights, trademarks, or third-party intellectual property rights.</p>

        <h3>2. Content Ownership & Rights</h3>
        <p>You warrant that you are the rightful owner of the audio track or have obtained all necessary permissions and licenses to use and distribute it. Earnova is not responsible for any copyright violations or legal issues arising from your uploaded content.</p>

        <h3>3. Content Rules</h3>
        <p>Do not upload content that is illegal, sexually explicit, hateful, violent, or otherwise violates our community standards. Earnova reserves the right to remove content and suspend accounts that breach these terms without prior notice.</p>

        <h3>4. Rewards Distribution</h3>
        <p>Rewards are distributed to users who listen to your audio ad according to our published reward structure. You acknowledge that Earnova determines reward amounts and distribution mechanisms at its sole discretion.</p>

        <h3>5. Platform Compliance</h3>
        <p>You must ensure that your redirect link matches the selected platform and complies with that platform's terms of service. Earnova is not responsible for any account suspensions or actions taken by third-party platforms.</p>

        <h3>6. Payment & Refunds</h3>
        <p>All payments for stream ads are non-refundable once the ad goes live. By submitting payment, you agree to these terms and acknowledge that participants will be assigned to listen to your track.</p>

        <h3>7. Prohibited Content</h3>
        <p>You may not upload content that promotes illegal activities, contains malware, violates privacy rights, or misrepresents your identity or affiliation. Violation of these rules may result in permanent account suspension.</p>

        <h3>8. Liability</h3>
        <p>Earnova is not liable for any damages, losses, or legal issues arising from your uploaded content or its distribution. You indemnify Earnova against any claims related to your audio ad.</p>
      </div>
      <div class="ts-modal-footer">
        <div class="ts-checkbox-wrapper">
          <input type="checkbox" id="streamAdTsCheckbox" class="ts-checkbox" <?php echo $stream_ad_post_agreed ? 'checked disabled' : ''; ?> />
          <label for="streamAdTsCheckbox" class="ts-checkbox-label">I agree to the Post Stream Ad Terms</label>
        </div>
        <div class="ts-modal-actions">
          <button class="btn-secondary" id="streamAdTsCloseBtn" onclick="closeStreamAdTermsModal()" style="<?php echo $stream_ad_post_agreed ? 'display: block;' : 'display: none;'; ?>">Close</button>
          <button class="btn-primary" id="streamAdTsAgreeBtn" onclick="agreeStreamAdTermsAndClose(this)" style="<?php echo $stream_ad_post_agreed ? 'display: none;' : 'display: block;'; ?>">Agree &amp; Continue</button>
        </div>
      </div>
    </div>
  </div>

  <script>
    // Audio duration detection
    document.getElementById('audioFile').addEventListener('change', function(e) {
      const file = e.target.files[0];
      if (file) {
        const audio = document.createElement('audio');
        const reader = new FileReader();
        
        reader.onload = function(ev) {
          audio.src = ev.target.result;
          audio.addEventListener('loadedmetadata', function() {
            const duration = Math.round(audio.duration);
            document.getElementById('audioDuration').value = duration;
            
            const minutes = Math.floor(duration / 60);
            const seconds = duration % 60;
            document.getElementById('durationText').textContent = minutes + ':' + (seconds < 10 ? '0' : '') + seconds;
            document.getElementById('audioDurationDisplay').style.display = 'block';
          });
        };
        
        reader.readAsDataURL(file);
      }
    });

    // Calculate pricing
    function updatePricing() {
      const platformSelect = document.getElementById('platform');
      const participantsInput = document.getElementById('participants');
      
      if (!platformSelect.value) {
        document.getElementById('selectedPlatform').textContent = 'Not selected';
        document.getElementById('pricePerTen').textContent = '₦0.00';
        document.getElementById('totalCost').textContent = '₦0.00';
        return;
      }
      
      const selectedOption = platformSelect.options[platformSelect.selectedIndex];
      const platformName = selectedOption.textContent.split(' - ')[0];
      const pricePerTen = parseFloat(selectedOption.dataset.price);
      const participants = parseInt(participantsInput.value);
      
      const totalCost = (participants / 10) * pricePerTen;
      
      document.getElementById('selectedPlatform').textContent = platformName;
      document.getElementById('pricePerTen').textContent = '₦' + pricePerTen.toFixed(2);
      document.getElementById('participantCount').textContent = participants;
      document.getElementById('totalCost').textContent = '₦' + totalCost.toFixed(2);
    }

    document.getElementById('platform').addEventListener('change', updatePricing);
    document.getElementById('participants').addEventListener('input', updatePricing);

    // Stream Ad Terms modal functions
    function openStreamAdTermsModal() {
      const el = document.getElementById('stream-ad-terms-modal');
      if (el) el.classList.add('active');
      document.body.classList.add('ts-modal-open');
    }

    function closeStreamAdTermsModal() {
      const el = document.getElementById('stream-ad-terms-modal');
      if (el) el.classList.remove('active');
      document.body.classList.remove('ts-modal-open');
    }

    function agreeStreamAdTermsAndClose(btn) {
      if (!btn) return;
      btn.disabled = true;
      const oldText = btn.textContent;
      btn.textContent = 'Agreeing...';

      fetch(window.location.href, {
        method: 'POST',
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        body: 'ajax=1&action=agree_stream_ad_terms'
      }).then(r => r.json()).then(data => {
        if (data && data.success) {
          showToast(data.message || 'Agreed to terms', 'success');
          closeStreamAdTermsModal();
          setTimeout(() => { location.reload(); }, 700);
        } else {
          showToast((data && data.message) ? data.message : 'Unable to record agreement', 'error');
          btn.disabled = false;
          btn.textContent = oldText;
        }
      }).catch(err => {
        console.error(err);
        showToast('Network error while saving agreement', 'error');
        btn.disabled = false;
        btn.textContent = oldText;
      });
    }

    // Open modal automatically if user hasn't agreed yet
    document.addEventListener('DOMContentLoaded', function() {
      const hasAgreed = <?php echo ($stream_ad_post_agreed ? 'true' : 'false'); ?>;
      if (!hasAgreed) {
        setTimeout(openStreamAdTermsModal, 220);
      }
    });

    // Toast notification
    function showToast(message, type) {
      const toast = document.createElement('div');
      toast.className = 'alert-message alert-' + type;
      toast.textContent = message;
      document.body.appendChild(toast);
      
      setTimeout(() => {
        toast.classList.add('show');
      }, 100);
      
      setTimeout(() => {
        toast.classList.remove('show');
        setTimeout(() => {
          document.body.removeChild(toast);
        }, 600);
      }, 3000);
    }

    <?php if ($message): ?>
      showToast('<?php echo addslashes($message); ?>', '<?php echo $messageType; ?>');
    <?php endif; ?>
  </script>
</body>
</html>
