<?php
session_start();
require_once 'config/database.php';

// Check if user just registered
if (!isset($_SESSION['new_user_id'])) {
    header('Location: register.php');
    exit();
}

$user_id = $_SESSION['new_user_id'];
$error = '';
$success = '';

// Handle survey submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $how_heard = trim($_POST['how_heard'] ?? '');
    $country = trim($_POST['country'] ?? 'Nigeria');
    // Validation
    if (empty($how_heard)) {
        $error = 'Please tell us how you heard about us';
    } elseif (empty($country)) {
        $error = 'Please select your country';
    } else {
        try {
            $pdo = getDBConnection();
            if (!$pdo) {
                throw new Exception('Database connection failed');
            }
            if (!$user_id) {
                throw new Exception('User ID not found in session');
            }
            $stmt = $pdo->prepare("UPDATE users SET how_heard = ?, country = ? WHERE id = ?");
            if (!$stmt) {
                throw new Exception('Failed to prepare statement: ' . $pdo->errorInfo()[2]);
            }
            $execute_result = $stmt->execute([$how_heard, $country, $user_id]);
            if (!$execute_result) {
                throw new Exception('Execute failed: ' . $stmt->errorInfo()[2]);
            }
            unset($_SESSION['new_user_id']);
            $_SESSION['user_id'] = $user_id;
            $success = 'Account created successfully! Redirecting...';
        } catch (Exception $e) {
            $error = 'Failed to save survey data. Please try again.';
            error_log("Survey error for user_id=$user_id: " . $e->getMessage());
        }
    }
}
?>
<?php include "doctype.php"; ?>
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; }
        
        body {
            font-family: "Titillium Web", "Segoe UI", sans-serif;
            background: radial-gradient(circle at 0% 0%, rgba(61, 116, 255, 0.28), transparent 55%),
                        radial-gradient(circle at 100% 0%, rgba(77, 225, 193, 0.18), transparent 45%),
                        linear-gradient(180deg, #030922, #0a164a);
            color: #f5f9ff;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        
        .survey-container {
            max-width: 540px;
            width: 100%;
            background: rgba(13, 24, 62, 0.84);
            border: 1px solid rgba(86, 139, 241, 0.3);
            border-radius: 26px;
            padding: 48px 40px;
            box-shadow: 0 40px 120px rgba(4, 10, 36, 0.65);
        }
        
        .logo {
            text-align: center;
            margin-bottom: 32px;
        }
        
        .logo h1 {
            font-size: 2.4rem;
            letter-spacing: 0.1em;
            text-transform: uppercase;
            background: linear-gradient(135deg, #2c5bf5, #4de1c1);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }
        
        .step-container {
            display: none;
        }
        
        .step-container.active {
            display: block;
            animation: fadeIn 0.5s ease;
        }
        
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }
        
        .step-title {
            font-size: 1.5rem;
            margin-bottom: 12px;
            letter-spacing: 0.05em;
        }
        
        .step-description {
            color: rgba(205, 219, 255, 0.7);
            margin-bottom: 24px;
            line-height: 1.6;
        }
        
        .form-group {
            margin-bottom: 24px;
        }
        
        label {
            display: block;
            margin-bottom: 8px;
            font-size: 0.9rem;
            letter-spacing: 0.08em;
            text-transform: uppercase;
            color: rgba(205, 219, 255, 0.7);
        }
        
        input, select, textarea {
            width: 100%;
            padding: 14px 16px;
            border: 1px solid rgba(99, 149, 255, 0.26);
            border-radius: 16px;
            background: rgba(5, 12, 36, 0.82);
            color: #f5f9ff;
            font-size: 1rem;
            transition: border-color 0.3s, box-shadow 0.3s;
        }
        
        input:focus, select:focus, textarea:focus {
            outline: none;
            border-color: #4de1c1;
            box-shadow: 0 0 0 3px rgba(77, 225, 193, 0.2);
        }
        
        .btn-primary, .btn-secondary {
            border: none;
            border-radius: 18px;
            padding: 16px 26px;
            font-weight: 600;
            letter-spacing: 0.05em;
            text-transform: uppercase;
            cursor: pointer;
            transition: transform 0.3s, box-shadow 0.3s;
            font-size: 1rem;
            width: 100%;
        }
        
        .btn-primary {
            background: linear-gradient(135deg, rgba(47, 91, 234, 0.95), rgba(77, 225, 193, 0.85));
            color: #030922;
            box-shadow: 0 24px 55px rgba(40, 90, 230, 0.45);
        }
        
        .btn-secondary {
            background: rgba(35, 70, 190, 0.62);
            color: #f5f9ff;
            border: 1px solid rgba(115, 166, 255, 0.4);
            margin-top: 12px;
        }
        
        .btn-primary:hover, .btn-secondary:hover {
            transform: translateY(-4px);
        }
        
        .alert {
            padding: 14px 16px;
            border-radius: 14px;
            margin-bottom: 24px;
            font-size: 0.9rem;
        }
        
        .alert-error {
            background: rgba(239, 68, 68, 0.15);
            border: 1px solid rgba(239, 68, 68, 0.3);
            color: #fca5a5;
        }
        
        .skip-text {
            text-align: center;
            margin-top: 16px;
            color: rgba(205, 219, 255, 0.6);
            font-size: 0.85rem;
        }

        /* === Step Circle Indicator === */
.step-indicator {
  position: relative;
  text-align: center;
 
  
}

.step-circle {
  width: 80px;
  height: 80px;
  background: linear-gradient(135deg, #2c5bf5, #4de1c1);
  color: #030922;
  border-radius: 50%;
    position: relative;
     top: -100px;
  display: flex;
  align-items: center;
  justify-content: center;
  font-weight: 800;
  font-size: 1.8rem;
  margin: 0 auto;
  box-shadow: 0 0 35px rgba(77, 225, 193, 0.5), inset 0 0 25px rgba(44, 91, 245, 0.4);
  animation: glowPulse 2s infinite alternate;
}

@keyframes glowPulse {
  from {
    box-shadow: 0 0 15px rgba(77, 225, 193, 0.3), inset 0 0 10px rgba(44, 91, 245, 0.2);
  }
  to {
    box-shadow: 0 0 45px rgba(77, 225, 193, 0.8), inset 0 0 35px rgba(44, 91, 245, 0.5);
  }
}

.mandatory-text {
  text-align: center;
  color: rgba(255, 140, 140, 0.8);
  font-size: 0.85rem;
  margin-bottom: 10px;
  opacity: 0;
  transition: opacity 0.3s;
}
.btn-primary[disabled] {
  opacity: 0.5;
  cursor: not-allowed;
  box-shadow: none;
}

/* Custom select styles */
.custom-select .selected-display:focus { outline: none; box-shadow: 0 0 0 4px rgba(77,225,193,0.08); }
.dropdown-list .dropdown-item { padding:10px 12px;border-radius:10px;cursor:pointer;color:#f5f9ff;border:1px solid transparent; }
.dropdown-list .dropdown-item:hover, .dropdown-list .dropdown-item.active { background: linear-gradient(90deg, rgba(77,225,193,0.06), rgba(44,91,245,0.04)); border-color: rgba(77,225,193,0.06); }
.dropdown-list .dropdown-item[aria-selected="true"] { background: linear-gradient(90deg, rgba(77,225,193,0.12), rgba(44,91,245,0.06));font-weight:700; }

    </style>
</head>
<body>
    <div class="survey-container">
        <div class="logo">
            <img src="logo.png" alt="Logo" style="height: 50px; width: auto;">
            <p style="color: rgba(205, 219, 255, 0.7); margin-top: 8px;">Welcome! Let's get to know you</p>
        </div>
        
        <?php if ($error): ?>
            <div class="alert alert-error"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>
        
        <form method="POST" action="" id="surveyForm">
            <!-- Step indicator -->
            <div class="step-indicator" style="display:flex;gap:12px;align-items:center;justify-content:center;margin-bottom:18px;">
                <div id="step1Indicator" style="flex:1;max-width:220px;text-align:center;">
                    <div style="width:44px;height:44px;border-radius:50%;margin:0 auto 8px;display:flex;align-items:center;justify-content:center;background:rgba(255,255,255,0.06);border:2px solid rgba(77,225,193,0.12);color:#4de1c1;font-weight:700;">1</div>
                    <div style="font-size:0.8rem;color:rgba(205,219,255,0.7);">How you heard</div>
                </div>
                <div style="width:40px;height:2px;background:rgba(205,219,255,0.06);"></div>
                <div id="step2Indicator" style="flex:1;max-width:220px;text-align:center;">
                    <div style="width:44px;height:44px;border-radius:50%;margin:0 auto 8px;display:flex;align-items:center;justify-content:center;background:rgba(255,255,255,0.02);border:2px solid rgba(255,255,255,0.06);color:rgba(205,219,255,0.5);font-weight:700;">2</div>
                    <div style="font-size:0.8rem;color:rgba(205,219,255,0.5);">Country</div>
                </div>
            </div>

            <!-- Step 1 -->
            <div class="step-container active" data-step="1">
                <h2 class="step-title">How did you hear about us?</h2>
                <p class="step-description">This helps us understand how to reach more people like you.</p>
                <p class="step-description" style="color: red;">This step is mandatory</p>

                <div class="form-group">
                    <label for="how_heard">Select one *</label>

                    <div class="custom-select" id="customHowSelect" style="position:relative;">
                        <input type="hidden" name="how_heard" id="howInput" value="" required>
                        <div class="selected-display" id="howSelected" tabindex="0" style="padding:12px 16px;border-radius:16px;border:1px solid rgba(99,149,255,0.26);background:rgba(5,12,36,0.82);color:#f5f9ff;display:flex;align-items:center;justify-content:space-between;cursor:pointer;">
                            <span id="howSelectedText">-- Choose an option --</span>
                            <span style="opacity:0.8">▾</span>
                        </div>
                    </div>
                </div>

                <div style="display:flex;gap:12px;">
                    <button type="button" class="btn-secondary" id="nextToCountry">Next</button>
                </div>
            </div>

            <!-- Step 2 -->
            <div class="step-container" data-step="2">
                <h2 class="step-title">Select your country</h2>
                <p class="step-description">Choose your country. You can search to find it quickly.</p>

                <div class="form-group">
                    <label for="country">Select Country *</label>

                    <div class="custom-select" id="customCountrySelect" style="position:relative;">
                        <input type="hidden" name="country" id="countryInput" value="Nigeria" required>
                        <div class="selected-display" id="countrySelected" tabindex="0" style="padding:12px 16px;border-radius:16px;border:1px solid rgba(99,149,255,0.26);background:rgba(5,12,36,0.82);color:#f5f9ff;display:flex;align-items:center;justify-content:space-between;cursor:pointer;">
                            <span id="countrySelectedText">Nigeria</span>
                            <span style="opacity:0.8">▾</span>
                        </div>

                        <div class="dropdown" id="countryDropdown" aria-hidden="true" style="position:absolute;left:0;right:0;top:calc(100% + 8px);background:rgba(5,12,36,0.98);border:1px solid rgba(77,225,193,0.08);border-radius:14px;padding:12px;box-shadow:0 20px 60px rgba(4,10,36,0.6);max-height:300px;overflow:auto;display:none;z-index:50;">
                            <input type="search" id="countryDropdownSearch" placeholder="Search country..." style="width:100%;padding:10px 12px;border-radius:12px;border:1px solid rgba(77,225,193,0.06);background:rgba(5,12,36,0.9);color:#f5f9ff;margin-bottom:10px;">

                            <div class="dropdown-list" id="countryList" style="display:flex;flex-direction:column;gap:6px;">
                                <div class="dropdown-item" data-value="Nigeria">Nigeria</div>
                                <div class="dropdown-item" data-value="Algeria">Algeria</div>
                                <div class="dropdown-item" data-value="Angola">Angola</div>
                                <div class="dropdown-item" data-value="Benin">Benin</div>
                                <div class="dropdown-item" data-value="Botswana">Botswana</div>
                                <div class="dropdown-item" data-value="Burkina Faso">Burkina Faso</div>
                                <div class="dropdown-item" data-value="Burundi">Burundi</div>
                                <div class="dropdown-item" data-value="Cabo Verde">Cabo Verde</div>
                                <div class="dropdown-item" data-value="Cameroon">Cameroon</div>
                                <div class="dropdown-item" data-value="Central African Republic">Central African Republic</div>
                                <div class="dropdown-item" data-value="Chad">Chad</div>
                                <div class="dropdown-item" data-value="Comoros">Comoros</div>
                                <div class="dropdown-item" data-value="Congo">Congo</div>
                                <div class="dropdown-item" data-value="DR Congo">DR Congo</div>
                                <div class="dropdown-item" data-value="Djibouti">Djibouti</div>
                                <div class="dropdown-item" data-value="Egypt">Egypt</div>
                                <div class="dropdown-item" data-value="Equatorial Guinea">Equatorial Guinea</div>
                                <div class="dropdown-item" data-value="Eritrea">Eritrea</div>
                                <div class="dropdown-item" data-value="Eswatini">Eswatini</div>
                                <div class="dropdown-item" data-value="Ethiopia">Ethiopia</div>
                                <div class="dropdown-item" data-value="Gabon">Gabon</div>
                                <div class="dropdown-item" data-value="Gambia">Gambia</div>
                                <div class="dropdown-item" data-value="Ghana">Ghana</div>
                                <div class="dropdown-item" data-value="Guinea">Guinea</div>
                                <div class="dropdown-item" data-value="Guinea-Bissau">Guinea-Bissau</div>
                                <div class="dropdown-item" data-value="Ivory Coast">Ivory Coast</div>
                                <div class="dropdown-item" data-value="Kenya">Kenya</div>
                                <div class="dropdown-item" data-value="Lesotho">Lesotho</div>
                                <div class="dropdown-item" data-value="Liberia">Liberia</div>
                                <div class="dropdown-item" data-value="Libya">Libya</div>
                                <div class="dropdown-item" data-value="Madagascar">Madagascar</div>
                                <div class="dropdown-item" data-value="Malawi">Malawi</div>
                                <div class="dropdown-item" data-value="Mali">Mali</div>
                                <div class="dropdown-item" data-value="Mauritania">Mauritania</div>
                                <div class="dropdown-item" data-value="Mauritius">Mauritius</div>
                                <div class="dropdown-item" data-value="Morocco">Morocco</div>
                                <div class="dropdown-item" data-value="Mozambique">Mozambique</div>
                                <div class="dropdown-item" data-value="Namibia">Namibia</div>
                                <div class="dropdown-item" data-value="Niger">Niger</div>
                                <div class="dropdown-item" data-value="Rwanda">Rwanda</div>
                                <div class="dropdown-item" data-value="Sao Tome and Principe">Sao Tome and Principe</div>
                                <div class="dropdown-item" data-value="Senegal">Senegal</div>
                                <div class="dropdown-item" data-value="Seychelles">Seychelles</div>
                                <div class="dropdown-item" data-value="Sierra Leone">Sierra Leone</div>
                                <div class="dropdown-item" data-value="Somalia">Somalia</div>
                                <div class="dropdown-item" data-value="South Africa">South Africa</div>
                                <div class="dropdown-item" data-value="South Sudan">South Sudan</div>
                                <div class="dropdown-item" data-value="Sudan">Sudan</div>
                                <div class="dropdown-item" data-value="Tanzania">Tanzania</div>
                                <div class="dropdown-item" data-value="Togo">Togo</div>
                                <div class="dropdown-item" data-value="Tunisia">Tunisia</div>
                                <div class="dropdown-item" data-value="Uganda">Uganda</div>
                                <div class="dropdown-item" data-value="Zambia">Zambia</div>
                                <div class="dropdown-item" data-value="Zimbabwe">Zimbabwe</div>
                            </div>
                        </div>
                    </div>
                </div>

                <div style="display:flex;gap:12px;">
                    <button type="button" class="btn-secondary" id="backToHow">Back</button>
                    <button type="submit" class="btn-primary" id="completeBtn">Complete Signup</button>
                </div>
            </div>
        </form>

        <!-- Success Popup -->
        <div id="successPopup" class="popup-overlay">
            <div class="popup-box">
                <div class="success-animation">
                    <div class="checkmark">
                        <svg viewBox="0 0 52 52">
                            <path d="M14 27l7 7 17-17" fill="none" stroke="#4de1c1" stroke-width="5" stroke-linecap="round" stroke-linejoin="round"/>
                        </svg>
                    </div>
                </div>
                <h2>Account Creation Successful</h2>
                <p>Your account has been created successfully.<br>Redirecting you to your dashboard...</p>
                <div class="countdown">Redirecting in <span id="countdownTimer">4</span>s</div>
            </div>
        </div>

        <style>
.popup-overlay {
  position: fixed;
  top: 0; left: 0;
  width: 100%; height: 100%;
  background: rgba(5, 12, 36, 0.9);
  backdrop-filter: blur(8px);
  display: none;
  align-items: center;
  justify-content: center;
  z-index: 9999;
}

.popup-box {
  text-align: center;
  background: linear-gradient(180deg, #08163d, #030922);
  border: 1px solid rgba(77,225,193,0.2);
  border-radius: 24px;
  padding: 60px 40px;
  max-width: 400px;
  width: 90%;
  color: #f5f9ff;
  box-shadow: 0 20px 70px rgba(4,10,36,0.7);
  animation: fadeInPopup 0.6s ease;
}

@keyframes fadeInPopup {
  from { opacity: 0; transform: scale(0.95); }
  to { opacity: 1; transform: scale(1); }
}

.success-animation {
  margin-bottom: 24px;
}

.checkmark {
  width: 80px;
  height: 80px;
  border-radius: 50%;
  border: 3px solid rgba(77,225,193,0.3);
  display: flex;
  align-items: center;
  justify-content: center;
  margin: 0 auto 20px;
  animation: pulseGlow 1.6s infinite;
}

@keyframes pulseGlow {
  0% { box-shadow: 0 0 0 0 rgba(77,225,193,0.3); }
  70% { box-shadow: 0 0 0 20px rgba(77,225,193,0); }
  100% { box-shadow: 0 0 0 0 rgba(77,225,193,0); }
}

.popup-box h2 {
  font-size: 1.6rem;
  background: linear-gradient(135deg, #4de1c1, #2c5bf5);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  margin-bottom: 12px;
}

.popup-box p {
  color: rgba(205, 219, 255, 0.8);
  line-height: 1.6;
  margin-bottom: 20px;
}

.countdown {
  font-weight: 600;
  color: #4de1c1;
  letter-spacing: 0.05em;
  font-size: 1rem;
}
</style>

    </div>

        <style>
        /* Fullscreen overlay select */
        #selectOverlay {
            position: fixed; inset: 0; z-index: 99999; display: none; align-items: center; justify-content: center; background: rgba(3,9,30,0.88); backdrop-filter: blur(6px);
        }
        #selectOverlay .overlay-box { width: 100%; max-width:900px; margin: 40px; background: linear-gradient(180deg,#071233,#07102b); border-radius:20px; padding:28px; border:1px solid rgba(77,225,193,0.06); box-shadow:0 30px 90px rgba(2,6,24,0.8); color:#f5f9ff; }
        #selectOverlay .overlay-header{ display:flex;align-items:center;gap:12px;margin-bottom:14px }
        #selectOverlay .overlay-logo img{ height:40px }
        #selectOverlay .overlay-title{ font-size:1.4rem; font-weight:700 }
        #selectOverlay .overlay-search{ margin:12px 0 }
        #selectOverlay .overlay-list{ max-height:420px; overflow:auto; display:flex;flex-direction:column; gap:6px; padding:6px }
        #selectOverlay .overlay-item{ padding:12px 14px;border-radius:12px; cursor:pointer; border:1px solid transparent }
        #selectOverlay .overlay-item:hover, #selectOverlay .overlay-item.active{ background: linear-gradient(90deg, rgba(77,225,193,0.06), rgba(44,91,245,0.04)); border-color: rgba(77,225,193,0.06); }
        #selectOverlay .overlay-close{ margin-left:auto; cursor:pointer; opacity:0.8 }
        </style>

        <div id="selectOverlay">
            <div class="overlay-box">
                <div class="overlay-header">
                    <div class="overlay-logo"><img src="logo.png" alt="Logo"></div>
                    <div class="overlay-title" id="overlayTitle">Select</div>
                    <div class="overlay-steps" style="margin-left:12px;color:rgba(205,219,255,0.6);">Step <span id="overlayStepNum">1</span> of 2</div>
                    <div class="overlay-close" id="overlayClose">✕</div>
                </div>
                <div id="overlayDesc" style="color:rgba(205,219,255,0.7);margin-bottom:8px">Choose an option</div>
                <div class="overlay-search">
                    <input type="search" id="overlaySearch" placeholder="Search..." style="width:100%;padding:12px;border-radius:12px;border:1px solid rgba(77,225,193,0.06);background:rgba(5,12,36,0.9);color:#f5f9ff;">
                    <div id="overlayHint" style="color:rgba(205,219,255,0.6);font-size:0.9rem;margin-top:8px;display:none">Tip: Press Enter to select the highlighted item.</div>
                </div>
                <div id="overlayNoResults" style="display:none;color:#fca5a5;margin-top:8px">No countries were found that match your search.</div>
                <div class="overlay-list" id="overlayList"></div>
            </div>
        </div>

        <script>
        <?php if ($success): ?>
            // Show success popup
            document.addEventListener('DOMContentLoaded', () => {
                const popup = document.getElementById('successPopup');
                const timer = document.getElementById('countdownTimer');
                let countdown = 4;

                popup.style.display = 'flex';

                const interval = setInterval(() => {
                    countdown--;
                    timer.textContent = countdown;
                    if (countdown <= 0) {
                        clearInterval(interval);
                        window.location.href = 'dashboard.php';
                    }
                }, 1000);
            });
        <?php endif; ?>

        // Step navigation + full-screen overlay select handler
        document.addEventListener('DOMContentLoaded', function() {
            const stepContainers = document.querySelectorAll('.step-container');
            const nextBtn = document.getElementById('nextToCountry');
            const backBtn = document.getElementById('backToHow');
            const step1Indicator = document.getElementById('step1Indicator');
            const step2Indicator = document.getElementById('step2Indicator');
            const howSelected = document.getElementById('howSelected');
            const howSelectedText = document.getElementById('howSelectedText');
            const howInput = document.getElementById('howInput');

            // country elements
            const countryInput = document.getElementById('countryInput');
            const countrySelected = document.getElementById('countrySelected');
            const countrySelectedText = document.getElementById('countrySelectedText');

            // overlay elements
            const overlay = document.getElementById('selectOverlay');
            const overlayTitle = document.getElementById('overlayTitle');
            const overlayDesc = document.getElementById('overlayDesc');
            const overlaySearch = document.getElementById('overlaySearch');
            const overlayList = document.getElementById('overlayList');
            const overlayHint = document.getElementById('overlayHint');
            const overlayStepNum = document.getElementById('overlayStepNum');
            const overlayClose = document.getElementById('overlayClose');

            const howOptions = [
                {v: 'social_media', t: 'Social Media (Instagram, Twitter, Facebook)'},
                {v: 'friend_referral', t: 'Friend or Family Referral'},
                {v: 'search_engine', t: 'Search Engine (Google, Bing)'},
                {v: 'youtube', t: 'YouTube'},
                {v: 'tiktok', t: 'TikTok'},
                {v: 'whatsapp', t: 'WhatsApp'},
                {v: 'telegram', t: 'Telegram'},
                {v: 'advertisement', t: 'Online Advertisement'},
                {v: 'blog_article', t: 'Blog or Article'},
                {v: 'other', t: 'Other'}
            ];

            const countries = Array.from(document.querySelectorAll('#countryList .dropdown-item')).map(d => ({ v: d.getAttribute('data-value'), t: d.textContent.trim() }));

            let currentMode = null; // 'how' or 'country'
            let items = [];
            let highlightedIndex = -1;

            function showStep(n) {
                stepContainers.forEach(el => {
                    el.classList.toggle('active', el.getAttribute('data-step') === String(n));
                });
                // indicator styles
                if (n === 1) {
                    const s1 = step1Indicator.querySelector('div');
                    const s2 = step2Indicator.querySelector('div');
                    s1.style.borderColor = 'rgba(77,225,193,0.12)';
                    s1.style.background = '#1c2b5a';
                    s1.style.color = '#4de1c1';
                    s2.style.borderColor = 'rgba(255,255,255,0.06)';
                    s2.style.background = '';
                    s2.style.color = 'rgba(205,219,255,0.5)';
                } else {
                    const s1 = step1Indicator.querySelector('div');
                    const s2 = step2Indicator.querySelector('div');
                    s1.style.borderColor = 'rgba(255,255,255,0.06)';
                    s1.style.background = '';
                    s1.style.color = 'rgba(205,219,255,0.5)';
                    s2.style.borderColor = 'rgba(77,225,193,0.12)';
                    s2.style.background = '#1c2b5a';
                    s2.style.color = '#4de1c1';
                }
            }

            nextBtn && nextBtn.addEventListener('click', function() {
                if (!howInput.value) {
                    alert('Please select how you heard about us before continuing.');
                    return;
                }
                showStep(2);
                // do not auto-open overlay; user must manually select country
            });

            backBtn && backBtn.addEventListener('click', function() {
                showStep(1);
            });

            // overlay functions
            function openOverlay(mode) {
                currentMode = mode;
                // ensure the visible onboarding step matches the overlay mode
                showStep(mode === 'how' ? 1 : 2);
                overlay.style.display = 'flex';
                overlay.setAttribute('aria-hidden', 'false');
                overlayStepNum.textContent = mode === 'how' ? '1' : '2';
                overlayTitle.textContent = mode === 'how' ? '' : '';
                overlayDesc.textContent = mode === 'how' ? 'Tell us how you heard about Earnova' : 'Choose your country. Search to find it quickly.';
                // show/hide search and hint depending on mode (how has no search)
                if (mode === 'how') {
                    overlaySearch.style.display = 'none';
                    if (overlayHint) overlayHint.style.display = 'none';
                } else {
                    overlaySearch.style.display = '';
                    overlaySearch.value = '';
                    if (overlayHint) overlayHint.style.display = '';
                }
                populatedOverlayList(mode === 'how' ? howOptions : countries);
                if (mode === 'country') overlaySearch.focus();
            }

            function closeOverlay() {
                overlay.style.display = 'none';
                overlay.setAttribute('aria-hidden', 'true');
                highlightedIndex = -1;
            }

            function populatedOverlayList(list) {
                overlayList.innerHTML = '';
                items = [];
                list.forEach((it, idx) => {
                    const div = document.createElement('div');
                    div.className = 'overlay-item';
                    div.setAttribute('data-value', it.v);
                    div.textContent = it.t;
                    div.tabIndex = 0;
                    div.addEventListener('click', function() {
                        applySelection(it.v, it.t);
                    });
                    div.addEventListener('keydown', function(e) { if (e.key === 'Enter') div.click(); });
                    overlayList.appendChild(div);
                    items.push(div);
                });
            }

            function applySelection(value, text) {
                if (currentMode === 'how') {
                    howInput.value = value;
                    howSelectedText.textContent = text;
                } else if (currentMode === 'country') {
                    countryInput.value = value;
                    countrySelectedText.textContent = text;
                }
                closeOverlay();
            }

            // overlay search
            overlaySearch && overlaySearch.addEventListener('input', function() {
                const q = overlaySearch.value.toLowerCase().trim();
                let firstVisible = null;
                items.forEach(it => {
                    const match = it.textContent.toLowerCase().includes(q);
                    it.style.display = match ? '' : 'none';
                    if (match && !firstVisible) firstVisible = it;
                });
                const noResultsEl = document.getElementById('overlayNoResults');
                if (firstVisible) {
                    items.forEach(i=> i.classList.remove('active'));
                    firstVisible.classList.add('active');
                    highlightedIndex = items.indexOf(firstVisible);
                    // DO NOT auto-apply selection; user must click or press Enter
                    if (noResultsEl) noResultsEl.style.display = 'none';
                } else {
                    if (noResultsEl) noResultsEl.style.display = '';
                }
            });

            // keyboard nav in overlay
            overlayList && overlayList.addEventListener('keydown', function(e) {
                const visible = items.filter(it => it.style.display !== 'none');
                if (!visible.length) return;
                if (e.key === 'ArrowDown') {
                    e.preventDefault(); highlightedIndex = (highlightedIndex + 1) % visible.length; items.forEach(i=> i.classList.remove('active')); visible[highlightedIndex].classList.add('active'); visible[highlightedIndex].scrollIntoView({block:'nearest'});
                } else if (e.key === 'ArrowUp') {
                    e.preventDefault(); highlightedIndex = (highlightedIndex - 1 + visible.length) % visible.length; items.forEach(i=> i.classList.remove('active')); visible[highlightedIndex].classList.add('active'); visible[highlightedIndex].scrollIntoView({block:'nearest'});
                } else if (e.key === 'Enter') {
                    e.preventDefault(); if (highlightedIndex >= 0 && visible[highlightedIndex]) visible[highlightedIndex].click();
                }
            });

            overlayClose && overlayClose.addEventListener('click', closeOverlay);
            // close overlay on Escape
            document.addEventListener('keydown', function(e){ if (e.key === 'Escape') closeOverlay(); });

            // clicking the howSelected/countrySelected opens overlay in correct mode
            howSelected && howSelected.addEventListener('click', function() { openOverlay('how'); });
            countrySelected && countrySelected.addEventListener('click', function() { openOverlay('country'); });

            // initialize selected values if present
            if (howInput && howInput.value) {
                const v = howInput.value; const found = howOptions.find(h => h.v === v);
                if (found) howSelectedText.textContent = found.t;
            }
            if (countryInput && countryInput.value) {
                const v = countryInput.value; const found = countries.find(c => c.v === v);
                if (found) countrySelectedText.textContent = found.t;
            }

            // Form submission validation
            const surveyForm = document.getElementById('surveyForm');
            surveyForm && surveyForm.addEventListener('submit', function(e) {
                if (!howInput.value) {
                    e.preventDefault();
                    alert('Please select how you heard about us');
                    return false;
                }
                if (!countryInput.value) {
                    e.preventDefault();
                    alert('Please select your country');
                    return false;
                }
                console.log('Form submitting with values - how_heard:', howInput.value, 'country:', countryInput.value);
            });

            // initialize indicators
            showStep(1);
        });
    </script>
</body>
</html>
