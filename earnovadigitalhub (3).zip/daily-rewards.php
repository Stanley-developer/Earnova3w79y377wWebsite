<?php
session_start();
require_once 'config/database.php';
require_once 'includes/session.php';
require_once 'includes/connect.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$user_id = $_SESSION['user_id'];

$stmt = $conn->prepare("SELECT username, full_name, email, membership_type FROM users WHERE id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();
$stmt->close();

$is_premium = ($user['membership_type'] === 'premium' || $user['membership_type'] === 'senior');
$show_premium_popup = false;

$today = date('Y-m-d');
$stmt = $conn->prepare("SELECT * FROM daily_rewards WHERE user_id = ? AND reward_date = ?");
$stmt->bind_param("is", $user_id, $today);
$stmt->execute();
$claimed_today = $stmt->get_result()->fetch_assoc();
$stmt->close();

$daily_reward_amount = ($user['membership_type'] === 'premium') ? 100.00 : 100.00;

$stmt = $conn->prepare("
    SELECT COUNT(*) as streak 
    FROM daily_rewards 
    WHERE user_id = ? 
    AND reward_date >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)
    ORDER BY reward_date DESC
");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$streak_result = $stmt->get_result()->fetch_assoc();
$current_streak = $streak_result['streak'];
$stmt->close();

$stmt = $conn->prepare("SELECT SUM(reward_amount) as total_claimed FROM daily_rewards WHERE user_id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$total_result = $stmt->get_result()->fetch_assoc();
$total_claimed = $total_result['total_claimed'] ?? 0;
$stmt->close();

$claim_message = '';
$claim_success = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['claim_reward'])) {
    if (!$is_premium) {
        $show_premium_popup = true;
        $claim_message = 'Premium membership required to claim daily rewards.';
    } elseif ($claimed_today) {
        $claim_message = 'Already claimed! Come back tomorrow.';
    } else {
        // Start transaction
        $conn->begin_transaction();
        
        try {
            // Insert daily reward claim
            $stmt = $conn->prepare("INSERT INTO daily_rewards (user_id, reward_date, reward_amount) VALUES (?, ?, ?)");
            $stmt->bind_param("isd", $user_id, $today, $daily_reward_amount);
            $stmt->execute();
            $stmt->close();
            
            // Update task_earnings balance
            $stmt = $conn->prepare("UPDATE balances SET task_earnings = task_earnings + ?, total_balance = total_balance + ? WHERE user_id = ?");
            $stmt->bind_param("ddi", $daily_reward_amount, $daily_reward_amount, $user_id);
            $stmt->execute();
            $stmt->close();
            
            // Create transaction record
            $description = "Daily login reward claimed - Day " . ($current_streak + 1);
            $stmt = $conn->prepare("INSERT INTO transactions (user_id, transaction_type, amount, balance_type, description) VALUES (?, 'daily_reward', ?, 'task', ?)");
            $stmt->bind_param("ids", $user_id, $daily_reward_amount, $description);
            $stmt->execute();
            $stmt->close();
            
            $conn->commit();
            
            $claim_success = true;
            $claim_message = "Reward claimed! Good job!";
            $claimed_today = true;
            $current_streak++;
            $total_claimed += $daily_reward_amount;
            
        } catch (Exception $e) {
            $conn->rollback();
            $claim_message = 'Error claiming reward.';
        }
    }
}

$next_claim_time = strtotime('tomorrow midnight');
$hours_until_next = floor(($next_claim_time - time()) / 3600);
$minutes_until_next = floor((($next_claim_time - time()) % 3600) / 60);
?>

<link rel="stylesheet" href="assets/css/gamified-fintech-theme.css">
<?php include "doctype.php"; ?>
  <style>
    :root {
      --page-blue-900: #030922;
      --page-blue-700: #0a164a;
      --page-blue-500: #142a7e;
      --page-blue-300: #2c5bf5;
      --page-mint: #4de1c1;
      --page-white: #f5f9ff;
      --panel-glass: rgba(13, 24, 62, 0.78);
      --panel-border: rgba(86, 139, 241, 0.3);
      --shadow-heavy: 0 40px 120px rgba(4, 10, 36, 0.65);
      --transition-long: 0.85s cubic-bezier(0.19, 1, 0.22, 1);
      --transition-short: 0.4s ease;
      --rewards-gold: #fbbf24;
      --rewards-amber: #f59e0b;
      --rewards-orange: #fb923c;
    }

    * { box-sizing: border-box; }

    body {
      margin: 0;
      font-family: "Titillium Web", "Segoe UI", sans-serif;
      background: var(--bg-primary);
      color: var(--page-white);
      overflow-x: hidden;
    }

    .page-shell { 
      min-height: 100vh; 
      display: flex;
    }

    aside {
      position: fixed;
      left: 0;
      top: 0;
      bottom: 0;
      width: 320px;
      background: rgba(13, 24, 62, 0.78);
      backdrop-filter: blur(18px);
      padding: clamp(1.25rem, 3vw, 2.25rem) clamp(1rem, 2.5vw, 2rem);
      display: flex;
      flex-direction: column;
      gap: clamp(1.25rem, 2.5vw, 2rem);
      border-right: 1px solid var(--panel-border);
      overflow-y: auto;
      z-index: 100;
      transition: transform var(--transition-short);
    }

    aside::before {
      content: "";
      position: absolute;
      inset: 0;
      background: 
        radial-gradient(circle at 20% 30%, rgba(251, 191, 36, 0.15), transparent 50%),
        radial-gradient(circle at 80% 70%, rgba(245, 158, 11, 0.12), transparent 45%);
      pointer-events: none;
    }

    main {
      margin-left: 320px;
      flex: 1;
      padding: clamp(2rem, 4vw, 2.625rem) clamp(1.5rem, 3vw, 3rem);
      display: grid;
      gap: clamp(2rem, 3.5vw, 2.625rem);
    }

    @media (max-width: 960px) {
      .page-shell {
        display: block;
      }

      aside {
        position: relative;
        top: 0;
        width: 100%;
        height: auto;
        border-right: none;
        border-bottom: 1px solid var(--panel-border);
        padding: clamp(1rem, 2.5vw, 1.75rem) clamp(0.875rem, 2vw, 1.25rem);
        gap: clamp(0.875rem, 2vw, 1.25rem);
      }

      aside.scrolled .page-title,
      aside.scrolled .side-description,
      aside.scrolled .vector-cluster {
        display: none;
      }

      aside.scrolled {
        padding: clamp(0.75rem, 1.5vw, 1rem) clamp(0.875rem, 2vw, 1.25rem);
      }

      aside.scrolled .aside-welcome {
        grid-template-columns: auto 1fr;
      }

      main {
        margin-left: 0;
        padding: clamp(1.5rem, 3vw, 2rem) clamp(0.625rem, 1.5vw, 1.25rem) 10rem;
      }

      .vector-cluster {
        display: none;
      }
    }

    .back-link {
      display: inline-flex;
      align-items: center;
      gap: 10px;
      font-weight: 600;
      font-size: clamp(0.75rem, 1.5vw, 0.875rem);
      letter-spacing: 0.1em;
      text-transform: uppercase;
      color: rgba(210, 226, 255, 0.78);
      transition: color var(--transition-short), transform var(--transition-short);
      text-decoration: none;
    }

    .back-link:hover { color: var(--page-white); transform: translateX(-4px); }

    .page-title {
      font-size: clamp(1rem, 3vw, 1.5rem);
      letter-spacing: 0.1em;
      text-transform: uppercase;
      margin: 0 0 clamp(0.5rem, 1vw, 0.75rem);
      font-weight: 700;
    }

    .side-description { 
      color: rgba(206, 224, 255, 0.74); 
      line-height: 1.7; 
      font-size: clamp(0.875rem, 1.5vw, 1rem);
    }

    .vector-cluster {
      position: relative;
      border-radius: 24px;
      padding: clamp(1rem, 2vw, 1.5rem);
      background: 
        linear-gradient(135deg, rgba(251, 191, 36, 0.3), rgba(217, 119, 6, 0.6)),
        rgba(12, 29, 82, 0.9);
      box-shadow: var(--shadow-heavy);
      overflow: hidden;
    }

    .vector-cluster::after {
      content: "";
      position: absolute;
      width: 320px;
      height: 320px;
      top: -150px;
      right: -120px;
      border-radius: 50%;
      background: radial-gradient(circle, rgba(245, 158, 11, 0.35), transparent 60%);
    }

    .vector-cluster img {
      width: 100%;
      border-radius: 18px;
      display: block;
      filter: drop-shadow(0 28px 80px rgba(251, 191, 36, 0.4));
    }

    .aside-welcome {
      display: grid;
      grid-template-columns: auto 1fr;
      align-items: center;
      gap: clamp(0.75rem, 1.5vw, 1rem);
      background: linear-gradient(135deg, rgba(44, 91, 245, 0.3), rgba(26, 58, 171, 0.2));
      border: 1px solid rgba(44, 91, 245, 0.5);
      box-shadow: 0 0 10px rgba(44, 91, 245, 0.6);
      border-radius: 20px;
      padding: clamp(0.875rem, 1.75vw, 1.125rem);
      position: relative;
      z-index: 2;

      
    }

    .aside-avatar {
      width: clamp(48px, 10vw, 64px);
      height: clamp(48px, 10vw, 64px);
      border-radius: 50%;
      overflow: hidden;
      border: 4px solid rgba(251, 191, 36, 0.35);
      box-shadow: 0 14px 34px rgba(3, 9, 30, 0.55);
    }

    .aside-avatar img {
      width: 100%;
      display: block;
    }

    .welcome-tag {
      margin: 0;
      font-size: clamp(0.6875rem, 1.25vw, 0.75rem);
      letter-spacing: 0.12em;
      text-transform: uppercase;
      color: rgba(205, 219, 255, 0.62);
    }

    .aside-welcome h3 {
      margin: clamp(0.25rem, 0.5vw, 0.375rem) 0 clamp(0.125rem, 0.25vw, 0.25rem);
      font-size: clamp(1rem, 2vw, 1.12rem);
      letter-spacing: 0.04em;
      color: var(--page-white);
      font-weight: 700;
    }

    .welcome-meta {
      font-size: clamp(0.75rem, 1.5vw, 0.8rem);
      letter-spacing: 0.08em;
      color: rgba(149, 183, 255, 0.7);
    }

    .rewards-hero {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
      gap: clamp(1.25rem, 2.5vw, 1.75rem);
      align-items: center;
      background: var(--panel-glass);
      border-radius: 26px;
      border: 1px solid var(--panel-border);
      padding: clamp(1.75rem, 3vw, 2.375rem);
      box-shadow: var(--shadow-heavy);
      position: relative;
      overflow: hidden;
    }

    .rewards-hero::before {
      content: "";
      position: absolute;
      inset: 0;
      background: url("front/assets/images/header-right-img.png") right/contain no-repeat;
      opacity: 0.08;
    }

    .rewards-copy { position: relative; z-index: 2; }

    .rewards-copy h1 { 
      margin: 0 0 clamp(0.5rem, 1vw, 0.75rem); 
      font-size: clamp(1.75rem, 4vw, 2.4rem);
      font-weight: 700;
    }

    .rewards-copy p { 
      margin: 0; 
      color: rgba(218, 231, 255, 0.78); 
      line-height: 1.7; 
      font-size: clamp(0.875rem, 1.5vw, 1rem);
    }

    .claim-section {
      background: rgba(9, 23, 66, 0.9);
      border: 1px solid var(--panel-border);
      border-radius: 24px;
      padding: clamp(1.75rem, 3vw, 2.375rem);
      box-shadow: var(--shadow-heavy);
      display: grid;
      gap: clamp(1.25rem, 2.5vw, 1.75rem);
      text-align: center;
      position: relative;
      overflow: hidden;
    }

    .claim-section::before {
      content: "";
      position: absolute;
      inset: 0;
      background: radial-gradient(circle at 50% 50%, rgba(251, 191, 36, 0.15), transparent 70%);
      pointer-events: none;
    }

    .reward-amount {
      font-size: clamp(3rem, 6vw, 4.5rem);
      font-weight: 700;
      background: linear-gradient(135deg, var(--rewards-gold), var(--rewards-orange));
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
      background-clip: text;
      margin: 0;
      position: relative;
      z-index: 2;
    }

    .claim-btn {
      border: none;
      border-radius: 20px;
      padding: clamp(1rem, 2vw, 1.25rem) clamp(1.5rem, 3vw, 2rem);
      font-weight: 700;
      font-size: clamp(1rem, 2vw, 1.125rem);
      letter-spacing: 0.04em;
      text-transform: uppercase;
      cursor: pointer;
      background: linear-gradient(135deg, var(--rewards-gold), var(--rewards-amber));
      color: var(--page-blue-900);
      border: 2px solid rgba(251, 191, 36, 0.4);
      transition: transform var(--transition-short), box-shadow var(--transition-short);
      box-shadow: 0 20px 60px rgba(251, 191, 36, 0.4);
      position: relative;
      z-index: 2;
    }

    .claim-btn:hover { 
      transform: translateY(-4px); 
      box-shadow: 0 25px 70px rgba(251, 191, 36, 0.5);
    }

    .claim-btn:disabled {
      background: rgba(100, 116, 139, 0.5);
      color: rgba(203, 213, 225, 0.6);
      cursor: not-allowed;
      border-color: rgba(100, 116, 139, 0.3);
      box-shadow: none;
    }

    .stats-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(min(100%, 200px), 1fr));
      gap: clamp(1rem, 2vw, 1.375rem);
    }

    .stat-card {
      padding: clamp(1.25rem, 2.5vw, 1.5rem);
      border-radius: 20px;
      background: rgba(6, 16, 48, 0.9);
      border: 1px solid rgba(100, 154, 255, 0.24);
      box-shadow: var(--shadow-heavy);
      position: relative;
      overflow: hidden;
    }

    .stat-card::after {
      content: "";
      position: absolute;
      width: 110px;
      height: 110px;
      top: -26px;
      right: -16px;
      border-radius: 50%;
      background: radial-gradient(circle, rgba(251, 191, 36, 0.28), transparent 60%);
    }

    .stat-label {
      font-size: clamp(0.75rem, 1.5vw, 0.875rem);
      letter-spacing: 0.08em;
      text-transform: uppercase;
      color: rgba(205, 219, 255, 0.7);
      margin-bottom: clamp(0.5rem, 1vw, 0.75rem);
    }

    .stat-value {
      font-size: clamp(1.5rem, 3vw, 2rem);
      font-weight: 700;
      color: var(--rewards-gold);
    }

    .ticker {
      border-radius: 24px;
      border: 1px solid rgba(251, 191, 36, 0.32);
      background: rgba(8, 18, 52, 0.78);
      padding: clamp(0.875rem, 1.5vw, 1rem);
      box-shadow: var(--shadow-heavy);
      overflow: hidden;
    }

    .ticker-track {
      display: inline-flex;
      gap: 42px;
      animation: tickerMove 30s linear infinite;
      letter-spacing: 0.16em;
      text-transform: uppercase;
      color: rgba(204, 228, 255, 0.82);
      font-weight: 600;
      font-size: clamp(0.75rem, 1.5vw, 0.875rem);
      white-space: nowrap;
    }

    @keyframes tickerMove { from { transform: translateX(0); } to { transform: translateX(-50%); } }



      
    /* Updated mobile footer with 5 icons */
    .mobile-fintech-footer {
      display: none;
      position: fixed;
      left: 12px;
      right: 12px;
      bottom: 16px;
      padding: 10px;
      background: transparent;
      border: 1px solid rgba(86, 139, 241, 0.35);
      border-radius: 32px;
      backdrop-filter: blur(50px);
      box-shadow: 0 20px 60px rgba(4, 10, 36, 0.7);
      justify-content: space-around;
      align-items: center;
      z-index: 90;
    }

    .mobile-fintech-footer a {
      flex: 1;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      gap: 4px;
      text-decoration: none;
      color: rgba(205, 219, 255, 0.75);
      font-size: 0.45rem;
      letter-spacing: 0.06em;
      text-transform: uppercase;
      transition: all var(--transition-short);
      padding: 8px 4px;
      border-radius: 16px;
    }

    /* Special styling for middle icon (3rd icon - Withdraw) */
    /* .mobile-fintech-footer a:nth-child(3) {
      position: relative;
      transform: translateY(-12px);
    } */

    .mobile-fintech-footer a:nth-child(3) .icon-wrapper {
      width: 56px;
      height: 56px;
      border-radius: 50%;
      background: linear-gradient(135deg, rgba(77, 225, 193, 0.25), rgba(47, 91, 234, 0.25));
      backdrop-filter: blur(12px);
      border: 2px solid rgba(77, 225, 193, 0.4);
      display: flex;
      align-items: center;
      justify-content: center;
      box-shadow: 0 8px 24px rgba(77, 225, 193, 0.3);
    }

    .mobile-fintech-footer a:nth-child(3) svg {
      width: 28px;
      height: 28px;
    }

    .mobile-fintech-footer a.active {
      color: var(--page-mint);
    }

    .mobile-fintech-footer svg {
      width: 22px;
      height: 22px;
      fill: currentColor;
      filter: drop-shadow(0 4px 12px rgba(4, 10, 36, 0.4));
    }

    .mobile-fintech-footer a:hover {
      color: var(--page-mint);
      transform: translateY(-2px);
    }

    .mobile-fintech-footer a:nth-child(3):hover {
      transform: translateY(-14px);
    }

    @media (max-width: 680px) {
      body {
        padding-bottom: 100px;
      }

      .mobile-fintech-footer {
        display: flex;
      }
    }


    footer {
      padding: clamp(2rem, 4vw, 3rem) 0 clamp(1.5rem, 3vw, 2.25rem);
      background: linear-gradient(180deg, rgba(1, 5, 16, 0.95), rgba(1, 4, 12, 0.98));
      border-top: 1px solid rgba(86, 136, 230, 0.2);
    }

    .footer-grid {
      max-width: 1020px;
      margin: 0 auto;
      padding: 0 clamp(1rem, 2.5vw, 2rem);
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(160px, 1fr));
      gap: clamp(1rem, 2vw, 1.5rem);
    }

    .footer-list h4 {
      text-transform: uppercase;
      letter-spacing: 0.12em;
      font-size: clamp(0.75rem, 1.5vw, 0.82rem);
      margin-bottom: clamp(0.75rem, 1.5vw, 1rem);
      color: rgba(181, 201, 240, 0.76);
      font-weight: 600;
    }

    .footer-list ul {
      list-style: none;
      padding: 0;
      margin: 0;
      display: grid;
      gap: clamp(0.625rem, 1.25vw, 0.75rem);
    }

    .footer-list a {
      color: rgba(210, 224, 253, 0.7);
      font-size: clamp(0.8125rem, 1.5vw, 0.9rem);
      transition: color var(--transition-short);
      text-decoration: none;
    }

    .footer-list a:hover { color: var(--page-mint); }

    .footer-brand {
      text-align: center;
      text-transform: uppercase;
      letter-spacing: 0.14em;
      color: rgba(160, 180, 226, 0.68);
      margin-top: clamp(1.5rem, 3vw, 2rem);
      font-size: clamp(0.6875rem, 1.25vw, 0.76rem);
    }


    /* Toast Base Style */
.claim-message {
  position: fixed;
  top: 20px;
  right: -400px; /* Start hidden off-screen */
  padding: 16px 24px;
  border-radius: 12px;
  color: white;
  font-family: 'Segoe UI', sans-serif;
  font-size: 15px;
  z-index: 1000;
  opacity: 0;
  box-shadow: 0 10px 40px rgba(0, 0, 0, 0.2);
  transition: right 0.6s ease, opacity 0.6s ease;
}

/* Success Toast */
.claim-message.success {
  background: rgba(77, 225, 193, 0.95);
  color: #030922;
  box-shadow: 0 10px 40px rgba(77, 225, 193, 0.4);
}

/* Error Toast */
.claim-message.error {
  background: rgba(255, 77, 77, 0.95);
  color: #fff;
  box-shadow: 0 10px 40px rgba(255, 77, 77, 0.4);
}

/* Active (slide-in) */
.claim-message.show {
  right: 20px;
  opacity: 1;
}

    /* Premium popup styles from chat-earn.php */
    .premium-popup-overlay {
      display: none;
      position: fixed;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      background: rgba(3, 9, 34, 0.95);
      backdrop-filter: blur(10px);
      z-index: 9999;
      align-items: center;
      justify-content: center;
      animation: fadeIn 0.3s ease;
    }

    .premium-popup-overlay.active {
      display: flex;
    }

    .premium-popup {
      background: linear-gradient(135deg, #0d1b3e 0%, #1a2847 100%);
      border: 2px solid var(--page-mint);
      border-radius: 32px;
      padding: 48px 40px;
      max-width: 500px;
      width: 90%;
      text-align: center;
      box-shadow: 0 30px 80px rgba(0, 0, 0, 0.6);
      animation: popupSlide 0.4s ease;
      position: relative;
      overflow: hidden;
    }

    .premium-popup::before {
      content: "";
      position: absolute;
      top: -50%;
      left: -50%;
      width: 200%;
      height: 200%;
      background: radial-gradient(circle, rgba(77, 225, 193, 0.1) 0%, transparent 70%);
      animation: rotate 20s linear infinite;
    }
    
    .free-user-content {
      background: rgba(6, 16, 48, 0.98);
      border: 1px solid rgba(100, 154, 255, 0.3);
      border-radius: 24px;
      padding: 32px;
      max-width: 500px;
      width: 100%;
      text-align: center;
    }
    
    .free-user-content svg {
      width: 80px;
      height: 80px;
      margin-bottom: 24px;
      color: #fbbf24;
    }
    
    .free-user-content h2 {
      margin: 0 0 16px;
      font-size: 1.5rem;
      color: var(--page-white);
    }
    
    .free-user-content p {
      color: rgba(205, 219, 255, 0.7);
      line-height: 1.7;
      margin-bottom: 24px;
    }
    
    .upgrade-btn {
      display: inline-block;
      padding: 14px 32px;
      background: linear-gradient(135deg, #fbbf24, #f59e0b);
      color: #000;
      border-radius: 12px;
      text-decoration: none;
      font-weight: 700;
      font-size: 1rem;
      text-transform: uppercase;
      letter-spacing: 0.05em;
      transition: all 0.3s ease;
      margin-right: 12px;
    }
    
    .upgrade-btn:hover {
      transform: translateY(-2px);
      box-shadow: 0 8px 24px rgba(251, 191, 36, 0.4);
    }
    
    .close-modal-btn {
      display: inline-block;
      padding: 14px 32px;
      background: rgba(100, 154, 255, 0.2);
      color: var(--page-white);
      border-radius: 12px;
      text-decoration: none;
      font-weight: 600;
      font-size: 1rem;
      cursor: pointer;
      transition: all 0.3s ease;
    }
    
    .close-modal-btn:hover {
      background: rgba(100, 154, 255, 0.3);
    }

    @keyframes fadeIn {
      from { opacity: 0; }
      to { opacity: 1; }
    }

    @keyframes popupSlide {
      from {
        opacity: 0;
        transform: scale(0.8) translateY(20px);
      }
      to {
        opacity: 1;
        transform: scale(1) translateY(0);
      }
    }

    @keyframes rotate {
      from { transform: rotate(0deg); }
      to { transform: rotate(360deg); }
    }

    .lock-icon {
      width: 80px;
      height: 80px;
      margin: 0 auto 24px;
      background: linear-gradient(135deg, rgba(77, 225, 193, 0.2) 0%, rgba(45, 92, 230, 0.2) 100%);
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      position: relative;
      z-index: 1;
    }

    .lock-icon svg {
      width: 40px;
      height: 40px;
      fill: var(--page-mint);
    }

    .premium-popup h2 {
      font-size: 2rem;
      margin: 0 0 16px 0;
      color: var(--page-white);
      position: relative;
      z-index: 1;
    }

    .premium-popup p {
      font-size: 1.05rem;
      color: rgba(216, 230, 255, 0.8);
      margin: 0 0 32px 0;
      line-height: 1.6;
      position: relative;
      z-index: 1;
    }

    .premium-upgrade-btn {
      background: linear-gradient(135deg, var(--page-mint) 0%, #2bc9a8 100%);
      color: #030922;
      border: none;
      padding: 16px 48px;
      border-radius: 16px;
      font-size: 1.1rem;
      font-weight: 700;
      cursor: pointer;
      text-decoration: none;
      display: inline-block;
      transition: all 0.3s ease;
      box-shadow: 0 10px 30px rgba(77, 225, 193, 0.3);
      position: relative;
      z-index: 1;
    }

    .premium-upgrade-btn:hover {
      transform: translateY(-2px);
      box-shadow: 0 15px 40px rgba(77, 225, 193, 0.4);
    }

    .premium-popup ul {
      text-align: left;
      margin: 20px 0;
      padding-left: 24px;
      line-height: 2;
      position: relative;
      z-index: 1;
    }
  </style>
</head>
<body>

<?php include "embed.php"; ?>
<?php include "header2.php"; ?>

<?php if ($claim_message): ?>
  <div id="claim-toast" class="claim-message <?php echo $claim_success ? 'success' : 'error'; ?>">
    <?php echo htmlspecialchars($claim_message); ?>
  </div>
<?php endif; ?>

  <div class="page-shell">
   
    <main>
      <section class="rewards-hero" style="background: linear-gradient(135deg, rgba(77, 225, 193, 0.08), rgba(13, 24, 62, 0.78));">
        <div class="rewards-copy">
          <h1 style="font-size: clamp(1rem, 3vw, 1.5rem);">Daily Login Rewards</h1>
          <p>Claim your daily reward every 24 hours. Premium members earn double rewards! Build your streak and maximize your earnings.</p>
        </div>
      </section>

      <section class="claim-section">
        <h2 style="margin: 0; font-size: clamp(1.25rem, 2.5vw, 1.5rem); position: relative; z-index: 2;">Today's Reward</h2>
        <div class="reward-amount">₦<?php echo number_format($daily_reward_amount, 2); ?></div>

        <form method="POST" style="position: relative; z-index: 2;">
          <button type="submit" name="claim_reward" class="claim-btn" <?php echo $claimed_today ? 'disabled' : ''; ?>>
            <?php echo $claimed_today ? 'Already Claimed Today' : 'Claim Reward Now'; ?>
          </button>
        </form>

        <?php if ($claimed_today): ?>
          <p style="color: rgba(205, 219, 255, 0.7); margin: 0; position: relative; z-index: 2;">
            Next reward available in <?php echo $hours_until_next; ?>h <?php echo $minutes_until_next; ?>m
          </p>
        <?php endif; ?>
      </section>

      <section class="stats-grid">
        <div class="stat-card">
          <div class="stat-label">Current Streak</div>
          <div class="stat-value"><?php echo $current_streak; ?> Days</div>
        </div>
        <div class="stat-card">
          <div class="stat-label">Total Claimed</div>
          <div class="stat-value">₦<?php echo number_format($total_claimed, 2); ?></div>
        </div>
        <div class="stat-card">
          <div class="stat-label">Daily Reward</div>
          <div class="stat-value">₦<?php echo number_format($daily_reward_amount, 2); ?></div>
        </div>
        <div class="stat-card">
          <div class="stat-label">Membership</div>
          <div class="stat-value"><?php echo ucfirst($user['membership_type']); ?></div>
        </div>
      </section>

      <section class="ticker">
        <div class="ticker-track">
          DAILY REWARD CLAIMED — <?php echo htmlspecialchars($user['username']); ?> • ₦<?php echo number_format($daily_reward_amount, 2); ?> ✦ 
          BUILD YOUR STREAK — Claim daily for maximum rewards ✦ 
          PREMIUM MEMBERS — Earn double rewards every day ✦ 
          DAILY REWARD CLAIMED — <?php echo htmlspecialchars($user['username']); ?> • ₦<?php echo number_format($daily_reward_amount, 2); ?> ✦
        </div>
      </section>
    </main>
  </div>

  <!-- Premium upgrade popup -->
  <div class="premium-popup-overlay <?php echo $show_premium_popup ? 'active' : ''; ?>" id="premiumPopup">
       <div class="free-user-content">
      <svg viewBox="0 0 24 24" fill="currentColor">
        <path d="M12 2L2 7l10 5 10-5-10-5zm0 18.5l-8-4v-7l8 4 8-4v7l-8 4z"/>
      </svg>
      <h2>Premium Access</h2>
      <p>Daily Rewards are exclusively available for Premium members. Upgrade now to Claim daily login rewards.</p>
      <div>
        <a href="membership.php" class="upgrade-btn">Activate Now</a>
        <button class="close-modal-btn" onclick="closePremiumPopup()">Maybe Later</button>
      </div>
      </div>
      
    <!--<div class="premium-popup">-->
    <!--  <div class="lock-icon">-->
    <!--    <svg viewBox="0 0 24 24">-->
    <!--      <path d="M18 8h-1V6c0-2.76-2.24-5-5-5S7 3.24 7 6v2H6c-1.1 0-2 .9-2 2v10c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V10c0-1.1-.9-2-2-2zm-6 9c-1.1 0-2-.9-2-2s.9-2 2-2 2 .9 2 2-.9 2-2 2zm3.1-9H8.9V6c0-1.71 1.39-3.1 3.1-3.1 1.71 0 3.1 1.39 3.1 3.1v2z"/>-->
    <!--    </svg>-->
    <!--  </div>-->
    <!--  <h2>Upgrade to Premium</h2>-->
    <!--  <p>Daily Rewards are exclusively available for Premium members. Upgrade now to Claim daily login rewards</p>-->
    <!--  <ul>-->
    <!--    <li>Claim daily login rewards automatically</li>-->
    <!--    <li>Earn up to ₦100 per day (double for Premium)</li>-->
    <!--    <li>Build streaks for bonus rewards</li>-->
    <!--    <li>Access exclusive premium features</li>-->
    <!--  </ul>-->
    <!--  <a href="membership.php" class="premium-upgrade-btn">Upgrade Now</a>-->
    <!--  <button onclick="closePremiumPopup()" style="margin-top: 16px; background: transparent; border: none; color: rgba(216, 230, 255, 0.6); cursor: pointer; font-size: 0.9rem;">Maybe Later</button>-->
    <!--</div>-->
  </div>

 <nav class="mobile-fintech-footer">
  <a href="dashboard.php">
    <svg viewBox="0 0 24 24"><path d="M12 3a9 9 0 1 1 0 18 9 9 0 0 1 0-18Zm1 4h-2v6h6v-2h-4V7Z"/></svg>
    <span>Dashboard</span>
  </a>

  <!-- Premium (crown icon) -->
  <a href="membership.php">
    <svg viewBox="0 0 24 24"><path d="M5 7l2.5 5 4.5-4 4.5 4L19 7l2 13H3l2-13Z"/></svg>
    <span>Premium</span>
  </a>

  <a href="daily-rewards.php" class="active">
    <svg viewBox="0 0 24 24"><path d="M20 3H4a1 1 0 0 0-1 1v16l5-3 5 3 5-3 5 3V4a1 1 0 0 0-1-1Zm-2 5-6.7 6.7L7 10.4l1.4-1.4 2.9 2.9L17.6 6 18 8Z"/></svg>
    <span>Rewards</span>
  </a>

  <!-- Referrals (users/people icon) -->
  <!-- <a href="refferrals.php">
    <svg viewBox="0 0 24 24"><path d="M12 12a4 4 0 1 0-4-4 4 4 0 0 0 4 4Zm0 2c-4 0-8 2-8 5v1h16v-1c0-3-4-5-8-5Zm7-6a3 3 0 1 0-3 3 3 3 0 0 0 3-3Zm-1 6a5 5 0 0 1 4 2.5v1.5h-4v-1.3a6.8 6.8 0 0 0-1.2-2.2A7.9 7.9 0 0 1 18 14Z"/></svg>
    <span>Referrals</span>
  </a> -->

  <a href="history.php">
  <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
    <path d="M13 3a9 9 0 1 0 9 9h-2a7 7 0 1 1-7-7V3l4 4-4 4V7a5 5 0 1 0 5 5h2a7 7 0 1 1-7-7z"/>
  </svg>
  <span>History</span>
</a>


  <a href="profile.php">
    <svg viewBox="0 0 24 24"><path d="M12 2a6 6 0 0 1 6 6c0 3.31-2.69 6-6 6s-6-2.69-6-6a6 6 0 0 1 6-6Zm0 14c4.42 0 8 1.79 8 4v2H4v-2c0-2.21 3.58-4 8-4Z"/></svg>
    <span>Profile</span>
  </a>
</nav>




<script>
document.addEventListener("DOMContentLoaded", () => {
  const claimToast = document.getElementById("claim-toast");

  if (claimToast) {
    // Slide in after short delay
    setTimeout(() => claimToast.classList.add("show"), 100);

    // Auto-hide after 4 seconds
    setTimeout(() => claimToast.classList.remove("show"), 4000);
  }
});

const premiumPopup = document.getElementById('premiumPopup');

function showPremiumPopup() {
  if (premiumPopup) {
    premiumPopup.classList.add('active');
  }
}

function closePremiumPopup() {
  if (premiumPopup) {
    premiumPopup.classList.remove('active');
  }
}

// Close popup when clicking outside
if (premiumPopup) {
  premiumPopup.addEventListener('click', (e) => {
    if (e.target === premiumPopup) {
      closePremiumPopup();
    }
  });
}

// Auto-show premium popup if free user tried to claim
if (<?php echo $show_premium_popup ? 'true' : 'false'; ?> && premiumPopup) {
  setTimeout(() => showPremiumPopup(), 300);
}
</script>
</body>
</html>
