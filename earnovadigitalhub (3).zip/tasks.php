<?php
require_once 'config/database.php';
require_once 'includes/session.php';
require_once 'includes/connect.php';

// Require authentication
requireLogin();
checkSessionTimeout();

// Get current user data
$user = getCurrentUser();
$userId = $user['id'];
$username = $user['username'] ?? 'User';
$membershipType = $user['membership_type'] ?? 'free';

// Get user balances
$pdo = getDBConnection();
$stmt = $pdo->prepare("SELECT * FROM balances WHERE user_id = ?");
$stmt->execute([$userId]);
$balances = $stmt->fetch();

if (!$balances) {
    // Create balance record if it doesn't exist
    $stmt = $pdo->prepare("INSERT INTO balances (user_id, task_earnings) VALUES (?, 1000.00)");
    $stmt->execute([$userId]);
    $balances = ['total_balance' => 1000.00, 'task_earnings' => 1000.00, 'referral_earnings' => 0.00];
}

// Handle task start/completion
$message = '';
$messageType = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $action = $_POST['action'];
    $taskId = intval($_POST['task_id'] ?? 0);
    
    if ($action === 'start_task' && $taskId > 0) {
        // Validate task exists and is active
        $stmt = $pdo->prepare("SELECT * FROM tasks WHERE id = ? AND is_active = 1");
        $stmt->execute([$taskId]);
        $task = $stmt->fetch();
        
        if (!$task) {
            $message = 'Task not found or no longer available';
            $messageType = 'error';
        } elseif ($task['is_premium_only'] && $membershipType !== 'premium') {
            $message = 'This task is only available for premium members';
            $messageType = 'error';
        } else {
            // Check if user already started this task
            $stmt = $pdo->prepare("SELECT * FROM user_tasks WHERE user_id = ? AND task_id = ?");
            $stmt->execute([$userId, $taskId]);
            $existingTask = $stmt->fetch();
            
            if ($existingTask) {
                $message = 'You have already started this task';
                $messageType = 'error';
            } else {
                // Create user task record
                $stmt = $pdo->prepare("INSERT INTO user_tasks (user_id, task_id, status) VALUES (?, ?, 'pending')");
                $stmt->execute([$userId, $taskId]);
                $message = 'Task started! Complete the task and submit proof.';
                $messageType = 'success';
            }
        }
    } elseif ($action === 'submit_proof' && $taskId > 0) {
        $proofUrl = trim($_POST['proof_url'] ?? '');
        
        if (empty($proofUrl)) {
            $message = 'Please provide proof URL';
            $messageType = 'error';
        } elseif (!filter_var($proofUrl, FILTER_VALIDATE_URL)) {
            $message = 'Please provide a valid URL';
            $messageType = 'error';
        } else {
            // Update user task with proof
            $stmt = $pdo->prepare("UPDATE user_tasks SET proof_url = ?, status = 'pending' WHERE user_id = ? AND task_id = ?");
            $stmt->execute([$proofUrl, $userId, $taskId]);
            $message = 'Proof submitted! Waiting for admin approval.';
            $messageType = 'success';
        }
    }
}

// Get available tasks
$tasksQuery = "SELECT t.*, 
               (SELECT COUNT(*) FROM user_tasks WHERE user_id = ? AND task_id = t.id) as user_started,
               (SELECT status FROM user_tasks WHERE user_id = ? AND task_id = t.id) as user_status
               FROM tasks t 
               WHERE t.is_active = 1";

if ($membershipType !== 'premium') {
    $tasksQuery .= " AND t.is_premium_only = 0";
}

$tasksQuery .= " ORDER BY t.created_at DESC";

$stmt = $pdo->prepare($tasksQuery);
$stmt->execute([$userId, $userId]);
$tasks = $stmt->fetchAll();

// Get user's completed tasks count
$stmt = $pdo->prepare("SELECT COUNT(*) as completed_count FROM user_tasks WHERE user_id = ? AND status = 'completed'");
$stmt->execute([$userId]);
$completedCount = $stmt->fetch()['completed_count'];

// Calculate weekly progress (assuming goal of 18 tasks)
$weeklyGoal = 100;
$weeklyProgress = min(100, ($completedCount / $weeklyGoal) * 100);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>FlowEarner Tasks</title>
  <style>
    :root {
      --page-blue-900: #030922;
      --page-blue-700: #0a164a;
      --page-blue-500: #142a7e;
      --page-blue-300: #2c5bf5;
      --page-mint: #4de1c1;
      --page-white: #f5f9ff;
      --panel-glass: rgba(13, 24, 62, 0.84);
      --panel-border: rgba(86, 139, 241, 0.3);
      --shadow-heavy: 0 40px 120px rgba(4, 10, 36, 0.65);
      --transition-long: 0.85s cubic-bezier(0.19, 1, 0.22, 1);
      --transition-short: 0.4s ease;
      --tasks-purple: #8b5cf6;
      --tasks-violet: #a78bfa;
      --tasks-lavender: #c4b5fd;
    }

    * { box-sizing: border-box; }

    body {
      margin: 0;
      font-family: "Titillium Web", "Segoe UI", sans-serif;
      background: radial-gradient(circle at 0% 0%, rgba(61, 116, 255, 0.28), transparent 55%),
                  radial-gradient(circle at 100% 0%, rgba(77, 225, 193, 0.18), transparent 45%),
                  linear-gradient(180deg, var(--page-blue-900), var(--page-blue-700));
      color: var(--page-white);
      overflow-x: hidden;
    }

    .page-shell { 
      min-height: 100vh; 
      display: flex;
    }

/*     

    aside {
      position: fixed;
      left: 0;
      top: 0;
      bottom: 0;
      width: 320px;
      background: rgba(5, 15, 44, 0.92);
      backdrop-filter: blur(18px);
      padding: clamp(1.25rem, 3vw, 2.25rem) clamp(1rem, 2.5vw, 2rem);
      display: flex;
      flex-direction: column;
      gap: clamp(1.25rem, 2.5vw, 2rem);
      border-right: 1px solid var(--panel-border);
      overflow-y: auto;
      z-index: 100;
      transition: transform var(--transition-short);
    }

    aside::before {
      content: "";
      position: absolute;
      inset: 0;
      background: 
        radial-gradient(circle at 20% 30%, rgba(139, 92, 246, 0.15), transparent 50%),
        radial-gradient(circle at 80% 70%, rgba(167, 139, 250, 0.12), transparent 45%);
      pointer-events: none;
    }

    main {
      margin-left: 320px;
      flex: 1;
      padding: clamp(2rem, 4vw, 2.625rem) clamp(1.5rem, 3vw, 3rem);
      display: grid;
      gap: clamp(2rem, 3.5vw, 2.625rem);
    }

    @media (max-width: 960px) {
      .page-shell {
        display: block;
      }

      aside {
        position: sticky;
        top: 0;
        width: 100%;
        height: auto;
        border-right: none;
        border-bottom: 1px solid var(--panel-border);
        padding: clamp(1rem, 2.5vw, 1.75rem) clamp(0.875rem, 2vw, 1.25rem);
        gap: clamp(0.875rem, 2vw, 1.25rem);
      }

      aside.scrolled .page-title,
      aside.scrolled .side-description,
      aside.scrolled .vector-cluster {
        display: none;
      }

      aside.scrolled {
        padding: clamp(0.75rem, 1.5vw, 1rem) clamp(0.875rem, 2vw, 1.25rem);
      }

      aside.scrolled .aside-welcome {
        grid-template-columns: auto 1fr;
      }

      main {
        margin-left: 0;
        padding: clamp(1.5rem, 3vw, 2rem) clamp(0.625rem, 1.5vw, 1.25rem) 10rem;
      }
    } */

      
aside {
  position: relative; /* or just remove position entirely */
 left: 0;
      top: 0;
      bottom: 0;
      width: 320px;
      background: rgba(5, 15, 44, 0.92);
      backdrop-filter: blur(18px);
      padding: clamp(1.25rem, 3vw, 2.25rem) clamp(1rem, 2.5vw, 2rem);
      display: flex;
      flex-direction: column;
      gap: clamp(1.25rem, 2.5vw, 2rem);
      border-right: 1px solid var(--panel-border);
      overflow-y: auto;
      z-index: 100;
      transition: transform var(--transition-short);
}

main {
  margin-left: 0; /* reset since aside is no longer fixed */
  flex: 1;
  padding: 32px 40px;
  display: grid;
  gap: 32px;
}



    @media (max-width: 700px) {
       .page-shell {
    flex-direction: column; /* stack sidebar on top of main */
  }

  aside {
    width: 100%; /* full width on mobile */
    border-right: none;
    border-bottom: 1px solid rgba(255, 140, 80, 0.3);
    box-shadow: 0 4px 20px rgba(255, 107, 53, 0.15);
  }

  main {
    margin-left: 0; /* already removed earlier */
    width: 100%;
  }

  .vector-cluster {
    display: none;
  }

  .page-title {
    font-size: clamp(1rem, 3vw, 1.5rem);
  }
    }

    
    .back-link {
      display: inline-flex;
      align-items: center;
      gap: 10px;
      font-weight: 600;
      font-size: clamp(0.75rem, 1.5vw, 0.875rem);
      letter-spacing: 0.1em;
      text-transform: uppercase;
      color: rgba(210, 226, 255, 0.78);
      transition: color var(--transition-short), transform var(--transition-short);
      text-decoration: none;
    }

    .back-link:hover { color: var(--page-white); transform: translateX(-4px); }

    .page-title {
      font-size: clamp(1rem, 3vw, 1.5rem);
      letter-spacing: 0.1em;
      text-transform: uppercase;
      margin: 0 0 clamp(0.5rem, 1vw, 0.75rem);
      font-weight: 700;
    }

    .side-description { 
      color: rgba(206, 224, 255, 0.74); 
      line-height: 1.7; 
      font-size: clamp(0.875rem, 1.5vw, 1rem);
    }

    .vector-cluster {
      position: relative;
      border-radius: 24px;
      padding: clamp(1rem, 2vw, 1.5rem);
      background: 
        linear-gradient(135deg, rgba(251, 191, 36, 0.3), rgba(217, 119, 6, 0.6)),
        rgba(12, 29, 82, 0.9);
      box-shadow: var(--shadow-heavy);
      overflow: hidden;
    }

    .vector-cluster::after {
      content: "";
      position: absolute;
      width: 320px;
      height: 320px;
      top: -150px;
      right: -120px;
      border-radius: 50%;
      background: radial-gradient(circle, rgba(245, 158, 11, 0.35), transparent 60%);
    }

    .vector-cluster img {
      width: 100%;
      border-radius: 18px;
      display: block;
      filter: drop-shadow(0 28px 80px rgba(251, 191, 36, 0.4));
    }


    .tasks-hero {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
      gap: clamp(1.25rem, 2.5vw, 1.75rem);
      align-items: center;
      background: var(--panel-glass);
      border-radius: 26px;
      border: 1px solid var(--panel-border);
      padding: clamp(1.75rem, 3vw, 2.375rem);
      box-shadow: var(--shadow-heavy);
      position: relative;
      overflow: hidden;
    }

    .tasks-hero::before {
      content: "";
      position: absolute;
      inset: 0;
      background: url("front/assets/images/header-right-img.png") right/contain no-repeat;
      opacity: 0.08;
    }

    .tasks-copy { position: relative; z-index: 2; }

    .tasks-copy h1 { 
      margin: 0 0 clamp(0.5rem, 1vw, 0.75rem); 
      font-size: clamp(1.75rem, 4vw, 2.4rem);
      font-weight: 700;
    }

    .tasks-copy p { 
      margin: 0; 
      color: rgba(218, 231, 255, 0.78); 
      line-height: 1.7; 
      font-size: clamp(0.875rem, 1.5vw, 1rem);
    }

    .reward-meter {
      background: rgba(9, 23, 66, 0.9);
      border: 1px solid var(--panel-border);
      border-radius: 24px;
      padding: clamp(1.25rem, 2.5vw, 1.75rem);
      box-shadow: var(--shadow-heavy);
      display: grid;
      gap: clamp(0.875rem, 1.5vw, 1.25rem);
    }

    .meter-bar {
      height: 14px;
      border-radius: 999px;
      background: rgba(23, 44, 120, 0.6);
      overflow: hidden;
    }

    .meter-fill {
      height: 100%;
      width: <?php echo round($weeklyProgress); ?>%;
      background: linear-gradient(135deg, rgba(139, 92, 246, 0.95), rgba(167, 139, 250, 0.85));
      border-radius: 999px;
      box-shadow: 0 10px 25px rgba(139, 92, 246, 0.45);
      transition: width 0.5s ease;
    }

    .task-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(min(100%, 240px), 1fr));
      gap: clamp(1rem, 2vw, 1.375rem);
    }

    .task-card {
      padding: clamp(1.25rem, 2.5vw, 1.5rem);
      border-radius: 20px;
      background: rgba(6, 16, 48, 0.9);
      border: 1px solid rgba(100, 154, 255, 0.24);
      box-shadow: var(--shadow-heavy);
      position: relative;
      overflow: hidden;
      transition: transform var(--transition-long), border-color var(--transition-short);
    }

    .task-card:hover {
      transform: translateY(-8px);
      border-color: rgba(167, 139, 250, 0.45);
    }

    .task-card::after {
      content: "";
      position: absolute;
      width: 110px;
      height: 110px;
      top: -26px;
      right: -16px;
      border-radius: 50%;
      background: radial-gradient(circle, rgba(167, 139, 250, 0.28), transparent 60%);
    }

    .task-title {
      font-size: clamp(1rem, 2vw, 1.1rem);
      font-weight: 700;
      letter-spacing: 0.03em;
      position: relative;
      z-index: 2;
    }

    .task-copy {
      color: rgba(205, 219, 255, 0.7);
      margin: clamp(0.625rem, 1.5vw, 0.75rem) 0 clamp(0.875rem, 1.75vw, 1.125rem);
      line-height: 1.68;
      font-size: clamp(0.875rem, 1.5vw, 0.9375rem);
      position: relative;
      z-index: 2;
    }

    .task-footer {
      display: flex;
      justify-content: space-between;
      align-items: center;
      gap: clamp(0.625rem, 1.5vw, 0.75rem);
      flex-wrap: wrap;
      position: relative;
      z-index: 2;
    }

    .task-footer span {
      font-weight: 600;
      font-size: clamp(0.75rem, 1.5vw, 0.875rem);
      letter-spacing: 0.08em;
      text-transform: uppercase;
      color: rgba(205, 219, 255, 0.72);
    }

    .btn-cta {
      border: none;
      border-radius: 16px;
      padding: clamp(0.625rem, 1.5vw, 0.75rem) clamp(0.875rem, 2vw, 1.125rem);
      font-weight: 600;
      font-size: clamp(0.75rem, 1.5vw, 0.875rem);
      letter-spacing: 0.04em;
      text-transform: uppercase;
      cursor: pointer;
      background: rgba(139, 92, 246, 0.72);
      color: var(--page-white);
      border: 1px solid rgba(167, 139, 250, 0.4);
      transition: transform var(--transition-short);
    }

    .btn-cta:hover { transform: translateY(-4px); }
    
    .btn-cta:disabled {
      opacity: 0.5;
      cursor: not-allowed;
    }

    .btn-completed {
      background: rgba(77, 225, 193, 0.3);
      border-color: rgba(77, 225, 193, 0.5);
    }

    .btn-pending {
      background: rgba(255, 193, 7, 0.3);
      border-color: rgba(255, 193, 7, 0.5);
    }

    .ticker {
      border-radius: 24px;
      border: 1px solid rgba(167, 139, 250, 0.32);
      background: rgba(8, 18, 52, 0.78);
      padding: clamp(0.875rem, 1.5vw, 1rem);
      box-shadow: var(--shadow-heavy);
      overflow: hidden;
    }

    .ticker-track {
      display: inline-flex;
      gap: 42px;
      animation: tickerMove 30s linear infinite;
      letter-spacing: 0.16em;
      text-transform: uppercase;
      color: rgba(204, 228, 255, 0.82);
      font-weight: 600;
      font-size: clamp(0.75rem, 1.5vw, 0.875rem);
      white-space: nowrap;
    }

    @keyframes tickerMove { from { transform: translateX(0); } to { transform: translateX(-50%); } }

    footer {
      padding: clamp(2rem, 4vw, 3rem) 0 clamp(1.5rem, 3vw, 2.25rem);
      background: linear-gradient(180deg, rgba(1, 5, 16, 0.95), rgba(1, 4, 12, 0.98));
      border-top: 1px solid rgba(86, 136, 230, 0.2);
    }

    .footer-grid {
      max-width: 1020px;
      margin: 0 auto;
      padding: 0 clamp(1rem, 2.5vw, 2rem);
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(160px, 1fr));
      gap: clamp(1rem, 2vw, 1.5rem);
    }

    .footer-list h4 {
      text-transform: uppercase;
      letter-spacing: 0.12em;
      font-size: clamp(0.75rem, 1.5vw, 0.82rem);
      margin-bottom: clamp(0.75rem, 1.5vw, 1rem);
      color: rgba(181, 201, 240, 0.76);
      font-weight: 600;
    }

    .footer-list ul {
      list-style: none;
      padding: 0;
      margin: 0;
      display: grid;
      gap: clamp(0.625rem, 1.25vw, 0.75rem);
    }

    .footer-list a {
      color: rgba(210, 224, 253, 0.7);
      font-size: clamp(0.8125rem, 1.5vw, 0.9rem);
      transition: color var(--transition-short);
      text-decoration: none;
    }

    .footer-list a:hover { color: var(--page-mint); }

    .footer-brand {
      text-align: center;
      text-transform: uppercase;
      letter-spacing: 0.14em;
      color: rgba(160, 180, 226, 0.68);
      margin-top: clamp(1.5rem, 3vw, 2rem);
      font-size: clamp(0.6875rem, 1.25vw, 0.76rem);
    }
.aside-welcome {
      display: grid;
      grid-template-columns: auto 1fr;
      align-items: center;
      gap: clamp(0.75rem, 1.5vw, 1rem);
      background: rgba(8, 21, 64, 0.92);
      border: 1px solid rgba(120, 170, 255, 0.25);
      border-radius: 20px;
      padding: clamp(0.875rem, 1.75vw, 1.125rem);
      box-shadow: 0 18px 48px rgba(3, 9, 30, 0.5);
      position: relative;
      z-index: 2;
    }

    .aside-avatar {
      width: clamp(48px, 10vw, 64px);
      height: clamp(48px, 10vw, 64px);
      border-radius: 50%;
      overflow: hidden;
      border: 4px solid rgba(251, 191, 36, 0.35);
      box-shadow: 0 14px 34px rgba(3, 9, 30, 0.55);
    }

    .aside-avatar img {
      width: 100%;
      display: block;
    }

    .welcome-tag {
      margin: 0;
      font-size: clamp(0.6875rem, 1.25vw, 0.75rem);
      letter-spacing: 0.12em;
      text-transform: uppercase;
      color: rgba(205, 219, 255, 0.62);
    }

    .aside-welcome h3 {
      margin: clamp(0.25rem, 0.5vw, 0.375rem) 0 clamp(0.125rem, 0.25vw, 0.25rem);
      font-size: clamp(1rem, 2vw, 1.12rem);
      letter-spacing: 0.04em;
      color: var(--page-white);
      font-weight: 700;
    }

    .welcome-meta {
      font-size: clamp(0.75rem, 1.5vw, 0.8rem);
      letter-spacing: 0.08em;
      color: rgba(149, 183, 255, 0.7);
    }

    .section-white {
      background: rgba(245, 249, 255, 0.96);
      border: 1px solid rgba(60, 102, 212, 0.14);
      border-radius: 26px;
      box-shadow: var(--shadow-heavy);
      padding: clamp(1.75rem, 3vw, 2.25rem);
      color: var(--page-blue-700);
      position: relative;
      overflow: hidden;
    }

    .section-white::before {
      content: "";
      position: absolute;
      inset: 0;
      background: radial-gradient(circle at 80% 20%, rgba(139, 92, 246, 0.14), transparent 60%);
    }

    .section-white h2 {
      margin-top: 0;
      color: var(--page-blue-500);
      font-size: clamp(1.25rem, 2.5vw, 1.5rem);
      font-weight: 700;
    }

    .section-white p {
      color: rgba(20, 42, 126, 0.68);
      line-height: 1.7;
      font-size: clamp(0.875rem, 1.5vw, 1rem);
    }

    .task-chip-row {
      position: relative;
      z-index: 2;
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(min(100%, 180px), 1fr));
      gap: clamp(0.875rem, 1.75vw, 1.125rem);
      margin-top: clamp(1.25rem, 2.5vw, 1.625rem);
    }

    .task-chip {
      padding: clamp(0.875rem, 1.75vw, 1.125rem);
      border-radius: 18px;
      background: rgba(139, 92, 246, 0.08);
      border: 1px solid rgba(139, 92, 246, 0.18);
      color: var(--page-blue-500);
      font-weight: 600;
      letter-spacing: 0.02em;
      display: grid;
      gap: clamp(0.25rem, 0.5vw, 0.375rem);
      font-size: clamp(0.875rem, 1.5vw, 1rem);
    }

    .task-chip span {
      font-size: clamp(0.6875rem, 1.25vw, 0.75rem);
      letter-spacing: 0.1em;
      text-transform: uppercase;
      color: rgba(20, 42, 126, 0.6);
    }

      
    /* Updated mobile footer with 5 icons */
    .mobile-fintech-footer {
      display: none;
      position: fixed;
      left: 12px;
      right: 12px;
      bottom: 16px;
      padding: 10px;
      background: rgba(5, 15, 44, 0.95);
      border: 1px solid rgba(86, 139, 241, 0.35);
      border-radius: 32px;
      backdrop-filter: blur(20px);
      box-shadow: 0 20px 60px rgba(4, 10, 36, 0.7);
      justify-content: space-around;
      align-items: center;
      z-index: 90;
    }

    .mobile-fintech-footer a {
      flex: 1;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      gap: 4px;
      text-decoration: none;
      color: rgba(205, 219, 255, 0.75);
      font-size: 0.65rem;
      letter-spacing: 0.06em;
      text-transform: uppercase;
      transition: all var(--transition-short);
      padding: 8px 4px;
      border-radius: 16px;
    }

    /* Special styling for middle icon (3rd icon - Withdraw) */
    /* .mobile-fintech-footer a:nth-child(3) {
      position: relative;
      transform: translateY(-12px);
    } */

    .mobile-fintech-footer a:nth-child(3) .icon-wrapper {
      width: 56px;
      height: 56px;
      border-radius: 50%;
      background: linear-gradient(135deg, rgba(77, 225, 193, 0.25), rgba(47, 91, 234, 0.25));
      backdrop-filter: blur(12px);
      border: 2px solid rgba(77, 225, 193, 0.4);
      display: flex;
      align-items: center;
      justify-content: center;
      box-shadow: 0 8px 24px rgba(77, 225, 193, 0.3);
    }

    .mobile-fintech-footer a:nth-child(3) svg {
      width: 28px;
      height: 28px;
    }

    .mobile-fintech-footer a.active {
      color: var(--page-mint);
    }

    .mobile-fintech-footer svg {
      width: 22px;
      height: 22px;
      fill: currentColor;
      filter: drop-shadow(0 4px 12px rgba(4, 10, 36, 0.4));
    }

    .mobile-fintech-footer a:hover {
      color: var(--page-mint);
      transform: translateY(-2px);
    }

    .mobile-fintech-footer a:nth-child(3):hover {
      transform: translateY(-14px);
    }

    @media (max-width: 680px) {
      body {
        padding-bottom: 100px;
      }

      .mobile-fintech-footer {
        display: flex;
      }
    }

    .alert {
      padding: 16px 20px;
      border-radius: 18px;
      margin-bottom: 24px;
      font-size: 0.95rem;
      font-weight: 500;
      letter-spacing: 0.02em;
    }

    .alert-success {
      background: rgba(77, 225, 193, 0.15);
      border: 1px solid rgba(77, 225, 193, 0.4);
      color: #4de1c1;
    }

    .alert-error {
      background: rgba(239, 68, 68, 0.15);
      border: 1px solid rgba(239, 68, 68, 0.4);
      color: #fca5a5;
    }

    .task-status-badge {
      display: inline-block;
      padding: 4px 12px;
      border-radius: 12px;
      font-size: 0.7rem;
      font-weight: 600;
      letter-spacing: 0.08em;
      text-transform: uppercase;
      margin-top: 8px;
    }

    .status-pending {
      background: rgba(255, 193, 7, 0.2);
      color: #ffc107;
      border: 1px solid rgba(255, 193, 7, 0.4);
    }

    .status-completed {
      background: rgba(77, 225, 193, 0.2);
      color: #4de1c1;
      border: 1px solid rgba(77, 225, 193, 0.4);
    }

    .status-rejected {
      background: rgba(239, 68, 68, 0.2);
      color: #fca5a5;
      border: 1px solid rgba(239, 68, 68, 0.4);
    }

   
 @media (max-width: 700px) {
  .tasks-hero {
    width: calc(100% - 10px);  /* subtracts 5px left + 5px right */
    margin: 0 5px;             /* 5px space on each side */
    border-radius: 18px;       /* optional rounded corners */
    padding: 1.5rem 1rem;      /* keep inner spacing readable */
    grid-template-columns: 1fr; /* stack content nicely */
  }
}


  .tasks-copy h1 {
    font-size: 1.5rem; /* smaller heading for mobile */
    text-align: center;
  }

  .tasks-copy p {
    text-align: center;
    font-size: 0.95rem;
  }

  .reward-meter {
    padding: 1rem;
  }
}

  </style>
</head>
<body>
  <div class="page-shell">
    <aside id="sidebar">
      <a class="back-link" href="dashboard.php">← Dashboard</a>
      <div class="aside-welcome">
        <div class="aside-avatar">
          <img src="front/assets/images/partners-icon4.png" alt="User avatar" />
        </div>
        <div>
          <p class="welcome-tag">Welcome back</p>
          <h3><?php echo htmlspecialchars($username); ?></h3>
          <p class="welcome-meta"><?php echo $completedCount; ?> tasks cleared</p>
        </div>
      </div>
      <div>
        <h2 class="page-title">Tasks</h2>
        <p class="side-description">Complete tasks to earn rewards and boost your wallet balance.</p>
      </div>
      <div class="vector-cluster">
        <img src="front/assets/images/header-right-img.png" alt="Tasks vector" />
      </div>
    </aside>
    <main>
      <?php if ($message): ?>
        <div class="alert alert-<?php echo $messageType; ?>">
          <?php echo htmlspecialchars($message); ?>
        </div>
      <?php endif; ?>

      <section class="tasks-hero">
        <div class="tasks-copy">
          <h1 style="font-size: 21px;">Mission Control for Earners.</h1>
          <p>FlowEarner tasks combine real-world actions with rewards. Pick a mission, complete it, and watch your earnings grow.</p>
        </div>
        <div class="reward-meter">
          <div style="display: flex; justify-content: space-between; align-items: center;">
            <span style="letter-spacing: 0.08em; text-transform: uppercase; color: rgba(205, 219, 255, 0.7); font-size: clamp(0.75rem, 1.5vw, 0.875rem);">Weekly Progress</span>
            <strong style="font-size: clamp(1.25rem, 2.5vw, 1.4rem);"><?php echo round($weeklyProgress); ?>%</strong>
          </div>
          <div class="meter-bar"><div class="meter-fill"></div></div>
          <div style="display: flex; justify-content: space-between; color: rgba(205, 219, 255, 0.7); font-weight: 600; font-size: clamp(0.75rem, 1.5vw, 0.875rem);">
            <span><?php echo $completedCount; ?> Tasks Cleared</span><!--<span>Goal: <?php //echo $weeklyGoal; ?></span> -->
          </div>
        </div>
      </section>

      <section class="task-grid">
        <?php if (empty($tasks)): ?>
          <div style="grid-column: 1 / -1; text-align: center; padding: 48px 24px;">
            <p style="font-size: 1.2rem; color: rgba(205, 219, 255, 0.7);">No tasks available at the moment. Check back soon!</p>
          </div>
        <?php else: ?>
          <?php foreach ($tasks as $task): ?>
            <article class="task-card">
              <div class="task-title"><?php echo htmlspecialchars($task['title']); ?></div>
              <p class="task-copy"><?php echo htmlspecialchars($task['description']); ?></p>
              
              <?php if ($task['user_started'] > 0): ?>
                <div class="task-status-badge status-<?php echo $task['user_status']; ?>">
                  <?php echo ucfirst($task['user_status']); ?>
                </div>
              <?php endif; ?>
              
              <div class="task-footer">
                <span>₦<?php echo number_format($task['reward_amount'], 2); ?></span>
                
                <?php if ($task['user_started'] == 0): ?>
                  <form method="POST" style="margin: 0;">
                    <input type="hidden" name="action" value="start_task">
                    <input type="hidden" name="task_id" value="<?php echo $task['id']; ?>">
                    <button type="submit" class="btn-cta">Start</button>
                  </form>
                <?php elseif ($task['user_status'] === 'pending'): ?>
                  <button class="btn-cta btn-pending" disabled>Pending Review</button>
                <?php elseif ($task['user_status'] === 'completed'): ?>
                  <button class="btn-cta btn-completed" disabled>Completed</button>
                <?php elseif ($task['user_status'] === 'rejected'): ?>
                  <button class="btn-cta" disabled>Rejected</button>
                <?php endif; ?>
              </div>
              
              <?php if ($task['task_url']): ?>
                <div style="margin-top: 12px; position: relative; z-index: 2;">
                  <a href="<?php echo htmlspecialchars($task['task_url']); ?>" target="_blank" 
                     style="color: var(--page-mint); font-size: 0.85rem; text-decoration: none;">
                    View Task →
                  </a>
                </div>
              <?php endif; ?>
            </article>
          <?php endforeach; ?>
        <?php endif; ?>
      </section>

      <section class="ticker">
        <div class="ticker-track">
          <?php
          // Get recent completed tasks for ticker
          $stmt = $pdo->prepare("
            SELECT u.username, t.title, t.reward_amount 
            FROM user_tasks ut
            JOIN users u ON ut.user_id = u.id
            JOIN tasks t ON ut.task_id = t.id
            WHERE ut.status = 'completed'
            ORDER BY ut.completed_at DESC
            LIMIT 10
          ");
          $stmt->execute();
          $recentTasks = $stmt->fetchAll();
          
          if (!empty($recentTasks)):
            foreach ($recentTasks as $recent):
          ?>
            TASK COMPLETED — <?php echo htmlspecialchars($recent['username']); ?> • ₦<?php echo number_format($recent['reward_amount'], 2); ?> • <?php echo htmlspecialchars($recent['title']); ?> ✦ 
          <?php 
            endforeach;
          else:
          ?>
            WELCOME TO FLOWEARNER ✦ COMPLETE TASKS ✦ EARN REWARDS ✦ GROW YOUR BALANCE ✦
          <?php endif; ?>
        </div>
      </section>

      <section class="section-white">
        <h2>Task Statistics</h2>
        <div class="task-chip-row">
          <div class="task-chip">
            <span>Available</span><?php echo count($tasks); ?> tasks
          </div>
          <div class="task-chip">
            <span>Completed</span><?php echo $completedCount; ?> tasks
          </div>
          <div class="task-chip">
            <span>Earnings</span>₦<?php echo number_format($balances['task_earnings'], 2); ?>
          </div>
        </div>
      </section>
    </main>
  </div>

  <nav class="mobile-fintech-footer">
    
  <a href="dashboard.php">
    <svg viewBox="0 0 24 24"><path d="M12 3a9 9 0 1 1 0 18 9 9 0 0 1 0-18Zm1 4h-2v6h6v-2h-4V7Z"/></svg>
    <span>Dashboard</span>
  </a>

  <!-- Premium (crown icon) -->
  <a href="membership.php">
    <svg viewBox="0 0 24 24"><path d="M5 7l2.5 5 4.5-4 4.5 4L19 7l2 13H3l2-13Z"/></svg>
    <span>Premium</span>
  </a>

  <a href="daily-rewards.php">
    <svg viewBox="0 0 24 24"><path d="M20 3H4a1 1 0 0 0-1 1v16l5-3 5 3 5-3 5 3V4a1 1 0 0 0-1-1Zm-2 5-6.7 6.7L7 10.4l1.4-1.4 2.9 2.9L17.6 6 18 8Z"/></svg>
    <span>Rewards</span>
  </a>

  <!-- Referrals (users/people icon) -->
  <a href="refferrals.php">
    <svg viewBox="0 0 24 24"><path d="M12 12a4 4 0 1 0-4-4 4 4 0 0 0 4 4Zm0 2c-4 0-8 2-8 5v1h16v-1c0-3-4-5-8-5Zm7-6a3 3 0 1 0-3 3 3 3 0 0 0 3-3Zm-1 6a5 5 0 0 1 4 2.5v1.5h-4v-1.3a6.8 6.8 0 0 0-1.2-2.2A7.9 7.9 0 0 1 18 14Z"/></svg>
    <span>Referrals</span>
  </a>

  <a href="profile.php">
    <svg viewBox="0 0 24 24"><path d="M12 2a6 6 0 0 1 6 6c0 3.31-2.69 6-6 6s-6-2.69-6-6a6 6 0 0 1 6-6Zm0 14c4.42 0 8 1.79 8 4v2H4v-2c0-2.21 3.58-4 8-4Z"/></svg>
    <span>Profile</span>
  </a>
</nav>
<script>

    let lastScrollTop = 0;
    const sidebar = document.getElementById('sidebar');
    
    window.addEventListener('scroll', function() {
      if (window.innerWidth <= 960) {
        let scrollTop = window.pageYOffset || document.documentElement.scrollTop;
        
        if (scrollTop > lastScrollTop && scrollTop > 50) {
          sidebar.classList.add('scrolled');
        } else if (scrollTop < lastScrollTop - 10) {
          sidebar.classList.remove('scrolled');
        }
        
        lastScrollTop = scrollTop <= 0 ? 0 : scrollTop;
      }
    }, false);
  </script>
</body>
</html>
