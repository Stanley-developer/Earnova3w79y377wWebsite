<?php
require_once 'config/database.php';
require_once 'includes/session.php';
require_once 'includes/connect.php';
require_once 'includes/theme-handler.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$user_id = $_SESSION['user_id'];
$pdo = getDBConnection();

// Fetch user data
$user_data = getCurrentUser();
$fullname = htmlspecialchars($user_data['fullname'] ?? $user_data['username']);
$membership_type = $user_data['membership_type'] ?? 'free';
?>

<?php include "doctype.php"; ?>
    <link rel="stylesheet" href="assets/css/gamified-fintech-theme.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: var(--font-sans);
            background: var(--bg-primary);
            color: var(--text-primary);
            min-height: 100vh;
            padding-bottom: 100px;
        }

        .community-container {
            max-width: 500px;
            margin: 0 auto;
            padding: 20px 16px;
        }

        /* Hero Section */
        .community-hero {
            text-align: center;
            padding: 40px 20px;
            background: linear-gradient(135deg, rgba(44, 91, 245, 0.15), rgba(77, 225, 193, 0.1));
            border-radius: 24px;
            border: 1px solid rgba(77, 225, 193, 0.2);
            margin-bottom: 32px;
            position: relative;
            overflow: hidden;
        }

        .community-hero::before {
            content: '';
            position: absolute;
            top: -50%;
            left: -50%;
            width: 200%;
            height: 200%;
            background: radial-gradient(circle, rgba(77, 225, 193, 0.08), transparent 50%);
            animation: heroGlow 8s ease-in-out infinite;
        }

        @keyframes heroGlow {
            0%, 100% { transform: translate(0, 0); }
            50% { transform: translate(10%, 10%); }
        }

        .community-hero-icon {
            width: 80px;
            height: 80px;
            margin: 0 auto 20px;
            background: linear-gradient(135deg, #4de1c1, #2c5bf5);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            position: relative;
            z-index: 1;
            box-shadow: 0 10px 40px rgba(77, 225, 193, 0.4);
        }

        .community-hero-icon svg {
            width: 40px;
            height: 40px;
            fill: white;
        }

        .community-hero h1 {
            font-size: 1.8rem;
            font-weight: 700;
            color: #ffffff;
            margin-bottom: 12px;
            position: relative;
            z-index: 1;
            background: linear-gradient(135deg, #ffffff, #4de1c1);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }

        .community-hero p {
            font-size: 1rem;
            color: rgba(255, 255, 255, 0.7);
            position: relative;
            z-index: 1;
            line-height: 1.6;
            max-width: 400px;
            margin: 0 auto;
        }

        /* Section Title */
        .section-title {
            font-size: 1.1rem;
            font-weight: 600;
            color: rgba(255, 255, 255, 0.9);
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .section-title svg {
            width: 24px;
            height: 24px;
            fill: #4de1c1;
        }

        /* Social Links Grid */
        .social-links-grid {
            display: flex;
            flex-direction: column;
            gap: 16px;
        }

        .social-link-card {
            display: flex;
            align-items: center;
            gap: 16px;
            padding: 20px;
            background: rgba(13, 24, 62, 0.6);
            border: 1px solid rgba(86, 139, 241, 0.2);
            border-radius: 16px;
            text-decoration: none;
            transition: all 0.3s ease;
            position: relative;
            overflow: hidden;
        }

        .social-link-card:hover {
            border-color: rgba(77, 225, 193, 0.4);
            transform: translateY(-2px);
            box-shadow: 0 8px 24px rgba(4, 10, 36, 0.4);
        }

        .social-link-card::after {
            content: '';
            position: absolute;
            right: 20px;
            top: 50%;
            transform: translateY(-50%);
            width: 24px;
            height: 24px;
            background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='rgba(77, 225, 193, 0.6)'%3E%3Cpath d='M10 6L8.59 7.41 13.17 12l-4.58 4.59L10 18l6-6z'/%3E%3C/svg%3E");
            background-size: contain;
            transition: transform 0.3s ease;
        }

        .social-link-card:hover::after {
            transform: translateY(-50%) translateX(4px);
        }

        .social-icon-wrapper {
            width: 56px;
            height: 56px;
            border-radius: 16px;
            display: flex;
            align-items: center;
            justify-content: center;
            flex-shrink: 0;
        }

        .social-icon-wrapper svg {
            width: 32px;
            height: 32px;
            fill: white;
        }

        .social-link-info {
            flex: 1;
        }

        .social-link-name {
            font-size: 1.1rem;
            font-weight: 600;
            color: #ffffff;
            margin-bottom: 4px;
        }

        .social-link-handle {
            font-size: 0.85rem;
            color: rgba(255, 255, 255, 0.6);
        }

        /* Platform-specific colors */
        .social-instagram .social-icon-wrapper {
            background: linear-gradient(135deg, #f09433, #e6683c, #dc2743, #cc2366, #bc1888);
        }

        .social-telegram .social-icon-wrapper {
            background: linear-gradient(135deg, #0088cc, #00a0dc);
        }

        .social-tiktok .social-icon-wrapper {
            background: linear-gradient(135deg, #000000, #25f4ee);
            border: 1px solid rgba(255, 255, 255, 0.2);
        }

        .social-facebook .social-icon-wrapper {
            background: linear-gradient(135deg, #1877f2, #3b5998);
        }

        .social-youtube .social-icon-wrapper {
            background: linear-gradient(135deg, #ff0000, #cc0000);
        }

        /* Benefits Section */
        .benefits-section {
            margin-top: 40px;
            padding: 24px;
            background: rgba(13, 24, 62, 0.4);
            border: 1px solid rgba(86, 139, 241, 0.15);
            border-radius: 20px;
        }

        .benefits-list {
            display: flex;
            flex-direction: column;
            gap: 16px;
        }

        .benefit-item {
            display: flex;
            align-items: flex-start;
            gap: 12px;
        }

        .benefit-icon {
            width: 40px;
            height: 40px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            flex-shrink: 0;
            font-size: 1.2rem;
        }

        .benefit-icon.updates {
            background: linear-gradient(135deg, rgba(77, 225, 193, 0.3), rgba(77, 225, 193, 0.1));
        }

        .benefit-icon.giveaways {
            background: linear-gradient(135deg, rgba(251, 191, 36, 0.3), rgba(251, 191, 36, 0.1));
        }

        .benefit-icon.support {
            background: linear-gradient(135deg, rgba(139, 92, 246, 0.3), rgba(139, 92, 246, 0.1));
        }

        .benefit-icon.tutorials {
            background: linear-gradient(135deg, rgba(244, 114, 182, 0.3), rgba(244, 114, 182, 0.1));
        }

        .benefit-text h4 {
            font-size: 0.95rem;
            font-weight: 600;
            color: #ffffff;
            margin-bottom: 4px;
        }

        .benefit-text p {
            font-size: 0.85rem;
            color: rgba(255, 255, 255, 0.6);
            line-height: 1.5;
        }

        /* CTA Section */
        .cta-section {
            margin-top: 32px;
            text-align: center;
            padding: 24px;
            background: linear-gradient(135deg, rgba(44, 91, 245, 0.2), rgba(77, 225, 193, 0.15));
            border-radius: 20px;
            border: 1px solid rgba(77, 225, 193, 0.25);
        }

        .cta-section p {
            font-size: 0.95rem;
            color: rgba(255, 255, 255, 0.8);
            margin-bottom: 16px;
            line-height: 1.6;
        }

        .cta-highlight {
            color: #4de1c1;
            font-weight: 600;
        }

        @media (max-width: 480px) {
            .community-hero h1 {
                font-size: 1.5rem;
            }

            .social-link-card {
                padding: 16px;
            }

            .social-icon-wrapper {
                width: 48px;
                height: 48px;
            }

            .social-icon-wrapper svg {
                width: 26px;
                height: 26px;
            }

            .social-link-name {
                font-size: 1rem;
            }
        }
    </style>
</head>
<body>

<?php include "header.php"; ?>

<div class="community-container">
    <!-- Hero Section -->
    <div class="community-hero">
        <div class="community-hero-icon">
            <svg viewBox="0 0 24 24">
                <path d="M16 11c1.66 0 2.99-1.34 2.99-3S17.66 5 16 5c-1.66 0-3 1.34-3 3s1.34 3 3 3zm-8 0c1.66 0 2.99-1.34 2.99-3S9.66 5 8 5C6.34 5 5 6.34 5 8s1.34 3 3 3zm0 2c-2.33 0-7 1.17-7 3.5V19h14v-2.5c0-2.33-4.67-3.5-7-3.5zm8 0c-.29 0-.62.02-.97.05 1.16.84 1.97 1.97 1.97 3.45V19h6v-2.5c0-2.33-4.67-3.5-7-3.5z"/>
            </svg>
        </div>
        <h1>Join Earnova Digital Community</h1>
        <p>Connect with thousands of earners, get exclusive updates, participate in giveaways, and stay ahead of the game!</p>
    </div>

    <!-- Social Links Section -->
    <h2 class="section-title">
        <svg viewBox="0 0 24 24">
            <path d="M18 16.08c-.76 0-1.44.3-1.96.77L8.91 12.7c.05-.23.09-.46.09-.7s-.04-.47-.09-.7l7.05-4.11c.54.5 1.25.81 2.04.81 1.66 0 3-1.34 3-3s-1.34-3-3-3-3 1.34-3 3c0 .24.04.47.09.7L8.04 9.81C7.5 9.31 6.79 9 6 9c-1.66 0-3 1.34-3 3s1.34 3 3 3c.79 0 1.5-.31 2.04-.81l7.12 4.16c-.05.21-.08.43-.08.65 0 1.61 1.31 2.92 2.92 2.92 1.61 0 2.92-1.31 2.92-2.92s-1.31-2.92-2.92-2.92z"/>
        </svg>
        Follow Us On Social Media
    </h2>

    <div class="social-links-grid">
        <!-- Instagram -->
        <a href="https://www.instagram.com/earnovadigitalhub?igsh=ZXFmdmw2Y3V2ZXQ2" target="_blank" rel="noopener noreferrer" class="social-link-card social-instagram">
            <div class="social-icon-wrapper">
                <svg viewBox="0 0 24 24">
                    <path d="M7.8 2h8.4C19.4 2 22 4.6 22 7.8v8.4a5.8 5.8 0 0 1-5.8 5.8H7.8C4.6 22 2 19.4 2 16.2V7.8A5.8 5.8 0 0 1 7.8 2m-.2 2A3.6 3.6 0 0 0 4 7.6v8.8C4 18.39 5.61 20 7.6 20h8.8a3.6 3.6 0 0 0 3.6-3.6V7.6C20 5.61 18.39 4 16.4 4H7.6m9.65 1.5a1.25 1.25 0 0 1 1.25 1.25A1.25 1.25 0 0 1 17.25 8 1.25 1.25 0 0 1 16 6.75a1.25 1.25 0 0 1 1.25-1.25M12 7a5 5 0 0 1 5 5 5 5 0 0 1-5 5 5 5 0 0 1-5-5 5 5 0 0 1 5-5m0 2a3 3 0 0 0-3 3 3 3 0 0 0 3 3 3 3 0 0 0 3-3 3 3 0 0 0-3-3z"/>
                </svg>
            </div>
            <div class="social-link-info">
                <div class="social-link-name">Instagram</div>
                <div class="social-link-handle">@earnovadigitalhub</div>
            </div>
        </a>

        <!-- Telegram -->
        <a href="https://t.me/earnovadigitalhub" target="_blank" rel="noopener noreferrer" class="social-link-card social-telegram">
            <div class="social-icon-wrapper">
                <svg viewBox="0 0 24 24">
                    <path d="M11.944 0A12 12 0 0 0 0 12a12 12 0 0 0 12 12 12 12 0 0 0 12-12A12 12 0 0 0 12 0a12 12 0 0 0-.056 0zm4.962 7.224c.1-.002.321.023.465.14a.506.506 0 0 1 .171.325c.016.093.036.306.02.472-.18 1.898-.962 6.502-1.36 8.627-.168.9-.499 1.201-.82 1.23-.696.065-1.225-.46-1.9-.902-1.056-.693-1.653-1.124-2.678-1.8-1.185-.78-.417-1.21.258-1.91.177-.184 3.247-2.977 3.307-3.23.007-.032.014-.15-.056-.212s-.174-.041-.249-.024c-.106.024-1.793 1.14-5.061 3.345-.48.33-.913.49-1.302.48-.428-.008-1.252-.241-1.865-.44-.752-.245-1.349-.374-1.297-.789.027-.216.325-.437.893-.663 3.498-1.524 5.83-2.529 6.998-3.014 3.332-1.386 4.025-1.627 4.476-1.635z"/>
                </svg>
            </div>
            <div class="social-link-info">
                <div class="social-link-name">Telegram</div>
                <div class="social-link-handle">@earnovadigitalhub</div>
            </div>
        </a>

        <!-- TikTok -->
        <a href="https://www.tiktok.com/@earnova.digital.h?_r=1&_t=ZM-91ddYm5WW0x" target="_blank" rel="noopener noreferrer" class="social-link-card social-tiktok">
            <div class="social-icon-wrapper">
                <svg viewBox="0 0 24 24">
                    <path d="M19.59 6.69a4.83 4.83 0 0 1-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 0 1-5.2 1.74 2.89 2.89 0 0 1 2.31-4.64 2.93 2.93 0 0 1 .88.13V9.4a6.84 6.84 0 0 0-1-.05A6.33 6.33 0 0 0 5 20.1a6.34 6.34 0 0 0 10.86-4.43v-7a8.16 8.16 0 0 0 4.77 1.52v-3.4a4.85 4.85 0 0 1-1-.1z"/>
                </svg>
            </div>
            <div class="social-link-info">
                <div class="social-link-name">TikTok</div>
                <div class="social-link-handle">@earnova.digital.h</div>
            </div>
        </a>

        <!-- Facebook -->
        <a href="https://www.facebook.com/profile.php?id=61584270685508&mibextid=ZbWKwL" target="_blank" rel="noopener noreferrer" class="social-link-card social-facebook">
            <div class="social-icon-wrapper">
                <svg viewBox="0 0 24 24">
                    <path d="M22 12c0-5.52-4.48-10-10-10S2 6.48 2 12c0 4.84 3.44 8.87 8 9.8V15H8v-3h2V9.5C10 7.57 11.57 6 13.5 6H16v3h-2c-.55 0-1 .45-1 1v2h3v3h-3v6.95c5.05-.5 9-4.76 9-9.95z"/>
                </svg>
            </div>
            <div class="social-link-info">
                <div class="social-link-name">Facebook</div>
                <div class="social-link-handle">Earnova Digital Hub</div>
            </div>
        </a>

        <!-- YouTube -->
        <a href="https://www.youtube.com/@EarnovaDigitalHub" target="_blank" rel="noopener noreferrer" class="social-link-card social-youtube">
            <div class="social-icon-wrapper">
                <svg viewBox="0 0 24 24">
                    <path d="M10 15l5.19-3L10 9v6m11.56-7.83c.13.47.22 1.1.28 1.9.07.8.1 1.49.1 2.09L22 12c0 2.19-.16 3.8-.44 4.83-.25.9-.83 1.48-1.73 1.73-.47.13-1.33.22-2.65.28-1.3.07-2.49.1-3.59.1L12 19c-4.19 0-6.8-.16-7.83-.44-.9-.25-1.48-.83-1.73-1.73-.13-.47-.22-1.1-.28-1.9-.07-.8-.1-1.49-.1-2.09L2 12c0-2.19.16-3.8.44-4.83.25-.9.83-1.48 1.73-1.73.47-.13 1.33-.22 2.65-.28 1.3-.07 2.49-.1 3.59-.1L12 5c4.19 0 6.8.16 7.83.44.9.25 1.48.83 1.73 1.73z"/>
                </svg>
            </div>
            <div class="social-link-info">
                <div class="social-link-name">YouTube</div>
                <div class="social-link-handle">@EarnovaDigitalHub</div>
            </div>
        </a>
    </div>

    <!-- Benefits Section -->
    <div class="benefits-section">
        <h2 class="section-title">
            <svg viewBox="0 0 24 24">
                <path d="M12 2L4 5v6.09c0 5.05 3.41 9.76 8 10.91 4.59-1.15 8-5.86 8-10.91V5l-8-3zm-1.06 13.54L7.4 12l1.41-1.41 2.12 2.12 4.24-4.24 1.41 1.41-5.64 5.66z"/>
            </svg>
            Why Join Our Community?
        </h2>
        
        <div class="benefits-list">
            <div class="benefit-item">
                <div class="benefit-icon updates">
                    <svg viewBox="0 0 24 24" width="20" height="20" fill="#4de1c1">
                        <path d="M18 11v2h4v-2h-4zm-2 6.61c.96.71 2.21 1.65 3.2 2.39.4-.53.8-1.07 1.2-1.6-.99-.74-2.24-1.68-3.2-2.4-.4.54-.8 1.08-1.2 1.61zM20.4 5.6c-.4-.53-.8-1.07-1.2-1.6-.99.74-2.24 1.68-3.2 2.4.4.53.8 1.07 1.2 1.6.96-.72 2.21-1.65 3.2-2.4zM4 9c-1.1 0-2 .9-2 2v2c0 1.1.9 2 2 2h1v4h2v-4h1l5 3V6L8 9H4zm11.5 3c0-1.33-.58-2.53-1.5-3.35v6.69c.92-.81 1.5-2.01 1.5-3.34z"/>
                    </svg>
                </div>
                <div class="benefit-text">
                    <h4>Exclusive Updates</h4>
                    <p>Be the first to know about new features, earning opportunities, and platform updates.</p>
                </div>
            </div>

            <div class="benefit-item">
                <div class="benefit-icon giveaways">
                    <svg viewBox="0 0 24 24" width="20" height="20" fill="#fbbf24">
                        <path d="M20 6h-2.18c.11-.31.18-.65.18-1a2.996 2.996 0 0 0-5.5-1.65l-.5.67-.5-.68C10.96 2.54 10.05 2 9 2 7.34 2 6 3.34 6 5c0 .35.07.69.18 1H4c-1.11 0-1.99.89-1.99 2L2 19c0 1.11.89 2 2 2h16c1.11 0 2-.89 2-2V8c0-1.11-.89-2-2-2zm-5-2c.55 0 1 .45 1 1s-.45 1-1 1-1-.45-1-1 .45-1 1-1zM9 4c.55 0 1 .45 1 1s-.45 1-1 1-1-.45-1-1 .45-1 1-1zm11 15H4v-2h16v2zm0-5H4V8h5.08L7 10.83 8.62 12 11 8.76l1-1.36 1 1.36L15.38 12 17 10.83 14.92 8H20v6z"/>
                    </svg>
                </div>
                <div class="benefit-text">
                    <h4>Giveaways & Bonuses</h4>
                    <p>Participate in exclusive community giveaways and earn bonus rewards.</p>
                </div>
            </div>

            <div class="benefit-item">
                <div class="benefit-icon support">
                    <svg viewBox="0 0 24 24" width="20" height="20" fill="#8b5cf6">
                        <path d="M21 6h-2v9H6v2c0 .55.45 1 1 1h11l4 4V7c0-.55-.45-1-1-1zm-4 6V3c0-.55-.45-1-1-1H3c-.55 0-1 .45-1 1v14l4-4h10c.55 0 1-.45 1-1z"/>
                    </svg>
                </div>
                <div class="benefit-text">
                    <h4>Community Support</h4>
                    <p>Get help from fellow earners and share tips for maximizing your earnings.</p>
                </div>
            </div>

            <div class="benefit-item">
                <div class="benefit-icon tutorials">
                    <svg viewBox="0 0 24 24" width="20" height="20" fill="#f472b6">
                        <path d="M12 3L1 9l4 2.18v6L12 21l7-3.82v-6l2-1.09V17h2V9L12 3zm6.82 6L12 12.72 5.18 9 12 5.28 18.82 9zM17 15.99l-5 2.73-5-2.73v-3.72L12 15l5-2.73v3.72z"/>
                    </svg>
                </div>
                <div class="benefit-text">
                    <h4>Tutorials & Tips</h4>
                    <p>Access video tutorials and earning tips to boost your income on Earnova.</p>
                </div>
            </div>
        </div>
    </div>

    <!-- CTA Section -->
    <div class="cta-section">
        <p>Join <span class="cta-highlight">10,000+ earners</span> who are already part of our thriving community. Follow us on all platforms to never miss an update!</p>
    </div>
</div>

<?php include "embed.php"; ?>

</body>
</html>
