<?php
/**
 * Chat Widget
 * Self-contained chat system with animated teaser and Q&A functionality
 * Can be included in any PHP file using: <?php include('chat_widget.php'); ?>
 */
?>


<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  

<style>
/* Scoped CSS with .cw- prefix to prevent conflicts */
.cw-container * {
  box-sizing: border-box;
  margin: 0;
  padding: 0;
}

/* Chat Icon - Fixed bottom-right */
.cw-chat-icon {
  position: fixed;
  bottom: 24px;
  right: 24px;
  width: 60px;
  height: 60px;
  border-radius: 50%;
  background: #0088cc; /* Pure Telegram signature blue */
  box-shadow: 0 8px 24px rgba(0, 136, 204, 0.4); /* shadow matches color */
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  z-index: 9998;
  transition: transform 0.3s ease, box-shadow 0.3s ease;
  border: 3px solid rgba(77, 225, 193, 0.3);
}


.cw-chat-icon:hover {
  transform: scale(1.1);
  box-shadow: 0 12px 32px rgba(44, 91, 245, 0.6);
}

.cw-chat-icon svg {
  width: 28px;
  height: 28px;
  fill: #f5f9ff;
}

/* Mind-Reader Chat Teaser */
.cw-teaser {
  position: fixed;
  bottom: 95px;
  right: 24px;
  max-width: 280px;
  z-index: 9997;
  perspective: 1000px;
}
.cw-teaser-bubble {
  background: linear-gradient(135deg, #0b1e3d, #162a5c); /* deep navy gradient */
  border: 1px solid rgba(77, 225, 193, 0.3);
  border-radius: 16px;
  padding: 14px 18px;
  box-shadow: 0 12px 40px rgba(4, 10, 36, 0.7);
  font-family: system-ui, Arial, sans-serif;
  font-size: 0.9rem;
  color: #cfd8ff; /* soft white for readability */
  line-height: 1.5;
  position: relative;
  transform-style: preserve-3d;
  animation: cw-float 3s ease-in-out infinite;
}

.cw-teaser-bubble::after {
  content: '';
  position: absolute;
  bottom: -10px;
  right: 20px;
  width: 20px;
  height: 10px;
  background: linear-gradient(135deg, #0b1e3d, #162a5c);
    box-shadow: 0 0 0 1px rgba(77, 225, 193, 0.3); /* fake border */
  clip-path: polygon(50% 0%, 0% 100%, 100% 100%);
  transform: rotate(180deg);
  transform-origin: center;
}

/* 3D Flip Animation */
@keyframes cw-flip {
  0% {
    transform: rotateY(0deg);
    opacity: 1;
  }
  45% {
    transform: rotateY(90deg);
    opacity: 0;
  }
  55% {
    transform: rotateY(-90deg);
    opacity: 0;
  }
  100% {
    transform: rotateY(0deg);
    opacity: 1;
  }
}

/* Float Animation */
@keyframes cw-float {
  0%, 100% {
    transform: translateY(0px);
  }
  50% {
    transform: translateY(-8px);
  }
}

.cw-teaser-bubble.cw-flipping {
  animation: cw-flip 2s ease-in-out;
}

/* Chat Window */
.cw-chat-window {
  position: fixed;
  bottom: 0;
  right: 0;
  width: 100%;
  height: 100%;
  background: linear-gradient(180deg, #030922, #0a164a);
  z-index: 9999;
  display: none;
  flex-direction: column;
  box-shadow: -4px 0 40px rgba(4, 10, 36, 0.8);
}

.cw-chat-window.cw-open {
  display: flex;
}

/* Desktop: 40% width */
@media (min-width: 768px) {

  .cw-chat-window {
    width: 40%;
    height: 600px;
    bottom: 24px;
    right: 24px;
    border-radius: 20px;
    border: 1px solid rgba(77, 225, 193, 0.3);
  }
}

/* Chat Header */
.cw-chat-header {
  background: linear-gradient(135deg, rgba(26, 58, 171, 0.78), rgba(5, 16, 58, 0.92));
  border-bottom: 1px solid rgba(77, 225, 193, 0.3);
  padding: 18px 20px;
  display: flex;
  align-items: center;
  justify-content: space-between;
}

.cw-chat-header h3 {
  font-family: "Titillium Web", system-ui, sans-serif;
  font-size: 1.1rem;
  color: #f5f9ff;
  font-weight: 600;
  letter-spacing: 0.02em;
}

.cw-close-btn {
  background: linear-gradient(135deg, #2c5bf5, #4de1c1);
  border: 1px solid rgba(255, 107, 53, 0.3);
  border-radius: 50%;
  width: 32px;
  height: 32px;
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  transition: all 0.3s ease;
  color: #f5f9ff;
  font-size: 1.2rem;
  font-weight: bold;
}

.cw-close-btn:hover {
  background: rgba(255, 107, 53, 0.4);
  transform: rotate(90deg);
}

/* Question Selection Area */
.cw-questions-area {
  flex: 1;
  padding: 24px;
  overflow-y: auto;
  background: radial-gradient(circle at 0% 0%, rgba(61, 116, 255, 0.15), transparent 55%),
              radial-gradient(circle at 100% 100%, rgba(77, 225, 193, 0.1), transparent 40%),
              linear-gradient(180deg, #030922, #0a164a);
}

.cw-questions-title {
  font-family: "Titillium Web", system-ui, sans-serif;
  font-size: 1rem;
  color: rgba(211, 227, 255, 0.9);
  margin-bottom: 16px;
  text-transform: uppercase;
  letter-spacing: 0.08em;
  font-weight: 600;
}

.cw-question-btn {
  width: 100%;
  background: rgba(13, 24, 62, 0.78);
  border: 1px solid rgba(77, 225, 193, 0.25);
  border-radius: 12px;
  padding: 14px 16px;
  margin-bottom: 12px;
  color: #f5f9ff;
  font-family: system-ui, Arial, sans-serif;
  font-size: 0.9rem;
  text-align: left;
  cursor: pointer;
  transition: all 0.3s ease;
  display: flex;
  align-items: center;
  gap: 10px;
}

.cw-question-btn:hover {
  background: rgba(26, 58, 171, 0.5);
  border-color: rgba(77, 225, 193, 0.5);
  transform: translateX(4px);
}

.cw-question-btn::before {
  content: '';
  font-size: 1.1rem;
}

/* Chat Messages Area */
.cw-messages-area {
  flex: 1;
  padding: 24px;
  overflow-y: auto;
  display: none;
  flex-direction: column;
  gap: 16px;
}

.cw-messages-area.cw-active {
  display: flex;
}

/* Message Bubbles */
.cw-message {
  max-width: 80%;
  padding: 12px 16px;
  border-radius: 16px;
  font-family: system-ui, Arial, sans-serif;
  font-size: 0.9rem;
  line-height: 1.5;
  animation: cw-slideIn 0.4s ease;
}

@keyframes cw-slideIn {
  from {
    opacity: 0;
    transform: translateY(10px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

.cw-message.cw-user {
  align-self: flex-end;
  background: linear-gradient(135deg, #2c5bf5, #4de1c1);
  color: #f5f9ff;
  border-bottom-right-radius: 4px;
}

.cw-message.cw-bot {
  align-self: flex-start;
  background: rgba(13, 24, 62, 0.78);
  border: 1px solid rgba(77, 225, 193, 0.25);
  color: #f5f9ff;
  border-bottom-left-radius: 4px;
}

/* Typing Indicator */
.cw-typing {
  align-self: flex-start;
  padding: 12px 16px;
  background: rgba(13, 24, 62, 0.78);
  border: 1px solid rgba(77, 225, 193, 0.25);
  border-radius: 16px;
  border-bottom-left-radius: 4px;
  display: none;
  gap: 4px;
}

.cw-typing.cw-active {
  display: flex;
}

.cw-typing-dot {
  width: 8px;
  height: 8px;
  border-radius: 50%;
  background: #4de1c1;
  animation: cw-typingBounce 1.4s infinite;
}

.cw-typing-dot:nth-child(2) {
  animation-delay: 0.2s;
}

.cw-typing-dot:nth-child(3) {
  animation-delay: 0.4s;
}

@keyframes cw-typingBounce {
  0%, 60%, 100% {
    transform: translateY(0);
  }
  30% {
    transform: translateY(-8px);
  }
}

/* Human Support Button */
.cw-support-btn {
   background: #0088cc; /* Telegram blue */
  border: 1px solid rgba(77, 225, 193, 0.3); /* border */
  border-radius: 12px;
  padding: 12px 20px;
  color: #f5f9ff;
  font-family: "Titillium Web", system-ui, sans-serif;
  font-size: 0.9rem;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.3s ease;
  display: inline-flex;
  align-items: center;
  gap: 8px;
  margin-top: 8px;
  text-decoration: none;
}

.cw-support-btn:hover {
  background: linear-gradient(135deg, rgba(255, 130, 70, 0.4), rgba(255, 107, 53, 0.5));
  transform: translateY(-2px);
  box-shadow: 0 8px 20px rgba(255, 107, 53, 0.3);
}

/* Mobile Adjustments */
@media (max-width: 767px) {
  .cw-chat-icon {
    bottom: 90px;
    right: 20px;
    width: 56px;
    height: 56px;
  }

  .cw-teaser-bubble {
    font-size: 10px;
}

  .cw-teaser {
    bottom: 155px;
    right: 20px;
    max-width: 260px;
  }

  .cw-chat-window {
    border-radius: 0;
  }
}

/* Scrollbar Styling */
.cw-questions-area::-webkit-scrollbar,
.cw-messages-area::-webkit-scrollbar {
  width: 6px;
}

.cw-questions-area::-webkit-scrollbar-track,
.cw-messages-area::-webkit-scrollbar-track {
  background: rgba(13, 24, 62, 0.5);
}

.cw-questions-area::-webkit-scrollbar-thumb,
.cw-messages-area::-webkit-scrollbar-thumb {
  background: rgba(77, 225, 193, 0.3);
  border-radius: 3px;
}

.cw-questions-area::-webkit-scrollbar-thumb:hover,
.cw-messages-area::-webkit-scrollbar-thumb:hover {
  background: rgba(77, 225, 193, 0.5);
}
</style>

<div class="cw-container">
  <!-- Mind-Reader Chat Teaser -->
  <div class="cw-teaser" id="cwTeaser">
    <div class="cw-teaser-bubble" id="cwTeaserBubble">
       Need help choosing a plan?
    </div>
  </div>

  <!-- Floating Chat Icon -->
  <div class="cw-chat-icon" id="cwChatIcon">
    <svg viewBox="0 0 24 24">
      <path d="M20 2H4c-1.1 0-2 .9-2 2v18l4-4h14c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2zm0 14H6l-2 2V4h16v12z"/>
      <path d="M7 9h10v2H7zm0-3h10v2H7zm0 6h7v2H7z"/>
    </svg>
  </div>

  <!-- Chat Window -->
  <div class="cw-chat-window" id="cwChatWindow">
    <!-- Header -->
    <div class="cw-chat-header">
      <h3>Virtual Assistant</h3>
      <div class="cw-close-btn" id="cwCloseBtn">✕</div>
    </div>

    <!-- Questions Selection Area -->
    <div class="cw-questions-area" id="cwQuestionsArea">
      <div class="cw-questions-title">How can we help you today?</div>
      <button class="cw-question-btn" data-question="What are your pricing plans?" data-answer="We offer flexible pricing plans to suit your needs. Our Premium Membership costs ₦1,500 for the first year (then ₦3,500/year), and our Senior Advertiser Plan costs ₦2,500 for the first year (then ₦5,500/year). Both plans come with exclusive benefits and features.">
        What are your pricing plans?
      </button>
      <button class="cw-question-btn" data-question="How can I contact support?" data-answer="You can contact us directly via this chat or email us at support@earnova.com. Our support team is available 24/7 to assist you with any questions or concerns.">
        How can I contact support?
      </button>
      <button class="cw-question-btn" data-question="Where are you located?" data-answer="We are based in Lagos, Nigeria. Earnova is a leading platform for task-based earnings and job marketplace services across Nigeria and beyond.">
        Where are you located?
      </button>
      <button class="cw-question-btn" data-question="Can I upgrade my account later?" data-answer="Yes, you can upgrade at any time from your dashboard! Simply navigate to the Membership page and choose the plan that best suits your needs. Upgrades are instant and you'll get immediate access to all premium features.">
        Can I upgrade my account later?
      </button>
      <button class="cw-question-btn" data-question="How do I earn money on Earnova?" data-answer="You can earn money on Earnova by completing tasks, referring friends, bidding on jobs in our marketplace, and participating in daily rewards. Premium members earn 20% more on tasks and get access to exclusive high-paying opportunities.">
        How do I earn money on Earnova?
      </button>
      <button class="cw-question-btn" data-question="What is the minimum withdrawal amount?" data-answer="The minimum withdrawal amount is ₦3,000 for referral earnings and ₦55,000 for task earnings. Withdrawals are processed within 24-48 hours to your preferred payment method.">
        What is the minimum withdrawal amount?
      </button>
    </div>

    <!-- Messages Area -->
    <div class="cw-messages-area" id="cwMessagesArea">
      <!-- Messages will be dynamically added here -->
    </div>
  </div>
</div>

<script>
(function() {
  'use strict';

  // Teaser messages
  const teaserMessages = [
    "Need help choosing a plan?",
    " Have a quick question?",
    "Looking for support?",
    "Ready to get started?",
    "Let's make things easier for you!"
  ];

  let currentMessageIndex = 0;
  let teaserInterval;

  // Elements
  const teaser = document.getElementById('cwTeaser');
  const teaserBubble = document.getElementById('cwTeaserBubble');
  const chatIcon = document.getElementById('cwChatIcon');
  const chatWindow = document.getElementById('cwChatWindow');
  const closeBtn = document.getElementById('cwCloseBtn');
  const questionsArea = document.getElementById('cwQuestionsArea');
  const messagesArea = document.getElementById('cwMessagesArea');
  const questionBtns = document.querySelectorAll('.cw-question-btn');

  // Start teaser animation
  function startTeaserAnimation() {
    teaserInterval = setInterval(() => {
      // Add flip animation
      teaserBubble.classList.add('cw-flipping');

      // Change message after 1 second (mid-flip)
      setTimeout(() => {
        currentMessageIndex = (currentMessageIndex + 1) % teaserMessages.length;
        teaserBubble.textContent = teaserMessages[currentMessageIndex];
      }, 1000);

      // Remove flip animation after 2 seconds
      setTimeout(() => {
        teaserBubble.classList.remove('cw-flipping');
      }, 2000);
    }, 10000); // Every 10 seconds
  }

  // Open chat window
  function openChat() {
    chatWindow.classList.add('cw-open');
    teaser.style.display = 'none';
    chatIcon.style.display = 'none';
  }

  // Close chat window
  function closeChat() {
    chatWindow.classList.remove('cw-open');
    teaser.style.display = 'block';
    chatIcon.style.display = 'flex';
    
    // Reset to questions view
    questionsArea.style.display = 'block';
    messagesArea.classList.remove('cw-active');
    messagesArea.innerHTML = '';
  }

  // Add message to chat
  function addMessage(text, type) {
    const message = document.createElement('div');
    message.className = `cw-message cw-${type}`;
    message.textContent = text;
    messagesArea.appendChild(message);
    messagesArea.scrollTop = messagesArea.scrollHeight;
  }

  // Show typing indicator
  function showTyping() {
    const typing = document.createElement('div');
    typing.className = 'cw-typing cw-active';
    typing.innerHTML = '<div class="cw-typing-dot"></div><div class="cw-typing-dot"></div><div class="cw-typing-dot"></div>';
    messagesArea.appendChild(typing);
    messagesArea.scrollTop = messagesArea.scrollHeight;
    return typing;
  }

  // Add support button
  function addSupportButton() {
    const supportLink = document.createElement('a');
    supportLink.href = 'https://t.me/earnoval_support'; // Replace with actual Telegram link
    supportLink.target = '_blank';
    supportLink.className = 'cw-support-btn';
    supportLink.innerHTML = 'Click here to chat with a human support';
    messagesArea.appendChild(supportLink);
    messagesArea.scrollTop = messagesArea.scrollHeight;
  }

  // Handle question click
  function handleQuestionClick(e) {
    const question = e.currentTarget.dataset.question;
    const answer = e.currentTarget.dataset.answer;

    // Switch to messages view
    questionsArea.style.display = 'none';
    messagesArea.classList.add('cw-active');

    // Add user message
    addMessage(question, 'user');

    // Show typing indicator
    const typing = showTyping();

    // After 4 seconds, show bot response
    setTimeout(() => {
      typing.remove();
      addMessage(answer, 'bot');
      addSupportButton();
    }, 2000);
  }

  // Event listeners
  chatIcon.addEventListener('click', openChat);
  closeBtn.addEventListener('click', closeChat);
  questionBtns.forEach(btn => {
    btn.addEventListener('click', handleQuestionClick);
  });

  // Start teaser animation on load
  startTeaserAnimation();
})();
</script>
