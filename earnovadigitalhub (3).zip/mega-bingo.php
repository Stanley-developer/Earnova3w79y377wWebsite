<?php
require_once 'config/database.php';
require_once 'includes/session.php';
require_once 'includes/connect.php';

requireLogin();
checkSessionTimeout();

$user = getCurrentUser();
$user_id = $user['id'];

try {
    $pdo = getDBConnection();
    $stmt = $pdo->prepare("SELECT u.*, b.total_balance, b.referral_earnings, b.game_earnings, b.task_earnings FROM users u LEFT JOIN balances b ON u.id = b.user_id WHERE u.id = ?");
    $stmt->execute([$user_id]);
    $user_data = $stmt->fetch();
    
    if (!$user_data) {
        header('Location: login.php');
        exit;
    }
    
    $is_premium = ($user_data['membership_type'] === 'premium');
} catch (PDOException $e) {
    error_log("Mega Bingo Error: " . $e->getMessage());
    $error_message = "Unable to load game data.";
}

$game_earnings = $user_data['game_earnings'] ?? 0;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mega Bingo - FlowEarner</title>
    <link rel="stylesheet" href="assets/css/gamified-fintech-theme.css">
    <style>
        :root {
            --page-blue-900: #030922;
            --page-blue-800: #0a1642;
            --page-blue-700: #0a164a;
            --page-blue-500: #142e7e;
            --page-mint: #4de1c1;
            --page-white: #f5f9ff;
            --page-orange: #fb923c;
            --page-gold: #fbbf24;
        }

        * { box-sizing: border-box; margin: 0; padding: 0; }

        body {
            font-family: 'Inter', sans-serif;
            background: linear-gradient(135deg, #0a0e27 0%, #1a1f3a 100%);
            color: #fff;
            overflow-x: hidden;
            min-height: 100vh;
            padding-bottom: 100px;
        }
        
        .container {
            max-width: 1400px;
            margin: 0 auto;
            padding: 20px;
        }
        
        .back-link {
            display: inline-block;
            margin-bottom: 20px;
            color: var(--page-mint);
            text-decoration: none;
            font-size: 1rem;
            font-weight: 600;
            transition: color 0.3s ease;
        }
        
        .back-link:hover { color: #fff; }
        
        .page-header {
            text-align: center;
            padding: 40px 20px;
            background: rgba(77, 225, 193, 0.1);
            border-radius: 20px;
            margin-bottom: 30px;
            border: 1px solid rgba(77, 225, 193, 0.2);
        }
        
        .page-header h1 {
            font-size: clamp(2rem, 5vw, 3rem);
            margin: 0 0 10px;
            background: linear-gradient(135deg, #2c5bf5, #4de1c1);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }
        
        .page-header p {
            font-size: clamp(1rem, 2vw, 1.2rem);
            color: rgba(255, 255, 255, 0.7);
        }
        
        .game-layout {
            display: flex;
            gap: 30px;
            margin-bottom: 40px;
            flex-wrap: wrap;
            justify-content: center;
        }
        
        .bingo-card-section {
            background: linear-gradient(135deg, #1a2a5e 0%, #0f1937 100%);
            border: 3px solid rgba(77, 225, 193, 0.3);
            border-radius: 30px;
            padding: 20px;
            flex: 1;
            min-width: 320px;
            max-width: 500px;
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.7);
        }
        
        .top-bar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
            flex-wrap: wrap;
            gap: 10px;
        }
        
        .balance-chip {
            background: rgba(10, 22, 66, 0.8);
            border: 2px solid rgba(77, 225, 193, 0.3);
            border-radius: 25px;
            padding: 10px 20px;
            display: flex;
            align-items: center;
            gap: 10px;
            cursor: pointer;
            transition: all 0.3s ease;
        }
        
        .balance-chip:hover {
            background: rgba(10, 22, 66, 1);
            border-color: var(--page-mint);
            transform: translateY(-2px);
        }
        
        .balance-chip-value {
            color: #fff;
            font-weight: 700;
        }
        
        .deposit-chip {
            background: linear-gradient(135deg, #fb923c, #f97316);
            border: none;
            font-weight: 700;
            padding: 10px 25px;
        }
        
        .deposit-chip:hover {
            transform: scale(1.05);
            box-shadow: 0 0 20px rgba(251, 146, 60, 0.6);
        }
        
        .bingo-title {
            text-align: center;
            font-size: 1.5rem;
            font-weight: 700;
            color: var(--page-mint);
            margin-bottom: 15px;
        }
        
        .bingo-card {
            background: linear-gradient(135deg, #6b4423 0%, #8b5a2b 25%, #a0522d 50%, #8b5a2b 75%, #6b4423 100%);
            border-radius: 15px;
            padding: 15px;
            display: grid;
            grid-template-columns: repeat(5, 1fr);
            gap: 8px;
            margin-bottom: 20px;
            box-shadow: inset 0 0 20px rgba(0, 0, 0, 0.5);
        }
        
        .bingo-number {
            aspect-ratio: 1;
            background: #fff;
            border: 3px solid #333;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.3rem;
            font-weight: 900;
            color: #333;
            cursor: pointer;
            transition: all 0.3s ease;
            user-select: none;
        }
        
        .bingo-number:hover:not(.marked) {
            background: #4de1c1;
            color: #fff;
            transform: scale(1.05);
            border-color: var(--page-mint);
        }
        
        .bingo-number.marked {
            background: #fb923c;
            color: #fff;
            border-color: #f97316;
            box-shadow: 0 0 15px rgba(251, 146, 60, 0.6);
        }
        
        .bingo-number.center {
            background: var(--page-mint);
            color: #fff;
            font-size: 1rem;
            font-weight: 700;
        }
        
        .controls-section {
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
            justify-content: center;
        }
        
        .bet-controls {
            display: flex;
            align-items: center;
            gap: 10px;
            background: rgba(10, 22, 66, 0.7);
            padding: 12px 20px;
            border-radius: 12px;
            border: 2px solid rgba(77, 225, 193, 0.3);
        }
        
        .bet-btn {
            width: 40px;
            height: 40px;
            border-radius: 8px;
            border: 2px solid rgba(251, 146, 60, 0.5);
            background: rgba(251, 146, 60, 0.1);
            color: var(--page-orange);
            font-size: 1.1rem;
            cursor: pointer;
            transition: all 0.3s ease;
            font-weight: 700;
        }
        
        .bet-btn:hover {
            background: rgba(251, 146, 60, 0.3);
            border-color: var(--page-orange);
            transform: scale(1.1);
        }
        
        .bet-display {
            background: rgba(10, 22, 66, 0.9);
            border: 2px solid rgba(77, 225, 193, 0.3);
            border-radius: 8px;
            padding: 8px 20px;
            color: #fff;
            font-weight: 700;
            min-width: 120px;
            text-align: center;
        }
        
        .play-button {
            background: linear-gradient(135deg, #fb923c, #f97316);
            border: none;
            border-radius: 12px;
            padding: 12px 40px;
            color: #fff;
            font-size: 1.2rem;
            font-weight: 900;
            cursor: pointer;
            transition: all 0.3s ease;
            text-transform: uppercase;
            letter-spacing: 1px;
            box-shadow: 0 8px 20px rgba(251, 146, 60, 0.3);
        }
        
        .play-button:hover:not(:disabled) {
            transform: scale(1.05);
            box-shadow: 0 12px 30px rgba(251, 146, 60, 0.6);
        }
        
        .play-button:disabled {
            opacity: 0.5;
            cursor: not-allowed;
        }
        
        .info-btn {
            width: 45px;
            height: 45px;
            border-radius: 50%;
            border: 2px solid rgba(77, 225, 193, 0.5);
            background: rgba(77, 225, 193, 0.1);
            color: var(--page-mint);
            font-size: 1.3rem;
            cursor: pointer;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 700;
        }
        
        .info-btn:hover {
            background: rgba(77, 225, 193, 0.3);
            transform: scale(1.1);
        }
        
        .caller-section {
            background: linear-gradient(135deg, #1a2a5e 0%, #0f1937 100%);
            border: 3px solid rgba(251, 146, 60, 0.3);
            border-radius: 30px;
            padding: 30px 20px;
            flex: 1;
            min-width: 250px;
            max-width: 350px;
            text-align: center;
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.7);
        }
        
        .caller-title {
            font-size: 1.2rem;
            color: var(--page-orange);
            margin-bottom: 20px;
            font-weight: 700;
        }
        
        .last-numbers {
            background: rgba(10, 22, 66, 0.8);
            border: 2px solid rgba(251, 146, 60, 0.3);
            border-radius: 15px;
            padding: 20px;
            margin-bottom: 20px;
            min-height: 150px;
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 8px;
        }
        
        .last-number {
            background: rgba(251, 146, 60, 0.2);
            border: 2px solid rgba(251, 146, 60, 0.5);
            border-radius: 10px;
            padding: 10px;
            color: var(--page-orange);
            font-weight: 700;
            font-size: 1.2rem;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        .caller-button {
            background: linear-gradient(135deg, #fb923c, #f97316);
            border: none;
            border-radius: 15px;
            padding: 20px 40px;
            color: #fff;
            font-size: 1.4rem;
            font-weight: 900;
            cursor: pointer;
            transition: all 0.3s ease;
            text-transform: uppercase;
            width: 100%;
            box-shadow: 0 8px 20px rgba(251, 146, 60, 0.3);
        }
        
        .caller-button:hover:not(:disabled) {
            transform: scale(1.05);
            box-shadow: 0 12px 30px rgba(251, 146, 60, 0.6);
        }
        
        .caller-button:disabled {
            opacity: 0.5;
            cursor: not-allowed;
        }
        
        .modal-overlay {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.9);
            backdrop-filter: blur(5px);
            z-index: 1000;
            align-items: center;
            justify-content: center;
            opacity: 0;
            transition: opacity 0.3s ease;
        }
        
        .modal-overlay.active {
            display: flex;
            opacity: 1;
        }
        
        .modal-content {
            background: linear-gradient(135deg, #0a0e27, #1a1f3a);
            border-radius: 30px;
            padding: 40px;
            max-width: 600px;
            width: 90%;
            border: 2px solid rgba(77, 225, 193, 0.3);
            text-align: center;
            position: relative;
            max-height: 90vh;
            overflow-y: auto;
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.8);
        }
        
        .modal-close {
            position: absolute;
            top: 20px;
            right: 20px;
            background: rgba(255, 59, 48, 0.2);
            border: 2px solid rgba(255, 59, 48, 0.5);
            color: #ff3b30;
            padding: 8px 16px;
            border-radius: 10px;
            cursor: pointer;
            font-weight: 600;
            transition: all 0.3s ease;
        }
        
        .modal-close:hover {
            background: rgba(255, 59, 48, 0.4);
        }
        
        .modal-title {
            font-size: 2.2rem;
            margin-bottom: 15px;
            background: linear-gradient(135deg, #2c5bf5, #4de1c1);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }
        
        .modal-message {
            font-size: 1.1rem;
            color: rgba(255, 255, 255, 0.8);
            line-height: 1.6;
            margin-bottom: 30px;
        }
        
        .modal-btn {
            padding: 15px 40px;
            border-radius: 15px;
            border: none;
            background: linear-gradient(135deg, #2c5bf5, #4de1c1);
            color: #fff;
            font-size: 1.1rem;
            font-weight: 700;
            cursor: pointer;
            margin: 0 10px;
            transition: all 0.3s ease;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        
        .modal-btn:hover {
            transform: scale(1.05);
            box-shadow: 0 0 20px rgba(77, 225, 193, 0.6);
        }
        
        .tutorial-steps {
            text-align: left;
            margin: 20px 0;
        }
        
        .tutorial-step {
            background: rgba(77, 225, 193, 0.1);
            padding: 20px;
            border-radius: 15px;
            margin-bottom: 15px;
            border-left: 4px solid var(--page-mint);
            display: none;
        }
        
        .tutorial-step.active {
            display: block;
            animation: slideIn 0.3s ease;
        }
        
        @keyframes slideIn {
            from { opacity: 0; transform: translateX(-20px); }
            to { opacity: 1; transform: translateX(0); }
        }
        
        .tutorial-step h4 {
            color: var(--page-mint);
            margin-bottom: 12px;
            font-size: 1.3rem;
        }
        
        .tutorial-step p {
            line-height: 1.6;
            font-size: 1rem;
            color: rgba(255, 255, 255, 0.9);
        }
        
        .tutorial-navigation {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-top: 30px;
            gap: 15px;
        }
        
        .tutorial-nav-btn {
            padding: 12px 30px;
            border-radius: 12px;
            border: none;
            background: linear-gradient(135deg, #2c5bf5, #4de1c1);
            color: #fff;
            font-size: 1rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
        }
        
        .tutorial-nav-btn:hover:not(:disabled) {
            transform: scale(1.05);
        }
        
        .tutorial-nav-btn:disabled {
            opacity: 0.3;
            cursor: not-allowed;
        }
        
        @media (max-width: 768px) {
            .game-layout {
                flex-direction: column;
            }
            
            .bingo-card-section, .caller-section {
                max-width: 100%;
            }
            
            .top-bar {
                flex-direction: column;
                align-items: stretch;
            }
            
            .controls-section {
                flex-direction: column;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <a href="play-earn.php" class="back-link">← Back to Games</a>
        
        <div class="page-header">
            <h1>🎰 Mega Bingo</h1>
            <p>Mark numbers, call the game, and win big!</p>
        </div>
        
        <div class="game-layout">
            <!-- Bingo Card -->
            <div class="bingo-card-section">
                <div class="top-bar">
                    <div class="balance-chip" onclick="openExchangeModal()">
                        <span style="font-size: 1.2rem;">🎮</span>
                        <span class="balance-chip-value" id="gameBalance">₦<?php echo number_format($game_earnings, 2); ?></span>
                    </div>
                    <div class="balance-chip deposit-chip" onclick="window.location.href='membership.php'">
                        Deposit
                    </div>
                    <button class="info-btn" onclick="openTutorialModal()" title="How to Play">?</button>
                </div>
                
                <div class="bingo-title">Your Card</div>
                <div class="bingo-card" id="bingoCard"></div>
                
                <div class="controls-section">
                    <div class="bet-controls">
                        <button class="bet-btn" onclick="decreaseBet()">−</button>
                        <div class="bet-display" id="betDisplay">₦5,000</div>
                        <button class="bet-btn" onclick="increaseBet()">+</button>
                    </div>
                    <button class="play-button" id="playBtn" onclick="startGame()">START GAME</button>
                </div>
            </div>
            
            <!-- Number Caller -->
            <div class="caller-section">
                <div class="caller-title">Number Caller</div>
                <div class="last-numbers" id="lastNumbers">
                    <div style="grid-column: 1/-1; display: flex; align-items: center; justify-content: center; color: rgba(255,255,255,0.5);">Waiting for game start...</div>
                </div>
                <button class="caller-button" id="callerBtn" onclick="callNumber()" disabled>CALL NUMBER</button>
            </div>
        </div>
    </div>
    
    <!-- Tutorial Modal -->
    <div class="modal-overlay" id="tutorialModal">
        <div class="modal-content">
            <button class="modal-close" onclick="closeTutorialModal()">✕</button>
            <h2 class="modal-title">How to Play Mega Bingo</h2>
            
            <div class="tutorial-steps">
                <div class="tutorial-step active">
                    <h4>🎯 Step 1: Set Your Bet</h4>
                    <p>Use + and − buttons to adjust your bet. Minimum ₦1,000, maximum ₦100,000. Higher bets = higher rewards!</p>
                </div>
                
                <div class="tutorial-step">
                    <h4>🎲 Step 2: Start the Game</h4>
                    <p>Click <strong>START GAME</strong> to generate your bingo card and activate the number caller.</p>
                </div>
                
                <div class="tutorial-step">
                    <h4>📞 Step 3: Call Numbers</h4>
                    <p>Click <strong>CALL NUMBER</strong> to randomly select numbers from 1-75. Numbers appear on your card!</p>
                </div>
                
                <div class="tutorial-step">
                    <h4>✓ Step 4: Mark Your Numbers</h4>
                    <p>Click any number on your card to mark it. The center space is FREE! Mark matching numbers from the caller.</p>
                </div>
                
                <div class="tutorial-step">
                    <h4>🎉 Step 5: Win!</h4>
                    <p>Complete a pattern (line, diagonal, or full card) and claim your reward! 2x multiplier for your bet amount!</p>
                </div>
            </div>
            
            <div class="tutorial-navigation">
                <button class="tutorial-nav-btn" onclick="previousTutorialStep()" id="prevTutBtn" disabled>← Back</button>
                <button class="tutorial-nav-btn" onclick="nextTutorialStep()" id="nextTutBtn">Next →</button>
            </div>
        </div>
    </div>
    
    <!-- Exchange Modal -->
    <div class="modal-overlay" id="exchangeModal">
        <div class="modal-content">
            <button class="modal-close" onclick="closeExchangeModal()">✕</button>
            <h2 class="modal-title">💱 Exchange Earnings</h2>
            <p class="modal-message">Convert your Game Earnings to Task Balance</p>
            
            <div style="background: rgba(77, 225, 193, 0.1); padding: 20px; border-radius: 15px; margin: 20px 0;">
                <p style="color: rgba(255,255,255,0.7); margin-bottom: 10px;">Available Game Earnings:</p>
                <p style="font-size: 2rem; color: var(--page-mint); font-weight: 900;" id="exchangeGameBalance">₦0.00</p>
            </div>
            
            <input type="number" style="width: 100%; padding: 15px; border: 2px solid rgba(77, 225, 193, 0.3); background: rgba(10, 22, 66, 0.8); border-radius: 12px; color: #fff; font-size: 1rem; margin: 20px 0;" id="exchangeAmount" placeholder="Enter amount to exchange" min="100" step="100">
            <button class="modal-btn" onclick="exchangeBalance()">Exchange Now</button>
        </div>
    </div>
    
    <!-- Premium Modal -->
    <div class="modal-overlay" id="premiumModal">
        <div class="modal-content">
            <button class="modal-close" onclick="closePremiumModal()">✕</button>
            <h2 class="modal-title">🔒 Premium Required</h2>
            <p class="modal-message">Mega Bingo is exclusively for Premium Members!</p>
            <button class="modal-btn" onclick="window.location.href='membership.php'" style="background: linear-gradient(135deg, #fb923c, #f97316);">Upgrade to Premium</button>
        </div>
    </div>
    
    <!-- Result Modal -->
    <div class="modal-overlay" id="resultModal">
        <div class="modal-content">
            <button class="modal-close" onclick="closeResultModal()">✕</button>
            <h2 class="modal-title" id="resultTitle">BINGO!</h2>
            <p style="font-size: 4rem; margin: 20px 0;" id="resultEmoji">🎉</p>
            <p class="modal-message" id="resultMessage">You completed a winning pattern!</p>
            <p style="font-size: 2.5rem; color: var(--page-mint); font-weight: 900; margin: 20px 0;" id="resultAmount">₦0.00</p>
            <button class="modal-btn" onclick="closeResultModal()">Play Again</button>
        </div>
    </div>
    
    <!-- Notification Modal -->
    <div class="modal-overlay" id="notifyModal">
        <div class="modal-content">
            <h2 class="modal-title" id="notifyTitle">Notification</h2>
            <p class="modal-message" id="notifyMessage">Message</p>
            <button class="modal-btn" onclick="closeNotifyModal()">OK</button>
        </div>
    </div>

    <script>
        const IS_PREMIUM = <?php echo $is_premium ? 'true' : 'false'; ?>;
        
        let bingoCard = [];
        let markedNumbers = new Set();
        let calledNumbers = [];
        let betAmount = 5;
        let gameActive = false;
        let tutorialStep = 0;
        const tutorialSteps = 5;
        
        if (!IS_PREMIUM) {
            document.getElementById('premiumModal').classList.add('active');
        }
        
        function generateBingoCard() {
            bingoCard = [];
            const ranges = [
                Array.from({length: 15}, (_, i) => i + 1),    // B: 1-15
                Array.from({length: 15}, (_, i) => i + 16),   // I: 16-30
                Array.from({length: 15}, (_, i) => i + 31),   // N: 31-45
                Array.from({length: 15}, (_, i) => i + 46),   // G: 46-60
                Array.from({length: 15}, (_, i) => i + 61)    // O: 61-75
            ];
            
            for (let col = 0; col < 5; col++) {
                bingoCard[col] = [];
                const shuffled = ranges[col].sort(() => Math.random() - 0.5);
                for (let row = 0; row < 5; row++) {
                    bingoCard[col][row] = shuffled[row];
                }
            }
            
            renderBingoCard();
        }
        
        function renderBingoCard() {
            const container = document.getElementById('bingoCard');
            container.innerHTML = '';
            markedNumbers.clear();
            
            for (let col = 0; col < 5; col++) {
                for (let row = 0; row < 5; row++) {
                    const num = bingoCard[col][row];
                    const div = document.createElement('div');
                    div.className = 'bingo-number';
                    
                    if (col === 2 && row === 2) {
                        div.className += ' center';
                        div.textContent = 'FREE';
                        markedNumbers.add(num);
                    } else {
                        div.textContent = num;
                        div.onclick = () => toggleMark(col, row, num);
                    }
                    
                    container.appendChild(div);
                }
            }
        }
        
        function toggleMark(col, row, num) {
            if (!gameActive) return;
            const container = document.getElementById('bingoCard');
            const elements = container.querySelectorAll('.bingo-number');
            const index = col * 5 + row;
            const element = elements[index];
            
            if (element.classList.contains('marked')) {
                element.classList.remove('marked');
                markedNumbers.delete(num);
            } else {
                element.classList.add('marked');
                markedNumbers.add(num);
            }
            
            checkWin();
        }
        
        function callNumber() {
            const available = Array.from({length: 75}, (_, i) => i + 1)
                .filter(n => !calledNumbers.includes(n));
            
            if (available.length === 0) {
                showNotify('No Numbers Left', 'All numbers have been called!');
                return;
            }
            
            const called = available[Math.floor(Math.random() * available.length)];
            calledNumbers.push(called);
            
            // Auto-mark matching numbers on card
            for (let col = 0; col < 5; col++) {
                for (let row = 0; row < 5; row++) {
                    if (bingoCard[col][row] === called) {
                        markedNumbers.add(called);
                    }
                }
            }
            
            renderLastNumbers();
            renderBingoCard();
            checkWin();
        }
        
        function renderLastNumbers() {
            const container = document.getElementById('lastNumbers');
            container.innerHTML = '';
            const recent = calledNumbers.slice(-9).reverse();
            recent.forEach(num => {
                const div = document.createElement('div');
                div.className = 'last-number';
                div.textContent = num;
                container.appendChild(div);
            });
        }
        
        function checkWin() {
            // Check rows
            for (let row = 0; row < 5; row++) {
                let count = 0;
                for (let col = 0; col < 5; col++) {
                    if (markedNumbers.has(bingoCard[col][row])) count++;
                }
                if (count === 5) return winGame('Row');
            }
            
            // Check columns
            for (let col = 0; col < 5; col++) {
                let count = 0;
                for (let row = 0; row < 5; row++) {
                    if (markedNumbers.has(bingoCard[col][row])) count++;
                }
                if (count === 5) return winGame('Column');
            }
            
            // Check diagonals
            let diag1 = 0, diag2 = 0;
            for (let i = 0; i < 5; i++) {
                if (markedNumbers.has(bingoCard[i][i])) diag1++;
                if (markedNumbers.has(bingoCard[4-i][i])) diag2++;
            }
            if (diag1 === 5) return winGame('Diagonal');
            if (diag2 === 5) return winGame('Diagonal');
            
            // Check full card
            if (markedNumbers.size === 25) return winGame('Full Card');
        }
        
        function winGame(pattern) {
            gameActive = false;
            document.getElementById('callerBtn').disabled = true;
            submitWin(pattern);
        }
        
        async function submitWin(pattern) {
            try {
                const reward = betAmount * 1000 * 2;
                const response = await fetch('api/mega-bingo-play.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ bet_amount: betAmount * 1000, pattern: pattern, reward: reward })
                });
                const data = await response.json();
                
                if (data.success) {
                    document.getElementById('gameBalance').textContent = '₦' + parseFloat(data.game_earnings).toLocaleString('en-NG', {minimumFractionDigits: 2, maximumFractionDigits: 2});
                    document.getElementById('resultEmoji').textContent = '🎉';
                    document.getElementById('resultTitle').textContent = 'BINGO!';
                    document.getElementById('resultMessage').textContent = 'You won with: ' + pattern;
                    document.getElementById('resultAmount').textContent = '₦' + parseFloat(reward).toLocaleString('en-NG', {minimumFractionDigits: 2, maximumFractionDigits: 2});
                    document.getElementById('resultModal').classList.add('active');
                }
            } catch (error) {
                console.error('Error:', error);
            }
        }
        
        function startGame() {
            if (!IS_PREMIUM) return;
            gameActive = true;
            calledNumbers = [];
            generateBingoCard();
            document.getElementById('callerBtn').disabled = false;
            document.getElementById('playBtn').disabled = true;
        }
        
        function increaseBet() {
            if (betAmount < 100) {
                betAmount++;
                updateBetDisplay();
            }
        }
        
        function decreaseBet() {
            if (betAmount > 1) {
                betAmount--;
                updateBetDisplay();
            }
        }
        
        function updateBetDisplay() {
            document.getElementById('betDisplay').textContent = '₦' + (betAmount * 1000).toLocaleString();
        }
        
        function openTutorialModal() {
            tutorialStep = 0;
            updateTutorialModal();
            document.getElementById('tutorialModal').classList.add('active');
        }
        
        function closeTutorialModal() {
            document.getElementById('tutorialModal').classList.remove('active');
        }
        
        function updateTutorialModal() {
            document.querySelectorAll('.tutorial-step').forEach((step, i) => {
                step.classList.toggle('active', i === tutorialStep);
            });
            document.getElementById('prevTutBtn').disabled = tutorialStep === 0;
            document.getElementById('nextTutBtn').disabled = tutorialStep === tutorialSteps - 1;
        }
        
        function nextTutorialStep() {
            if (tutorialStep < tutorialSteps - 1) {
                tutorialStep++;
                updateTutorialModal();
            }
        }
        
        function previousTutorialStep() {
            if (tutorialStep > 0) {
                tutorialStep--;
                updateTutorialModal();
            }
        }
        
        function openExchangeModal() {
            document.getElementById('exchangeGameBalance').textContent = document.getElementById('gameBalance').textContent;
            document.getElementById('exchangeModal').classList.add('active');
        }
        
        function closeExchangeModal() {
            document.getElementById('exchangeModal').classList.remove('active');
        }
        
        async function exchangeBalance() {
            const amount = parseFloat(document.getElementById('exchangeAmount').value) || 0;
            if (amount < 100) {
                showNotify('Invalid Amount', 'Minimum exchange is ₦100');
                return;
            }
            
            try {
                const response = await fetch('api/exchange-balance.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ amount: amount })
                });
                const data = await response.json();
                
                if (data.success) {
                    document.getElementById('gameBalance').textContent = '₦' + parseFloat(data.game_earnings).toLocaleString('en-NG', {minimumFractionDigits: 2, maximumFractionDigits: 2});
                    closeExchangeModal();
                    showNotify('Success', 'Balance exchanged successfully!');
                } else {
                    showNotify('Error', data.message);
                }
            } catch (error) {
                showNotify('Error', error.message);
            }
        }
        
        function closePremiumModal() {
            document.getElementById('premiumModal').classList.remove('active');
        }
        
        function closeResultModal() {
            document.getElementById('resultModal').classList.remove('active');
            document.getElementById('playBtn').disabled = false;
            gameActive = false;
        }
        
        function showNotify(title, message) {
            document.getElementById('notifyTitle').textContent = title;
            document.getElementById('notifyMessage').textContent = message;
            document.getElementById('notifyModal').classList.add('active');
        }
        
        function closeNotifyModal() {
            document.getElementById('notifyModal').classList.remove('active');
        }
        
        document.addEventListener('DOMContentLoaded', () => {
            updateBetDisplay();
        });
    </script>
</body>
</html>
