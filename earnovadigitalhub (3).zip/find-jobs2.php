<?php
session_start();
require_once 'config/database.php';
require_once 'includes/session.php';
require_once 'includes/connect.php';
require_once 'includes/email.php';

requireLogin();
checkSessionTimeout();


$user_id = $_SESSION['user_id'];

$stmt = $conn->prepare("
    SELECT u.*, b.total_balance, b.task_earnings, b.referral_earnings, v.verification_status 
    FROM users u 
    LEFT JOIN balances b ON u.id = b.user_id 
    LEFT JOIN user_verification v ON u.id = v.user_id
    WHERE u.id = ?
");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();
$stmt->close();

$is_premium = ($user['membership_type'] === 'premium');
// if (!$is_premium) {
//     header('Location: membership.php');
//     exit();
// }

$is_verified = ($user['verification_status'] === 'approved');

$user = getCurrentUser();
$user_id = $user['id'];

try {
    $pdo = getDBConnection();
    
    $stmt = $pdo->prepare("
        SELECT u.*, b.total_balance, b.task_earnings, b.referral_earnings, b.ref_balance
        FROM users u
        LEFT JOIN balances b ON u.id = b.user_id
        WHERE u.id = ?
    ");
    $stmt->execute([$user_id]);
    $user_data = $stmt->fetch();
    
    if (!$user_data) {
        header('Location: login.php');
        exit;
    }
    
    $is_member = in_array($user_data['membership_type'], ['premium']);
    
    $has_paid_bid_fee = ($user_data['bid_fee_paid'] ?? 0) == 1;
    
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'submit_bid') {
        $job_id = intval($_POST['job_id'] ?? 0);
        $cover_letter = trim($_POST['cover_letter'] ?? '');
        $proposed_rate = floatval($_POST['proposed_rate'] ?? 0);
        $payment_source = $_POST['payment_source'] ?? 'refbalance';
        
        // Validation
        if (empty($cover_letter) || $proposed_rate <= 0) {
            $_SESSION['error_message'] = 'Please fill in all required fields';
        } elseif (!$is_member) {
            $_SESSION['error_message'] = 'Only members can bid on jobs. Upgrade your membership to continue.';
        } else {
            if (!$has_paid_bid_fee) {
                $fee_amount = ($payment_source === 'refbalance') ? 1000 : 2000;
                $balance_field = ($payment_source === 'refbalance') ? 'ref_balance' : 'task_earnings';
                $current_balance = $user_data[$balance_field] ?? 0;
                
                if ($current_balance < $fee_amount) {
                    $_SESSION['error_message'] = 'Insufficient balance. You need ₦' . number_format($fee_amount, 2) . ' to place your first bid.';
                } else {
                    // Deduct fee and mark as paid
                    $pdo->beginTransaction();
                    try {
                        // Deduct from balance
                        $stmt = $pdo->prepare("UPDATE balances SET $balance_field = $balance_field - ?, total_balance = total_balance - ? WHERE user_id = ?");
                        $stmt->execute([$fee_amount, $fee_amount, $user_id]);
                        
                        // Mark bid fee as paid
                        $stmt = $pdo->prepare("UPDATE users SET bid_fee_paid = 1 WHERE id = ?");
                        $stmt->execute([$user_id]);
                        
                        // Record transaction
                        $stmt = $pdo->prepare("INSERT INTO transactions (user_id, transaction_type, amount, balance_type, description, created_at) VALUES (?, 'bid_fee', ?, ?, 'First bid fee payment', NOW())");
                        $stmt->execute([$user_id, $fee_amount, $payment_source]);
                        
                        // Submit bid
                        $stmt = $pdo->prepare("INSERT INTO job_bids (job_id, user_id, cover_letter, proposed_rate, bid_status, created_at) VALUES (?, ?, ?, ?, 'pending', NOW())");
                        $stmt->execute([$job_id, $user_id, $cover_letter, $proposed_rate]);
                        
                        $pdo->commit();
                        $_SESSION['success_message'] = 'Bid submitted successfully! Your bid is pending approval.';
                        $has_paid_bid_fee = true;
                    } catch (Exception $e) {
                        $pdo->rollBack();
                        $_SESSION['error_message'] = 'Failed to submit bid. Please try again.';
                        error_log("Bid submission error: " . $e->getMessage());
                    }
                }
            } else {
                // User has already paid fee, just submit bid
                try {
                    $stmt = $pdo->prepare("INSERT INTO job_bids (job_id, user_id, cover_letter, proposed_rate, bid_status, created_at) VALUES (?, ?, ?, ?, 'pending', NOW())");
                    $stmt->execute([$job_id, $user_id, $cover_letter, $proposed_rate]);
                    $_SESSION['success_message'] = 'Bid submitted successfully! Your bid is pending approval.';
                } catch (Exception $e) {
                    $_SESSION['error_message'] = 'Failed to submit bid. You may have already bid on this job.';
                    error_log("Bid submission error: " . $e->getMessage());
                }
            }
        }
        
        header('Location: find-jobs.php');
        exit;
    }
    
    $career1 = $user_data['career1'] ?? '';
    $career2 = $user_data['career2'] ?? '';
    
    $query = "
        SELECT j.*, u.username as posted_by,
        (SELECT COUNT(*) FROM job_bids WHERE job_id = j.id AND user_id = ?) as user_has_bid
        FROM jobs j
        LEFT JOIN users u ON j.created_by = u.id
        WHERE j.is_active = 1 AND j.approval_status = 'approved'
    ";
    
    if (!empty($career1) || !empty($career2)) {
        $query .= " AND (j.career_category = ? OR j.career_category = ?)";
        $stmt = $pdo->prepare($query . " ORDER BY j.created_at DESC");
        $stmt->execute([$user_id, $career1, $career2]);
    } else {
        $stmt = $pdo->prepare($query . " ORDER BY j.created_at DESC");
        $stmt->execute([$user_id]);
    }
    
    $jobs = $stmt->fetchAll();
    
} catch (PDOException $e) {
    error_log("Find Jobs Error: " . $e->getMessage());
    $error_message = "Unable to load jobs.";
}

$username = htmlspecialchars($user_data['username'] ?? 'User');
$success_message = $_SESSION['success_message'] ?? '';
$error_message = $_SESSION['error_message'] ?? '';
unset($_SESSION['success_message'], $_SESSION['error_message']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Find Jobs - FlowEarner</title>
  <link rel="stylesheet" href="post-task.css" />
</head>
<body>

<?php if ($success_message): ?>
  <div id="alert-toast" class="alert-message alert-success">
    <?php echo htmlspecialchars($success_message); ?>
  </div>
<?php endif; ?>

<?php if ($error_message): ?>
  <div id="alert-toast" class="alert-message alert-error">
    <?php echo htmlspecialchars($error_message); ?>
  </div>
<?php endif; ?>

<style>
.alert-message {
  position: fixed;
  top: 20px;
  right: -400px;
  padding: 16px 24px;
  border-radius: 12px;
  font-family: 'Segoe UI', sans-serif;
  font-size: 15px;
  z-index: 1000;
  opacity: 0;
  box-shadow: 0 10px 40px rgba(0, 0, 0, 0.2);
  transition: right 0.6s ease, opacity 0.6s ease;
  color: #fff;
}

.alert-success {
  background: rgba(77, 225, 193, 0.95);
  color: #030922;
  box-shadow: 0 10px 40px rgba(77, 225, 193, 0.4);
}

.alert-error {
  background: rgba(255, 77, 77, 0.95);
  color: #fff;
  box-shadow: 0 10px 40px rgba(255, 77, 77, 0.4);
}

.alert-message.show {
  right: 20px;
  opacity: 1;
}

.jobs-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(320px, 1fr));
  gap: 24px;
  margin-top: 32px;
}

.job-card {
  background: rgba(6, 16, 48, 0.9);
  border: 1px solid rgba(100, 154, 255, 0.24);
  border-radius: 20px;
  padding: 24px;
  transition: all 0.3s ease;
  position: relative;
  overflow: hidden;
}

.job-card:hover {
  border-color: rgba(77, 225, 193, 0.45);
  transform: translateY(-4px);
}

.job-badge {
  display: inline-block;
  padding: 6px 14px;
  background: rgba(77, 225, 193, 0.2);
  border: 1px solid rgba(77, 225, 193, 0.3);
  border-radius: 16px;
  font-size: 0.75rem;
  letter-spacing: 0.08em;
  text-transform: uppercase;
  color: var(--page-mint);
  margin-bottom: 12px;
  font-weight: 600;
}

.job-title {
  font-size: 1.3rem;
  margin: 0 0 12px;
  color: var(--page-white);
  font-weight: 700;
}

.job-meta {
  display: flex;
  flex-wrap: wrap;
  gap: 16px;
  margin-bottom: 16px;
  font-size: 0.9rem;
  color: rgba(216, 230, 255, 0.7);
}

.job-description {
  color: rgba(216, 230, 255, 0.85);
  line-height: 1.7;
  margin-bottom: 20px;
}

.bid-btn {
  width: 100%;
  padding: 14px 24px;
  border: none;
  border-radius: 12px;
  background: linear-gradient(135deg, var(--page-mint), var(--page-blue-300));
  color: var(--page-blue-900);
  font-weight: 600;
  cursor: pointer;
  transition: transform 0.3s;
  font-size: 0.95rem;
  text-transform: uppercase;
  letter-spacing: 0.04em;
}

.bid-btn:hover {
  transform: translateY(-2px);
}

.bid-btn:disabled {
  background: rgba(100, 152, 255, 0.3);
  color: rgba(210, 224, 253, 0.5);
  cursor: not-allowed;
}

.modal {
  display: none;
  position: fixed;
  inset: 0;
  background: rgba(3, 9, 30, 0.9);
  backdrop-filter: blur(8px);
  z-index: 2000;
  align-items: center;
  justify-content: center;
  padding: 20px;
}

.modal.active {
  display: flex;
}

.modal-content {
  background: rgba(6, 16, 48, 0.98);
  border: 1px solid rgba(100, 154, 255, 0.3);
  border-radius: 24px;
  padding: 32px;
  max-width: 600px;
  width: 100%;
  max-height: 90vh;
  overflow-y: auto;
}

.form-group {
  margin-bottom: 20px;
}

.form-group label {
  display: block;
  margin-bottom: 8px;
  color: rgba(216, 230, 255, 0.9);
  font-weight: 600;
  font-size: 0.9rem;
  text-transform: uppercase;
  letter-spacing: 0.04em;
}

.form-group input,
.form-group textarea,
.form-group select {
  width: 100%;
  padding: 12px 16px;
  border-radius: 10px;
  border: 1px solid rgba(86, 139, 241, 0.3);
  background: rgba(13, 24, 62, 0.5);
  color: var(--page-white);
  font-size: 1rem;
  font-family: inherit;
}

.form-group textarea {
  resize: vertical;
  min-height: 120px;
}

.modal-actions {
  display: flex;
  gap: 12px;
  margin-top: 24px;
}

.btn-secondary {
  flex: 1;
  padding: 12px 24px;
  border: 1px solid rgba(86, 139, 241, 0.3);
  border-radius: 10px;
  background: transparent;
  color: var(--page-white);
  cursor: pointer;
  font-weight: 600;
  transition: all 0.3s ease;
}

.btn-secondary:hover {
  border-color: rgba(77, 225, 193, 0.5);
}

.btn-primary {
  flex: 1;
  padding: 12px 24px;
  border: none;
  border-radius: 10px;
  background: linear-gradient(135deg, var(--page-mint), var(--page-blue-300));
  color: var(--page-blue-900);
  font-weight: 600;
  cursor: pointer;
  transition: all 0.3s ease;
}

.btn-primary:hover {
  transform: translateY(-2px);
}

.fee-notice {
  background: rgba(251, 191, 36, 0.2);
  border: 1px solid rgba(251, 191, 36, 0.4);
  border-radius: 12px;
  padding: 16px;
  margin-bottom: 20px;
  color: #fbbf24;
  font-size: 0.9rem;
}
</style>

<script>
document.addEventListener("DOMContentLoaded", () => {
  const alertToast = document.getElementById("alert-toast");
  if (alertToast) {
    setTimeout(() => alertToast.classList.add("show"), 100);
    setTimeout(() => alertToast.classList.remove("show"), 4000);
  }
});
</script>

  <div class="page-shell">
    <aside id="sidebar">
      <a class="back-link" href="dashboard.php">← Dashboard</a>
      <div class="aside-welcome">
        <div class="aside-avatar">
          <img src="<?php echo !empty($user_data['profile_picture']) ? htmlspecialchars($user_data['profile_picture']) : 'front/assets/images/default-avatar.png'; ?>" alt="User avatar">
        </div>
        <div>
          <p class="welcome-tag">Job Seeker</p>
          <h3><?php echo $username; ?></h3>
          <p class="welcome-meta"><?php echo $is_premium ? 'Member' : 'Free User'; ?></p>
        </div>
      </div>
      <div>
        <h2 class="page-title">Find Jobs</h2>
        <p class="side-description">Browse available jobs matching your career category and submit your bids to start earning.</p>
      </div>
    </aside>
    
    <main>
      <section class="hero-section">
        <div class="hero-content">
          <h1>Job Marketplace</h1>
          <p>Find jobs matching your skills and expertise. <?php echo !$is_member ? 'Upgrade to membership to start bidding.' : ($has_paid_bid_fee ? 'Submit your bids now!' : 'First bid costs ₦1,000 (refbalance) or ₦2,000 (taskbalance).'); ?></p>
        </div>
      </section>

      <?php if (!$is_member): ?>
        <div style="padding: 20px; background: rgba(239, 68, 68, 0.2); border: 1px solid rgba(239, 68, 68, 0.4); border-radius: 12px; color: #ef4444; margin-bottom: 24px;">
          <strong>⚠ Membership Required</strong><br>
          Only members can bid on jobs. Upgrade your membership to start earning from the job marketplace.
          <a href="membership.php" style="display: inline-block; margin-top: 12px; padding: 10px 20px; background: rgba(239, 68, 68, 0.3); border-radius: 8px; color: #ef4444; text-decoration: none; font-weight: 600;">Upgrade Now →</a>
        </div>
      <?php endif; ?>

      <section>
        <h2 style="font-size: 1.5rem; margin-bottom: 20px; color: var(--page-white);">💼 Available Jobs (<?php echo count($jobs); ?>)</h2>
        
        <?php if (empty($jobs)): ?>
          <div style="padding: 60px 40px; text-align: center; background: rgba(6, 16, 48, 0.9); border: 1px solid rgba(100, 154, 255, 0.24); border-radius: 20px;">
            <svg viewBox="0 0 24 24" width="80" height="80" fill="rgba(77, 225, 193, 0.3)" style="margin-bottom: 24px;">
              <path d="M20 6h-4V4c0-1.1-.9-2-2-2h-4c-1.1 0-2 .9-2 2v2H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V8c0-1.1-.9-2-2-2zM10 4h4v2h-4V4zm10 16H4V8h16v12z"/>
            </svg>
            <h2 style="color: var(--page-white); margin-bottom: 12px;">No Jobs Available</h2>
            <p style="color: rgba(216, 230, 255, 0.7);">Check back soon for new job opportunities matching your career!</p>
          </div>
        <?php else: ?>
          <div class="jobs-grid">
            <?php foreach ($jobs as $job): ?>
              <article class="job-card">
                <span class="job-badge"><?php echo htmlspecialchars($job['career_category']); ?></span>
                <h3 class="job-title"><?php echo htmlspecialchars($job['title']); ?></h3>
                
                <div class="job-meta">
                  <span>💰 ₦<?php echo number_format($job['payment_amount'], 2); ?></span>
                  <span>⏱ <?php echo $job['duration_days']; ?> days</span>
                  <span>📅 <?php echo date('M d, Y', strtotime($job['created_at'])); ?></span>
                </div>
                
                <p class="job-description"><?php echo nl2br(htmlspecialchars(substr($job['description'], 0, 150))) . (strlen($job['description']) > 150 ? '...' : ''); ?></p>
                
                <?php if ($job['user_has_bid']): ?>
                  <button class="bid-btn" disabled>Already Bid</button>
                <?php else: ?>
                  <button class="bid-btn" onclick="openBidModal(<?php echo $job['id']; ?>, '<?php echo htmlspecialchars($job['title'], ENT_QUOTES); ?>', <?php echo $job['payment_amount']; ?>)" <?php echo !$is_member ? 'disabled' : ''; ?>>
                    <?php echo $is_member ? 'Submit Bid' : 'Membership Required'; ?>
                  </button>
                <?php endif; ?>
              </article>
            <?php endforeach; ?>
          </div>
        <?php endif; ?>
      </section>
    </main>
  </div>

  <!-- Bid Modal -->
  <div id="bidModal" class="modal">
    <div class="modal-content">
      <h2 style="margin-top: 0; color: var(--page-white);">Submit Your Bid</h2>
      <p id="modalJobTitle" style="color: rgba(216, 230, 255, 0.7); margin-bottom: 24px;"></p>
      
      <?php if (!$has_paid_bid_fee): ?>
        <div class="fee-notice">
          <strong>⚠ First Bid Fee Required</strong><br>
          Your first bid requires a one-time fee of ₦1,000 (from refbalance) or ₦2,000 (from taskbalance). After this, all future bids are free!
        </div>
      <?php endif; ?>
      
      <form method="POST">
        <input type="hidden" name="action" value="submit_bid" />
        <input type="hidden" name="job_id" id="modalJobId" />
        
        <div class="form-group">
          <label>Your Proposed Rate (₦)</label>
          <input type="number" name="proposed_rate" id="proposedRate" required min="0" step="0.01" />
          <small style="color: rgba(216, 230, 255, 0.6); display: block; margin-top: 4px;">Suggested: ₦<span id="suggestedRate">0.00</span></small>
        </div>
        
        <?php if (!$has_paid_bid_fee): ?>
          <div class="form-group">
            <label>Payment Source for Bid Fee</label>
            <select name="payment_source" required>
              <option value="refbalance">Refbalance (₦1,000)</option>
              <option value="taskbalance">Taskbalance (₦2,000)</option>
            </select>
            <small style="color: rgba(216, 230, 255, 0.6); display: block; margin-top: 4px;">
              Your balance: Refbalance ₦<?php echo number_format($user_data['ref_balance'] ?? 0, 2); ?> | Taskbalance ₦<?php echo number_format($user_data['task_earnings'] ?? 0, 2); ?>
            </small>
          </div>
        <?php endif; ?>
        
        <div class="form-group">
          <label>Cover Letter</label>
          <textarea name="cover_letter" required placeholder="Explain why you're the best fit for this job..."></textarea>
        </div>
        
        <div class="modal-actions">
          <button type="button" class="btn-secondary" onclick="closeBidModal()">Cancel</button>
          <button type="submit" class="btn-primary">Submit Bid</button>
        </div>
      </form>
    </div>
  </div>

  <nav class="mobile-fintech-footer">
    <a href="dashboard.php">
      <svg viewBox="0 0 24 24"><path d="M12 3a9 9 0 1 1 0 18 9 9 0 0 1 0-18Zm1 4h-2v6h6v-2h-4V7Z"/></svg>
      <span>Dashboard</span>
    </a>
    <a href="membership.php">
      <svg viewBox="0 0 24 24"><path d="M5 7l2.5 5 4.5-4 4.5 4L19 7l2 13H3l2-13Z"/></svg>
      <span>Premium</span>
    </a>
    <a href="find-jobs.php" class="active">
      <svg viewBox="0 0 24 24"><path d="M9 2h6a2 2 0 0 1 2 2v2h3v16H4V6h3V4a2 2 0 0 1 2-2zm0 4h6V4H9v2zm2 6h2v5h-2v-5z"/></svg>
      <span>Find Jobs</span>
    </a>
    <a href="my-bids.php">
      <svg viewBox="0 0 24 24"><path d="M13 2v8h8M12 2a10 10 0 1 0 10 10h-2a8 8 0 1 1-8-8V2z"/></svg>
      <span>My Bids</span>
    </a>
    <a href="profile.php">
      <svg viewBox="0 0 24 24"><path d="M12 2a6 6 0 0 1 6 6c0 3.31-2.69 6-6 6s-6-2.69-6-6a6 6 0 0 1 6-6Zm0 14c4.42 0 8 1.79 8 4v2H4v-2c0-2.21 3.58-4 8-4Z"/></svg>
      <span>Profile</span>
    </a>
  </nav>

  <script>
    function openBidModal(jobId, jobTitle, paymentAmount) {
      document.getElementById('modalJobId').value = jobId;
      document.getElementById('modalJobTitle').textContent = jobTitle;
      document.getElementById('suggestedRate').textContent = paymentAmount.toFixed(2);
      document.getElementById('proposedRate').value = paymentAmount.toFixed(2);
      document.getElementById('bidModal').classList.add('active');
    }
    
    function closeBidModal() {
      document.getElementById('bidModal').classList.remove('active');
    }
    
    // Close modal on outside click
    document.getElementById('bidModal').addEventListener('click', function(e) {
      if (e.target === this) {
        closeBidModal();
      }
    });
  </script>
</body>
</html>
