<?php
require_once 'config/database.php';
require_once 'includes/session.php';
require_once 'includes/connect.php';

// Require authentication
requireLogin();
checkSessionTimeout();

error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('log_errors', 1);
ini_set('error_log', __DIR__ . '/error_log.txt');

// Get current user data
$user = getCurrentUser();
$user_id = $user['id'];

$error_message = '';
$success_message = '';
$paired_user = null;
$trigger_error_display = false;

$profile_incomplete = false;
$missing_requirements = [];
$completed_requirements = [];

// Flag to indicate if the premium popup should be shown
$show_premium_popup = false;

try {
    $pdo = getDBConnection();
    
    // Fetch user details
    $stmt = $pdo->prepare("
        SELECT u.*, b.total_balance, b.task_earnings, b.referral_earnings
        FROM users u
        LEFT JOIN balances b ON u.id = b.user_id
        WHERE u.id = ?
    ");
    $stmt->execute([$user_id]);
    $user_data = $stmt->fetch();
    
    if (!$user_data) {
        header('Location: login.php');
        exit;
    }
    
    $stmt = $pdo->prepare("
        SELECT u.id, u.username, u.full_name, u.whatsapp_number, u.profile_picture, u.gender,
               ch.is_premium_pair, ch.can_view_details, ch.paired_at, ch.expires_at
        FROM chat_earn_history ch
        JOIN users u ON ch.paired_user_id = u.id
        WHERE ch.user_id = ? AND ch.expires_at > NOW()
        ORDER BY ch.paired_at DESC
        LIMIT 1
    ");
    $stmt->execute([$user_id]);
    $existing_pair = $stmt->fetch();
    
    if ($existing_pair) {
        $paired_user = $existing_pair;
    }
    
    
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['cancel_progress'])) {
        $stmt = $pdo->prepare("UPDATE users SET chat_earn_progress = NULL, chat_earn_selected_gender = NULL WHERE id = ?");
        $stmt->execute([$user_id]);
        $user_data['chat_earn_progress'] = null;
        $user_data['chat_earn_selected_gender'] = null;
        $success_message = "Progress reset! You can start fresh.";
        $trigger_error_display = true;
    }
    
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['selected_gender'])) {
        $trigger_error_display = true;
        $selected_gender = $_POST['selected_gender'];
        
        if (!in_array($selected_gender, ['male', 'female'])) {
            $error_message = "Invalid gender selection.";
        } else {
            $stmt = $pdo->prepare("UPDATE users SET chat_earn_selected_gender = ?, chat_earn_progress = 'gender_selected' WHERE id = ?");
            $stmt->execute([$selected_gender, $user_id]);
            $user_data['chat_earn_selected_gender'] = $selected_gender;
            $user_data['chat_earn_progress'] = 'gender_selected';
            
            if (empty($user_data['whatsapp_number'])) {
                $missing_requirements[] = 'Add your WhatsApp number';
            } else {
                $completed_requirements[] = 'WhatsApp number added';
            }
            
            if (empty($user_data['profile_picture']) || $user_data['profile_picture'] === 'front/assets/images/default-avatar.png') {
                $missing_requirements[] = 'Upload a profile picture';
            } else {
                $completed_requirements[] = 'Profile picture uploaded';
            }
            
            if (empty($user_data['gender'])) {
                $missing_requirements[] = 'Set Your Gender on profile page';
            } else {
                $completed_requirements[] = 'Gender set on profile';
            }
            
            if (!$user_data['chat_earn_enabled']) {
                $missing_requirements[] = 'Enable Echo-Chat in Profile Settings';
            } else {
                $completed_requirements[] = 'Echo-Chat enabled';
            }
            
            if (!empty($missing_requirements)) {
                $profile_incomplete = true;
                $stmt = $pdo->prepare("UPDATE users SET chat_earn_progress = 'requirements_check' WHERE id = ?");
                $stmt->execute([$user_id]);
            } else {
                // Profile is complete, proceed to pairing
                $stmt = $pdo->prepare("UPDATE users SET chat_earn_progress = 'requirements_complete' WHERE id = ?");
                $stmt->execute([$user_id]);
            }
        }
    }
    
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['continue_pairing'])) {
        $trigger_error_display = true;
        $selected_gender = $user_data['chat_earn_selected_gender'];
        
        error_log("[CHAT-EARN] Continue pairing clicked by user ID: " . $user_id);
        error_log("[CHAT-EARN] Selected gender: " . $selected_gender);
        error_log("[CHAT-EARN] User membership: " . $user_data['advertiser_plan']);
        
        if (!$selected_gender) {
            $error_message = "Please select a gender first.";
            error_log("[CHAT-EARN] ERROR: No gender selected");
        } else {
            // Check if already paired today
            if ($paired_user) {
                $error_message = "You have an active pairing! Come back after it expires.";
                error_log("[CHAT-EARN] ERROR: User already has active pairing");
            } else {
                $is_premium = $user_data['advertiser_plan'] === 'senior';
                
                // Check if terms are agreed for continue pairing
                $terms_agreed = isset($_POST['terms_agreed']) && $_POST['terms_agreed'] === 'on';
                if (!$terms_agreed) {
                    $error_message = "Please agree to the Terms and Policy to continue.";
                    $trigger_error_display = true;
                } else {
                    try {
                        if ($is_premium) {
                            // Real-time pairing for premium users
                            $user_gender = $user_data['gender']; // Current user's gender
                            $match_gender = $selected_gender; // Gender they want to match with
                            
                            error_log("[CHAT-EARN] Premium user - searching for match. User gender: $user_gender, Looking for: $match_gender");
                            
                            $stmt = $pdo->prepare("
                                SELECT u.id, u.username, u.full_name, u.whatsapp_number, u.profile_picture, u.gender
                                FROM users u
                                WHERE u.gender = ?
                                AND u.chat_earn_enabled = 1
                                AND u.id != ?
                                AND u.whatsapp_number IS NOT NULL
                                AND u.profile_picture IS NOT NULL
                                AND u.profile_picture != 'front/assets/images/default-avatar.png'
                                AND u.id NOT IN (
                                    SELECT paired_user_id 
                                    FROM chat_earn_history 
                                    WHERE user_id = ?
                                )
                                ORDER BY RAND()
                                LIMIT 1
                            ");
                            $stmt->execute([$match_gender, $user_id, $user_id]);
                            $paired_user = $stmt->fetch();
                            
                            error_log("[CHAT-EARN] Query executed. Found match: " . ($paired_user ? "YES (ID: " . $paired_user['id'] . ")" : "NO"));
                            
                            if ($paired_user) {
                                $expires_at = date('Y-m-d H:i:s', strtotime('+24 hours'));
                                
                                error_log("[CHAT-EARN] Inserting pairing record. Expires at: $expires_at");
                                
                                $stmt = $pdo->prepare("
                                    INSERT INTO chat_earn_history (user_id, paired_user_id, paired_at, expires_at, is_premium_pair, can_view_details)
                                    VALUES (?, ?, NOW(), ?, TRUE, TRUE)
                                ");
                                $stmt->execute([$user_id, $paired_user['id'], $expires_at]);
                                
                                error_log("[CHAT-EARN] Pairing record inserted. Updating user progress.");
                                
                                $stmt = $pdo->prepare("UPDATE users SET chat_earn_last_paired = NOW(), chat_earn_progress = 'paired' WHERE id = ?");
                                $stmt->execute([$user_id]);

                                
                               
                                $success_message = "Successfully paired with " . htmlspecialchars($paired_user['full_name']) . "!";
                                error_log("[CHAT-EARN] SUCCESS: User paired successfully");
                                
                                header("Location: " . $_SERVER['PHP_SELF']);
                                exit;
                            } else {
                                $error_message = "No available users to pair with. Please try again later.";
                                error_log("[CHAT-EARN] ERROR: No available users found for pairing");
                            }
                        } else {
                            error_log("[CHAT-EARN] Free user - showing premium popup");
                            
                            // Set flag to show premium popup
                            $show_premium_popup = true;
                            $error_message = "Upgrade to Premium to access Echo-Chat features!";
                            error_log("[CHAT-EARN] Premium popup will be shown to free user");
                            
                        }
                    } catch (Exception $e) {
                        $error_message = "Database error: " . $e->getMessage();
                        error_log("[CHAT-EARN] EXCEPTION: " . $e->getMessage());
                        error_log("[CHAT-EARN] Stack trace: " . $e->getTraceAsString());
                    }
                }
            }
        }
    }
    
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['send_message'])) {
        $message_text = trim($_POST['message_text']);
        $is_premium = $user_data['advertiser_plan'] === 'senior';
        
        if (!$is_premium) {
            $error_message = "Upgrade to Premium to send messages!";
            $trigger_error_display = true;
        } elseif ($paired_user && !empty($message_text)) {
            // Save message to database
            $stmt = $pdo->prepare("
                INSERT INTO chat_earn_messages (user_id, paired_user_id, message_text, is_from_user)
                VALUES (?, ?, ?, TRUE)
            ");
            $stmt->execute([$user_id, $paired_user['id'], $message_text]);
            $success_message = "Message sent!";
            $trigger_error_display = true;
        }
    }
    
} catch (PDOException $e) {
    error_log("Error: " . $e->getMessage());
    $error_message = "Unable to load  data.";
}

$full_name = htmlspecialchars($user_data['full_name'] ?? 'User');
$username = htmlspecialchars($user_data['username'] ?? 'user');
$membership_status = $user_data['advertiser_plan'] === 'senior' ? 'Premium Plus' : 'Free Member';
$avatar_url = !empty($user_data['profile_picture']) ? $user_data['profile_picture'] : 'front/assets/images/default-avatar.png';
$is_premium = $user_data['advertiser_plan'] === 'senior';
?>

<?php include "doctype.php"; ?>
  <link rel="stylesheet" href="assets/css/gamified-fintech-theme.css">
  <style>
    :root {
      --page-blue-900: #030922;
      --page-blue-700: #0a164a;
      --page-blue-500: #142a7e;
      --page-blue-300: #2c5bf5;
      --page-mint: #4de1c1;
      --page-white: #f5f9ff;
      --panel-glass: rgba(13, 24, 62, 0.78);
      --panel-border: rgba(86, 139, 241, 0.28);
      --shadow-heavy: 0 40px 120px rgba(4, 10, 36, 0.65);
      --transition-long: 0.85s cubic-bezier(0.19, 1, 0.22, 1);
      --transition-short: 0.4s ease;
      /* Added for terms modal */
      --primary: #2c5bf5; 
    }

    * { box-sizing: border-box; }

    body {
      margin: 0;
      font-family: "Titillium Web", "Segoe UI", sans-serif;
     background: #030922;
      color: var(--page-white);
      overflow-x: hidden;
      padding-bottom: 100px;
    }

    .page-shell {
      min-height: 100vh;
      display: flex;
    }

    aside {
      position: fixed;
      left: 0;
      top: 0;
      bottom: 0;
      width: 320px;
      background: rgba(5, 15, 44, 0.92);
      backdrop-filter: blur(18px);
      padding: 28px 24px;
      display: flex;
      flex-direction: column;
      gap: 24px;
      border-right: 1px solid rgba(255, 140, 80, 0.3);
      box-shadow: 4px 0 40px rgba(255, 107, 53, 0.15);
      overflow-y: auto;
      z-index: 100;
    }

    main {
      margin-left: 320px;
      flex: 1;
      padding: 32px 40px;
      display: grid;
      gap: 32px;
    }

    @media (max-width: 960px) {
      .page-shell { display: block; }
      aside {
        position: relative;
        width: 100%;
        height: auto;
        border-right: none;
        border-bottom: 1px solid var(--panel-border);
      }
      main { margin-left: 0; padding: 32px 20px 160px; }
    }

    .back-link {
      display: inline-flex;
      align-items: center;
      gap: 10px;
      font-weight: 600;
      font-size: clamp(0.75rem, 1.5vw, 0.875rem);
      letter-spacing: 0.1em;
      text-transform: uppercase;
      color: rgba(210, 226, 255, 0.78);
      transition: color var(--transition-short), transform var(--transition-short);
      text-decoration: none;
    }

    .back-link:hover { color: var(--page-white); transform: translateX(-4px); }

    .page-title {
      font-size: clamp(1rem, 3vw, 1.5rem);
      letter-spacing: 0.08em;
      text-transform: uppercase;
      margin: 0;
    }

    .aside-welcome {
      display: grid;
      grid-template-columns: auto 1fr;
      align-items: center;
      gap: clamp(0.75rem, 1.5vw, 1rem);
       background: linear-gradient(135deg, rgba(44, 91, 245, 0.3), rgba(26, 58, 171, 0.2));
      border: 1px solid rgba(44, 91, 245, 0.5);
      box-shadow: 0 0 10px rgba(44, 91, 245, 0.6);
      border-radius: 20px;
      padding: clamp(0.875rem, 1.75vw, 1.125rem);
      
      position: relative;
      z-index: 2;
    }

    .aside-avatar {
      width: clamp(48px, 10vw, 64px);
      height: clamp(48px, 10vw, 64px);
      border-radius: 50%;
      overflow: hidden;
      border: 4px solid rgba(251, 191, 36, 0.35);
      box-shadow: 0 14px 34px rgba(3, 9, 30, 0.55);
    }

    .aside-avatar img {
      width: 100%;
      display: block;
    }

    .welcome-tag {
      margin: 0;
      font-size: clamp(0.6875rem, 1.25vw, 0.75rem);
      letter-spacing: 0.12em;
      text-transform: uppercase;
      color: rgba(205, 219, 255, 0.62);
    }

    .aside-welcome h3 {
      margin: clamp(0.25rem, 0.5vw, 0.375rem) 0 clamp(0.125rem, 0.25vw, 0.25rem);
      font-size: clamp(1rem, 2vw, 1.12rem);
      letter-spacing: 0.04em;
      color: var(--page-white);
      font-weight: 700;
    }

    .welcome-meta {
      font-size: clamp(0.75rem, 1.5vw, 0.8rem);
      letter-spacing: 0.08em;
      color: rgba(149, 183, 255, 0.7);
    }

    .side-description {
      line-height: 1.6;
      font-size: clamp(0.85rem, 1.5vw, 0.95rem);
    }

    .hero-section {
      background: var(--panel-glass);
      border: 1px solid var(--panel-border);
      border-radius: 24px;
      padding: clamp(24px, 4vw, 36px);
      box-shadow: var(--shadow-heavy);
      position: relative;
      overflow: hidden;
    }

    .hero-section::before {
      content: "";
      position: absolute;
      inset: 0;
      background: url("front/assets/images/header-right-img.png") center/cover no-repeat;
      opacity: 0.08;
    }

    .hero-content {
      position: relative;
      z-index: 2;
      text-align: center;
    }

    .hero-content h1 {
      margin: 0 0 12px;
      font-size: clamp(1rem, 3vw, 1.5rem);
      letter-spacing: -0.01em;
    }

    .highlight {
      color: var(--page-mint);
    }

    .hero-content p {
      margin: 0 0 24px;
      color: rgba(216, 230, 255, 0.78);
      line-height: 1.7;
      font-size: clamp(0.9rem, 2vw, 1rem);
    }

    .gender-selector {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(200px, 2fr));
      gap: 20px;
      margin-top: 32px;
    }

    .gender-card {
      background: rgba(6, 16, 48, 0.9);
      border: 2px solid rgba(100, 154, 255, 0.24);
      border-radius: 20px;
      padding: 32px 24px;
      text-align: center;
      cursor: pointer;
      transition: all var(--transition-short);
      position: relative;
      overflow: hidden;
      display: flex; /* Changed to flex for better content alignment */
      flex-direction: column; /* Stack items vertically */
      justify-content: center; /* Center content vertically */
      align-items: center; /* Center content horizontally */
      height: 180px; /* Fixed height for consistency */
    }

    .gender-card::after {
      content: "";
      position: absolute;
      width: 100px;
      height: 100px;
      top: -20px;
      right: -14px;
      border-radius: 50%;
      background: radial-gradient(circle, rgba(77, 225, 193, 0.28), transparent 60%);
    }

    .gender-card:hover {
      transform: translateY(-8px);
      border-color: var(--page-mint);
      box-shadow: 0 20px 60px rgba(77, 225, 193, 0.3);
    }

    .gender-card svg {
      width: 180px;
      height: 180px;
      margin-bottom: 16px;
      fill: var(--page-mint);
    }

    .gender-card h3 {
      margin: 0 0 8px;
      font-size: 1.4rem;
      letter-spacing: 0.05em;
      color: white; /* Ensure text is visible */
    }

    .gender-card p {
      margin: 0;
      color: rgba(205, 219, 255, 0.7);
      font-size: 0.9rem;
    }

    /* Optimized Mobile Layout */
    @media (max-width: 600px) {
      .gender-selector {
        grid-template-columns: repeat(2, 1fr); /* Two cards side-by-side */
        gap: 20px; /* 20px space between them */
      }

      .gender-card {
        padding: 20px;
        border-radius: 14px;
        width: 110px !important; /* Override inline style if any */
        height: 120px !important; /* Fixed height for consistency */
      }

      .gender-card svg {
        width: 80px !important;
        height: 80px !important;
        margin-bottom: 10px;
      }

      .gender-card h3 {
        font-size: 11px;
        color: white;
      }

      .gender-card p {
        font-size: 0.75rem;
        color: white;
      }
    }

    .paired-user-card {
      background: linear-gradient(135deg, rgba(77, 225, 193, 0.15), rgba(47, 91, 234, 0.15));
      border: 2px solid var(--page-mint);
      border-radius: 24px;
      padding: 36px;
      text-align: center;
      box-shadow: var(--shadow-heavy);
      animation: fadeIn 0.6s ease;
      cursor: pointer;
      transition: all 0.3s ease;
    }

    .paired-user-card:hover {
      transform: translateY(-4px);
      box-shadow: 0 20px 60px rgba(77, 225, 193, 0.4);
    }

    @keyframes fadeIn {
      from { opacity: 0; transform: scale(0.9); }
      to { opacity: 1; transform: scale(1); }
    }

    .paired-avatar {
      width: 120px;
      height: 120px;
      border-radius: 50%;
      margin: 0 auto 20px;
      border: 4px solid var(--page-mint);
      overflow: hidden;
      box-shadow: 0 20px 60px rgba(77, 225, 193, 0.4);
    }

    .paired-avatar img {
      width: 100%;
      display: block;
    }

    .paired-user-card h2 {
      margin: 0 0 12px;
      font-size: 2rem;
      color: var(--page-mint);
    }

    .paired-user-card p {
      margin: 0 0 24px;
      color: rgba(216, 230, 255, 0.78);
      line-height: 1.7;
    }

    .whatsapp-number {
      background: rgba(37, 211, 102, 0.15);
      border: 2px solid rgba(37, 211, 102, 0.4);
      border-radius: 16px;
      padding: 20px;
      margin: 24px 0;
      font-size: 1.4rem;
      font-weight: 700;
      letter-spacing: 0.05em;
      color: #25d366;
    }

    .action-buttons {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
      gap: 16px;
      margin-top: 24px;
    }

    .btn-cta {
      border: none;
      border-radius: 16px;
      padding: 14px 24px;
      font-weight: 600;
      letter-spacing: 0.04em;
      text-transform: uppercase;
      cursor: pointer;
      background: rgba(45, 92, 230, 0.72);
      color: var(--page-white);
      border: 1px solid rgba(115, 166, 255, 0.4);
      transition: transform var(--transition-short);
      font-size: 0.9rem;
      text-decoration: none;
      display: inline-block;
      text-align: center;
    }

    .btn-cta:hover {
      transform: translateY(-4px);
    }

    .btn-whatsapp {
      background: linear-gradient(135deg, #25d366 0%, #128c7e 100%);
      border-color: rgba(37, 211, 102, 0.6);
    }

    .btn-whatsapp:hover {
      box-shadow: 0 12px 40px rgba(37, 211, 102, 0.4);
    }

    .alert {
      padding: 20px 24px;
      border-radius: 16px;
      margin-bottom: 24px;
      font-weight: 600;
      letter-spacing: 0.02em;
    }

    .alert-error {
      background: rgba(255, 77, 77, 0.15);
      border: 2px solid rgba(255, 77, 77, 0.4);
      color: #ff6b6b;
    }

    .alert-success {
      background: rgba(77, 225, 193, 0.15);
      border: 2px solid rgba(77, 225, 193, 0.4);
      color: var(--page-mint);
    }

    .info-section {
      background: var(--panel-glass);
      border: 1px solid var(--panel-border);
      box-shadow: var(--shadow-heavy);
      border-radius: 26px;
      padding: clamp(24px, 3.5vw, 36px);
      position: relative;
      overflow: hidden;
    }

    .info-section h2 {
      margin-top: 0;
      font-size: clamp(1.3rem, 3vw, 1.6rem);
    }

    .info-section p {
      color: #999999;
      line-height: 1.7;
      font-size: clamp(0.9rem, 1.5vw, 1rem);
    }

    .info-section ul {
      line-height: 1.8;
      padding-left: 24px;
    }

   /* Updated mobile footer with 5 icons */
    .mobile-fintech-footer {
      display: none;
      position: fixed;
      left: 12px;
      right: 12px;
      bottom: 16px;
      padding: 10px;
      background: transparent;
      border: 1px solid rgba(86, 139, 241, 0.35);
      border-radius: 32px;
      backdrop-filter: blur(50px);
      box-shadow: 0 20px 60px rgba(4, 10, 36, 0.7);
      justify-content: space-around;
      align-items: center;
      z-index: 90;
    }

    .mobile-fintech-footer a {
      flex: 1;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      gap: 4px;
      text-decoration: none;
      color: rgba(205, 219, 255, 0.75);
      font-size: 0.45rem;
      letter-spacing: 0.06em;
      text-transform: uppercase;
      transition: all var(--transition-short);
      padding: 8px 4px;
      border-radius: 16px;
    }

    .mobile-fintech-footer a.active {
      color: var(--page-mint);
    }

    .mobile-fintech-footer svg {
      width: 22px;
      height: 22px;
      fill: currentColor;
      filter: drop-shadow(0 4px 12px rgba(4, 10, 36, 0.4));
    }

    .mobile-fintech-footer a:hover {
      color: var(--page-mint);
      transform: translateY(-2px);
    }

    @media (max-width: 680px) {
      body {
        padding-bottom: 100px;
      }

      .mobile-fintech-footer {
        display: flex;
      }

      .gender-card {
        height: 100px;
        width: 70px;
      }
    }

    .toast-message {
      position: fixed;
      top: 20px;
      right: -400px; /* start hidden off-screen */
      padding: 16px 24px;
      border-radius: 12px;
      color: white;
      font-family: 'Segoe UI', sans-serif;
      font-size: 15px;
      z-index: 1000;
      opacity: 0;
      box-shadow: 0 10px 40px rgba(0, 0, 0, 0.2);
      transition: right 0.6s ease, opacity 0.6s ease;
    }

    /* Success styling */
    .toast-message.success {
      background: rgba(77, 225, 193, 0.95);
      color: #030922;
      box-shadow: 0 10px 40px rgba(77, 225, 193, 0.4);
    }

    /* Error styling */
    .toast-message.error {
      background: rgba(255, 77, 77, 0.95);
      color: #fff;
      box-shadow: 0 10px 40px rgba(255, 77, 77, 0.4);
    }

    /* When visible */
    .toast-message.show {
      right: 20px;
      opacity: 1;
    }

    /* WhatsApp-style chat interface styles */
    .whatsapp-chat-container {
      max-width: 900px;
      margin: 0 auto;
      background: #0a1628;
      border-radius: 24px;
      overflow: hidden;
      box-shadow: 0 20px 60px rgba(0, 0, 0, 0.4);
      border: 1px solid rgba(86, 139, 241, 0.3);
    }

    .chat-header {
      background: linear-gradient(135deg, #0d1b3e 0%, #1a2847 100%);
      padding: 20px 24px;
      display: flex;
      align-items: center;
      gap: 16px;
      border-bottom: 1px solid rgba(86, 139, 241, 0.2);
      position: relative;
    }

    .chat-header::before {
      content: "";
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      height: 100%;
      background: url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><circle cx="10" cy="10" r="1" fill="rgba(77,225,193,0.1)"/><circle cx="30" cy="25" r="1.5" fill="rgba(77,225,193,0.08)"/><circle cx="60" cy="15" r="1" fill="rgba(77,225,193,0.1)"/><circle cx="85" cy="30" r="1.2" fill="rgba(77,225,193,0.09)"/></svg>');
      opacity: 0.6;
      pointer-events: none;
    }

    .chat-avatar {
      width: 50px;
      height: 50px;
      border-radius: 50%;
      border: 3px solid var(--page-mint);
      overflow: hidden;
      box-shadow: 0 4px 12px rgba(77, 225, 193, 0.3);
      position: relative;
      z-index: 1;
    }

    .chat-avatar img {
      width: 100%;
      height: 100%;
      object-fit: cover;
    }

    .chat-user-info {
      flex: 1;
      position: relative;
      z-index: 1;
    }

    .chat-user-name {
      font-size: 1.1rem;
      font-weight: 700;
      color: var(--page-white);
      margin: 0 0 4px 0;
    }

    .chat-user-status {
      font-size: 0.85rem;
      color: var(--page-mint);
      display: flex;
      align-items: center;
      gap: 6px;
    }

    .status-dot {
      width: 8px;
      height: 8px;
      background: var(--page-mint);
      border-radius: 50%;
      animation: pulse 2s infinite;
    }

    @keyframes pulse {
      0%, 100% { opacity: 1; }
      50% { opacity: 0.5; }
    }

    /* Added earning badge styles in chat header */
    .earning-badge {
      background: linear-gradient(135deg, rgba(37, 211, 102, 0.3), rgba(77, 225, 193, 0.2));
      border: 1px solid rgba(37, 211, 102, 0.5);
      border-radius: 12px;
      padding: 8px 16px;
      font-size: 0.9rem;
      font-weight: 600;
      color: #25d366;
      display: flex;
      align-items: center;
      gap: 8px;
      position: relative;
      z-index: 1;
    }

    .earning-badge.claimed {
      background: linear-gradient(135deg, rgba(77, 225, 193, 0.2), rgba(45, 92, 230, 0.2));
      border-color: rgba(77, 225, 193, 0.4);
      color: var(--page-mint);
    }

    .earning-icon {
      width: 18px;
      height: 18px;
      font-size: 1.2rem;
    }

    .chat-messages {
      height: 500px;
      overflow-y: auto;
      padding: 24px;
      background: #050f2c;
      position: relative;
    }

    /* WhatsApp-style background pattern */
    .chat-messages::before {
      content: "";
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      background-image: 
        radial-gradient(circle at 20% 30%, rgba(77, 225, 193, 0.03) 0%, transparent 50%),
        radial-gradient(circle at 80% 70%, rgba(45, 92, 230, 0.03) 0%, transparent 50%),
        repeating-linear-gradient(45deg, transparent, transparent 10px, rgba(255,255,255,0.01) 10px, rgba(255,255,255,0.01) 20px);
      pointer-events: none;
    }

    .message {
      display: flex;
      margin-bottom: 16px;
      animation: messageSlide 0.3s ease;
      position: relative;
      z-index: 1;
    }

    @keyframes messageSlide {
      from {
        opacity: 0;
        transform: translateY(10px);
      }
      to {
        opacity: 1;
        transform: translateY(0);
      }
    }

    .message.sent {
      justify-content: flex-end;
    }

    .message.received {
      justify-content: flex-start;
    }

    .message-bubble {
      max-width: 70%;
      padding: 12px 16px;
      border-radius: 16px;
      font-size: 0.95rem;
      line-height: 1.5;
      word-wrap: break-word;
      box-shadow: 0 2px 8px rgba(0, 0, 0, 0.2);
    }

    .message.sent .message-bubble {
      background: linear-gradient(135deg, #2d5ce6 0%, #1a4bc9 100%);
      color: white;
      border-bottom-right-radius: 4px;
    }

    .message.received .message-bubble {
      background: rgba(13, 27, 62, 0.9);
      color: var(--page-white);
      border: 1px solid rgba(86, 139, 241, 0.2);
      border-bottom-left-radius: 4px;
    }

    .message-time {
      font-size: 0.7rem;
      color: rgba(255, 255, 255, 0.6);
      margin-top: 4px;
      text-align: right;
    }

  .chat-input-area {
    padding: 20px 24px;
    background: #0d1b3e;
    border-top: 1px solid rgba(86, 139, 241, 0.2);
    display: flex;
    flex-direction: row;
    flex-wrap: nowrap;
    gap: 12px;
    align-items: center;
}



.chat-send-btn {
    width: 48px;
    height: 48px;
    border-radius: 50%;
    background: linear-gradient(135deg, #25d366 0%, #128c7e 100%);
    border: none;
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    transition: all 0.3s ease;
    box-shadow: 0 4px 12px rgba(37, 211, 102, 0.3);
    flex-shrink: 0; /* ← Prevents shrinking */
}



    .chat-input:focus {
      border-color: var(--page-mint);
      box-shadow: 0 0 0 3px rgba(77, 225, 193, 0.1);
    }

    .chat-send-btn {
      width: 48px;
      height: 48px;
      border-radius: 50%;
      background: linear-gradient(135deg, #25d366 0%, #128c7e 100%);
      border: none;
      cursor: pointer;
      display: flex;
      align-items: center;
      justify-content: center;
      transition: all 0.3s ease;
      box-shadow: 0 4px 12px rgba(37, 211, 102, 0.3);
    }

    .chat-send-btn:hover {
      transform: scale(1.1);
      box-shadow: 0 6px 20px rgba(37, 211, 102, 0.5);
    }

    .chat-send-btn svg {
      width: 24px;
      height: 24px;
      fill: #030922;
    }

    /* Full-screen chat overlay styles */
    .chat-overlay {
      position: fixed;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      background: linear-gradient(180deg, var(--page-blue-900), var(--page-blue-700));
      z-index: 9999;
      display: none;
      flex-direction: column;
      animation: slideIn 0.4s ease;
    }

    .chat-overlay.active {
      display: flex;
    }

    @keyframes slideIn {
      from {
        opacity: 0;
        transform: translateY(20px);
      }
      to {
        opacity: 1;
        transform: translateY(0);
      }
    }

    .chat-overlay-header {
      background: linear-gradient(135deg, #0d1b3e 0%, #1a2847 100%);
      padding: 20px 24px;
      display: flex;
      align-items: center;
      gap: 16px;
      border-bottom: 1px solid rgba(86, 139, 241, 0.2);
      box-shadow: 0 4px 20px rgba(0, 0, 0, 0.3);
    }

    .close-chat-btn {
      width: 40px;
      height: 40px;
      border-radius: 50%;
      background: rgba(255, 77, 77, 0.2);
      border: 1px solid rgba(255, 77, 77, 0.4);
      cursor: pointer;
      display: flex;
      align-items: center;
      justify-content: center;
      transition: all 0.3s ease;
    }

    .close-chat-btn:hover {
      background: rgba(255, 77, 77, 0.4);
      transform: scale(1.1);
    }

    .close-chat-btn svg {
      width: 20px;
      height: 20px;
      fill: #ff6b6b;
    }

    /* Added countdown timer styles */
    .chat-timer {
      background: rgba(77, 225, 193, 0.15);
      border: 1px solid rgba(77, 225, 193, 0.3);
      border-radius: 12px;
      padding: 8px 16px;
      display: flex;
      align-items: center;
      gap: 8px;
      font-size: 0.9rem;
      font-weight: 600;
      color: var(--page-mint);
    }

    .timer-icon {
      width: 20px;
      height: 20px;
      animation: pulse 2s infinite;
    }

    .chat-messages {
      flex: 1;
      overflow-y: auto;
      padding: 24px;
      background: #050f2c;
      position: relative;
    }

    /* WhatsApp-style background pattern */
    .chat-messages::before {
      content: "";
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      background-image: 
        radial-gradient(circle at 20% 30%, rgba(77, 225, 193, 0.03) 0%, transparent 50%),
        radial-gradient(circle at 80% 70%, rgba(45, 92, 230, 0.03) 0%, transparent 50%),
        repeating-linear-gradient(45deg, transparent, transparent 10px, rgba(255,255,255,0.01) 10px, rgba(255,255,255,0.01) 20px);
      pointer-events: none;
    }

    .message {
      display: flex;
      margin-bottom: 16px;
      animation: messageSlide 0.3s ease;
      position: relative;
      z-index: 1;
    }

    @keyframes messageSlide {
      from {
        opacity: 0;
        transform: translateY(10px);
      }
      to {
        opacity: 1;
        transform: translateY(0);
      }
    }

    .message.sent {
      justify-content: flex-end;
    }

    .message.received {
      justify-content: flex-start;
    }

    .message-bubble {
      max-width: 70%;
      padding: 12px 16px;
      border-radius: 16px;
      font-size: 0.95rem;
      line-height: 1.5;
      word-wrap: break-word;
      box-shadow: 0 2px 8px rgba(0, 0, 0, 0.2);
    }

    .message.sent .message-bubble {
      background: linear-gradient(135deg, #2d5ce6 0%, #1a4bc9 100%);
      color: white;
      border-bottom-right-radius: 4px;
    }

    .message.received .message-bubble {
      background: rgba(13, 27, 62, 0.9);
      color: var(--page-white);
      border: 1px solid rgba(86, 139, 241, 0.2);
      border-bottom-left-radius: 4px;
    }

    .message-time {
      font-size: 0.7rem;
      color: rgba(255, 255, 255, 0.6);
      margin-top: 4px;
      text-align: right;
    }

    .chat-input-area {
      padding: 20px 24px;
      background: #0d1b3e;
      border-top: 1px solid rgba(86, 139, 241, 0.2);
      display: flex;
      gap: 12px;
      align-items: center;
    }

    /*.chat-input {*/
    /*  flex: 1;*/
    /*  background: rgba(5, 15, 44, 0.8);*/
    /*  border: 1px solid rgba(86, 139, 241, 0.3);*/
    /*  border-radius: 24px;*/
    /*  padding: 12px 20px;*/
    /*  color: var(--page-white);*/
    /*  font-size: 0.95rem;*/
    /*  outline: none;*/
    /*  transition: all 0.3s ease;*/
    /*}*/
    
    .chat-input {
  flex: 1;
  resize: none;
  overflow-y: hidden;
  min-height: 40px;
  max-height: 150px;
  padding: 10px;
  border-radius: 10px;
  border: 1px solid rgba(255,255,255,0.2);
  background: rgba(255,255,255,0.05);
  color: white;
  font-size: 1rem;
}


    .chat-input:focus {
      border-color: var(--page-mint);
      box-shadow: 0 0 0 3px rgba(77, 225, 193, 0.1);
    }

    .chat-send-btn {
      width: 48px;
      height: 48px;
      border-radius: 50%;
      background: linear-gradient(135deg, #25d366 0%, #128c7e 100%);
      border: none;
      cursor: pointer;
      display: flex;
      align-items: center;
      justify-content: center;
      transition: all 0.3s ease;
      box-shadow: 0 4px 12px rgba(37, 211, 102, 0.3);
    }

    .chat-send-btn:hover {
      transform: scale(1.1);
      box-shadow: 0 6px 20px rgba(37, 211, 102, 0.5);
    }

    .chat-send-btn svg {
      width: 24px;
      height: 24px;
      fill: #030922;
    }

    /* Premium upgrade popup with tech-giant style */
.premium-popup-overlay {
  display: none;
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(0, 0, 0, 0.85);
  backdrop-filter: blur(15px);
  z-index: 9999;
  align-items: center;
  justify-content: center;
  animation: fadeIn 0.3s ease forwards;
}

.premium-popup-overlay.active {
  display: flex;
}

.premium-popup {
  background: linear-gradient(145deg, #111827, #1f2937);
  border: 2px solid #4de1c1;
  border-radius: 32px;
  padding: 50px 40px;
  max-width: 520px;
  width: 90%;
  text-align: center;
  box-shadow: 0 40px 100px rgba(0, 0, 0, 0.7);
  animation: popupSlide 0.4s ease forwards;
  position: relative;
  overflow: hidden;
  font-family: 'Segoe UI', 'Roboto', sans-serif;
  color: #f0f0f0;
}

/* Neon animated background effect */
.premium-popup::before {
  content: "";
  position: absolute;
  top: -60%;
  left: -60%;
  width: 220%;
  height: 220%;
  background: conic-gradient(from 0deg, rgba(77, 225, 193, 0.2), rgba(255, 255, 255, 0) 80%);
  animation: rotate 25s linear infinite;
  z-index: 0;
}

/* Popup content wrapper */
.premium-popup-content {
  position: relative;
  z-index: 1; /* above pseudo-element */
}

/* Title */
.premium-popup h2 {
  font-size: 1.8rem;
  font-weight: 700;
  margin-bottom: 15px;
  color: #4de1c1;
  text-transform: uppercase;
  letter-spacing: 1px;
}

/* Subtitle */
.premium-popup p {
  font-size: 1rem;
  margin-bottom: 25px;
  line-height: 1.5;
  color: #e5e7eb;
}

/* Call-to-action button */
.premium-popup .btn-upgrade {
  display: inline-block;
  padding: 14px 28px;
  background: linear-gradient(90deg, #4de1c1, #1d9d7f);
  color: #111827;
  font-weight: 600;
  border-radius: 24px;
  border: none;
  cursor: pointer;
  transition: all 0.3s ease;
  text-decoration: none;
  font-size: 1rem;
}

.premium-popup .btn-upgrade:hover {
  transform: scale(1.05);
  box-shadow: 0 8px 20px rgba(77, 225, 193, 0.6);
}

/* Animations */
@keyframes popupSlide {
  0% { transform: translateY(-50px); opacity: 0; }
  100% { transform: translateY(0); opacity: 1; }
}

@keyframes fadeIn {
  0% { opacity: 0; }
  100% { opacity: 1; }
}

@keyframes rotate {
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
}

  

    .lock-icon {
      width: 80px;
      height: 80px;
      margin: 0 auto 24px;
      background: linear-gradient(135deg, rgba(77, 225, 193, 0.2) 0%, rgba(45, 92, 230, 0.2) 100%);
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      position: relative;
      z-index: 1;
    }

    .lock-icon svg {
      width: 40px;
      height: 40px;
      fill: var(--page-mint);
    }

    .premium-popup h2 {
      font-size: 2rem;
      margin: 0 0 16px 0;
      color: var(--page-white);
      position: relative;
      z-index: 1;
    }

    .premium-popup p {
      font-size: 1.05rem;
      color: rgba(216, 230, 255, 0.8);
      margin: 0 0 32px 0;
      line-height: 1.6;
      position: relative;
      z-index: 1;
    }

    .premium-upgrade-btn {
      background: linear-gradient(135deg, var(--page-mint) 0%, #2bc9a8 100%);
      color: #030922;
      border: none;
      padding: 16px 48px;
      border-radius: 16px;
      font-size: 1.1rem;
      font-weight: 700;
      cursor: pointer;
      transition: all 0.3s ease;
      text-decoration: none;
      display: inline-block;
      box-shadow: 0 8px 24px rgba(77, 225, 193, 0.4);
      position: relative;
      z-index: 1;
    }

    .premium-upgrade-btn:hover {
      transform: translateY(-4px);
      box-shadow: 0 12px 32px rgba(77, 225, 193, 0.6);
    }

    .empty-chat-state {
      height: 500px;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      color: rgba(216, 230, 255, 0.5);
      font-size: 1.1rem;
    }

    .empty-chat-state svg {
      width: 80px;
      height: 80px;
      fill: rgba(77, 225, 193, 0.3);
      margin-bottom: 20px;
    }
    
    
    .free-user-content {
      background: rgba(6, 16, 48, 0.98);
      border: 1px solid rgba(100, 154, 255, 0.3);
      border-radius: 24px;
      padding: 32px;
      max-width: 500px;
      width: 100%;
      text-align: center;
    }
    
    .free-user-content svg {
      width: 80px;
      height: 80px;
      margin-bottom: 24px;
      color: #fbbf24;
    }
    
    .free-user-content h2 {
      margin: 0 0 16px;
      font-size: 1.5rem;
      color: var(--page-white);
    }
    
    .free-user-content p {
      color: rgba(205, 219, 255, 0.7);
      line-height: 1.7;
      margin-bottom: 24px;
    }
    
    .upgrade-btn {
      display: inline-block;
      padding: 14px 32px;
      background: linear-gradient(135deg, #fbbf24, #f59e0b);
      color: #000;
      border-radius: 12px;
      text-decoration: none;
      font-weight: 700;
      font-size: 1rem;
      text-transform: uppercase;
      letter-spacing: 0.05em;
      transition: all 0.3s ease;
      margin-right: 12px;
    }
    
    .upgrade-btn:hover {
      transform: translateY(-2px);
      box-shadow: 0 8px 24px rgba(251, 191, 36, 0.4);
    }
    
    .close-modal-btn {
      display: inline-block;
      padding: 14px 32px;
      background: rgba(100, 154, 255, 0.2);
      color: var(--page-white);
      border-radius: 12px;
      text-decoration: none;
      font-weight: 600;
      font-size: 1rem;
      cursor: pointer;
      transition: all 0.3s ease;
    }
    
    .close-modal-btn:hover {
      background: rgba(100, 154, 255, 0.3);
    }

    @media (max-width: 680px) {
      .chat-messages {
        height: 400px;
      }

      .message-bubble {
        max-width: 85%;
      }

      .premium-popup {
        padding: 32px 24px;
      }

      .premium-popup h2 {
        font-size: 1.5rem;
      }
    }

   /* Profile Incomplete Screen – compact */
.profile-incomplete-screen {
  max-width: 550px;
  margin: 0 auto;
  padding: 28px 20px;
  text-align: center;
  background: var(--panel-glass);
  border: 2px solid rgba(255,184,0,.4);
  border-radius: 20px;
  box-shadow: var(--shadow-heavy);
  animation: fadeIn .5s ease;
}

.warning-icon {
  width: 42px; height: 42px;
  margin: 0 auto 14px;
  border-radius: 50%;
  background: rgba(255,184,0,.15);
  display: flex; align-items: center; justify-content: center;
}

.warning-icon svg { width: 32px; height: 32px; fill: #fbbf24; }

.profile-incomplete-screen h2 {
  font-size: 1.4rem;
  margin-bottom: 8px;
  color: #fbbf24;
}

.profile-incomplete-screen p {
  font-size: .95rem;
  color: rgba(216,230,255,.85);
  margin-bottom: 18px;
  line-height: 1.3;
}

/* Requirements List – compressed height */
.requirements-list {
  background: rgba(255,184,0,.1);
  border: 1px solid rgba(255,184,0,.25);
  padding: 14px;
  border-radius: 14px;
  margin: 14px 0;
}

.requirements-list h3 {
  font-size: 1rem;
  margin-bottom: 8px;
  color: #fbbf24;
}

.requirements-list ul { margin: 0; padding: 0; list-style: none; }

.requirements-list li {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 8px 0;
  line-height: 1.2;
  border-bottom: 1px solid rgba(255,184,0,.1);
  color: rgba(216,230,255,.9);
}

.requirements-list li:last-child { border: none; }
.requirements-list li::before { content: "⚠️"; font-size: 1rem; }

/* Button – compact */
.btn-go-to-profile {
  padding: 12px 34px;
  background: linear-gradient(135deg,#fbbf24,#f59e0b);
  border: none;
  border-radius: 14px;
  color: #030922;
  font-size: 1rem;
  font-weight: 700;
  cursor: pointer;
  transition: .25s;
  text-decoration: none;
  box-shadow: 0 5px 18px rgba(251,191,36,.4);
}

.btn-go-to-profile:hover {
  transform: translateY(-3px);
  box-shadow: 0 9px 26px rgba(251,191,36,.55);
}

/* Requirement Checklist Modal – NO padding, NO background */
.requirements-checklist {
  padding: 0 !important;
  margin: 10px 0;
  background: none !important;
  border: none !important;
}

.requirements-checklist h3 {
  margin-bottom: 10px;
  font-size: 1.1rem;
  color: var(--page-mint);
  display: flex;
  align-items: center;
  gap: 8px;
}

/* Checklist items – smaller & dense */
.requirement-item {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 10px;
  margin-bottom: 8px;
  border-radius: 10px;
  border: 1px solid rgba(86,139,241,.25);
  background: rgba(13,27,62,.55);
}

.requirement-item.completed {
  background: rgba(77,225,193,.15);
  border-color: rgba(77,225,193,.4);
}

.requirement-item.missing {
  background: rgba(255,184,0,.1);
  border-color: rgba(255,184,0,.3);
}

.requirement-icon {
  width: 26px; height: 26px;
  border-radius: 50%;
  display: flex; align-items: center; justify-content: center;
  font-size: 1rem;
}

.requirement-icon.completed { background: rgba(77,225,193,.3); color: var(--page-mint); }
.requirement-icon.missing   { background: rgba(255,184,0,.25); color: #fbbf24; }

.requirement-text {
  flex: 1;
  font-size: .9rem;
  color: var(--page-white);
  line-height: 1.2;
}


    /* Added blurred profile styles for free users */
    .blurred-profile {
      filter: blur(8px);
      opacity: 0.6;
      pointer-events: none;
    }

    .blurred-name {
      filter: blur(6px);
      user-select: none;
    }

    /* Added emoji picker styles */
    .emoji-picker {
      position: absolute;
      bottom: 70px;
      right: 24px;
      background: rgba(13, 27, 62, 0.95);
      border: 1px solid rgba(86, 139, 241, 0.3);
      border-radius: 16px;
      padding: 16px;
      display: none;
      grid-template-columns: repeat(8, 1fr);
      gap: 8px;
      max-width: 320px;
      box-shadow: 0 20px 60px rgba(0, 0, 0, 0.4);
      z-index: 100;
    }

    .emoji-picker.show {
      display: grid;
    }

    .emoji-btn {
      width: 32px;
      height: 32px;
      border: none;
      background: transparent;
      font-size: 1.5rem;
      cursor: pointer;
      border-radius: 8px;
      transition: all 0.2s ease;
    }

    .emoji-btn:hover {
      background: rgba(77, 225, 193, 0.2);
      transform: scale(1.2);
    }

    /* Added cancel button styles */
    .btn-cancel {
      background: linear-gradient(135deg, rgba(255, 77, 77, 0.8), rgba(220, 38, 38, 0.8));
      border: 1px solid rgba(255, 77, 77, 0.4);
    }

    .btn-cancel:hover {
      box-shadow: 0 12px 40px rgba(255, 77, 77, 0.4);
    }

    /* Added paired history styles */
    .paired-history-section {
      background: var(--panel-glass);
      border: 1px solid var(--panel-border);
      border-radius: 24px;
      padding: 32px;
      margin-top: 32px;
      box-shadow: var(--shadow-heavy);
    }

    .history-item {
      background: rgba(13, 27, 62, 0.6);
      border: 1px solid rgba(86, 139, 241, 0.2);
      border-radius: 16px;
      padding: 20px;
      margin-bottom: 16px;
      cursor: pointer;
      transition: all 0.3s ease;
    }

    .history-item:hover {
      border-color: var(--page-mint);
      transform: translateY(-4px);
      box-shadow: 0 12px 40px rgba(77, 225, 193, 0.2);
    }

    .history-avatar {
      width: 48px;
      height: 48px;
      border-radius: 50%;
      border: 2px solid var(--page-mint);
      overflow: hidden;
    }

    .history-avatar img {
      width: 100%;
      height: 100%;
      object-fit: cover;
    }
  </style>

<body>
  <?php include "embed.php" ?>
  
  <!-- Full-screen chat overlay -->
  <div class="chat-overlay" id="chatOverlay">
    <div class="chat-overlay-header">
      <button class="close-chat-btn" onclick="closeChatOverlay()">
        <svg viewBox="0 0 24 24">
          <path d="M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z"/>
        </svg>
      </button>
      
      <div class="chat-avatar <?php echo !$is_premium ? 'blurred-profile' : ''; ?>">
        <img id="overlayAvatar" src="front/assets/images/default-avatar.png" alt="User">
      </div>
      
      <div class="chat-user-info" style="flex: 1;">
        <h3 class="chat-user-name <?php echo !$is_premium ? 'blurred-name' : ''; ?>" id="overlayName">User</h3>
        <div class="chat-user-status">
          <span class="status-dot"></span>
          <span>Active</span>
        </div>
      </div>
      

    </div>

    <div class="chat-messages" id="overlayMessages">
      <!-- Messages will be loaded here -->
    </div>

   <div class="chat-input-area">
      
  <button type="button" class="chat-send-btn" onclick="toggleEmojiPicker()" 
    style="width: 40px; height: 40px; background: rgba(99,102,241,0.3);">
    <span style="font-size: 1.5rem;">😊</span>
  </button>

  <?php
    // Default message for premium users
    $defaultMessage = "Hello, I was connected to you through Earnova EchoChat. My name is $username Nice connecting with you";
  ?>
  
 

 
<textarea
  class="chat-input"
  id="overlayMessageInput"
  placeholder="Type a message..."
  autocomplete="off"
  rows="1"
  oninput="autoResize(this)"
  <?php echo !$is_premium ? 'disabled' : ''; ?>
><?php echo $is_premium ? htmlspecialchars($defaultMessage, ENT_QUOTES, 'UTF-8') : ''; ?></textarea>


      
      <button class="chat-send-btn" id="overlaySendBtn" <?php echo !$is_premium ? 'onclick="showPremiumPopup()"' : 'onclick="sendOverlayMessage()"'; ?>>
        <?php if (!$is_premium): ?>
          <svg viewBox="0 0 24 24" width="20" height="20" fill="var(--page-mint)">
            <path d="M18 8h-1V6c0-2.76-2.24-5-5-5S7 3.24 7 6v2H6c-1.1 0-2 .9-2 2v10c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V10c0-1.1-.9-2-2-2zm-6 9c-1.1 0-2-.9-2-2s.9-2 2-2 2 .9 2 2-.9 2-2 2zm3.1-9H8.9V6c0-1.71 1.39-3.1 3.1-3.1 1.71 0 3.1 1.39 3.1 3.1v2z"/>
          </svg>
        <?php else: ?>
          <svg viewBox="0 0 24 24" width="20" height="20">
            <path d="M2.01 21L23 12 2.01 3 2 10l15 2-15 2z" fill="white"/>
          </svg>
        <?php endif; ?>
      </button>
      </div>
      
      <!-- Emoji picker -->
      <div class="emoji-picker" id="overlayEmojiPicker">
        <?php
        $emojis = ['😀', '😂', '😍', '🥰', '😎', '🤔', '👍', '👏', '🙏', '❤️', '🔥', '✨', '🎉', '💯', '👋', '🤝'];
        foreach ($emojis as $emoji) {
          echo "<button type='button' class='emoji-btn' onclick='insertOverlayEmoji(\"$emoji\")'>$emoji</button>";
        }
        ?>
      </div>
    </div>
  </div>
  
  <script>function autoResize(textarea) {
    textarea.style.height = "auto";
    textarea.style.height = (textarea.scrollHeight) + "px";

    // Prevent chat from jumping
    const messages = document.getElementById("overlayMessages");
    messages.scrollTop = messages.scrollHeight;
}
</script>
  
  <?php include "header2.php"; ?>
  <div class="page-shell">
    <main>
      <?php if ($trigger_error_display && !empty($error_message)): ?>
        <div id="toast-error" class="toast-message error">
          <?php echo htmlspecialchars($error_message); ?>
        </div>
      <?php endif; ?>

      <?php if ($trigger_error_display && !empty($success_message)): ?>
        <div id="toast-success" class="toast-message success">
          <?php echo htmlspecialchars($success_message); ?>
        </div>
      <?php endif; ?>

      <?php if ($profile_incomplete): ?>
        <!-- Profile requirements checklist screen -->
        <div class="profile-incomplete-screen">
          <div class="warning-icon">
            <svg viewBox="0 0 24 24">
              <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-2h2v2zm0-4h-2V7h2v6z"/>
            </svg>
          </div>
          <h2 style="font-size: 20px">Profile Requirements</h2>
          <p>To use Echo-Chat, please complete the following requirements:</p>
          
          <div class="requirements-checklist">
            <h3>
              <svg viewBox="0 0 24 24" width="24" height="24" fill="currentColor">
                <path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z"/>
              </svg>
              Your Progress
            </h3>
            
            <?php foreach ($completed_requirements as $requirement): ?>
              <div class="requirement-item completed">
                <div class="requirement-icon completed">✓</div>
                <div class="requirement-text"><?php echo htmlspecialchars($requirement); ?></div>
              </div>
            <?php endforeach; ?>
            
            <?php foreach ($missing_requirements as $requirement): ?>
              <div class="requirement-item missing">
                <div class="requirement-icon missing">!</div>
                <div class="requirement-text"><?php echo htmlspecialchars($requirement); ?></div>
              </div>
            <?php endforeach; ?>
          </div>

          <div style="display: flex; gap: 16px; flex-wrap: wrap; justify-content: center;">
            <a href="profile.php" class="btn-go-to-profile">Go to Profile Settings</a>
            <form method="POST" action="" style="display: inline;">
              <button type="submit" name="cancel_progress" class="btn-cta btn-cancel">Cancel & Start Fresh</button>
            </form>
          </div>
          
          <?php if (empty($missing_requirements)): ?>
            <form method="POST" action="" style="margin-top: 24px;">
              <!-- Added terms and conditions checkbox before continue pairing -->
              <div style="margin-bottom: 20px; text-align: left; background: rgba(99, 102, 241, 0.1); padding: 16px; border-radius: 12px; border: 1px solid rgba(99, 102, 241, 0.3);">
                <label style="display: flex; align-items: start; cursor: pointer; user-select: none;">
                  <input type="checkbox" id="termsCheckbox" name="terms_agreed" required style="margin-right: 12px; margin-top: 4px; width: 18px; height: 18px; cursor: pointer; accent-color: var(--primary);">
                  <span style="flex: 1; font-size: 0.95rem; line-height: 1.5;">
                    I agree to the 
                    <button type="button" onclick="openTermsModal()" style="color: var(--primary); text-decoration: underline; background: none; border: none; padding: 0; cursor: pointer; font-size: 0.95rem; font-weight: 600;">
                      Terms and Policy of Echo-Chat.
                    </button>
                  </span>
                </label>
              </div>
              <button type="submit" name="continue_pairing" id="continuePairingBtn" class="btn-cta" style="width: 100%; padding: 16px;">Continue to Pairing</button>
            </form>
          <?php endif; ?>
        </div>
      <?php elseif ($paired_user): ?>
        <!-- Paired user card with click to open full-screen chat -->
        <div class="paired-user-card" onclick="openChatOverlay()">
          <div class="paired-avatar <?php echo !$is_premium ? 'blurred-profile' : ''; ?>">
            <img src="<?php echo !empty($paired_user['profile_picture']) ? htmlspecialchars($paired_user['profile_picture']) : 'front/assets/images/default-avatar.png'; ?>" alt="<?php echo htmlspecialchars($paired_user['full_name']); ?>">
          </div>
          <h2 class="<?php echo !$is_premium ? 'blurred-name' : ''; ?>"><?php echo htmlspecialchars($paired_user['full_name']); ?></h2>
          <p>Click to open chat</p>
          
          <!-- Display countdown timer -->
          <div class="chat-timer" style="margin: 20px auto; width: fit-content;">
            <svg class="timer-icon" viewBox="0 0 24 24" fill="currentColor">
              <path d="M15 1H9v2h6V1zm-4 13h2V8h-2v6zm8.03-6.61l1.42-1.42c-.43-.51-.9-.99-1.41-1.41l-1.42 1.42A8.962 8.962 0 0 0 12 4c-4.97 0-9 4.03-9 9s4.02 9 9 9a8.994 8.994 0 0 0 7.03-14.61zM12 20c-3.87 0-7-3.13-7-7s3.13-7 7-7 7 3.13 7 7-3.13 7-7 7z"/>
            </svg>
            <span id="cardTimerDisplay">24:00:00</span>
          </div>
          
          <?php if (!$is_premium): ?>
            <div class="whatsapp-number" style="filter: blur(8px);">
              +234 XXX XXX XXXX
            </div>
          <?php else: ?>
            <div class="whatsapp-number">
              <?php echo htmlspecialchars($paired_user['whatsapp_number']); ?>
            </div>
          <?php endif; ?>
        </div>

        <div style="display: flex; gap: 16px; margin-top: 24px; flex-wrap: wrap; justify-content: center;">
          <p style="flex: 1; text-align: center; font-size: 0.9rem; color: rgba(205, 219, 255, 0.6);">
            Chat expires in <span id="expiryText">24 hours</span>. Come back after expiration to connect with someone new!
          </p>
        </div>
      <?php else: ?>
        <!-- Gender selection with cancel option -->
        <section class="hero-section">
          <div class="hero-content">
            <h1 style="font-size: 18px; ">Meet New People, On <span class="highlight">Echo Chat</span></h1>
            <p>Initiate a conversation and enjoy engaging exchanges. You’ll be paired with a new user every 24 hours.</p>
            
            <?php if ($user_data['chat_earn_progress'] === 'gender_selected' || $user_data['chat_earn_progress'] === 'requirements_complete'): ?>
              <div style="background: rgba(77, 225, 193, 0.1); border: 1px solid rgba(77, 225, 193, 0.3); border-radius: 16px; padding: 20px; margin-bottom: 24px;">
                <p style="margin: 0; color: var(--page-mint); font-weight: 600;">
                  ✓ You selected: <?php echo ucfirst($user_data['chat_earn_selected_gender']); ?>
                </p>
                <p style="margin: 8px 0 0; font-size: 0.9rem; opacity: 0.8;">
                  Make sure to read the Echo Chat Terms and Conditions before pairing with someone new.
                </p>
              </div>
              
              <div style="display: flex; gap: 16px; flex-wrap: wrap;">
                <form method="POST" action="" style="flex: 1;">
                  <!-- Added terms and conditions checkbox for continue pairing -->
                  <div style="margin-bottom: 16px; text-align: left; background: rgba(99, 102, 241, 0.1); padding: 16px; border-radius: 12px; border: 1px solid rgba(99, 102, 241, 0.3);">
                    <label style="display: flex; align-items: start; cursor: pointer; user-select: none;">
                      <input type="checkbox" id="termsCheckbox2" name="terms_agreed" required style="margin-right: 12px; margin-top: 4px; width: 18px; height: 18px; cursor: pointer; accent-color: var(--primary);">
                      <span style="flex: 1; font-size: 0.95rem; line-height: 1.5;">
                        I agree to the 
                        <button type="button" onclick="openTermsModal()" style="color: var(--primary); text-decoration: underline; background: none; border: none; padding: 0; cursor: pointer; font-size: 0.95rem; font-weight: 600;">
                          Terms and Policy of Echo-Chat
                        </button>
                      </span>
                    </label>
                  </div>
                  <button type="submit" name="continue_pairing" class="btn-cta" style="width: 100%;">Continue Pairing</button>
                </form>
              </div>
            <?php else: ?>
              <form method="POST" action="">
                <div class="gender-selector">
                  <button type="submit" name="selected_gender" value="male" class="gender-card">
                    <svg viewBox="0 0 448 512" fill="currentColor">
                      <path d="M224 256A128 128 0 1 0 224 0a128 128 0 1 0 0 256zM313.6 288h-16.7c-22.2 10.2-46.9 16-72.9 16s-50.7-5.8-72.9-16h-16.7C60.2 288 0 348.2 0 422.4V464c0 26.5 21.5 48 48 48h352c26.5 0 48-21.5 48-48v-41.6c0-74.2-60.2-134.4-134.4-134.4z"/>
                    </svg>
                    <h3>Male</h3>
                    <p>Connect with male users</p>
                  </button>

                  <button type="submit" name="selected_gender" value="female" class="gender-card">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512" fill="currentColor">
                      <path d="M224 256A128 128 0 1 0 224 0a128 128 0 1 0 0 256zm97.2 32h-29.7a174.8 174.8 0 0 1-134.9 0h-29.7C57.3 288 0 345.3 0 416v32c0 35.3 28.7 64 64 64h320c35.3 0 64-28.7 64-64v-32c0-70.7-57.3-128-126.8-128zM224 32c-48.5 0-88 39.5-88 88s39.5 88 88 88 88-39.5 88-88-39.5-88-88-88zm0 352H64c0-53 43-96 96-96h128c53 0 96 43 96 96H224z"/>
                    </svg>
                    <h3>Female</h3>
                    <p>Connect with female users</p>
                  </button>
                </div>
              </form>
            <?php endif; ?>
          </div>
        </section>
      <?php endif; ?>
    </main>
  </div>

  <!-- Premium upgrade popup -->
  <div class="premium-popup-overlay <?php echo $show_premium_popup ? 'active' : ''; ?>" id="premiumPopup">
    <div class="free-user-content">
      <svg viewBox="0 0 24 24" fill="currentColor">
        <path d="M12 2L2 7l10 5 10-5-10-5zm0 18.5l-8-4v-7l8 4 8-4v7l-8 4z"/>
      </svg>
      <h2>Premium Plus Access</h2>
      <p>Echo-Chat with full features is exclusively available for Premium Plus Members.</p> 
      <div>
        <a href="membership.php" class="upgrade-btn">Activate Now</a>
        <button class="close-modal-btn" onclick="closePremiumPopup()">Maybe Later</button>
      </div>
    </div>
  </div>

  <!-- Added Terms and Conditions Modal -->
  <div class="premium-popup-overlay" id="termsModal" style="z-index: 10001;">
    <div class="free-user-content" style="max-width: 600px; max-height: 80vh; overflow-y: auto;">
      <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
        <h2 style="margin: 0;">Echo-Chat Terms and Policy</h2>
        <button onclick="closeTermsModal()" style="background: rgba(255, 255, 255, 0.1); border: none; color: white; width: 32px; height: 32px; border-radius: 50%; cursor: pointer; display: flex; align-items: center; justify-content: center; font-size: 20px;">
          ×
        </button>
      </div>
      
      <div style="text-align: left; line-height: 1.8; font-size: 0.95rem;">
        <div style="background: rgba(239, 68, 68, 0.1); padding: 16px; margin-bottom: 20px; border-radius: 8px;">
          <p style="margin: 0; font-weight: 600; color: #fca5a5;"> Important Notice</p>
          <p style="margin: 8px 0 0; font-size: 0.9rem;">Please read and understand these terms before continuing.</p>
        </div>

        <h3 style="color: var(--primary); margin-top: 24px; margin-bottom: 12px;">1. Platform Disclaimer</h3>
        <p style="margin-bottom: 16px;">
          <strong>Earnova</strong> is solely a connection platform. We do not have any relationship, affiliation, or control over the users you are paired with through the Echo-Chat feature.
        </p>

        <h3 style="color: var(--primary); margin-top: 24px; margin-bottom: 12px;">2. Personal Information Protection</h3>
        <p style="margin-bottom: 16px;">
          <strong>DO NOT share sensitive personal information</strong> including but not limited to:
        </p>
        <ul style="margin-left: 20px; margin-bottom: 16px;">
          <li>Bank account details, PINs, or passwords</li>
          <li>Credit/debit card information</li>
          <li>Home address or exact location</li>
          <li>Government-issued ID numbers (NIN, BVN, etc.)</li>
          <li>Financial account credentials</li>
        </ul>

        <h3 style="color: var(--primary); margin-top: 24px; margin-bottom: 12px;">3. User Conduct</h3>
        <p style="margin-bottom: 16px;">
          You agree to:
        </p>
        <ul style="margin-left: 20px; margin-bottom: 16px;">
          <li>Communicate respectfully with paired users</li>
          <li>Report any inappropriate behavior or harassment</li>
          <li>Use the platform for its intended purpose only</li>
          <li>Not engage in spam, scams, or fraudulent activities</li>
        </ul>

        <h3 style="color: var(--primary); margin-top: 24px; margin-bottom: 12px;">4. Liability Limitation</h3>
        <p style="margin-bottom: 16px;">
          <strong>Earnova will NOT be held responsible for:</strong>
        </p>
        <ul style="margin-left: 20px; margin-bottom: 16px;">
          <li>Any interactions, agreements, or disputes between paired users</li>
          <li>Loss of money, data, or personal information shared with other users</li>
          <li>Inappropriate conduct, harassment, or fraudulent activities by other users</li>
          <li>Any damages or losses resulting from chat interactions</li>
        </ul>

        <h3 style="color: var(--primary); margin-top: 24px; margin-bottom: 12px;">5. Security Recommendations</h3>
        <ul style="margin-left: 20px; margin-bottom: 16px;">
          <li>Verify the identity of users before sharing any personal details</li>
          <li>Be cautious of requests for money or financial assistance</li>
          <li>Report suspicious behavior immediately to our support team</li>
          <li>Use the platform's built-in chat features when possible</li>
        </ul>

        <h3 style="color: var(--primary); margin-top: 24px; margin-bottom: 12px;">6. WhatsApp Communication</h3>
        <p style="margin-bottom: 16px;">
          When you communicate via WhatsApp with your paired user, you are leaving our platform. All conversations on WhatsApp are between you and the other user. Earnova has no access to, control over, or responsibility for WhatsApp communications.
        </p>

        <h3 style="color: var(--primary); margin-top: 24px; margin-bottom: 12px;">7. Reporting & Support</h3>
        <p style="margin-bottom: 16px;">
          If you experience any issues, harassment, or suspicious activity, please contact our support team immediately through the Help section in your dashboard.
        </p>

        <div style="background: rgba(99, 102, 241, 0.1); border: 1px solid rgba(99, 102, 241, 0.3); padding: 16px; margin-top: 24px; border-radius: 8px;">
          <p style="margin: 0; font-size: 0.9rem; text-align: center;">
            By checking the agreement box, you acknowledge that you have read, understood, and agree to these terms and conditions.
          </p>
        </div>
      </div>
      
      <div style="margin-top: 24px;">
        <button onclick="closeTermsModal()" class="upgrade-btn" style="width: 100%;">I Understand</button>
      </div>
    </div>
  </div>
  
  
    <nav class="mobile-fintech-footer">
    
  <a href="dashboard.php">
    <svg viewBox="0 0 24 24"><path d="M12 3a9 9 0 1 1 0 18 9 9 0 0 1 0-18Zm1 4h-2v6h6v-2h-4V7Z"/></svg>
    <span>Dashboard</span>
  </a>

  <!-- Premium (crown icon) -->
  <a href="membership.php">
    <svg viewBox="0 0 24 24"><path d="M5 7l2.5 5 4.5-4 4.5 4L19 7l2 13H3l2-13Z"/></svg>
    <span>Premium</span>
  </a>

  <a href="post-task.php">
<svg viewBox="0 0 24 24" aria-hidden="true">
  <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8l-6-6Zm1 14h-3v3h-2v-3H7v-2h3v-3h2v3h3v2Zm-3-9V3.5L18.5 8H12Z"/>
</svg>
    
    <span>Advert Post</span>
  </a>
  
  

  <a href="history.php">
  <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
    <path d="M13 3a9 9 0 1 0 9 9h-2a7 7 0 1 1-7-7V3l4 4-4 4V7a5 5 0 1 0 5 5h2a7 7 0 1 1-7-7z"/>
  </svg>
  <span>History</span>
</a>


  <a href="profile.php">
    <svg viewBox="0 0 24 24"><path d="M12 2a6 6 0 0 1 6 6c0 3.31-2.69 6-6 6s-6-2.69-6-6a6 6 0 0 1 6-6Zm0 14c4.42 0 8 1.79 8 4v2H4v-2c0-2.21 3.58-4 8-4Z"/></svg>
    <span>Profile</span>
  </a>
</nav>

  <script>
    const isPremium = <?php echo $is_premium ? 'true' : 'false'; ?>;
    const pairedWhatsApp = '<?php echo isset($paired_user) && $is_premium ? preg_replace('/[^0-9]/', '', $paired_user['whatsapp_number']) : ''; ?>';
    const pairedName = '<?php echo isset($paired_user) ? htmlspecialchars($paired_user['full_name']) : ''; ?>';
    const pairedAvatar = '<?php echo isset($paired_user) && !empty($paired_user['profile_picture']) ? htmlspecialchars($paired_user['profile_picture']) : 'front/assets/images/default-avatar.png'; ?>';
    
    // Added for localStorage
    const userId = '<?php echo $user_id; ?>';
    const pairedUserId = '<?php echo isset($paired_user) ? $paired_user['id'] : 'null'; ?>';

    // Expiration timestamp for countdown
    const expiresAt = '<?php echo isset($paired_user['expires_at']) ? $paired_user['expires_at'] : ''; ?>';
    
    function updateCountdown() {
      if (!expiresAt) return;
      
      const now = new Date().getTime();
      const expiry = new Date(expiresAt.replace(' ', 'T')).getTime();
      const distance = expiry - now;
      
      if (distance < 0) {
        document.getElementById('timerDisplay').textContent = 'Expired';
        document.getElementById('cardTimerDisplay').textContent = 'Expired';
        document.getElementById('expiryText').textContent = '0 hours';
        clearChatMessages();
        // Reload page to show new pairing option
        setTimeout(() => location.reload(), 2000);
        return;
      }
      
      const hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
      const minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
      const seconds = Math.floor((distance % (1000 * 60)) / 1000);
      
      const timeString = `${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;
      
      const timerDisplay = document.getElementById('timerDisplay');
      const cardTimerDisplay = document.getElementById('cardTimerDisplay');
      const expiryText = document.getElementById('expiryText');
      
      if (timerDisplay) timerDisplay.textContent = timeString;
      if (cardTimerDisplay) cardTimerDisplay.textContent = timeString;
      if (expiryText) expiryText.textContent = `${hours}h ${minutes}m`;
    }
    
    function saveChatMessages() {
      const overlayMessages = document.getElementById('overlayMessages');
      // Ensure userId and pairedUserId are valid before creating storageKey
      if (userId && pairedUserId && pairedUserId !== 'null') {
        const storageKey = `chat_messages_${userId}_${pairedUserId}`;
        localStorage.setItem(storageKey, overlayMessages.innerHTML);
      }
    }

    function clearChatMessages() {
      // Ensure userId and pairedUserId are valid before creating storageKey
      if (userId && pairedUserId && pairedUserId !== 'null') {
        const storageKey = `chat_messages_${userId}_${pairedUserId}`;
        localStorage.removeItem(storageKey);
      }
    }

    function openChatOverlay() {
      chatOverlay.classList.add('active');
      document.getElementById('overlayAvatar').src = pairedAvatar;
      document.getElementById('overlayName').textContent = pairedName;
      
      const overlayMessages = document.getElementById('overlayMessages');
      let storageKey = null;
      if (userId && pairedUserId && pairedUserId !== 'null') {
        storageKey = `chat_messages_${userId}_${pairedUserId}`;
      }
      
      const savedMessages = storageKey ? localStorage.getItem(storageKey) : null;
      
      if (savedMessages) {
        // Load saved messages from localStorage
        overlayMessages.innerHTML = savedMessages;
      } else {
        // Load welcome messages for first time
        overlayMessages.innerHTML = `
          <div class="message received">
            <div class="message-bubble">
              <strong> Privacy Notice</strong><br>
              Welcome to Echo-Chat! Your privacy is important. Please be respectful and follow community guidelines.
              <div class="message-time">${new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' })}</div>
            </div>
          </div>
          <div class="message received">
            <div class="message-bubble">
              👋 Hi! I'm ${pairedName}. Nice to meet you!
              <div class="message-time">${new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' })}</div>
            </div>
          </div>
        `;
        // Save welcome messages to localStorage if key is valid
        if (storageKey) {
          saveChatMessages();
        }
      }
      
      // Scroll to bottom
      overlayMessages.scrollTop = overlayMessages.scrollHeight;
    }

    function closeChatOverlay() {
      chatOverlay.classList.remove('active');
    }

    function sendOverlayMessage() {
      const input = document.getElementById('overlayMessageInput');
      const message = input.value.trim();
      
      if (!message) return;
      
      if (!isPremium) {
        showPremiumPopup();
        return;
      }
      
      // Add message to chat UI
      addMessageToOverlay(message, 'sent');
      input.value = '';
      
      // Redirect to WhatsApp
      setTimeout(() => {
        const whatsappUrl = `https://wa.me/${pairedWhatsApp}?text=${encodeURIComponent(message)}`;
        window.open(whatsappUrl, '_blank');
      }, 500);
    }

    function addMessageToOverlay(text, type) {
      const overlayMessages = document.getElementById('overlayMessages');
      const messageDiv = document.createElement('div');
      messageDiv.className = `message ${type}`;
      
      const now = new Date();
      const timeString = now.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' });
      
      messageDiv.innerHTML = `
        <div class="message-bubble">
          ${text}
          <div class="message-time">${timeString}</div>
        </div>
      `;
      
      overlayMessages.appendChild(messageDiv);
      overlayMessages.scrollTop = overlayMessages.scrollHeight;
      
      saveChatMessages();
    }

    // Update countdown every second
    if (expiresAt) {
      updateCountdown();
      setInterval(updateCountdown, 1000);
    }


    // Enter key to send message
    const overlayInput = document.getElementById('overlayMessageInput');
    if (overlayInput) {
      overlayInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter' && isPremium) {
          sendOverlayMessage();
        }
      });
    }

    // Close emoji picker when clicking outside
    document.addEventListener('click', function(e) {
      const picker = document.getElementById('overlayEmojiPicker');
      const emojiBtn = e.target.closest('.chat-send-btn'); // Check if the click was on the emoji button
      if (picker && !picker.contains(e.target) && !emojiBtn) {
        picker.classList.remove('show');
      }
    });

    function showPremiumPopup() {
      premiumPopup.classList.add('active');
    }

    function closePremiumPopup() {
      premiumPopup.classList.remove('active');
    }

    // Close popup when clicking outside
    if (premiumPopup) {
      premiumPopup.addEventListener('click', (e) => {
        if (e.target === premiumPopup) {
          closePremiumPopup();
        }
      });
    }

    // Close overlay when clicking outside
    if (chatOverlay) {
      chatOverlay.addEventListener('click', (e) => {
        if (e.target === chatOverlay) {
          closeChatOverlay();
        }
      });
    }

    // Toast messages
    document.addEventListener("DOMContentLoaded", () => {
      const successToast = document.getElementById("toast-success");
      const errorToast = document.getElementById("toast-error");

      function showToast(toast) {
        if (!toast) return;
        setTimeout(() => toast.classList.add("show"), 100);
        setTimeout(() => toast.classList.remove("show"), 5000);
      }

      showToast(successToast);
      showToast(errorToast);
    });

    function toggleEmojiPicker() {
      const picker = document.getElementById('overlayEmojiPicker');
      picker.classList.toggle('show');
    }

    function insertOverlayEmoji(emoji) {
      const input = document.getElementById('overlayMessageInput');
      input.value += emoji;
      input.focus();
    }

    // Auto-show premium popup for free users
    // This script should run after DOM is loaded
    document.addEventListener('DOMContentLoaded', function() {
      const premiumPopup = document.getElementById('premiumPopup');
      // Ensure the flag is set and the popup element exists
      if (<?php echo $show_premium_popup ? 'true' : 'false'; ?> && premiumPopup) {
        premiumPopup.classList.add('active');
      }
    });

    function openTermsModal() {
      const termsModal = document.getElementById('termsModal');
      if (termsModal) {
        termsModal.classList.add('active');
      }
    }

    function closeTermsModal() {
      const termsModal = document.getElementById('termsModal');
      if (termsModal) {
        termsModal.classList.remove('active');
      }
    }

    // Close terms modal when clicking outside
    document.getElementById('termsModal')?.addEventListener('click', function(e) {
      if (e.target === this) {
        closeTermsModal();
      }
    });
  </script>
  
</body>
</html>
