<?php
session_start();
require_once 'config/database.php';
require_once 'config/korapay.php';
require_once 'includes/session.php';
require_once 'includes/connect.php';

define('PAYSTACK_PUBLIC_KEY', 'pk_test_40030e4aa08e323dc666117c50c698d2583a05df');
define('PAYSTACK_SECRET_KEY', 'sk_test_60026e40277f7334fddec6fccb31eb8ab5c51f01');

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$user_id = $_SESSION['user_id'];

// Fetch user data
$stmt = $conn->prepare("
    SELECT u.*, b.total_balance, b.task_earnings, b.referral_earnings, b.game_earnings
    FROM users u 
    LEFT JOIN balances b ON u.id = b.user_id 
    WHERE u.id = ?
");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();
$stmt->close();

// Fetch user's email and full_name for Paystack metadata
$user_data = $user; 

if (!$user) {
    header('Location: login.php');
    exit();
}

function getRenewalPrice($start_date, $first_year_price, $normal_price) {
    if (!$start_date) {
        return $first_year_price; // First time subscriber
    }
    
    $start = new DateTime($start_date);
    $now = new DateTime();
    $diff = $start->diff($now);
    
    // If more than 1 year has passed, use normal price
    if ($diff->y >= 1) {
        return $normal_price;
    }
    
    return $first_year_price;
}

$premium_price = getRenewalPrice($user['membership_start_date'], 1500, 3500);
$senior_yearly_price = getRenewalPrice($user['advertiser_plan_start_date'], 2500, 5500);

// Handle Korapay redirect callback (checkout_url redirects here after payment)
// Korapay sends back: ?reference=EARNOVA-xxx&status=success (or failed)
if (isset($_GET['reference'])) {
    $reference = $_GET['reference'];
    
    // Check if this is a Korapay reference (format: EARNOVA-xxxx-...)
    if (strpos($reference, 'EARNOVA-') === 0) {
        error_log(" Korapay redirect callback received - Reference: $reference");
        
        try {
            $kp_verify = verifyKorapayCharge($reference);
            file_put_contents("logs/payment_error.log", date('Y-m-d H:i:s') . " | Korapay API Response: " . json_encode($kp_verify) . PHP_EOL, FILE_APPEND);
            error_log(" Korapay verify response: " . json_encode($kp_verify));
            
            // Check if charge was successful
            $is_success = false;
            $kp_data = $kp_verify['data'] ?? [];
            
            if (!empty($kp_verify['status']) && $kp_verify['status'] === true) {
                if (isset($kp_data['status']) && $kp_data['status'] === 'success') {
                    $is_success = true;
                } else {
                    file_put_contents("logs/payment_error.log", date('Y-m-d H:i:s') . " | Korapay Reason: kp_data.status != 'success'. status='" . ($kp_data['status'] ?? 'MISSING') . "'" . PHP_EOL, FILE_APPEND);
                }
            } else {
                file_put_contents("logs/payment_error.log", date('Y-m-d H:i:s') . " | Korapay Reason: kp_verify.status != true. status='" . ($kp_verify['status'] ?? 'MISSING') . "'" . PHP_EOL, FILE_APPEND);
            }
            
            if ($is_success) {
                // Map Korapay response to the Paystack format so we can reuse existing logic
                // Map Korapay response into Paystack-like shape.
                // Korapay returns amounts as a decimal string (e.g. "1200.00").
                // Convert to kobo (integer) so downstream code that expects Paystack's
                // integer kobo amount works correctly.
                $amount_kobo = (int) round(floatval($kp_data['amount'] ?? 0) * 100);
                $result = [
                  'status' => true,
                  'data' => [
                    'status' => 'success',
                    'amount' => $amount_kobo,
                    'reference' => $reference,
                    'metadata' => $kp_data['metadata'] ?? [],
                    'customer' => [
                      'email' => $kp_data['customer']['email'] ?? null
                    ]
                  ]
                ];
                error_log(" Mapped Korapay result to Paystack shape: " . json_encode($result));
                file_put_contents("logs/payment_error.log", date('Y-m-d H:i:s') . " | Korapay Verified Success: amount_kobo=$amount_kobo, result=" . json_encode($result) . PHP_EOL, FILE_APPEND);
                $status = 'success';
                
                error_log(" Korapay charge verified successfully");
            } else {
                error_log(" Korapay charge verification failed - status not success");
                file_put_contents("logs/payment_error.log", date('Y-m-d H:i:s') . " | Korapay Verification Failed: is_success=false" . PHP_EOL, FILE_APPEND);
                $status = 'failed';
                $result = ['status' => false, 'data' => ['status' => 'failed']];
            }
        } catch (Exception $e) {
            error_log(' Korapay verification exception: ' . $e->getMessage());
            file_put_contents("logs/payment_error.log", date('Y-m-d H:i:s') . " | Korapay Exception: " . $e->getMessage() . " Trace: " . $e->getTraceAsString() . PHP_EOL, FILE_APPEND);
            $status = 'failed';
            $result = ['status' => false, 'data' => ['status' => 'failed']];
        }
    }

// Process callback when a reference is present. Some gateways (or webhooks)
// may not include a `status` GET param on redirect — prefer verified data
// from earlier Korapay verification if available.
if (isset($_GET['reference'])) {
  $reference = $_GET['reference'];
  // Prefer explicit status if provided by the redirect, otherwise use the
  // status derived from the earlier remote verification (e.g. Korapay).
  $status = $_GET['status'] ?? ($result['data']['status'] ?? null);

  error_log(" Payment callback received - Status: " . var_export($status, true) . ", Reference: $reference");

  // If this reference looks like a Korapay reference (we mapped it earlier),
  // reuse the $result created by the Korapay verification above and skip Paystack verify.
  $is_korapay_ref = (strpos($reference, 'EARNOVA-') === 0);

  if ($is_korapay_ref) {
    error_log(" Detected Korapay reference, using earlier Korapay verification result.");
    // Ensure $result and $status are available from earlier Korapay handling.
    if (!isset($result) || !is_array($result)) {
      // Attempt a fresh verification just in case (graceful fallback)
      try {
        $kp_verify = verifyKorapayCharge($reference);
        error_log(" Korapay fallback verify response: " . json_encode($kp_verify));
        $kp_data = $kp_verify['data'] ?? [];
          if (!empty($kp_verify['status']) && $kp_verify['status'] === true && isset($kp_data['status']) && $kp_data['status'] === 'success') {
          // Convert Korapay decimal amount string into kobo integer for parity with Paystack
          $amount_kobo = (int) round(floatval($kp_data['amount'] ?? 0) * 100);
          $result = [
            'status' => true,
            'data' => [
              'status' => 'success',
              'amount' => $amount_kobo,
              'reference' => $reference,
              'metadata' => $kp_data['metadata'] ?? [],
              'customer' => ['email' => $kp_data['customer']['email'] ?? null]
            ]
          ];
          error_log(" Korapay fallback mapped result: " . json_encode($result));
        } else {
          $result = ['status' => false, 'data' => ['status' => 'failed']];
        }
      } catch (Exception $e) {
        error_log(' Korapay fallback verification exception: ' . $e->getMessage());
        $result = ['status' => false, 'data' => ['status' => 'failed']];
      }
    }
  } else {
    // Non-Korapay flow: Paystack verification
    if ($status === 'success') {
      $curl = curl_init();
      curl_setopt_array($curl, array(
        CURLOPT_URL => "https://api.paystack.co/transaction/verify/{$reference}",
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HTTPHEADER => array(
          "Authorization: Bearer " . PAYSTACK_SECRET_KEY
        ),
      ));

      $response = curl_exec($curl);
      $curl_error = curl_error($curl);
      curl_close($curl);

      error_log(" Paystack API Response: " . $response);
      file_put_contents("logs/payment_error.log", date('Y-m-d H:i:s') . " | Paystack API Response: " . $response . PHP_EOL, FILE_APPEND);
      if ($curl_error) {
        error_log(" CURL Error: " . $curl_error);
        file_put_contents("logs/payment_error.log", date('Y-m-d H:i:s') . " | CURL Error: " . $curl_error . PHP_EOL, FILE_APPEND);
      }

      $result = json_decode($response, true);
    } else {
      // status is not 'success' and not Korapay
      error_log(" Payment status is not success: $status");
      $result = ['status' => false, 'data' => ['status' => 'failed']];
    }
  }

  // Deep debug: dump GET, is_korapay_ref, and the verification result before deciding
  error_log("DEBUG: ", 0);
  error_log("DEBUG GET: " . json_encode($_GET));
  error_log("DEBUG is_korapay_ref: " . ($is_korapay_ref ? 'true' : 'false'));
  error_log("DEBUG result raw: " . json_encode($result));
  $debug_has_result = !empty($result) && isset($result['status']) && $result['status'] === true;
  $debug_data_status = isset($result['data']['status']) ? $result['data']['status'] : 'MISSING';
  error_log("DEBUG condition parts: has_result=" . ($debug_has_result ? 'true' : 'false') . ", data_status=" . $debug_data_status);

  // Log each part of the success condition separately
  file_put_contents("logs/payment_error.log", date('Y-m-d H:i:s') . " | Condition check - !empty(result)=" . (!empty($result) ? 'true' : 'false') . PHP_EOL, FILE_APPEND);
  file_put_contents("logs/payment_error.log", date('Y-m-d H:i:s') . " | Condition check - isset(result[status])=" . (isset($result['status']) ? 'true' : 'false') . PHP_EOL, FILE_APPEND);
  file_put_contents("logs/payment_error.log", date('Y-m-d H:i:s') . " | Condition check - result[status]===true=" . (isset($result['status']) && $result['status'] === true ? 'true' : 'false') . PHP_EOL, FILE_APPEND);
  file_put_contents("logs/payment_error.log", date('Y-m-d H:i:s') . " | Condition check - isset(result[data][status])=" . (isset($result['data']['status']) ? 'true' : 'false') . PHP_EOL, FILE_APPEND);
  file_put_contents("logs/payment_error.log", date('Y-m-d H:i:s') . " | Condition check - result[data][status]===\"success\"=" . (isset($result['data']['status']) && $result['data']['status'] === 'success' ? 'true' : 'false') . PHP_EOL, FILE_APPEND);

    // Proceed only if result indicates success
    file_put_contents("logs/payment_error.log", date('Y-m-d H:i:s') . " | Before success check - GET: " . json_encode($_GET) . ", is_korapay_ref: " . ($is_korapay_ref ? 'true' : 'false') . ", result: " . json_encode($result) . PHP_EOL, FILE_APPEND);

    // Compute a single boolean to avoid complex short-circuit confusion
    $is_verified_result = (!empty($result) && isset($result['status']) && $result['status'] === true && isset($result['data']['status']) && $result['data']['status'] === 'success');
    file_put_contents("logs/payment_error.log", date('Y-m-d H:i:s') . " | Computed is_verified_result=" . ($is_verified_result ? 'true' : 'false') . PHP_EOL, FILE_APPEND);

    // For Korapay references explicitly accept when the mapped result indicates success
    $accept_payment = false;
    if ($is_korapay_ref && $is_verified_result) {
      $accept_payment = true;
      file_put_contents("logs/payment_error.log", date('Y-m-d H:i:s') . " | Korapay auto-accept applied." . PHP_EOL, FILE_APPEND);
    } else {
      $accept_payment = $is_verified_result;
    }

    if ($accept_payment) {
        $amount = $result['data']['amount'] / 100; // Paystack returns amount in kobo
        $payment_type = $result['data']['metadata']['payment_type'] ?? null;
        if ($payment_type === null) {
          error_log("DEBUG: metadata.payment_type is missing in result: " . json_encode($result['data']['metadata'] ?? []));
          file_put_contents("logs/payment_error.log", date('Y-m-d H:i:s') . " | Missing payment_type in metadata: " . json_encode($result['data']['metadata'] ?? []) . PHP_EOL, FILE_APPEND);
        }

        error_log(" Payment verified - Amount: $amount, Type: $payment_type");
        file_put_contents("logs/payment_error.log", date('Y-m-d H:i:s') . " | Payment Success - Amount: $amount, Type: $payment_type" . PHP_EOL, FILE_APPEND);
            
            // Start transaction
            $conn->begin_transaction();
            
            try {
                if ($payment_type === 'premium_upgrade') {
                    error_log(" Processing premium upgrade for user_id: $user_id");
                    
                    $downline_username = $user['username'];
                    $downline_plan = 'Premium';
                    
                    // Process premium upgrade (old 1500/year plan)
                    $upgrade_amount = $amount; // This should reflect the actual amount paid
                    $referrer_commission = 500; // Fixed commission for premium upgrade
                    $company_amount = $upgrade_amount - $referrer_commission; // The amount for the company
                    
                    // Update user membership, ensuring membership_start_date is set if it's the first purchase
                    $stmt = $conn->prepare("UPDATE users SET membership_type = 'premium', membership_expires_at = DATE_ADD(NOW(), INTERVAL 1 YEAR), membership_start_date = COALESCE(membership_start_date, NOW()) WHERE id = ?");
                    $stmt->bind_param("i", $user_id);
                    if (!$stmt->execute()) {
                        error_log(" ERROR updating users table: " . $stmt->error);
                        throw new Exception("Failed to update user membership: " . $stmt->error);
                    }
                    $stmt->close();
                    error_log(" User membership updated successfully");
                    
                    $stmt = $conn->prepare("INSERT INTO premium_payments (user_id, amount, payment_method, payment_reference, status, referrer_commission, company_amount) VALUES (?, ?, 'paystack', ?, 'completed', ?, ?)");
                    $stmt->bind_param("idsdd", $user_id, $upgrade_amount, $reference, $referrer_commission, $company_amount);
                    if (!$stmt->execute()) {
                        error_log(" ERROR inserting into premium_payments: " . $stmt->error);
                        throw new Exception("Failed to record premium payment: " . $stmt->error);
                    }
                    $stmt->close();
                    error_log(" Premium payment recorded successfully");
                    
                    if ($user['referred_by']) {
                        $referrer_id = $user['referred_by'];
                        error_log(" Processing referrer commission for referrer_id: $referrer_id");
                        
                        $stmt = $conn->prepare("SELECT membership_type, advertiser_plan FROM users WHERE id = ?");
                        $stmt->bind_param("i", $referrer_id);
                        $stmt->execute();
                        $referrer_result = $stmt->get_result();
                        $referrer = $referrer_result->fetch_assoc();
                        $stmt->close();
                        
                        $commission = 0;
                        $commission_type = 'premium_upgrade';
                        
                        // Rule: Free users earn nothing until they upgrade
                        if ($referrer && $referrer['membership_type'] !== 'free') {
                            // Premium user referring Premium user = N500
                            if ($referrer['membership_type'] === 'premium' && $referrer['advertiser_plan'] !== 'senior') {
                                $commission = 500;
                                error_log("Premium user referring Premium: N500 commission");
                            }
                            // Premium Plus (Senior) user referring any tier = N500 for Premium
                            elseif ($referrer['advertiser_plan'] === 'senior') {
                                $commission = 500;
                                error_log("Premium Plus user referring Premium: N500 commission");
                            }
                        } else {
                            error_log("Referrer is Free user - no commission awarded until they upgrade");
                        }
                        
                        // Award commission if applicable
                        if ($commission > 0) {
                            // Update referrer's balance
                            $stmt = $conn->prepare("UPDATE balances SET referral_earnings = referral_earnings + ?, total_balance = total_balance + ? WHERE user_id = ?");
                            $stmt->bind_param("ddi", $commission, $commission, $referrer_id);
                            if (!$stmt->execute()) {
                                error_log(" ERROR updating referrer balance: " . $stmt->error);
                                throw new Exception("Failed to update referrer balance: " . $stmt->error);
                            }
                            $stmt->close();
                            error_log(" Referrer balance updated successfully with N$commission");
                            
                            $stmt = $conn->prepare("INSERT INTO referral_commissions (referrer_id, referred_user_id, commission_type, commission_amount, description) VALUES (?, ?, ?, ?, ?)");
                            $commission_description = "$downline_username upgraded to $downline_plan";
                            // Bind types: referrer_id (i), referred_user_id (i), commission_type (s), commission_amount (d), description (s)
                            $stmt->bind_param("iisds", $referrer_id, $user_id, $commission_type, $commission, $commission_description);
                            if (!$stmt->execute()) {
                                error_log(" ERROR inserting referral commission: " . $stmt->error);
                                throw new Exception("Failed to record referral commission: " . $stmt->error);
                            }
                            $stmt->close();
                            
                            // Record transaction for referrer
                            $stmt = $conn->prepare("INSERT INTO transactions (user_id, transaction_type, amount, balance_type, description, reference_id) VALUES (?, 'invite_commission', ?, 'Prime Earnings', ?, ?)");
                            $transaction_description = "$downline_username upgraded to $downline_plan plan - Commission";
                            $stmt->bind_param("idss", $referrer_id, $commission, $transaction_description, $reference);
                            if (!$stmt->execute()) {
                                error_log(" ERROR inserting referrer transaction: " . $stmt->error);
                                throw new Exception("Failed to record referrer transaction: " . $stmt->error);
                            }
                            $stmt->close();
                            error_log(" Referrer commission recorded successfully");
                        }
                    }
                    
                    // Record transaction
                    $stmt = $conn->prepare("INSERT INTO transactions (user_id, transaction_type, amount, balance_type, description, reference_id) VALUES (?, 'premium_upgrade', ?, 'total', 'Premium membership upgrade', ?)");
                    $stmt->bind_param("ids", $user_id, $upgrade_amount, $reference);
                    if (!$stmt->execute()) {
                        error_log(" ERROR inserting user transaction: " . $stmt->error);
                        throw new Exception("Failed to record user transaction: " . $stmt->error);
                    }
                    $stmt->close();
                    
                    $success_message = "Membership upgrade is successful!";
                    error_log(" Premium upgrade completed successfully");
                    
                } elseif ($payment_type === 'premium_plus_upgrade') {
                    error_log(" Processing premium plus upgrade for user_id: $user_id");
                    
                    $was_premium = ($user['membership_type'] === 'premium');

                    // ⭐ Auto-upgrade user to Premium if they buy Senior before Premium
                    if (!$was_premium) {
                        $stmt = $conn->prepare("
                            UPDATE users 
                            SET membership_type = 'premium',
                                membership_expires_at = DATE_ADD(NOW(), INTERVAL 1 YEAR),
                                membership_start_date = COALESCE(membership_start_date, NOW())
                            WHERE id = ?
                        ");
                        $stmt->bind_param("i", $user_id);
                        if (!$stmt->execute()) {
                            error_log("ERROR auto-upgrading user to premium during senior purchase: " . $stmt->error);
                            throw new Exception("Failed to auto-upgrade user to premium");
                        }
                        $stmt->close();
                        error_log("User auto-upgraded to Premium because they purchased Senior plan.");
                    }

                    $downline_username = $user['username'];
                    $downline_plan = 'Premium Plus';
                    
                    $plan_duration = $result['data']['metadata']['plan_duration'];
                    $upgrade_amount = $amount;
                    
                    // Calculate expiry date based on plan duration
                    $expires_at = ($plan_duration === 'monthly') 
                        ? date('Y-m-d H:i:s', strtotime('+1 month'))
                        : date('Y-m-d H:i:s', strtotime('+1 year'));
                    
                    // Update user advertiser plan (NOT membership_type). Set advertiser_plan_start_date if it's the first time.
                    $stmt = $conn->prepare("UPDATE users SET advertiser_plan = 'senior', advertiser_plan_start_date = COALESCE(advertiser_plan_start_date, NOW()) WHERE id = ?");
                    $stmt->bind_param("i", $user_id);
                    if (!$stmt->execute()) {
                        error_log(" ERROR updating advertiser plan: " . $stmt->error);
                        throw new Exception("Failed to update advertiser plan: " . $stmt->error);
                    }
                    $stmt->close();
                    
                    $is_renewal = !empty($user['advertiser_plan_start_date']) ? 1 : 0; // Check if it's a renewal
                    $stmt = $conn->prepare("INSERT INTO advertiser_payments (user_id, amount, plan_duration, payment_method, payment_reference, status, is_renewal) VALUES (?, ?, ?, 'paystack', ?, 'completed', ?)");
                    $stmt->bind_param("idssi", $user_id, $upgrade_amount, $plan_duration, $reference, $is_renewal);
                    if (!$stmt->execute()) {
                        error_log(" ERROR inserting advertiser payment: " . $stmt->error);
                        throw new Exception("Failed to record advertiser payment: " . $stmt->error);
                    }
                    $stmt->close();
                    
                    if ($user['referred_by']) {
                        $referrer_id = $user['referred_by'];
                        error_log(" Processing premium plus referrer commission for referrer_id: $referrer_id");
                        
                        $stmt = $conn->prepare("SELECT membership_type, advertiser_plan FROM users WHERE id = ?");
                        $stmt->bind_param("i", $referrer_id);
                        $stmt->execute();
                        $referrer_result = $stmt->get_result();
                        $referrer = $referrer_result->fetch_assoc();
                        $stmt->close();
                        
                        $commission = 0;
                        $commission_type = 'premium_plus_upgrade';
                        
                        // Rule: Free users earn nothing until they upgrade
                        if ($referrer && $referrer['membership_type'] !== 'free') {
                            // Premium user referring Premium Plus = N500
                            if ($referrer['membership_type'] === 'premium' && $referrer['advertiser_plan'] !== 'senior') {
                                $commission = 500;
                                error_log("Premium user referring Premium Plus: N500 commission");
                            }
                            // Premium Plus user referring Premium Plus = N1000
                            elseif ($referrer['advertiser_plan'] === 'senior') {
                                $commission = 1000;
                                error_log("Premium Plus user referring Premium Plus: N1000 commission");
                            }
                        } else {
                            error_log("Referrer is Free user - no commission awarded until they upgrade");
                        }
                        
                        // Award commission if applicable
                        if ($commission > 0) {
                            // Update referrer's balance
                            $stmt = $conn->prepare("UPDATE balances SET referral_earnings = referral_earnings + ?, total_balance = total_balance + ? WHERE user_id = ?");
                            $stmt->bind_param("ddi", $commission, $commission, $referrer_id);
                            if (!$stmt->execute()) {
                                error_log(" ERROR updating referrer balance: " . $stmt->error);
                                throw new Exception("Failed to update referrer balance: " . $stmt->error);
                            }
                            $stmt->close();
                            error_log(" Referrer balance updated successfully with N$commission");
                            
                            $stmt = $conn->prepare("INSERT INTO referral_commissions (referrer_id, referred_user_id, commission_type, commission_amount, description) VALUES (?, ?, ?, ?, ?)");
                            $commission_description = "$downline_username upgraded to $downline_plan plan";
                            // Bind types: referrer_id (i), referred_user_id (i), commission_type (s), commission_amount (d), description (s)
                            $stmt->bind_param("iisds", $referrer_id, $user_id, $commission_type, $commission, $commission_description);
                            if (!$stmt->execute()) {
                                error_log(" ERROR inserting referral commission: " . $stmt->error);
                                throw new Exception("Failed to record referral commission: " . $stmt->error);
                            }
                            $stmt->close();
                            
                            // Record transaction for referrer
                            $stmt = $conn->prepare("INSERT INTO transactions (user_id, transaction_type, amount, balance_type, description, reference_id) VALUES (?, 'invite_commission', ?, 'Prime Earnings', ?, ?)");
                            $transaction_description = "$downline_username upgraded to $downline_plan plan - Commission";
                            $stmt->bind_param("idss", $referrer_id, $commission, $transaction_description, $reference);
                            if (!$stmt->execute()) {
                                error_log(" ERROR inserting referrer transaction: " . $stmt->error);
                                throw new Exception("Failed to record referrer transaction: " . $stmt->error);
                            }
                            $stmt->close();
                            error_log(" Referrer commission recorded successfully");
                        }
                    }
                    
                    // Record transaction
                    $description = "Premium Plus plan upgrade (" . $plan_duration . ")";
                    $stmt = $conn->prepare("INSERT INTO transactions (user_id, transaction_type, amount, balance_type, description, reference_id) VALUES (?, 'premium_upgrade', ?, 'total', ?, ?)");
                    $stmt->bind_param("idss", $user_id, $upgrade_amount, $description, $reference);
                    if (!$stmt->execute()) {
                        error_log(" ERROR inserting advertiser transaction: " . $stmt->error);
                        throw new Exception("Failed to record advertiser transaction: " . $stmt->error);
                    }
                    $stmt->close();
                    
                    $success_message = "Premium Plus plan activated successfully";
                    error_log("Premium Plus upgrade completed successfully");

                } elseif ($payment_type === 'deposit') {
                    error_log("[v0] Processing deposit for user_id: $user_id");
                    
                    $deposit_purpose = $result['data']['metadata']['purpose'];
                    
                    // Validate: Free users cannot deposit for games
                    if ($deposit_purpose === 'games' && $user['membership_type'] !== 'premium') {
                        throw new Exception("Only Premium members can deposit for Games & Entertainment. Please upgrade to Premium first.");
                    }
                    
                    // Route deposit to correct balance based on purpose
                    if ($deposit_purpose === 'games') {
                        // Games & Entertainment → game_earnings
                        $stmt = $conn->prepare("UPDATE balances SET game_earnings = game_earnings + ?, total_balance = total_balance + ? WHERE user_id = ?");
                        $stmt->bind_param("ddi", $amount, $amount, $user_id);
                        if (!$stmt->execute()) {
                            error_log("[v0] ERROR updating game_earnings balance: " . $stmt->error);
                            throw new Exception("Failed to update game balance: " . $stmt->error);
                        }
                        $stmt->close();
                        
                        $balance_type = 'game_earnings';
                        $description = "Deposit for Games & Entertainment";
                    } elseif ($deposit_purpose === 'ads') {
                        // Publish Advertisements → referral_earnings
                        $stmt = $conn->prepare("UPDATE balances SET referral_earnings = referral_earnings + ?, total_balance = total_balance + ? WHERE user_id = ?");
                        $stmt->bind_param("ddi", $amount, $amount, $user_id);
                        if (!$stmt->execute()) {
                            error_log("[v0] ERROR updating referral_earnings balance: " . $stmt->error);
                            throw new Exception("Failed to update Prime wallet: " . $stmt->error);
                        }
                        $stmt->close();
                        
                        $balance_type = 'prime_earnings';
                        $description = "Deposit for Publishing Advertisements";
                    } else {
                        // General balance → referral_earnings
                        $stmt = $conn->prepare("UPDATE balances SET referral_earnings = referral_earnings + ?, total_balance = total_balance + ? WHERE user_id = ?");
                        $stmt->bind_param("ddi", $amount, $amount, $user_id);
                        if (!$stmt->execute()) {
                            error_log("[v0] ERROR updating referral_earnings balance: " . $stmt->error);
                            throw new Exception("Failed to update Prime wallet: " . $stmt->error);
                        }
                        $stmt->close();
                        
                        $balance_type = 'prime_earnings';
                        $description = "Deposit for General Balance";
                    }
                    
                    // Before recording the deposit transaction, ensure Korapay details are recorded
                    // (only for Korapay redirects) so admin UI can show Purpose/Description.
                    if (!empty($is_korapay_ref) && $is_korapay_ref === true) {
                      // Check for existing korapay_transactions row for this reference
                      $chk = $conn->prepare("SELECT id FROM korapay_transactions WHERE korapay_reference = ? LIMIT 1");
                      if ($chk) {
                        $chk->bind_param("s", $reference);
                        $chk->execute();
                        $chk_res = $chk->get_result();
                        $exists = ($chk_res && $chk_res->num_rows > 0);
                        $chk->close();
                      } else {
                        $exists = false;
                      }

                      if (!$exists) {
                        $kp_amount = $amount;
                        $kp_payer_account = $result['data']['metadata']['payer_account_number'] ?? null;
                        $kp_payer_name = $result['data']['metadata']['payer_account_name'] ?? null;
                        // Map deposit purpose to korapay_transactions.deposit_purpose where possible
                        $kp_deposit_purpose = $deposit_purpose ?? ($result['data']['metadata']['deposit_purpose'] ?? 'general');
                        // Use the human-friendly description we set earlier
                        $kp_description = $description ?? ($result['data']['metadata']['description'] ?? null);
                        $kp_narration = $result['data']['metadata']['transaction_narration'] ?? $kp_description;
                        $kp_payment_type = $payment_type ?? ($result['data']['metadata']['payment_type'] ?? 'deposit');
                        $kp_received_at = date('Y-m-d H:i:s');

                        $ins = $conn->prepare(
                          "INSERT INTO korapay_transactions (user_id, korapay_reference, amount, currency, payer_account_number, payer_account_name, transaction_narration, status, payment_type, deposit_purpose, description, received_at) VALUES (?, ?, ?, 'NGN', ?, ?, ?, 'success', ?, ?, ?, ?)"
                        );
                        if ($ins) {
                          $ins->bind_param(
                            "isdsssssss",
                            $user_id,
                            $reference,
                            $kp_amount,
                            $kp_payer_account,
                            $kp_payer_name,
                            $kp_narration,
                            $kp_payment_type,
                            $kp_deposit_purpose,
                            $kp_description,
                            $kp_received_at
                          );
                          $ins->execute();
                          $ins->close();
                        } else {
                          error_log("WARNING: failed to prepare korapay_transactions insert: " . $conn->error);
                          file_put_contents("logs/payment_error.log", date('Y-m-d H:i:s') . " | Failed to prepare korapay_transactions insert: " . $conn->error . PHP_EOL, FILE_APPEND);
                        }
                      }
                    }

                    // Record transaction with correct balance_type
                    $stmt = $conn->prepare("INSERT INTO transactions (user_id, transaction_type, amount, balance_type, description, reference_id) VALUES (?, 'deposit', ?, ?, ?, ?)");
                    $stmt->bind_param("idsss", $user_id, $amount, $balance_type, $description, $reference);
                    if (!$stmt->execute()) {
                      error_log("[v0] ERROR inserting deposit transaction: " . $stmt->error);
                      throw new Exception("Failed to record deposit transaction: " . $stmt->error);
                    }
                    $stmt->close();
                    
                    $success_message = "Deposit of ₦" . number_format($amount, 2) . " successful!";
                    error_log("[v0] Deposit completed successfully");
                }
                
                $conn->commit();
                error_log(" Transaction committed successfully");
                
                // Refresh user data
                $stmt = $conn->prepare("
                    SELECT u.*, b.total_balance, b.task_earnings, b.referral_earnings, b.game_earnings 
                    FROM users u 
                    LEFT JOIN balances b ON u.id = b.user_id 
                    WHERE u.id = ?
                ");
                $stmt->bind_param("i", $user_id);
                $stmt->execute();
                $result = $stmt->get_result();
                $user = $result->fetch_assoc();
                $stmt->close();

                // Fetch user's email and full_name for Paystack metadata after refresh
                $user_data = $user;

                // Recalculate prices after refresh
                $premium_price = getRenewalPrice($user['membership_start_date'], 1500, 3500);
                $senior_yearly_price = getRenewalPrice($user['advertiser_plan_start_date'], 2500, 5500);
                
            } catch (Exception $e) {
                $conn->rollback();
                error_log(" EXCEPTION CAUGHT: " . $e->getMessage());
                error_log(" Exception trace: " . $e->getTraceAsString());
                
                $error_message = "Payment failed. Error: " . $e->getMessage() . " (Check error logs for details)";
            }
        } else {
            error_log(" Paystack verification failed. Response: " . json_encode($result));
            $error_message = "Payment failed. Please contact support. (Paystack verification failed)";
        }
    } else {
      error_log(" Payment verification failed or returned non-success for reference: $reference");
      // Log the reason for the failure with full details
      file_put_contents("logs/payment_error.log", date('Y-m-d H:i:s') . " | Entering ELSE branch - Payment failed" . PHP_EOL, FILE_APPEND);
      
      if (empty($result)) {
        file_put_contents("logs/payment_error.log", date('Y-m-d H:i:s') . " | Payment Failed: result is empty/false" . PHP_EOL, FILE_APPEND);
      } elseif (!isset($result['status'])) {
        file_put_contents("logs/payment_error.log", date('Y-m-d H:i:s') . " | Payment Failed: result['status'] is not set. Full result=" . json_encode($result) . PHP_EOL, FILE_APPEND);
      } elseif ($result['status'] !== true) {
        file_put_contents("logs/payment_error.log", date('Y-m-d H:i:s') . " | Payment Failed: result['status'] is '" . json_encode($result['status']) . "', expected true" . PHP_EOL, FILE_APPEND);
      } elseif (!isset($result['data']) || !isset($result['data']['status'])) {
        file_put_contents("logs/payment_error.log", date('Y-m-d H:i:s') . " | Payment Failed: result['data']['status'] is not set. Full result=" . json_encode($result) . PHP_EOL, FILE_APPEND);
      } elseif ($result['data']['status'] !== 'success') {
        file_put_contents("logs/payment_error.log", date('Y-m-d H:i:s') . " | Payment Failed: result['data']['status'] is '" . json_encode($result['data']['status']) . "', expected 'success'" . PHP_EOL, FILE_APPEND);
      } else {
        file_put_contents("logs/payment_error.log", date('Y-m-d H:i:s') . " | Payment Failed: Unknown reason. Full result=" . json_encode($result) . PHP_EOL, FILE_APPEND);
      }
      $error_message = "Payment was not successful";
    }

    //
    // FLASH: If we set success/error messages during processing above, convert them to session flash
    // and redirect to the same page without query params to prevent form resubmission and to clear GET params.
    //
    if (!empty($success_message)) {
        $_SESSION['success_message'] = $success_message;
        // Redirect to same URL without query string
        $redirect = strtok($_SERVER["REQUEST_URI"], '?');
        header("Location: {$redirect}");
        exit();
    }
    if (!empty($error_message)) {
        $_SESSION['error_message'] = $error_message;
        // Redirect to same URL without query string
        $redirect = strtok($_SERVER["REQUEST_URI"], '?');
        header("Location: {$redirect}");
        exit();
    }
}

// Removed duplicate define statements
// define('PAYSTACK_PUBLIC_KEY', 'pk_test_2889acc30e717c743676ced0e02e0e1ad4d274fe');
// define('PAYSTACK_SECRET_KEY', 'sk_test_6a29ffe76f6118fde9f04cb80713d4393d13c1e2');

$is_premium = ($user['membership_type'] === 'premium');
$is_advertiser = ($user['advertiser_plan'] === 'senior'); // Changed to check advertiser_plan
$membership_display = $is_premium ? 'Premium Member' : 'Basic Member';
if ($is_advertiser) {
    $membership_display .= ' + Premium Plus';
}
?>


<?php include "doctype.php"; ?>
  <!-- Removed Flutterwave script, keeping only Paystack -->
  <script src="https://js.paystack.co/v1/inline.js"></script>
  <style>
     :root {
      --page-blue-900: #030922;
      --page-blue-700: #0a164a;
      --page-blue-500: #142a7e;
      --page-blue-300: #2c5bf5;
      --page-mint: #4de1c1;
      --page-white: #f5f9ff;
      --panel-glass: rgba(13, 24, 62, 0.78);
      --panel-border: rgba(86, 139, 241, 0.28);
      --shadow-heavy: 0 40px 120px rgba(4, 10, 36, 0.65);
      --transition-long: 0.85s cubic-bezier(0.19, 1, 0.22, 1);
      --transition-short: 0.4s ease;
    }

    * { box-sizing: border-box; }

    body {
      margin: 0;
      font-family: "Titillium Web", "Segoe UI", sans-serif;
      background: #030922;
      color: var(--page-white);
      overflow-x: hidden;
    }

    /* Fixed sidebar layout structure */
    .page-shell {
      min-height: 100vh;
      display: flex;
    }
 aside {
      position: fixed;
      left: 0;
      top: 0;
      bottom: 0;
      width: 320px;
      background: rgba(13, 24, 62, 0.78);
      backdrop-filter: blur(18px);
      padding: clamp(1.25rem, 3vw, 2.25rem) clamp(1rem, 2.5vw, 2rem);
      display: flex;
      flex-direction: column;
      gap: clamp(1.25rem, 2.5vw, 2rem);
      border-right: 1px solid var(--panel-border);
      overflow-y: auto;
      z-index: 100;
      transition: transform var(--transition-short);
    }

    aside::before {
      content: "";
      position: absolute;
      inset: 0;
      background: 
        radial-gradient(circle at 20% 30%, rgba(251, 191, 36, 0.15), transparent 50%),
        radial-gradient(circle at 80% 70%, rgba(245, 158, 11, 0.12), transparent 45%);
      pointer-events: none;
    }

    main {
      margin-left: 320px;
      flex: 1;
      padding: clamp(2rem, 4vw, 2.625rem) clamp(1.5rem, 3vw, 3rem);
      display: grid;
      gap: clamp(2rem, 3.5vw, 2.625rem);
    }

    @media (max-width: 960px) {
      .page-shell {
        display: block;
      }

      aside {
        position: relative;
        top: 0;
        width: 100%;
        height: auto;
        border-right: none;
        border-bottom: 1px solid var(--panel-border);
        padding: clamp(1rem, 2.5vw, 1.75rem) clamp(0.875rem, 2vw, 1.25rem);
        gap: clamp(0.875rem, 2vw, 1.25rem);
      }

      aside.scrolled .page-title,
      aside.scrolled .side-description,
      aside.scrolled .vector-cluster {
        display: none;
      }

      aside.scrolled {
        padding: clamp(0.75rem, 1.5vw, 1rem) clamp(0.875rem, 2vw, 1.25rem);
      }

      aside.scrolled .aside-welcome {
        grid-template-columns: auto 1fr;
      }

      main {
        margin-left: 0;
        padding: clamp(1.5rem, 3vw, 2rem) clamp(0.625rem, 1.5vw, 1.25rem) 10rem;
      }

      .vector-cluster {
        display: none;
      }
    }

    .back-link {
      display: inline-flex;
      align-items: center;
      gap: 10px;
      font-weight: 600;
      font-size: clamp(0.75rem, 1.5vw, 0.875rem);
      letter-spacing: 0.1em;
      text-transform: uppercase;
      color: rgba(210, 226, 255, 0.78);
      transition: color var(--transition-short), transform var(--transition-short);
      text-decoration: none;
    }

    .back-link:hover { color: var(--page-white); transform: translateX(-4px); }

    .page-title {
      font-size: clamp(1rem, 3vw, 1.5rem);
      letter-spacing: 0.1em;
      text-transform: uppercase;
      margin: 0 0 clamp(0.5rem, 1vw, 0.75rem);
      font-weight: 700;
    }

    .vector-cluster {
      position: relative;
      width: 100%;
      border-radius: 20px;
      padding: 20px;
      background: linear-gradient(135deg, rgba(251, 191, 36, 0.25), rgba(12, 29, 82, 0.85));
      box-shadow: 0 20px 60px rgba(251, 191, 36, 0.3);
      overflow: hidden;
    }

    .vector-cluster::after {
      content: "";
      position: absolute;
      width: 280px;
      height: 280px;
      top: -120px;
      right: -100px;
      border-radius: 50%;
      background: radial-gradient(circle, rgba(251, 191, 36, 0.4), transparent 65%);
    }

    .vector-cluster img {
      width: 100%;
      border-radius: 16px;
      display: block;
      filter: drop-shadow(0 20px 60px rgba(251, 191, 36, 0.4));
    }

     .aside-welcome {
      display: grid;
      grid-template-columns: auto 1fr;
      align-items: center;
      gap: clamp(0.75rem, 1.5vw, 1rem);
     
      background: linear-gradient(135deg, rgba(44, 91, 245, 0.3), rgba(26, 58, 171, 0.2));
      border: 1px solid rgba(44, 91, 245, 0.5);
      box-shadow: 0 0 10px rgba(44, 91, 245, 0.6);
      border-radius: 20px;
      padding: clamp(0.875rem, 1.75vw, 1.125rem);
      
      position: relative;
      z-index: 2;
    }

    .aside-avatar {
      width: clamp(48px, 10vw, 64px);
      height: clamp(48px, 10vw, 64px);
      border-radius: 50%;
      overflow: hidden;
      border: 4px solid rgba(251, 191, 36, 0.35);
      box-shadow: 0 14px 34px rgba(3, 9, 30, 0.55);
    }

    .aside-avatar img {
      width: 100%;
      display: block;
    }

    .welcome-tag {
      margin: 0;
      font-size: clamp(0.6875rem, 1.25vw, 0.75rem);
      letter-spacing: 0.12em;
      text-transform: uppercase;
      color: rgba(205, 219, 255, 0.62);
    }

    .aside-welcome h3 {
      margin: clamp(0.25rem, 0.5vw, 0.375rem) 0 clamp(0.125rem, 0.25vw, 0.25rem);
      font-size: clamp(1rem, 2vw, 1.12rem);
      letter-spacing: 0.04em;
      color: var(--page-white);
      font-weight: 700;
    }

    .welcome-meta {
      font-size: clamp(0.75rem, 1.5vw, 0.8rem);
      letter-spacing: 0.08em;
      color: rgba(149, 183, 255, 0.7);
    }

    /* Main content membership cards */
    .membership-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
      gap: 24px;
    }

    .membership-card {
      padding: clamp(24px, 4vw, 36px);
      border-radius: 24px;
      background: var(--panel-glass);
      border: 1px solid var(--panel-border);
      box-shadow: var(--shadow-heavy);
      position: relative;
      overflow: hidden;
      transition: transform var(--transition-long);
    }

    .membership-card:hover {
      transform: translateY(-8px);
    }

    .membership-card.current {
      border-color: rgba(77, 225, 193, 0.4);
    }

    .membership-card.premium {
      border-color: rgba(251, 191, 36, 0.4);
      background: linear-gradient(135deg, rgba(251, 191, 36, 0.08), rgba(13, 24, 62, 0.78));
    }

    .membership-card::before {
      content: "";
      position: absolute;
      inset: 0;
      background: url("front/assets/images/header-right-img.png") center/cover no-repeat;
      opacity: 0.05;
      pointer-events: none;
    }

    .card-badge {
      display: inline-block;
      padding: 8px 16px;
      background: rgba(77, 225, 193, 0.2);
      border: 1px solid rgba(77, 225, 193, 0.3);
      border-radius: 20px;
      font-size: clamp(0.7rem, 1.5vw, 0.75rem);
      letter-spacing: 0.1em;
      text-transform: uppercase;
      color: var(--page-mint);
      margin-bottom: 16px;
      font-weight: 600;
    }

    .card-badge.premium {
      background: rgba(251, 191, 36, 0.2);
      border-color: rgba(251, 191, 36, 0.3);
      color: #fbbf24;
    }

    .card-title {
      font-size: clamp(1.5rem, 3vw, 1.8rem);
      margin: 0 0 12px;
      letter-spacing: 0.05em;
      position: relative;
      z-index: 2;
    }

    .card-price {
      font-size: clamp(2rem, 5vw, 2.8rem);
      font-weight: 700;
      margin-bottom: 8px;
      position: relative;
      z-index: 2;
    }

    .card-price span {
      font-size: clamp(1rem, 2vw, 1.2rem);
      color: rgba(216, 230, 255, 0.7);
      font-weight: 400;
    }

    .card-description {
      color: rgba(216, 230, 255, 0.78);
      line-height: 1.7;
      font-size: clamp(0.9rem, 2vw, 1rem);
      margin-bottom: 24px;
      position: relative;
      z-index: 2;
    }

    .card-features {
      list-style: none;
      padding: 0;
      margin: 0 0 24px;
      display: grid;
      gap: 12px;
      position: relative;
      z-index: 2;
    }

    .card-features li {
      display: flex;
      align-items: center;
      gap: 12px;
      font-size: clamp(0.85rem, 1.5vw, 0.95rem);
      color: rgba(210, 224, 253, 0.85);
    }

    .feature-icon {
      width: 24px;
      height: 24px;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 12px;
      flex-shrink: 0;
    }

    .feature-check {
      background: rgba(77, 225, 193, 0.3);
      color: var(--page-mint);
    }

    .feature-lock {
      background: rgba(239, 68, 68, 0.3);
      color: #ef4444;
    }

    .upgrade-btn {
      width: 100%;
      padding: clamp(12px, 2.5vw, 16px);
      border: none;
      border-radius: 14px;
      font-size: clamp(0.9rem, 2vw, 1rem);
      font-weight: 600;
      cursor: pointer;
      transition: transform var(--transition-short);
      position: relative;
      z-index: 2;
      letter-spacing: 0.02em;
    }

    .upgrade-btn.current {
      background: rgba(100, 152, 255, 0.3);
      color: rgba(210, 224, 253, 0.7);
      cursor: not-allowed;
    }

    .upgrade-btn.premium {
      background: linear-gradient(135deg, #fbbf24, #f59e0b);
      color: var(--page-blue-900);
      box-shadow: 0 12px 28px rgba(251, 191, 36, 0.4);
    }

    .upgrade-btn.premium:hover {
      transform: translateY(-3px);
      box-shadow: 0 16px 36px rgba(251, 191, 36, 0.5);
    }

    /* Benefits section */
    .section-white {
      background: rgba(245, 249, 255, 0.96);
      border: 1px solid rgba(60, 102, 212, 0.14);
      border-radius: 22px;
      box-shadow: var(--shadow-heavy);
      padding: clamp(24px, 4vw, 36px);
      color: var(--page-blue-700);
    }

    .section-white h2 {
      color: var(--page-blue-500);
      margin-top: 0;
      font-size: clamp(1.3rem, 3vw, 1.6rem);
      margin-bottom: 24px;
    }

    .benefits-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
      gap: 20px;
    }

    .benefit-item {
      display: flex;
      gap: 16px;
      padding: clamp(16px, 3vw, 20px);
      border-radius: 14px;
      background: rgba(44, 92, 240, 0.08);
      border: 1px solid rgba(44, 92, 240, 0.16);
      transition: transform var(--transition-short);
    }

    .benefit-item:hover {
      transform: translateX(4px);
    }

    .benefit-icon {
      width: 48px;
      height: 48px;
      border-radius: 12px;
      background: linear-gradient(135deg, #fbbf24, #f59e0b);
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 24px;
      flex-shrink: 0;
    }

    .benefit-content h3 {
      margin: 0 0 6px;
      font-size: clamp(0.95rem, 2vw, 1.05rem);
      color: var(--page-blue-500);
    }

    .benefit-content p {
      margin: 0;
      font-size: clamp(0.85rem, 1.5vw, 0.9rem);
      color: rgba(20, 42, 126, 0.7);
      line-height: 1.6;
    }

    footer {
      padding: 40px 0 32px;
      background: linear-gradient(180deg, rgba(1, 5, 16, 0.95), rgba(1, 4, 12, 0.98));
      border-top: 1px solid rgba(86, 136, 230, 0.2);
    }

    .footer-grid {
      max-width: 1020px;
      margin: 0 auto;
      padding: 0 clamp(16px, 4vw, 32px);
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(140px, 1fr));
      gap: 20px;
    }

    .footer-list h4 {
      text-transform: uppercase;
      letter-spacing: 0.1em;
      font-size: clamp(0.75rem, 1.5vw, 0.82rem);
      margin-bottom: 14px;
      color: rgba(181, 201, 240, 0.76);
    }

    .footer-list ul {
      list-style: none;
      padding: 0;
      margin: 0;
      display: grid;
      gap: 10px;
    }

    .footer-list a {
      color: rgba(210, 224, 253, 0.7);
      font-size: clamp(0.8rem, 1.5vw, 0.9rem);
      transition: color var(--transition-short);
    }

    .footer-list a:hover { color: var(--page-mint); }

    .footer-brand {
      text-align: center;
      text-transform: uppercase;
      letter-spacing: 0.12em;
      color: rgba(160, 180, 226, 0.68);
      margin-top: 28px;
      font-size: clamp(0.7rem, 1.5vw, 0.76rem);
    }

    /* Updated mobile footer with 5 icons */
    .mobile-fintech-footer {
      display: none;
      position: fixed;
      left: 12px;
      right: 12px;
      bottom: 16px;
      padding: 10px;
      background: transparent;
      border: 1px solid rgba(86, 139, 241, 0.35);
      border-radius: 32px;
      backdrop-filter: blur(50px);
      box-shadow: 0 20px 60px rgba(4, 10, 36, 0.7);
      justify-content: space-around;
      align-items: center;
      z-index: 90;
    }

    .mobile-fintech-footer a {
      flex: 1;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      gap: 4px;
      text-decoration: none;
      color: rgba(205, 219, 255, 0.75);
      font-size: 0.45rem;
      letter-spacing: 0.06em;
      text-transform: uppercase;
      transition: all var(--transition-short);
      padding: 8px 4px;
      border-radius: 16px;
    }

    /* Special styling for middle icon (3rd icon - Withdraw) */
    /* .mobile-fintech-footer a:nth-child(3) {
      position: relative;
      transform: translateY(-12px);
    } */

    .mobile-fintech-footer a:nth-child(3) .icon-wrapper {
      width: 56px;
      height: 56px;
      border-radius: 50%;
      background: linear-gradient(135deg, rgba(77, 225, 193, 0.25), rgba(47, 91, 234, 0.25));
      backdrop-filter: blur(12px);
      border: 2px solid rgba(77, 225, 193, 0.4);
      display: flex;
      align-items: center;
      justify-content: center;
      box-shadow: 0 8px 24px rgba(77, 225, 193, 0.3);
    }

    .mobile-fintech-footer a:nth-child(3) svg {
      width: 28px;
      height: 28px;
    }

    .mobile-fintech-footer a.active {
      color: var(--page-mint);
    }

    .mobile-fintech-footer svg {
      width: 22px;
      height: 22px;
      fill: currentColor;
      filter: drop-shadow(0 4px 12px rgba(4, 10, 36, 0.4));
    }

    .mobile-fintech-footer a:hover {
      color: var(--page-mint);
      transform: translateY(-2px);
    }

    .mobile-fintech-footer a:nth-child(3):hover {
      transform: translateY(-14px);
    }

    @media (max-width: 680px) {
      body {
        padding-bottom: 100px;
      }

      .mobile-fintech-footer {
        display: flex;
      }
    }

    /* Common toast styles */
.toast-message {
  position: fixed;
  top: 20px;
  right: -400px; /* start hidden off-screen */
  padding: 16px 24px;
  border-radius: 12px;
  color: white;
  font-family: 'Segoe UI', sans-serif;
  font-size: 15px;
  z-index: 1000;
  opacity: 0;
  box-shadow: 0 10px 40px rgba(0, 0, 0, 0.2);
  transition: right 0.6s ease, opacity 0.6s ease;
}

/* Success styling */
.toast-message.success {
  background: rgba(77, 225, 193, 0.95);
  color: #030922;
  box-shadow: 0 10px 40px rgba(77, 225, 193, 0.4);
}

/* Error styling */
.toast-message.error {
  background: rgba(255, 77, 77, 0.95);
  color: #fff;
  box-shadow: 0 10px 40px rgba(255, 77, 77, 0.4);
}

/* When visible */
.toast-message.show {
  right: 20px;
  opacity: 1;
}

    /* Add checkout cart modal styles */
    .checkout-modal {
      display: none;
      position: fixed;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      background: rgba(3, 9, 34, 0.95);
      backdrop-filter: blur(10px);
      z-index: 1000;
      overflow-y: auto;
      padding: 20px;
    }

    .checkout-modal.active {
      display: flex;
      align-items: center;
      justify-content: center;
    }

    .checkout-container {
      max-width: 900px;
      width: 100%;
      background: var(--panel-glass);
      border: 1px solid var(--panel-border);
      border-radius: 24px;
      padding: clamp(24px, 4vw, 40px);
      box-shadow: var(--shadow-heavy);
    }

    .checkout-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 32px;
      padding-bottom: 20px;
      border-bottom: 1px solid var(--panel-border);
    }

    .checkout-header h2 {
      font-size: clamp(1.5rem, 3vw, 2rem);
      margin: 0;
      color: var(--page-white);
    }

    .close-checkout {
      background: none;
      border: none;
      color: rgba(216, 230, 255, 0.7);
      font-size: 32px;
      cursor: pointer;
      transition: color var(--transition-short);
    }

    .close-checkout:hover {
      color: var(--page-white);
    }

    .checkout-grid {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 32px;
    }

    @media (max-width: 768px) {
      .checkout-grid {
        grid-template-columns: 1fr;
      }
    }

    .order-summary {
      background: rgba(44, 91, 245, 0.08);
      border: 1px solid rgba(44, 91, 245, 0.2);
      border-radius: 16px;
      padding: 24px;
    }

    .order-summary h3 {
      margin: 0 0 20px;
      font-size: 1.2rem;
      color: var(--page-white);
    }

    .order-item {
      display: flex;
      justify-content: space-between;
      padding: 12px 0;
      border-bottom: 1px solid rgba(86, 139, 241, 0.2);
    }

    .order-item:last-child {
      border-bottom: none;
      font-weight: 700;
      font-size: 1.2rem;
      color: var(--page-mint);
      padding-top: 16px;
      margin-top: 8px;
      border-top: 2px solid rgba(77, 225, 193, 0.3);
    }

    .billing-form {
      display: grid;
      gap: 20px;
    }

    .form-group {
      display: grid;
      gap: 8px;
    }

    .form-group label {
      color: rgba(216, 230, 255, 0.9);
      font-size: 0.9rem;
      font-weight: 600;
    }

    .form-group input,
    .form-group select,
    .form-group textarea {
      width: 100%;
      padding: 12px;
      border-radius: 10px;
      border: 1px solid rgba(86, 139, 241, 0.3);
      background: rgba(13, 24, 62, 0.5);
      color: var(--page-white);
      font-size: 1rem;
      transition: border-color var(--transition-short);
    }

    .form-group input:focus,
    .form-group select:focus,
    .form-group textarea:focus {
      outline: none;
      border-color: var(--page-mint);
    }

    .payment-gateway-selector {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 16px;
      margin: 24px 0;
    }

    .gateway-option {
      padding: 20px;
      border: 2px solid rgba(86, 139, 241, 0.3);
      border-radius: 12px;
      background: rgba(13, 24, 62, 0.5);
      cursor: pointer;
      transition: all var(--transition-short);
      text-align: center;
    }

    .gateway-option:hover {
      border-color: var(--page-mint);
      transform: translateY(-2px);
    }

    .gateway-option.selected {
      border-color: var(--page-mint);
      background: rgba(77, 225, 193, 0.1);
    }

    .gateway-option input[type="radio"] {
      display: none;
    }

    .gateway-logo {
      font-size: 1.5rem;
      font-weight: 700;
      color: var(--page-white);
      margin-bottom: 8px;
    }

    .proceed-btn {
      width: 100%;
      padding: 16px;
      border: none;
      border-radius: 14px;
      font-size: 1.1rem;
      font-weight: 600;
      cursor: pointer;
      background: linear-gradient(135deg, #fbbf24, #f59e0b);
      color: var(--page-blue-900);
      box-shadow: 0 12px 28px rgba(251, 191, 36, 0.4);
      transition: transform var(--transition-short);
    }

    .proceed-btn:hover {
      transform: translateY(-3px);
      box-shadow: 0 16px 36px rgba(251, 191, 36, 0.5);
    }

    .proceed-btn:disabled {
      opacity: 0.5;
      cursor: not-allowed;
      transform: none;
    }

  </style>
</head>
<body>


<?php if (isset($_SESSION['success_message'])): ?>
  <div id="toast-success" class="toast-message success">
    <?php echo htmlspecialchars($_SESSION['success_message']); ?>
  </div>
  <?php unset($_SESSION['success_message']); ?>
<?php endif; ?>

<?php if (isset($_SESSION['error_message'])): ?>
  <div id="toast-error" class="toast-message error">
    <?php echo htmlspecialchars($_SESSION['error_message']); ?>
  </div>
  <?php unset($_SESSION['error_message']); ?>
<?php endif; ?>



<?php include "header2.php"; ?>

  <div class="page-shell">
    <?php include "embed.php"; ?>
  
      
    <main>
    
      <!-- Updated deposit section with three deposit types -->
      <section style="<?php echo ($user['membership_type'] === 'free') ? 'display:none;' : ''; ?>">
        <h2 style="font-size: clamp(1.3rem, 3vw, 1.6rem); margin-bottom: 20px; color: var(--page-white); display:flex; align-items:center; gap:8px;">
  <svg viewBox="0 0 24 24" width="22" height="22" fill="currentColor">
    <path d="M12 2c1.1 0 2 .9 2 2v1.2c1.7.5 3 2 3 3.8 0 2.2-1.8 4-4 4h-2c-2.2 0-4-1.8-4-4 0-1.8 1.3-3.3 3-3.8V4c0-1.1.9-2 2-2Zm-2 11h4v2h-4v-2Zm-2 4h8v2H8v-2Zm-2 4h12v2H6v-2Z"/>
  </svg>
  Deposit Funds 
</h2>

        <div class="membership-grid">
          <article class="membership-card" style="background: linear-gradient(135deg, rgba(77, 225, 193, 0.08), rgba(13, 24, 62, 0.78));">
            <span class="card-badge">Quick Deposit</span>
            <h3 class="card-title">Add Balance</h3>
            <p class="card-description">Choose where to deposit your funds based on your needs.</p>
            
            <div style="margin: 24px 0;">
              <label style="display: block; margin-bottom: 8px; color: rgba(216, 230, 255, 0.9); font-size: 0.9rem;">Amount (₦)</label>
              <input type="number" id="deposit-amount" min="100" step="100" placeholder="Enter amount" style="width: 100%; padding: 12px; border-radius: 10px; border: 1px solid rgba(86, 139, 241, 0.3); background: rgba(13, 24, 62, 0.5); color: var(--page-white); font-size: 1rem;" />
              <p style="color: #e53935; font-size: 12px; margin-top: 5px; font-weight: 500;">Minimum deposit amount is ₦1,000</p>
            </div>
            
            <!-- Added deposit type selection with clear descriptions -->
            <div style="margin: 24px 0;">
              <label style="display: block; margin-bottom: 12px; color: rgba(216, 230, 255, 0.9); font-size: 0.95rem; font-weight: 600;">Select Deposit Type</label>
              
              <!-- Publish Advertisements Option -->
              <div class="deposit-option" data-purpose="ads" style="padding: 14px; border-radius: 12px; border: 2px solid rgba(86, 139, 241, 0.3); background: rgba(13, 24, 62, 0.4); margin-bottom: 12px; cursor: pointer; transition: all 0.3s ease;">
                <div style="display: flex; align-items: start; gap: 12px;">
                  <input type="radio" name="deposit-purpose" value="ads" id="purpose-ads" style="margin-top: 4px; cursor: pointer;" />
                  <div style="flex: 1;">
                    <label for="purpose-ads" style="display: block; font-weight: 600; color: var(--page-white); margin-bottom: 4px; cursor: pointer; font-size: 0.95rem;">
                       Publish Advertisements
                    </label>
                    <p style="margin: 0; font-size: 0.8rem; color: rgba(216, 230, 255, 0.7); line-height: 1.5;">
                      Deposit goes to <strong style="color: var(--page-mint);">Prime Balance</strong>. Use this to create and publish advertising tasks for your business or services.
                    </p>
                  </div>
                </div>
              </div>
              
              <!-- Games & Entertainment Option -->
              <div class="deposit-option" data-purpose="games" style="padding: 14px; border-radius: 12px; border: 2px solid rgba(86, 139, 241, 0.3); background: rgba(13, 24, 62, 0.4); margin-bottom: 12px; cursor: pointer; transition: all 0.3s ease; <?php echo $is_premium ? '' : 'opacity: 0.6;'; ?>">
                <div style="display: flex; align-items: start; gap: 12px;">
                  <input type="radio" disabled name="deposit-purpose" value="games" id="purpose-games" style="margin-top: 4px; cursor: pointer;" <?php echo $is_premium ? '' : 'disabled'; ?> />
                  <div style="flex: 1;">
                    <label for="purpose-games" style="display: block; font-weight: 600; color: var(--page-white); margin-bottom: 4px; cursor: pointer; font-size: 0.95rem;">
                       Games & Entertainment <?php echo !$is_premium ? '<span style="color: #fbbf24; font-size: 0.75rem;">(Premium Only)</span>' : ''; ?>
                    </label>
                    <p style="margin: 0; font-size: 0.8rem; color: rgba(216, 230, 255, 0.7); line-height: 1.5;">
                     Deposit to games is currently not available.
                    </p>
                  </div>
                </div>
              </div>
              
              <!-- General Balance Option -->
              <div class="deposit-option" data-purpose="general" style="padding: 14px; border-radius: 12px; border: 2px solid rgba(86, 139, 241, 0.3); background: rgba(13, 24, 62, 0.4); cursor: pointer; transition: all 0.3s ease;">
                <div style="display: flex; align-items: start; gap: 12px;">
                  <input type="radio" name="deposit-purpose" value="general" id="purpose-general" style="margin-top: 4px; cursor: pointer;" checked />
                  <div style="flex: 1;">
                    <label for="purpose-general" style="display: block; font-weight: 600; color: var(--page-white); margin-bottom: 4px; cursor: pointer; font-size: 0.95rem;">
                       General Balance
                    </label>
                    <p style="margin: 0; font-size: 0.8rem; color: rgba(216, 230, 255, 0.7); line-height: 1.5;">
                      Deposit goes to <strong style="color: var(--page-mint);">Prime Balance</strong>. Use this for general purposes, withdrawals, and other platform activities.
                    </p>
                  </div>
                </div>
              </div>
            </div>
            
            <button class="upgrade-btn premium" onclick="initiateDeposit()">Deposit Now</button>
          </article>
          
          <article class="membership-card" style="background: linear-gradient(135deg, rgba(77, 225, 193, 0.08), rgba(13, 24, 62, 0.78));">
            <span class="card-badge">Current Balance</span>
            <h3 class="card-title">Your Wallet</h3>
            <div style="margin: 20px 0;">
              <div style="margin-bottom: 16px;">
                <p style="margin: 0; font-size: 0.85rem; color: rgba(216, 230, 255, 0.7);">Total Balance</p>
                <p style="margin: 4px 0 0; font-size: 1.8rem; font-weight: 700; color: var(--page-mint);">₦<?php echo number_format($user['total_balance'], 2); ?></p>
              </div>
              <div style="margin-bottom: 16px;">
                <p style="margin: 0; font-size: 0.85rem; color: rgba(216, 230, 255, 0.7);">Activity Balance</p>
                <p style="margin: 4px 0 0; font-size: 1.3rem; font-weight: 600; color: rgba(210, 224, 253, 0.9);">₦<?php echo number_format($user['task_earnings'], 2); ?></p>
              </div>
              <div style="margin-bottom: 16px;">
                <p style="margin: 0; font-size: 0.85rem; color: rgba(216, 230, 255, 0.7);">Prime Wallet</p>
                <p style="margin: 4px 0 0; font-size: 1.3rem; font-weight: 600; color: rgba(210, 224, 253, 0.9);">₦<?php echo number_format($user['referral_earnings'], 2); ?></p>
              </div>
              <div>
                <p style="margin: 0; font-size: 0.85rem; color: rgba(216, 230, 255, 0.7);">Game Earnings</p>
                <p style="margin: 4px 0 0; font-size: 1.3rem; font-weight: 600; color: rgba(210, 224, 253, 0.9);">₦<?php echo number_format($user['game_earnings'], 2); ?></p>
              </div>
            </div>
          </article>
        </div>
      </section>

      <!-- Membership Cards -->
      <section style="margin-top: 32px;">
        <h2 style="font-size: clamp(1.3rem, 3vw, 1.6rem); margin-bottom: 20px; color: var(--page-white);">Membership Plans</h2>
        <div class="membership-grid">
          <!-- Premium Plan -->
          <article class="membership-card premium <?php echo $is_premium ? 'current' : ''; ?>">
            <?php if ($is_premium): ?>
              <span class="card-badge premium">✓ Active</span>
            <?php else: ?>
              <span class="card-badge premium"> Recommended</span>
              <?php if ($premium_price == 1500): ?>
                <div style="position: absolute; top: 16px; right: 16px; background: linear-gradient(135deg, #ef4444, #dc2626); color: white; padding: 6px 12px; border-radius: 8px; font-size: 0.75rem; font-weight: 700; letter-spacing: 0.05em; box-shadow: 0 4px 12px rgba(239, 68, 68, 0.4); z-index: 10;">
                  57% OFF
                </div>
              <?php endif; ?>
            <?php endif; ?>
            <h3 class="card-title">Premium</h3>
            <?php if ($premium_price == 1500): ?>
              <div class="card-price">
                <span style="font-size: 1.2rem; color: rgba(216, 230, 255, 0.5); text-decoration: line-through; margin-right: 8px;">₦3,500</span>
                ₦1,500<span>/year</span>
              </div>
              <p style="font-size: 0.85rem; color: var(--page-mint); margin-top: 4px; margin-bottom: 12px;"> First year special discount!</p>
            <?php else: ?>
              <div class="card-price">₦<?php echo number_format($premium_price, 0); ?><span>/year</span></div>
            <?php endif; ?>
            <p class="card-description">Unlock all premium features and maximize your potential</p>
            <ul class="card-features">
              <li>
                <span class="feature-icon feature-check">✓</span>
                Everything in Basic
              </li>
              <li>
                <span class="feature-icon feature-check">✓</span>
                Advanced Analytics Dashboard
              </li>
              <li>
                <span class="feature-icon feature-check">✓</span>
                Priority 24/7 Support
              </li>
              <li>
                <span class="feature-icon feature-check">✓</span>
                Higher Withdrawal Limits
              </li>
              <li>
                <span class="feature-icon feature-check">✓</span>
                Exclusive Premium Tasks
              </li>
              <li>
                <span class="feature-icon feature-check">✓</span>
                Special Invite Bonuses (₦500 per upgrade)
              </li>
              <li>
                <span class="feature-icon feature-check">✓</span>
                Early Access to New Features
              </li>
            </ul>
            <?php if ($is_premium): ?>
              <button class="upgrade-btn current">Current Plan</button>
              <?php if ($user['membership_expires_at']): ?>
                <p style="margin-top: 12px; font-size: 0.85rem; color: rgba(216, 230, 255, 0.7); text-align: center;">
                  Expires: <?php echo date('M d, Y', strtotime($user['membership_expires_at'])); ?>
                </p>
              <?php endif; ?>
            <?php else: ?>
              <button class="upgrade-btn premium" onclick="openCheckout('premium_upgrade', <?php echo $premium_price; ?>, 'Premium Membership')">Upgrade to Premium</button>
            <?php endif; ?>
          </article>
        </div>
      </section>

      <!-- New separate section for Advertiser Plans -->
      <section style="margin-top: 20px;">
        <h2 style="font-size: clamp(1.3rem, 3vw, 1.6rem); margin-bottom: 12px; color: var(--page-white); display: flex; align-items: center; gap: 8px;">
          📢 Advertiser Plans
        </h2>
        <p style="color: rgba(216, 230, 255, 0.8); margin-bottom: 24px; font-size: 0.95rem;">
           <!--Upgrade to Premium Plus member to access all features on premium time!-->
        </p>
        <div class="membership-grid">
          <article class="membership-card premium" style="background: linear-gradient(135deg, rgba(251, 146, 60, 0.12), rgba(13, 24, 62, 0.78)); border-color: rgba(251, 146, 60, 0.45);">
            <?php if ($is_advertiser): ?>
              <span class="card-badge premium" style="background: rgba(77, 225, 193, 0.25); border-color: rgba(77, 225, 193, 0.4); color: var(--page-mint);">✓ Active Advertiser</span>
            <?php else: ?>
              <span class="card-badge premium" style="background: rgba(251, 146, 60, 0.25); border-color: rgba(251, 146, 60, 0.4); color: #fb923c;">🏆 Best for Advertising</span>
              <?php if ($senior_yearly_price == 2500): ?>
                <div style="position: absolute; top: 16px; right: 16px; background: linear-gradient(135deg, #ef4444, #dc2626); color: white; padding: 6px 12px; border-radius: 8px; font-size: 0.75rem; font-weight: 700; letter-spacing: 0.05em; box-shadow: 0 4px 12px rgba(239, 68, 68, 0.4); z-index: 10;">
                  55% OFF
                </div>
              <?php endif; ?>
            <?php endif; ?>
            <h3 class="card-title">Premium Plus</h3>
            <div class="card-price">
              <?php if ($senior_yearly_price == 2500): ?>
                <span style="font-size: 1.2rem; color: rgba(216, 230, 255, 0.5); text-decoration: line-through; margin-left: 8px; margin-right: 8px;">₦5,500</span>
                ₦2,500<span>/year</span>
              <?php else: ?>
                ₦<?php echo number_format($senior_yearly_price, 0); ?><span>/year</span>
              <?php endif; ?>
            </div>
            <?php if ($senior_yearly_price == 2500): ?>
              <p style="font-size: 0.85rem; color: var(--page-mint); margin-top: 4px; margin-bottom: 12px;"> First year special discount!</p>
            <?php endif; ?>
            <p class="card-description"> You can be a Premium Member AND a Premium plus user at the same time!</p>
            <ul class="card-features">
              <li>
                <span class="feature-icon feature-check" style="background: rgba(251, 146, 60, 0.3); color: #fb923c;">✓</span>
                Post Task Access - Create advertising tasks
              </li>
              <li>
                <span class="feature-icon feature-check" style="background: rgba(251, 146, 60, 0.3); color: #fb923c;">✓</span>
                Earn 5% Advertisement Invite Commission
              </li>
              <li>
                <span class="feature-icon feature-check" style="background: rgba(251, 146, 60, 0.3); color: #fb923c;">✓</span>
                Unlimited earning potential
              </li>
              <li>
                <span class="feature-icon feature-check" style="background: rgba(251, 146, 60, 0.3); color: #fb923c;">✓</span>
                Priority ad placement
              </li>
            </ul>
            <div style="margin: 16px 0; padding: 14px; background: rgba(251, 146, 60, 0.15); border: 1px solid rgba(251, 146, 60, 0.3); border-radius: 12px;">
              <p style="margin: 0; font-size: 0.85rem; line-height: 1.6; color: rgba(216, 230, 255, 0.85);">
                <strong style="color: #fb923c;"></strong>Invite 100 users to buy 2000 likes or followers worth ₦10,000, you will earn ₦500 per user and a total whopping amount of <strong style="color: var(--page-mint);">₦50,000</strong> instantly & unlimited earnings.
              </p>
            </div>
            <?php if ($is_advertiser): ?>
              <button class="upgrade-btn current">Active Advertiser Plan</button>
            <?php else: ?>
              <!-- Added 'yearly' as the 4th parameter for plan_duration -->
              <button class="upgrade-btn premium" style="background: linear-gradient(135deg, #fb923c, #f97316); margin-top: 12px;" onclick="openCheckout('premium_plus_upgrade', <?php echo $senior_yearly_price; ?>, 'Premium Plus', 'yearly')">Continue to Premium Plus</button>
            <?php endif; ?>
          </article>
        </div>
      </section>

  <nav class="mobile-fintech-footer">
    
  <a href="dashboard.php">
    <svg viewBox="0 0 24 24"><path d="M12 3a9 9 0 1 1 0 18 9 9 0 0 1 0-18Zm1 4h-2v6h6v-2h-4V7Z"/></svg>
    <span>Dashboard</span>
  </a>

  <!-- Premium (crown icon) -->
  <a href="membership.php" class="active">
    <svg viewBox="0 0 24 24"><path d="M5 7l2.5 5 4.5-4 4.5 4L19 7l2 13H3l2-13Z"/></svg>
    <span>Premium</span>
  </a>

  <a href="post-task.php">
<svg viewBox="0 0 24 24" aria-hidden="true">
  <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8l-6-6Zm1 14h-3v3h-2v-3H7v-2h3v-3h2v3h3v2Zm-3-9V3.5L18.5 8H12Z"/>
</svg>
    
    <span>Post Advert </span>
  </a>
  
  

  <a href="history.php">
  <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
    <path d="M13 3a9 9 0 1 0 9 9h-2a7 7 0 1 1-7-7V3l4 4-4 4V7a5 5 0 1 0 5 5h2a7 7 0 1 1-7-7z"/>
  </svg>
  <span>History</span>
</a>


  <a href="profile.php">
    <svg viewBox="0 0 24 24"><path d="M12 2a6 6 0 0 1 6 6c0 3.31-2.69 6-6 6s-6-2.69-6-6a6 6 0 0 1 6-6Zm0 14c4.42 0 8 1.79 8 4v2H4v-2c0-2.21 3.58-4 8-4Z"/></svg>
    <span>Profile</span>
  </a>
</nav>

    </main>
  </div>


  <!-- Checkout Modal -->
  <div id="checkout-modal" class="checkout-modal">
    <div class="checkout-container">
      <div class="checkout-header">
        <h2>Checkout</h2>
        <button class="close-checkout" onclick="closeCheckout()">&times;</button>
      </div>
      
      <!-- Payment Gateway Selection Step -->
      <div id="gateway-selection-step" style="display: block;">
        <div class="order-summary" style="margin-bottom: 24px;">
          <h3>Order Summary</h3>
          <div class="order-item">
            <span>Item:</span>
            <span id="order-item-name-summary">-</span>
          </div>
          <div class="order-item">
            <span>Price:</span>
            <span id="order-item-price-summary">₦0.00</span>
          </div>
          <div class="order-item">
            <span>Total:</span>
            <span id="order-total-summary">₦0.00</span>
          </div>
        </div>

        <label style="display: block; margin-bottom: 16px; color: rgba(216, 230, 255, 0.9); font-size: 0.95rem; font-weight: 600;">Choose Payment Method</label>
        
        <div class="payment-gateway-selector">
          <!-- Kora Pay Option -->
          <div class="gateway-option" onclick="selectPaymentGateway('korapay', this)">
            <input type="radio" name="payment-gateway" value="korapay" id="gateway-korapay" style="display: none;" />
            <label for="gateway-korapay" style="cursor: pointer; user-select: none;">
              <div class="gateway-logo" style="color: #2563eb;"></div>
              <div style="font-weight: 600; color: var(--page-white); margin-bottom: 6px; font-size: 0.95rem;">Kora Pay</div>
              <div style="font-size: 0.75rem; color: rgba(216, 230, 255, 0.7);">
                <strong style="color: var(--page-mint);">RECOMMENDED</strong>
                <!-- <br>Instant bank transfer -->
              </div>
            </label>
          </div>

          <!-- Paystack Option -->
          <div class="gateway-option" onclick="selectPaymentGateway('paystack', this)">
            <input type="radio" name="payment-gateway" value="paystack" id="gateway-paystack" style="display: none;" />
            <label for="gateway-paystack" style="cursor: pointer; user-select: none;">
              <div class="gateway-logo" style="color: #5433ff;"></div>
              <div style="font-weight: 600; color: var(--page-white); margin-bottom: 6px; font-size: 0.95rem;">Paystack</div>
              <div style="font-size: 0.75rem; color: rgba(216, 230, 255, 0.7);">
                <!-- Cards & Wallets
                <br>Trusted payment platform -->
              </div>
            </label>
          </div>
        </div>

        <button type="button" class="proceed-btn" onclick="proceedWithGateway()" style="margin-top: 24px;">Proceed to Payment</button>
      </div>
    </div>
  </div>

  <script>
    let lastScrollTop = 0;
    const sidebar = document.getElementById('sidebar');

    window.addEventListener('scroll', function() {
      if (window.innerWidth <= 960) {
        let scrollTop = window.pageYOffset || document.documentElement.scrollTop;

        // Guard: only operate if sidebar exists
        if (sidebar) {
          if (scrollTop > lastScrollTop && scrollTop > 50) {
            sidebar.classList.add('scrolled');
          } else if (scrollTop < lastScrollTop) {
            sidebar.classList.remove('scrolled');
          }
        }

        lastScrollTop = scrollTop <= 0 ? 0 : scrollTop;
      }
    }, false);

    let currentOrderType = '';
    let currentAmount = 0;
    let currentItemName = '';
    let currentDepositPurpose = 'general'; // Default value
    let currentPlanDuration = 'yearly'; // Default to yearly
    let selectedPaymentGateway = 'korapay'; // Default to Kora Pay

    function openCheckout(orderType, amount, itemName, planDuration = 'yearly') {
      currentOrderType = orderType;
      currentAmount = amount;
      currentItemName = itemName;
      currentPlanDuration = planDuration; // Store plan duration
      selectedPaymentGateway = 'korapay'; // Reset to default
      
      // Update summary for both old and new IDs
      document.getElementById('order-item-name-summary').textContent = itemName;
      document.getElementById('order-item-price-summary').textContent = '₦' + amount.toLocaleString();
      document.getElementById('order-total-summary').textContent = '₦' + amount.toLocaleString();
      
      // Also update old IDs for backwards compatibility
      const oldNameElem = document.getElementById('order-item-name');
      const oldPriceElem = document.getElementById('order-item-price');
      const oldTotalElem = document.getElementById('order-total');
      if (oldNameElem) oldNameElem.textContent = itemName;
      if (oldPriceElem) oldPriceElem.textContent = '₦' + amount.toLocaleString();
      if (oldTotalElem) oldTotalElem.textContent = '₦' + amount.toLocaleString();
      
      // Clear previous selection and show gateway selection
      document.querySelectorAll('input[name="payment-gateway"]').forEach(el => el.checked = false);
      document.getElementById('checkout-modal').classList.add('active');
    }

    function selectPaymentGateway(gateway, clickedElem) {
      selectedPaymentGateway = gateway;
      const radio = document.getElementById('gateway-' + gateway);
      if (radio) radio.checked = true;

      // Update UI styling
      document.querySelectorAll('.gateway-option').forEach(el => el.classList.remove('selected'));

      if (clickedElem && typeof clickedElem.classList !== 'undefined') {
        clickedElem.classList.add('selected');
      } else {
        // Fallback: find the gateway-option that contains the radio
        const found = Array.from(document.querySelectorAll('.gateway-option')).find(el => el.querySelector('#gateway-' + gateway));
        if (found) found.classList.add('selected');
      }
    }

    function proceedWithGateway() {
      if (!selectedPaymentGateway) {
        alert('Please select a payment method');
        return;
      }
      
      if (selectedPaymentGateway === 'korapay') {
        proceedToKorapayPayment();
      } else if (selectedPaymentGateway === 'paystack') {
        proceedToPaystackPayment();
      }
    }

    function closeCheckout() {
      document.getElementById('checkout-modal').classList.remove('active');
    }

    function proceedToKorapayPayment() {
      // Show loader while we initialize KoraPay
      showLoadingIndicator('Initializing Kora Pay...');

      // Call Kora Pay API endpoint to initialize a checkout
      fetch('api/korapay-pay.php', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          payment_type: currentOrderType,
          amount: currentAmount,
          plan_duration: currentPlanDuration,
        })
      })
      .then(async response => {
        hideLoadingIndicator();
        const text = await response.text();
        let data = null;
        try {
          data = text ? JSON.parse(text) : null;
        } catch (e) {
          console.error('Failed to parse JSON from server. Raw response:', text);
          alert('Payment initialization failed (invalid server response). Check console for details.');
          return;
        }

        if (!response.ok) {
          console.error('Server returned HTTP', response.status, data);
          alert('Payment initialization failed: ' + (data && data.message ? data.message : 'Server error'));
          return;
        }

        if (data && data.status === true && data.checkout_url) {
          // Store reference for potential polling if redirect doesn't work
          const reference = data.reference || null;
          
          // Redirect to Korapay checkout URL (full page redirect, not iframe)
          // Korapay will redirect back to membership.php?reference=xxx after payment
          // BUT: if automatic redirect is not configured in Korapay dashboard,
          // we'll poll for payment status and redirect manually after 5 seconds
          if (reference) {
            // Start polling in background to catch the payment even if redirect fails
            pollKorapayStatus(reference, 5000);
          }
          
          window.location.href = data.checkout_url;
        } else {
          alert('Error: ' + (data && data.message ? data.message : 'Failed to initialize payment'));
        }
      })
      .catch(error => {
        hideLoadingIndicator();
        console.error('Network/Error:', error);
        alert('Payment initialization failed due to network error. See console for details.');
      });
    }

    // Fallback: poll for payment status if Korapay doesn't redirect automatically
    function pollKorapayStatus(reference, delayMs) {
      setTimeout(() => {
        // Poll the membership page with the reference to check payment status
        fetch('membership.php?check_payment=1&reference=' + encodeURIComponent(reference), {
          method: 'GET',
          credentials: 'same-origin'
        })
        .then(response => response.text())
        .then(text => {
          // If the response contains success indicator, redirect
          if (text.includes('success_message') || text.includes('Premium')) {
            // Payment was successful, redirect to membership page
            window.location.href = 'membership.php?reference=' + encodeURIComponent(reference);
          }
        })
        .catch(err => console.log('Poll check skipped:', err));
      }, delayMs);
    }

    // Open an inline modal with an iframe to host the KoraPay checkout page
    // Note: Now using full-page redirect instead of iframe, but keeping these as backup
    function openInlineCheckout(url) {
      // Redirect to checkout URL instead of opening iframe
      window.location.href = url;
    }

    function closeInlineCheckout() {
      // Not used with full-page redirect, but keeping for backwards compatibility
      const modal = document.getElementById('korapay-inline-modal');
      if (modal) {
        modal.classList.remove('active');
      }
    }

    function proceedToPaystackPayment() {
      // Close checkout modal
      closeCheckout();

      // Initiate Paystack payment directly
      initiatePaystackPayment();
    }

    function showLoadingIndicator(message = 'Processing...') {
      let loader = document.getElementById('payment-loader');
      if (!loader) {
        loader = document.createElement('div');
        loader.id = 'payment-loader';
        loader.style.cssText = `
          position: fixed;
          top: 0;
          left: 0;
          right: 0;
          bottom: 0;
          background: rgba(0, 0, 0, 0.7);
          display: flex;
          flex-direction: column;
          align-items: center;
          justify-content: center;
          z-index: 9999;
          color: white;
          font-size: 1.2rem;
        `;
        document.body.appendChild(loader);
      }
      loader.innerHTML = `
        <div style="display: flex; flex-direction: column; align-items: center; gap: 20px;">
          <div style="
            width: 50px;
            height: 50px;
            border: 4px solid rgba(255,255,255,0.3);
            border-top-color: white;
            border-radius: 50%;
            animation: spin 1s linear infinite;
          "></div>
          <div>${message}</div>
        </div>
        <style>
          @keyframes spin { to { transform: rotate(360deg); } }
        </style>
      `;
      loader.style.display = 'flex';
    }

    function hideLoadingIndicator() {
      const loader = document.getElementById('payment-loader');
      if (loader) {
        loader.style.display = 'none';
      }
    }

    function initiatePaystackPayment() {
      var handler = PaystackPop.setup({
        key: "<?php echo PAYSTACK_PUBLIC_KEY; ?>",
        email: "<?php echo htmlspecialchars($user_data['email']); ?>",
        amount: currentAmount * 100,
        currency: "NGN",
        ref: currentOrderType.toUpperCase() + "-" + Math.random().toString(36).substring(2, 15),
        metadata: {
          payment_type: currentOrderType,
          purpose: currentDepositPurpose || 'general',
          plan_duration: currentPlanDuration, // Added plan_duration to metadata
          user_id: <?php echo $user_id; ?>,
          custom_fields: [
            {
              display_name: "Customer Name",
              variable_name: "customer_name",
              value: "<?php echo htmlspecialchars($user_data['full_name']); ?>"
            }
          ]
        },
        callback: function(response) {
          window.location.href = "membership.php?status=success&reference=" + response.reference;
        },
        onClose: function() {
          console.log("Payment cancelled");
        }
      });
      handler.openIframe();
    }

    function initiateDeposit() {
      const amount = document.getElementById('deposit-amount').value;
      const purposeRadio = document.querySelector('input[name="deposit-purpose"]:checked');
      currentDepositPurpose = purposeRadio ? purposeRadio.value : 'general'; // Update global variable

      function showError(message) {
        let errorToast = document.getElementById("toast-error");
        if (!errorToast) {
          errorToast = document.createElement("div");
          errorToast.id = "toast-error";
          errorToast.className = "toast-message error";
          document.body.appendChild(errorToast);
        }
        errorToast.textContent = message;
        errorToast.classList.remove("show");
        setTimeout(() => errorToast.classList.add("show"), 50);
        setTimeout(() => errorToast.classList.remove("show"), 4000);
      }

      if (!amount || amount < 1000) {
        showError("Minimum Deposit is ₦1,000");
        return;
      }

      // Validate: Free users cannot deposit for games
      <?php if (!$is_premium): ?>
      if (currentDepositPurpose === 'games') {
        showError("Only Premium members can deposit for Games & Entertainment. Please upgrade to Premium first.");
        return;
      }
      <?php endif; ?>

      // Open checkout for deposit with purpose
      openCheckout('deposit', parseFloat(amount), 'Account Deposit - ' + getPurposeLabel(currentDepositPurpose));
    }

    function getPurposeLabel(purpose) {
      switch(purpose) {
        case 'ads': return 'Publish Advertisements';
        case 'games': return 'Games & Entertainment';
        case 'general': return 'General Balance';
        default: return 'General Balance';
      }
    }

  </script>

  <!-- Added interactive styling for deposit options -->
  <script>
document.addEventListener("DOMContentLoaded", () => {
  const successToast = document.getElementById("toast-success");
  const errorToast = document.getElementById("toast-error");

  function showToast(toast) {
    if (!toast) return;
    setTimeout(() => toast.classList.add("show"), 100);
    setTimeout(() => toast.classList.remove("show"), 4000);
  }

  showToast(successToast);
  showToast(errorToast);
  
  // Add interactive styling for deposit options
  const depositOptions = document.querySelectorAll('.deposit-option');
  depositOptions.forEach(option => {
    option.addEventListener('click', function() {
      // Remove active state from all options
      depositOptions.forEach(opt => {
        opt.style.borderColor = 'rgba(86, 139, 241, 0.3)';
        opt.style.background = 'rgba(13, 24, 62, 0.4)';
      });
      
      // Add active state to clicked option
      this.style.borderColor = 'rgba(77, 225, 193, 0.6)';
      this.style.background = 'rgba(77, 225, 193, 0.1)';
      
      // Check the radio button
      const radio = this.querySelector('input[type="radio"]');
      if (radio && !radio.disabled) {
        radio.checked = true;
      }
    });
  });
  
  // Set initial active state for checked radio
  const checkedRadio = document.querySelector('input[name="deposit-purpose"]:checked');
  if (checkedRadio) {
    const activeOption = checkedRadio.closest('.deposit-option');
    if (activeOption) {
      activeOption.style.borderColor = 'rgba(77, 225, 193, 0.6)';
      activeOption.style.background = 'rgba(77, 225, 193, 0.1)';
    }
  }
});
</script>
</body>
</html>
