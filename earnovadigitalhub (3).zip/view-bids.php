<?php
session_start();
require_once 'config/database.php';
require_once 'includes/email.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$user_id = $_SESSION['user_id'];

// Get user info
$stmt = $conn->prepare("SELECT username, advertiser_plan FROM users WHERE id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();

// Check if user is a Senior Advertiser
$is_senior_advertiser = ($user['advertiser_plan'] === 'senior');

if (!$is_senior_advertiser) {
    $_SESSION['error'] = "Only Senior Advertisers can view bids.";
    header('Location: dashboard.php');
    exit();
}

// Handle bid actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action']) && isset($_POST['bid_id'])) {
        $bid_id = intval($_POST['bid_id']);
        $action = $_POST['action'];
        
        // Verify the bid belongs to a job owned by this user
        $verify_stmt = $conn->prepare("
            SELECT jb.*, j.title as job_title, j.created_by, u.username, u.email 
            FROM job_bids jb 
            JOIN jobs j ON jb.job_id = j.id 
            JOIN users u ON jb.user_id = u.id
            WHERE jb.id = ? AND j.created_by = ?
        ");
        $verify_stmt->bind_param("ii", $bid_id, $user_id);
        $verify_stmt->execute();
        $bid_data = $verify_stmt->get_result()->fetch_assoc();
        
        if ($bid_data) {
            if ($action === 'accept') {
                // Update bid status to accepted
                $update_stmt = $conn->prepare("UPDATE job_bids SET bid_status = 'accepted', updated_at = NOW() WHERE id = ?");
                $update_stmt->bind_param("i", $bid_id);
                
                if ($update_stmt->execute()) {
                    // Send email to bidder
                    $email_subject = "Your Bid Has Been Accepted!";
                    $email_body = "
                        <h2>Congratulations!</h2>
                        <p>Your bid on the job '<strong>{$bid_data['job_title']}</strong>' has been accepted.</p>
                        <p>The job owner will contact you soon to discuss the next steps.</p>
                        <p>Thank you for using FlowEarner!</p>
                    ";
                    sendEmail($bid_data['email'], $bid_data['username'], $email_subject, $email_body);
                    
                    $_SESSION['success'] = "Bid accepted successfully! The bidder has been notified.";
                } else {
                    $_SESSION['error'] = "Failed to accept bid. Please try again.";
                }
            } elseif ($action === 'reject') {
                // Update bid status to rejected
                $update_stmt = $conn->prepare("UPDATE job_bids SET bid_status = 'rejected', updated_at = NOW() WHERE id = ?");
                $update_stmt->bind_param("i", $bid_id);
                
                if ($update_stmt->execute()) {
                    // Send email to bidder
                    $email_subject = "Bid Status Update";
                    $email_body = "
                        <h2>Bid Status Update</h2>
                        <p>Thank you for your interest in the job '<strong>{$bid_data['job_title']}</strong>'.</p>
                        <p>Unfortunately, your bid was not selected this time.</p>
                        <p>Keep exploring more opportunities on FlowEarner!</p>
                    ";
                    sendEmail($bid_data['email'], $bid_data['username'], $email_subject, $email_body);
                    
                    $_SESSION['success'] = "Bid rejected. The bidder has been notified.";
                } else {
                    $_SESSION['error'] = "Failed to reject bid. Please try again.";
                }
            }
        } else {
            $_SESSION['error'] = "Invalid bid or unauthorized access.";
        }
        
        header('Location: view-bids.php');
        exit();
    }
}

// Get all jobs posted by this user with bid counts
$jobs_query = "
    SELECT j.*, 
           COUNT(jb.id) as total_bids,
           SUM(CASE WHEN jb.bid_status = 'pending' THEN 1 ELSE 0 END) as pending_bids,
           SUM(CASE WHEN jb.bid_status = 'accepted' THEN 1 ELSE 0 END) as accepted_bids
    FROM jobs j
    LEFT JOIN job_bids jb ON j.id = jb.job_id
    WHERE j.created_by = ?
    GROUP BY j.id
    ORDER BY j.created_at DESC
";
$jobs_stmt = $conn->prepare($jobs_query);
$jobs_stmt->bind_param("i", $user_id);
$jobs_stmt->execute();
$jobs = $jobs_stmt->get_result();

// Get selected job ID from URL
$selected_job_id = isset($_GET['job_id']) ? intval($_GET['job_id']) : null;

// Get bids for selected job
$bids = [];
if ($selected_job_id) {
    $bids_query = "
        SELECT jb.*, u.username, u.email, u.career1, u.career2
        FROM job_bids jb
        JOIN users u ON jb.user_id = u.id
        JOIN jobs j ON jb.job_id = j.id
        WHERE jb.job_id = ? AND j.created_by = ?
        ORDER BY jb.created_at DESC
    ";
    $bids_stmt = $conn->prepare($bids_query);
    $bids_stmt->bind_param("ii", $selected_job_id, $user_id);
    $bids_stmt->execute();
    $bids = $bids_stmt->get_result();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Bids - FlowEarner</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        :root {
            --page-purple: #8b5cf6;
            --page-blue: #3b82f6;
            --page-mint: #10b981;
            --page-orange: #f59e0b;
            --page-red: #ef4444;
            --page-dark: #1e1b4b;
            --page-light: #f8fafc;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px;
            padding-bottom: 80px;
        }

        .container {
            max-width: 1400px;
            margin: 0 auto;
        }

        .page-header {
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(10px);
            border-radius: 15px;
            padding: 20px;
            margin-bottom: 20px;
            border: 1px solid rgba(255, 255, 255, 0.2);
        }

        .page-header h1 {
            color: white;
            font-size: 1.8rem;
            margin-bottom: 5px;
        }

        .page-header p {
            color: rgba(255, 255, 255, 0.8);
            font-size: 0.95rem;
        }

        .toast {
            position: fixed;
            top: 20px;
            right: 20px;
            padding: 15px 20px;
            border-radius: 10px;
            color: white;
            font-weight: 500;
            z-index: 1000;
            animation: slideIn 0.3s ease-out;
            max-width: 400px;
        }

        .toast.success {
            background: var(--page-mint);
        }

        .toast.error {
            background: var(--page-red);
        }

        @keyframes slideIn {
            from {
                transform: translateX(400px);
                opacity: 0;
            }
            to {
                transform: translateX(0);
                opacity: 1;
            }
        }

        .content-grid {
            display: grid;
            grid-template-columns: 350px 1fr;
            gap: 20px;
        }

        .jobs-sidebar {
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(10px);
            border-radius: 15px;
            padding: 20px;
            border: 1px solid rgba(255, 255, 255, 0.2);
            height: fit-content;
            max-height: calc(100vh - 200px);
            overflow-y: auto;
        }

        .jobs-sidebar h2 {
            color: white;
            font-size: 1.3rem;
            margin-bottom: 15px;
        }

        .job-item {
            background: rgba(255, 255, 255, 0.05);
            border-radius: 10px;
            padding: 15px;
            margin-bottom: 10px;
            cursor: pointer;
            transition: all 0.3s ease;
            border: 2px solid transparent;
        }

        .job-item:hover {
            background: rgba(255, 255, 255, 0.1);
            transform: translateX(5px);
        }

        .job-item.active {
            background: rgba(255, 255, 255, 0.15);
            border-color: var(--page-mint);
        }

        .job-item h3 {
            color: white;
            font-size: 1rem;
            margin-bottom: 8px;
        }

        .job-item .job-meta {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-top: 10px;
        }

        .job-item .bid-count {
            background: var(--page-mint);
            color: white;
            padding: 4px 10px;
            border-radius: 20px;
            font-size: 0.85rem;
            font-weight: 600;
        }

        .job-item .job-status {
            color: rgba(255, 255, 255, 0.7);
            font-size: 0.85rem;
        }

        .bids-content {
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(10px);
            border-radius: 15px;
            padding: 25px;
            border: 1px solid rgba(255, 255, 255, 0.2);
        }

        .empty-state {
            text-align: center;
            padding: 60px 20px;
            color: rgba(255, 255, 255, 0.7);
        }

        .empty-state i {
            font-size: 4rem;
            margin-bottom: 20px;
            opacity: 0.5;
        }

        .empty-state h3 {
            color: white;
            font-size: 1.5rem;
            margin-bottom: 10px;
        }

        .bid-card {
            background: rgba(255, 255, 255, 0.05);
            border-radius: 12px;
            padding: 20px;
            margin-bottom: 15px;
            border: 1px solid rgba(255, 255, 255, 0.1);
        }

        .bid-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 15px;
        }

        .bidder-info {
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .bidder-avatar {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            background: linear-gradient(135deg, var(--page-purple), var(--page-blue));
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: 600;
            font-size: 1.2rem;
        }

        .bidder-details h4 {
            color: white;
            font-size: 1.1rem;
            margin-bottom: 3px;
        }

        .bidder-details .career-tags {
            display: flex;
            gap: 5px;
        }

        .career-tag {
            background: rgba(139, 92, 246, 0.3);
            color: white;
            padding: 2px 8px;
            border-radius: 12px;
            font-size: 0.75rem;
        }

        .bid-status {
            padding: 6px 15px;
            border-radius: 20px;
            font-size: 0.85rem;
            font-weight: 600;
        }

        .bid-status.pending {
            background: var(--page-orange);
            color: white;
        }

        .bid-status.accepted {
            background: var(--page-mint);
            color: white;
        }

        .bid-status.rejected {
            background: var(--page-red);
            color: white;
        }

        .bid-body {
            color: rgba(255, 255, 255, 0.9);
            line-height: 1.6;
            margin-bottom: 15px;
        }

        .bid-body h5 {
            color: white;
            margin-bottom: 8px;
            font-size: 0.95rem;
        }

        .bid-footer {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding-top: 15px;
            border-top: 1px solid rgba(255, 255, 255, 0.1);
        }

        .bid-meta {
            color: rgba(255, 255, 255, 0.7);
            font-size: 0.9rem;
        }

        .bid-meta strong {
            color: var(--page-mint);
            font-size: 1.1rem;
        }

        .bid-actions {
            display: flex;
            gap: 10px;
        }

        .btn {
            padding: 10px 20px;
            border: none;
            border-radius: 8px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            font-size: 0.9rem;
        }

        .btn-accept {
            background: var(--page-mint);
            color: white;
        }

        .btn-accept:hover {
            background: #059669;
            transform: translateY(-2px);
        }

        .btn-reject {
            background: var(--page-red);
            color: white;
        }

        .btn-reject:hover {
            background: #dc2626;
            transform: translateY(-2px);
        }

        .btn:disabled {
            opacity: 0.5;
            cursor: not-allowed;
        }

        .mobile-footer {
            position: fixed;
            bottom: 0;
            left: 0;
            right: 0;
            background: rgba(30, 27, 75, 0.95);
            backdrop-filter: blur(10px);
            padding: 12px 0;
            display: flex;
            justify-content: space-around;
            align-items: center;
            z-index: 100;
            border-top: 1px solid rgba(255, 255, 255, 0.1);
        }

        .mobile-footer a {
            color: rgba(255, 255, 255, 0.6);
            text-decoration: none;
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 4px;
            font-size: 0.75rem;
            transition: all 0.3s ease;
        }

        .mobile-footer a i {
            font-size: 1.3rem;
        }

        .mobile-footer a.active,
        .mobile-footer a:hover {
            color: var(--page-mint);
        }

        @media (max-width: 968px) {
            .content-grid {
                grid-template-columns: 1fr;
            }

            .jobs-sidebar {
                max-height: 400px;
            }
        }

        @media (max-width: 768px) {
            body {
                padding: 15px;
                padding-bottom: 80px;
            }

            .page-header h1 {
                font-size: 1.5rem;
            }

            .bid-header {
                flex-direction: column;
                align-items: flex-start;
                gap: 10px;
            }

            .bid-footer {
                flex-direction: column;
                gap: 15px;
                align-items: flex-start;
            }

            .bid-actions {
                width: 100%;
            }

            .btn {
                flex: 1;
            }
        }
    </style>
</head>
<body>
    <?php if (isset($_SESSION['success'])): ?>
        <div class="toast success">
            <i class="fas fa-check-circle"></i> <?php echo $_SESSION['success']; unset($_SESSION['success']); ?>
        </div>
    <?php endif; ?>

    <?php if (isset($_SESSION['error'])): ?>
        <div class="toast error">
            <i class="fas fa-exclamation-circle"></i> <?php echo $_SESSION['error']; unset($_SESSION['error']); ?>
        </div>
    <?php endif; ?>

    <div class="container">
        <div class="page-header">
            <h1><i class="fas fa-briefcase"></i> Manage Job Bids</h1>
            <p>Review and manage bids on your posted jobs</p>
        </div>

        <div class="content-grid">
            <div class="jobs-sidebar">
                <h2>Your Jobs</h2>
                <?php if ($jobs->num_rows > 0): ?>
                    <?php while ($job = $jobs->fetch_assoc()): ?>
                        <a href="?job_id=<?php echo $job['id']; ?>" style="text-decoration: none;">
                            <div class="job-item <?php echo ($selected_job_id == $job['id']) ? 'active' : ''; ?>">
                                <h3><?php echo htmlspecialchars($job['title']); ?></h3>
                                <div class="job-meta">
                                    <span class="bid-count">
                                        <i class="fas fa-users"></i> <?php echo $job['total_bids']; ?> Bids
                                    </span>
                                    <span class="job-status">
                                        <?php if ($job['status'] === 'approved'): ?>
                                            <i class="fas fa-check-circle" style="color: var(--page-mint);"></i> Active
                                        <?php else: ?>
                                            <i class="fas fa-clock" style="color: var(--page-orange);"></i> Pending
                                        <?php endif; ?>
                                    </span>
                                </div>
                                <?php if ($job['pending_bids'] > 0): ?>
                                    <div style="margin-top: 8px; color: var(--page-orange); font-size: 0.85rem;">
                                        <i class="fas fa-bell"></i> <?php echo $job['pending_bids']; ?> new bid(s)
                                    </div>
                                <?php endif; ?>
                            </div>
                        </a>
                    <?php endwhile; ?>
                <?php else: ?>
                    <div class="empty-state">
                        <i class="fas fa-briefcase"></i>
                        <p>No jobs posted yet</p>
                    </div>
                <?php endif; ?>
            </div>

            <div class="bids-content">
                <?php if ($selected_job_id && $bids->num_rows > 0): ?>
                    <?php while ($bid = $bids->fetch_assoc()): ?>
                        <div class="bid-card">
                            <div class="bid-header">
                                <div class="bidder-info">
                                    <div class="bidder-avatar">
                                        <?php echo strtoupper(substr($bid['username'], 0, 1)); ?>
                                    </div>
                                    <div class="bidder-details">
                                        <h4><?php echo htmlspecialchars($bid['username']); ?></h4>
                                        <div class="career-tags">
                                            <?php if ($bid['career1']): ?>
                                                <span class="career-tag"><?php echo htmlspecialchars($bid['career1']); ?></span>
                                            <?php endif; ?>
                                            <?php if ($bid['career2']): ?>
                                                <span class="career-tag"><?php echo htmlspecialchars($bid['career2']); ?></span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                                <span class="bid-status <?php echo $bid['bid_status']; ?>">
                                    <?php echo ucfirst($bid['bid_status']); ?>
                                </span>
                            </div>

                            <div class="bid-body">
                                <h5>Cover Letter:</h5>
                                <p><?php echo nl2br(htmlspecialchars($bid['cover_letter'])); ?></p>
                            </div>

                            <div class="bid-footer">
                                <div class="bid-meta">
                                    Proposed Rate: <strong>₦<?php echo number_format($bid['proposed_rate'], 2); ?></strong>
                                    <br>
                                    <small>Bid placed on <?php echo date('M d, Y', strtotime($bid['created_at'])); ?></small>
                                </div>

                                <?php if ($bid['bid_status'] === 'pending'): ?>
                                    <div class="bid-actions">
                                        <form method="POST" style="display: inline;">
                                            <input type="hidden" name="bid_id" value="<?php echo $bid['id']; ?>">
                                            <input type="hidden" name="action" value="accept">
                                            <button type="submit" class="btn btn-accept">
                                                <i class="fas fa-check"></i> Accept
                                            </button>
                                        </form>
                                        <form method="POST" style="display: inline;">
                                            <input type="hidden" name="bid_id" value="<?php echo $bid['id']; ?>">
                                            <input type="hidden" name="action" value="reject">
                                            <button type="submit" class="btn btn-reject">
                                                <i class="fas fa-times"></i> Reject
                                            </button>
                                        </form>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php endwhile; ?>
                <?php elseif ($selected_job_id): ?>
                    <div class="empty-state">
                        <i class="fas fa-inbox"></i>
                        <h3>No Bids Yet</h3>
                        <p>This job hasn't received any bids yet. Check back later!</p>
                    </div>
                <?php else: ?>
                    <div class="empty-state">
                        <i class="fas fa-hand-pointer"></i>
                        <h3>Select a Job</h3>
                        <p>Choose a job from the sidebar to view its bids</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <div class="mobile-footer">
        <a href="dashboard.php">
            <i class="fas fa-home"></i>
            <span>Home</span>
        </a>
        <a href="perform-task.php">
            <i class="fas fa-tasks"></i>
            <span>Tasks</span>
        </a>
        <a href="find-jobs.php">
            <i class="fas fa-briefcase"></i>
            <span>Jobs</span>
        </a>
        <a href="view-bids.php" class="active">
            <i class="fas fa-eye"></i>
            <span>Bids</span>
        </a>
        <a href="profile.php">
            <i class="fas fa-user"></i>
            <span>Profile</span>
        </a>
    </div>

    <script>
        // Auto-hide toast after 5 seconds
        setTimeout(() => {
            const toast = document.querySelector('.toast');
            if (toast) {
                toast.style.animation = 'slideIn 0.3s ease-out reverse';
                setTimeout(() => toast.remove(), 300);
            }
        }, 5000);
    </script>
</body>
</html>
