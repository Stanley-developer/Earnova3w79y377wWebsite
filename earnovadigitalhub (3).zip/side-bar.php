<?php
// side-bar.php - Enhanced fintech sidebar with page detection, dropdowns, and logout
// Detect current page to highlight active menu item
$current_page = basename($_SERVER['PHP_SELF']);

// Define menu items with grouping for dropdowns
$menu_items = array(
  array('name' => 'Perform Task', 'file' => 'perform-task.php', 'icon' => 'M9 11l3 3L22 4l-1.41-1.41L12 10.17 10.41 8.59 9 10l-3.59-3.59L4 8l5 5zM19 19H5v-2h14v2zm0-4H5v-2h14v2z', 'color' => '#FF6B6B'),
  array('name' => 'Post Task', 'file' => 'post-task.php', 'icon' => 'M12 4v7H5v2h7v7h2v-7h7v-2h-7V4h-2z', 'color' => '#4ECDC4'),
  array('name' => 'My Tasks', 'file' => 'my-posted-task.php', 'icon' => 'M9 11H7v2h2v-2zm0-4H7v2h2V7zm0 8H7v2h2v-2zm10-8H11v2h8V7zm0 4H11v2h8v-2zm0 4H11v2h8v-2zM4 3h16a1 1 0 0 1 1 1v16a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1z', 'color' => '#FFD93D'),
);

$earn_items = array(
  array('name' => 'Chat & Earn', 'file' => 'chat-earn.php', 'icon' => 'M20 2H4a2 2 0 0 0-2 2v18l4-4h14a2 2 0 0 0 2-2V4a2 2 0 0 0-2-2z', 'color' => '#6BCB77'),
  array('name' => 'Watch & Earn', 'file' => 'watch-earn.php', 'icon' => 'M10 16.5l6-4.5-6-4.5v9zM21 3H3a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h18a2 2 0 0 0 2-2V5a2 2 0 0 0-2-2z', 'color' => '#A78BFA'),
  array('name' => 'Stream & Earn', 'file' => 'stream-earn.php', 'icon' => 'M4 5h16a1 1 0 0 1 1 1v12a1 1 0 0 1-1.6.8L13 15v3H4a1 1 0 0 1-1-1V6a1 1 0 0 1 1-1z', 'color' => '#F87171'),
  array('name' => 'Play & Earn', 'file' => 'play-earn.php', 'icon' => 'M21 16.5V7.5a1.5 1.5 0 0 0-2.25-1.3l-8.25 4.5a1.5 1.5 0 0 0 0 2.6l8.25 4.5A1.5 1.5 0 0 0 21 16.5zM4 8h2v8H4V8zm3 2h2v4H7v-4z', 'color' => '#34D399'),
);

$account_items = array(
  array('name' => 'Dashboard', 'file' => 'dashboard.php', 'icon' => 'M12 3a9 9 0 1 1 0 18 9 9 0 0 1 0-18Zm1 4h-2v6h6v-2h-4V7Z', 'color' => '#60A5FA'),
  array('name' => 'Withdrawal', 'file' => 'withdrawal.php', 'icon' => 'M12 1L8 5h3v9h2V5h3l-4-4zm-7 18v2h14v-2H5z', 'color' => '#FB7185'),
  array('name' => 'Premium', 'file' => 'membership.php', 'icon' => 'M5 7l2.5 5 4.5-4 4.5 4L19 7l2 13H3l2-13Z', 'color' => '#FBBF24'),
  array('name' => 'Rewards', 'file' => 'daily-rewards.php', 'icon' => 'M20 3H4a1 1 0 0 0-1 1v16l5-3 5 3 5-3 5 3V4a1 1 0 0 0-1-1Zm-2 5-6.7 6.7L7 10.4l1.4-1.4 2.9 2.9L17.6 6 18 8Z', 'color' => '#A78BFA'),
);

$community_items = array(
  array('name' => 'Skill Require', 'file' => 'skill-require.php', 'icon' => 'M12 2a10 10 0 0 0-10 10 9.9 9.9 0 0 0 5.7 9L8 21a8 8 0 1 1 8 0l.3.9A9.9 9.9 0 0 0 22 12 10 10 0 0 0 12 2Zm-1 5h2v6h-2Zm0 8h2v2h-2Z', 'color' => '#14B8A6'),
  array('name' => 'My Invites', 'file' => 'referrals.php', 'icon' => 'M12 12a4 4 0 1 0-4-4 4 4 0 0 0 4 4Zm0 2c-4 0-8 2-8 5v1h16v-1c0-3-4-5-8-5zM18 10a3 3 0 1 0-3 3 3 3 0 0 0 3-3Zm-1 6a5 5 0 0 1 4 2.5v1.5h-4v-1.3a6.8 6.8 0 0 0-1.2-2.2A7.9 7.9 0 0 1 18 14Z', 'color' => '#F59E0B'),
);

$other_items = array(
  array('name' => 'Deposit', 'file' => 'membership.php', 'icon' => 'M12 2 2 7v2h20V7L12 2zM4 10v10h2v-8h2v8h2v-8h4v8h2v-8h2v8h2V10H4zM2 22h20v-2H2v2z', 'color' => '#0EA5E9'),
  array('name' => 'History', 'file' => 'history.php', 'icon' => 'M13 3a9 9 0 1 0 9 9h-2a7 7 0 1 1-7-7V3l4 4-4 4V7a5 5 0 1 0 5 5h2a7 7 0 1 1-7-7z', 'color' => '#8B5CF6'),
  array('name' => 'Profile', 'file' => 'profile.php', 'icon' => 'M12 2a6 6 0 0 1 6 6c0 3.31-2.69 6-6 6s-6-2.69-6-6a6 6 0 0 1 6-6Zm0 14c4.42 0 8 1.79 8 4v2H4v-2c0-2.21 3.58-4 8-4Z', 'color' => '#06B6D4'),
);
?>

<style>
  /* Import Poppins font */
  @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap');

  /* Sidebar Container - enhanced for all screens with dropdown support */
  .laptop-sidebar-container {
    display: block;
  }

  /* Hamburger button */
  .hamburger-btn {
    position: fixed;
    top: 20px;
    left: 20px;
    z-index: 9999;
    width: 50px;
    height: 50px;
    background: linear-gradient(135deg, rgba(44, 91, 245, 0.9), rgba(26, 58, 171, 0.8));
    border: 1px solid rgba(44, 91, 245, 0.5);
    border-radius: 12px;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    gap: 5px;
    cursor: pointer;
    transition: all 0.3s ease;
    box-shadow: 0 4px 15px rgba(44, 91, 245, 0.4);
  }

  .hamburger-btn:hover {
    transform: scale(1.05);
    box-shadow: 0 6px 20px rgba(44, 91, 245, 0.6);
  }

  .hamburger-btn span {
    width: 24px;
    height: 3px;
    background: #fff;
    border-radius: 2px;
    transition: all 0.3s ease;
  }

  .hamburger-btn.active span:nth-child(1) {
    transform: rotate(45deg) translate(7px, 7px);
  }

  .hamburger-btn.active span:nth-child(2) {
    opacity: 0;
  }

  .hamburger-btn.active span:nth-child(3) {
    transform: rotate(-45deg) translate(7px, -7px);
  }

  /* Sidebar overlay */
  .sidebar-overlay {
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: rgba(3, 9, 34, 0.8);
    backdrop-filter: blur(5px);
    opacity: 0;
    visibility: hidden;
    transition: all 0.3s ease;
    z-index: 9998;
    cursor: pointer;
  }

  .sidebar-overlay.active {
    opacity: 1;
    visibility: visible;
  }

  /* Sidebar panel with improved styling */
  .sidebar-panel {
    position: fixed;
    top: 0;
    left: 0;
    bottom: 0;
    width: 280px;
    background: linear-gradient(180deg, rgba(13, 24, 62, 0.98), rgba(8, 18, 52, 0.98));
    backdrop-filter: blur(20px);
    border-right: 1px solid rgba(86, 139, 241, 0.28);
    box-shadow: 4px 0 30px rgba(4, 10, 36, 0.7);
    transform: translateX(-100%);
    transition: transform 0.4s cubic-bezier(0.19, 1, 0.22, 1);
    z-index: 9999;
    overflow-y: auto;
    display: flex;
    flex-direction: column;
  }

  .sidebar-panel.active {
    transform: translateX(0);
  }

  /* Sidebar header with logo image and close icon */
  .sidebar-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 20px;
    border-bottom: 1px solid rgba(86, 139, 241, 0.2);
    flex-shrink: 0;
  }

  .sidebar-logo {
    font-size: 1.3rem;
    font-weight: 700;
    color: #fff;
    letter-spacing: 0.05em;
    display: flex;
    align-items: center;
    gap: 8px;
  }

.sidebar-logo img {
  width: 32px;
  height: 32px;
  object-fit: contain;
  transform: scale(1.5) translateY(1px);
  transform-origin: center;
}


  .sidebar-close-btn {
    background: none;
    border: none;
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 4px;
    color: rgba(205, 219, 255, 0.7);
    transition: color 0.3s ease;
  }

  .sidebar-close-btn:hover {
    color: #fff;
  }

  .sidebar-close-btn svg {
    width: 24px;
    height: 24px;
  }

  /* Menu sections with dropdown functionality */
  .sidebar-menu-section {
    padding: 8px 0;
  }

  .sidebar-section-toggle {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 12px 16px;
    background: none;
    border: none;
    cursor: pointer;
    width: 100%;
    color: rgba(205, 219, 255, 0.75);
    font-family: 'Poppins', sans-serif;
    font-size: 0.85rem;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 0.05em;
    transition: all 0.3s ease;
  }

  .sidebar-section-toggle:hover {
    color: #fff;
    background: rgba(44, 92, 240, 0.1);
  }

  .sidebar-section-toggle svg {
    width: 16px;
    height: 16px;
    transition: transform 0.3s ease;
  }

  .sidebar-section-toggle.active svg {
    transform: rotate(180deg);
  }

  .sidebar-section-items {
    max-height: 0;
    overflow: hidden;
    transition: max-height 0.3s ease;
  }

  .sidebar-section-items.active {
    max-height: 500px;
  }

  /* Simple menu list with Poppins font */
  .sidebar-menu-list {
    display: flex;
    flex-direction: column;
    padding: 16px 0;
    flex: 1;
    font-family: 'Poppins', sans-serif;
  }

  /* Menu items with individual icon colors and improved active state */
  .sidebar-menu-item {
    display: flex;
    align-items: center;
    gap: 12px;
    padding: 12px 16px;
    text-decoration: none;
    color: rgba(205, 219, 255, 0.85);
    font-family: 'Poppins', sans-serif;
    font-size: 0.9rem;
    font-weight: 500;
    transition: all 0.3s ease;
    border-left: 3px solid transparent;
    position: relative;
  }

  .sidebar-menu-item.active {
    background: linear-gradient(90deg, rgba(77, 225, 193, 0.15), transparent);
    color: #fff;
    border-left-color: #4de1c1;
    padding-left: 20px;
  }

  .sidebar-menu-item:hover {
    background: rgba(44, 92, 240, 0.1);
    color: #fff;
    border-left-color: #4de1c1;
    padding-left: 20px;
  }

  .sidebar-menu-item svg {
    width: 20px;
    height: 20px;
    flex-shrink: 0;
    fill: currentColor;
  }

  .sidebar-menu-item span {
    font-size: 0.9rem;
    font-weight: 500;
  }

  /* Logout section at bottom */
  .sidebar-logout-section {
    padding: 16px 0;
    border-top: 1px solid rgba(86, 139, 241, 0.2);
    margin-top: auto;
    flex-shrink: 0;
  }

  .sidebar-logout-btn {
    display: flex;
    align-items: center;
    gap: 12px;
    padding: 12px 16px;
    background: linear-gradient(135deg, rgba(255, 77, 77, 0.15), rgba(255, 51, 102, 0.1));
    border: 1px solid rgba(255, 77, 77, 0.3);
    border-radius: 8px;
    margin: 0 8px;
    color: #FF6B6B;
    font-family: 'Poppins', sans-serif;
    font-size: 0.9rem;
    font-weight: 600;
    cursor: pointer;
    transition: all 0.3s ease;
    width: calc(100% - 16px);
  }

  .sidebar-logout-btn:hover {
    background: linear-gradient(135deg, rgba(255, 77, 77, 0.25), rgba(255, 51, 102, 0.2));
    border-color: rgba(255, 77, 77, 0.5);
    transform: translateY(-2px);
  }

  .sidebar-logout-btn svg {
    width: 18px;
    height: 18px;
    fill: currentColor;
  }

  /* Add body lock styles to prevent scrolling when sidebar is open */
  body.sidebar-open {
    overflow: hidden;
    height: 100vh;
  }
</style>

<!-- Sidebar Container -->
<div class="laptop-sidebar-container">
  <!-- Hamburger Button -->
  <div class="hamburger-btn" id="hamburgerBtn">
    <span></span>
    <span></span>
    <span></span>
  </div>

  <!-- Sidebar Overlay -->
  <div class="sidebar-overlay" id="sidebarOverlay"></div>

  <!-- Enhanced Sidebar Panel with logo and dropdown sections -->
  <div class="sidebar-panel" id="sidebarPanel">
    <!-- Logo and Close Icon Header -->
    <div class="sidebar-header">
      <div class="sidebar-logo">
        <img src="logo.png" alt="Earnova Logo">
        <span style="display: none;">Earnova</span>
      </div>
      <button class="sidebar-close-btn" id="sidebarCloseBtn">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <line x1="18" y1="6" x2="6" y2="18"></line>
          <line x1="6" y1="6" x2="18" y2="18"></line>
        </svg>
      </button>
    </div>

    <!-- Menu List with Sections -->
    <div class="sidebar-menu-list">
      <!-- Main Tasks Section -->
      <div class="sidebar-menu-section">
        <button class="sidebar-section-toggle active" onclick="toggleSection(this)">
          Tasks
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <polyline points="6 9 12 15 18 9"></polyline>
          </svg>
        </button>
        <div class="sidebar-section-items active">
          <?php foreach($menu_items as $item): ?>
            <a href="<?php echo $item['file']; ?>" class="sidebar-menu-item <?php echo ($current_page === $item['file']) ? 'active' : ''; ?>">
              <svg viewBox="0 0 24 24" style="color: <?php echo $item['color']; ?>"><path d="<?php echo $item['icon']; ?>"/></svg>
              <span><?php echo $item['name']; ?></span>
            </a>
          <?php endforeach; ?>
        </div>
      </div>

      <!-- Earn Section with Dropdown -->
      <div class="sidebar-menu-section">
        <button class="sidebar-section-toggle" onclick="toggleSection(this)">
          Earn
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <polyline points="6 9 12 15 18 9"></polyline>
          </svg>
        </button>
        <div class="sidebar-section-items">
          <?php foreach($earn_items as $item): ?>
            <a href="<?php echo $item['file']; ?>" class="sidebar-menu-item <?php echo ($current_page === $item['file']) ? 'active' : ''; ?>">
              <svg viewBox="0 0 24 24" style="color: <?php echo $item['color']; ?>"><path d="<?php echo $item['icon']; ?>"/></svg>
              <span><?php echo $item['name']; ?></span>
            </a>
          <?php endforeach; ?>
        </div>
      </div>

      <!-- Account Section with Dropdown -->
      <div class="sidebar-menu-section">
        <button class="sidebar-section-toggle" onclick="toggleSection(this)">
          Account
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <polyline points="6 9 12 15 18 9"></polyline>
          </svg>
        </button>
        <div class="sidebar-section-items">
          <?php foreach($account_items as $item): ?>
            <a href="<?php echo $item['file']; ?>" class="sidebar-menu-item <?php echo ($current_page === $item['file']) ? 'active' : ''; ?>">
              <svg viewBox="0 0 24 24" style="color: <?php echo $item['color']; ?>"><path d="<?php echo $item['icon']; ?>"/></svg>
              <span><?php echo $item['name']; ?></span>
            </a>
          <?php endforeach; ?>
        </div>
      </div>

      <!-- Community Section with Dropdown -->
      <div class="sidebar-menu-section">
        <button class="sidebar-section-toggle" onclick="toggleSection(this)">
          Community
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <polyline points="6 9 12 15 18 9"></polyline>
          </svg>
        </button>
        <div class="sidebar-section-items">
          <?php foreach($community_items as $item): ?>
            <a href="<?php echo $item['file']; ?>" class="sidebar-menu-item <?php echo ($current_page === $item['file']) ? 'active' : ''; ?>">
              <svg viewBox="0 0 24 24" style="color: <?php echo $item['color']; ?>"><path d="<?php echo $item['icon']; ?>"/></svg>
              <span><?php echo $item['name']; ?></span>
            </a>
          <?php endforeach; ?>
        </div>
      </div>

      <!-- Other Section with Dropdown -->
      <div class="sidebar-menu-section">
        <button class="sidebar-section-toggle" onclick="toggleSection(this)">
          More
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <polyline points="6 9 12 15 18 9"></polyline>
          </svg>
        </button>
        <div class="sidebar-section-items">
          <?php foreach($other_items as $item): ?>
            <a href="<?php echo $item['file']; ?>" class="sidebar-menu-item <?php echo ($current_page === $item['file']) ? 'active' : ''; ?>">
              <svg viewBox="0 0 24 24" style="color: <?php echo $item['color']; ?>"><path d="<?php echo $item['icon']; ?>"/></svg>
              <span><?php echo $item['name']; ?></span>
            </a>
          <?php endforeach; ?>
        </div>
      </div>
    </div>

    <!-- Logout Section at Bottom -->
    <div class="sidebar-logout-section">
      <button class="sidebar-logout-btn" onclick="openLogoutModal()">
        <svg viewBox="0 0 24 24" fill="currentColor"><path d="M17 7l-1.41 1.41L18.17 11H8v2h10.17l-2.58 2.58L17 17l5-5zM4 5h8V3H4c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h8v-2H4V5z"/></svg>
        <span>Logout</span>
      </button>
    </div>
  </div>
</div>

<!-- Logout Modal -->
<div id="logoutModal" style="display: none; position: fixed; top: 0; left: 0; right: 0; bottom: 0; background: rgba(3, 9, 34, 0.9); backdrop-filter: blur(10px); z-index: 10000; justify-content: center; align-items: center;">
  <div style="background: linear-gradient(180deg, rgba(13, 24, 62, 0.98), rgba(8, 18, 52, 0.98)); border: 1px solid rgba(86, 139, 241, 0.28); border-radius: 16px; padding: 32px; max-width: 400px; box-shadow: 0 20px 60px rgba(4, 10, 36, 0.7);">
    <h2 style="font-family: 'Poppins', sans-serif; font-size: 1.5rem; color: #fff; margin-bottom: 16px; font-weight: 700;">Confirm Logout</h2>
    <p style="font-family: 'Poppins', sans-serif; color: rgba(205, 219, 255, 0.85); margin-bottom: 32px; font-size: 0.95rem;">Are you sure you want to logout from your account?</p>
    <div style="display: flex; gap: 12px;">
      <button onclick="window.location.href='logout.php'" style="flex: 1; padding: 12px 16px; background: linear-gradient(135deg, rgba(255, 77, 77, 0.25), rgba(255, 51, 102, 0.2)); color: #FF6B6B; border: 1px solid rgba(255, 77, 77, 0.3); border-radius: 8px; font-family: 'Poppins', sans-serif; font-weight: 600; cursor: pointer; transition: all 0.3s ease;">
        Yes, Logout
      </button>
      <button onclick="closeLogoutModal()" style="flex: 1; padding: 12px 16px; background: rgba(44, 92, 240, 0.2); color: #4de1c1; border: 1px solid rgba(44, 92, 240, 0.3); border-radius: 8px; font-family: 'Poppins', sans-serif; font-weight: 600; cursor: pointer; transition: all 0.3s ease;">
        Cancel
      </button>
    </div>
  </div>
</div>

<script>
  const hamburgerBtn = document.getElementById('hamburgerBtn');
  const sidebarOverlay = document.getElementById('sidebarOverlay');
  const sidebarPanel = document.getElementById('sidebarPanel');
  const sidebarCloseBtn = document.getElementById('sidebarCloseBtn');

  function toggleSidebar() {
    hamburgerBtn.classList.toggle('active');
    sidebarOverlay.classList.toggle('active');
    sidebarPanel.classList.toggle('active');
    document.body.classList.toggle('sidebar-open');
  }

  function closeSidebar() {
    hamburgerBtn.classList.remove('active');
    sidebarOverlay.classList.remove('active');
    sidebarPanel.classList.remove('active');
    document.body.classList.remove('sidebar-open');
  }

  function toggleSection(btn) {
    btn.classList.toggle('active');
    const items = btn.nextElementSibling;
    items.classList.toggle('active');
  }

  function openLogoutModal() {
    document.getElementById('logoutModal').style.display = 'flex';
  }

  function closeLogoutModal() {
    document.getElementById('logoutModal').style.display = 'none';
  }

  // Toggle on hamburger click
  hamburgerBtn.addEventListener('click', toggleSidebar);

  sidebarOverlay.addEventListener('click', closeSidebar);

  // Close on close button click
  sidebarCloseBtn.addEventListener('click', closeSidebar);

  // Close on menu item click
  document.querySelectorAll('.sidebar-menu-item').forEach(link => {
    link.addEventListener('click', closeSidebar);
  });

  // Close on Escape key
  document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape' && sidebarPanel.classList.contains('active')) {
      closeSidebar();
    }
  });
</script>
