<?php include "doctype.php"; ?>

  <!-- Fonts -->
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700;800&display=swap" rel="stylesheet">

  <style>
    /* Reset & utilities */
    :root{
      --bg-1: #030922;
      --bg-2: #0a164a;
      --card: rgba(13,24,62,0.84);
      --muted: rgba(205,219,255,0.7);
      --neon-1: #4de1c1;
      --neon-2: #2c5bf5;
      --glass-border: rgba(86,139,241,0.18);
      --accent-shadow: 0 24px 60px rgba(44,91,245,0.22);
      --max-width: 1200px;
    }
    *{box-sizing:border-box}
    html,body{height:100%}
    body{
      margin:0;
      font-family:"Poppins", system-ui, -apple-system, "Segoe UI", Roboto, "Helvetica Neue", Arial;
      background: #030922;
      color:#f5f9ff;
      -webkit-font-smoothing:antialiased;
      -moz-osx-font-smoothing:grayscale;
      line-height:1.45;
    }
    a{color:inherit;text-decoration:none}

    /* Centered container */
    .site-wrap{
      max-width:var(--max-width);
      margin:0 auto;
      padding:24px;
    }

   /* Header / Navigation from index.php */
        header {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            z-index: 1000;
            backdrop-filter: blur(12px);
            background: rgba(3, 9, 34, 0.85);
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
            transition: all 0.3s ease;
        }
        
        .nav-container {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 16px 24px;
            max-width: 1280px;
            margin: 0 auto;
        }
        
        .logo-link {
            display: flex;
            align-items: center;
            gap: 12px;
            text-decoration: none;
            color: inherit;
            transition: opacity 0.3s ease;
        }
        
        .logo-link:hover {
            opacity: 0.8;
        }
        
        .logo-img {
            height: 40px;
            width: auto;
        }
        
        nav ul {
            display: none;
            list-style: none;
            gap: 32px;
        }
        
        @media (min-width: 768px) {
            nav ul {
                display: flex;
            }
        }
        
        nav a {
            text-decoration: none;
            color: inherit;
            opacity: 0.8;
            transition: opacity 0.3s ease;
            font-weight: 500;
            font-size: 15px;
        }
        
        nav a:hover {
            opacity: 1;
        }
        
        nav a.active {
            opacity: 1;
            color: #4de1c1;
            font-weight: 600;
        }
        
        .nav-cta {
            display: flex;
            gap: 12px;
            align-items: center;
        }
        
        @media (max-width: 767px) {
            .nav-cta .btn-ghost {
                display: none;
            }
        }
        
        .hamburger-menu {
            display: flex;
            flex-direction: column;
            gap: 5px;
            cursor: pointer;
            padding: 8px;
            background: transparent;
            border: none;
            z-index: 1001;
        }
        
        .hamburger-menu span {
            width: 25px;
            height: 3px;
            background: #f5f9ff;
            border-radius: 2px;
            transition: all 0.3s ease;
        }
        
        .hamburger-menu.active span:nth-child(1) {
            transform: rotate(45deg) translate(8px, 8px);
        }
        
        .hamburger-menu.active span:nth-child(2) {
            opacity: 0;
        }
        
        .hamburger-menu.active span:nth-child(3) {
            transform: rotate(-45deg) translate(7px, -7px);
        }
        
        @media (min-width: 768px) {
            .hamburger-menu {
                display: none;
            }
        }
        
        .mobile-menu {
            position: fixed;
            top: 72px;
            left: 0;
            right: 0;
            background: rgba(3, 9, 34, 0.98);
            backdrop-filter: blur(12px);
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
            max-height: 0;
            overflow: hidden;
            transition: max-height 0.5s ease;
            z-index: 999;
        }
        
        .mobile-menu.active {
            max-height: 400px;
        }
        
        .mobile-menu ul {
            list-style: none;
            padding: 20px 24px;
        }
        
        .mobile-menu li {
            opacity: 0;
            transform: translateX(-20px);
            transition: all 0.3s ease;
        }
        
        .mobile-menu.active li:nth-child(1) { opacity: 1; transform: translateX(0); transition-delay: 0.1s; }
        .mobile-menu.active li:nth-child(2) { opacity: 1; transform: translateX(0); transition-delay: 0.2s; }
        .mobile-menu.active li:nth-child(3) { opacity: 1; transform: translateX(0); transition-delay: 0.3s; }
        .mobile-menu.active li:nth-child(4) { opacity: 1; transform: translateX(0); transition-delay: 0.4s; }
        .mobile-menu.active li:nth-child(5) { opacity: 1; transform: translateX(0); transition-delay: 0.5s; }
        
        .mobile-menu a {
            display: block;
            padding: 12px 0;
            color: #f5f9ff;
            text-decoration: none;
            font-size: 16px;
            font-weight: 500;
            border-bottom: 1px solid rgba(255, 255, 255, 0.05);
            transition: color 0.3s ease;
        }
        
        .mobile-menu a:hover {
            color: #4de1c1;
        }
        
        @media (min-width: 768px) {
            .mobile-menu {
                display: none;
            }
        }

        /* Button Styles matching register.php */
        .btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            padding: 12px 24px;
            border-radius: 12px;
            font-weight: 600;
            font-size: 15px;
            text-decoration: none;
            transition: all 0.3s ease;
            border: none;
            cursor: pointer;
            font-family: inherit;
        }
        
        .btn-primary {
            background: linear-gradient(135deg, #2c5bf5, #4de1c1);
            color: #030922;
            box-shadow: 0 4px 16px rgba(44, 91, 245, 0.3);
        }
        
        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 24px rgba(44, 91, 245, 0.4);
        }
        
        .btn-ghost {
            background: transparent;
            color: inherit;
            border: 2px solid rgba(255, 255, 255, 0.2);
        }
        
        .btn-ghost:hover {
            border-color: rgba(255, 255, 255, 0.4);
            background: rgba(255, 255, 255, 0.05);
        }

    /* HERO */
    .hero {
      padding:84px 0 36px;
      text-align:center;
    }
    .hero .eyebrow{
      color:var(--neon-1);
      font-weight:700;
      letter-spacing:0.06em;
      margin-bottom:10px;
      display:inline-block;
      background:linear-gradient(135deg,var(--neon-2),var(--neon-1));
      -webkit-background-clip:text;
      -webkit-text-fill-color:transparent;
    }
    .hero h1{
      font-size:clamp(28px,5vw,48px);
      margin:0 0 18px;
      line-height:1.02;
      letter-spacing:-0.01em;
    }
    .hero p.lead{max-width:900px;margin:0 auto;color:var(--muted);font-size:16px}

    /* Grid sections */
    .grid {
      display:grid;
      gap:20px;
    }
    .grid.cols-3 {grid-template-columns:1fr; }
    .grid.cols-2 {grid-template-columns:1fr; }
    @media(min-width:880px){
      .grid.cols-3{grid-template-columns:repeat(3,1fr)}
      .grid.cols-2{grid-template-columns:repeat(2,1fr)}
    }

    /* Cards (mission / features) */
    .about-card{
      background:var(--card);
      border-radius:18px;
      padding:22px;
      border:1px solid var(--glass-border);
      box-shadow:0 18px 50px rgba(2,8,28,0.55);
      transition:transform .28s, box-shadow .28s;
    }
    .about-card:hover{transform:translateY(-8px);box-shadow:0 30px 80px rgba(2,8,28,0.75)}
    .card-icon {
      width:56px;height:56px;border-radius:12px;
      display:inline-grid;place-items:center;margin-bottom:14px;
      background:linear-gradient(135deg, rgba(77,225,193,0.12), rgba(44,91,245,0.08));
      border:1px solid rgba(77,225,193,0.06);
    }
    .card-title{font-weight:700;margin-bottom:8px}
    .card-desc{color:var(--muted);font-size:15px}

    /* HOW IT WORKS steps */
    .steps {
      margin-top:20px;
      display:grid;
      gap:16px;
    }
    .step {
      display:flex;
      gap:16px;
      align-items:flex-start;
      background:linear-gradient(180deg, rgba(255,255,255,0.02), rgba(255,255,255,0.01));
      padding:16px;border-radius:14px;border:1px solid rgba(255,255,255,0.03);
    }
    .step .num{
      width:54px;height:54px;border-radius:12px;background:linear-gradient(135deg,var(--neon-2),var(--neon-1));
      display:grid;place-items:center;font-weight:800;color:#030922;font-size:18px;flex:0 0 54px;
      box-shadow:0 18px 48px rgba(44,91,245,0.18);
    }
    .step h4{margin:0 0 6px;font-size:18px}
    .step p{margin:0;color:var(--muted);font-size:14px}

    /* Membership plan cards */
    .plans {margin-top:8px; display:grid; gap:18px;}
    .plan {
      background:linear-gradient(180deg, rgba(255,255,255,0.02), rgba(255,255,255,0.01));
      border-radius:14px;padding:20px;border:1px solid rgba(255,255,255,0.04);
      display:flex;flex-direction:column;gap:12px;
    }
    .plan .plan-head{display:flex;align-items:center;justify-content:space-between}
    .plan .price{font-weight:800;background:linear-gradient(135deg,var(--neon-2),var(--neon-1));
                 -webkit-background-clip:text;-webkit-text-fill-color:transparent}
    .plan ul{margin:0;padding-left:18px;color:var(--muted);list-style:disc}

    /* Feature grid */
    .features-grid{display:grid;gap:14px}
    @media(min-width:880px){ .features-grid{grid-template-columns:repeat(3,1fr)}}
    .feature {
      background:var(--card);padding:16px;border-radius:12px;border:1px solid rgba(255,255,255,0.03);
      display:flex;gap:12px;align-items:flex-start;
    }
    .feature svg{width:36px;height:36px;flex:0 0 36px}

    /* FAQ accordion */
    .faq {margin-top:6px}
    .faq-item{border-radius:12px;overflow:hidden;margin-bottom:12px;border:1px solid rgba(255,255,255,0.03)}
    .faq-q{
      display:flex;justify-content:space-between;gap:12px;padding:14px 16px;background:linear-gradient(180deg, rgba(255,255,255,0.01), rgba(255,255,255,0.00));
      cursor:pointer;align-items:center;
    }
    .faq-q h5{margin:0;font-size:16px; color: white;}
    .faq-a{padding:0 16px 16px 16px;color:var(--muted);font-size:14px;line-height:1.6;display:none}
    .faq-q[aria-expanded="true"] + .faq-a{display:block}

    /* Footer (simple version matching style) */
    footer.site-footer{
      border-top:1px solid rgba(255,255,255,0.04);
      padding:48px 0 24px;margin-top:48px;background:transparent;
    }
    .footer-grid{display:grid;gap:18px}
    @media(min-width:880px){.footer-grid{grid-template-columns:2fr 1fr 1fr 1fr}}
    .footer-brand p{color:var(--muted);font-size:14px}
    .footer-links a{display:block;color:var(--muted);margin-bottom:8px}

    /* small helpers */
    .muted{color:var(--muted)}
    .text-gradient{background:linear-gradient(135deg,var(--neon-2),var(--neon-1)); -webkit-background-clip:text; -webkit-text-fill-color:transparent}
    .center {text-align:center}
    .spacer{height:18px}
  </style>
</head>
<body>
    

 <!-- Added header navigation from index.php -->
    <header role="banner">
        <div class="nav-container">
            <a href="index.php" class="logo-link" aria-label="Earnova Home">
                <img src="logo.png" alt="Earnova Logo" class="logo-img" />
            </a>
            
            <nav role="navigation" aria-label="Main navigation">
                <ul>
                    <li><a href="index.php">Home</a></li>
                    <li><a href="about-us.php">About Us</a></li>
                    <li><a href="terms.php">Privacy Policy</a></li>
                    <li><a href="login.php">Login</a></li>
                </ul>
            </nav>
            
            <div class="nav-cta">
                <a href="register.php" class="btn btn-primary">Get Started</a>
                <a href="login.php" class="btn btn-ghost">Sign In</a>
                <button class="hamburger-menu" aria-label="Toggle mobile menu" aria-expanded="false">
                    <span></span>
                    <span></span>
                    <span></span>
                </button>
            </div>
        </div>
        
        <div class="mobile-menu">
            <ul>
               <li><a href="index.php">Home</a></li>
                    <li><a href="about-us.php">About Us</a></li>
                    <li><a href="terms.php">Privacy Policy</a></li>
                    <li><a href="login.php">Login</a></li>
            </ul>
        </div>
    </header>


  <!-- Page content -->
  <main class="site-wrap" role="main">
    <!-- Hero -->
    <section class="hero" id="top">
      <div class="eyebrow">About Earnova Digital Hub</div>
      <h1>We make content engagement safe, clear and rewarding.</h1>
      <p class="lead">Earnova Digital Hub is a modern engagement platform where users interact with approved content, complete activities and get rewarded with platform benefits — not guaranteed earnings or financial investments.</p>
    </section>

    <!-- Mission / What we provide -->
    <section class="spacer"></section>
    <section aria-labelledby="mission-heading">
      <div style="display:flex;align-items:center;gap:20px;flex-wrap:wrap;justify-content:space-between;">
        <div>
          <h2 id="mission-heading" class="text-gradient">Our Mission</h2>
          <p class="muted" style="max-width:640px;margin-top:10px">Create a safe, transparent and rewarding content ecosystem that empowers users and brands — while keeping all rewards platform-based (not financial investments).</p>
        </div>
      </div>

      <div class="spacer"></div>

      <div class="grid cols-3">
        <div class="about-card">
          <div class="card-icon" aria-hidden="true">
            <!-- svg: smooth interaction -->
            <svg width="28" height="28" viewBox="0 0 24 24" fill="none">
              <rect x="3" y="3" width="18" height="18" rx="4" stroke="#4de1c1" stroke-width="1.2"></rect>
              <path d="M7 12h10" stroke="#4de1c1" stroke-width="1.4" stroke-linecap="round"></path>
            </svg>
          </div>
          <div class="card-title">Content Engagement</div>
          <div class="card-desc">A smooth environment for content viewing, curated activities, and brand-driven experiences that encourage meaningful interaction.</div>
        </div>

        <div class="about-card">
          <div class="card-icon" aria-hidden="true">
            <svg width="28" height="28" viewBox="0 0 24 24" fill="none">
              <circle cx="12" cy="12" r="9" stroke="#2c5bf5" stroke-width="1.2"></circle>
              <path d="M8 12l2 2 4-4" stroke="#2c5bf5" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round"></path>
            </svg>
          </div>
          <div class="card-title">Activity Experiences</div>
          <div class="card-desc">Interactive tasks, streaming engagement, and messaging activities designed to make participation digestible and fun.</div>
        </div>

        <div class="about-card">
          <div class="card-icon" aria-hidden="true">
            <svg width="28" height="28" viewBox="0 0 24 24" fill="none">
              <rect x="4" y="4" width="16" height="16" rx="3" stroke="#4de1c1" stroke-width="1.2"></rect>
              <path d="M8 16l2-4 2 2 4-6" stroke="#4de1c1" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round"></path>
            </svg>
          </div>
          <div class="card-title">Platform Rewards</div>
          <div class="card-desc">A rewards structure that enhances participation — platform credits, visibility, and unlockable perks. Not financial investments.</div>
        </div>
      </div>
    </section>

    <!-- How it works -->
    <section style="margin-top:40px">
      <div style="display:flex;justify-content:space-between;align-items:flex-end;gap:16px;flex-wrap:wrap;">
        <h2 class="text-gradient">How It Works</h2>
        <p class="muted" style="margin:0">A simple 4-step flow to get started and earn platform rewards.</p>
      </div>

      <div class="spacer"></div>

      <div class="steps">
        <div class="step" role="article" aria-label="Step 1">
          <div class="num">1</div>
          <div>
            <h4>Create an account</h4>
            <p>Sign up using your email to access engagement features and personalized activity feeds.</p>
          </div>
        </div>

        <div class="step" role="article" aria-label="Step 2">
          <div class="num">2</div>
          <div>
            <h4>Choose activities</h4>
            <p>Participate in content viewing, interactive tasks and digital participation tools selected by brands and partners.</p>
          </div>
        </div>

        <div class="step" role="article" aria-label="Step 3">
          <div class="num">3</div>
          <div>
            <h4>Earn platform rewards</h4>
            <p>Complete consistent activity to earn points, badges, and redeemable rewards according to platform rules.</p>
          </div>
        </div>

        <div class="step" role="article" aria-label="Step 4">
          <div class="num">4</div>
          <div>
            <h4>Upgrade to unlock more</h4>
            <p>Upgrade your plan to unlock streaming engagement, interactive messaging activities and enhanced rewards.</p>
          </div>
        </div>
      </div>
    </section>

    <!-- Membership Plans -->
    <section style="margin-top:36px">
      <h2 class="text-gradient">Membership Plans</h2>
      <p class="muted" style="max-width:860px">Choose a plan that matches your level of engagement — all plans follow platform rules and are non-refundable.</p>

      <div class="spacer"></div>

      <div class="grid cols-2 plans">
        <div class="plan about-card">
          <div class="plan-head">
            <div>
              <div style="font-weight:700;font-size:18px">Premium Plan</div>
              <div class="muted" style="font-size:13px">Access essential content engagement tools</div>
            </div>
            <div class="price">Essential</div>
          </div>

          <p class="muted">Includes:</p>
          <ul>
            <li>Core engagement tools</li>
            <li>Access to activity tasks</li>
            <li>Standard reward opportunities</li>
          </ul>

          <div style="margin-top:8px">
            <a class="btn btn-primary" href="register.php">Get Premium</a>
          </div>
        </div>

        <div class="plan about-card">
          <div class="plan-head">
            <div>
              <div style="font-weight:700;font-size:18px">Premium Plus Plan</div>
              <div class="muted" style="font-size:13px">Advanced tools & expanded rewards</div>
            </div>
            <div class="price">Advanced</div>
          </div>

          <p class="muted">Includes everything in Premium, plus:</p>
          <ul>
            <li>Streaming engagement tools</li>
            <li>Music/content listening participation</li>
            <li>Interactive messaging activities</li>
            <li>Advertising participation visibility</li>
            <li>Enhanced activity rewards</li>
          </ul>

          <div style="margin-top:8px">
            <a class="btn btn-primary" href="register.php">Get Premium Plus</a>
          </div>
        </div>
      </div>
    </section>

    <!-- Features -->
    <section style="margin-top:36px">
      <div style="display:flex;align-items:center;justify-content:space-between;gap:16px;flex-wrap:wrap">
        <h2 class="text-gradient">Key Features</h2>
        <p class="muted" style="margin:0">Tools and modules designed to help you engage and be rewarded.</p>
      </div>

      <div class="spacer"></div>

      <div class="features-grid">
        <div class="feature about-card">
          <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><path d="M3 7h18" stroke="#4de1c1" stroke-width="1.6" stroke-linecap="round"/></svg>
          <div>
            <div style="font-weight:700">Content View Activities</div>
            <div class="muted">Structured content sessions designed for measurable engagement.</div>
          </div>
        </div>

        <div class="feature about-card">
          <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><circle cx="12" cy="12" r="9" stroke="#2c5bf5" stroke-width="1.6"/></svg>
          <div>
            <div style="font-weight:700">Streaming Engagement</div>
            <div class="muted">Real-time listening and viewing participation tools.</div>
          </div>
        </div>

        <div class="feature about-card">
          <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M4 7h16v10H4z" stroke="#4de1c1" stroke-width="1.4"/></svg>
          <div>
            <div style="font-weight:700">Interactive Messaging</div>
            <div class="muted">Engage via chat-based tasks and messaging campaigns.</div>
          </div>
        </div>

        <div class="feature about-card">
          <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M12 2v20" stroke="#4de1c1" stroke-width="1.4"/></svg>
          <div>
            <div style="font-weight:700">Listening Engagement</div>
            <div class="muted">Music and audio participation features for rewards.</div>
          </div>
        </div>

        <div class="feature about-card">
          <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M3 12h18" stroke="#2c5bf5" stroke-width="1.4"/></svg>
          <div>
            <div style="font-weight:700">Participation Rewards</div>
            <div class="muted">Points, badges and perks that increase with consistent activity.</div>
          </div>
        </div>

        <div class="feature about-card">
          <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><rect x="3" y="3" width="18" height="18" rx="3" stroke="#4de1c1" stroke-width="1.2"/></svg>
          <div>
            <div style="font-weight:700">Campaign & Ads Tools</div>
            <div class="muted">Modules for brand campaigns and advertising interaction metrics.</div>
          </div>
        </div>
      </div>
    </section>

    <!-- FAQ -->
    <section style="margin-top:36px">
      <h2 class="text-gradient">FAQ</h2>
      <p class="muted">Answers to common questions about the platform and rewards.</p>

      <div class="spacer"></div>

      <div class="faq" id="faq">
        <div class="faq-item">
          <button class="faq-q" aria-expanded="false">
            <h5>Is this an earning platform?</h5>
            <div class="muted">+</div>
          </button>
          <div class="faq-a">No. This is a content engagement and participation platform. Rewards are platform-based and do not represent guaranteed financial returns.</div>
        </div>

        <div class="faq-item">
          <button class="faq-q" aria-expanded="false">
            <h5>Are rewards withdrawable?</h5>
            <div class="muted">+</div>
          </button>
          <div class="faq-a">Rewards may be converted or redeemed according to platform rules. They are not guaranteed financial earnings.</div>
        </div>

        <div class="faq-item">
          <button class="faq-q" aria-expanded="false">
            <h5>Is this an investment or trading service?</h5>
            <div class="muted">+</div>
          </button>
          <div class="faq-a">No. We do not provide investments, trading, or profit-based services.</div>
        </div>
      </div>
    </section>

    <!-- Policies -->
    <section style="margin-top:36px">
      <h2 class="text-gradient">Policy Highlights</h2>
      <p class="muted">Quick access to our Terms, Privacy and Refund policy summaries.</p>

      <div class="spacer"></div>

      <div class="grid cols-3">
        <div class="about-card">
          <div class="card-title">Terms of Use</div>
          <div class="card-desc">Users must participate responsibly. Abuse or fraud is prohibited. Paid plans are non-refundable. We may update features for compliance and security.</div>
          <div style="margin-top:12px"><a class="btn btn-ghost" href="terms.php">Read Terms</a></div>
        </div>

        <div class="about-card">
          <div class="card-title">Refund Policy</div>
          <div class="card-desc">Payments for premium memberships are final. Contact support if technical issues prevent access to purchased features.</div>
          <div style="margin-top:12px"><a class="btn btn-ghost" href="terms.php">View Policy</a></div>
        </div>

        <div class="about-card">
          <div class="card-title">Privacy Policy</div>
          <div class="card-desc">We collect basic account info, device logs and usage data to improve the experience. We do not sell personal data. Users may request data updates or deletion.</div>
          <div style="margin-top:12px"><a class="btn btn-ghost" href="terms.php">Privacy Details</a></div>
        </div>
      </div>
    </section>

    <!-- CTA -->
    <section style="margin-top:48px" class="center">
      <div style="max-width:820px;margin:0 auto">
        <h3 class="text-gradient">Ready to join the hub?</h3>
        <p class="muted">Create an account for free and start participating in curated activities that reward you.</p>
        <div style="margin-top:16px">
          <a class="btn btn-primary" href="register.php">Create Account</a>
          <a class="btn btn-ghost" href="about-us.php" style="margin-left:10px">Learn More</a>
        </div>
      </div>
    </section>

  </main>

  <!-- Footer -->
  <footer class="site-footer" role="contentinfo">
   
      <div class="footer-bottom" style="margin-top:28px;color:var(--muted);text-align:center">
       <p>&copy; 2025 Earnova. All rights reserved. Built with care for earners and advertisers worldwide.</p>
            <!--<p class="footer-developer">-->
            <!--    Developed by <a href="https://wa.me/2348012345678" target="_blank" rel="noopener noreferrer">OBODO DEV</a>-->
            <!--</p>-->
      </div>
      
      
    
  </footer>

  <script>
    // Small interaction script: FAQ accordion & accessible toggles
    (function(){
      // FAQ accordion
      document.querySelectorAll('.faq-q').forEach(function(btn){
        btn.addEventListener('click', function(){
          const expanded = this.getAttribute('aria-expanded') === 'true';
          // close all
          document.querySelectorAll('.faq-q').forEach(q => q.setAttribute('aria-expanded','false'));
          if (!expanded) this.setAttribute('aria-expanded','true');
        });
      });

      // count year
      document.getElementById('year').textContent = new Date().getFullYear();

      // Basic responsive nav hamburger (shows on small screens only if needed)
      const hamburger = document.getElementById('hamburger');
      if (hamburger){
        hamburger.style.display = 'none'; // hide; implement if you have mobile menu
      }

      // small reveal on scroll (very light)
      const reveal = function(){
        document.querySelectorAll('.about-card, .step, .plan, .feature').forEach(function(el, idx){
          const rect = el.getBoundingClientRect();
          if (rect.top < (window.innerHeight || document.documentElement.clientHeight) - 60){
            el.style.transform = 'translateY(0)';
            el.style.opacity = 1;
            el.style.transition = 'all 0.6s cubic-bezier(.2,.9,.2,1)';
          } else {
            el.style.transform = 'translateY(10px)';
            el.style.opacity = 0;
          }
        });
      };
      window.addEventListener('load', reveal);
      window.addEventListener('scroll', reveal);
    })();
  </script>
  
     <script>
        function togglePassword(fieldId) {
            const field = document.getElementById(fieldId);
            const eyeIcon = document.getElementById(fieldId + '-eye');
            
            if (field.type === 'password') {
                field.type = 'text';
                eyeIcon.innerHTML = '<path d="M12 7c2.76 0 5 2.24 5 5 0 .65-.13 1.26-.36 1.83l2.92 2.92c1.51-1.26 2.7-2.89 3.43-4.75-1.73-4.39-6-7.5-11-7.5-1.4 0-2.74.25-3.98.7l2.16 2.16C10.74 7.13 11.35 7 12 7zM2 4.27l2.28 2.28.46.46C3.08 8.3 1.78 10.02 1 12c1.73 4.39 6 7.5 11 7.5 1.55 0 3.03-.3 4.38-.84l.42.42L19.73 22 21 20.73 3.27 3 2 4.27zM7.53 9.8l1.55 1.55c-.05.21-.08.43-.08.65 0 1.66 1.34 3 3 3 .22 0 .44-.03.65-.08l1.55 1.55c-.67.33-1.41.53-2.2.53-2.76 0-5-2.24-5-5 0-.79.2-1.53.53-2.2zm4.31-.78l3.15 3.15.02-.16c0-1.66-1.34-3-3-3l-.17.01z"/>';
            } else {
                field.type = 'password';
                eyeIcon.innerHTML = '<path d="M12 4.5C7 4.5 2.73 7.61 1 12c1.73 4.39 6 7.5 11 7.5s9.27-3.11 11-7.5c-1.73-4.39-6-7.5-11-7.5zM12 17c-2.76 0-5-2.24-5-5s2.24-5 5-5 5 2.24 5 5-2.24 5-5 5zm0-8c-1.66 0-3 1.34-3 3s1.34 3 3 3 3-1.34 3-3-1.34-3-3-3z"/>';
            }
        }

        // Removed: All device verification related functions (showDeviceVerificationModal, verifyDeviceCode, etc.)

        document.addEventListener('DOMContentLoaded', async function() {
            const successToast = document.getElementById("toast-success");
            const errorToast = document.getElementById("toast-error");

            function showToast(toast) {
                if (!toast) return;
                setTimeout(() => toast.classList.add("show"), 100);
                setTimeout(() => toast.classList.remove("show"), 5000);
            }

            showToast(successToast);
            showToast(errorToast);

            const hamburger = document.querySelector('.hamburger-menu');
            const mobileMenu = document.querySelector('.mobile-menu');
            
            if (hamburger && mobileMenu) {
                hamburger.addEventListener('click', function() {
                    this.classList.toggle('active');
                    mobileMenu.classList.toggle('active');
                    const isExpanded = this.classList.contains('active');
                    this.setAttribute('aria-expanded', isExpanded);
                });
                
                const mobileLinks = document.querySelectorAll('.mobile-menu a');
                mobileLinks.forEach(link => {
                    link.addEventListener('click', function() {
                        hamburger.classList.remove('active');
                        mobileMenu.classList.remove('active');
                        hamburger.setAttribute('aria-expanded', 'false');
                    });
                });
            }

            window.addEventListener('load', function() {
                if (typeof gsap !== 'undefined') {
                    gsap.registerPlugin(ScrollTrigger);
                    
                    const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
                    
                    if (!prefersReducedMotion) {
                        gsap.from('.login-container', {
                            duration: 0.8,
                            y: 50,
                            opacity: 0,
                            ease: 'power3.out'
                        });
                    }
                }
            });
        });
    </script>
</body>
</html>
