<?php
require_once 'config/database.php';
require_once 'includes/session.php';
require_once 'includes/connect.php';

// Require authentication
requireLogin();
checkSessionTimeout();

// Get current user data
$user = getCurrentUser();
$user_id = $user['id'];

try {
    $pdo = getDBConnection();
    
    // Fetch user details
    $stmt = $pdo->prepare("
        SELECT u.*, b.total_balance, b.task_earnings, b.referral_earnings
        FROM users u
        LEFT JOIN balances b ON u.id = b.user_id
        WHERE u.id = ?
    ");
    $stmt->execute([$user_id]);
    $user_data = $stmt->fetch();
    
    if (!$user_data) {
        header('Location: login.php');
        exit;
    }
    
    // Filter parameters
    $filter_type = $_GET['filter'] ?? 'all';
    $search_query = $_GET['search'] ?? '';
    
    // Build query based on filter
    $where_conditions = ["t.user_id = ?"];
    $params = [$user_id];
    
    if ($filter_type !== 'all') {
        $where_conditions[] = "t.transaction_type = ?";
        $params[] = $filter_type;
    }
    
    if (!empty($search_query)) {
        $where_conditions[] = "(t.description LIKE ? OR t.reference_id LIKE ?)";
        $search_param = "%{$search_query}%";
        $params[] = $search_param;
        $params[] = $search_param;
    }
    
    $where_clause = implode(" AND ", $where_conditions);
    
    // Fetch all transaction history
    $stmt = $pdo->prepare("
        SELECT 
            t.id,
            t.transaction_type,
            t.amount,
            t.balance_type,
            t.description,
            t.reference_id,
            t.created_at
        FROM transactions t
        WHERE {$where_clause}
        ORDER BY t.created_at DESC
        LIMIT 100
    ");
    $stmt->execute($params);
    $transactions = $stmt->fetchAll();
    
    // Fetch withdrawal history with additional details
    $stmt = $pdo->prepare("
        SELECT 
            w.id,
            w.withdrawal_type,
            w.amount,
            w.status,
            w.payment_method,
            w.account_details,
            w.admin_notes,
            w.requested_at,
            w.processed_at
        FROM withdrawals w
        WHERE w.user_id = ?
        ORDER BY w.requested_at DESC
    ");
    $stmt->execute([$user_id]);
    $withdrawals = $stmt->fetchAll();
    
    // Fetch task completion history
    $stmt = $pdo->prepare("
        SELECT 
            ut.id,
            ut.task_id,
            ut.status,
            ut.proof_url,
            ut.completed_at,
            ut.created_at,
            t.title as task_title,
            t.reward_amount
        FROM user_tasks ut
        JOIN tasks t ON ut.task_id = t.id
        WHERE ut.user_id = ?
        ORDER BY ut.created_at DESC
    ");
    $stmt->execute([$user_id]);
    $task_history = $stmt->fetchAll();
    
    // Fetch referral commission history
    $stmt = $pdo->prepare("
        SELECT 
            rc.id,
            rc.commission_type,
            rc.commission_amount,
            rc.created_at,
            u.username as referred_username
        FROM referral_commissions rc
        JOIN users u ON rc.referred_user_id = u.id
        WHERE rc.referrer_id = ?
        ORDER BY rc.created_at DESC
    ");
    $stmt->execute([$user_id]);
    $referral_history = $stmt->fetchAll();
    
    // Fetch daily rewards history
    $stmt = $pdo->prepare("
        SELECT 
            dr.id,
            dr.reward_date,
            dr.reward_amount,
            dr.claimed_at
        FROM daily_rewards dr
        WHERE dr.user_id = ?
        ORDER BY dr.claimed_at DESC
    ");
    $stmt->execute([$user_id]);
    $daily_rewards_history = $stmt->fetchAll();
    
    // Calculate statistics
    $total_earned = 0;
    $total_withdrawn = 0;
    $total_deposits = 0;
    
    foreach ($transactions as $trans) {
        if (in_array($trans['transaction_type'], ['task_reward', 'referral_commission'])) {
            $total_earned += $trans['amount'];
        } elseif ($trans['transaction_type'] === 'withdrawal') {
            $total_withdrawn += $trans['amount'];
        } elseif ($trans['transaction_type'] === 'deposit') {
            $total_deposits += $trans['amount'];
        }
    }
    
} catch (PDOException $e) {
    error_log("History Error: " . $e->getMessage());
    $error_message = "Unable to load history.";
}

$username = htmlspecialchars($user_data['username'] ?? 'User');
$is_member = in_array($user_data['membership_type'], ['premium', 'senior']);

// Helper function to get transaction icon
function getTransactionIcon($type) {
    $icons = [
        'deposit' => '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M12 2L2 7v10c0 5.55 3.84 10.74 9 12 5.16-1.26 9-6.45 9-12V7l-10-5zm0 18c-3.87-.78-7-4.42-7-8V8.3l7-3.11 7 3.11V12c0 3.58-3.13 7.22-7 8z"/><path d="M11 7h2v7h-2zm0 8h2v2h-2z"/></svg>',
        'withdrawal' => '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-2h2v2zm0-4h-2V7h2v6z"/></svg>',
        'task_reward' => '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M9 16.2L4.8 12l-1.4 1.4L9 19 21 7l-1.4-1.4L9 16.2z"/></svg>',
        'referral_commission' => '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M16 11c1.66 0 2.99-1.34 2.99-3S17.66 5 16 5c-1.66 0-3 1.34-3 3s1.34 3 3 3zm-8 0c1.66 0 2.99-1.34 2.99-3S9.66 5 8 5C6.34 5 5 6.34 5 8s1.34 3 3 3zm0 2c-2.33 0-7 1.17-7 3.5V19h14v-2.5c0-2.33-4.67-3.5-7-3.5zm8 0c-.29 0-.62.02-.97.05 1.16.84 1.97 1.97 1.97 3.45V19h6v-2.5c0-2.33-4.67-3.5-7-3.5z"/></svg>',
        'premium_upgrade' => '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/></svg>',
        'ad_purchase' => '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M21 3H3c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h18c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm0 16H3V5h18v14zM5 10h5v7H5zm7-5h7v3h-7zm0 4h7v9h-7z"/></svg>'
    ];
    return $icons[$type] ?? $icons['task_reward'];
}

// Helper function to get status badge color
function getStatusColor($status) {
    $colors = [
        'completed' => '#4DE1C1',
        'approved' => '#4DE1C1',
        'processing' => '#2C5CF0',
        'pending' => '#FFC107',
        'rejected' => '#FF3366',
        'failed' => '#FF3366'
    ];
    return $colors[$status] ?? '#FFC107';
}
?>
<?php include "doctype.php"; ?>
  <!-- <link rel="stylesheet" href="history-design.css" /> -->
</head>
<style>
  /* Base styles matching my-posted-task.css design */
:root {
  --page-bg: #0a0e27;
  --page-white: #ffffff;
  --page-mint: #4de1c1;
  --page-blue-300: #2c5cf0;
  --page-purple: #8b5cf6;
  --page-pink: #ff3366;
  --panel-glass: rgba(255, 255, 255, 0.05);
  --panel-border: rgba(255, 255, 255, 0.1);
  --text-muted: rgba(255, 255, 255, 0.6);
   --page-blue-900: #030922;
      --page-blue-700: #0a164a;
      --page-blue-500: #142a7e;
      --page-blue-300: #2c5bf5;


        --page-blue-900: #030922;
      --page-blue-700: #0a164a;
      --page-blue-500: #142a7e;
      --page-blue-300: #2c5bf5;
      --page-mint: #4de1c1;
      --page-white: #f5f9ff;
      --panel-glass: rgba(13, 24, 62, 0.78);
      --panel-border: rgba(86, 139, 241, 0.28);
      --shadow-heavy: 0 40px 120px rgba(4, 10, 36, 0.65);
      --transition-long: 0.85s cubic-bezier(0.19, 1, 0.22, 1);
      --transition-short: 0.4s ease;
}

* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}

body {
   font-family: "Titillium Web", "Segoe UI", sans-serif;
  font-family: "Inter", -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
 background: #030922;
  color: var(--page-white);
  min-height: 100vh;
  line-height: 1.6;
}

.page-shell {
  display: flex;
  min-height: 100vh;
  padding-bottom: 80px;
}

/* Sidebar */
#sidebar {
  width: 320px;
   background: rgba(13, 24, 62, 0.78);
      backdrop-filter: blur(18px);
  border-right: 1px solid var(--panel-border);
  padding: 32px 24px;
  position: sticky;
  top: 0;
  height: 100vh;
  overflow-y: auto;
  display: flex;
  flex-direction: column;
  gap: 32px;
}


    .back-link {
      display: inline-flex;
      align-items: center;
      gap: 10px;
      font-weight: 600;
      font-size: clamp(0.75rem, 1.5vw, 0.875rem);
      letter-spacing: 0.1em;
      text-transform: uppercase;
      color: rgba(210, 226, 255, 0.78);
      transition: color var(--transition-short), transform var(--transition-short);
      text-decoration: none;
    }

    .back-link:hover { color: var(--page-white); transform: translateX(-4px); }

 .aside-welcome {
      display: grid;
      grid-template-columns: auto 1fr;
      align-items: center;
      gap: clamp(0.75rem, 1.5vw, 1rem);
       background: linear-gradient(135deg, rgba(44, 91, 245, 0.3), rgba(26, 58, 171, 0.2));
      border: 1px solid rgba(44, 91, 245, 0.5);
      box-shadow: 0 0 10px rgba(44, 91, 245, 0.6);
      border-radius: 20px;
      padding: clamp(0.875rem, 1.75vw, 1.125rem);
   
      position: relative;
      z-index: 2;
    }

    .aside-avatar {
      width: clamp(48px, 10vw, 64px);
      height: clamp(48px, 10vw, 64px);
      border-radius: 50%;
      overflow: hidden;
      border: 4px solid rgba(251, 191, 36, 0.35);
      box-shadow: 0 14px 34px rgba(3, 9, 30, 0.55);
    }

    .aside-avatar img {
      width: 100%;
      display: block;
    }

    .welcome-tag {
      margin: 0;
      font-size: clamp(0.6875rem, 1.25vw, 0.75rem);
      letter-spacing: 0.12em;
      text-transform: uppercase;
      color: rgba(205, 219, 255, 0.62);
    }

    .aside-welcome h3 {
      margin: clamp(0.25rem, 0.5vw, 0.375rem) 0 clamp(0.125rem, 0.25vw, 0.25rem);
      font-size: clamp(1rem, 2vw, 1.12rem);
      letter-spacing: 0.04em;
      color: var(--page-white);
      font-weight: 700;
    }

    .welcome-meta {
      font-size: clamp(0.75rem, 1.5vw, 0.8rem);
      letter-spacing: 0.08em;
      color: rgba(149, 183, 255, 0.7);
    }


.page-title {
  /* Reduced font size to 16px for compact display */
  font-size: 16px;
  font-weight: 700;
  margin-bottom: 8px;
  background: linear-gradient(135deg, var(--page-mint), var(--page-blue-300));
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
}

.side-description {
  color: var(--text-muted);
  /* Reduced font size to 14px for compact display */
  font-size: 14px;
  line-height: 1.5;
}

.stats-box {
  background: var(--panel-glass);
  border: 1px solid var(--panel-border);
  border-radius: 16px;
  /* Reduced padding for compact display */
  padding: 16px;
}

.stats-box h4 {
  /* Reduced font size to 16px */
  font-size: 16px;
  margin-bottom: 12px;
  color: var(--page-mint);
}

.stat-item {
  display: flex;
  justify-content: space-between;
  align-items: center;
  /* Reduced padding for compact display */
  padding: 8px 0;
  border-bottom: 1px solid var(--panel-border);
}

.stat-item:last-child {
  border-bottom: none;
}

.stat-item span {
  color: var(--text-muted);
  /* Reduced font size to 14px */
  font-size: 14px;
}

.stat-item strong {
  color: var(--page-white);
  /* Reduced font size to 16px */
  font-size: 16px;
}

/* Main Content */
main {
  flex: 1;
  /* Reduced padding for compact display */
  padding: 24px;
  width:100%;
  margin: 0 auto;
}

.hero-section {
  /* Reduced margin for compact display */
  margin-bottom: 24px;
  display: flex;
  justify-content: space-between;
  align-items: flex-start;
  gap: 16px;
}

.hero-content h1 {
  /* Reduced font size to 20px */
  font-size: 20px;
  font-weight: 700;
  margin-bottom: 8px;
  background: linear-gradient(135deg, var(--page-mint), var(--page-blue-300));
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
}

.hero-content p {
  color: var(--text-muted);
  /* Reduced font size to 16px */
  font-size: 16px;
  max-width: 600px;
}

.filter-controls {
  width: 100%;
  /* Reduced margin for compact display */
  margin-top: 16px;
}

.filter-form {
  display: flex;
  gap: 12px;
  align-items: center;
  flex-wrap: wrap;
}

.filter-form select,
.filter-form input[type="text"] {
  /* Reduced padding for compact display */
  padding: 10px 14px;
  background: var(--panel-glass);
  border: 1px solid var(--panel-border);
  border-radius: 12px;
  color: var(--page-white);
  /* Reduced font size to 14px */
  font-size: 14px;
  outline: none;
  transition: all 0.3s;
}

.filter-form select {
  min-width: 180px;
}

.filter-form input[type="text"] {
  flex: 1;
  min-width: 200px;
}

.filter-form select:focus,
.filter-form input[type="text"]:focus {
  border-color: var(--page-mint);
  background: rgba(77, 225, 193, 0.05);
}

.btn-primary {
  /* Reduced padding for compact display */
  padding: 10px 20px;
  background: linear-gradient(135deg, var(--page-mint), var(--page-blue-300));
  color: var(--page-bg);
  border: none;
  border-radius: 12px;
  font-weight: 600;
  /* Reduced font size to 14px */
  font-size: 14px;
  cursor: pointer;
  transition: all 0.3s;
  text-decoration: none;
  display: inline-block;
}

.btn-primary:hover {
  transform: translateY(-2px);
  box-shadow: 0 8px 24px rgba(77, 225, 193, 0.3);
}

/* Empty State */
.empty-state {
  text-align: center;
  /* Reduced padding for compact display */
  padding: 60px 20px;
  background: var(--panel-glass);
  border: 1px solid var(--panel-border);
  border-radius: 20px;
  /* Reduced margin for compact display */
  margin: 24px 0;
}

.empty-state svg {
  margin-bottom: 20px;
}

.empty-state h2 {
  /* Reduced font size to 18px */
  font-size: 18px;
  margin-bottom: 8px;
}

.empty-state p {
  color: var(--text-muted);
  /* Reduced margin and font size */
  margin-bottom: 24px;
  font-size: 16px;
}

/* History Section */
.history-section {
  /* Reduced margin for compact display */
  margin-bottom: 32px;
}

.section-title {
  /* Reduced font size to 16px */
  font-size: 16px;
  font-weight: 700;
  /* Reduced margin for compact display */
  margin-bottom: 16px;
  color: var(--page-white);
}

.history-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(400px, 1fr));
  gap: 20px;
}

.history-card {
  background: var(--panel-glass);
  border: 1px solid var(--panel-border);
  border-radius: 16px;
  /* Reduced padding for compact display */
  padding: 20px;
  cursor: pointer;
  transition: all 0.3s;
}

.history-card:hover {
  transform: translateY(-4px);
  border-color: var(--page-mint);
  box-shadow: 0 8px 32px rgba(77, 225, 193, 0.2);
}

.card-header {
  display: flex;
  align-items: flex-start;
  gap: 14px;
  /* Reduced margin for compact display */
  margin-bottom: 12px;
}

.icon-wrapper {
  width: 44px;
  height: 44px;
  border-radius: 12px;
  display: flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
}

.icon-wrapper svg {
  width: 22px;
  height: 22px;
}

.icon-wrapper.withdrawal {
  background: rgba(255, 51, 102, 0.2);
  color: var(--page-pink);
}

.icon-wrapper.deposit {
  background: rgba(77, 225, 193, 0.2);
  color: var(--page-mint);
}

.card-info {
  flex: 1;
}

.card-info h3 {
  /* Reduced font size to 16px */
  font-size: 16px;
  font-weight: 600;
  margin-bottom: 4px;
}

.card-meta {
  /* Reduced font size to 14px */
  font-size: 14px;
  color: var(--text-muted);
}

.card-amount {
  /* Reduced font size to 18px */
  font-size: 18px;
  font-weight: 700;
}

.card-amount.positive {
  color: var(--page-mint);
}

.card-amount.negative {
  color: var(--page-pink);
}

.card-details {
  display: flex;
  justify-content: space-between;
  align-items: center;
  /* Reduced margin for compact display */
  margin-bottom: 12px;
}

.status-badge {
  padding: 5px 10px;
  border-radius: 8px;
  /* Reduced font size to 12px */
  font-size: 12px;
  font-weight: 600;
  color: var(--page-bg);
}

.card-date {
  /* Reduced font size to 14px */
  font-size: 14px;
  color: var(--text-muted);
}

.card-action {
  text-align: right;
}

.receipt-link {
  color: var(--page-mint);
  /* Reduced font size to 14px */
  font-size: 14px;
  font-weight: 500;
}

/* Transactions Table */
.transactions-table {
  background: var(--panel-glass);
  border: 1px solid var(--panel-border);
  border-radius: 16px;
  overflow: hidden;
}

.transactions-table table {
  width: 100%;
  border-collapse: collapse;
}

.transactions-table thead {
  background: rgba(77, 225, 193, 0.1);
}

.transactions-table th {
  /* Reduced padding for compact display */
  padding: 12px;
  text-align: left;
  font-weight: 600;
  /* Reduced font size to 14px */
  font-size: 14px;
  color: var(--page-mint);
  text-transform: uppercase;
  letter-spacing: 0.05em;
}

.transactions-table td {
  /* Reduced padding for compact display */
  padding: 12px;
  border-top: 1px solid var(--panel-border);
  /* Reduced font size to 14px */
  font-size: 14px;
}

.table-icon {
  display: flex;
  align-items: center;
  gap: 10px;
}

.table-icon svg {
  width: 18px;
  height: 18px;
  color: var(--page-mint);
}

.transactions-table .positive {
  color: var(--page-mint);
  font-weight: 600;
}

.transactions-table .negative {
  color: var(--page-pink);
  font-weight: 600;
}

.badge-task,
.badge-referral,
.badge-total {
  padding: 4px 10px;
  border-radius: 6px;
  /* Reduced font size to 12px */
  font-size: 12px;
  font-weight: 600;
  text-transform: uppercase;
}

.badge-task {
  background: rgba(44, 92, 240, 0.2);
  color: var(--page-blue-300);
}

.badge-referral {
  background: rgba(139, 92, 246, 0.2);
  color: var(--page-purple);
}

.badge-total {
  background: rgba(77, 225, 193, 0.2);
  color: var(--page-mint);
}

/* Modal */
.modal {
  display: none;
  position: fixed;
  z-index: 1000;
  left: 0;
  top: 0;
  width: 100%;
  height: 100%;
  background: rgba(0, 0, 0, 0.8);
  backdrop-filter: blur(10px);
}

.modal-content {
  background: var(--page-bg);
  margin: 5% auto;
  padding: 0;
  border: 1px solid var(--panel-border);
  border-radius: 20px;
  width: 90%;
  max-width: 600px;
  position: relative;
  animation: slideIn 0.3s ease-out;
}

@keyframes slideIn {
  from {
    transform: translateY(-50px);
    opacity: 0;
  }
  to {
    transform: translateY(0);
    opacity: 1;
  }
}

.close {
  position: absolute;
  right: 20px;
  top: 20px;
  font-size: 28px;
  font-weight: bold;
  color: var(--text-muted);
  cursor: pointer;
  transition: color 0.3s;
  z-index: 1;
}

.close:hover {
  color: var(--page-white);
}

.receipt-container {
  /* Reduced padding for compact display */
  padding: 32px;
}

.receipt-header {
  text-align: center;
  /* Reduced margin for compact display */
  margin-bottom: 24px;
  padding-bottom: 20px;
  border-bottom: 2px solid var(--panel-border);
}

.receipt-header h2 {
  /* Reduced font size to 20px */
  font-size: 20px;
  margin-bottom: 10px;
  background: linear-gradient(135deg, var(--page-mint), var(--page-blue-300));
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
}

.receipt-logo {
  /* Reduced font size to 18px */
  font-size: 18px;
  font-weight: 700;
  color: var(--page-mint);
}

.receipt-body {
  /* Reduced margin for compact display */
  margin-bottom: 24px;
}

.receipt-row {
  display: flex;
  justify-content: space-between;
  align-items: center;
  /* Reduced padding for compact display */
  padding: 12px 0;
  border-bottom: 1px solid var(--panel-border);
}

.receipt-row:last-child {
  border-bottom: none;
}

.receipt-row span {
  color: var(--text-muted);
  /* Reduced font size to 14px */
  font-size: 14px;
}

.receipt-row strong {
  color: var(--page-white);
  /* Reduced font size to 16px */
  font-size: 9px;
  text-align: right;
}

.amount-highlight {
  /* Reduced font size to 18px */
  font-size: 18px !important;
  color: var(--page-mint) !important;
}

.receipt-footer {
  text-align: center;
  /* Reduced padding for compact display */
  padding-top: 20px;
  border-top: 2px solid var(--panel-border);
}

.receipt-footer p {
  color: var(--text-muted);
  /* Reduced font size to 14px */
  font-size: 14px;
  margin-bottom: 16px;
}
 
 /* Updated mobile footer with 5 icons */
    .mobile-fintech-footer {
      display: none;
      position: fixed;
      left: 12px;
      right: 12px;
      bottom: 16px;
      padding: 10px;
      background: transparent;
      border: 1px solid rgba(86, 139, 241, 0.35);
      border-radius: 32px;
      backdrop-filter: blur(50px);
      box-shadow: 0 20px 60px rgba(4, 10, 36, 0.7);
      justify-content: space-around;
      align-items: center;
      z-index: 90;
    }

    .mobile-fintech-footer a {
      flex: 1;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      gap: 4px;
      text-decoration: none;
      color: rgba(205, 219, 255, 0.75);
      font-size: 0.45rem;
      letter-spacing: 0.06em;
      text-transform: uppercase;
      transition: all var(--transition-short);
      padding: 8px 4px;
      border-radius: 16px;
    }
    /* Special styling for middle icon (3rd icon - Withdraw) */
    /* .mobile-fintech-footer a:nth-child(3) {
      position: relative;
      transform: translateY(-12px);
    } */

    .mobile-fintech-footer a:nth-child(3) .icon-wrapper {
      width: 56px;
      height: 56px;
      border-radius: 50%;
      background: linear-gradient(135deg, rgba(77, 225, 193, 0.25), rgba(47, 91, 234, 0.25));
      backdrop-filter: blur(12px);
      border: 2px solid rgba(77, 225, 193, 0.4);
      display: flex;
      align-items: center;
      justify-content: center;
      box-shadow: 0 8px 24px rgba(77, 225, 193, 0.3);
    }

    .mobile-fintech-footer a:nth-child(3) svg {
      width: 28px;
      height: 28px;
    }

    .mobile-fintech-footer a.active {
      color: var(--page-mint);
    }

    .mobile-fintech-footer svg {
      width: 22px;
      height: 22px;
      fill: currentColor;
      filter: drop-shadow(0 4px 12px rgba(4, 10, 36, 0.4));
    }

    .mobile-fintech-footer a:hover {
      color: var(--page-mint);
      transform: translateY(-2px);
    }

    .mobile-fintech-footer a:nth-child(3):hover {
      transform: translateY(-14px);
    }
/* Alert */
.alert {
  padding: 16px 20px;
  border-radius: 12px;
  margin-bottom: 24px;
  font-weight: 500;
}

.alert-success {
  background: rgba(77, 225, 193, 0.2);
  border: 1px solid var(--page-mint);
  color: var(--page-mint);
}

.alert-error {
  background: rgba(255, 51, 102, 0.2);
  border: 1px solid var(--page-pink);
  color: var(--page-pink);
}

/* Responsive Design */
@media (max-width: 1024px) {
  #sidebar {
    width: 280px;
  }

  .history-grid {
    grid-template-columns: 1fr;
  }
  
}

@media (max-width: 768px) {
  .page-shell {
    flex-direction: column;
  }

  #sidebar {
    width: 100%;
    height: auto;
    position: relative;
    border-right: none;
    border-bottom: 1px solid var(--panel-border);
  }

  main {
    padding: 24px 16px;
  }

  .hero-section {
    flex-direction: column;
  }

  .hero-content h1 {
    font-size: 2rem;
  }

  .filter-form {
    flex-direction: column;
  }

  .filter-form select,
  .filter-form input[type="text"] {
    width: 100%;
  }

  .history-grid {
    grid-template-columns: 1fr;
  }

  .transactions-table {
    overflow-x: auto;
  }

  .mobile-fintech-footer {
    display: flex;
  }

  .receipt-container {
    padding: 24px;
  }
}

@media print {
  body * {
    visibility: hidden;
  }

  .receipt-container,
  .receipt-container * {
    visibility: visible;
  }

  .receipt-container {
    position: absolute;
    left: 0;
    top: 0;
    width: 100%;
  }

  .close,
  .btn-primary {
    display: none !important;
  }
}

</style>
<body>
  <?php include "embed.php"; ?>
  <?php include "header2.php"; ?>
  <div class="page-shell">
   
    
    <main>

     <div>
        <h2 class="page-title" style="font-size: 18px; color: #fff;">Transaction History</h2>
        <p class="side-description" style="margin-bottom: 15px;">View all your financial activities including deposits, withdrawals, earnings, and rewards.</p>
      </div>
      <div class="stats-box" style="border-color: rgba(251, 191, 36, 0.4);
      background: linear-gradient(135deg, rgba(251, 191, 36, 0.08), rgba(13, 24, 62, 0.78));">
        <h4>Financial Summary</h4>
        <div class="stat-item">
          <span>Total Withdrawn</span>
          <strong>â‚¦<?php echo number_format($total_withdrawn, 2); ?></strong>
        </div>
        <div class="stat-item">
          <span>Total Deposits</span>
          <strong>â‚¦<?php echo number_format($total_deposits, 2); ?></strong>
        </div>
        <div class="stat-item">
          <span>Total Balance</span>
          <strong>â‚¦<?php echo number_format($user_data['total_balance'], 2); ?></strong>
        </div>
      </div>
      <section class="hero-section">
        <!-- <div class="hero-content">
          <h1>Complete Transaction History</h1>
          <p>Track all your financial activities, view receipts, and monitor your earnings across the platform.</p>
        </div> -->
        <div class="filter-controls">
          <form method="GET" class="filter-form">
            <select name="filter" onchange="this.form.submit()">
              <option value="all" <?php echo $filter_type === 'all' ? 'selected' : ''; ?>>All Transactions</option>
              <option value="deposit" <?php echo $filter_type === 'deposit' ? 'selected' : ''; ?>>Deposits</option>
              <option value="withdrawal" <?php echo $filter_type === 'withdrawal' ? 'selected' : ''; ?>>Withdrawals</option>
              <option value="task_reward" <?php echo $filter_type === 'task_reward' ? 'selected' : ''; ?>>Activity Rewards</option>
              <option value="referral_commission" <?php echo $filter_type === 'referral_commission' ? 'selected' : ''; ?>>Invite Commissions</option>
             
            </select>
            <input type="text" name="search" placeholder="Search transactions..." value="<?php echo htmlspecialchars($search_query); ?>">
            <button type="submit" class="btn-primary">Search</button>
          </form>
        </div>
      </section>

      <?php if (empty($transactions) && empty($withdrawals)): ?>
        <section class="empty-state">
          <svg viewBox="0 0 24 24" width="80" height="80" fill="rgba(77, 225, 193, 0.3)">
            <path d="M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm-7 3c1.93 0 3.5 1.57 3.5 3.5S13.93 13 12 13s-3.5-1.57-3.5-3.5S10.07 6 12 6zm7 13H5v-.23c0-.62.28-1.2.76-1.58C7.47 15.82 9.64 15 12 15s4.53.82 6.24 2.19c.48.38.76.97.76 1.58V19z"/>
          </svg>
          <h2>No Transaction History</h2>
          <p>Start earning by completing tasks,  friends Invitation, and many more.</p>
          <a href="dashboard.php" class="btn-primary">Go to Dashboard</a>
        </section>
      <?php else: ?>
        
        <!-- Withdrawals Section -->
        <?php if (!empty($withdrawals)): ?>
          <section class="history-section">
            <h2 class="section-title">Withdrawal History</h2>
            <div class="history-grid">
              <?php foreach ($withdrawals as $withdrawal): ?>
                <article class="history-card withdrawal-card" onclick="openWithdrawalReceipt(<?php echo htmlspecialchars(json_encode($withdrawal)); ?>)">
                  <div class="card-header">
                    <div class="icon-wrapper withdrawal">
                      <?php echo getTransactionIcon('withdrawal'); ?>
                    </div>
                    <div class="card-info">
                      <h3>Withdrawal - <?php echo ucfirst($withdrawal['withdrawal_type']); ?></h3>
                      <p class="card-meta"><?php echo ucfirst($withdrawal['payment_method']); ?></p>
                    </div>
                    <div class="card-amount negative">
                      -â‚¦<?php echo number_format($withdrawal['amount'], 2); ?>
                    </div>
                  </div>
                  <div class="card-details">
                    <span class="status-badge" style="background: <?php echo getStatusColor($withdrawal['status']); ?>">
                      <?php echo strtoupper($withdrawal['status']); ?>
                    </span>
                    <span class="card-date"><?php echo date('M d, Y - h:i A', strtotime($withdrawal['requested_at'])); ?></span>
                  </div>
                  <div class="card-action">
                    <span class="receipt-link">Click to view receipt â†’</span>
                  </div>
                </article>
              <?php endforeach; ?>
            </div>
          </section>
        <?php endif; ?>

        <!-- Deposits Section -->
        <?php 
        $deposits = array_filter($transactions, fn($t) => $t['transaction_type'] === 'deposit');
        if (!empty($deposits)): 
        ?>
          <section class="history-section">
            <h2 class="section-title">Deposit History</h2>
            <div class="history-grid">
              <?php foreach ($deposits as $deposit): ?>
                <article class="history-card deposit-card" onclick="openDepositReceipt(<?php echo htmlspecialchars(json_encode($deposit)); ?>)">
                  <div class="card-header">
                    <div class="icon-wrapper deposit">
                      <?php echo getTransactionIcon('deposit'); ?>
                    </div>
                    <div class="card-info">
                      <h3>Deposit</h3>
                      <p class="card-meta"><?php echo htmlspecialchars($deposit['description']); ?></p>
                    </div>
                    <div class="card-amount positive">
                      +â‚¦<?php echo number_format($deposit['amount'], 2); ?>
                    </div>
                  </div>
                  <div class="card-details">
                    <span class="status-badge" style="background: #4DE1C1">COMPLETED</span>
                    <span class="card-date"><?php echo date('M d, Y - h:i A', strtotime($deposit['created_at'])); ?></span>
                  </div>
                  <div class="card-action">
                    <span class="receipt-link">Click to view receipt â†’</span>
                  </div>
                </article>
              <?php endforeach; ?>
            </div>
          </section>
        <?php endif; ?>

        <!-- All Transactions Section -->
        <section class="history-section">
          <h2 class="section-title">All Transactions</h2>
          <div class="transactions-table">
            <table>
              <thead>
                <tr>
                  <th>Type</th>
                  <th>Description</th>
                  <th>Amount</th>
                  <th>Balance Type</th>
                  <th>Reference</th>
                  <th>Date</th>
                </tr>
              </thead>
              <tbody>
                <?php foreach ($transactions as $trans): ?>
                  <tr>
                    <td>
                      <div class="table-icon">
                        <?php echo getTransactionIcon($trans['transaction_type']); ?>
                        <span><?php echo ucwords(str_replace('_', ' ', $trans['transaction_type'])); ?></span>
                      </div>
                    </td>
                    <td><?php echo htmlspecialchars($trans['description']); ?></td>
                    <td class="<?php echo in_array($trans['transaction_type'], ['withdrawal', 'ad_purchase']) ? 'negative' : 'positive'; ?>">
                      <?php echo in_array($trans['transaction_type'], ['withdrawal', 'ad_purchase']) ? '-' : '+'; ?>â‚¦<?php echo number_format($trans['amount'], 2); ?>
                    </td>
                    <td><span class="badge-<?php echo $trans['balance_type']; ?>"><?php echo ucfirst($trans['balance_type']); ?></span></td>
                    <td><?php echo htmlspecialchars($trans['reference_id'] ?? 'N/A'); ?></td>
                    <td><?php echo date('M d, Y h:i A', strtotime($trans['created_at'])); ?></td>
                  </tr>
                <?php endforeach; ?>
              </tbody>
            </table>
          </div>
        </section>
      <?php endif; ?>
    </main>
  </div>

  <!-- Withdrawal Receipt Modal -->
  <div id="withdrawalReceiptModal" class="modal">
    <div class="modal-content receipt-modal">
      <span class="close" onclick="closeWithdrawalReceipt()">&times;</span>
      <div class="receipt-container">
        <div class="receipt-header">
          <h2>Withdrawal Receipt</h2>
          <div class="receipt-logo">Earnova</div>
        </div>
        <div class="receipt-body">
          <div class="receipt-row">
            <span>Transaction Type:</span>
            <strong id="wr_type">--</strong>
          </div>
          <div class="receipt-row">
            <span>Amount:</span>
            <strong id="wr_amount" class="amount-highlight">--</strong>
          </div>
          <div class="receipt-row">
            <span>Payment Method:</span>
            <strong id="wr_method">--</strong>
          </div>
          <div class="receipt-row">
            <span>Account Details:</span>
            <strong id="wr_account">--</strong>
          </div>
          <div class="receipt-row">
            <span>Status:</span>
            <strong id="wr_status">--</strong>
          </div>
          <div class="receipt-row">
            <span>Requested Date:</span>
            <strong id="wr_requested">--</strong>
          </div>
          <div class="receipt-row">
            <span>Processed Date:</span>
            <strong id="wr_processed">--</strong>
          </div>
          <div class="receipt-row" id="wr_notes_row" style="display: none;">
            <span>Admin Notes:</span>
            <strong id="wr_notes">--</strong>
          </div>
          <div class="receipt-row">
            <span>Reference ID:</span>
            <strong id="wr_reference">--</strong>
          </div>
        </div>
        <div class="receipt-footer">
          <p>This is an official receipt from Earnova</p>
          <button onclick="printReceipt()" class="btn-primary">Print Receipt</button>
        </div>
      </div>
    </div>
  </div>

  <!-- Deposit Receipt Modal -->
  <div id="depositReceiptModal" class="modal">
    <div class="modal-content receipt-modal">
      <span class="close" onclick="closeDepositReceipt()">&times;</span>
      <div class="receipt-container">
        <div class="receipt-header">
          <h2>Deposit Receipt</h2>
          <div class="receipt-logo">Earnova</div>
        </div>
        <div class="receipt-body">
          <div class="receipt-row">
            <span>Transaction Type:</span>
            <strong>Deposit</strong>
          </div>
          <div class="receipt-row">
            <span>Amount:</span>
            <strong id="dr_amount" class="amount-highlight">--</strong>
          </div>
          <div class="receipt-row">
            <span>Description:</span>
            <strong id="dr_description">--</strong>
          </div>
          <div class="receipt-row">
            <span>Balance Type:</span>
            <strong id="dr_balance_type">--</strong>
          </div>
          <div class="receipt-row">
            <span>Status:</span>
            <strong style="color: #4DE1C1;">COMPLETED</strong>
          </div>
          <div class="receipt-row">
            <span>Transaction Date:</span>
            <strong id="dr_date">--</strong>
          </div>
          <div class="receipt-row">
            <span>Reference ID:</span>
            <strong id="dr_reference">--</strong>
          </div>
        </div>
        <div class="receipt-footer">
          <p>This is an official receipt from Earnova</p>
          <button onclick="printReceipt()" class="btn-primary">Print Receipt</button>
        </div>
      </div>
    </div>
  </div>

  <nav class="mobile-fintech-footer">
    
  <a href="dashboard.php">
    <svg viewBox="0 0 24 24"><path d="M12 3a9 9 0 1 1 0 18 9 9 0 0 1 0-18Zm1 4h-2v6h6v-2h-4V7Z"/></svg>
    <span>Dashboard</span>
  </a>

  <!-- Premium (crown icon) -->
  <a href="membership.php">
    <svg viewBox="0 0 24 24"><path d="M5 7l2.5 5 4.5-4 4.5 4L19 7l2 13H3l2-13Z"/></svg>
    <span>Premium</span>
  </a>

  <a href="post-task.php">
<svg viewBox="0 0 24 24" aria-hidden="true">
  <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8l-6-6Zm1 14h-3v3h-2v-3H7v-2h3v-3h2v3h3v2Zm-3-9V3.5L18.5 8H12Z"/>
</svg>
    
    <span>Post Advert</span>
  </a>
  
  

  <a href="history.php" class="active">
  <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
    <path d="M13 3a9 9 0 1 0 9 9h-2a7 7 0 1 1-7-7V3l4 4-4 4V7a5 5 0 1 0 5 5h2a7 7 0 1 1-7-7z"/>
  </svg>
  <span>History</span>
</a>


  <a href="profile.php">
    <svg viewBox="0 0 24 24"><path d="M12 2a6 6 0 0 1 6 6c0 3.31-2.69 6-6 6s-6-2.69-6-6a6 6 0 0 1 6-6Zm0 14c4.42 0 8 1.79 8 4v2H4v-2c0-2.21 3.58-4 8-4Z"/></svg>
    <span>Profile</span>
  </a>
</nav>

<script>
    function openWithdrawalReceipt(withdrawal) {
      document.getElementById('wr_type').textContent = withdrawal.withdrawal_type.toUpperCase() + ' Withdrawal';
      document.getElementById('wr_amount').textContent = 'â‚¦' + parseFloat(withdrawal.amount).toLocaleString('en-NG', {minimumFractionDigits: 2});
      document.getElementById('wr_method').textContent = withdrawal.payment_method.toUpperCase();
      
      let accountDetails = withdrawal.account_details;
      try {
        // Try to parse if it's JSON
        const parsed = JSON.parse(accountDetails);
        accountDetails = `${parsed.account_name || 'N/A'} | ${parsed.account_number || 'N/A'} | ${parsed.bank_name || 'N/A'}`;
      } catch (e) {
        // If not JSON, check if it's a serialized PHP array or just plain text
        if (accountDetails && accountDetails.includes('account_name')) {
          // Extract values from serialized format
          const nameMatch = accountDetails.match(/account_name["\s:]+([^";\s]+)/);
          const numberMatch = accountDetails.match(/account_number["\s:]+([^";\s]+)/);
          const bankMatch = accountDetails.match(/bank_name["\s:]+([^";\s]+)/);
          accountDetails = `${nameMatch ? nameMatch[1] : 'N/A'} | ${numberMatch ? numberMatch[1] : 'N/A'} | ${bankMatch ? bankMatch[1] : 'N/A'}`;
        }
      }
      document.getElementById('wr_account').textContent = accountDetails;
      
      document.getElementById('wr_status').textContent = withdrawal.status.toUpperCase();
      document.getElementById('wr_status').style.color = getStatusColorJS(withdrawal.status);
      document.getElementById('wr_requested').textContent = new Date(withdrawal.requested_at).toLocaleString();
      document.getElementById('wr_processed').textContent = withdrawal.processed_at ? new Date(withdrawal.processed_at).toLocaleString() : 'Pending';
      document.getElementById('wr_reference').textContent = 'WD-' + withdrawal.id;
      
      if (withdrawal.admin_notes) {
        document.getElementById('wr_notes_row').style.display = 'flex';
        document.getElementById('wr_notes').textContent = withdrawal.admin_notes;
      } else {
        document.getElementById('wr_notes_row').style.display = 'none';
      }
      
      document.getElementById('withdrawalReceiptModal').style.display = 'block';
    }

    function closeWithdrawalReceipt() {
      document.getElementById('withdrawalReceiptModal').style.display = 'none';
    }

    function openDepositReceipt(deposit) {
      document.getElementById('dr_amount').textContent = 'â‚¦' + parseFloat(deposit.amount).toLocaleString('en-NG', {minimumFractionDigits: 2});
      document.getElementById('dr_description').textContent = deposit.description;
      document.getElementById('dr_balance_type').textContent = deposit.balance_type.toUpperCase();
      document.getElementById('dr_date').textContent = new Date(deposit.created_at).toLocaleString();
      document.getElementById('dr_reference').textContent = deposit.reference_id || 'N/A';
      
      document.getElementById('depositReceiptModal').style.display = 'block';
    }

    function closeDepositReceipt() {
      document.getElementById('depositReceiptModal').style.display = 'none';
    }

    function getStatusColorJS(status) {
      const colors = {
        'completed': '#4DE1C1',
        'approved': '#4DE1C1',
        'processing': '#2C5CF0',
        'pending': '#FFC107',
        'rejected': '#FF3366',
        'failed': '#FF3366'
      };
      return colors[status] || '#FFC107';
    }

    function printReceipt() {
      window.print();
    }

    // Close modals when clicking outside
    window.onclick = function(event) {
      if (event.target.classList.contains('modal')) {
        event.target.style.display = 'none';
      }
    }
  </script>
</body>
</html>
