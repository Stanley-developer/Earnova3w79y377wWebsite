<?php
require_once 'config/database.php';
require_once 'includes/session.php';

// Require authentication
requireLogin();
checkSessionTimeout();

// Get current user data
$user = getCurrentUser();
$user_id = $user['id'];

try {
    $pdo = getDBConnection();
    
    // Fetch user details with balance
    $stmt = $pdo->prepare("SELECT u.*, b.total_balance, b.task_earnings, b.referral_earnings FROM users u LEFT JOIN balances b ON u.id = b.user_id WHERE u.id = ?");
    $stmt->execute([$user_id]);
    $user_data = $stmt->fetch();
    
    if (!$user_data) {
        header('Location: login.php');
        exit;
    }
    
    $is_premium = ($user_data['membership_type'] === 'premium');
    
    if (!$is_premium) {
        ?>
        <!DOCTYPE html>
        <html lang="en">
        <head>
          <meta charset="UTF-8" />
          <meta name="viewport" content="width=device-width, initial-scale=1.0" />
          <title>Spin & Win - FlowEarner</title>
          <style>
            :root {
              --page-blue-900: #030922;
              --page-blue-700: #0a164a;
              --page-blue-500: #142a7e;
              --page-mint: #4de1c1;
              --page-white: #f5f9ff;
              --page-orange: #fb923c;
            }

            * { box-sizing: border-box; margin: 0; padding: 0; }

            body {
              font-family: "Titillium Web", "Segoe UI", sans-serif;
              background: radial-gradient(circle at 0% 0%, rgba(61, 116, 255, 0.28), transparent 55%),
                          radial-gradient(circle at 100% 0%, rgba(77, 225, 193, 0.18), transparent 40%),
                          linear-gradient(180deg, var(--page-blue-900), var(--page-blue-700));
              color: var(--page-white);
              min-height: 100vh;
              display: flex;
              align-items: center;
              justify-content: center;
              padding: 20px;
            }

            .lock-overlay {
              position: fixed;
              top: 0;
              left: 0;
              width: 100vw;
              height: 100vh;
              background: rgba(5, 10, 25, 0.75);
              backdrop-filter: blur(6px);
              display: flex;
              justify-content: center;
              align-items: center;
              z-index: 9999;
              overflow: hidden;
            }

            body.locked {
              overflow: hidden;
              pointer-events: none;
            }

            .lock-container {
              position: relative;
              max-width: 600px;
              width: 90%;
              text-align: center;
              background: rgba(13, 24, 62, 0.95);
              backdrop-filter: blur(20px);
              border: 1px solid rgba(86, 139, 241, 0.3);
              border-radius: 24px;
              padding: clamp(32px, 5vw, 48px);
              box-shadow: 0 40px 120px rgba(4, 10, 36, 0.7);
              z-index: 10000;
            }

            .lock-icon {
              width: 120px;
              height: 120px;
              margin: 0 auto 24px;
              background: linear-gradient(135deg, rgba(251, 146, 60, 0.2), rgba(239, 68, 68, 0.2));
              border-radius: 50%;
              display: flex;
              align-items: center;
              justify-content: center;
              border: 3px solid rgba(251, 146, 60, 0.4);
            }

            .lock-icon svg {
              width: 60px;
              height: 60px;
              fill: var(--page-orange);
              filter: drop-shadow(0 4px 12px rgba(251, 146, 60, 0.5));
            }

            h1 {
              font-size: clamp(1.8rem, 4vw, 2.4rem);
              margin-bottom: 16px;
              color: var(--page-white);
              letter-spacing: 0.02em;
            }

            .lock-message {
              font-size: clamp(1rem, 2vw, 1.1rem);
              line-height: 1.7;
              color: rgba(216, 230, 255, 0.85);
              margin-bottom: 32px;
            }

            .feature-list {
              text-align: left;
              margin: 24px 0;
              padding: 24px;
              background: rgba(251, 146, 60, 0.08);
              border: 1px solid rgba(251, 146, 60, 0.25);
              border-radius: 16px;
            }

            .feature-list h3 {
              font-size: 1.2rem;
              margin-bottom: 16px;
              color: var(--page-orange);
              text-align: center;
            }

            .feature-list ul {
              list-style: none;
              padding: 0;
            }

            .feature-list li {
              display: flex;
              align-items: flex-start;
              gap: 12px;
              margin-bottom: 12px;
              font-size: 0.95rem;
              color: rgba(216, 230, 255, 0.9);
            }

            .feature-list li::before {
              content: "✓";
              display: inline-block;
              width: 24px;
              height: 24px;
              background: rgba(251, 146, 60, 0.3);
              color: var(--page-orange);
              border-radius: 50%;
              text-align: center;
              line-height: 24px;
              flex-shrink: 0;
              font-weight: bold;
            }

            .upgrade-btn {
              display: inline-block;
              padding: 16px 40px;
              background: linear-gradient(135deg, #fb923c, #f97316);
              color: var(--page-blue-900);
              font-size: 1.1rem;
              font-weight: 700;
              border: none;
              border-radius: 14px;
              cursor: pointer;
              text-decoration: none;
              transition: transform 0.3s ease, box-shadow 0.3s ease;
              box-shadow: 0 12px 28px rgba(251, 146, 60, 0.4);
              letter-spacing: 0.02em;
            }

            .upgrade-btn:hover {
              transform: translateY(-3px);
              box-shadow: 0 16px 36px rgba(251, 146, 60, 0.5);
            }

            .back-link {
              display: inline-block;
              margin-top: 24px;
              color: rgba(210, 226, 255, 0.7);
              text-decoration: none;
              font-size: 0.95rem;
              transition: color 0.3s ease;
            }

            .back-link:hover {
              color: var(--page-mint);
            }
          </style>
        </head>
        <body class="locked">
          <div class="lock-overlay">
            <div class="lock-container">
              <div class="lock-icon">
                <svg viewBox="0 0 24 24">
                  <path d="M12 2a5 5 0 0 1 5 5v3h1a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V12a2 2 0 0 1 2-2h1V7a5 5 0 0 1 5-5Zm0 2a3 3 0 0 0-3 3v3h6V7a3 3 0 0 0-3-3Zm-6 9v8h12v-8H6Zm6 2a2 2 0 1 1 0 4 2 2 0 0 1 0-4Z"/>
                </svg>
              </div>
              
              <h1>🎡 Spin & Win Access Locked</h1>
              
              <p class="lock-message">
                This game is exclusively available for <strong>Premium Members</strong>. Upgrade to Premium to unlock Spin & Win and start winning big rewards!
              </p>

              <div class="feature-list">
                <h3>Premium Benefits</h3>
                <ul>
                  <li>2 free spins daily (no balance required)</li>
                  <li>Win up to 10x your bet amount</li>
                  <li>Access to all premium games</li>
                  <li>Higher winning multipliers</li>
                  <li>Priority customer support</li>
                </ul>
              </div>
            
              <a href="membership.php" class="upgrade-btn">Upgrade to Premium Now</a>
              
              <br>
              <a href="play-earn.php" class="back-link">← Back to Games</a>
            </div>
          </div>
        </body>
        </html>
        <?php
        exit;
    }
    
    $today = date('Y-m-d');
    if ($user_data['spin_win_last_reset'] !== $today) {
        $stmt = $pdo->prepare("UPDATE users SET spin_win_free_plays = 2, spin_win_last_reset = ? WHERE id = ?");
        $stmt->execute([$today, $user_id]);
        $user_data['spin_win_free_plays'] = 2;
    }
    
} catch (PDOException $e) {
    error_log("Spin & Win Error: " . $e->getMessage());
    $error_message = "Unable to load game data.";
}

$task_earnings = $user_data['task_earnings'] ?? 0;
$free_spins = $user_data['spin_win_free_plays'] ?? 0;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Spin & Win - FlowEarner</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
            background: linear-gradient(135deg, #0a0e27 0%, #1a1f3a 50%, #0f1429 100%);
            color: #fff;
            min-height: 100vh;
            overflow-x: hidden;
        }
        
        .container {
            max-width: 1400px;
            margin: 0 auto;
            padding: 20px;
        }
        
        .header {
            text-align: center;
            padding: 30px 20px;
            background: linear-gradient(135deg, rgba(255, 107, 107, 0.15), rgba(255, 145, 77, 0.15));
            border-radius: 25px;
            margin-bottom: 30px;
            border: 2px solid rgba(255, 145, 77, 0.3);
            box-shadow: 0 0 50px rgba(255, 145, 77, 0.2);
        }
        
        .header h1 {
            font-size: 3rem;
            margin-bottom: 10px;
            background: linear-gradient(135deg, #ff6b6b, #ff914d);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            text-shadow: 0 0 30px rgba(255, 145, 77, 0.5);
        }
        
        .header p {
            font-size: 1.2rem;
            color: rgba(255, 255, 255, 0.7);
        }
        
        .game-container {
            display: grid;
            grid-template-columns: 1fr 400px;
            gap: 30px;
            margin-bottom: 30px;
        }
        
        .wheel-section {
            background: linear-gradient(135deg, rgba(26, 58, 171, 0.3), rgba(5, 16, 58, 0.5));
            border: 2px solid rgba(255, 145, 77, 0.3);
            border-radius: 25px;
            padding: 40px;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            position: relative;
            overflow: hidden;
        }
        
        .wheel-section::before {
            content: '';
            position: absolute;
            top: -50%;
            left: -50%;
            width: 200%;
            height: 200%;
            background: radial-gradient(circle, rgba(255, 145, 77, 0.1) 0%, transparent 70%);
            animation: pulse 4s ease-in-out infinite;
        }
        
        @keyframes pulse {
            0%, 100% { transform: scale(1); opacity: 0.5; }
            50% { transform: scale(1.1); opacity: 0.8; }
        }
        
        .wheel-container {
            position: relative;
            width: 500px;
            height: 500px;
            z-index: 1;
        }
        
        .wheel {
            width: 100%;
            height: 100%;
            border-radius: 50%;
            position: relative;
            transition: transform 4s cubic-bezier(0.17, 0.67, 0.12, 0.99);
            box-shadow: 0 0 0 15px rgba(255, 145, 77, 0.3),
                        0 0 0 20px rgba(255, 145, 77, 0.2),
                        0 0 60px rgba(255, 145, 77, 0.4);
        }
        
        .wheel-segment {
            position: absolute;
            width: 50%;
            height: 50%;
            transform-origin: 100% 100%;
            clip-path: polygon(0 0, 100% 0, 100% 100%);
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        .wheel-segment span {
            position: absolute;
            top: 30%;
            left: 60%;
            transform: rotate(22.5deg);
            font-size: 1.5rem;
            font-weight: 900;
            color: #fff;
            text-shadow: 0 2px 10px rgba(0, 0, 0, 0.5);
        }
        
        .wheel-pointer {
            position: absolute;
            top: -30px;
            left: 50%;
            transform: translateX(-50%);
            width: 0;
            height: 0;
            border-left: 20px solid transparent;
            border-right: 20px solid transparent;
            border-top: 40px solid #ff914d;
            filter: drop-shadow(0 5px 15px rgba(255, 145, 77, 0.8));
            z-index: 10;
        }
        
        .wheel-center {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            width: 80px;
            height: 80px;
            background: linear-gradient(135deg, #ff6b6b, #ff914d);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 2rem;
            box-shadow: 0 0 30px rgba(255, 145, 77, 0.8);
            z-index: 5;
        }
        
        .controls-section {
            background: linear-gradient(135deg, rgba(26, 58, 171, 0.3), rgba(5, 16, 58, 0.5));
            border: 2px solid rgba(255, 145, 77, 0.3);
            border-radius: 25px;
            padding: 30px;
            display: flex;
            flex-direction: column;
            gap: 20px;
        }
        
        .balance-card {
            background: rgba(255, 145, 77, 0.1);
            border: 2px solid rgba(255, 145, 77, 0.3);
            border-radius: 15px;
            padding: 20px;
        }
        
        .balance-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 15px;
        }
        
        .balance-item:last-child {
            margin-bottom: 0;
        }
        
        .balance-label {
            color: rgba(255, 255, 255, 0.7);
            font-size: 0.95rem;
        }
        
        .balance-value {
            font-size: 1.3rem;
            font-weight: 700;
            color: #ff914d;
        }
        
        .bet-input {
            width: 100%;
            padding: 18px;
            border-radius: 12px;
            border: 2px solid rgba(255, 145, 77, 0.3);
            background: rgba(255, 255, 255, 0.05);
            color: #fff;
            font-size: 1.1rem;
            transition: all 0.3s ease;
        }
        
        .bet-input:focus {
            outline: none;
            border-color: rgba(255, 145, 77, 0.6);
            box-shadow: 0 0 20px rgba(255, 145, 77, 0.3);
        }
        
        .spin-btn {
            width: 100%;
            padding: 20px;
            border-radius: 15px;
            border: none;
            background: linear-gradient(135deg, #ff6b6b, #ff914d);
            color: #fff;
            font-size: 1.3rem;
            font-weight: 700;
            cursor: pointer;
            transition: all 0.3s ease;
            box-shadow: 0 5px 30px rgba(255, 145, 77, 0.4);
            position: relative;
            overflow: hidden;
        }
        
        .spin-btn::before {
            content: '';
            position: absolute;
            top: 50%;
            left: 50%;
            width: 0;
            height: 0;
            border-radius: 50%;
            background: rgba(255, 255, 255, 0.3);
            transform: translate(-50%, -50%);
            transition: width 0.6s, height 0.6s;
        }
        
        .spin-btn:hover::before {
            width: 300px;
            height: 300px;
        }
        
        .spin-btn:hover {
            transform: translateY(-3px);
            box-shadow: 0 8px 40px rgba(255, 145, 77, 0.6);
        }
        
        .spin-btn:disabled {
            opacity: 0.5;
            cursor: not-allowed;
            transform: none;
        }
        
        .spin-btn span {
            position: relative;
            z-index: 1;
        }
        
        .free-spin-btn {
            background: linear-gradient(135deg, #4de1c1, #2c5bf5);
        }
        
        .multipliers-info {
            background: rgba(255, 255, 255, 0.05);
            border-radius: 15px;
            padding: 20px;
        }
        
        .multipliers-info h3 {
            margin-bottom: 15px;
            color: #ff914d;
            font-size: 1.2rem;
        }
        
        .multiplier-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 10px;
            font-size: 0.95rem;
        }
        
        .multiplier-item {
            display: flex;
            justify-content: space-between;
            padding: 8px 12px;
            background: rgba(255, 255, 255, 0.05);
            border-radius: 8px;
        }
        
        .multiplier-item.jackpot {
            grid-column: 1 / -1;
            background: linear-gradient(135deg, rgba(255, 215, 0, 0.2), rgba(255, 145, 77, 0.2));
            border: 1px solid rgba(255, 215, 0, 0.4);
        }
        
        .leaderboard {
            background: linear-gradient(135deg, rgba(26, 58, 171, 0.3), rgba(5, 16, 58, 0.5));
            border: 2px solid rgba(255, 145, 77, 0.3);
            border-radius: 25px;
            padding: 30px;
        }
        
        .leaderboard h2 {
            margin-bottom: 25px;
            font-size: 2rem;
            background: linear-gradient(135deg, #ff6b6b, #ff914d);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }
        
        .leaderboard-list {
            display: flex;
            flex-direction: column;
            gap: 15px;
        }
        
        .leaderboard-item {
            display: grid;
            grid-template-columns: 50px 60px 1fr auto auto;
            gap: 15px;
            align-items: center;
            background: rgba(255, 255, 255, 0.05);
            padding: 15px;
            border-radius: 15px;
            border: 1px solid rgba(255, 145, 77, 0.2);
            transition: all 0.3s ease;
        }
        
        .leaderboard-item:hover {
            background: rgba(255, 255, 255, 0.1);
            border-color: rgba(255, 145, 77, 0.5);
            transform: translateX(5px);
        }
        
        .rank {
            font-size: 1.5rem;
            font-weight: 700;
            color: #ff914d;
        }
        
        .rank.gold { color: #ffd700; }
        .rank.silver { color: #c0c0c0; }
        .rank.bronze { color: #cd7f32; }
        
        .player-avatar {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            border: 2px solid rgba(255, 145, 77, 0.5);
        }
        
        .player-info {
            display: flex;
            flex-direction: column;
        }
        
        .player-name {
            font-weight: 700;
            font-size: 1.1rem;
        }
        
        .player-username {
            color: rgba(255, 255, 255, 0.6);
            font-size: 0.9rem;
        }
        
        .stat {
            text-align: right;
        }
        
        .stat-label {
            color: rgba(255, 255, 255, 0.6);
            font-size: 0.8rem;
        }
        
        .stat-value {
            font-weight: 700;
            color: #ff914d;
            font-size: 1.1rem;
        }
        
        /* Custom notification popup styles */
        .notification-overlay {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.8);
            backdrop-filter: blur(8px);
            z-index: 10001;
            animation: fadeIn 0.3s ease;
        }
        
        .notification-overlay.active {
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        .notification-popup {
            background: linear-gradient(135deg, rgba(26, 58, 171, 0.98), rgba(5, 16, 58, 0.98));
            border: 3px solid rgba(255, 145, 77, 0.5);
            border-radius: 25px;
            padding: 40px;
            text-align: center;
            box-shadow: 0 0 80px rgba(255, 145, 77, 0.6);
            animation: popIn 0.4s cubic-bezier(0.68, -0.55, 0.265, 1.55);
            min-width: 400px;
            max-width: 500px;
        }
        
        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }
        
        @keyframes popIn {
            0% { transform: scale(0.5); opacity: 0; }
            100% { transform: scale(1); opacity: 1; }
        }
        
        .notification-popup.error {
            border-color: rgba(255, 59, 48, 0.6);
            box-shadow: 0 0 80px rgba(255, 59, 48, 0.6);
        }
        
        .notification-popup.success {
            border-color: rgba(77, 225, 193, 0.6);
            box-shadow: 0 0 80px rgba(77, 225, 193, 0.6);
        }
        
        .notification-popup.warning {
            border-color: rgba(255, 159, 10, 0.6);
            box-shadow: 0 0 80px rgba(255, 159, 10, 0.6);
        }
        
        .notification-icon {
            width: 100px;
            height: 100px;
            margin: 0 auto 25px;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        .notification-icon svg {
            width: 100%;
            height: 100%;
            filter: drop-shadow(0 0 20px currentColor);
            animation: iconPulse 2s ease-in-out infinite;
        }
        
        @keyframes iconPulse {
            0%, 100% { transform: scale(1); }
            50% { transform: scale(1.1); }
        }
        
        .notification-title {
            font-size: 2rem;
            font-weight: 700;
            margin-bottom: 15px;
            color: #fff;
        }
        
        .notification-message {
            font-size: 1.15rem;
            color: rgba(255, 255, 255, 0.85);
            line-height: 1.6;
            margin-bottom: 30px;
        }
        
        .notification-btn {
            padding: 15px 40px;
            border-radius: 12px;
            border: none;
            background: linear-gradient(135deg, #ff6b6b, #ff914d);
            color: #fff;
            font-size: 1.1rem;
            font-weight: 700;
            cursor: pointer;
            transition: all 0.3s ease;
            box-shadow: 0 5px 20px rgba(255, 145, 77, 0.4);
        }
        
        .notification-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(255, 145, 77, 0.6);
        }
        
        .notification-btn.error-btn {
            background: linear-gradient(135deg, #ff3b30, #ff6b6b);
        }
        
        .notification-btn.success-btn {
            background: linear-gradient(135deg, #4de1c1, #2c5bf5);
        }
        
        .notification-btn.warning-btn {
            background: linear-gradient(135deg, #ff9f0a, #ffb340);
        }
        
        /* Result popup */
        .result-popup {
            background: linear-gradient(135deg, rgba(26, 58, 171, 0.98), rgba(5, 16, 58, 0.98));
            border: 3px solid rgba(255, 145, 77, 0.5);
            border-radius: 25px;
            padding: 50px;
            text-align: center;
            box-shadow: 0 0 100px rgba(255, 145, 77, 0.8);
            animation: popIn 0.5s cubic-bezier(0.68, -0.55, 0.265, 1.55);
            min-width: 450px;
        }
        
        .result-icon {
            font-size: 6rem;
            margin-bottom: 20px;
            animation: bounce 1s infinite;
        }
        
        @keyframes bounce {
            0%, 100% { transform: translateY(0); }
            50% { transform: translateY(-20px); }
        }
        
        .result-text {
            font-size: 2.5rem;
            font-weight: 900;
            margin-bottom: 20px;
            background: linear-gradient(135deg, #ff6b6b, #ff914d);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }
        
        .result-amount {
            font-size: 4rem;
            font-weight: 900;
            color: #4de1c1;
            margin-bottom: 30px;
            text-shadow: 0 0 30px rgba(77, 225, 193, 0.8);
        }
        
        .result-buttons {
            display: flex;
            gap: 15px;
            justify-content: center;
        }
        
        .result-btn {
            padding: 18px 35px;
            border-radius: 15px;
            border: none;
            font-size: 1.2rem;
            font-weight: 700;
            cursor: pointer;
            transition: all 0.3s ease;
        }
        
        .claim-btn {
            background: linear-gradient(135deg, #4de1c1, #2c5bf5);
            color: #fff;
            box-shadow: 0 5px 25px rgba(77, 225, 193, 0.4);
        }
        
        .claim-btn:hover {
            transform: translateY(-3px);
            box-shadow: 0 8px 30px rgba(77, 225, 193, 0.6);
        }
        
        .spin-again-btn {
            background: rgba(255, 255, 255, 0.1);
            color: #fff;
            border: 2px solid rgba(255, 255, 255, 0.3);
        }
        
        .spin-again-btn:hover {
            background: rgba(255, 255, 255, 0.2);
            transform: translateY(-3px);
        }
        
        @media (max-width: 1024px) {
            .game-container {
                grid-template-columns: 1fr;
            }
            
            .wheel-container {
                width: 400px;
                height: 400px;
            }
            
            .notification-popup,
            .result-popup {
                min-width: 90%;
                max-width: 90%;
                padding: 30px 25px;
            }
        }
        
        @media (max-width: 768px) {
            .wheel-container {
                width: 300px;
                height: 300px;
            }
            
            .wheel-center {
                width: 60px;
                height: 60px;
                font-size: 1.5rem;
            }
            
            .wheel-segment span {
                font-size: 1rem;
            }
            
            .leaderboard-item {
                grid-template-columns: 40px 50px 1fr;
            }
            
            .stat {
                display: none;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🎡 Spin & Win</h1>
            <p>Spin the wheel and win amazing rewards!</p>
        </div>
        
        <div class="game-container">
            <div class="wheel-section">
                <div class="wheel-container">
                    <div class="wheel-pointer"></div>
                    <div class="wheel" id="wheel">
                       <!-- Wheel segments will be generated by JavaScript -->
                    </div>
                    <div class="wheel-center">🎡</div>
                </div>
            </div>
            
            <div class="controls-section">
                <div class="balance-card">
                    <div class="balance-item">
                        <span class="balance-label">Task Balance:</span>
                        <span class="balance-value" id="taskBalance">₦<?php echo number_format($task_earnings, 2); ?></span>
                    </div>
                    <div class="balance-item">
                        <span class="balance-label">Free Spins:</span>
                        <span class="balance-value" id="freeSpins"><?php echo $free_spins; ?>/2</span>
                    </div>
                </div>
                
                <input type="number" class="bet-input" id="betAmount" placeholder="Enter bet amount (Min: ₦1,000)" min="1000" step="100" value="1000">
                
                <button class="spin-btn free-spin-btn" id="freeSpinBtn" onclick="spin(true)" <?php echo $free_spins <= 0 ? 'disabled' : ''; ?>>
                    <span>Free Spin (<?php echo $free_spins; ?> left)</span>
                </button>
                
                <button class="spin-btn" id="betSpinBtn" onclick="spin(false)">
                    <span> Spin with Bet (Min: ₦1,000)</span>
                </button>
                
                <div class="multipliers-info">
                    <h3>Prize Multipliers</h3>
                    <div class="multiplier-grid">
                        <div class="multiplier-item"><span>0.5x</span><span>25%</span></div>
                        <div class="multiplier-item"><span>1.0x</span><span>20%</span></div>
                        <div class="multiplier-item"><span>1.5x</span><span>20%</span></div>
                        <div class="multiplier-item"><span>2.0x</span><span>15%</span></div>
                        <div class="multiplier-item"><span>3.0x</span><span>10%</span></div>
                        <div class="multiplier-item"><span>5.0x</span><span>7%</span></div>
                        <div class="multiplier-item jackpot"><span>10.0x 🎰</span><span>3%</span></div>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="leaderboard">
            <h2>🏆 Top Spinners</h2>
            <div class="leaderboard-list" id="leaderboardList">
                <div style="text-align: center; padding: 20px; color: rgba(255, 255, 255, 0.5);">
                    Loading leaderboard...
                </div>
            </div>
        </div>
    </div>
    
     Custom notification overlay and popup 
    <div class="notification-overlay" id="notificationOverlay" onclick="closeNotification()">
        <div class="notification-popup" id="notificationPopup" onclick="event.stopPropagation()">
            <div class="notification-icon" id="notificationIcon"></div>
            <div class="notification-title" id="notificationTitle"></div>
            <div class="notification-message" id="notificationMessage"></div>
            <button class="notification-btn" id="notificationBtn" onclick="closeNotification()">Got it!</button>
        </div>
    </div>
    
     Result overlay 
    <div class="notification-overlay" id="resultOverlay" onclick="closeResult()">
        <div class="result-popup" id="resultPopup" onclick="event.stopPropagation()">
            <div class="result-icon" id="resultIcon">🎉</div>
            <div class="result-text" id="resultText">You Won!</div>
            <div class="result-amount" id="resultAmount">₦0.00</div>
            <div class="result-buttons">
                <button class="result-btn claim-btn" onclick="closeResult()">✓ Claim Reward</button>
                <button class="result-btn spin-again-btn" onclick="spinAgain()">🔄 Spin Again</button>
            </div>
        </div>
    </div>
    
    <script>
        let isSpinning = false;
        const multipliers = [0.5, 1.0, 1.5, 2.0, 3.0, 5.0, 10.0, 0.5];
        const colors = ['#ff6b6b', '#ff914d', '#ffd93d', '#6bcf7f', '#4de1c1', '#2c5bf5', '#a855f7', '#ff6b6b'];
        
        function initWheel() {
            const wheel = document.getElementById('wheel');
            const segmentAngle = 360 / multipliers.length;
            
            multipliers.forEach((multiplier, index) => {
                const segment = document.createElement('div');
                segment.className = 'wheel-segment';
                segment.style.background = colors[index];
                segment.style.transform = `rotate(${index * segmentAngle}deg)`;
                
                const label = document.createElement('span');
                label.textContent = multiplier + 'x';
                segment.appendChild(label);
                
                wheel.appendChild(segment);
            });
        }
        
        function showNotification(title, message, type = 'info') {
            const overlay = document.getElementById('notificationOverlay');
            const popup = document.getElementById('notificationPopup');
            const icon = document.getElementById('notificationIcon');
            const titleEl = document.getElementById('notificationTitle');
            const messageEl = document.getElementById('notificationMessage');
            const btn = document.getElementById('notificationBtn');
            
            titleEl.textContent = title;
            messageEl.textContent = message;
            
            popup.className = 'notification-popup';
            btn.className = 'notification-btn';
            
            if (type === 'error') {
                popup.classList.add('error');
                btn.classList.add('error-btn');
                icon.innerHTML = `
                    <svg viewBox="0 0 24 24" fill="none" stroke="#ff3b30" stroke-width="2.5">
                        <circle cx="12" cy="12" r="10"/>
                        <line x1="15" y1="9" x2="9" y2="15"/>
                        <line x1="9" y1="9" x2="15" y2="15"/>
                    </svg>
                `;
            } else if (type === 'success') {
                popup.classList.add('success');
                btn.classList.add('success-btn');
                icon.innerHTML = `
                    <svg viewBox="0 0 24 24" fill="none" stroke="#4de1c1" stroke-width="2.5">
                        <circle cx="12" cy="12" r="10"/>
                        <polyline points="9 12 11 14 15 10"/>
                    </svg>
                `;
            } else if (type === 'warning') {
                popup.classList.add('warning');
                btn.classList.add('warning-btn');
                icon.innerHTML = `
                    <svg viewBox="0 0 24 24" fill="none" stroke="#ff9f0a" stroke-width="2.5">
                        <path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/>
                        <line x1="12" y1="9" x2="12" y2="13"/>
                        <line x1="12" y1="17" x2="12.01" y2="17"/>
                    </svg>
                `;
            } else {
                icon.innerHTML = `
                    <svg viewBox="0 0 24 24" fill="none" stroke="#ff914d" stroke-width="2.5">
                        <circle cx="12" cy="12" r="10"/>
                        <line x1="12" y1="16" x2="12" y2="12"/>
                        <line x1="12" y1="8" x2="12.01" y2="8"/>
                    </svg>
                `;
            }
            
            overlay.classList.add('active');
        }
        
        function closeNotification() {
            document.getElementById('notificationOverlay').classList.remove('active');
        }
        
        async function spin(isFree) {
            if (isSpinning) return;
            
            const betAmount = isFree ? 0 : parseFloat(document.getElementById('betAmount').value);
            
            if (!isFree && (isNaN(betAmount) || betAmount < 1000)) {
                showNotification(
                    'Invalid Bet Amount',
                    'Please enter a valid bet amount. The minimum bet is ₦1,000.',
                    'warning'
                );
                return;
            }
            
            isSpinning = true;
            document.getElementById('freeSpinBtn').disabled = true;
            document.getElementById('betSpinBtn').disabled = true;
            
            const wheel = document.getElementById('wheel');
            const randomRotation = 360 * 5 + Math.random() * 360;
            wheel.style.transform = `rotate(${randomRotation}deg)`;
            
            setTimeout(async () => {
                try {
                    const response = await fetch('api/spin-win-play.php', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({
                            bet_amount: betAmount,
                            is_free_play: isFree
                        })
                    });
                    
                    const data = await response.json();
                    
                    if (data.success) {
                        document.getElementById('taskBalance').textContent = '₦' + parseFloat(data.new_balance).toFixed(2);
                        document.getElementById('freeSpins').textContent = data.free_spins_remaining + '/2';
                        
                        const freeSpinBtn = document.getElementById('freeSpinBtn');
                        const betSpinBtn = document.getElementById('betSpinBtn');
                        
                        if (data.free_spins_remaining <= 0) {
                            freeSpinBtn.disabled = true;
                            freeSpinBtn.innerHTML = '<span>🎁 No Free Spins Left</span>';
                        } else {
                            freeSpinBtn.disabled = false;
                            freeSpinBtn.innerHTML = `<span>🎁 Free Spin (${data.free_spins_remaining} left)</span>`;
                        }
                        
                        if (data.new_balance < 1000) {
                            betSpinBtn.disabled = true;
                            betSpinBtn.title = 'Insufficient balance (Min: ₦1,000)';
                        } else {
                            betSpinBtn.disabled = false;
                            betSpinBtn.title = '';
                        }
                        
                        showResult(data.win_amount, data.multiplier);
                        loadLeaderboard();
                    } else {
                        showNotification(
                            'Oops!',
                            data.message || 'An error occurred. Please try again.',
                            'error'
                        );
                    }
                } catch (error) {
                    console.error('Error:', error);
                    showNotification(
                        'Connection Error',
                        'Unable to connect to the server. Please check your internet connection.',
                        'error'
                    );
                }
                
                isSpinning = false;
                const freeSpinsRemaining = parseInt(document.getElementById('freeSpins').textContent.split('/')[0]);
                const currentBalance = parseFloat(document.getElementById('taskBalance').textContent.replace('₦', '').replace(',', ''));
                
                document.getElementById('freeSpinBtn').disabled = freeSpinsRemaining <= 0;
                document.getElementById('betSpinBtn').disabled = currentBalance < 1000;
            }, 4000);
        }
        
        function showResult(amount, multiplier) {
            const overlay = document.getElementById('resultOverlay');
            const icon = document.getElementById('resultIcon');
            const text = document.getElementById('resultText');
            const amountEl = document.getElementById('resultAmount');
            
            if (multiplier >= 10) {
                icon.textContent = '🎰';
                text.textContent = 'JACKPOT!!!';
            } else if (multiplier >= 5) {
                icon.textContent = '💎';
                text.textContent = 'MEGA WIN!';
            } else if (multiplier >= 2) {
                icon.textContent = '🎉';
                text.textContent = 'BIG WIN!';
            } else if (multiplier > 1) {
                icon.textContent = '✨';
                text.textContent = 'You Won!';
            } else {
                icon.textContent = '😔';
                text.textContent = 'Try Again!';
            }
            
            amountEl.textContent = '₦' + parseFloat(amount).toFixed(2);
            overlay.classList.add('active');
        }
        
        function closeResult() {
            document.getElementById('resultOverlay').classList.remove('active');
        }
        
        function spinAgain() {
            closeResult();
        }
        
        async function loadLeaderboard() {
            try {
                const response = await fetch('api/spin-win-leaderboard.php');
                const data = await response.json();
                
                if (data.success && data.leaderboard.length > 0) {
                    const leaderboardList = document.getElementById('leaderboardList');
                    leaderboardList.innerHTML = data.leaderboard.map((player, index) => `
                        <div class="leaderboard-item">
                            <div class="rank ${index === 0 ? 'gold' : index === 1 ? 'silver' : index === 2 ? 'bronze' : ''}">#${index + 1}</div>
                            <img src="${player.profile_picture || 'front/assets/images/default-avatar.png'}" alt="${player.username}" class="player-avatar">
                            <div class="player-info">
                                <div class="player-name">${player.full_name || player.username}</div>
                                <div class="player-username">@${player.username}</div>
                            </div>
                            <div class="stat">
                                <div class="stat-label">Profit</div>
                                <div class="stat-value">₦${parseFloat(player.total_profit).toFixed(2)}</div>
                            </div>
                            <div class="stat">
                                <div class="stat-label">Spins</div>
                                <div class="stat-value">${player.total_spins}</div>
                            </div>
                        </div>
                    `).join('');
                } else {
                    document.getElementById('leaderboardList').innerHTML = '<div style="text-align: center; padding: 20px; color: rgba(255, 255, 255, 0.5);">No players yet. Be the first!</div>';
                }
            } catch (error) {
                console.error('Error loading leaderboard:', error);
            }
        }
        
        // Initialize on page load
        initWheel();
        loadLeaderboard();
        
        const freeSpins = parseInt(document.getElementById('freeSpins').textContent.split('/')[0]);
        const taskBalance = parseFloat(document.getElementById('taskBalance').textContent.replace('₦', '').replace(',', ''));
        
        document.getElementById('freeSpinBtn').disabled = freeSpins <= 0;
        document.getElementById('betSpinBtn').disabled = taskBalance < 1000;
    </script>
</body>
</html>
