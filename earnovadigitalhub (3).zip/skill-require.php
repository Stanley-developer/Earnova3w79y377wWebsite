<?php
require_once 'config/database.php';
require_once 'includes/session.php';
require_once 'includes/connect.php';

// Require authentication
requireLogin();
checkSessionTimeout();

// Get current user data
$user = getCurrentUser();
$user_id = $user['id'];

// Handle AJAX request for terms agreement
if (isset($_POST['ajax']) && $_POST['ajax'] == '1' && isset($_POST['action']) && $_POST['action'] == 'agree_terms') {
    header('Content-Type: application/json');
    $_SESSION['skill_terms_agreed'] = true;
    echo json_encode(['success' => true]);
    exit;
}

// Check if user has agreed to skill center terms
$skill_agreed = isset($_SESSION['skill_terms_agreed']) && $_SESSION['skill_terms_agreed'] === true;

try {
    $pdo = getDBConnection();
    
    // Fetch user details
    $stmt = $pdo->prepare("
        SELECT u.*, b.total_balance, b.task_earnings, b.referral_earnings
        FROM users u
        LEFT JOIN balances b ON u.id = b.user_id
        WHERE u.id = ?
    ");
    $stmt->execute([$user_id]);
    $user_data = $stmt->fetch();
    
    if (!$user_data) {
        header('Location: login.php');
        exit;
    }
    
    $is_premium = ($user_data['membership_type'] === 'premium');
    
    // Handle search
    $search_query = isset($_GET['search']) ? trim($_GET['search']) : '';
    
    // Fetch skills
    if (!empty($search_query)) {
        $stmt = $pdo->prepare("
            SELECT * FROM skills 
            WHERE is_active = 1 
            AND (title LIKE ? OR description LIKE ? OR professor_name LIKE ?)
            ORDER BY created_at DESC
        ");
        $search_param = "%{$search_query}%";
        $stmt->execute([$search_param, $search_param, $search_param]);
    } else {
        $stmt = $pdo->query("
            SELECT * FROM skills 
            WHERE is_active = 1 
            ORDER BY created_at DESC
        ");
    }
    $skills = $stmt->fetchAll();
    
} catch (PDOException $e) {
    error_log("Skill Center Error: " . $e->getMessage());
    $error_message = "Unable to load skills data.";
}

$username = htmlspecialchars($user_data['username'] ?? 'User');
$membership_status = $is_premium ? 'Premium Member' : 'Free Member';
?>
<?php include "doctype.php"; ?>
  <link rel="stylesheet" href="assets/css/gamified-fintech-theme.css" />
  <style>
    :root {
      --page-blue-900: #030922;
      --page-blue-700: #0a164a;
      --page-blue-500: #142a7e;
      --page-mint: #4de1c1;
      --page-white: #f5f9ff;
      --panel-glass: rgba(13, 24, 62, 0.78);
      --panel-border: rgba(86, 139, 241, 0.28);
      --shadow-heavy: 0 40px 120px rgba(4, 10, 36, 0.65);
    }

    * { box-sizing: border-box; }

    body {
      margin: 0;
      font-family: "Titillium Web", "Segoe UI", sans-serif;
      background: #030922;
      color: var(--page-white);
      overflow-x: hidden;
      padding-bottom: 100px;
    }

    .page-shell {
      min-height: 100vh;
      display: flex;
    }

    aside {
      position: fixed;
      left: 0;
      top: 0;
      bottom: 0;
      width: 320px;
      background: var(--panel-glass);
      backdrop-filter: blur(18px);
      padding: 28px 24px;
      display: flex;
      flex-direction: column;
      gap: 24px;
      border-right: 1px solid var(--panel-border);
      overflow-y: auto;
      z-index: 100;
    }

    main {
      margin-left: 320px;
      flex: 1;
      padding: 32px 40px;
    }

    .back-link {
      display: inline-flex;
      align-items: center;
      gap: 8px;
      font-weight: 600;
      letter-spacing: 0.06em;
      text-transform: uppercase;
      font-size: 0.8rem;
      color: #f5f9ff;
      text-decoration: none;
      transition: color 0.3s, transform 0.3s;
    }

    .back-link:hover {
      color: var(--page-white);
      transform: translateX(-4px);
    }

    .aside-welcome {
      display: grid;
      grid-template-columns: auto 1fr;
      align-items: center;
      gap: 14px;
      background: linear-gradient(135deg, rgba(44, 91, 245, 0.3), rgba(26, 58, 171, 0.2));
      border: 1px solid rgba(44, 91, 245, 0.5);
      border-radius: 18px;
      padding: 16px;
      box-shadow: 0 0 10px rgba(44, 91, 245, 0.6);
    }

    .aside-avatar {
      width: 56px;
      height: 56px;
      border-radius: 50%;
      overflow: hidden;
      border: 3px solid rgba(77, 225, 193, 0.45);
    }

    .aside-avatar img {
      width: 100%;
      display: block;
    }

    .welcome-tag {
      margin: 0;
      font-size: 0.75rem;
      letter-spacing: 0.1em;
      text-transform: uppercase;
      color: rgba(211, 227, 255, 0.7);
    }

    .aside-welcome h3 {
      margin: 5px 0 3px;
      font-size: 1.12rem;
      color: var(--page-white);
    }

    .welcome-meta {
      font-size: 0.8rem;
      color: rgba(196, 216, 255, 0.75);
    }

    .page-title {
      font-size: 1.5rem;
      letter-spacing: 0.08em;
      text-transform: uppercase;
      margin: 0 0 8px;
      color: #f5f9ff;
    }

    .side-description {
      color: rgba(216, 230, 255, 0.78);
      line-height: 1.6;
      font-size: 0.95rem;
    }

    .search-section {
      margin-bottom: 32px;
    }

    .search-form {
      display: flex;
      gap: 12px;
      max-width: 600px;
    }

    .search-input {
      flex: 1;
      padding: 14px 20px;
      border: 1px solid var(--panel-border);
      border-radius: 12px;
      background: var(--panel-glass);
      color: var(--page-white);
      font-size: 1rem;
      font-family: inherit;
      transition: border-color 0.3s;
    }

    .search-input:focus {
      outline: none;
      border-color: var(--page-mint);
    }

    .search-input::placeholder {
      color: rgba(216, 230, 255, 0.5);
    }

    .search-btn {
      padding: 14px 28px;
      background: linear-gradient(135deg, var(--page-mint), #3bc9a8);
      color: var(--page-blue-900);
      border: none;
      border-radius: 12px;
      font-weight: 700;
      font-size: 1rem;
      cursor: pointer;
      transition: transform 0.3s, box-shadow 0.3s;
      box-shadow: 0 8px 20px rgba(77, 225, 193, 0.3);
    }

    .search-btn:hover {
      transform: translateY(-2px);
      box-shadow: 0 12px 28px rgba(77, 225, 193, 0.4);
    }

    .skills-grid {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(320px, 1fr));
      gap: 24px;
    }

    .skill-card {
      background: var(--panel-glass);
      border: 1px solid var(--panel-border);
      border-radius: 20px;
      overflow: hidden;
      box-shadow: var(--shadow-heavy);
      transition: transform 0.3s, box-shadow 0.3s;
      position: relative;
    }

    .skill-card:hover {
      transform: translateY(-4px);
      box-shadow: 0 20px 60px rgba(77, 225, 193, 0.2);
    }

    .skill-image {
      position: relative;
      width: 100%;
      height: 200px;
      overflow: hidden;
      background: linear-gradient(135deg, rgba(44, 91, 245, 0.3), rgba(26, 58, 171, 0.2));
    }

    .skill-image img {
      width: 100%;
      height: 100%;
      object-fit: cover;
    }

    .skill-badges {
      position: absolute;
      top: 12px;
      left: 12px;
      right: 12px;
      display: flex;
      justify-content: space-between;
      align-items: flex-start;
      gap: 8px;
    }

    .promo-badge {
      padding: 6px 14px;
      background: linear-gradient(135deg, #fb923c, #f97316);
      color: var(--page-blue-900);
      border-radius: 20px;
      font-size: 0.75rem;
      font-weight: 700;
      text-transform: uppercase;
      letter-spacing: 0.05em;
      box-shadow: 0 4px 12px rgba(251, 146, 60, 0.4);
    }

    .active-badge {
      padding: 6px 14px;
      background: rgba(77, 225, 193, 0.9);
      color: var(--page-blue-900);
      border-radius: 20px;
      font-size: 0.75rem;
      font-weight: 700;
      box-shadow: 0 4px 12px rgba(77, 225, 193, 0.4);
    }

    .skill-content {
      padding: 20px;
    }

    .skill-professor {
      font-size: 0.85rem;
      color: var(--page-mint);
      margin-bottom: 8px;
      font-weight: 600;
    }

    .skill-title {
      font-size: 1.3rem;
      margin: 0 0 12px;
      color: var(--page-white);
      font-weight: 700;
    }

    .skill-description {
      font-size: 0.95rem;
      color: rgba(216, 230, 255, 0.78);
      line-height: 1.6;
      margin-bottom: 16px;
    }

    .skill-footer {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding-top: 16px;
      border-top: 1px solid rgba(86, 139, 241, 0.2);
    }

    .skill-clicks {
      font-size: 0.85rem;
      color: rgba(216, 230, 255, 0.6);
      display: flex;
      align-items: center;
      gap: 6px;
    }

    .skill-link-btn {
      padding: 10px 20px;
      background: linear-gradient(135deg, var(--page-mint), #3bc9a8);
      color: var(--page-blue-900);
      border: none;
      border-radius: 10px;
      font-weight: 700;
      font-size: 0.9rem;
      cursor: pointer;
      text-decoration: none;
      display: inline-block;
      transition: transform 0.3s, box-shadow 0.3s;
      box-shadow: 0 4px 12px rgba(77, 225, 193, 0.3);
    }

    .skill-link-btn:hover {
      transform: translateY(-2px);
      box-shadow: 0 6px 16px rgba(77, 225, 193, 0.4);
    }

    .empty-state {
      text-align: center;
      padding: 80px 20px;
      color: rgba(216, 230, 255, 0.6);
    }

    .empty-state svg {
      width: 120px;
      height: 120px;
      margin-bottom: 24px;
      opacity: 0.3;
    }

    .empty-state h3 {
      font-size: 1.5rem;
      margin-bottom: 12px;
      color: rgba(216, 230, 255, 0.8);
    }

    /* Updated mobile footer with 5 icons */
    .mobile-fintech-footer {
      display: none;
      position: fixed;
      left: 12px;
      right: 12px;
      bottom: 16px;
      padding: 10px;
      background: transparent;
      border: 1px solid rgba(86, 139, 241, 0.35);
      border-radius: 32px;
      backdrop-filter: blur(50px);
      box-shadow: 0 20px 60px rgba(4, 10, 36, 0.7);
      justify-content: space-around;
      align-items: center;
      z-index: 90;
    }

    .mobile-fintech-footer a {
      flex: 1;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      gap: 4px;
      text-decoration: none;
      color: rgba(205, 219, 255, 0.75);
      font-size: 0.45rem;
      letter-spacing: 0.06em;
      text-transform: uppercase;
      transition: all var(--transition-short);
      padding: 8px 4px;
      border-radius: 16px;
    }

    .mobile-fintech-footer a.active {
      color: var(--page-mint);
    }

    .mobile-fintech-footer svg {
      width: 22px;
      height: 22px;
      fill: currentColor;
    }

    @media (max-width: 960px) {
      .page-shell {
        display: block;
      }

      aside {
        position: relative;
        width: 100%;
        height: auto;
        border-right: none;
        border-bottom: 1px solid var(--panel-border);
      }

      main {
        margin-left: 0;
        padding: 24px 16px 120px;
      }

      .skills-grid {
        grid-template-columns: repeat(1, 1fr);
        gap: 16px;
      }

      .skill-card {
        font-size: 0.9rem;
      }

      .skill-image {
        height: 150px;
      }

      .skill-title {
        font-size: 1.1rem;
      }

      .mobile-fintech-footer {
        display: flex;
      }
    }

    @media (max-width: 600px) {
     
    }

     .rewards-hero {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
      gap: clamp(1.25rem, 2.5vw, 1.75rem);
      align-items: center;
      background: var(--panel-glass);
      border-radius: 26px;
      border: 1px solid var(--panel-border);
      padding: clamp(1.75rem, 3vw, 2.375rem);
      box-shadow: var(--shadow-heavy);
      position: relative;
      overflow: hidden;
    }

    .rewards-hero::before {
      content: "";
      position: absolute;
      inset: 0;
      background: url("front/assets/images/header-right-img.png") right/contain no-repeat;
      opacity: 0.08;
      pointer-events: none;
    }

    .premium-lock-modal {
      display: none;
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: rgba(0, 0, 0, 0.5);
      justify-content: center;
      align-items: center;
      z-index: 1000;
    }

    .premium-lock-modal.active {
      display: flex;
    }

    .premium-lock-content {
      background: var(--panel-glass);
      border-radius: 20px;
      padding: 24px;
      text-align: center;
      color: var(--page-white);
    }

    .premium-lock-header svg {
      margin-bottom: 16px;
    }

    .premium-lock-title {
      font-size: 1.5rem;
      margin-bottom: 8px;
    }

    .premium-lock-text {
      font-size: 0.9rem;
      margin-bottom: 24px;
    }

    .premium-lock-buttons {
      display: flex;
      gap: 12px;
      justify-content: center;
    }

    .premium-upgrade-btn, .premium-cancel-btn {
      padding: 12px 24px;
      background: linear-gradient(135deg, var(--page-mint), #3bc9a8);
      color: var(--page-blue-900);
      border: none;
      border-radius: 10px;
      font-weight: 700;
      font-size: 0.9rem;
      cursor: pointer;
      text-decoration: none;
      transition: transform 0.3s, box-shadow 0.3s;
      box-shadow: 0 4px 12px rgba(77, 225, 193, 0.3);
    }

    .premium-upgrade-btn:hover, .premium-cancel-btn:hover {
      transform: translateY(-2px);
      box-shadow: 0 6px 16px rgba(77, 225, 193, 0.4);
    }

    /* Skill Center Terms Modal Styles - Matching perform-task.php exactly */
    .ts-modal {
      display: none;
      position: fixed;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      background: rgba(3, 9, 34, 0.9);
      backdrop-filter: blur(8px);
      z-index: 2500;
      align-items: center;
      justify-content: center;
      padding: 20px;
      z-index: 99999;
    }

    .ts-modal.active {
      display: flex;
    }

    .ts-modal-content {
      background: rgba(6, 16, 48, 0.98);
      border: 1px solid rgba(100, 154, 255, 0.3);
      border-radius: 24px;
      padding: 32px;
      max-width: 600px;
      width: 100%;
      max-height: 80vh;
      overflow-y: auto;
      display: flex;
      flex-direction: column;
    }

    .ts-modal-header {
      margin-bottom: 24px;
      border-bottom: 1px solid rgba(100, 154, 255, 0.2);
      padding-bottom: 16px;
    }

    .ts-modal-header h2 {
      margin: 0;
      font-size: 1.5rem;
      color: var(--page-white);
    }

    .ts-modal-body {
      flex: 1;
      overflow-y: auto;
      margin-right: 8px;
      padding-right: 8px;
    }

    .ts-modal-body::-webkit-scrollbar {
      width: 6px;
    }

    .ts-modal-body::-webkit-scrollbar-track {
      background: rgba(100, 154, 255, 0.1);
      border-radius: 3px;
    }

    .ts-modal-body::-webkit-scrollbar-thumb {
      background: rgba(77, 225, 193, 0.3);
      border-radius: 3px;
    }

    .ts-modal-body::-webkit-scrollbar-thumb:hover {
      background: rgba(77, 225, 193, 0.5);
    }

    .ts-modal-body h3 {
      color: var(--page-white);
      margin-top: 20px;
      margin-bottom: 12px;
      font-size: 1.1rem;
    }

    .ts-modal-body p {
      color: rgba(205, 219, 255, 0.8);
      line-height: 1.6;
      margin-bottom: 12px;
      font-size: 0.95rem;
    }

    .ts-modal-body ul {
      color: rgba(205, 219, 255, 0.8);
      line-height: 1.6;
      margin-bottom: 12px;
      margin-left: 20px;
      font-size: 0.95rem;
    }

    .ts-modal-body li {
      margin-bottom: 8px;
    }

    .ts-modal-footer {
      display: flex;
      gap: 12px;
      justify-content: flex-end;
      align-items: center;
      border-top: 1px solid rgba(100, 154, 255, 0.2);
      padding-top: 20px;
    }

    .ts-checkbox-container {
      display: flex;
      align-items: center;
      gap: 8px;
    }

    .ts-checkbox {
      width: 20px;
      height: 20px;
      cursor: pointer;
      accent-color: var(--page-mint);
    }

    .ts-checkbox-label {
      color: rgba(205, 219, 255, 0.8);
      font-size: 0.9rem;
      cursor: pointer;
    }

    .ts-modal-actions {
      display: flex;
      gap: 12px;
      justify-content: flex-end;
    }

    .ts-checkbox-wrapper {
      background: rgba(77, 225, 193, 0.08);
      border: 1px solid rgba(77, 225, 193, 0.3);
      border-radius: 12px;
      padding: 16px;
      margin-bottom: 24px;
      display: flex;
      align-items: center;
      gap: 12px;
    }

    .ts-checkbox-wrapper input[type="checkbox"]:disabled {
      opacity: 0.5;
      cursor: not-allowed;
    }

    .ts-checkbox-wrapper input[type="checkbox"]:disabled + label {
      opacity: 0.5;
      cursor: not-allowed;
    }

    .btn-primary {
      padding: 12px 28px;
      background: linear-gradient(135deg, #4de1c1, #3bb89f);
      color: #030922;
      border: none;
      border-radius: 10px;
      font-size: 1rem;
      font-weight: 600;
      cursor: pointer;
      transition: all 0.3s ease;
      box-shadow: 0 4px 15px rgba(77, 225, 193, 0.3);
    }

    .btn-primary:hover {
      transform: translateY(-2px);
      box-shadow: 0 6px 20px rgba(77, 225, 193, 0.4);
    }

    .btn-secondary {
      padding: 12px 28px;
      background: rgba(100, 154, 255, 0.15);
      color: #f5f9ff;
      border: 1px solid rgba(100, 154, 255, 0.3);
      border-radius: 10px;
      font-size: 1rem;
      font-weight: 600;
      cursor: pointer;
      transition: all 0.3s ease;
    }

    .btn-secondary:hover {
      background: rgba(100, 154, 255, 0.25);
      transform: translateY(-2px);
    }

    .alert-message {
      position: fixed;
      top: 20px;
      right: 20px;
      padding: 16px 24px;
      border-radius: 12px;
      font-weight: 600;
      z-index: 100000;
      transform: translateX(120%);
      transition: transform 0.3s ease;
    }

    .alert-message.show {
      transform: translateX(0);
    }

    .alert-success {
      background: linear-gradient(135deg, rgba(77, 225, 193, 0.95), rgba(59, 185, 159, 0.95));
      color: #030922;
    }

    .alert-error {
      background: linear-gradient(135deg, rgba(255, 107, 107, 0.95), rgba(220, 53, 69, 0.95));
      color: #fff;
    }
  </style>

<body>


<?php include "header2.php"; ?>
<?php include "embed.php"; ?>

  <!-- Skill Center Terms & Instructions Modal -->
  <div class="ts-modal" id="tsModal">
    <div class="ts-modal-content">
      <div class="ts-modal-header">
        <h2>Skill Center Guidelines</h2>
      </div>
      <div class="ts-modal-body">
        <p><strong>Earnova Digital – 2025 Skill Center Terms</strong></p>

        <h3>1. Introduction</h3>
        <p>Welcome to our Skill Center. By accessing our learning resources, you agree to comply with and be bound by these Terms and Services. If you do not agree with any part of these terms, please do not use our platform.</p>

        <h3>2. User Responsibilities</h3>
        <p>As a learner, you are responsible for:</p>
        <ul>
          <li>Using learning materials for personal educational purposes only</li>
          <li>Not sharing or redistributing premium content</li>
          <li>Respecting intellectual property rights of course creators</li>
          <li>Maintaining the confidentiality of your account credentials</li>
          <li>Providing honest feedback and reviews</li>
        </ul>

        <h3>3. Premium Access Requirements</h3>
        <p>When accessing premium content:</p>
        <ul>
          <li>Premium membership is required for exclusive courses</li>
          <li>Access is granted to the registered account holder only</li>
          <li>Content may not be downloaded or reproduced without permission</li>
          <li>Premium benefits are non-transferable</li>
        </ul>

        <h3>4. Course Content and Quality</h3>
        <p>Regarding our courses:</p>
        <ul>
          <li>Courses are created by verified professors and experts</li>
          <li>Content is regularly updated to maintain relevance</li>
          <li>We strive to ensure accuracy but cannot guarantee results</li>
          <li>External links are provided for convenience only</li>
        </ul>

        <h3>5. Prohibited Activities</h3>
        <p>You agree not to:</p>
        <ul>
          <li>Share your account credentials with others</li>
          <li>Attempt to bypass premium access restrictions</li>
          <li>Copy, modify, or distribute course materials</li>
          <li>Use automated tools to access content</li>
          <li>Engage in any activity that disrupts the platform</li>
          <li>Misrepresent your identity or qualifications</li>
        </ul>

        <h3>6. Intellectual Property</h3>
        <p>All content on the Skill Center is protected by:</p>
        <ul>
          <li>Copyright and intellectual property laws</li>
          <li>Course creators retain ownership of their materials</li>
          <li>Earnova Digital holds platform-wide content rights</li>
          <li>Unauthorized use may result in legal action</li>
        </ul>

        <h3>7. Liability Disclaimer</h3>
        <p>The platform is provided "as is" without warranties. We are not liable for:</p>
        <ul>
          <li>Results or outcomes from applying learned skills</li>
          <li>Accuracy of third-party content or links</li>
          <li>Technical issues or platform downtime</li>
          <li>Changes to course availability or content</li>
        </ul>

        <h3>8. Changes to Terms</h3>
        <p>We reserve the right to modify these terms at any time. Your continued use of the platform constitutes acceptance of any changes.</p>

        <h3>9. Contact Information</h3>
        <p>For questions or concerns, please contact our support team through the help section of your account.</p>

        <h3>10. Skills Center Content & Course Submission</h3>
        <p>We welcome high-quality educational content from qualified instructors and professionals. If you have courses, tutorials, or learning materials you'd like to share with our community, we'd be happy to review your submission.</p>

        <div style="
          background: linear-gradient(135deg, rgba(77, 225, 193, 0.15) 0%, rgba(99, 102, 241, 0.15) 100%);
          border: 1px solid rgba(77, 225, 193, 0.3);
          border-radius: 12px;
          padding: 20px;
          margin: 16px 0;
          backdrop-filter: blur(10px);
        ">
          <div style="display: flex; align-items: flex-start; gap: 12px;">
            <div style="flex: 1; display: flex; flex-direction: column; align-items: flex-start;">
              <h4 style="color: #f5f9ff; margin: 0 0 8px 0; font-size: 1rem;">Skills Center Course Submission Notice</h4>
              <p style="color: rgba(205, 219, 255, 0.8); margin: 0 0 12px 0; font-size: 0.95rem; line-height: 1.5;">
                All courses and learning materials in the Skills Center are manually posted by our team. We ensure quality and relevance before publication.<br><br>
                If you would like your skill training, course, or educational content to be listed here, please contact our Support Team for approval and posting instructions.
              </p>
              <a href="https://t.me/earnovadigitalhub" target="_blank" style="
                display: inline-block;
                background: linear-gradient(135deg, #4DE1C1 0%, #3BC9B0 100%);
                color: #030922;
                padding: 10px 20px;
                border-radius: 8px;
                text-decoration: none;
                font-weight: 600;
                font-size: 0.95rem;
                transition: all 0.3s ease;
                border: none;
                cursor: pointer;
              " onmouseover="this.style.opacity='0.9'; this.style.transform='translateY(-2px)';" onmouseout="this.style.opacity='1'; this.style.transform='translateY(0)';">
                Message Us on Telegram
              </a>
            </div>
          </div>
        </div>
      </div>
      <div class="ts-modal-footer">
        <div class="ts-checkbox-wrapper" style="margin-bottom: 0;">
          <input type="checkbox" id="tsCheckbox" class="ts-checkbox" <?php echo $skill_agreed ? 'checked disabled' : ''; ?>>
          <label for="tsCheckbox" class="ts-checkbox-label"><span style="font-size: 13px;">I agree</span></label>
        </div>
        <div class="ts-modal-actions">
          <button class="btn-secondary" id="tsCloseBtn" onclick="closeTSModal()" style="<?php echo $skill_agreed ? 'display: block;' : 'display: none;'; ?>">Close</button>
          <button class="btn-primary" id="tsAgreeBtn" onclick="agreeTSAndClose()" style="<?php echo $skill_agreed ? 'display: none;' : 'display: block;'; ?>">Agree & Continue</button>
        </div>
      </div>
    </div>
  </div>

    <main>
        <section class="rewards-hero" style="background: linear-gradient(135deg, rgba(77, 225, 193, 0.08), rgba(13, 24, 62, 0.78));">
        <div class="rewards-copy">
          <h1 style="font-size: clamp(1rem, 3vw, 1.5rem);">Skill Center</h1>
          <p style="font-size: 12px;">Explore exclusive learning opportunities from top professors and industry experts. Enhance your skills with premium courses and tutorials.</p>
          <!-- Added clickable checkbox to view skill center guidelines -->
          <div style="background: rgba(77, 225, 193, 0.08); border: 1px solid rgba(77, 225, 193, 0.3); border-radius: 12px; padding: 16px; margin-top: 16px; display: flex; align-items: center; gap: 12px; cursor: pointer;" onclick="openTSModal()">
            <input type="checkbox" id="skillHeroCheckbox" style="width: 20px; height: 20px; cursor: pointer; accent-color: var(--page-mint);" onclick="event.stopPropagation(); openTSModal();">
            <label for="skillHeroCheckbox" style="color: rgba(205, 219, 255, 0.8); font-size: 0.9rem; cursor: pointer; margin: 0;">View Skill Center Guidelines</label>
          </div>
        </div>
      </section>
      <section class="search-section" style="margin-top: 17px;">
        <form method="GET" class="search-form">
          <input 
            type="text" 
            name="search" 
            class="search-input" 
            placeholder="Search skills, professors, or topics..." 
            value="<?php echo htmlspecialchars($search_query); ?>"
          >
          <button type="submit" class="search-btn">Search</button>
        </form>
      </section>

      <?php if (empty($skills)): ?>
        <div class="empty-state">
          <svg viewBox="0 0 24 24" fill="currentColor">
            <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 18c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8zm-1-13h2v6h-2zm0 8h2v2h-2z"/>
          </svg>
          <h3>No Skills Available</h3>
          <p><?php echo !empty($search_query) ? 'No skills found matching your search.' : 'Check back soon for new learning opportunities!'; ?></p>
        </div>
      <?php else: ?>
        <section class="skills-grid">
          <?php foreach ($skills as $skill): ?>
            <article class="skill-card">
              <div class="skill-image">
                <?php if (!empty($skill['image_url'])): ?>
                  <img src="<?php echo htmlspecialchars($skill['image_url']); ?>" alt="<?php echo htmlspecialchars($skill['title']); ?>">
                <?php endif; ?>
                <div class="skill-badges">
                  <?php if (!empty($skill['promo_badge'])): ?>
                    <span class="promo-badge"><?php echo htmlspecialchars($skill['promo_badge']); ?></span>
                  <?php endif; ?>
                  <?php if (!empty($skill['active_hours'])): ?>
                    <span class="active-badge">Active for <?php echo $skill['active_hours']; ?>h</span>
                  <?php endif; ?>
                </div>
              </div>
              <div class="skill-content">
                <?php if (!empty($skill['professor_name'])): ?>
                  <div class="skill-professor">Prof. <?php echo htmlspecialchars($skill['professor_name']); ?></div>
                <?php endif; ?>
                <h3 class="skill-title"><?php echo htmlspecialchars($skill['title']); ?></h3>
                <?php if (!empty($skill['description'])): ?>
                  <p class="skill-description"><?php echo htmlspecialchars($skill['description']); ?></p>
                <?php endif; ?>
                <div class="skill-footer">
                  <a 
                    href="<?php echo htmlspecialchars($skill['external_link']); ?>" 
                    target="_blank" 
                    class="skill-link-btn"
                    onclick="<?php if (!$is_premium) { echo "event.preventDefault(); showPremiumLockModal(); return false;"; } else { echo "trackClick(" . $skill['id'] . ");"; } ?>"
                  >
                    Learn More →
                  </a>
                </div>
              </div>
            </article>
          <?php endforeach; ?>
        </section>
      <?php endif; ?>
    </main>
  </div>
  <nav class="mobile-fintech-footer">
    
  <a href="dashboard.php">
    <svg viewBox="0 0 24 24"><path d="M12 3a9 9 0 1 1 0 18 9 9 0 0 1 0-18Zm1 4h-2v6h6v-2h-4V7Z"/></svg>
    <span>Dashboard</span>
  </a>

  <!-- Premium (crown icon) -->
  <a href="membership.php">
    <svg viewBox="0 0 24 24"><path d="M5 7l2.5 5 4.5-4 4.5 4L19 7l2 13H3l2-13Z"/></svg>
    <span>Premium</span>
  </a>

  <a href="post-task.php">
<svg viewBox="0 0 24 24" aria-hidden="true">
  <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8l-6-6Zm1 14h-3v3h-2v-3H7v-2h3v-3h2v3h3v2Zm-3-9V3.5L18.5 8H12Z"/>
</svg>
    
    <span>Advert Post</span>
  </a>
  
  

  <a href="history.php">
  <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
    <path d="M13 3a9 9 0 1 0 9 9h-2a7 7 0 1 1-7-7V3l4 4-4 4V7a5 5 0 1 0 5 5h2a7 7 0 1 1-7-7z"/>
  </svg>
  <span>History</span>
</a>


  <a href="profile.php">
    <svg viewBox="0 0 24 24"><path d="M12 2a6 6 0 0 1 6 6c0 3.31-2.69 6-6 6s-6-2.69-6-6a6 6 0 0 1 6-6Zm0 14c4.42 0 8 1.79 8 4v2H4v-2c0-2.21 3.58-4 8-4Z"/></svg>
    <span>Profile</span>
  </a>
</nav>

  <script>
    function trackClick(skillId) {
      // Track click via API
      fetch('api/skill-click.php', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ skill_id: skillId })
      }).catch(err => console.error('Click tracking failed:', err));
    }

    function showPremiumLockModal() {
      const modal = document.getElementById('premiumLockModal');
      if (modal) {
        modal.classList.add('active');
      }
    }

    function closePremiumLockModal() {
      const modal = document.getElementById('premiumLockModal');
      if (modal) {
        modal.classList.remove('active');
      }
    }

    // Close modal when clicking outside
    window.addEventListener('click', (e) => {
      const modal = document.getElementById('premiumLockModal');
      if (modal && e.target === modal) {
        closePremiumLockModal();
      }
    });

    // Skill Center Terms Modal Functions - Matching perform-task.php exactly
    function openTSModal() {
      const modal = document.getElementById('tsModal');
      if (modal) {
        modal.classList.add('active');
      }
    }

    function closeTSModal() {
      const modal = document.getElementById('tsModal');
      if (modal) {
        modal.classList.remove('active');
      }
      // Ensure checkbox is checked and buttons are reset if modal is closed without agreeing
      const tsCheckbox = document.getElementById('tsCheckbox');
      const tsAgreeBtn = document.getElementById('tsAgreeBtn');
      const tsCloseBtn = document.getElementById('tsCloseBtn');

      if (tsCheckbox && !tsCheckbox.disabled) { // Only reset if not permanently agreed
        tsCheckbox.checked = false;
        if(tsAgreeBtn) tsAgreeBtn.style.display = 'block';
        if(tsCloseBtn) tsCloseBtn.style.display = 'none';
      }
    }

    function agreeTSAndClose() {
      // Set checkbox as checked
      const tsCheckbox = document.getElementById('tsCheckbox');
      if(tsCheckbox) tsCheckbox.checked = true;
      
      // Disable checkbox and buttons after agreeing
      if(tsCheckbox) tsCheckbox.disabled = true;
      const tsAgreeBtn = document.getElementById('tsAgreeBtn');
      const tsCloseBtn = document.getElementById('tsCloseBtn');
      if(tsAgreeBtn) tsAgreeBtn.style.display = 'none';
      if(tsCloseBtn) tsCloseBtn.style.display = 'block';
      
      // Send AJAX request to store agreement in session
      fetch('skill-require.php', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: 'ajax=1&action=agree_terms'
      })
      .then(response => response.json())
      .then(data => {
        if (data.success) {
          // Reload the page after successful agreement
          showToast('Skill Center Guidelines accepted!', 'success');
          setTimeout(() => {
            window.location.reload();
          }, 500);
        } else {
          // Re-enable buttons if AJAX fails
          if(tsCheckbox) tsCheckbox.disabled = false;
          if(tsCheckbox) tsCheckbox.checked = false;
          if(tsAgreeBtn) tsAgreeBtn.style.display = 'block';
          if(tsCloseBtn) tsCloseBtn.style.display = 'none';
          showToast('Failed to save agreement. Please try again.', 'error');
        }
      })
      .catch(error => {
        console.error('Error agreeing to T&S:', error);
        // Re-enable buttons if AJAX fails
        if(tsCheckbox) tsCheckbox.disabled = false;
        if(tsCheckbox) tsCheckbox.checked = false;
        if(tsAgreeBtn) tsAgreeBtn.style.display = 'block';
        if(tsCloseBtn) tsCloseBtn.style.display = 'none';
        showToast('Failed to save agreement. Please try again.', 'error');
      });
    }

    function showToast(message, type = 'info') {
      const toast = document.createElement('div');
      toast.className = `alert-message alert-${type}`;
      toast.textContent = message;
      document.body.appendChild(toast);

      setTimeout(() => {
        toast.classList.add('show');
      }, 50);

      setTimeout(() => {
        toast.classList.remove('show');
        setTimeout(() => toast.remove(), 600);
      }, 4000);
    }

    // Show modal on first visit if not agreed
    document.addEventListener('DOMContentLoaded', function() {
      <?php if (!$skill_agreed): ?>
      openTSModal();
      <?php endif; ?>
    });
  </script>

  <!-- Premium lock modal for free users -->
  <div id="premiumLockModal" class="premium-lock-modal">
    <div class="premium-lock-content">
      <div class="premium-lock-header">
        <svg width="60" height="60" viewBox="0 0 24 24" fill="none">
          <rect x="3" y="13" width="18" height="8" rx="2" stroke="currentColor" stroke-width="2"/>
          <path d="M7 13V9C7 5.13 9.13 3 12 3C14.87 3 17 5.13 17 9V13" stroke="currentColor" stroke-width="2"/>
          <circle cx="12" cy="17" r="1.5" fill="currentColor"/>
        </svg>
      </div>
      <h2 class="premium-lock-title">Premium Feature</h2>
      <p class="premium-lock-text">This learning resource is exclusively available for Premium Members. Upgrade your membership to unlock premium courses and resources.</p>
      <div class="premium-lock-buttons">
        <a href="membership.php" class="premium-upgrade-btn">Upgrade to Premium</a>
        <button onclick="closePremiumLockModal()" class="premium-cancel-btn">Maybe Later</button>
      </div>
    </div>
  </div>
</body>
</html>
