<?php
require_once 'config/database.php';
require_once 'includes/session.php';
require_once 'includes/connect.php';

// Require authentication
requireLogin();
checkSessionTimeout();

// Get current user data
$user = getCurrentUser();
$user_id = $user['id'];

try {
    $pdo = getDBConnection();
    
    // Fetch user details with balance
    $stmt = $pdo->prepare("SELECT u.*, b.total_balance, b.task_earnings, b.referral_earnings FROM users u LEFT JOIN balances b ON u.id = b.user_id WHERE u.id = ?");
    $stmt->execute([$user_id]);
    $user_data = $stmt->fetch();
    
    if (!$user_data) {
        header('Location: login.php');
        exit;
    }
    
    $is_premium = ($user_data['membership_type'] === 'premium');
    
    // Reset free plays if it's a new day
    $today = date('Y-m-d');
    if ($user_data['plinko_last_reset'] !== $today) {
        $stmt = $pdo->prepare("UPDATE users SET plinko_free_plays = 2, plinko_last_reset = ? WHERE id = ?");
        $stmt->execute([$today, $user_id]);
        $user_data['plinko_free_plays'] = 2;
    }
    
} catch (PDOException $e) {
    error_log("Play & Earn Error: " . $e->getMessage());
    $error_message = "Unable to load game data.";
}

$task_earnings = $user_data['task_earnings'] ?? 0;
$referral_earnings = $user_data['referral_earnings'] ?? 0;
$free_plays = $user_data['plinko_free_plays'] ?? 0;
$membership_type = $user_data['membership_type'] ?? 'free';
?>
<?php include "doctype.php"; ?>
<?php include "embed.php"; ?>
<link rel="stylesheet" href="assets/css/gamified-fintech-theme.css">
    <style>
        :root {
            --page-blue-900: #030922;
            --page-blue-700: #0a164a;
            --page-blue-500: #142a7e;
            --page-mint: #4de1c1;
            --page-white: #f5f9ff;
            --page-orange: #fb923c;
            --page-gold: #fbbf24;
        }

        * { box-sizing: border-box; margin: 0; padding: 0; }

        body {
            font-family: "Titillium Web", "Segoe UI", sans-serif;
            background: var(--bg-primary);
            color: var(--page-white);
            min-height: 100vh;
            padding-bottom: 120px;
        }
        
        .container {
            max-width: 1400px;
            margin: 0 auto;
            padding: 20px;
        }
        
        .page-header {
            text-align: center;
            padding: 40px 20px;
           background: rgba(77, 225, 193, 0.1); border-radius: 12px; border: 1px solid rgba(77, 225, 193, 0.2);
            border-radius: 20px;
            margin-bottom: 30px;
           
        }
        
        .page-header h1 {
            font-size: clamp(2rem, 5vw, 3rem);
            margin: 0 0 10px;
            background: linear-gradient(135deg, #2c5bf5, #4de1c1);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }
        
        .page-header p {
            font-size: clamp(1rem, 2vw, 1.2rem);
            color: rgba(255, 255, 255, 0.7);
        }
        
        /* Game Cards Grid */
        .games-grid {
            display: grid;
            /* Updated to 3 columns for horizontal layout */
            grid-template-columns: repeat(3, 1fr);
            gap: 24px;
            margin-bottom: 40px;
        }
        
        .game-card {
            background: linear-gradient(135deg, rgba(26, 58, 171, 0.4), rgba(5, 16, 58, 0.6));
            border: 2px solid rgba(77, 225, 193, 0.3);
            border-radius: 20px;
            padding: 0;
            text-align: center;
            cursor: pointer;
            transition: all 0.3s ease;
            position: relative;
            overflow: hidden;
            text-decoration: none;
            display: block;
        }
        
      .game-card img {
          width: 100%;
    height: 150px;
}

        
        /* Added locked card state */
        .game-card.locked-game {
            cursor: not-allowed;
            opacity: 0.8;
        }
        
        .game-card.locked-game:hover {
            transform: none;
            box-shadow: none;
        }

        .game-image {
            width: 100%;
            height: 200px;
            object-fit: cover;
            border-radius: 18px 18px 0 0;
        }
        
        .game-info {
            padding: 20px;
        }
        
        .game-title {
            font-size: 1.1rem;
            font-weight: 700;
            margin-bottom: 10px;
            color: var(--page-white);
        }
        
        .game-description {
            font-size: 0.9rem;
            color: rgba(255, 255, 255, 0.7);
            margin-bottom: 15px;
        }
        
        .game-status {
            display: inline-block;
            padding: 8px 20px;
            border-radius: 20px;
            font-size: 0.9rem;
            font-weight: 600;
        }
        
        .game-status.unlocked {
            background: rgba(77, 225, 193, 0.2);
            color: #4de1c1;
            border: 1px solid rgba(77, 225, 193, 0.5);
        }
        
        .game-status.locked {
            background: rgba(251, 146, 60, 0.2);
            color: #fb923c;
            border: 1px solid rgba(251, 146, 60, 0.5);
        }
        
        /* Added coming soon status */
        .game-status.coming-soon {
            background: rgba(148, 163, 184, 0.2);
            color: #94a3b8;
            border: 1px solid rgba(148, 163, 184, 0.5);
        }
        
        /* Added locked message overlay */
        .locked-message {
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(3, 9, 34, 0.85);
            backdrop-filter: blur(5px);
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            padding: 20px;
            border-radius: 20px;
        }
        
        .locked-message svg {
            width: 60px;
            height: 60px;
            fill: #94a3b8;
            margin-bottom: 15px;
        }
        
        .locked-message h3 {
            font-size: 1.3rem;
            color: #94a3b8;
            margin-bottom: 8px;
        }
        
        .locked-message p {
            font-size: 0.9rem;
            color: rgba(148, 163, 184, 0.7);
        }

        /* Premium Lock Modal */
        .lock-modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.8);
            backdrop-filter: blur(10px);
            z-index: 9999;
            justify-content: center;
            align-items: center;
            padding: 20px;
        }
        
        .lock-modal.active {
            display: flex;
        }
        
        .lock-content {
            max-width: 500px;
            width: 100%;
            background: linear-gradient(135deg, rgba(26, 58, 171, 0.95), rgba(5, 16, 58, 0.95));
            border: 3px solid rgba(251, 191, 36, 0.5);
            border-radius: 24px;
            padding: 40px;
            text-align: center;
            box-shadow: 0 0 80px rgba(251, 191, 36, 0.6);
        }
        
        .lock-icon {
            width: 100px;
            height: 100px;
            margin: 0 auto 20px;
            background: linear-gradient(135deg, rgba(251, 191, 36, 0.3), rgba(245, 158, 11, 0.3));
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            border: 3px solid rgba(251, 191, 36, 0.5);
        }
        
        .lock-icon svg {
            width: 50px;
            height: 50px;
            fill: var(--page-gold);
        }
        
        .lock-content h2 {
            font-size: 2rem;
            margin-bottom: 15px;
            color: var(--page-white);
        }
        
        .lock-content p {
            font-size: 1.1rem;
            color: rgba(255, 255, 255, 0.8);
            margin-bottom: 30px;
            line-height: 1.6;
        }
        
        .free-user-content {
      background: rgba(6, 16, 48, 0.98);
      border: 1px solid rgba(100, 154, 255, 0.3);
      border-radius: 24px;
      padding: 32px;
      max-width: 500px;
      width: 100%;
      text-align: center;
    }
    
    .free-user-content svg {
      width: 80px;
      height: 80px;
      margin-bottom: 24px;
      color: #fbbf24;
    }
    
    .free-user-content h2 {
      margin: 0 0 16px;
      font-size: 1.5rem;
      color: var(--page-white);
    }
    
    .free-user-content p {
      color: rgba(205, 219, 255, 0.7);
      line-height: 1.7;
      margin-bottom: 24px;
    }
    
    .upgrade-btn {
      display: inline-block;
      padding: 14px 32px;
      background: linear-gradient(135deg, #fbbf24, #f59e0b);
      color: #000;
      border-radius: 12px;
      text-decoration: none;
      font-weight: 700;
      font-size: 1rem;
      text-transform: uppercase;
      letter-spacing: 0.05em;
      transition: all 0.3s ease;
      margin-right: 12px;
    }
    
    .upgrade-btn:hover {
      transform: translateY(-2px);
      box-shadow: 0 8px 24px rgba(251, 191, 36, 0.4);
    }
    
    .close-modal-btn {
      display: inline-block;
      padding: 14px 32px;
      background: rgba(100, 154, 255, 0.2);
      color: var(--page-white);
      border-radius: 12px;
      text-decoration: none;
      font-weight: 600;
      font-size: 1rem;
      cursor: pointer;
      transition: all 0.3s ease;
    }
    
    .close-modal-btn:hover {
      background: rgba(100, 154, 255, 0.3);
    }
        
      
        
        /* Coming Soon Modal Styles */
        .coming-soon-modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.8);
            backdrop-filter: blur(10px);
            z-index: 9999;
            justify-content: center;
            align-items: center;
            padding: 20px;
        }
        
        .coming-soon-modal.active {
            display: flex;
        }
        
        .coming-soon-content {
            max-width: 500px;
            width: 100%;
            background: linear-gradient(135deg, rgba(26, 58, 171, 0.95), rgba(5, 16, 58, 0.95));
            border: 3px solid rgba(77, 225, 193, 0.5);
            border-radius: 24px;
            padding: 40px;
            text-align: center;
            box-shadow: 0 0 80px rgba(77, 225, 193, 0.6);
            animation: slideUp 0.4s ease;
        }
        
        @keyframes slideUp {
            from {
                opacity: 0;
                transform: translateY(30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        .coming-soon-icon {
            width: 100px;
            height: 100px;
            margin: 0 auto 20px;
            background: linear-gradient(135deg, rgba(77, 225, 193, 0.3), rgba(44, 91, 245, 0.3));
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            border: 3px solid rgba(77, 225, 193, 0.5);
        }
        
        .coming-soon-icon svg {
            width: 50px;
            height: 50px;
            fill: var(--page-mint);
        }
        
        .coming-soon-content h2 {
            font-size: 2rem;
            margin-bottom: 15px;
            color: var(--page-white);
        }
        
        .coming-soon-content p {
            font-size: 1.1rem;
            color: rgba(255, 255, 255, 0.8);
            margin-bottom: 30px;
            line-height: 1.6;
        }
        
        .ok-btn {
            display: inline-block;
            padding: 16px 40px;
            background: linear-gradient(135deg, #4de1c1, #2c5bf5);
            color: var(--page-white);
            font-size: 1.1rem;
            font-weight: 700;
            border: none;
            border-radius: 14px;
            cursor: pointer;
            text-decoration: none;
            transition: all 0.3s ease;
            box-shadow: 0 10px 30px rgba(77, 225, 193, 0.4);
        }
        
        .ok-btn:hover {
            transform: translateY(-3px);
            box-shadow: 0 15px 40px rgba(77, 225, 193, 0.6);
        }
        
        /* Mobile fintech footer */
        .mobile-fintech-footer {
            display: none;
            position: fixed;
            left: 12px;
            right: 12px;
            bottom: 16px;
            padding: 10px;
            background: transparent;
            border: 1px solid rgba(86, 139, 241, 0.35);
            border-radius: 32px;
            backdrop-filter: blur(50px);
            box-shadow: 0 20px 60px rgba(4, 10, 36, 0.7);
            justify-content: space-around;
            align-items: center;
            z-index: 90;
        }

        .mobile-fintech-footer a {
            flex: 1;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            gap: 4px;
            text-decoration: none;
            color: rgba(205, 219, 255, 0.75);
            font-size: 0.45rem;
            letter-spacing: 0.06em;
            text-transform: uppercase;
            transition: all 0.4s ease;
            padding: 8px 4px;
            border-radius: 16px;
        }

        .mobile-fintech-footer a.active {
            color: var(--page-mint);
        }

        .mobile-fintech-footer svg {
            width: 22px;
            height: 22px;
            fill: currentColor;
            filter: drop-shadow(0 4px 12px rgba(4, 10, 36, 0.4));
        }

        .mobile-fintech-footer a:hover {
            color: var(--page-mint);
            transform: translateY(-2px);
        }

        @media (max-width: 680px) {
            .mobile-fintech-footer {
                display: flex;
            }
            
            /* Keep 2 columns on mobile, 3 on desktop */
            .games-grid {
                grid-template-columns: repeat(2, 1fr);
                gap: 16px;
            }
            
            .game-image {
                height: 150px;
            }
            
            .game-info {
                padding: 15px;
            }
            
            .game-title {
                font-size: 0.9rem;
            }
            
            .game-description {
                font-size: 0.7rem;
            }
        }
        
        /* Added tablet breakpoint for 3 columns */
        @media (min-width: 681px) and (max-width: 1024px) {
            .games-grid {
                grid-template-columns: repeat(3, 1fr);
                gap: 20px;
            }
        }
    </style>
</head>
<body>
    <?php include 'header2.php'; ?>
    
    <div class="container">
        <div class="page-header">
            <h1>🎮 Play & Earn</h1>
            <p>Play exciting games and win real rewards!</p>
        </div>
        
        <!-- Expanded games grid to 12 games with real images -->
        <!-- Game Cards Grid -->
        <div class="games-grid">
            <!-- Plinko 3D -->
            <div class="game-card" onclick="handleGameClick('Plinko 3D')">
                <img src="plinko-3d.jpeg">
                <div class="game-info">
                    <div class="game-title">Plinko 3D</div>
                    <p class="game-description">Drop the ball and watch it bounce through pegs to win multipliers!</p>
                    <span class="game-status coming-soon">Play Now</span>
                </div>
            </div>
            
            <!-- Keno 3D -->
            <div class="game-card" onclick="handleGameClick('Keno 3D')">
                <img src="bubble-shooter.jpeg">
                <div class="game-info">
                    <div class="game-title">Keno 3D</div>
                    <p class="game-description">Pick your lucky numbers and match them to win big prizes!</p>
                    <span class="game-status coming-soon">Play Now</span>
                </div>
            </div>
            
            <!-- Spin & Win -->
            <div class="game-card" onclick="handleGameClick('Spin & Win')">
                <img src="slot.jpeg">
                <div class="game-info">
                    <div class="game-title">Spin & Win</div>
                    <p class="game-description">Spin the lucky wheel and land on amazing multipliers!</p>
                    <span class="game-status coming-soon">Play Now</span>
                </div>
            </div>
            
            <!-- Mystery Box -->
            <div class="game-card" onclick="handleGameClick('Mystery Box')">
                <img src="mystery-box.jpeg" alt="Mystery Box" class="game-image">
                <div class="game-info">
                    <div class="game-title">Mystery Box</div>
                    <p class="game-description">Choose a mystery box and reveal your surprise prize!</p>
                    <span class="game-status coming-soon">Play Now</span>
                </div>
            </div>
            
            <!-- Dice Roll -->
            <div class="game-card" onclick="handleGameClick('Dice Roll')">
                <img src="dice-roll.jpeg">
                <div class="game-info">
                    <div class="game-title">Dice Roll</div>
                    <p class="game-description">Roll the dice and predict the outcome to win big!</p>
                    <span class="game-status coming-soon">Play Now</span>
                </div>
            </div>
            
            <!-- Slot Machine -->
            <div class="game-card" onclick="handleGameClick('Slot Machine')">
                <img src="777.jpeg">
                <div class="game-info">
                    <div class="game-title">Slot Machine</div>
                    <p class="game-description">Spin the reels and match symbols for jackpot wins!</p>
                    <span class="game-status coming-soon">Play Now</span>
                </div>
            </div>
            
            <!-- Card Flip -->
            <div class="game-card" onclick="handleGameClick('Card Flip')">
                <img src="https://images.unsplash.com/photo-1541278107931-e006523892df?w=400&h=200&fit=crop" alt="Card Flip" class="game-image">
                <div class="game-info">
                    <div class="game-title">Card Flip</div>
                    <p class="game-description">Flip cards to match pairs and earn bonus rewards!</p>
                    <span class="game-status coming-soon">Play Now</span>
                </div>
            </div>
            
            
            <!-- Treasure Hunt -->
            <div class="game-card" onclick="handleGameClick('Treasure Hunt')">
                <img src="treasure-haunting.jpeg">
                <div class="game-info">
                    <div class="game-title">Treasure Hunt</div>
                    <p class="game-description">Search for hidden treasures and claim amazing prizes!</p>
                    <span class="game-status coming-soon">Play Now</span>
                </div>
            </div>
            
            
            <!-- Mega Bingo -->
            <div class="game-card" onclick="handleGameClick('Mega Bingo')">
                <img src="bingo.jpeg">
                <div class="game-info">
                    <div class="game-title">Mega Bingo</div>
                    <p class="game-description">Mark your numbers and complete patterns for big wins!</p>
                    <span class="game-status coming-soon">Play Now</span>
                </div>
            </div>
            
            <!-- Coin Toss -->
            <div class="game-card" onclick="handleGameClick('Coin Toss')">
                <img src="wild1.jpeg">
                <div class="game-info">
                    <div class="game-title">Coin Toss</div>
                    <p class="game-description">Call heads or tails and double your rewards instantly!</p>
                    <span class="game-status coming-soon">Play Now</span>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Premium Lock Modal -->
    <div id="lockModal" class="lock-modal">
         <div class="free-user-content">
      <svg viewBox="0 0 24 24" fill="currentColor">
        <path d="M12 2L2 7l10 5 10-5-10-5zm0 18.5l-8-4v-7l8 4 8-4v7l-8 4z"/>
      </svg>
      <h2>Premium Access</h2>
      <p>Play & Earn is exclusively available for premium members. Upgrade now to unlock exciting games and earn real rewards!</p>
      <div>
        <a href="membership.php" class="upgrade-btn">Activate Now</a>
        <button class="close-modal-btn" onclick="closeLockModal()">Maybe Later</button>
      </div>
     </div>
    </div>
    
    <!-- Coming Soon Modal -->
    <div id="comingSoonModal" class="coming-soon-modal">
        <div class="coming-soon-content">
            <div class="coming-soon-icon">
               <svg role="img" aria-labelledby="comingTitle2 comingDesc2" viewBox="0 0 300 120" width="600" height="240" xmlns="http://www.w3.org/2000/svg" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
  <title id="comingTitle2">Coming Soon</title>
  <desc id="comingDesc2">Calendar icon with clock and "Coming Soon" text</desc>

  <!-- small calendar + clock at left -->
  <g transform="translate(12,12) scale(1.6)">
    <rect x="6" y="10" width="52" height="44" rx="4" />
    <rect x="6" y="6" width="52" height="8" rx="2" />
    <rect x="16" y="2" width="6" height="6" rx="1" />
    <rect x="42" y="2" width="6" height="6" rx="1" />
    <circle cx="40" cy="34" r="8" />
    <line x1="40" y1="34" x2="40" y2="28" />
    <line x1="40" y1="34" x2="44" y2="34" />
  </g>

  <!-- text -->
  <g transform="translate(120,60)">
    <text x="0" y="-6" font-family="Poppins, Arial, sans-serif" font-size="20" font-weight="600" fill="currentColor">Coming Soon</text>
    <text x="0" y="18" font-family="Poppins, Arial, sans-serif" font-size="12" fill="currentColor" opacity="0.8">We’re launching this feature shortly — stay tuned!</text>
  </g>
</svg>

            </div>
            <h2 id="gameTitle">Coming Soon!</h2>
            <p id="gameMessage">This game is currently under development. We're working hard to bring you an amazing gaming experience. Stay tuned!</p>
            <button class="ok-btn" onclick="closeComingSoonModal()">Got It</button>
        </div>
    </div>
    
   
     <nav class="mobile-fintech-footer">
    
  <a href="dashboard.php">
    <svg viewBox="0 0 24 24"><path d="M12 3a9 9 0 1 1 0 18 9 9 0 0 1 0-18Zm1 4h-2v6h6v-2h-4V7Z"/></svg>
    <span>Dashboard</span>
  </a>

  <!-- Premium (crown icon) -->
  <a href="membership.php">
    <svg viewBox="0 0 24 24"><path d="M5 7l2.5 5 4.5-4 4.5 4L19 7l2 13H3l2-13Z"/></svg>
    <span>Premium</span>
  </a>

  <a href="post-task.php">
<svg viewBox="0 0 24 24" aria-hidden="true">
  <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8l-6-6Zm1 14h-3v3h-2v-3H7v-2h3v-3h2v3h3v2Zm-3-9V3.5L18.5 8H12Z"/>
</svg>
    
    <span>Advert Post</span>
  </a>
  
  

  <a href="history.php">
  <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
    <path d="M13 3a9 9 0 1 0 9 9h-2a7 7 0 1 1-7-7V3l4 4-4 4V7a5 5 0 1 0 5 5h2a7 7 0 1 1-7-7z"/>
  </svg>
  <span>History</span>
</a>


  <a href="profile.php">
    <svg viewBox="0 0 24 24"><path d="M12 2a6 6 0 0 1 6 6c0 3.31-2.69 6-6 6s-6-2.69-6-6a6 6 0 0 1 6-6Zm0 14c4.42 0 8 1.79 8 4v2H4v-2c0-2.21 3.58-4 8-4Z"/></svg>
    <span>Profile</span>
  </a>
</nav>

    
    <script>
        const isPremium = <?php echo $is_premium ? 'true' : 'false'; ?>;
        
        function handleGameClick(gameName) {
            if (!isPremium) {
                // Show premium lock modal for free users
                showLockModal();
            } else {
                // Show coming soon modal for premium users
                showComingSoonModal(gameName);
            }
        }
        
        function showLockModal() {
            document.getElementById('lockModal').classList.add('active');
        }
        
        function closeLockModal() {
            document.getElementById('lockModal').classList.remove('active');
        }
        
        function showComingSoonModal(gameName) {
            document.getElementById('gameTitle').textContent = gameName + ' - Coming Soon!';
            document.getElementById('comingSoonModal').classList.add('active');
        }
        
        function closeComingSoonModal() {
            document.getElementById('comingSoonModal').classList.remove('active');
        }
        
        // Close modals when clicking outside
        document.getElementById('lockModal').addEventListener('click', function(e) {
            if (e.target === this) {
                closeLockModal();
            }
        });
        
        document.getElementById('comingSoonModal').addEventListener('click', function(e) {
            if (e.target === this) {
                closeComingSoonModal();
            }
        });
    </script>
</body>
</html>
