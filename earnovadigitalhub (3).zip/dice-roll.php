<?php
require_once 'config/database.php';
require_once 'includes/session.php';
require_once 'includes/connect.php';

// Require authentication
requireLogin();
checkSessionTimeout();

// Get current user data
$user = getCurrentUser();
$user_id = $user['id'];

try {
    $pdo = getDBConnection();
    
    // Fetch user details with balance
    $stmt = $pdo->prepare("SELECT u.*, b.total_balance, b.referral_earnings, b.game_earnings, b.task_earnings FROM users u LEFT JOIN balances b ON u.id = b.user_id WHERE u.id = ?");
    $stmt->execute([$user_id]);
    $user_data = $stmt->fetch();
    
    if (!$user_data) {
        header('Location: login.php');
        exit;
    }
    
    $is_premium = ($user_data['membership_type'] === 'premium');
    
} catch (PDOException $e) {
    error_log("Dice Roll Error: " . $e->getMessage());
    $error_message = "Unable to load game data.";
}

$referral_earnings = $user_data['referral_earnings'] ?? 0;
$game_earnings = $user_data['game_earnings'] ?? 0;
$task_earnings = $user_data['task_earnings'] ?? 0;
$membership_type = $user_data['membership_type'] ?? 'free';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dice Roll - FlowEarner</title>
    <link rel="stylesheet" href="assets/css/gamified-fintech-theme.css">
    <style>
        :root {
            --page-blue-900: #030922;
            --page-blue-800: #0a1642;
            --page-blue-700: #0a164a;
            --page-blue-500: #142e7e;
            --page-mint: #4de1c1;
            --page-white: #f5f9ff;
            --page-orange: #fb923c;
            --page-gold: #fbbf24;
        }

        * { box-sizing: border-box; margin: 0; padding: 0; }

        body {
            font-family: 'Inter', sans-serif;
            background: linear-gradient(135deg, #0a0e27 0%, #1a1f3a 100%);
            color: #fff;
            overflow-x: hidden;
            min-height: 100vh;
            padding-bottom: 100px;
        }
        
        .container {
            max-width: 1400px;
            margin: 0 auto;
            padding: 20px;
        }
        
        .back-link {
            display: inline-block;
            margin-bottom: 20px;
            color: var(--page-mint);
            text-decoration: none;
            font-size: 1rem;
            transition: color 0.3s ease;
            font-weight: 600;
        }
        
        .back-link:hover { color: #fff; }
        
        .page-header {
            text-align: center;
            padding: 40px 20px;
            background: rgba(77, 225, 193, 0.1);
            border-radius: 20px;
            margin-bottom: 30px;
            border: 1px solid rgba(77, 225, 193, 0.2);
        }
        
        .page-header h1 {
            font-size: clamp(2rem, 5vw, 3rem);
            margin: 0 0 10px;
            background: linear-gradient(135deg, #2c5bf5, #4de1c1);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }
        
        .page-header p {
            font-size: clamp(1rem, 2vw, 1.2rem);
            color: rgba(255, 255, 255, 0.7);
        }
        
        .game-layout {
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 20px;
            margin-bottom: 40px;
        }
        
        .game-canvas-container {
            background: linear-gradient(135deg, #1a2a5e 0%, #0f1937 100%);
            border: 3px solid rgba(77, 225, 193, 0.3);
            border-radius: 30px;
            padding: 20px 0;
            position: relative;
            width: 100%;
            max-width: 850px;
            height: 720px;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: space-between;
            overflow: hidden;
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.7), inset 0 0 20px rgba(77, 225, 193, 0.1);
        }
        
        .top-balance-bar {
            display: flex;
            justify-content: flex-end;
            align-items: center;
            width: 100%;
            padding: 15px 20px;
            gap: 15px;
            z-index: 10;
        }
        
        .balance-chip {
            background: rgba(10, 22, 66, 0.8);
            border: 2px solid rgba(77, 225, 193, 0.3);
            border-radius: 25px;
            padding: 10px 20px;
            display: flex;
            align-items: center;
            gap: 10px;
            cursor: pointer;
            transition: all 0.3s ease;
            backdrop-filter: blur(10px);
        }
        
        .balance-chip:hover {
            background: rgba(10, 22, 66, 1);
            border-color: var(--page-mint);
            transform: translateY(-2px);
        }
        
        .balance-chip-value {
            color: #fff;
            font-weight: 700;
            font-size: 1rem;
        }
        
        .deposit-chip {
            background: linear-gradient(135deg, #fb923c, #f97316);
            border: none;
            color: #fff;
            font-weight: 700;
            padding: 10px 25px;
        }
        
        .deposit-chip:hover {
            transform: scale(1.05);
            box-shadow: 0 0 20px rgba(251, 146, 60, 0.6);
        }
        
        .canvas-wrapper {
            width: 100%;
            flex: 1;
            display: flex;
            align-items: center;
            justify-content: center;
            position: relative;
            padding: 0;
            background: linear-gradient(135deg, #6b4423 0%, #8b5a2b 25%, #a0522d 50%, #8b5a2b 75%, #6b4423 100%);
            overflow: hidden;
        }
        
        canvas#diceCanvas {
            width: 100%;
            height: 100%;
            display: block;
        }
        
        .bottom-controls {
            width: 100%;
            background: rgba(10, 22, 66, 0.7);
            border-top: 2px solid rgba(77, 225, 193, 0.2);
            padding: 20px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 15px;
            flex-wrap: wrap;
            z-index: 10;
            backdrop-filter: blur(10px);
        }
        
        .bet-controls {
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .bet-label {
            color: rgba(255, 255, 255, 0.7);
            font-size: 0.95rem;
            font-weight: 600;
        }
        
        .bet-btn {
            width: 40px;
            height: 40px;
            border-radius: 10px;
            border: 2px solid rgba(251, 146, 60, 0.5);
            background: rgba(251, 146, 60, 0.1);
            color: var(--page-orange);
            font-size: 1.1rem;
            cursor: pointer;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 700;
        }
        
        .bet-btn:hover {
            background: rgba(251, 146, 60, 0.3);
            border-color: var(--page-orange);
            transform: scale(1.1);
        }
        
        .bet-display {
            background: rgba(10, 22, 66, 0.9);
            border: 2px solid rgba(77, 225, 193, 0.3);
            border-radius: 12px;
            padding: 10px 30px;
            color: #fff;
            font-size: 1.2rem;
            font-weight: 700;
            min-width: 140px;
            text-align: center;
        }
        
        .choice-buttons {
            display: flex;
            gap: 12px;
        }
        
        .choice-btn {
            padding: 12px 28px;
            border-radius: 12px;
            border: 2px solid;
            font-size: 1rem;
            font-weight: 700;
            cursor: pointer;
            transition: all 0.3s ease;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            text-shadow: 0 2px 4px rgba(0, 0, 0, 0.3);
        }
        
        .choice-btn.high {
            background: linear-gradient(135deg, #ef4444, #dc2626);
            border-color: #ef4444;
            color: #fff;
        }
        
        .choice-btn.low {
            background: linear-gradient(135deg, #3b82f6, #2563eb);
            border-color: #3b82f6;
            color: #fff;
        }
        
        .choice-btn:hover:not(:disabled) {
            transform: scale(1.08);
            box-shadow: 0 0 20px rgba(251, 146, 60, 0.6);
        }
        
        .choice-btn:disabled {
            opacity: 0.4;
            cursor: not-allowed;
        }
        
        .choice-btn.inactive {
            opacity: 0.5;
        }
        
        .play-button {
            background: linear-gradient(135deg, #fb923c, #f97316);
            border: none;
            border-radius: 15px;
            padding: 12px 50px;
            color: #fff;
            font-size: 1.3rem;
            font-weight: 900;
            cursor: pointer;
            transition: all 0.3s ease;
            text-transform: uppercase;
            letter-spacing: 1px;
            text-shadow: 0 2px 4px rgba(0, 0, 0, 0.3);
            box-shadow: 0 8px 20px rgba(251, 146, 60, 0.3);
        }
        
        .play-button:hover:not(:disabled) {
            transform: scale(1.05);
            box-shadow: 0 12px 30px rgba(251, 146, 60, 0.6);
        }
        
        .play-button:disabled {
            opacity: 0.5;
            cursor: not-allowed;
        }
        
        .info-btn {
            width: 45px;
            height: 45px;
            border-radius: 50%;
            border: 2px solid rgba(77, 225, 193, 0.5);
            background: rgba(77, 225, 193, 0.1);
            color: var(--page-mint);
            font-size: 1.3rem;
            cursor: pointer;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 700;
        }
        
        .info-btn:hover {
            background: rgba(77, 225, 193, 0.3);
            transform: scale(1.1);
        }
        
        .modal-overlay {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.9);
            backdrop-filter: blur(5px);
            z-index: 1000;
            align-items: center;
            justify-content: center;
            opacity: 0;
            transition: opacity 0.3s ease;
        }
        
        .modal-overlay.active {
            display: flex;
            opacity: 1;
        }
        
        .modal-content {
            background: linear-gradient(135deg, #0a0e27, #1a1f3a);
            border-radius: 30px;
            padding: 40px;
            max-width: 600px;
            width: 90%;
            border: 2px solid rgba(77, 225, 193, 0.3);
            text-align: center;
            position: relative;
            max-height: 90vh;
            overflow-y: auto;
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.8);
        }
        
        .modal-close {
            position: absolute;
            top: 20px;
            right: 20px;
            background: rgba(255, 59, 48, 0.2);
            border: 2px solid rgba(255, 59, 48, 0.5);
            color: #ff3b30;
            padding: 8px 16px;
            border-radius: 10px;
            cursor: pointer;
            font-weight: 600;
            transition: all 0.3s ease;
        }
        
        .modal-close:hover {
            background: rgba(255, 59, 48, 0.4);
        }
        
        .modal-title {
            font-size: 2.2rem;
            margin-bottom: 15px;
            background: linear-gradient(135deg, #2c5bf5, #4de1c1);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }
        
        .modal-message {
            font-size: 1.1rem;
            color: rgba(255, 255, 255, 0.8);
            line-height: 1.6;
            margin-bottom: 30px;
        }
        
        .modal-btn {
            padding: 15px 40px;
            border-radius: 15px;
            border: none;
            background: linear-gradient(135deg, #2c5bf5, #4de1c1);
            color: #fff;
            font-size: 1.1rem;
            font-weight: 700;
            cursor: pointer;
            margin: 0 10px;
            transition: all 0.3s ease;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        
        .modal-btn:hover {
            transform: scale(1.05);
            box-shadow: 0 0 20px rgba(77, 225, 193, 0.6);
        }
        
        .tutorial-steps {
            text-align: left;
            margin: 20px 0;
        }
        
        .tutorial-step {
            background: rgba(77, 225, 193, 0.1);
            padding: 20px;
            border-radius: 15px;
            margin-bottom: 15px;
            border-left: 4px solid var(--page-mint);
            display: none;
        }
        
        .tutorial-step.active {
            display: block;
            animation: slideIn 0.3s ease;
        }
        
        @keyframes slideIn {
            from { opacity: 0; transform: translateX(-20px); }
            to { opacity: 1; transform: translateX(0); }
        }
        
        .tutorial-step h4 {
            color: var(--page-mint);
            margin-bottom: 12px;
            font-size: 1.3rem;
        }
        
        .tutorial-step p {
            line-height: 1.6;
            font-size: 1rem;
            color: rgba(255, 255, 255, 0.9);
        }
        
        .tutorial-navigation {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-top: 30px;
            gap: 15px;
        }
        
        .tutorial-nav-btn {
            padding: 12px 30px;
            border-radius: 12px;
            border: none;
            background: linear-gradient(135deg, #2c5bf5, #4de1c1);
            color: #fff;
            font-size: 1rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
        }
        
        .tutorial-nav-btn:hover:not(:disabled) {
            transform: scale(1.05);
        }
        
        .tutorial-nav-btn:disabled {
            opacity: 0.3;
            cursor: not-allowed;
        }
        
        .tutorial-dots {
            display: flex;
            justify-content: center;
            gap: 8px;
        }
        
        .tutorial-dot {
            width: 10px;
            height: 10px;
            border-radius: 50%;
            background: rgba(255, 255, 255, 0.3);
            transition: all 0.3s ease;
        }
        
        .tutorial-dot.active {
            background: var(--page-mint);
            width: 30px;
            border-radius: 5px;
        }
        
        .exchange-input {
            width: 100%;
            padding: 15px;
            border: 2px solid rgba(77, 225, 193, 0.3);
            background: rgba(10, 22, 66, 0.8);
            border-radius: 12px;
            color: #fff;
            font-size: 1rem;
            margin: 20px 0;
        }
        
        .exchange-input::placeholder {
            color: rgba(255, 255, 255, 0.5);
        }

        @media (max-width: 768px) {
            .game-canvas-container {
                height: 500px;
            }
            
            .bottom-controls {
                flex-direction: column;
                align-items: stretch;
            }
            
            .choice-buttons {
                width: 100%;
                justify-content: center;
            }
            
            .play-button {
                width: 100%;
            }
            
            .bet-controls {
                justify-content: center;
                width: 100%;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <a href="play-earn.php" class="back-link">← Back to Games</a>
        
        <div class="page-header">
            <h1>🎲 Dice Roll</h1>
            <p>Roll the dice and predict if you'll get High or Low!</p>
        </div>
        
        <div class="game-layout">
            <div class="game-canvas-container">
                <div class="top-balance-bar">
                    <div class="balance-chip" onclick="openExchangeModal()" style="cursor: pointer;">
                        <span style="font-size: 1.2rem;">🎮</span>
                        <span class="balance-chip-value" id="gameBalance">₦<?php echo number_format($game_earnings, 2); ?></span>
                    </div>
                    <div class="balance-chip" onclick="toggleMute()" style="cursor: pointer;">
                        <span id="volumeIcon">🔊</span>
                    </div>
                    <div class="balance-chip deposit-chip" onclick="window.location.href='membership.php'">
                        Deposit
                    </div>
                </div>
                
                <div class="canvas-wrapper">
                    <canvas id="diceCanvas"></canvas>
                </div>
                
                <div class="bottom-controls">
                    <div class="choice-buttons">
                        <button class="choice-btn high" id="highBtn" onclick="selectChoice('high')">🔴 High (7-12)</button>
                        <button class="choice-btn low" id="lowBtn" onclick="selectChoice('low')">🔵 Low (2-6)</button>
                    </div>
                    
                    <div class="bet-controls">
                        <span class="bet-label">Bet:</span>
                        <button class="bet-btn" onclick="decreaseBet()">−</button>
                        <div class="bet-display" id="betDisplay">₦1,000</div>
                        <button class="bet-btn" onclick="increaseBet()">+</button>
                    </div>
                    
                    <button class="play-button" id="playBtn" onclick="rollDice()">ROLL</button>
                    <button class="info-btn" onclick="openTutorialModal()" title="How to Play">?</button>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Tutorial Modal -->
    <div class="modal-overlay" id="tutorialModal">
        <div class="modal-content">
            <button class="modal-close" onclick="closeTutorialModal()">✕</button>
            <h2 class="modal-title">How to Play Dice Roll</h2>
            
            <div class="tutorial-steps">
                <div class="tutorial-step active">
                    <h4>🎯 Step 1: Choose Your Prediction</h4>
                    <p>Select either <strong>High (7-12)</strong> or <strong>Low (2-6)</strong>. This is your prediction for the total of two dice.</p>
                </div>
                
                <div class="tutorial-step">
                    <h4>💰 Step 2: Set Your Bet</h4>
                    <p>Use the + and − buttons to adjust your bet amount. Minimum is ₦1,000, maximum is ₦100,000. Higher bets mean higher rewards!</p>
                </div>
                
                <div class="tutorial-step">
                    <h4>🎲 Step 3: Roll the Dice</h4>
                    <p>Click the <strong>ROLL</strong> button to roll two dice. Watch them bounce and tumble on the table with realistic physics!</p>
                </div>
                
                <div class="tutorial-step">
                    <h4>🎉 Step 4: Win or Learn</h4>
                    <p>If your prediction is correct, you win <strong>2x your bet amount</strong>! If you're wrong, your bet is deducted. Either way, roll again!</p>
                </div>
                
                <div class="tutorial-step">
                    <h4>🔄 Step 5: Exchange Your Earnings</h4>
                    <p>Click on your <strong>Game Earnings</strong> balance (top left) to exchange it to Task Balance for withdrawals!</p>
                </div>
            </div>
            
            <div style="text-align: center; margin: 20px 0;">
                <div class="tutorial-dots" id="tutorialDots"></div>
            </div>
            
            <div class="tutorial-navigation">
                <button class="tutorial-nav-btn" id="prevBtn" onclick="previousStep()" disabled>← Back</button>
                <button class="tutorial-nav-btn" id="nextBtn" onclick="nextStep()">Next →</button>
            </div>
        </div>
    </div>
    
    <!-- Exchange Modal -->
    <div class="modal-overlay" id="exchangeModal">
        <div class="modal-content">
            <button class="modal-close" onclick="closeExchangeModal()">✕</button>
            <h2 class="modal-title">💱 Exchange Earnings</h2>
            <p class="modal-message">Convert your Game Earnings to Task Balance for withdrawals</p>
            
            <div style="background: rgba(77, 225, 193, 0.1); padding: 20px; border-radius: 15px; margin: 20px 0;">
                <p style="color: rgba(255,255,255,0.7); margin-bottom: 10px;">Available Game Earnings:</p>
                <p style="font-size: 2rem; color: var(--page-mint); font-weight: 900;" id="exchangeGameBalance">₦0.00</p>
            </div>
            
            <input type="number" class="exchange-input" id="exchangeAmount" placeholder="Enter amount to exchange" min="100" step="100">
            <button class="modal-btn" onclick="exchangeBalance()">Exchange Now</button>
        </div>
    </div>
    
    <!-- Upgrade Modal -->
    <div class="modal-overlay" id="upgradeModal">
        <div class="modal-content">
            <button class="modal-close" onclick="closeUpgradeModal()">✕</button>
            <h2 class="modal-title">🔒 Premium Required</h2>
            <p class="modal-message">This game is exclusively for Premium Members. Upgrade now to unlock all games!</p>
            
            <div style="background: rgba(251, 146, 60, 0.1); padding: 20px; border-radius: 15px; margin: 20px 0; text-align: left;">
                <h4 style="color: var(--page-orange); margin-bottom: 15px;">Premium Benefits:</h4>
                <p style="margin-bottom: 8px;">✓ Access to all games</p>
                <p style="margin-bottom: 8px;">✓ Higher winning rates</p>
                <p style="margin-bottom: 8px;">✓ Exclusive tournaments</p>
                <p>✓ Priority support</p>
            </div>
            
            <button class="modal-btn" onclick="window.location.href='membership.php'" style="background: linear-gradient(135deg, #fb923c, #f97316);">Upgrade to Premium</button>
        </div>
    </div>
    
    <!-- Result Modal -->
    <div class="modal-overlay" id="resultModal">
        <div class="modal-content">
            <button class="modal-close" onclick="closeResultModal()">✕</button>
            <h2 class="modal-title" id="resultTitle">You Won!</h2>
            <p style="font-size: 4rem; margin: 20px 0;" id="resultEmoji">🎉</p>
            <p class="modal-message" id="resultMessage">Message here</p>
            <p style="font-size: 2.5rem; color: var(--page-mint); font-weight: 900; margin: 20px 0;" id="resultAmount">₦0.00</p>
            <button class="modal-btn" onclick="closeResultModal()">Roll Again 🎲</button>
        </div>
    </div>
    
    <!-- Notification Modal -->
    <div class="modal-overlay" id="notificationModal">
        <div class="modal-content">
            <h2 class="modal-title" id="notifyTitle">Notification</h2>
            <p class="modal-message" id="notifyMessage">Message</p>
            <button class="modal-btn" onclick="closeNotificationModal()">OK</button>
        </div>
    </div>

    <script>
        const IS_PREMIUM = <?php echo $is_premium ? 'true' : 'false'; ?>;
        
        let canvas, ctx;
        let betAmount = 1;
        let selectedChoice = null;
        let isRolling = false;
        let tutorialStep = 0;
        let tutorialSteps = 5;
        let isMuted = localStorage.getItem('diceRoll_sound_muted') === 'true';
        let dice1Angle = 0, dice2Angle = 0;
        let dice1AngVel = 0, dice2AngVel = 0;
        
        // Sound effects
        const sounds = {
            roll: new Audio('data:audio/wav;base64,UklGRiYAAABXQVZFZm10IBAAAAABAAEAQB8AAAB9AAACABAAZGF0YQIAAAAAAA=='),
            win: new Audio('data:audio/wav;base64,UklGRiYAAABXQVZFZm10IBAAAAABAAEAQB8AAAB9AAACABAAZGF0YQIAAAAAAA=='),
            lose: new Audio('data:audio/wav;base64,UklGRiYAAABXQVZFZm10IBAAAAABAAEAQB8AAAB9AAACABAAZGF0YQIAAAAAAA==')
        };
        
        Object.values(sounds).forEach(sound => sound.volume = 0.6);
        updateVolumeIcon();
        
        function initCanvas() {
            canvas = document.getElementById('diceCanvas');
            ctx = canvas.getContext('2d');
            resizeCanvas();
            window.addEventListener('resize', resizeCanvas);
            renderLoop();
        }
        
        function resizeCanvas() {
            const container = canvas.parentElement;
            canvas.width = container.offsetWidth;
            canvas.height = container.offsetHeight;
        }
        
        function renderLoop() {
            ctx.clearRect(0, 0, canvas.width, canvas.height);
            
            // Draw wood texture
            drawWoodTexture();
            
            // Draw table
            ctx.fillStyle = 'rgba(101, 67, 33, 0.7)';
            ctx.fillRect(0, canvas.height - 100, canvas.width, 100);
            
            // Draw dice
            drawDice(canvas.width / 2 - 80, canvas.height - 200, dice1Angle, 1);
            drawDice(canvas.width / 2 + 80, canvas.height - 200, dice2Angle, 2);
            
            requestAnimationFrame(renderLoop);
        }
        
        function drawWoodTexture() {
            ctx.fillStyle = 'rgba(107, 68, 35, 0.4)';
            ctx.fillRect(0, 0, canvas.width, canvas.height);
            ctx.strokeStyle = 'rgba(139, 90, 43, 0.3)';
            ctx.lineWidth = 1;
            for (let i = 0; i < canvas.height; i += 4) {
                ctx.beginPath();
                ctx.moveTo(0, i);
                ctx.lineTo(canvas.width, i + Math.random() * 2 - 1);
                ctx.stroke();
            }
        }
        
        function drawDice(x, y, angle, diceNum) {
            ctx.save();
            ctx.translate(x, y);
            ctx.rotate(angle);
            
            // Dice shadow
            ctx.fillStyle = 'rgba(0, 0, 0, 0.3)';
            ctx.fillRect(-30, 35, 60, 10);
            
            // Dice face
            ctx.fillStyle = '#ffffff';
            ctx.fillRect(-30, -30, 60, 60);
            ctx.strokeStyle = '#333';
            ctx.lineWidth = 2;
            ctx.strokeRect(-30, -30, 60, 60);
            
            // Dice dots based on rotation (simplified)
            ctx.fillStyle = '#000';
            const dotNum = (Math.round(angle / (Math.PI / 3)) % 6) + 1;
            drawDots(dotNum);
            
            ctx.restore();
        }
        
        function drawDots(num) {
            ctx.fillStyle = '#000';
            const dotSize = 4;
            const positions = {
                1: [[0, 0]],
                2: [[-10, -10], [10, 10]],
                3: [[-10, -10], [0, 0], [10, 10]],
                4: [[-10, -10], [10, -10], [-10, 10], [10, 10]],
                5: [[-10, -10], [10, -10], [0, 0], [-10, 10], [10, 10]],
                6: [[-10, -10], [10, -10], [-10, 0], [10, 0], [-10, 10], [10, 10]]
            };
            
            (positions[num] || []).forEach(([x, y]) => {
                ctx.beginPath();
                ctx.arc(x, y, dotSize, 0, Math.PI * 2);
                ctx.fill();
            });
        }
        
        function selectChoice(choice) {
            if (isRolling) return;
            selectedChoice = choice;
            document.getElementById('highBtn').classList.toggle('inactive', choice !== 'high');
            document.getElementById('lowBtn').classList.toggle('inactive', choice !== 'low');
        }
        
        function increaseBet() {
            if (betAmount < 100 && !isRolling) {
                betAmount++;
                updateBetDisplay();
            }
        }
        
        function decreaseBet() {
            if (betAmount > 1 && !isRolling) {
                betAmount--;
                updateBetDisplay();
            }
        }
        
        function updateBetDisplay() {
            document.getElementById('betDisplay').textContent = '₦' + (betAmount * 1000).toLocaleString();
        }
        
        function toggleMute() {
            isMuted = !isMuted;
            localStorage.setItem('diceRoll_sound_muted', isMuted);
            Object.values(sounds).forEach(sound => sound.muted = isMuted);
            updateVolumeIcon();
        }
        
        function updateVolumeIcon() {
            document.getElementById('volumeIcon').textContent = isMuted ? '🔇' : '🔊';
        }
        
        function openTutorialModal() {
            tutorialStep = 0;
            document.getElementById('tutorialModal').style.display = 'flex';
            setTimeout(() => document.getElementById('tutorialModal').classList.add('active'), 10);
            updateTutorialStep();
        }
        
        function closeTutorialModal() {
            document.getElementById('tutorialModal').classList.remove('active');
            setTimeout(() => document.getElementById('tutorialModal').style.display = 'none', 300);
        }
        
        function updateTutorialStep() {
            document.querySelectorAll('.tutorial-step').forEach((step, i) => {
                step.classList.toggle('active', i === tutorialStep);
            });
            document.getElementById('prevBtn').disabled = tutorialStep === 0;
            document.getElementById('nextBtn').disabled = tutorialStep === tutorialSteps - 1;
            renderTutorialDots();
        }
        
        function renderTutorialDots() {
            const dotsContainer = document.getElementById('tutorialDots');
            dotsContainer.innerHTML = '';
            for (let i = 0; i < tutorialSteps; i++) {
                const dot = document.createElement('div');
                dot.className = 'tutorial-dot' + (i === tutorialStep ? ' active' : '');
                dotsContainer.appendChild(dot);
            }
        }
        
        function nextStep() {
            if (tutorialStep < tutorialSteps - 1) {
                tutorialStep++;
                updateTutorialStep();
            }
        }
        
        function previousStep() {
            if (tutorialStep > 0) {
                tutorialStep--;
                updateTutorialStep();
            }
        }
        
        function openExchangeModal() {
            document.getElementById('exchangeGameBalance').textContent = document.getElementById('gameBalance').textContent;
            document.getElementById('exchangeModal').style.display = 'flex';
            setTimeout(() => document.getElementById('exchangeModal').classList.add('active'), 10);
        }
        
        function closeExchangeModal() {
            document.getElementById('exchangeModal').classList.remove('active');
            setTimeout(() => document.getElementById('exchangeModal').style.display = 'none', 300);
        }
        
        async function exchangeBalance() {
            const amount = parseFloat(document.getElementById('exchangeAmount').value) || 0;
            if (amount < 100) {
                showNotification('Invalid Amount', 'Minimum exchange is ₦100');
                return;
            }
            
            try {
                const response = await fetch('api/exchange-balance.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ amount: amount })
                });
                const data = await response.json();
                
                if (data.success) {
                    document.getElementById('gameBalance').textContent = '₦' + parseFloat(data.game_earnings).toLocaleString('en-NG', {minimumFractionDigits: 2, maximumFractionDigits: 2});
                    closeExchangeModal();
                    showNotification('Success', 'Balance exchanged successfully!');
                } else {
                    showNotification('Error', data.message);
                }
            } catch (error) {
                showNotification('Error', error.message);
            }
        }
        
        async function rollDice() {
            if (isRolling) return;
            if (!selectedChoice) {
                showNotification('Choose First', 'Select High or Low before rolling!');
                return;
            }
            if (!IS_PREMIUM) {
                document.getElementById('upgradeModal').style.display = 'flex';
                setTimeout(() => document.getElementById('upgradeModal').classList.add('active'), 10);
                return;
            }
            
            isRolling = true;
            document.getElementById('playBtn').disabled = true;
            
            // Animate dice
            dice1AngVel = Math.random() * 0.5 + 0.2;
            dice2AngVel = Math.random() * 0.5 + 0.2;
            
            if (!isMuted) try { sounds.roll.play(); } catch (e) {}
            
            // Wait for animation then call API
            await new Promise(resolve => setTimeout(resolve, 1500));
            
            try {
                const response = await fetch('api/dice-roll-play.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ bet_amount: betAmount * 1000, choice: selectedChoice })
                });
                
                const data = await response.json();
                
                if (data.success) {
                    document.getElementById('gameBalance').textContent = '₦' + parseFloat(data.game_earnings).toLocaleString('en-NG', {minimumFractionDigits: 2, maximumFractionDigits: 2});
                    
                    const resultEmoji = data.won ? '🎉' : '😔';
                    const resultTitle = data.won ? 'You Won!' : 'Better Luck Next Time!';
                    
                    document.getElementById('resultEmoji').textContent = resultEmoji;
                    document.getElementById('resultTitle').textContent = resultTitle;
                    document.getElementById('resultMessage').textContent = `Dice rolled: ${data.result} (${data.won ? 'WIN' : 'LOSE'})`;
                    document.getElementById('resultAmount').textContent = '₦' + parseFloat(data.win_amount).toLocaleString('en-NG', {minimumFractionDigits: 2, maximumFractionDigits: 2});
                    
                    document.getElementById('resultModal').style.display = 'flex';
                    setTimeout(() => document.getElementById('resultModal').classList.add('active'), 10);
                    
                    if (!isMuted) try { sounds[data.won ? 'win' : 'lose'].play(); } catch (e) {}
                } else {
                    showNotification('Error', data.message);
                }
            } catch (error) {
                showNotification('Error', error.message);
            }
            
            isRolling = false;
            document.getElementById('playBtn').disabled = false;
        }
        
        function closeResultModal() {
            document.getElementById('resultModal').classList.remove('active');
            setTimeout(() => document.getElementById('resultModal').style.display = 'none', 300);
            selectedChoice = null;
            document.getElementById('highBtn').classList.remove('inactive');
            document.getElementById('lowBtn').classList.remove('inactive');
        }
        
        function closeUpgradeModal() {
            document.getElementById('upgradeModal').classList.remove('active');
            setTimeout(() => document.getElementById('upgradeModal').style.display = 'none', 300);
        }
        
        function showNotification(title, message) {
            document.getElementById('notifyTitle').textContent = title;
            document.getElementById('notifyMessage').textContent = message;
            document.getElementById('notificationModal').style.display = 'flex';
            setTimeout(() => document.getElementById('notificationModal').classList.add('active'), 10);
        }
        
        function closeNotificationModal() {
            document.getElementById('notificationModal').classList.remove('active');
            setTimeout(() => document.getElementById('notificationModal').style.display = 'none', 300);
        }
        
        document.addEventListener('DOMContentLoaded', () => {
            initCanvas();
            updateBetDisplay();
        });
    </script>
</body>
</html>
