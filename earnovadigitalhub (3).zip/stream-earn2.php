<?php
require_once 'config/database.php';
require_once 'includes/session.php';
require_once 'includes/connect.php';

// Require authentication
requireLogin();
checkSessionTimeout();

// Get current user data
$user = getCurrentUser();
$user_id = $user['id'];

try {
    $pdo = getDBConnection();
    
    // Fetch user details with balance
    $stmt = $pdo->prepare("
        SELECT u.*, b.total_balance, b.task_earnings, b.referral_earnings
        FROM users u
        LEFT JOIN balances b ON u.id = b.user_id
        WHERE u.id = ?
    ");
    $stmt->execute([$user_id]);
    $user_data = $stmt->fetch();
    
    if (!$user_data) {
        header('Location: login.php');
        exit;
    }
    
} catch (PDOException $e) {
    error_log("Stream & Earn Error: " . $e->getMessage());
    $error_message = "Unable to load streaming data.";
}

$username = htmlspecialchars($user_data['username'] ?? 'User');
$advertiser_plan = $user_data['advertiser_plan'] ?? null;
// User is premium if advertiser_plan === 'senior'
$is_premium = ($advertiser_plan === 'senior');
$referral_earnings = $user_data['referral_earnings'] ?? 0;


$stream_agreed = isset($_SESSION['stream_agreed_' . $user_id]) ? $_SESSION['stream_agreed_' . $user_id] : false;

// Get available tracks (including track_link for audio ad redirect)
try {
    $stmt = $pdo->prepare("SELECT *, COALESCE(track_link, '') as track_link FROM stream_tracks WHERE is_active = 1 ORDER BY upload_date DESC");
    $stmt->execute();
    $tracks = $stmt->fetchAll();
} catch (PDOException $e) {
    $tracks = [];
    error_log("Error fetching tracks: " . $e->getMessage());
}

// Get user's stream stats
try {
    $stmt = $pdo->prepare("
        SELECT 
            COUNT(*) as total_streams,
            SUM(payout_amount) as total_earned
        FROM stream_earnings 
        WHERE user_id = ? AND is_eligible = 1
    ");
    $stmt->execute([$user_id]);
    $user_stats = $stmt->fetch();
    
    // Get today's streams
    $today = date('Y-m-d');
    $stmt = $pdo->prepare("
        SELECT COUNT(*) as today_streams
        FROM stream_earnings 
        WHERE user_id = ? AND DATE(streamed_at) = ?
    ");
    $stmt->execute([$user_id, $today]);
    $today_stats = $stmt->fetch();
    
} catch (PDOException $e) {
    $user_stats = ['total_streams' => 0, 'total_earned' => 0];
    $today_stats = ['today_streams' => 0];
}

 if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['ajax'])) {
        ob_end_clean();
        
        header('Content-Type: application/json; charset=utf-8');
        
        $action = $_POST['action'] ?? '';

        if ($action === 'agree_terms') {
            $_SESSION['stream_agreed_' . $user_id] = true;
            echo json_encode(['success' => true, 'message' => 'Stream Instructions agreed']);
            exit;
        }
 }
        
      
?>
<?php include "doctype.php"; ?>
    <style>
        :root {
            --page-blue-900: #030922;
            --page-blue-700: #0a164a;
            --page-blue-500: #142a7e;
            --page-blue-300: #2c5bf5;
            --page-mint: #4de1c1;
            --page-white: #f5f9ff;
            --stream-purple: #8b5cf6;
            --stream-pink: #ec4899;
            --panel-glass: rgba(13, 24, 62, 0.84);
            --panel-border: rgba(86, 139, 241, 0.3);
            --shadow-heavy: 0 40px 120px rgba(4, 10, 36, 0.65);
        }

        * { box-sizing: border-box; margin: 0; padding: 0; }

        body {
            font-family: "Titillium Web", "Segoe UI", sans-serif;
            background: radial-gradient(circle at 0% 0%, rgba(61, 116, 255, 0.28), transparent 55%),
                  radial-gradient(circle at 100% 0%, rgba(77, 225, 193, 0.18), transparent 45%),
                  linear-gradient(180deg, var(--page-blue-900), var(--page-blue-700));
            color: var(--page-white);
            overflow-x: hidden;
            min-height: 100vh;
        }

        .page-shell {
            min-height: 100vh;
            display: flex;
        }

        aside {
            position: fixed;
            left: 0;
            top: 0;
            bottom: 0;
            width: 320px;
            background: rgba(5, 15, 44, 0.92);
            backdrop-filter: blur(18px);
            padding: clamp(1.25rem, 3vw, 2.25rem) clamp(1rem, 2.5vw, 2rem);
            display: flex;
            flex-direction: column;
            gap: clamp(1.25rem, 2.5vw, 2rem);
            border-right: 1px solid var(--panel-border);
            overflow-y: auto;
            z-index: 100;
        }

        main {
            margin-left: 320px;
            flex: 1;
            padding: 32px 40px 120px;
            display: grid;
            gap: 32px;
        }

        @media (max-width: 960px) {
            .page-shell { display: block; }
            aside {
                position: relative;
                width: 100%;
                height: auto;
                border-right: none;
                border-bottom: 1px solid var(--panel-border);
            }
            main {
                margin-left: 0;
                padding: 24px 16px 120px;
            }
        }

        .back-link {
            display: inline-flex;
            align-items: center;
            gap: 10px;
            font-weight: 600;
            font-size: 0.875rem;
            letter-spacing: 0.1em;
            text-transform: uppercase;
            color: rgba(210, 226, 255, 0.78);
            text-decoration: none;
            transition: all 0.3s ease;
        }

        .back-link:hover {
            color: var(--page-white);
            transform: translateX(-4px);
        }

        .page-title {
            font-size: clamp(1rem, 3vw, 1.5rem);
            letter-spacing: 0.1em;
            text-transform: uppercase;
            margin: 0 0 0.75rem;
            font-weight: 700;
        }

        .side-description {
            color: rgba(206, 224, 255, 0.74);
            line-height: 1.7;
            font-size: 1rem;
        }

        .aside-welcome {
            display: grid;
            grid-template-columns: auto 1fr;
            align-items: center;
            gap: 14px;
            background: linear-gradient(135deg, rgba(44, 91, 245, 0.3), rgba(26, 58, 171, 0.2));
            border: 1px solid rgba(44, 91, 245, 0.5);
            box-shadow: 0 0 10px rgba(44, 91, 245, 0.6);
            border-radius: 18px;
            padding: 16px;
            
        }

        .aside-avatar {
            width: 56px;
            height: 56px;
            border-radius: 50%;
            overflow: hidden;
            border: 3px solid rgba(139, 92, 246, 0.45);
            box-shadow: 0 12px 28px rgba(139, 92, 246, 0.35);
        }

        .aside-avatar img {
            width: 100%;
            display: block;
        }

        .welcome-tag {
            font-size: 0.75rem;
            letter-spacing: 0.1em;
            text-transform: uppercase;
            color: rgba(206, 224, 255, 0.7);
        }

        .aside-welcome h3 {
            margin: 5px 0 3px;
            font-size: 1.12rem;
            color: var(--page-white);
        }

        .welcome-meta {
            font-size: 0.8rem;
            color: rgba(206, 224, 255, 0.8);
        }


        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 1.5rem;
        }

        .stat-card {
            /* background: var(--panel-glass); */
            border: 1px solid rgba(139, 92, 246, 0.3);
            border-radius: 20px;
            padding: 1.5rem;
            box-shadow: 0 10px 40px rgba(139, 92, 246, 0.2);
        }

        .stat-label {
            font-size: 0.875rem;
            letter-spacing: 0.08em;
            text-transform: uppercase;
            color: rgba(205, 219, 255, 0.7);
            margin-bottom: 0.75rem;
        }

        .stat-value {
            font-size: 2rem;
            font-weight: 700;
            color: #fbbf24;
        }

        .player-container {
            background: var(--panel-glass);
            border: 1px solid var(--panel-border);
            border-radius: 24px;
            padding: 2rem;
            box-shadow: var(--shadow-heavy);
        }

        .section-title {
            font-size: 1.5rem;
            font-weight: 700;
            margin-bottom: 1.5rem;
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .section-title::before {
            content: "";
            width: 4px;
            height: 28px;
            background: linear-gradient(180deg, var(--stream-purple), var(--stream-pink));
            border-radius: 4px;
        }

        /* Add playlist button to header */
        .section-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1.5rem;
        }

        .playlist-btn {
            background: linear-gradient(135deg, var(--stream-purple), var(--stream-pink));
            border: none;
            color: white;
            padding: 0.75rem 1.5rem;
            border-radius: 12px;
            font-weight: 600;
            cursor: pointer;
            display: flex;
            align-items: center;
            gap: 0.5rem;
            transition: all 0.3s ease;
            font-size: 0.95rem;
        }

        .playlist-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 24px rgba(139, 92, 246, 0.4);
        }

        .track-list {
            display: grid;
            gap: 1rem;
        }

        .track-item {
            background: rgba(6, 16, 48, 0.7);
            border: 1px solid rgba(139, 92, 246, 0.2);
            border-radius: 16px;
            padding: 1rem;
            display: grid;
            grid-template-columns: 60px 1fr auto;
            gap: 1rem;
            align-items: center;
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .track-item:hover {
            border-color: rgba(139, 92, 246, 0.5);
            transform: translateY(-2px);
            box-shadow: 0 8px 24px rgba(139, 92, 246, 0.3);
        }

        .track-item.completed {
            display: none;
        }

        .track-cover {
            width: 60px;
            height: 60px;
            border-radius: 12px;
            overflow: hidden;
            background: linear-gradient(135deg, var(--stream-purple), var(--stream-pink));
        }

        .track-cover img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .track-info h3 {
            font-size: 1.1rem;
            margin-bottom: 0.25rem;
        }

        .track-info p {
            font-size: 0.9rem;
            color: rgba(205, 219, 255, 0.7);
        }

        .track-duration {
            font-size: 0.9rem;
            color: rgba(205, 219, 255, 0.6);
        }

        /* Full-screen music player overlay (Audiomack/Boomplay style) */
        .fullscreen-player {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: linear-gradient(180deg, var(--page-blue-900), var(--page-blue-700));
            z-index: 1000;
            display: none;
            flex-direction: column;
            overflow-y: auto;
        }

        .fullscreen-player.active {
            display: flex;
        }

        .fullscreen-header {
            padding: 1.5rem 2rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-bottom: 1px solid var(--panel-border);
        }

        .close-player-btn {
            background: rgba(139, 92, 246, 0.2);
            border: none;
            color: white;
            width: 40px;
            height: 40px;
            border-radius: 50%;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: all 0.3s ease;
        }

        .close-player-btn:hover {
            background: rgba(139, 92, 246, 0.4);
            transform: scale(1.1);
        }

        .fullscreen-content {
            flex: 1;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            padding: 2rem;
            max-width: 600px;
            margin: 0 auto;
            width: 100%;
        }

        .fullscreen-cover {
            width: 100%;
            max-width: 400px;
            aspect-ratio: 1;
            border-radius: 24px;
            overflow: hidden;
            box-shadow: 0 30px 80px rgba(139, 92, 246, 0.5);
            margin-bottom: 2rem;
            animation: coverPulse 3s ease-in-out infinite;
        }

        @keyframes coverPulse {
            0%, 100% { transform: scale(1); }
            50% { transform: scale(1.02); }
        }

        .fullscreen-cover img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .fullscreen-info {
            text-align: center;
            margin-bottom: 2rem;
            width: 100%;
        }

        .fullscreen-info h2 {
            font-size: 2rem;
            margin-bottom: 0.5rem;
            font-weight: 700;
        }

        .fullscreen-info p {
            font-size: 1.2rem;
            color: rgba(205, 219, 255, 0.7);
        }

        .fullscreen-progress {
            width: 100%;
            margin-bottom: 1.5rem;
        }

        .progress-bar-full {
            display: flex;
            align-items: center;
            gap: 1rem;
            margin-bottom: 0.5rem;
        }

        .progress-time-full {
            font-size: 0.9rem;
            color: rgba(205, 219, 255, 0.7);
            min-width: 50px;
        }

        .progress-track-full {
            flex: 1;
            height: 8px;
            background: rgba(139, 92, 246, 0.2);
            border-radius: 4px;
            cursor: pointer;
            position: relative;
        }

        .progress-fill-full {
            height: 100%;
            background: linear-gradient(90deg, var(--stream-purple), var(--stream-pink));
            border-radius: 4px;
            width: 0%;
            transition: width 0.1s linear;
            position: relative;
        }

        .progress-fill-full::after {
            content: '';
            position: absolute;
            right: -6px;
            top: 50%;
            transform: translateY(-50%);
            width: 16px;
            height: 16px;
            background: white;
            border-radius: 50%;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.3);
        }

        /* Replaced percentage with loading animation */
        .loading-animation {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 0.5rem;
            margin-bottom: 1rem;
        }

        .loading-dot {
            width: 12px;
            height: 12px;
            border-radius: 50%;
            background: linear-gradient(135deg, var(--stream-purple), var(--stream-pink));
            animation: loadingPulse 1.4s ease-in-out infinite;
        }

        .loading-dot:nth-child(2) {
            animation-delay: 0.2s;
        }

        .loading-dot:nth-child(3) {
            animation-delay: 0.4s;
        }

        @keyframes loadingPulse {
            0%, 80%, 100% {
                transform: scale(0.6);
                opacity: 0.5;
            }
            40% {
                transform: scale(1);
                opacity: 1;
            }
        }

        .loading-text {
            text-align: center;
            font-size: 1rem;
            color: var(--page-mint);
            font-weight: 600;
        }

        .fullscreen-progress .progress-percentage {
            text-align: center;
            font-size: 1.1rem;
            font-weight: 600;
            color: var(--page-mint);
            margin-bottom: 1rem;
        }

        .fullscreen-controls {
            display: flex;
            justify-content: center;
            align-items: center;
            gap: 2rem;
            margin-bottom: 2rem;
        }

        .control-btn {
            background: rgba(139, 92, 246, 0.2);
            border: none;
            color: white;
            width: 60px;
            height: 60px;
            border-radius: 50%;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: all 0.3s ease;
        }

        /* Updated control button styles for disabled state */
        .control-btn:disabled {
            background: rgba(139, 92, 246, 0.1);
            color: rgba(205, 219, 255, 0.3);
            cursor: not-allowed;
        }

        .control-btn:disabled:hover {
            transform: none;
            background: rgba(139, 92, 246, 0.1);
        }

        .control-btn:hover {
            background: rgba(139, 92, 246, 0.4);
            transform: scale(1.1);
        }

        .control-btn.play-pause-full {
            width: 80px;
            height: 80px;
            background: linear-gradient(135deg, var(--stream-purple), var(--stream-pink));
        }

        .control-btn.play-pause-full:hover {
            transform: scale(1.15);
            box-shadow: 0 0 30px rgba(139, 92, 246, 0.6);
        }

        /* Added control message for validation feedback */
        .control-message {
            text-align: center;
            font-size: 0.85rem;
            color: rgba(255, 107, 107, 0.9);
            margin-top: 0.5rem;
            min-height: 20px;
            font-weight: 500;
        }


        /* Claim button for 100% completion */
        .claim-section {
            width: 100%;
            text-align: center;
        }

        .claim-btn {
            background: linear-gradient(135deg, var(--page-mint), #2ecc71);
            border: none;
            color: var(--page-blue-900);
            padding: 1.25rem 3rem;
            border-radius: 16px;
            font-size: 1.2rem;
            font-weight: 700;
            cursor: pointer;
            transition: all 0.3s ease;
            display: inline-flex;
            align-items: center;
            gap: 0.75rem;
            box-shadow: 0 10px 30px rgba(77, 225, 193, 0.4);
        }

        .claim-btn:disabled {
            background: rgba(139, 92, 246, 0.2);
            color: rgba(205, 219, 255, 0.5);
            cursor: not-allowed;
            box-shadow: none;
        }

        .claim-btn:not(:disabled):hover {
            transform: translateY(-3px);
            box-shadow: 0 15px 40px rgba(77, 225, 193, 0.6);
        }

        .claim-status {
            margin-top: 1rem;
            font-size: 0.95rem;
            color: rgba(205, 219, 255, 0.7);
        }

        /* ADS Indicator Badge */
        .ads-indicator {
            position: absolute;
            top: 16px;
            right: 16px;
            background: linear-gradient(135deg, #ff6b6b, #ee5a24);
            color: white;
            padding: 8px 16px;
            border-radius: 20px;
            font-size: 0.85rem;
            font-weight: 700;
            letter-spacing: 0.1em;
            text-transform: uppercase;
            box-shadow: 0 4px 15px rgba(238, 90, 36, 0.4);
            animation: adsPulse 2s ease-in-out infinite;
            z-index: 10;
            display: none;
        }

        .ads-indicator.active {
            display: flex;
            align-items: center;
            gap: 6px;
        }

        @keyframes adsPulse {
            0%, 100% { transform: scale(1); box-shadow: 0 4px 15px rgba(238, 90, 36, 0.4); }
            50% { transform: scale(1.05); box-shadow: 0 6px 20px rgba(238, 90, 36, 0.6); }
        }

        /* Go to Ad Button */
        .go-ad-btn {
            background: linear-gradient(135deg, #ff6b6b, #ee5a24);
            border: none;
            color: white;
            padding: 1rem 2.5rem;
            border-radius: 16px;
            font-size: 1.1rem;
            font-weight: 700;
            cursor: pointer;
            transition: all 0.3s ease;
            display: none;
            align-items: center;
            gap: 0.75rem;
            box-shadow: 0 10px 30px rgba(238, 90, 36, 0.4);
            margin-top: 1rem;
        }

        .go-ad-btn.active {
            display: inline-flex;
        }

        .go-ad-btn:hover {
            transform: translateY(-3px);
            box-shadow: 0 15px 40px rgba(238, 90, 36, 0.6);
        }

        .go-ad-btn:disabled {
            opacity: 0.5;
            cursor: not-allowed;
            transform: none;
            box-shadow: none;
        }

        /* Email Verification Modal */
        .verification-modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(3, 9, 34, 0.95);
            backdrop-filter: blur(12px);
            z-index: 3000;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }

        .verification-modal.active {
            display: flex;
        }

        .verification-content {
            background: rgba(6, 16, 48, 0.98);
            border: 1px solid rgba(100, 154, 255, 0.3);
            border-radius: 24px;
            padding: 32px;
            max-width: 500px;
            width: 100%;
            max-height: 90vh;
            overflow-y: auto;
        }

        .verification-step {
            display: none;
        }

        .verification-step.active {
            display: block;
        }

        .verification-step h2 {
            margin: 0 0 24px;
            font-size: 1.5rem;
            color: var(--page-white);
            text-align: center;
        }

        .verification-step p {
            color: rgba(205, 219, 255, 0.7);
            line-height: 1.7;
            margin-bottom: 24px;
            text-align: center;
        }

        .form-input {
            width: 100%;
            padding: 14px 16px;
            border-radius: 12px;
            border: 1px solid rgba(100, 154, 255, 0.3);
            background: rgba(8, 21, 64, 0.6);
            color: var(--page-white);
            font-size: 0.95rem;
            font-family: inherit;
            transition: border-color 0.3s ease;
            margin-bottom: 16px;
        }

        .form-input:focus {
            outline: none;
            border-color: rgba(77, 225, 193, 0.5);
        }

        .verification-actions {
            display: flex;
            gap: 12px;
            justify-content: center;
            margin-top: 24px;
        }

        .btn-secondary {
            padding: 12px 24px;
            border-radius: 12px;
            border: 1px solid rgba(100, 154, 255, 0.3);
            background: rgba(8, 21, 64, 0.6);
            color: var(--page-white);
            font-weight: 600;
            font-size: 0.9rem;
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .btn-secondary:hover {
            border-color: rgba(77, 225, 193, 0.5);
        }

        .btn-primary {
            padding: 12px 24px;
            border-radius: 12px;
            border: none;
            background: linear-gradient(135deg, var(--page-mint), #2ecc71);
            color: var(--page-blue-900);
            font-weight: 600;
            font-size: 0.9rem;
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(77, 225, 193, 0.3);
        }

        .btn-primary:disabled {
            opacity: 0.5;
            cursor: not-allowed;
            transform: none;
        }

        .countdown-spinner {
            width: 80px;
            height: 80px;
            border: 4px solid rgba(77, 225, 193, 0.3);
            border-top-color: var(--page-mint);
            border-radius: 50%;
            animation: spin 1s linear infinite;
            margin: 0 auto 24px;
        }

        @keyframes spin {
            to { transform: rotate(360deg); }
        }

        /* Playlist overlay */
        .playlist-overlay {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(3, 9, 34, 0.98);
            backdrop-filter: blur(20px);
            z-index: 999;
            display: none;
            flex-direction: column;
            overflow-y: auto;
        }

        .playlist-overlay.active {
            display: flex;
        }

        .playlist-header {
            padding: 1.5rem 2rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-bottom: 1px solid var(--panel-border);
            position: sticky;
            top: 0;
            background: rgba(3, 9, 34, 0.95);
            backdrop-filter: blur(20px);
            z-index: 10;
        }

        .playlist-header h2 {
            font-size: 1.5rem;
            display: flex;
            align-items: center;
            gap: 0.75rem;
        }

        .playlist-content {
            padding: 2rem;
            max-width: 800px;
            margin: 0 auto;
            width: 100%;
        }

        .playlist-item {
            background: rgba(6, 16, 48, 0.7);
            border: 1px solid rgba(139, 92, 246, 0.2);
            border-radius: 16px;
            padding: 1rem;
            display: grid;
            grid-template-columns: 80px 1fr auto;
            gap: 1rem;
            align-items: center;
            cursor: pointer;
            transition: all 0.3s ease;
            margin-bottom: 1rem;
        }

        .playlist-item:hover {
            border-color: rgba(139, 92, 246, 0.5);
            transform: translateX(5px);
            box-shadow: 0 8px 24px rgba(139, 92, 246, 0.3);
        }

        .playlist-cover {
            width: 80px;
            height: 80px;
            border-radius: 12px;
            overflow: hidden;
            background: linear-gradient(135deg, var(--stream-purple), var(--stream-pink));
        }

        .playlist-cover img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .playlist-item-info h3 {
            font-size: 1.1rem;
            margin-bottom: 0.5rem;
        }

        .playlist-item-info p {
            font-size: 0.9rem;
            color: rgba(205, 219, 255, 0.7);
        }

        .playlist-empty {
            text-align: center;
            padding: 4rem 2rem;
            color: rgba(205, 219, 255, 0.6);
        }

        .playlist-empty svg {
            width: 80px;
            height: 80px;
            margin-bottom: 1rem;
            opacity: 0.5;
        }

        .alert {
            padding: 1rem 1.25rem;
            border-radius: 16px;
            margin-bottom: 1.5rem;
            font-size: 0.95rem;
            font-weight: 500;
        }

        .alert-success {
            background: rgba(77, 225, 193, 0.15);
            border: 1px solid rgba(77, 225, 193, 0.4);
            color: #4de1c1;
        }

        .alert-info {
            background: rgba(139, 92, 246, 0.15);
            border: 1px solid rgba(139, 92, 246, 0.4);
            color: var(--stream-purple);
        }

        /* Added free user modal styles matching watch-earn.php */
        .free-user-modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(3, 9, 34, 0.9);
            backdrop-filter: blur(8px);
            z-index: 2000;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        
        .free-user-modal.active {
            display: flex;
        }
        
        .free-user-content {
            background: rgba(6, 16, 48, 0.98);
            border: 1px solid rgba(100, 154, 255, 0.3);
            border-radius: 24px;
            padding: 32px;
            max-width: 500px;
            width: 100%;
            text-align: center;
        }
        
        .free-user-content svg {
            width: 80px;
            height: 80px;
            margin-bottom: 24px;
            color: #fbbf24;
        }
        
        .free-user-content h2 {
            margin: 0 0 16px;
            font-size: 1.5rem;
            color: var(--page-white);
        }
        
        .free-user-content p {
            color: rgba(205, 219, 255, 0.7);
            line-height: 1.7;
            margin-bottom: 24px;
        }
        
        .upgrade-btn {
            display: inline-block;
            padding: 14px 32px;
            background: linear-gradient(135deg, #fbbf24, #f59e0b);
            color: #000;
            border-radius: 12px;
            text-decoration: none;
            font-weight: 700;
            font-size: 1rem;
            text-transform: uppercase;
            letter-spacing: 0.05em;
            transition: all 0.3s ease;
            margin-right: 12px;
        }
        
        .upgrade-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 24px rgba(251, 191, 36, 0.4);
        }
        
        .close-modal-btn {
            display: inline-block;
            padding: 14px 32px;
            background: rgba(100, 154, 255, 0.2);
            color: var(--page-white);
            border-radius: 12px;
            text-decoration: none;
            font-weight: 600;
            font-size: 1rem;
            cursor: pointer;
            transition: all 0.3s ease;
            border: none;
        }
        
        .close-modal-btn:hover {
            background: rgba(100, 154, 255, 0.3);
        }

        /* CHANGE: Add Terms and Services modal styles */
    .ts-modal {
      display: none;
      position: fixed;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      background: rgba(3, 9, 34, 0.9);
      backdrop-filter: blur(8px);
      z-index: 2500;
      align-items: center;
      justify-content: center;
      padding: 20px;
      z-index: 99999;
    }

    .ts-modal.active {
      display: flex;
    }

    .ts-modal-content {
      background: rgba(6, 16, 48, 0.98);
      border: 1px solid rgba(100, 154, 255, 0.3);
      border-radius: 24px;
      padding: 32px;
      max-width: 600px;
      width: 100%;
      max-height: 80vh;
      overflow-y: auto;
      display: flex;
      flex-direction: column;
    }

    .ts-modal-header {
      margin-bottom: 24px;
      border-bottom: 1px solid rgba(100, 154, 255, 0.2);
      padding-bottom: 16px;
    }

    .ts-modal-header h2 {
      margin: 0;
      font-size: 1.5rem;
      color: var(--page-white);
    }

    .ts-modal-body {
      flex: 1;
      overflow-y: auto;
      margin-right: 8px; /* Added for scrollbar spacing */
      padding-right: 8px; /* Ensure content doesn't touch scrollbar */
    }

    .ts-modal-body::-webkit-scrollbar {
      width: 6px;
    }

    .ts-modal-body::-webkit-scrollbar-track {
      background: rgba(100, 154, 255, 0.1);
      border-radius: 3px;
    }

    .ts-modal-body::-webkit-scrollbar-thumb {
      background: rgba(77, 225, 193, 0.3);
      border-radius: 3px;
    }

    .ts-modal-body::-webkit-scrollbar-thumb:hover {
      background: rgba(77, 225, 193, 0.5);
    }

    .ts-modal-body h3 {
      color: var(--page-white);
      margin-top: 20px;
      margin-bottom: 12px;
      font-size: 1.1rem;
    }

    .ts-modal-body p {
      color: rgba(205, 219, 255, 0.8);
      line-height: 1.6;
      margin-bottom: 12px;
      font-size: 0.95rem;
    }

    .ts-modal-body ul {
      color: rgba(205, 219, 255, 0.8);
      line-height: 1.6;
      margin-bottom: 12px;
      margin-left: 20px;
      font-size: 0.95rem;
    }

    .ts-modal-body li {
      margin-bottom: 8px;
    }

    .ts-modal-footer {
      display: flex;
      gap: 12px;
      justify-content: flex-end;
      align-items: center;
      border-top: 1px solid rgba(100, 154, 255, 0.2);
      padding-top: 20px;
    }

    .ts-checkbox-container {
      display: flex;
      align-items: center;
      gap: 8px;
    }

    .ts-checkbox {
      width: 20px;
      height: 20px;
      cursor: pointer;
      accent-color: var(--page-mint);
    }

    .ts-checkbox-label {
      color: rgba(205, 219, 255, 0.8);
      font-size: 0.9rem;
      cursor: pointer;
    }

    .ts-modal-actions {
      display: flex;
      gap: 12px;
      justify-content: flex-end;
    }

    .ts-checkbox-wrapper {
      background: rgba(77, 225, 193, 0.08);
      border: 1px solid rgba(77, 225, 193, 0.3);
      border-radius: 12px;
      padding: 16px;
      margin-bottom: 24px;
      display: flex;
      align-items: center;
      gap: 12px;
    }

    .ts-checkbox-wrapper input[type="checkbox"]:disabled {
      opacity: 0.5;
      cursor: not-allowed;
    }

    .ts-checkbox-wrapper input[type="checkbox"]:disabled + label {
      opacity: 0.5;
      cursor: not-allowed;
    }

       .btn-secondary {
      padding: 12px 24px;
      border-radius: 12px;
      border: 1px solid rgba(100, 154, 255, 0.3);
      background: rgba(8, 21, 64, 0.6);
      color: var(--page-white);
      font-weight: 600;
      font-size: 0.9rem;
      cursor: pointer;
      transition: all 0.3s ease;
    }
    
    .btn-secondary:hover {
      border-color: rgba(77, 225, 193, 0.5);
    }
    
        .mobile-fintech-footer {
            display: none;
            position: fixed;
            left: 12px;
            right: 12px;
            bottom: 16px;
            padding: 10px;
            background: transparent;
            border: 1px solid rgba(86, 139, 241, 0.35);
            border-radius: 32px;
            backdrop-filter: blur(50px);
            box-shadow: 0 20px 60px rgba(4, 10, 36, 0.7);
            justify-content: space-around;
            align-items: center;
            z-index: 90;
        }

        .mobile-fintech-footer a {
            flex: 1;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            gap: 4px;
            text-decoration: none;
            color: rgba(205, 219, 255, 0.75);
            font-size: 0.45rem;
            letter-spacing: 0.06em;
            text-transform: uppercase;
            transition: all 0.3s;
            padding: 8px 4px;
            border-radius: 16px;
        }

        @media (max-width: 680px) {
            .mobile-fintech-footer {
                display: flex;
            }

            .fullscreen-cover {
                max-width: 300px;
            }

            .fullscreen-info h2 {
                font-size: 1.5rem;
            }

            .fullscreen-controls {
                gap: 1rem;
            }

            .control-btn {
                width: 50px;
                height: 50px;
            }

            .control-btn.play-pause-full {
                width: 70px;
                height: 70px;
            }
        }

        /* Added gamified success popup styles */
        .success-popup-overlay {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(3, 9, 34, 0.95);
            backdrop-filter: blur(20px);
            z-index: 10001;
            display: none;
            align-items: center;
            justify-content: center;
            animation: fadeIn 0.3s ease;
        }

        .success-popup-overlay.active {
            display: flex;
        }

        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }

        .success-popup {
            background: linear-gradient(135deg, rgba(139, 92, 246, 0.2), rgba(236, 72, 153, 0.2));
            border: 2px solid rgba(77, 225, 193, 0.5);
            border-radius: 32px;
            padding: 3rem 2.5rem;
            max-width: 500px;
            width: 90%;
            text-align: center;
            box-shadow: 0 30px 80px rgba(77, 225, 193, 0.4);
            animation: popIn 0.5s cubic-bezier(0.68, -0.55, 0.265, 1.55);
        }

        @keyframes popIn {
            0% {
                transform: scale(0.5);
                opacity: 0;
            }
            100% {
                transform: scale(1);
                opacity: 1;
            }
        }

        .success-icon {
            font-size: 5rem;
            margin-bottom: 1.5rem;
            animation: bounce 1s ease infinite;
        }

        @keyframes bounce {
            0%, 100% { transform: translateY(0); }
            50% { transform: translateY(-10px); }
        }

        .success-popup-cover {
            width: 150px;
            height: 150px;
            border-radius: 20px;
            overflow: hidden;
            margin: 0 auto 1.5rem;
            box-shadow: 0 20px 50px rgba(139, 92, 246, 0.5);
            border: 3px solid rgba(77, 225, 193, 0.6);
        }

        .success-popup-cover img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .success-popup h2 {
            font-size: 1.8rem;
            margin-bottom: 0.5rem;
            color: var(--page-white);
        }

        .success-popup .artist {
            font-size: 1.1rem;
            color: rgba(205, 219, 255, 0.7);
            margin-bottom: 1.5rem;
        }

        .success-popup .reward-amount {
            font-size: 3rem;
            font-weight: 900;
            color: var(--page-mint);
            margin-bottom: 0.5rem;
            text-shadow: 0 0 20px rgba(77, 225, 193, 0.6);
        }

        .success-popup .duration {
            font-size: 0.95rem;
            color: rgba(205, 219, 255, 0.6);
            margin-bottom: 1.5rem;
        }

        .success-popup .message {
            font-size: 1.1rem;
            color: rgba(205, 219, 255, 0.8);
            margin-bottom: 2rem;
            line-height: 1.6;
        }

        .success-popup-close {
            background: linear-gradient(135deg, var(--stream-purple), var(--stream-pink));
            border: none;
            color: white;
            padding: 1rem 2.5rem;
            border-radius: 16px;
            font-size: 1.1rem;
            font-weight: 700;
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .success-popup-close:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 30px rgba(139, 92, 246, 0.5);
        }

         .rewards-hero {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
      gap: clamp(1.25rem, 2.5vw, 1.75rem);
      align-items: center;
      background: var(--panel-glass);
      border-radius: 26px;
      border: 1px solid var(--panel-border);
      padding: clamp(1.75rem, 3vw, 2.375rem);
      box-shadow: var(--shadow-heavy);
      position: relative;
      overflow: hidden;
    }

    .rewards-hero::before {
      content: "";
      position: absolute;
      inset: 0;
      background: url("front/assets/images/header-right-img.png") right/contain no-repeat;
      opacity: 0.08;
        pointer-events: none;
    }

    </style>

    <!-- CHANGE: Added toast notification styles for stream instructions -->
    <style>
      /* Added toast notification styles */
      .alert-message {
        position: fixed;
        top: 20px;
        right: -400px; /* start hidden off-screen */
        padding: 16px 24px;
        border-radius: 12px;
        color: white;
        font-family: 'Segoe UI', sans-serif;
        font-size: 15px;
        z-index: 10000;
        opacity: 0;
        box-shadow: 0 10px 40px rgba(0, 0, 0, 0.2);
        transition: right 0.6s ease, opacity 0.6s ease;
      }

      .alert-message.show {
        right: 20px;
        opacity: 1;
      }

      .alert-info { background-color: rgba(77, 225, 193, 0.2); border: 1px solid rgba(77, 225, 193, 0.4); }
      .alert-success { 
        background: rgba(77, 225, 193, 0.95);
        color: #030922;
        box-shadow: 0 10px 40px rgba(77, 225, 193, 0.4); 
      }
      .alert-warning { background-color: rgba(255, 193, 7, 0.2); border: 1px solid rgba(255, 193, 7, 0.4); color: #ffc107; }
      .alert-error {  
        background: rgba(255, 77, 77, 0.95);
        color: #fff;
        box-shadow: 0 10px 40px rgba(255, 77, 77, 0.4); 
      }
    </style>

<body>
    <?php include "header2.php"; ?>
     <!-- CHANGE: Added Terms and Services Modal -->
  <div class="ts-modal" id="tsModal">
    <div class="ts-modal-content">
      <div class="ts-modal-header"> <!-- 1 -->
        <h2>Stream & Instructions</h2>
                </div>
                <div class="ts-modal-body">
                  <p><strong>Earnova Digital – 2025 Stream & Earn</strong></p>

                  <h3>1. Introduction</h3>
                  <p>Welcome to our Stream & Earn Platform. By using our services, you agree to comply with and be bound by these Terms and Services. If you do not agree with any part of these terms, please do not use our platform.</p>

                  <h3>2. User Responsibilities</h3>
                  <p>As a user, you are responsible for:</p>
                  <ul>
                    <li>Providing accurate and truthful information</li>
                    <li>Streaming music honestly and thoroughly</li>
                    <li>Not using fake profiles or misleading information</li>
                    <li>Not engaging in fraudulent or deceptive practices</li>
                    <li>Maintaining the confidentiality of your account credentials</li>
                  </ul>

                  <h3>3. Music Streaming Requirements</h3>
                  <p>When streaming music:</p>
                  <ul>
                    <li>You must stream tracks for the full duration required</li>
                    <li>You must use your genuine account or profile</li>
                    <li>Track information and metadata must be valid and not duplicated</li>
                    <li>Any violation may result in rejection and account suspension</li>
                  </ul>

                  <h3>4. Verification and Approval</h3>
                  <p>All stream submissions are subject to verification. We reserve the right to:</p>
                  <ul>
                    <li>Review and verify all stream submissions</li>
                    <li>Reject submissions that don't meet requirements</li>
                    <li>Flag suspicious activity for investigation</li>
                    <li>Withhold or reverse earnings for fraudulent submissions</li>
                  </ul>

                  <h3>5. Prohibited Activities</h3>
                  <p>You agree not to:</p>
                  <ul>
                    <li>Use duplicate or fake accounts</li>
                    <li>Submit false track information</li>
                    <li>Use bots or automated tools to stream music</li>
                    <li>Engage in collusion with other users</li>
                    <li>Attempt to exploit platform vulnerabilities</li>
                    <li>Use abusive, harassing, or offensive language</li>
                  </ul>

                  <h3>6. Earnings and Payments</h3>
                  <p>Your earnings are calculated based on:</p>
                  <ul>
                    <li>Successfully streamed and verified tracks</li>
                    <li>Your membership tier</li>
                    <li>Platform-specific reward rates</li>
                  </ul>
                  <p>We reserve the right to modify payment terms and rates at any time with notice.</p>

                  <h3>7. Account Suspension and Termination</h3>
                  <p>We may suspend or terminate your account if you:</p>
                  <ul>
                    <li>Violate these terms and conditions</li>
                    <li>Engage in fraudulent activity</li>
                    <li>Submit false or misleading information</li>
                    <li>Violate platform policies</li>
                  </ul>

                  <h3>8. Liability Disclaimer</h3>
                  <p>The platform is provided "as is" without warranties. We are not liable for:</p>
                  <ul>
                    <li>Lost earnings due to stream rejection</li>
                    <li>Technical issues or platform downtime</li>
                    <li>Actions of third parties or external platforms</li>
                  </ul>

                  <h3>9. Changes to Terms</h3>
                  <p>We reserve the right to modify these terms at any time. Your continued use of the platform constitutes acceptance of any changes.</p>

                  <h3>10. Contact Information</h3>
                  <p>For questions or concerns, please contact our support team through the help section of your account.</p>
                </div>
      <div class="ts-modal-footer">
        <!-- <button class="btn-secondary" id="tsCloseBtn" onclick="closeTSModal()">Close</button> -->
        <div class="ts-checkbox-wrapper" style="margin-bottom: 0;">
          <input type="checkbox" id="tsCheckbox" class="ts-checkbox" <?php echo $stream_agreed ? 'checked disabled' : ''; ?>>
          <label for="tsCheckbox" class="ts-checkbox-label"><span style="font-size: 13px;">I agree</label>
        </div>
        <div class="ts-modal-actions">
          <button class="btn-secondary" id="tsCloseBtn" onclick="closeTSModal()" style="<?php echo $stream_agreed ? 'display: block;' : 'display: none;'; ?>">Close</button>
          <button class="btn-primary" id="tsAgreeBtn" onclick="agreeTSAndClose()" style="<?php echo $stream_agreed ? 'display: none;' : 'display: block;'; ?>">Agree & Continue</button>
        </div>
      </div>
    </div>
  </div>
    <div class="page-shell">
      
       

        <main>
              <section class="rewards-hero" style="background: linear-gradient(135deg, rgba(77, 225, 193, 0.08), rgba(13, 24, 62, 0.78));">
        <div class="rewards-copy">
          <h1 style="font-size: clamp(1rem, 3vw, 1.5rem);">Stream & Earn</h1>
          <p> Stream music and earn rewards! Premium Plus members get paid for every eligible stream.</p>
        </div>
         <!-- CHANGE: Added hero section clickable instructions link -->
            <div style="background: rgba(77, 225, 193, 0.08); border: 1px solid rgba(77, 225, 193, 0.3); border-radius: 12px; padding: 16px; display: flex; align-items: center; gap: 12px; cursor: pointer;" onclick="openStreamInstructionsModal()">
              <input type="checkbox" id="heroCheckbox" style="width: 20px; height: 20px; cursor: pointer; accent-color: var(--page-mint);" onclick="event.stopPropagation(); openStreamInstructionsModal();">
              <label for="heroCheckbox" style="color: rgba(205, 219, 255, 0.8); font-size: 0.9rem; cursor: pointer; margin: 0;">View Stream & Instructions</label>
            </div>
      </section>
           
            
            <!-- Added Stream & Instructions Modal -->
            <div class="ts-modal" id="streamInstructionsModal">
              <div class="ts-modal-content">
                <div class="ts-modal-header">
                  <h2>Stream & Instructions</h2>
                </div>
                <div class="ts-modal-body">
                  <p><strong>Earnova Digital – 2025 Stream & Earn</strong></p>

                  <h3>1. Introduction</h3>
                  <p>Welcome to our Stream & Earn Platform. By using our services, you agree to comply with and be bound by these Terms and Services. If you do not agree with any part of these terms, please do not use our platform.</p>

                  <h3>2. User Responsibilities</h3>
                  <p>As a user, you are responsible for:</p>
                  <ul>
                    <li>Providing accurate and truthful information</li>
                    <li>Streaming music honestly and thoroughly</li>
                    <li>Not using fake profiles or misleading information</li>
                    <li>Not engaging in fraudulent or deceptive practices</li>
                    <li>Maintaining the confidentiality of your account credentials</li>
                  </ul>

                  <h3>3. Music Streaming Requirements</h3>
                  <p>When streaming music:</p>
                  <ul>
                    <li>You must stream tracks for the full duration required</li>
                    <li>You must use your genuine account or profile</li>
                    <li>Track information and metadata must be valid and not duplicated</li>
                    <li>Any violation may result in rejection and account suspension</li>
                  </ul>

                  <h3>4. Verification and Approval</h3>
                  <p>All stream submissions are subject to verification. We reserve the right to:</p>
                  <ul>
                    <li>Review and verify all stream submissions</li>
                    <li>Reject submissions that don't meet requirements</li>
                    <li>Flag suspicious activity for investigation</li>
                    <li>Withhold or reverse earnings for fraudulent submissions</li>
                  </ul>

                  <h3>5. Prohibited Activities</h3>
                  <p>You agree not to:</p>
                  <ul>
                    <li>Use duplicate or fake accounts</li>
                    <li>Submit false track information</li>
                    <li>Use bots or automated tools to stream music</li>
                    <li>Engage in collusion with other users</li>
                    <li>Attempt to exploit platform vulnerabilities</li>
                    <li>Use abusive, harassing, or offensive language</li>
                  </ul>

                  <h3>6. Earnings and Payments</h3>
                  <p>Your earnings are calculated based on:</p>
                  <ul>
                    <li>Successfully streamed and verified tracks</li>
                    <li>Your membership tier</li>
                    <li>Platform-specific reward rates</li>
                  </ul>
                  <p>We reserve the right to modify payment terms and rates at any time with notice.</p>

                  <h3>7. Account Suspension and Termination</h3>
                  <p>We may suspend or terminate your account if you:</p>
                  <ul>
                    <li>Violate these terms and conditions</li>
                    <li>Engage in fraudulent activity</li>
                    <li>Submit false or misleading information</li>
                    <li>Violate platform policies</li>
                  </ul>

                  <h3>8. Liability Disclaimer</h3>
                  <p>The platform is provided "as is" without warranties. We are not liable for:</p>
                  <ul>
                    <li>Lost earnings due to stream rejection</li>
                    <li>Technical issues or platform downtime</li>
                    <li>Actions of third parties or external platforms</li>
                  </ul>

                  <h3>9. Changes to Terms</h3>
                  <p>We reserve the right to modify these terms at any time. Your continued use of the platform constitutes acceptance of any changes.</p>

                  <h3>10. Contact Information</h3>
                  <p>For questions or concerns, please contact our support team through the help section of your account.</p>
                </div>
                <div class="ts-modal-footer">
                  <div class="ts-checkbox-wrapper" style="margin-bottom: 0;">
                    <input type="checkbox" id="streamCheckboxCheck" class="ts-checkbox">
                    <label for="streamCheckboxCheck" class="ts-checkbox-label">Don't show this again</label>
                  </div>
                  <div class="ts-modal-actions">
                    <button class="btn-secondary" onclick="closeStreamInstructionsModal()">Close</button>
                  </div>
                </div>
              </div>
            </div>

            <!-- <?php //if (!$is_premium): ?>
                <div class="alert alert-info">
                     Only Premium members earn from streaming. Upgrade to Premium to start earning ₦200 per track!
                </div>
            <?php //endif; ?> -->

            <!-- <section class="stats-grid" style="background: linear-gradient(135deg, rgba(77, 225, 193, 0.08), rgba(13, 24, 62, 0.78));">
                <div class="stat-card">
                    <div class="stat-label" >Total Earned</div>
                    <div class="stat-value">₦<?php //echo number_format($user_stats['total_earned'], 0); ?></div>
                </div>
            </section> -->

            <section class="player-container">
                <!-- Add playlist button to section header -->
                <div class="section-header">
                    <h2 class="section-title">Available Tracks</h2>
                    <button class="playlist-btn" onclick="openPlaylist()" style="display: none;">
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor">
                            <path d="M15 6H3v2h12V6zm0 4H3v2h12v-2zM3 16h8v-2H3v2zM17 6v8.18c-.31-.11-.65-.18-1-.18-1.66 0-3 1.34-3 3s1.34 3 3 3 3-1.34 3-3V8h3V6h-5z"/>
                        </svg>
                        My Playlist
                    </button>
                </div>
                <div class="track-list" id="trackList">
                    <?php if (empty($tracks)): ?>
                        <p style="text-align: center; padding: 2rem; color: rgba(205, 219, 255, 0.6);">
                            No tracks available yet. Check back soon!
                        </p>
                    <?php else: ?>
                        <?php foreach ($tracks as $track): ?>
                            <?php
                                $free_reward = $track['free_reward'] ?? 100;
                                $premium_reward = $track['premium_reward'] ?? 200;
                                $earning = $is_premium ? $premium_reward : $free_reward;
                                
                                $stmt = $pdo->prepare("
                                    SELECT COUNT(*) as count FROM stream_earnings 
                                    WHERE user_id = ? AND track_id = ? AND is_eligible = 1
                                ");
                                $stmt->execute([$user_id, $track['track_id']]);
                                $userEarning = $stmt->fetch();
                                $isCompleted = $userEarning['count'] > 0;
                                
                                if ($isCompleted) continue;
                            ?>
                            <div class="track-item" 
                                 data-track-id="<?php echo htmlspecialchars($track['track_id']); ?>"
                                 data-track-title="<?php echo htmlspecialchars($track['title']); ?>"
                                 data-track-artist="<?php echo htmlspecialchars($track['artist']); ?>"
                                 data-track-duration="<?php echo $track['duration']; ?>"
                                 data-track-audio="<?php echo htmlspecialchars($track['audio_file']); ?>"
                                 data-track-cover="<?php echo htmlspecialchars($track['cover_image'] ?? '/placeholder.svg?height=60&width=60'); ?>"
                                 data-track-link="<?php echo htmlspecialchars($track['track_link'] ?? ''); ?>"
                                 data-free-reward="<?php echo $free_reward; ?>"
                                 data-premium-reward="<?php echo $premium_reward; ?>"
                                 onclick="openFullscreenPlayer(this)">
                                <div class="track-cover">
                                    <img src="<?php echo htmlspecialchars($track['cover_image'] ?? '/placeholder.svg?height=60&width=60'); ?>" 
                                         alt="<?php echo htmlspecialchars($track['title']); ?>">
                                </div>
                                <div class="track-info">
                                    <h3><?php echo htmlspecialchars($track['title']); ?></h3>
                                    <p><?php echo htmlspecialchars($track['artist']); ?></p>
                                    <!-- Display both free and premium prices -->
                                    <p style="font-size: 0.85rem; margin-top: 0.25rem;">
                                        <!-- <span style="color: rgba(205, 219, 255, 0.6);">Free: ₦<?php //echo number_format($free_reward, 0); ?></span> -->
                                        <span style="color: #fbbf24; margin-left: 0.75rem;">Reward: ₦<?php echo number_format($premium_reward, 0); ?></span>
                                    </p>
                                </div>
                                <div class="track-duration">
                                    <?php echo gmdate("i:s", $track['duration']); ?>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </section>
        </main>
    </div>

    <!-- Full-screen music player overlay -->
    <div class="fullscreen-player" id="fullscreenPlayer">
        <div class="fullscreen-header">
            <button class="close-player-btn" onclick="closeFullscreenPlayer()">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor">
                    <path d="M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12 19 6.41z"/>
                </svg>
            </button>
            <div class="ads-indicator" id="adsIndicator">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor">
                    <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/>
                </svg>
                ADS
            </div>
        </div>
        <div class="fullscreen-content">
            <div class="fullscreen-cover" id="fullscreenCover">
                <img src="/placeholder.svg?height=400&width=400" alt="Album Cover">
            </div>
            <div class="fullscreen-info">
                <h2 id="fullscreenTitle">Track Title</h2>
                <p id="fullscreenArtist">Artist Name</p>
            </div>
            <div class="fullscreen-progress">
                <div class="progress-bar-full">
                    <span class="progress-time-full" id="currentTimeFull">0:00</span>
                    <div class="progress-track-full" id="progressTrackFull" onclick="seekTrackFull(event)">
                        <div class="progress-fill-full" id="progressFillFull"></div>
                    </div>
                    <span class="progress-time-full" id="totalTimeFull">0:00</span>
                </div>
                <!-- Replaced percentage with loading animation -->
                <div class="loading-animation" id="loadingAnimation">
                    <div class="loading-dot"></div>
                    <div class="loading-dot"></div>
                    <div class="loading-dot"></div>
                </div>
                <div class="loading-text" id="loadingText">Streaming...</div>
            </div>
            <div class="fullscreen-controls">
                <!-- Added disabled state and IDs for rewind/forward buttons -->
                <button class="control-btn" id="rewindBtn" onclick="seekBackward()">
                    <svg width="28" height="28" viewBox="0 0 24 24" fill="currentColor">
                        <path d="M11 18V6l-8.5 6 8.5 6zm.5-6l8.5 6V6l-8.5 6z"/>
                    </svg>
                </button>
                <button class="control-btn play-pause-full" id="playPauseBtnFull" onclick="togglePlayPauseFull()">
                    <svg width="32" height="32" viewBox="0 0 24 24" fill="currentColor" id="playIconFull">
                        <path d="M8 5v14l11-7z"/>
                    </svg>
                    <svg width="32" height="32" viewBox="0 0 24 24" fill="currentColor" id="pauseIconFull" style="display: none;">
                        <path d="M6 4h4v16H6V4zm8 0h4v16h-4V4z"/>
                    </svg>
                </button>
                <button class="control-btn" id="forwardBtn" onclick="seekForward()">
                    <svg width="28" height="28" viewBox="0 0 24 24" fill="currentColor">
                        <path d="M4 18l8.5-6L4 6v12zm9-12v12l8.5-6L13 6z"/>
                    </svg>
                </button>
            </div>
            <!-- Added control message for validation feedback -->
            <div class="control-message" id="controlMessage"></div>
            <!-- Claim button now always visible -->
            <div class="claim-section">
                <button class="claim-btn" id="claimBtn" onclick="claimReward()">
                    <svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor">
                        <path d="M12 2L2 7v10c0 5.55 3.84 10.74 9 12 5.16-1.26 9-6.45 9-12V7l-10-5zm0 18c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8zm-1-13h2v6h-2zm0 8h2v2h-2z"/>
                    </svg>
                    <span id="claimBtnText">Claim Reward</span>
                </button>
                <div class="claim-status" id="claimStatus"></div>
                <button class="go-ad-btn" id="goAdBtn" onclick="goToAdLink()">
                    <svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor">
                        <path d="M19 19H5V5h7V3H5c-1.11 0-2 .9-2 2v14c0 1.1.89 2 2 2h14c1.1 0 2-.9 2-2v-7h-2v7zM14 3v2h3.59l-9.83 9.83 1.41 1.41L19 6.41V10h2V3h-7z"/>
                    </svg>
                    <span id="goAdBtnText">Go to Ad</span>
                </button>
            </div>
        </div>
    </div>

    <!-- Email Verification Modal for Audio Ads -->
    <div class="verification-modal" id="adVerificationModal">
        <div class="verification-content">
            <div class="verification-step active" id="adStep1">
                <h2>Verification Required</h2>
                <p>Enter your email to verify that you listened to the track..</p>
                <div id="adCountdownTimer" style="text-align: center; padding: 30px 20px;">
                    <div class="countdown-spinner"></div>
                    <h3 style="color: var(--page-mint); margin-bottom: 12px;">Please wait...</h3>
                    <p style="color: rgba(205, 219, 255, 0.7); font-size: 1.5rem; font-weight: 600;" id="adCountdownText">120</p>
                    <p style="color: rgba(205, 219, 255, 0.5); font-size: 0.9rem;">seconds remaining</p>
                </div>
                <div id="adEmailForm" style="display: none;">
                    <input type="email" class="form-input" id="adEmailInput" placeholder="Enter your email address">
                    <small style="color: rgba(205, 219, 255, 0.6); display: block; margin-top: -8px; margin-bottom: 16px;">
                        Enter the email associated with your account for verification.
                    </small>
                    <div class="verification-actions">
                        <button class="btn-secondary" onclick="cancelAdVerification()">Cancel</button>
                        <button class="btn-primary" id="adSubmitBtn" onclick="submitAdVerification()" disabled>Submit</button>
                    </div>
                </div>
            </div>
            <div class="verification-step" id="adStep2">
                <h2>Verifying...</h2>
                <div style="text-align: center; padding: 40px 20px;">
                    <div class="countdown-spinner"></div>
                    <p style="color: rgba(205, 219, 255, 0.7);">Verifying your email...</p>
                </div>
            </div>
            <div class="verification-step" id="adStep3">
                <h2>Ad Completed!</h2>
                <div style="text-align: center; padding: 40px 20px;">
                    <svg viewBox="0 0 52 52" style="width: 90px; height: 90px; margin-bottom: 18px; filter: drop-shadow(0 4px 10px rgba(0,0,0,0.15));">
                        <circle cx="26" cy="26" r="26" fill="#4de1c1"></circle>
                        <path d="M38 18L22.6 33.4 14 25" fill="none" stroke="#fff" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"/>
                    </svg>
                    <h3 style="margin: 0 0 12px; color: var(--page-mint); font-size: 1.4rem; font-weight: 600;">Congratulations!</h3>
                    <p style="color: rgba(205, 219, 255, 0.75); margin-bottom: 26px; font-size: 1rem;">
                        You've completed the audio ad and earned your reward!
                    </p>
                </div>
                <div class="verification-actions">
                    <button onclick="closeAdVerification()" style="width: 100%; padding: 14px; font-size: 1.1rem; font-weight: 600; cursor: pointer; background: linear-gradient(135deg, #4de1c1, #25bfa3); color: white; border: none; border-radius: 10px; transition: 0.25s ease; box-shadow: 0 6px 16px rgba(0, 255, 188, 0.25);">
                        Continue
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- Playlist overlay -->
    <div class="playlist-overlay" id="playlistOverlay">
        <div class="playlist-header">
            <h2>
                <svg width="28" height="28" viewBox="0 0 24 24" fill="currentColor">
                    <path d="M15 6H3v2h12V6zm0 4H3v2h12v-2zM3 16h8v-2H3v2zM17 6v8.18c-.31-.11-.65-.18-1-.18-1.66 0-3 1.34-3 3s1.34 3 3 3 3-1.34 3-3V8h3V6h-5z"/>
                </svg>
                My Playlist
            </h2>
            <button class="close-player-btn" onclick="closePlaylist()">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor">
                    <path d="M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12 19 6.41z"/>
                </svg>
            </button>
        </div>
        <div class="playlist-content" id="playlistContent">
            <div class="playlist-empty">
                <svg viewBox="0 0 24 24" fill="currentColor">
                    <path d="M15 6H3v2h12V6zm0 4H3v2h12v-2zM3 16h8v-2H3v2zM17 6v8.18c-.31-.11-.65-.18-1-.18-1.66 0-3 1.34-3 3s1.34 3 3 3 3-1.34 3-3V8h3V6h-5z"/>
                </svg>
                <h3>Your playlist is empty</h3>
                <p>Complete listening to tracks to add them to your playlist</p>
            </div>
        </div>
    </div>

    <!-- Added gamified success popup -->
    <div class="success-popup-overlay" id="successPopupOverlay">
        <div class="success-popup">
            <div class="success-icon"></div>
            <div class="success-popup-cover" id="successCover">
                <!-- Dynamic image will be loaded here -->
            </div>
            <h2 id="successTitle">Reward Earned!</h2>
            <p class="artist" id="successArtist">Artist Name</p>
            <div class="reward-amount" id="successReward">₦0</div>
            <p class="duration" id="successDuration">Duration: 0:00</p>
            <p class="message">Congratulations! You've successfully earned your reward. The amount has been added to your Activity Earnings.</p>
            <button class="success-popup-close" onclick="closeSuccessPopup()">Continue Earning</button>
        </div>
    </div>

    <!-- Free User Modal -->
    <div class="free-user-modal" id="freeUserModal">
        <div class="free-user-content">
            <svg viewBox="0 0 24 24" fill="currentColor">
                <path d="M12 2L2 7l10 5 10-5-10-5zm0 18.5l-8-4v-7l8 4 8-4v7l-8 4z"/>
            </svg>
            <h2>Premium Plus Feature</h2>
            <p>Stream & Earn is exclusively for premium Plus members. Upgrade your account to start earning from streaming music!</p>
            <div>
                <a href="membership.php" class="upgrade-btn">Upgrade Now</a>
                <button class="close-modal-btn" onclick="closeFreeUserModal()">Maybe Later</button>
            </div>
        </div>
    </div>

    <nav class="mobile-fintech-footer">
        <a href="dashboard.php" class="active">
            <svg viewBox="0 0 24 24" width="24" height="24" fill="currentColor"><path d="M12 3a9 9 0 1 1 0 18 9 9 0 0 1 0-18Zm1 4h-2v6h6v-2h-4V7Z"/></svg>
            <span>Dashboard</span>
        </a>
        <a href="membership.php">
            <svg viewBox="0 0 24 24" width="24" height="24" fill="currentColor"><path d="M5 7l2.5 5 4.5-4 4.5 4L19 7l2 13H3l2-13Z"/></svg>
            <span>Premium</span>
        </a>
        <a href="daily-rewards.php">
            <svg viewBox="0 0 24 24" width="24" height="24" fill="currentColor"><path d="M20 3H4a1 1 0 0 0-1 1v16l5-3 5 3 5-3 5 3V4a1 1 0 0 0-1-1Zm-2 5-6.7 6.7L7 10.4l1.4-1.4 2.9 2.9L17.6 6 18 8Z"/></svg>
            <span>Rewards</span>
        </a>
        <a href="history.php">
            <svg viewBox="0 0 24 24" width="24" height="24" fill="currentColor"><path d="M13 3a9 9 0 1 0 9 9h-2a7 7 0 1 1-7-7V3a5 5 0 1 0 5 5h2a7 7 0 1 1-7-7z"/></svg>
            <span>History</span>
        </a>
        <a href="profile.php">
            <svg viewBox="0 0 24 24" width="24" height="24" fill="currentColor"><path d="M12 2a6 6 0 0 1 6 6c0 3.31-2.69 6-6 6s-6-2.69-6-6a6 6 0 0 1 6-6Zm0 14c4.42 0 8 1.79 8 4v2H4v-2c0-2.21 3.58-4 8-4Z"/></svg>
            <span>Profile</span>
        </a>
    </nav>

    <audio id="audioPlayer" preload="metadata"></audio>

    <script>
        const audioPlayer = document.getElementById('audioPlayer');
        const fullscreenPlayer = document.getElementById('fullscreenPlayer');
        const playIconFull = document.getElementById('playIconFull');
        const pauseIconFull = document.getElementById('pauseIconFull');
        const progressFillFull = document.getElementById('progressFillFull');
        const currentTimeFull = document.getElementById('currentTimeFull');
        const totalTimeFull = document.getElementById('totalTimeFull');
        const loadingAnimation = document.getElementById('loadingAnimation');
        const loadingText = document.getElementById('loadingText');
        const claimBtn = document.getElementById('claimBtn');
        const claimBtnText = document.getElementById('claimBtnText');
        const claimStatus = document.getElementById('claimStatus');
        const playlistOverlay = document.getElementById('playlistOverlay');
        const playlistContent = document.getElementById('playlistContent');
        const rewindBtn = document.getElementById('rewindBtn');
        const forwardBtn = document.getElementById('forwardBtn');
        const controlMessage = document.getElementById('controlMessage');
        const successPopupOverlay = document.getElementById('successPopupOverlay');
        const freeUserModal = document.getElementById('freeUserModal');
        const streamInstructionsModal = document.getElementById('streamInstructionsModal');
        const streamCheckboxCheck = document.getElementById('streamCheckboxCheck');
        const adsIndicator = document.getElementById('adsIndicator');
        const goAdBtn = document.getElementById('goAdBtn');
        const goAdBtnText = document.getElementById('goAdBtnText');
        const adVerificationModal = document.getElementById('adVerificationModal');
        const adEmailInput = document.getElementById('adEmailInput');
        const adSubmitBtn = document.getElementById('adSubmitBtn');

        const tsModal = document.getElementById('tsModal');
        const tsCheckbox = document.getElementById('tsCheckbox');
        const tsAgreeBtn = document.getElementById('tsAgreeBtn');
        const tsCloseBtn = document.getElementById('tsCloseBtn');


        let currentTrack = null;
        let hasClaimedPayout = false;
        let isPremium = <?php echo $is_premium ? 'true' : 'false'; ?>;
        let completedTracks = [];
        let userPlaylist = [];
        let playbackCounts = {};
        
        let adLeftTime = null;
        let adReturnCheckInterval = null;
        let adCountdownInterval = null;
        let adVerificationPending = false;
        const AD_WAIT_TIME = 30;
        
        // CHANGE: Toast notification function for stream instructions
        function showToast(message, type = 'info') {
          const toast = document.createElement('div');
          toast.className = `alert-message alert-${type}`;
          toast.textContent = message;
          document.body.appendChild(toast);

          setTimeout(() => {
            toast.classList.add('show');
          }, 50);

          setTimeout(() => {
            toast.classList.remove('show');
            setTimeout(() => toast.remove(), 600);
          }, 4000);
        }

        
        
         // Terms and Services Modal Functions
    document.addEventListener('DOMContentLoaded', function() {
      const tsCheckbox = document.getElementById('tsCheckbox');
      if (tsCheckbox) {
        tsCheckbox.disabled = false;
      }
    });

    function openTSModal() {
      const modal = document.getElementById('tsModal');
      if (modal) {
        modal.classList.add('active');
      }
    }

    function closeTSModal() {
      const modal = document.getElementById('tsModal');
      if (modal) {
        modal.classList.remove('active');
      }
      const tsCheckbox = document.getElementById('tsCheckbox');
      const tsAgreeBtn = document.getElementById('tsAgreeBtn');
      const tsCloseBtn = document.getElementById('tsCloseBtn');

      if (tsCheckbox && !tsCheckbox.disabled) { // Only reset if not permanently agreed
        tsCheckbox.checked = false;
        if(tsAgreeBtn) tsAgreeBtn.style.display = 'block';
        if(tsCloseBtn) tsCloseBtn.style.display = 'none';
      }
    }

    function agreeTSAndClose() {
      const tsCheckbox = document.getElementById('tsCheckbox');
      if(tsCheckbox) tsCheckbox.checked = true;
      
      if(tsCheckbox) tsCheckbox.disabled = true;
      const tsAgreeBtn = document.getElementById('tsAgreeBtn');
      const tsCloseBtn = document.getElementById('tsCloseBtn');
      if(tsAgreeBtn) tsAgreeBtn.style.display = 'none';
      if(tsCloseBtn) tsCloseBtn.style.display = 'block';
      
      fetch('stream-earn.php', { // Updated to stream-earn.php for AJAX POST
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: 'ajax=1&action=agree_terms'
      })
      .then(response => response.json())
      .then(data => {
        if (data.success) {
          closeTSModal();
          showToast('Stream instructions accepted!', 'success');
        } else {
          // Re-enable buttons if AJAX fails
          if(tsCheckbox) tsCheckbox.disabled = false; // Re-enable checkbox
          if(tsCheckbox) tsCheckbox.checked = false; // Reset checkbox
          if(tsAgreeBtn) tsAgreeBtn.style.display = 'block';
          if(tsCloseBtn) tsCloseBtn.style.display = 'none';
          showToast('Failed to save agreement. Please try again.', 'error');
        }
      })
      .catch(error => {
        console.error('Error agreeing to instructions:', error);
        // Re-enable buttons if AJAX fails
        if(tsCheckbox) tsCheckbox.disabled = false; // Re-enable checkbox
        if(tsCheckbox) tsCheckbox.checked = false; // Reset checkbox
        if(tsAgreeBtn) tsAgreeBtn.style.display = 'block';
        if(tsCloseBtn) tsCloseBtn.style.display = 'none';
        showToast('Failed to save agreement. Please try again.', 'error');
      });
    }

        // CHANGE: Hero section instructions modal functions
        function openStreamInstructionsModal() { // Renamed for clarity
          const modal = document.getElementById('streamInstructionsModal');
          if (modal) modal.classList.add('active');
        }

        function closeStreamInstructionsModal() { // Renamed for clarity
          const modal = document.getElementById('streamInstructionsModal');
          if (modal) modal.classList.remove('active');
          
          const checkbox = document.getElementById('streamCheckboxCheck');
          if (checkbox && checkbox.checked) {
            localStorage.setItem('hideStreamInstructionsModal', 'true'); // Updated key
          }
        }

        // CHANGE: Initialize modals on page load
        document.addEventListener('DOMContentLoaded', () => {
          const tsCheckbox = document.getElementById('tsCheckbox');
          if (tsCheckbox) {
            <?php if ($stream_agreed): ?>
              tsCheckbox.checked = true;
              tsCheckbox.disabled = true;
              document.getElementById('tsAgreeBtn').style.display = 'none';
              document.getElementById('tsCloseBtn').style.display = 'block';
            <?php else: ?>
              setTimeout(openTSModal, 500);
            <?php endif; ?>
          }

          // Hide hero instructions if user selected "don't show again"
        //   if (localStorage.getItem('hideStreamInstructionsModal') === 'true') { // Updated key
        //     const heroCheckboxContainer = document.querySelector('div[onclick="openStreamInstructionsModal()"]'); // Updated function call
        //     if (heroCheckboxContainer) heroCheckboxContainer.style.display = 'none';
        //   }
        });

        async function loadCompletedTracks() {
            try {
                const response = await fetch('api/get-completed-tracks.php');
                const data = await response.json();
                if (data.success) {
                    completedTracks = data.completed_tracks;
                    completedTracks.forEach(trackId => {
                        const trackElement = document.querySelector(`[data-track-id="${trackId}"]`);
                        if (trackElement) {
                            trackElement.classList.add('completed');
                        }
                    });
                }
            } catch (error) {
                console.error(' Error loading completed tracks:', error);
            }
        }

        function openFullscreenPlayer(element) {
            // Show premium lock popup for free users
            if (!isPremium) {
                freeUserModal.classList.add('active');
                return; // Stop execution here - don't open player
            }

            const trackId = element.dataset.trackId;
            const trackTitle = element.dataset.trackTitle;
            const trackArtist = element.dataset.trackArtist;
            const trackDuration = parseInt(element.dataset.trackDuration);
            const trackAudio = element.dataset.trackAudio;
            const trackCover = element.dataset.trackCover;
            const trackLink = element.dataset.trackLink || '';
            const freeReward = parseFloat(element.dataset.freeReward);
            const premiumReward = parseFloat(element.dataset.premiumReward);

            currentTrack = {
                id: trackId,
                title: trackTitle,
                artist: trackArtist,
                duration: trackDuration,
                audio: trackAudio,
                cover: trackCover,
                link: trackLink,
                freeReward: freeReward,
                premiumReward: premiumReward,
                reward: isPremium ? premiumReward : freeReward
            };

            hasClaimedPayout = completedTracks.includes(trackId);
            
            if (trackLink && trackLink.trim() !== '') {
                adsIndicator.classList.add('active');
            } else {
                adsIndicator.classList.remove('active');
            }
            
            goAdBtn.classList.remove('active');
            adVerificationPending = false;

            if (!playbackCounts[trackId]) {
                playbackCounts[trackId] = 0;
            }
            playbackCounts[trackId]++;

            const isFirstPlayback = playbackCounts[trackId] === 1;
            rewindBtn.disabled = isFirstPlayback;
            forwardBtn.disabled = isFirstPlayback;

            // Update UI
            document.getElementById('fullscreenTitle').textContent = trackTitle;
            document.getElementById('fullscreenArtist').textContent = trackArtist;
            document.getElementById('fullscreenCover').innerHTML = `<img src="${trackCover}" alt="${trackTitle}">`;
            document.getElementById('totalTimeFull').textContent = formatTime(trackDuration);

            // Load and play audio
            audioPlayer.src = trackAudio;
            audioPlayer.load();
            audioPlayer.play();

            // Show fullscreen player
            fullscreenPlayer.classList.add('active');

            // Update play/pause button
            playIconFull.style.display = 'none';
            pauseIconFull.style.display = 'block';

            // Reset claim button
            updateClaimButton();
            controlMessage.textContent = '';

            console.log(' Playing track:', trackTitle, 'Playback count:', playbackCounts[trackId]);
        }

        function closeFullscreenPlayer() {
            fullscreenPlayer.classList.remove('active');
            audioPlayer.pause();
            audioPlayer.currentTime = 0;
        }

        function togglePlayPauseFull() {
            if (audioPlayer.paused) {
                audioPlayer.play();
                playIconFull.style.display = 'none';
                pauseIconFull.style.display = 'block';
            } else {
                audioPlayer.pause();
                playIconFull.style.display = 'block';
                pauseIconFull.style.display = 'none';
            }
        }

        function seekTrackFull(event) {
            if (currentTrack && playbackCounts[currentTrack.id] === 1) {
                const percentage = (audioPlayer.currentTime / audioPlayer.duration) * 100;
                if (percentage < 100) {
                    controlMessage.textContent = 'Seeking is locked on first playback. Listen to 100% first.';
                    setTimeout(() => { controlMessage.textContent = ''; }, 3000);
                    return;
                }
            }

            const progressTrack = document.getElementById('progressTrackFull');
            const clickX = event.offsetX;
            const width = progressTrack.offsetWidth;
            const percentage = clickX / width;
            audioPlayer.currentTime = audioPlayer.duration * percentage;
        }

        function seekBackward() {
            if (rewindBtn.disabled) {
                const percentage = (audioPlayer.currentTime / audioPlayer.duration) * 100;
                if (percentage < 100) {
                    controlMessage.textContent = 'Rewind is locked on first playback. Listen to 100% first.';
                    setTimeout(() => { controlMessage.textContent = ''; }, 3000);
                }
                return;
            }
            audioPlayer.currentTime = Math.max(0, audioPlayer.currentTime - 10);
        }

        function seekForward() {
            if (forwardBtn.disabled) {
                const percentage = (audioPlayer.currentTime / audioPlayer.duration) * 100;
                if (percentage < 100) {
                    controlMessage.textContent = 'Fast-forward is locked on first playback. Listen to 100% first.';
                    setTimeout(() => { controlMessage.textContent = ''; }, 3000);
                }
                return;
            }
            audioPlayer.currentTime = Math.min(audioPlayer.duration, audioPlayer.currentTime + 10);
        }

        function formatTime(seconds) {
            const mins = Math.floor(seconds / 60);
            const secs = Math.floor(seconds % 60);
            return `${mins}:${secs.toString().padStart(2, '0')}`;
        }

        function updateClaimButton() {
            if (!isPremium) {
                claimBtn.disabled = true;
                claimBtnText.textContent = 'Premium Plus Members Only';
                claimStatus.textContent = `Upgrade to Premium Plus to earn ₦${currentTrack ? currentTrack.premiumReward.toFixed(0) : '200'} per track`;
                goAdBtn.classList.remove('active');
                return;
            }

            if (!currentTrack) {
                claimBtn.disabled = true;
                claimBtnText.textContent = 'Claim Reward';
                goAdBtn.classList.remove('active');
                return;
            }

            const currentTime = audioPlayer.currentTime;
            const duration = currentTrack.duration;
            const percentage = (currentTime / duration) * 100;
            const hasAdLink = currentTrack.link && currentTrack.link.trim() !== '';

            if (hasClaimedPayout) {
                claimBtn.disabled = true;
                claimBtnText.textContent = 'Already Claimed';
                claimStatus.textContent = `₦${currentTrack.reward.toFixed(0)} has been added to your wallet`;
                goAdBtn.classList.remove('active');
            } else if (percentage >= 100) {
                if (hasAdLink && !adVerificationPending) {
                    claimBtn.disabled = true;
                    claimBtn.style.display = 'none';
                    goAdBtn.classList.add('active');
                    goAdBtnText.textContent = 'Go to Ad';
                    claimStatus.textContent = `You listened to 100%! Click "Go to Ad" to complete the ad and claim your reward.`;
                } else if (adVerificationPending) {
                    claimBtn.disabled = false;
                    claimBtn.style.display = 'inline-flex';
                    goAdBtn.classList.remove('active');
                    claimBtnText.textContent = `Claim ₦${currentTrack.reward.toFixed(0)} Now!`;
                    claimStatus.textContent = `Ad completed! Click to claim your ₦${currentTrack.reward.toFixed(0)} reward.`;
                } else {
                    claimBtn.disabled = false;
                    claimBtn.style.display = 'inline-flex';
                    goAdBtn.classList.remove('active');
                    claimBtnText.textContent = `Claim ₦${currentTrack.reward.toFixed(0)} Now!`;
                    claimStatus.textContent = `You listened to 100%! Click to claim your ₦${currentTrack.reward.toFixed(0)} reward.`;
                }
            } else {
                claimBtn.disabled = true;
                claimBtn.style.display = 'inline-flex';
                claimBtnText.textContent = `Claim ₦${currentTrack.reward.toFixed(0)} Reward`;
                claimStatus.textContent = `Keep listening to unlock your ₦${currentTrack.reward.toFixed(0)} reward`;
                goAdBtn.classList.remove('active');
            }
        }
        
        function goToAdLink() {
            if (!currentTrack || !currentTrack.link) return;
            
            adLeftTime = Date.now();
            sessionStorage.setItem('adLeftTime', adLeftTime.toString());
            sessionStorage.setItem('adTrackId', currentTrack.id);
            
            window.open(currentTrack.link, '_blank');
            
            goAdBtn.disabled = true;
            goAdBtnText.textContent = 'Waiting for return...';
            claimStatus.textContent = 'Stream the tracks on the page and return afterward to collect your rewards.';
            
            document.addEventListener('visibilitychange', handleVisibilityChange);
        }
        
          function handleVisibilityChange() {
            if (document.visibilityState === 'visible' && adLeftTime) {
                const timeSpent = (Date.now() - adLeftTime) / 1000;
                
                if (timeSpent >= AD_WAIT_TIME) {
                    document.removeEventListener('visibilitychange', handleVisibilityChange);
                    showAdVerificationModal();
                } else {
                    const remaining = Math.ceil(AD_WAIT_TIME - timeSpent);
                    claimStatus.textContent = `You need to spend at least 1 minutes on the ad page. ${remaining} seconds remaining.`;
                    // showToast(`Please spend more time on the ad page. ${remaining} seconds remaining.`, 'warning');
                }
            }
        }
        
        
        function showAdVerificationModal() {
            adVerificationModal.classList.add('active');
            document.getElementById('adStep1').classList.add('active');
            document.getElementById('adStep2').classList.remove('active');
            document.getElementById('adStep3').classList.remove('active');
            
            let countdown = 60;
            document.getElementById('adCountdownText').textContent = countdown;
            document.getElementById('adCountdownTimer').style.display = 'block';
            document.getElementById('adEmailForm').style.display = 'none';
            
            adCountdownInterval = setInterval(() => {
                countdown--;
                document.getElementById('adCountdownText').textContent = countdown;
                
                if (countdown <= 0) {
                    clearInterval(adCountdownInterval);
                    document.getElementById('adCountdownTimer').style.display = 'none';
                    document.getElementById('adEmailForm').style.display = 'block';
                }
            }, 1000);
        }
        
        function validateAdEmail() {
            const email = adEmailInput.value.trim();
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            adSubmitBtn.disabled = !emailRegex.test(email);
        }
        
        if (adEmailInput) {
            adEmailInput.addEventListener('input', validateAdEmail);
        }
        
        function submitAdVerification() {
            const email = adEmailInput.value.trim();
            if (!email || !currentTrack) return;
            
            document.getElementById('adStep1').classList.remove('active');
            document.getElementById('adStep2').classList.add('active');
            
            fetch('api/verify-ad-email.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    track_id: currentTrack.id,
                    email: email
                })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    setTimeout(() => {
                        document.getElementById('adStep2').classList.remove('active');
                        document.getElementById('adStep3').classList.add('active');
                        
                        adVerificationPending = true;
                        adLeftTime = null;
                        sessionStorage.removeItem('adLeftTime');
                        sessionStorage.removeItem('adTrackId');
                        
                        goAdBtn.classList.remove('active');
                        goAdBtn.disabled = false;
                        goAdBtnText.textContent = 'Go to Ad';
                        
                        updateClaimButton();
                    }, 2000);
                } else {
                    document.getElementById('adStep2').classList.remove('active');
                    document.getElementById('adStep1').classList.add('active');
                    showToast(data.message || 'Verification failed. Please try again.', 'error');
                }
            })
            .catch(error => {
                console.error('Verification error:', error);
                document.getElementById('adStep2').classList.remove('active');
                document.getElementById('adStep1').classList.add('active');
                showToast('An error occurred during verification. Please try again.', 'error');
            });
        }
        
        function cancelAdVerification() {
            if (adCountdownInterval) {
                clearInterval(adCountdownInterval);
            }
            adVerificationModal.classList.remove('active');
            goAdBtn.disabled = false;
            goAdBtnText.textContent = 'Go to Ad';
            claimStatus.textContent = 'Click "Go to Ad" to visit the advertiser page.';
        }
        
        function closeAdVerification() {
            adVerificationModal.classList.remove('active');
        }

        audioPlayer.addEventListener('timeupdate', function() {
            const currentTime = audioPlayer.currentTime;
            const duration = audioPlayer.duration;

            if (duration) {
                const percentage = (currentTime / duration) * 100;
                progressFillFull.style.width = percentage + '%';
                currentTimeFull.textContent = formatTime(currentTime);
                
                if (percentage < 100) {
                    loadingText.textContent = 'Streaming...';
                    loadingAnimation.style.display = 'flex'; // Ensure animation is visible
                } else {
                    loadingText.textContent = 'Complete!';
                    loadingAnimation.style.display = 'none';
                }
                
                updateClaimButton();

                if (currentTrack && playbackCounts[currentTrack.id] === 1 && percentage >= 100) {
                    rewindBtn.disabled = false;
                    forwardBtn.disabled = false;
                }
            }
        });

        audioPlayer.addEventListener('ended', async function() {
            console.log(' Track ended at 100%');
            
            if (currentTrack && !hasClaimedPayout) {
                // Add to playlist
                await addToPlaylist(currentTrack);
                
                completedTracks.push(currentTrack.id);
                const trackElement = document.querySelector(`[data-track-id="${currentTrack.id}"]`);
                if (trackElement) {
                    trackElement.classList.add('completed');
                }

                // Enable claim button
                updateClaimButton();

                rewindBtn.disabled = false;
                forwardBtn.disabled = false;
            }
        });

        async function claimReward() {
            if (!currentTrack || hasClaimedPayout || !isPremium) return;

            const percentage = (audioPlayer.currentTime / currentTrack.duration) * 100;
            
            if (percentage < 100) {
                claimStatus.textContent = 'You must listen to 100% of the track to claim';
                controlMessage.textContent = 'Complete the full track to unlock your reward!';
                setTimeout(() => { controlMessage.textContent = ''; }, 3000);
                return;
            }

            claimBtn.disabled = true;
            claimBtnText.textContent = 'Processing...';

            try {
                const response = await fetch('api/stream-record.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({
                        track_id: currentTrack.id,
                        track_title: currentTrack.title,
                        stream_duration: Math.floor(currentTrack.duration),
                        track_duration: currentTrack.duration
                    })
                });

                const data = await response.json();
                console.log(' Claim response:', data);

                if (data.success) {
                    if (data.payout_awarded) {
                        hasClaimedPayout = true;
                        showSuccessPopup(currentTrack, data.payout_amount);
                        
                        updateClaimButton();
                    } else {
                        claimStatus.textContent = data.message;
                        claimBtn.disabled = false;
                        claimBtnText.textContent = 'Try Again';
                    }
                } else {
                    claimStatus.textContent = data.message || 'Failed to claim reward';
                    claimBtn.disabled = false;
                    claimBtnText.textContent = 'Try Again';
                }
            } catch (error) {
                console.error(' Error claiming reward:', error);
                claimStatus.textContent = 'An error occurred. Please try again.';
                claimBtn.disabled = false;
                claimBtnText.textContent = 'Try Again';
            }
        }

        function showSuccessPopup(track, amount) {
            document.getElementById('successCover').innerHTML = `<img src="${track.cover}" alt="${track.title}">`;
            document.getElementById('successTitle').textContent = track.title;
            document.getElementById('successArtist').textContent = track.artist;
            document.getElementById('successReward').textContent = `₦${amount.toFixed(0)}`;
            document.getElementById('successDuration').textContent = `Duration: ${formatTime(track.duration)}`;
            
            successPopupOverlay.classList.add('active');
        }

        function closeSuccessPopup() {
            successPopupOverlay.classList.remove('active');
            closeFullscreenPlayer();
            // Reload page to update balance
            setTimeout(() => {
                location.reload();
            }, 500);
        }

        function closeFreeUserModal() {
            freeUserModal.classList.remove('active');
        }

        async function addToPlaylist(track) {
            try {
                const response = await fetch('api/add-to-playlist.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({
                        track_id: track.id,
                        track_title: track.title,
                        artist: track.artist,
                        cover_image: track.cover,
                        audio_file: track.audio,
                        duration: track.duration
                    })
                });

                const data = await response.json();
                if (data.success) {
                    console.log(' Added to playlist');
                }
            } catch (error) {
                console.error(' Error adding to playlist:', error);
            }
        }

        async function openPlaylist() {
            playlistOverlay.classList.add('active');
            await loadPlaylist();
        }

        function closePlaylist() {
            playlistOverlay.classList.remove('active');
        }

        async function loadPlaylist() {
            try {
                const response = await fetch('api/get-playlist.php');
                const data = await response.json();

                if (data.success && data.playlist.length > 0) {
                    userPlaylist = data.playlist;
                    playlistContent.innerHTML = data.playlist.map(track => `
                        <div class="playlist-item" onclick='playFromPlaylist(${JSON.stringify(track)})'>
                            <div class="playlist-cover">
                                <img src="${track.cover_image || '/placeholder.svg?height=80&width=80'}" alt="${track.track_title}">
                            </div>
                            <div class="playlist-item-info">
                                <h3>${track.track_title}</h3>
                                <p>${track.artist}</p>
                                <p style="font-size: 0.8rem; margin-top: 0.25rem;">Added ${new Date(track.added_at).toLocaleDateString()}</p>
                            </div>
                            <div class="track-duration">
                                ${formatTime(track.duration)}
                            </div>
                        </div>
                    `).join('');
                } else {
                    playlistContent.innerHTML = `
                        <div class="playlist-empty">
                            <svg viewBox="0 0 24 24" fill="currentColor">
                                <path d="M15 6H3v2h12V6zm0 4H3v2h12v-2zM3 16h8v-2H3v2zM17 6v8.18c-.31-.11-.65-.18-1-.18-1.66 0-3 1.34-3 3s1.34 3 3 3 3-1.34 3-3V8h3V6h-5z"/>
                            </svg>
                            <h3>Your playlist is empty</h3>
                            <p>Complete listening to tracks to add them to your playlist</p>
                        </div>
                    `;
                }
            } catch (error) {
                console.error(' Error loading playlist:', error);
            }
        }

        function playFromPlaylist(track) {
            closePlaylist();
            
            currentTrack = {
                id: track.track_id,
                title: track.track_title,
                artist: track.artist,
                duration: track.duration,
                audio: track.audio_file,
                cover: track.cover_image
            };

            hasClaimedPayout = completedTracks.includes(track.track_id);

            if (!playbackCounts[track.track_id]) {
                playbackCounts[track.track_id] = 0;
            }
            playbackCounts[track.track_id]++;

            rewindBtn.disabled = false;
            forwardBtn.disabled = false;

            // Update UI
            document.getElementById('fullscreenTitle').textContent = track.track_title;
            document.getElementById('fullscreenArtist').textContent = track.artist;
            document.getElementById('fullscreenCover').innerHTML = `<img src="${track.cover_image}" alt="${track.track_title}">`;
            document.getElementById('totalTimeFull').textContent = formatTime(track.duration);

            // Load and play audio
            audioPlayer.src = track.audio_file;
            audioPlayer.load();
            audioPlayer.play();

            // Show fullscreen player
            fullscreenPlayer.classList.add('active');

            // Update play/pause button
            playIconFull.style.display = 'none';
            pauseIconFull.style.display = 'block';

            updateClaimButton();
        }

        loadCompletedTracks();
    </script>

    <!-- Added Stream & Instructions modal functions -->
    <script>
      function openStreamInstructionsModal() {
        const modal = document.getElementById('streamInstructionsModal');
        if (modal) modal.classList.add('active');
      }

      function closeStreamInstructionsModal() {
        const modal = document.getElementById('streamInstructionsModal');
        if (modal) modal.classList.remove('active');
        
        const checkbox = document.getElementById('streamCheckboxCheck');
        if (checkbox && checkbox.checked) {
          localStorage.setItem('hideStreamInstructionsModal', 'true');
        }
      }

      document.addEventListener('DOMContentLoaded', () => {
        if (localStorage.getItem('hideStreamInstructionsModal') === 'true') {
          const heroCheckboxContainer = document.querySelector('div[onclick="openStreamInstructionsModal()"]'); // Corrected function call
          if (heroCheckboxContainer) heroCheckboxContainer.style.display = 'flex';
        }
      });
    </script>
</body>
</html>
